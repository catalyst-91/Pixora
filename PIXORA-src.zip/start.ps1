# PIXORA — Booth Productions  ·  Windows launcher (runs natively so every drive letter is visible)
$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  Write-Host "Node.js is not installed. Install it with:  winget install OpenJS.NodeJS.LTS" -ForegroundColor Yellow; exit 1
}
if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) {
  Write-Host "ffmpeg not found - AVI/WMV/MPEG-2/ProRes files won't be converted. Install with:  winget install Gyan.FFmpeg" -ForegroundColor Yellow
}
if (-not $env:PORT) { $env:PORT = "8080" }
# Allow phones/tablets on the LAN to connect (needs admin once):
#   New-NetFirewallRule -DisplayName "PIXORA" -Direction Inbound -Protocol TCP -LocalPort 8080 -Action Allow
#   New-NetFirewallRule -DisplayName "PIXORA OSC/ArtNet" -Direction Inbound -Protocol UDP -LocalPort 7000,6454,5568 -Action Allow
Start-Process "http://localhost:$($env:PORT)/"
node server.js
