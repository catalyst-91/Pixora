// PIXORA — PJLink projector control (JBMIA PJLink class 1 and class 2), for the Devices hub (server-devices.js).
// TCP 4352. The projector greets with "PJLINK 0" (no password) or "PJLINK 1 <random>" (password: every command is
// prefixed with MD5(random + password) as 32 hex digits). Commands are "%<class><CMD> <param>\r", replies
// "%<class><CMD>=<value>\r" or ERR1 (undefined) / ERR2 (bad parameter) / ERR3 (unavailable now) / ERR4 (projector failure),
// "PJLINK ERRA" on a wrong password. One short connection per command batch, as most projectors close idle sockets.
// Discovery: class 2 "%2SRCH" broadcast on UDP 4352, projectors answer "%2ACKN=<mac>".
'use strict';
module.exports = function pjlink({ Device, net, dgram, crypto }) {
  const TYPES = { pjlink: { label: 'Projector — PJLink (Epson, Panasonic, NEC, Sony, Christie, BenQ, …)', port: 4352, projector: true } };
  const INPUT_KIND = { 1: 'RGB', 2: 'Video', 3: 'Digital', 4: 'Storage', 5: 'Network', 6: 'Internal' };
  const POWER = { 0: 'standby', 1: 'on', 2: 'cooling', 3: 'warming up' };
  const ERRS = { ERR1: 'not supported by this projector', ERR2: 'value out of range', ERR3: 'not possible right now (warming up / cooling / standby)', ERR4: 'projector failure' };
  const ERST = ['fan', 'lamp', 'temperature', 'cover open', 'filter', 'other'];

  // run a batch of commands on one connection → array of reply values (or Error objects)
  function session(host, port, password, cmds, timeout = 5000) {
    return new Promise((resolve, reject) => {
      const s = net.connect({ host, port }); let buf = '', auth = null, out = [], i = -1, done = false;
      const end = (err) => { if (done) return; done = true; clearTimeout(t); try { s.destroy(); } catch {} err ? reject(err) : resolve(out); };
      const t = setTimeout(() => end(new Error('no reply from the projector (timeout)')), timeout);
      const next = () => { i++; if (i >= cmds.length) return end(); s.write((auth || '') + cmds[i] + '\r'); };
      s.setEncoding('latin1'); s.on('error', e => end(e)); s.on('close', () => { if (!done) end(i < 0 ? new Error('connection closed by the projector') : null); });
      s.on('data', d => {
        buf += d; let k;
        while ((k = buf.search(/\r/)) >= 0) {
          const line = buf.slice(0, k).replace(/^\n/, ''); buf = buf.slice(k + 1);
          if (i < 0) { // greeting
            const m = /^PJLINK ([01])(?: (\S+))?/.exec(line); if (!m) { if (/^PJLINK ERRA/.test(line)) return end(new Error('wrong PJLink password')); continue; }
            if (m[1] === '1') { if (!password) return end(new Error('this projector needs its PJLink password')); auth = crypto.createHash('md5').update(m[2] + password).digest('hex'); }
            next(); continue;
          }
          if (/^PJLINK ERRA/.test(line)) return end(new Error('wrong PJLink password'));
          const r = /^%(\d)(\w{4})=(.*)$/.exec(line); if (!r) continue;
          const v = r[3]; out.push(/^ERR[1-4]$/.test(v) ? Object.assign(new Error(ERRS[v]), { code: v }) : v); next();
        }
      });
    });
  }

  class PJLink extends Device {
    async run(cmds) { return session(this.host, this.port, this.cfg.password || '', cmds); }
    async one(cmd) { const [r] = await this.run([cmd]); if (r instanceof Error) throw new Error(`${this.cfg.name}: ${r.message}`); return r; }
    start() { Object.assign(this.state, { inputs: [], info: {} }); this.cls = 1; this.every(+((this.cfg.opts || {}).poll) * 1000 || 10000, () => this.poll()); }
    stop() { this.stopped = true; super.stop(); } retry() {}
    async poll() {
      try {
        const first = !this.state.info.model;
        const q = ['%1POWR ?', '%1INPT ?', '%1AVMT ?', '%1ERST ?', '%1LAMP ?'].concat(first ? ['%1NAME ?', '%1INF1 ?', '%1INF2 ?', '%1INST ?', '%1CLSS ?'] : []);
        const r = await this.run(q); const ok = v => (v instanceof Error ? null : v);
        const st = this.state, info = st.info;
        info.power = POWER[ok(r[0])] || ok(r[0]) || '?'; info.on = ok(r[0]) === '1'; info.input = ok(r[1]) || '';
        const mute = ok(r[2]) || '30'; info.videoMute = /^(11|31)$/.test(mute); info.audioMute = /^(21|31)$/.test(mute);
        const er = ok(r[3]) || ''; info.errors = er;
        const lamps = String(ok(r[4]) || '').trim().split(/\s+/); info.lamps = []; for (let k = 0; k + 1 < lamps.length; k += 2) info.lamps.push({ hours: +lamps[k] || 0, on: lamps[k + 1] === '1' });
        if (first) { info.name = ok(r[5]) || ''; info.make = ok(r[6]) || ''; info.model = ok(r[7]) || 'PJLink projector'; this.cls = +ok(r[9]) || 1;
          st.inputs = String(ok(r[8]) || '').trim().split(/\s+/).filter(Boolean).map(id => ({ id, name: `${INPUT_KIND[id[0]] || 'Input'} ${id[1]}` }));
          if (this.cls >= 2 && st.inputs.length) { try { const names = await this.run(st.inputs.map(x => `%2INNM ?${x.id}`)); names.forEach((n, k) => { if (!(n instanceof Error) && n) st.inputs[k].name = n; }); } catch {} } }
        if (this.cls >= 2) { try { const [f] = await this.run(['%2FILT ?']); if (!(f instanceof Error)) info.filterHours = +f || 0; } catch {} }
        this.health(); if (!st.online) this._online(true); else this.changed();
      } catch (e) { if (this.state.online) this._online(false); this._error(e); }
    }
    health() { // same shape as the LED processors, for the Health page
      const info = this.state.info, H = { at: Date.now(), temp: null, alerts: [], lampHours: info.lamps && info.lamps.length ? Math.max(...info.lamps.map(l => l.hours)) : null };
      String(info.errors || '').split('').forEach((c, k) => { if (c === '1' || c === '2') H.alerts.push({ lvl: c === '2' ? 'err' : 'warn', msg: `${ERST[k] || 'status'} ${c === '2' ? 'error' : 'warning'}` }); });
      const lim = +((this.cfg.opts || {}).lampWarn) || 0; if (lim && H.lampHours >= lim) H.alerts.push({ lvl: 'warn', msg: `lamp at ${H.lampHours} h (limit ${lim} h)` });
      const prev = new Set(((this.state.health || {}).alerts || []).map(a => a.msg)); this.state.health = H;
      for (const a of H.alerts) if (!prev.has(a.msg)) this.hub.monitor('device', `${this.cfg.name}: ${a.msg}`);
    }
    actions() { return [['power', 'Power on/off', ['on']], ['input', 'Input (e.g. 31 = Digital 1, or its name)', ['input']], ['mute', 'Picture + sound mute on/off', ['on']],
      ['videoMute', 'Picture mute (shutter) on/off', ['on']], ['audioMute', 'Sound mute on/off', ['on']], ['freeze', 'Freeze on/off (PJLink class 2)', ['on']]]; }
    async act(name, a = {}) {
      const on = !(a.on === false || a.on === 'false' || a.on === 0 || a.on === '0' || a.on === 'off'); let r;
      switch (name) {
        case 'power': r = await this.one(`%1POWR ${on ? 1 : 0}`); break;
        case 'input': { const v = String(a.input ?? '').trim(); const hit = (this.state.inputs || []).find(x => x.id === v || x.name.toLowerCase() === v.toLowerCase());
          const id = hit ? hit.id : v; if (!/^[1-9][1-9A-Z]$/.test(id)) throw new Error(`${this.cfg.name}: unknown input "${v}"${this.state.inputs.length ? ' — inputs: ' + this.state.inputs.map(x => x.name + ' (' + x.id + ')').join(', ') : ''}`);
          r = await this.one(`%${/[A-Z]/.test(id) ? 2 : 1}INPT ${id}`); break; }
        case 'mute': r = await this.one(`%1AVMT ${on ? 31 : 30}`); break;
        case 'videoMute': r = await this.one(`%1AVMT ${on ? 11 : 10}`); break;
        case 'audioMute': r = await this.one(`%1AVMT ${on ? 21 : 20}`); break;
        case 'freeze': r = await this.one(`%2FREZ ${on ? 1 : 0}`); break;
        default: return super.act(name);
      }
      setTimeout(() => this.poll(), 400); return { ok: r === 'OK', reply: r };
    }
  }

  // class 2 search: broadcast %2SRCH, collect %2ACKN replies for `ms`
  function discover(ms = 2000) {
    return new Promise(resolve => {
      const found = new Map(); let s; try { s = dgram.createSocket({ type: 'udp4', reuseAddr: true }); } catch { return resolve([]); }
      s.on('message', (m, ri) => { const t = m.toString('latin1'); const r = /%2ACKN=([0-9A-Fa-f:]{17})/.exec(t); if (r) found.set(ri.address, { host: ri.address, mac: r[1].toUpperCase() }); });
      s.on('error', () => { try { s.close(); } catch {} resolve([...found.values()]); });
      s.bind(4352, () => { try { s.setBroadcast(true); s.send(Buffer.from('%2SRCH\r'), 4352, '255.255.255.255'); } catch {} });
      setTimeout(() => { try { s.close(); } catch {} resolve([...found.values()]); }, ms);
    });
  }
  return { TYPES, CLASSES: { pjlink: PJLink }, session, discover };
};
