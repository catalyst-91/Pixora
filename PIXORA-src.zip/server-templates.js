// PIXORA show templates — Booth Productions.
// "New show from template" starts a show that is ready to go for a kind of event: named layers with placeholder clips
// (swap them for your media), overlays (lower thirds, logo bug, full-screen titles, countdowns), shared timers, a cue list,
// the view that suits the job and, where it fits, the switcher, replay, data feeds or beat reaction.
'use strict';
module.exports = function templates(S) {
  const gen = (kind, name, p = {}) => ({ type: 'gen', name, gen: { kind, params: Object.assign(S.genDefaults(kind), p) } });
  const TPL = S.GENERATORS.find(g => g.id === 'title').params.find(p => p.k === 'tpl').options; // title designer templates by name
  const POS = S.GENERATORS.find(g => g.id === 'title').params.find(p => p.k === 'pos').options;
  const title = (name, tpl, p = {}) => gen('title', name, Object.assign({ tpl: TPL.indexOf(tpl) }, p.pos ? { pos: POS.indexOf(p.pos) } : {}, Object.fromEntries(Object.entries(p).filter(([k]) => k !== 'pos'))));
  const solid = (name, c1) => gen('solid', name, { c1 });
  // build helpers
  function layers(st, defs) { // defs: [{ name, clips: [clip|null…] }]
    st.layers = defs.map((d, i) => { const L = S.layerDefaults(i, st.comp.columns); L.name = d.name; d.clips.forEach((c, ci) => { if (c) L.clips[ci] = Object.assign(S.clipDefaults ? S.clipDefaults() : {}, c); }); if (d.layer) Object.assign(L, d.layer); return L; });
  }
  const overlays = (st, list) => { st.overlays = list.map(o => Object.assign({ clip: null, on: false, trig: 0, transition: 'fade', dur: 0.5, volume: 1 }, o)); };
  const timers = (st, list) => { st.timers = list.map(t => Object.assign({ mode: 'down', secs: 300, until: '', running: false, startedAt: 0, base: 0 }, t)); };
  let qn = 0; const cue = (name, col, extra = {}) => Object.assign({ id: 'q' + (++qn).toString(36) + Math.random().toString(36).slice(2, 6), name, type: 'column', data: { col }, fade: 1, follow: 'none', wait: 0, tc: '' }, extra);

  const LIST = [
    { id: 'wedding', name: 'Wedding', icon: 'heart', view: 'show', desc: 'Background loops, photo slideshow, names lower third, monogram bug, welcome title, ceremony and speech timers, and a cue for each part of the night.',
      build(st) {
        layers(st, [
          { name: 'Backgrounds', clips: [gen('plasma', 'Soft plasma (swap for your loop)', { c1: '#f7d9e3', c2: '#fff4e6' }), gen('gradient', 'Blush gradient', { c1: '#f3c6d3', c2: '#fdebd3' }), solid('Warm white', '#fff1e0')] },
          { name: 'Photos & video', clips: [{ type: 'playlist', name: 'Photo slideshow (add photos)', items: [], index: 0, order: 'sequential', loop: true, imageSecs: 6, fit: 'fit' }, null, null] },
          { name: 'Titles', clips: [title('Welcome', 'Full-screen title', { line1: 'Welcome', line2: 'Sarah & James · 14 March', c1: '#d4a373', bg: '#00000000', font: 1 }), title('First dance', 'Full-screen title', { line1: 'The First Dance', line2: '', c1: '#d4a373', font: 1 }), title('Thank you', 'Full-screen title', { line1: 'Thank you for celebrating with us', line2: '', c1: '#d4a373', font: 1 })] },
        ]);
        overlays(st, [
          { clip: title('Names', 'Lower third', { line1: 'SARAH & JAMES', line2: 'Saturday 14 March', c1: '#d4a373', font: 1 }) },
          { clip: title('Monogram', 'Corner bug', { line1: 'S & J', line2: '', c1: '#d4a373', font: 1, pos: 'Top right' }) },
          { clip: title('Speech: name', 'Lower third', { line1: 'BEST MAN', line2: 'Tom', c1: '#d4a373', font: 1 }) },
          { clip: title('Countdown', 'Countdown', { line1: 'Ceremony begins in', c1: '#d4a373', minutes: 30, font: 1 }) }]);
        timers(st, [{ name: 'Ceremony', secs: 1800 }, { name: 'Speech', secs: 300 }]);
        st.cues = [cue('Guests arrive', 0), cue('Ceremony', 2), cue('First dance', 1), cue('Speeches', 0), cue('Party', 1)];
      } },
    { id: 'conference', name: 'Conference', icon: 'cam', view: 'production', desc: 'Program switcher with camera, slides and walk-in sources, speaker lower thirds, logo bug, "next session" screen, session and Q&A timers.',
      build(st) {
        layers(st, [
          { name: 'Program', clips: [gen('bars', 'Camera 1 (pick your camera)'), gen('testgrid', 'Slides (pick the slides input)'), gen('gradient', 'Walk-in loop', { c1: '#14213d', c2: '#000000' }), title('Holding slide', 'Full-screen title', { line1: 'We will begin shortly', line2: '{{clock}}' })], layer: { transition: 'fade' } },
          { name: 'Picture in picture', clips: [null, null, null] },
          { name: 'Background', clips: [gen('gradient', 'Brand background', { c1: '#0b132b', c2: '#1c2541' })] },
        ]);
        st.switcher = { on: true, layer: 0, preview: 1, tbar: 0 };
        overlays(st, [
          { clip: title('Speaker', 'Lower third', { line1: 'DR JANE SMITH', line2: 'Head of Research, Example Co.' }) },
          { clip: title('Logo', 'Corner bug', { line1: 'EVENT 2026', line2: '', pos: 'Top right' }) },
          { clip: title('Next session', 'Full-screen title', { line1: 'Next session', line2: 'Panel discussion · 11:30' }) },
          { clip: title('Break countdown', 'Countdown', { line1: 'We will be back in', minutes: 15 }) }]);
        timers(st, [{ name: 'Session', secs: 1200 }, { name: 'Q&A', secs: 600 }, { name: 'Break', secs: 900 }]);
        st.cues = [cue('Walk-in', 2), cue('Opening', 0), cue('Keynote', 0), cue('Break', 3), cue('Close', 2)];
      } },
    { id: 'sports', name: 'Sports', icon: 'restart', view: 'replay', desc: 'Scoreboard driven by a data feed, game clock, instant replay set up, sponsor bug, pre-game, half-time and full-time screens.',
      build(st) {
        layers(st, [
          { name: 'Program', clips: [gen('bars', 'Camera 1 (pick your camera)'), gen('bars', 'Camera 2'), { type: 'replay', name: 'Replay', unit: 'auto', fit: 'fit' }, title('Half-time', 'Full-screen title', { line1: 'HALF-TIME', line2: '{{score.home}} {{score.homeScore}} – {{score.awayScore}} {{score.away}}' })] },
          { name: 'Sponsors', clips: [{ type: 'playlist', name: 'Sponsor loop (add logos)', items: [], index: 0, order: 'sequential', loop: true, imageSecs: 8, fit: 'fit' }] },
        ]);
        st.switcher = { on: true, layer: 0, preview: 1, tbar: 0 };
        overlays(st, [
          { clip: title('Scoreboard', 'Scoreboard', { home: '{{score.home}}', homeScore: '{{score.homeScore}}', away: '{{score.away}}', awayScore: '{{score.awayScore}}', period: '{{score.period}}', line1: '{{timer.Game clock}}', line2: '', pos: 'Top centre' }), on: false },
          { clip: title('Sponsor bug', 'Corner bug', { line1: 'YOUR SPONSOR', line2: '', pos: 'Bottom right' }) },
          { clip: title('Player', 'Lower third', { line1: 'PLAYER NAME', line2: 'Team · Position' }) },
          { clip: title('Pre-game', 'Countdown', { line1: 'Game starts in', minutes: 15 }) }]);
        timers(st, [{ name: 'Game clock', secs: 420 }, { name: 'Half-time', secs: 600 }]);
        st.feeds = [{ id: 'score', name: 'score', type: 'push', url: '', interval: 5, on: true, sample: { home: 'HOME', homeScore: 0, away: 'AWAY', awayScore: 0, period: 'Period 1' } }];
        st.cues = [cue('Pre-game', 1), cue('Start', 0), cue('Half-time', 3), cue('Full-time', 3)];
      } },
    { id: 'dj', name: 'DJ night', icon: 'play', view: 'vj', desc: 'Four layers of beat-reactive loops, strobes and flashes, DJ name lower third and logo; follows the DJ through Pioneer DJ Link or Ableton Link.',
      build(st) {
        layers(st, [
          { name: 'Backgrounds', clips: [gen('plasma', 'Plasma'), gen('rings', 'Rings'), gen('noise', 'Noise'), gen('gradient', 'Gradient sweep')] },
          { name: 'Visuals', clips: [gen('bars', 'Bars'), gen('checker', 'Checker'), null, null], layer: { blend: 'add' } },
          { name: 'Beat FX', clips: [gen('beatflash', 'Beat flash'), null, null, null], layer: { blend: 'screen', opacity: 0.6 } },
          { name: 'Logos & text', clips: [title('DJ name', 'Full-screen title', { line1: 'DJ NAME', line2: 'Live', font: 3 }), null, null, null] },
        ]);
        overlays(st, [{ clip: title('Now playing', 'Lower third', { line1: '{{djlink.master.title}}', line2: '{{djlink.master.artist}}' }) }, { clip: title('Logo', 'Corner bug', { line1: 'CLUB', line2: '', pos: 'Top right' }) }]);
        st.react = Object.assign(st.react || {}, { enabled: true, onBeat: 'next', everyBeats: 16, layer: 0, onDrop: 'off', autoBpm: true });
        st.cues = [0, 1, 2, 3].map(i => cue(`Column ${i + 1}`, i, { fade: 0 }));
      } },
    { id: 'corporate', name: 'Awards & corporate', icon: 'star', view: 'show', desc: 'Award categories and winners, walk-up stings, presenter and winner lower thirds, countdown and stinger transitions, all on the cue list.',
      build(st) {
        layers(st, [
          { name: 'Screens', clips: [gen('gradient', 'Holding loop', { c1: '#1d1d3a', c2: '#000000' }), title('Category 1', 'Full-screen title', { line1: 'BEST NEW BUSINESS', line2: 'And the nominees are…' }), title('Winner 1', 'Full-screen title', { line1: 'WINNER', line2: 'Example Co.' }), title('Category 2', 'Full-screen title', { line1: 'INNOVATION AWARD', line2: 'And the nominees are…' }), title('Winner 2', 'Full-screen title', { line1: 'WINNER', line2: 'Another Co.' })], layer: { transition: 'fade' } },
          { name: 'Nominee videos', clips: [null, null, null, null, null] },
          { name: 'Background', clips: [gen('plasma', 'Brand plasma', { c1: '#1d1d3a', c2: '#c9a227' })] },
        ]);
        overlays(st, [{ clip: title('Presenter', 'Lower third', { line1: 'PRESENTER NAME', line2: 'Title, Company' }) }, { clip: title('Logo', 'Corner bug', { line1: 'AWARDS 2026', line2: '', pos: 'Top right' }) }, { clip: title('Winner', 'Lower third', { line1: 'WINNER NAME', line2: 'Company' }) }, { clip: title('Countdown', 'Countdown', { line1: 'The awards begin in', minutes: 10 }) }]);
        timers(st, [{ name: 'Show', mode: 'up', secs: 0 }]);
        st.cues = [cue('Doors', 0), cue('Welcome', 0), cue('Category 1', 1), cue('Winner 1', 2), cue('Category 2', 3), cue('Winner 2', 4), cue('Close', 0)];
      } },
    { id: 'theatre', name: 'Theatre', icon: 'restart', view: 'show', desc: 'Scene layers on a cue list with fades, a timeline that can chase timecode, and a preset blackout — for a fully programmed show.',
      build(st) {
        layers(st, [
          { name: 'Scenery', clips: [gen('gradient', 'Scene 1 (swap for your content)', { c1: '#203a43', c2: '#0f2027' }), gen('gradient', 'Scene 2', { c1: '#3a1c71', c2: '#d76d77' }), gen('gradient', 'Scene 3', { c1: '#000000', c2: '#434343' })], layer: { transition: 'fade' } },
          { name: 'Effects', clips: [gen('noise', 'Haze texture'), null, null], layer: { opacity: 0.4 } },
          { name: 'Surtitles', clips: [title('Act 1', 'Full-screen title', { line1: 'ACT ONE', line2: '' }), title('Interval', 'Full-screen title', { line1: 'INTERVAL', line2: '20 minutes' }), title('Act 2', 'Full-screen title', { line1: 'ACT TWO', line2: '' })] },
        ]);
        timers(st, [{ name: 'Interval', secs: 1200 }]);
        st.timeline = Object.assign(st.timeline || {}, { followTc: true, duration: 3600 });
        st.cues = [cue('Pre-show', 0, { fade: 3 }), cue('Act 1 · Scene 1', 0, { fade: 2 }), cue('Scene 2', 1, { fade: 2 }), cue('Interval', 1, { fade: 3 }), cue('Act 2', 2, { fade: 2 })];
      } },
  ];
  const view = t => ({ id: t.id, name: t.name, icon: t.icon, view: t.view, desc: t.desc });
  function build(id) { const t = LIST.find(x => x.id === id); if (!t) throw new Error('unknown template ' + id); const st = S.newState(); t.build(st); st.template = { id: t.id, name: t.name, view: t.view }; return st; }
  return { list: () => LIST.map(view), build };
};
