// Bitfocus Companion module for PIXORA — Booth Productions
const { InstanceBase, InstanceStatus, runEntrypoint, combineRgb } = require('@companion-module/base');
// Socket: the bundled 'ws' package when present, otherwise Node 22's built-in WebSocket (Companion 4 runs modules on Node 22).
let WS = null; try { WS = require('ws'); } catch {}
function openSocket(url, h) {
  if (WS) { const ws = new WS(url); ws.on('open', h.open); ws.on('close', h.close); ws.on('error', h.error); ws.on('message', (d, bin) => { if (!bin) h.message(d.toString()); }); return { send: t => ws.readyState === 1 && ws.send(t), close: () => { try { ws.terminate(); } catch {} }, get ready() { return ws.readyState === 1; } }; }
  if (typeof WebSocket !== 'function') throw new Error('No WebSocket implementation (install ws or use Node 22+)');
  const ws = new WebSocket(url); ws.binaryType = 'arraybuffer';
  // Node's WebSocket may fire only 'error' (no 'close') when the connection is refused — make close fire exactly once
  let closed = false; const fireClose = () => { if (!closed) { closed = true; h.close(); } };
  ws.onopen = h.open; ws.onclose = fireClose; ws.onerror = e => { h.error(new Error(e && e.message || 'socket error')); if (ws.readyState !== 1) setTimeout(fireClose, 0); };
  ws.onmessage = ev => { if (typeof ev.data === 'string') h.message(ev.data); };
  return { send: t => ws.readyState === 1 && ws.send(t), close: () => { try { ws.close(); } catch {} }, get ready() { return ws.readyState === 1; } };
}

class PixoraInstance extends InstanceBase {
  async init(config) { this.config = config; this.state = null; this.connect(); this.initActions(); this.initFeedbacks(); this.initVariables(); }
  async destroy() { clearTimeout(this.retry); if (this.ws) { this.ws.closing = true; this.ws.close(); } }
  async configUpdated(config) { this.config = config; this.connect(); }
  getConfigFields() {
    return [
      { type: 'textinput', id: 'host', label: 'PIXORA computer IP', width: 8, default: '127.0.0.1' },
      { type: 'number', id: 'port', label: 'Port', width: 4, default: 8080, min: 1, max: 65535 },
      { type: 'textinput', id: 'pin', label: 'Operator PIN (optional)', width: 6, default: '' },
    ];
  }
  connect() {
    clearTimeout(this.retry); if (this.ws) { this.ws.closing = true; this.ws.close(); this.ws = null; }
    const { host, port, pin } = this.config || {}; if (!host) return this.updateStatus(InstanceStatus.BadConfig);
    this.updateStatus(InstanceStatus.Connecting);
    const url = `ws://${host}:${port || 8080}/ws?role=remote${pin ? '&pin=' + encodeURIComponent(pin) : ''}`;
    let sock; const self = this;
    try {
      sock = openSocket(url, {
        open: () => { sock.opened = true; self.updateStatus(InstanceStatus.Ok); sock.send(JSON.stringify({ t: 'whoami', name: 'Companion', color: '#2fd3c4' })); },
        message: txt => { let m; try { m = JSON.parse(txt); } catch { return; }
          if (m.t === 'state') { const first = !self.state; self.state = m.state; self.refresh(first); }
          else if (m.t === 'hping') sock.send(JSON.stringify({ t: 'hpong', at: m.at })); },
        close: async () => { if (sock.closing) return;
          // PIXORA refuses the WebSocket upgrade with 401 on a wrong PIN; tell that apart from "offline" with a quick HTTP probe
          let auth = false; if (!sock.opened) { try { const r = await fetch(`http://${host}:${port || 8080}/api/state${pin ? '?pin=' + encodeURIComponent(pin) : ''}`, { signal: AbortSignal.timeout(2000) }); auth = r.status === 401; } catch {} }
          if (sock.closing) return;
          self.updateStatus(auth ? InstanceStatus.AuthenticationFailure : InstanceStatus.Disconnected, auth ? 'Wrong or missing PIN' : undefined);
          self.retry = setTimeout(() => self.connect(), auth ? 10000 : 3000); },
        error: e => self.log('debug', 'PIXORA: ' + (e && e.message)),
      });
    } catch (e) { this.updateStatus(InstanceStatus.ConnectionFailure, e.message); this.retry = setTimeout(() => this.connect(), 5000); return; }
    this.ws = sock;
  }
  cmd(c) { if (this.ws && this.ws.ready) this.ws.send(JSON.stringify({ t: 'cmd', cmd: c })); }
  async http(path, body) { const { host, port, pin } = this.config; try { await fetch(`http://${host}:${port || 8080}${path}${pin ? (path.includes('?') ? '&' : '?') + 'pin=' + encodeURIComponent(pin) : ''}`, body ? { method: 'POST', body: JSON.stringify(body), headers: { 'Content-Type': 'application/json' } } : {}); } catch (e) { this.log('warn', e.message); } }
  clipName(l, c) { const L = this.state && this.state.layers[l]; const cl = L && L.clips[c]; return cl ? (cl.name || (cl.src || '').split('/').pop() || cl.type) : ''; }
  refresh(rebuild) {
    const s = this.state; if (!s) return;
    const v = { bpm: s.comp.bpm.toFixed(1), master: Math.round(s.comp.master * 100), comp: s.comp.name, deck: (s.decks[s.comp.deck] || {}).name || '', cue_index: s.cueIndex + 1, cue_name: (s.cues[s.cueIndex] || {}).name || '' };
    s.layers.forEach((l, i) => { const c = l.active != null ? (l.activeClip || l.clips[l.active]) : null; v[`layer${i + 1}_clip`] = c ? (c.name || c.type) : ''; l.clips.forEach((_, ci) => { v[`clip_${i + 1}_${ci + 1}`] = this.clipName(i, ci); }); });
    if (rebuild || Object.keys(v).length !== this._vc) { this._vc = Object.keys(v).length; this.initVariables(Object.keys(v)); this.initPresets(); }
    this.setVariableValues(v); this.checkFeedbacks();
  }
  initVariables(keys) {
    const defs = [['bpm', 'Tempo (BPM)'], ['master', 'Master %'], ['comp', 'Composition name'], ['deck', 'Current deck'], ['cue_index', 'Current cue number'], ['cue_name', 'Current cue name']].map(([variableId, name]) => ({ variableId, name }));
    for (const k of keys || []) if (/^layer\d+_clip$|^clip_\d+_\d+$/.test(k)) defs.push({ variableId: k, name: k.replace(/_/g, ' ') });
    this.setVariableDefinitions(defs);
  }
  initActions() {
    const n = (id, label, def = 1) => ({ type: 'number', id, label, default: def, min: 1, max: 64 });
    this.setActionDefinitions({
      trigger: { name: 'Trigger clip', options: [n('layer', 'Layer'), n('clip', 'Clip / column')], callback: a => this.cmd({ op: 'trigger', layer: a.options.layer - 1, clip: a.options.clip - 1 }) },
      column: { name: 'Trigger column', options: [n('col', 'Column')], callback: a => this.cmd({ op: 'column', col: a.options.col - 1 }) },
      clear_layer: { name: 'Clear layer', options: [n('layer', 'Layer')], callback: a => this.cmd({ op: 'clearLayer', layer: a.options.layer - 1 }) },
      clear_all: { name: 'Clear all layers', options: [], callback: () => this.cmd({ op: 'clearAll' }) },
      next_clip: { name: 'Next clip on layer', options: [n('layer', 'Layer')], callback: a => this.cmd({ op: 'next', layer: a.options.layer - 1 }) },
      cue_go: { name: 'Cue GO', options: [], callback: () => this.cmd({ op: 'cueGo' }) },
      cue_back: { name: 'Cue BACK', options: [], callback: () => this.cmd({ op: 'cueBack' }) },
      cue_index: { name: 'Go to cue #', options: [n('index', 'Cue number')], callback: a => this.cmd({ op: 'cueGo', index: a.options.index - 1 }) },
      deck: { name: 'Switch deck', options: [n('deck', 'Deck number')], callback: a => this.cmd({ op: 'deckSwitch', deck: a.options.deck - 1 }) },
      blackout: { name: 'Blackout', options: [{ type: 'dropdown', id: 'mode', label: 'Mode', default: 'toggle', choices: [{ id: 'toggle', label: 'Toggle' }, { id: 'on', label: 'On' }, { id: 'off', label: 'Off' }] }], callback: a => this.cmd({ op: 'blackout', on: a.options.mode === 'toggle' ? undefined : a.options.mode === 'on' }) },
      master: { name: 'Set master level', options: [{ type: 'number', id: 'value', label: 'Level %', default: 100, min: 0, max: 100 }], callback: a => this.cmd({ op: 'set', path: 'comp.master', value: a.options.value / 100 }) },
      tap: { name: 'Tap tempo', options: [], callback: () => { const now = Date.now(); this.taps = (this.taps || []).filter(t => now - t < 2500); this.taps.push(now); if (this.taps.length > 1) { const iv = (this.taps[this.taps.length - 1] - this.taps[0]) / (this.taps.length - 1); this.cmd({ op: 'bpm', bpm: Math.round(60000 / iv * 10) / 10, resync: true }); } } },
      bpm: { name: 'Set BPM', options: [{ type: 'number', id: 'bpm', label: 'BPM', default: 120, min: 20, max: 400 }], callback: a => this.cmd({ op: 'bpm', bpm: a.options.bpm }) },
      test: { name: 'LED test pattern', options: [{ type: 'dropdown', id: 'mode', label: 'Mode', default: 'toggle', choices: ['toggle', 'off', 'panels', 'chain', 'bars', 'solid', 'gradient', 'checker', 'scan', 'black'].map(id => ({ id, label: id })) }],
        callback: a => this.http('/api/test/' + a.options.mode) },
      timeline: { name: 'Timeline', options: [{ type: 'dropdown', id: 'mode', label: 'Action', default: 'play', choices: [{ id: 'play', label: 'Play' }, { id: 'stop', label: 'Stop' }, { id: 'zero', label: 'Back to start' }] }],
        callback: a => this.cmd(a.options.mode === 'play' ? { op: 'tlPlay' } : a.options.mode === 'stop' ? { op: 'tlStop' } : { op: 'tlSeek', pos: 0 }) },
      sponsors: { name: 'Sponsor rotation on/off', options: [{ type: 'checkbox', id: 'on', label: 'On', default: true }], callback: a => this.cmd({ op: 'set', path: 'rotation.enabled', value: !!a.options.on }) },
      feed: { name: 'Push data-feed value', options: [{ type: 'textinput', id: 'feed', label: 'Feed id', default: 'companion' }, { type: 'textinput', id: 'key', label: 'Key', default: 'value' }, { type: 'textinput', id: 'value', label: 'Value', default: '1', useVariables: true }],
        callback: async a => { const val = await this.parseVariablesInString(a.options.value); this.http(`/api/feed/${encodeURIComponent(a.options.feed)}?${encodeURIComponent(a.options.key)}=${encodeURIComponent(val)}`); } },
      custom: { name: 'Custom JSON command', options: [{ type: 'textinput', id: 'json', label: 'Command JSON', default: '{"op":"trigger","layer":0,"clip":0}' }], callback: a => { try { this.cmd(JSON.parse(a.options.json)); } catch { this.log('warn', 'Invalid JSON'); } } },
    });
  }
  initFeedbacks() {
    const n = (id, label) => ({ type: 'number', id, label, default: 1, min: 1, max: 64 });
    const s = () => this.state;
    this.setFeedbackDefinitions({
      clip_active: { type: 'boolean', name: 'Clip is playing', defaultStyle: { bgcolor: combineRgb(0, 180, 220), color: combineRgb(0, 0, 0) }, options: [n('layer', 'Layer'), n('clip', 'Clip')],
        callback: f => { const l = s() && s().layers[f.options.layer - 1]; return !!l && l.active === f.options.clip - 1; } },
      clip_loaded: { type: 'boolean', name: 'Slot has a clip', defaultStyle: { bgcolor: combineRgb(60, 30, 90) }, options: [n('layer', 'Layer'), n('clip', 'Clip')],
        callback: f => { const l = s() && s().layers[f.options.layer - 1]; return !!(l && l.clips[f.options.clip - 1]); } },
      blackout: { type: 'boolean', name: 'Blackout is on', defaultStyle: { bgcolor: combineRgb(220, 0, 40) }, options: [], callback: () => !!(s() && s().comp.blackout) },
      test: { type: 'boolean', name: 'Test pattern on air', defaultStyle: { bgcolor: combineRgb(255, 47, 109) }, options: [], callback: () => !!(s() && s().led.test.on) },
      cue_current: { type: 'boolean', name: 'Cue is current', defaultStyle: { bgcolor: combineRgb(0, 160, 80) }, options: [n('index', 'Cue number')], callback: f => !!(s() && s().cueIndex === f.options.index - 1) },
      timeline_playing: { type: 'boolean', name: 'Timeline playing', defaultStyle: { bgcolor: combineRgb(155, 59, 255) }, options: [], callback: () => !!(s() && s().timeline && s().timeline.play.playing) },
      layer_locked: { type: 'boolean', name: 'Layer locked', defaultStyle: { bgcolor: combineRgb(200, 160, 0), color: combineRgb(0, 0, 0) }, options: [n('layer', 'Layer')], callback: f => { const l = s() && s().layers[f.options.layer - 1]; return !!(l && l.lockedBy); } },
    });
  }
  initPresets() {
    const p = {}; const st = { size: '14', color: combineRgb(255, 255, 255), bgcolor: combineRgb(20, 20, 28) };
    for (let l = 1; l <= 4; l++) for (let c = 1; c <= 8; c++) {
      p[`clip_${l}_${c}`] = { type: 'button', category: `Layer ${l} clips`, name: `Layer ${l} clip ${c}`, style: Object.assign({}, st, { text: `$(pixora:clip_${l}_${c})`, size: 'auto' }),
        steps: [{ down: [{ actionId: 'trigger', options: { layer: l, clip: c } }], up: [] }],
        feedbacks: [{ feedbackId: 'clip_loaded', options: { layer: l, clip: c } }, { feedbackId: 'clip_active', options: { layer: l, clip: c }, style: { bgcolor: combineRgb(0, 180, 220), color: combineRgb(0, 0, 0) } }] };
    }
    const btn = (id, text, action, options = {}, fb) => { p[id] = { type: 'button', category: 'Show control', name: text, style: Object.assign({}, st, { text }), steps: [{ down: [{ actionId: action, options }], up: [] }], feedbacks: fb ? [fb] : [] }; };
    btn('go', 'CUE\\nGO', 'cue_go'); btn('back', 'CUE\\nBACK', 'cue_back'); btn('bo', 'BLACK\\nOUT', 'blackout', { mode: 'toggle' }, { feedbackId: 'blackout', options: {} });
    btn('tap', 'TAP\\n$(pixora:bpm)', 'tap'); btn('test', 'TEST', 'test', { mode: 'toggle' }, { feedbackId: 'test', options: {} }); btn('clear', 'CLEAR\\nALL', 'clear_all');
    btn('tl', 'TIMELINE\\nPLAY', 'timeline', { mode: 'play' }, { feedbackId: 'timeline_playing', options: {} });
    for (let c = 1; c <= 8; c++) btn('col' + c, 'COL ' + c, 'column', { col: c });
    this.setPresetDefinitions(p);
  }
}
runEntrypoint(PixoraInstance, []);
module.exports = { PixoraInstance };
