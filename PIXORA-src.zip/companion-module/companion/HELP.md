## PIXORA (Booth Productions)

Enter the IP address and port (8080 by default) of the computer running PIXORA, and the operator PIN if one is set.
The module connects over PIXORA's WebSocket API and updates buttons live. Requires Companion 4.0 or newer.

**Status:** *Authentication failure* means the PIN is wrong; *Disconnected* means PIXORA can't be reached (the module retries every few seconds).

**Actions:** trigger clip, trigger column, clear layer / all, cue GO / BACK / go to cue, switch deck, blackout on / off / toggle, master level, tap tempo, set BPM, test pattern on / off / mode, timeline play / stop, sponsor rotation on / off, push a data-feed value, and send any custom JSON command.

**Feedbacks:** clip is playing, layer has a clip, blackout on, test pattern on, current cue, timeline playing, layer locked.

**Variables:** `$(pixora:bpm)`, `$(pixora:master)`, `$(pixora:cue_name)`, `$(pixora:cue_index)`, `$(pixora:deck)`, `$(pixora:comp)`, `$(pixora:layerN_clip)` (N = 1–8) and `$(pixora:clip_L_C)` for every clip name.

**Presets:** a 4-layer × 8-clip grid showing your clip names, column buttons 1–8, Timeline play, plus Cue GO, Cue BACK, Blackout, Tap, Test and Clear All.
