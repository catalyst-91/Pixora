## PIXORA 1.7.1

- DeckLink is back in the Windows app. In 1.7.0 the Windows DeckLink module failed to build, so DeckLink inputs and outputs were missing on Windows (macOS and Linux were not affected).
- 1.7.0 installs update to this version automatically.

## PIXORA 1.7.0

**Video and colour**
- ISF shader import: bring in whole folders of ISF (.fs) generators and effects, the shader format shared by VDMX, Resolume and many free libraries. A matching .vs file and any images a shader uses come in with it. Multi-pass shaders, feedback buffers, audio waveform and spectrum inputs and the older ISF 1.0 format all work. Each shader's inputs appear as proper controls (sliders, colours, menus, toggles, XY points and triggers that can fire every beat).
- ISF Effect slots: two on every clip, layer and the composition, each with a Mix control.
- LUTs: import .cube (1D and 3D) and .3dl files into a new LUTs tab, with a before / after swatch. Two LUT slots on every clip, layer and the composition, each with intensity, exposure, temperature, tint, contrast, saturation and output gain. Re-importing a LUT with the same name updates it everywhere it's used.
- Display LUT per output, for calibrating a particular projector or LED wall, or for a show look on one feed.
- Dome and 360 output: fisheye domemaster (adjustable field of view and tilt), equirectangular 360, or a perspective camera looking into the 360. The composition can be 360 content, or flat content placed on the dome. Slices and warps then map the projected picture. One-click output sizes for 2K and 4K domes and 4K and 8K 360.

**Outputs and recording**
- Extra NDI® feeds (up to 16, in the desktop app): preview (the switcher's PVW clip as it will look once taken), multiview, one layer on its own, and more copies of the program, each with its own name and size.
- DeckLink genlock: outputs schedule frames against the card's reference and render ahead on frame boundaries. The Health page shows reference lock, late frames and underruns.
- ISO recording: record every camera (capture devices, NDI, DeckLink, Spout / Syphon, remote guests) to its own file alongside the program, started together and with the program audio so they line up in an edit. Choose which cameras and the ISO quality.

**Show control**
- Timecode: LTC and MIDI timecode readers rebuilt. They now handle 23.976 / 24 / 25 / 29.97 drop-frame / 30, reverse playback, a freewheel window for dropouts, and an always-on reader in the desktop app (no browser tab needed). Art-Net timecode in and out handles drop-frame.
- Timeline: audio waveforms on clips, drawn with the clip's in / out points, speed and loop mode. They are read by ffmpeg on the server, or decoded in the browser when ffmpeg isn't installed, and shared with every controller.

**Shows**
- Show versions: save named versions with notes. Automatic versions are taken on a timer (only when something changed), on Save, and before opening, importing or restoring a show. Compare any two versions, or a version with the live show, by layer, clip slot, effect, output, cue and timeline. Bring back a single clip, cue, effect or output, or restore the whole show while what's on air keeps playing. Any version can be exported as a .pixora file.

**Interface languages**
- The controller in Español, Français, Deutsch, Português and 日本語, chosen per screen with the globe in the status bar. The main screens and common controls are translated; deeper panels and help text are still partly English. To add a language or fill the gaps, export the untranslated strings and import the filled-in pack. Names you type are never translated.

**Fixes**
- The change log showed "[object Object]" for clips dropped into slots.

## PIXORA 1.6.1

- Spout (Windows) and Syphon (macOS) are now included in the desktop app. In 1.6.0 they failed to build and fell back to the NDI bridge.
- 1.6.0 installs update to this version automatically.

## PIXORA 1.6.0

**Projection**
- Projector tools: mesh warp (2×2 to 16×9, smoothed) for curved and uneven screens, black-level compensation for blends, feathered masks, and new test patterns (alignment grid, grid through the mapping, white / black, and white / black through the mapping).
- Camera auto-alignment: point a camera at the screen and click its corners. PIXORA projects coded dots from each projector, then sets the corner pins, the area each projector covers and the edge blends. **Tune blends** then matches brightness, the blend curve and black level with the camera. For flat screens; use the mesh warp afterwards for curved ones.
- PJLink projector control: power, input (by name), picture / sound mute, freeze, lamp and filter hours, error alerts, and network search.

**LED**
- LED processor control: Novastar COEX, MCTRL / VX / NovaPro / J6 and H series, Megapixel HELIOS, and DMX-controlled processors (Brompton Tessera, ROE…). Brightness, blackout, freeze, presets, test patterns and inputs, from the device card or any action.
- LED processor health: temperatures, receiving cards, ports, fans, data errors and broken links (COEX), and status fields from HELIOS, on the device card and the Health page.
- Processor setup pack: a printable cabling sheet per screen, raster and port CSVs, port loads and setup notes for NovaLCT / VMP, Tessera, HELIOS and Colorlight.
- 3D stage from MVR: trusses, set pieces and fixtures (with beams) from the MVR's 3DS / glTF models in Stage 3D. The model travels with exported and collected shows and is copied to backup servers.

**Live production**
- Show templates: wedding, conference, sports, DJ night, corporate and theatre.
- Data-driven graphics: Google Sheets by share link, a live values editor for push feeds, rows that cycle or list (`{{row.Column}}`), and timer tokens with spaces in the name.
- Timeline mode: clip fade-in / fade-out, and an Events row for cues, overlays, device actions, OSC and DMX locked to timecode.
- Live captions: speech-to-text in Chrome / Edge or from any captioner (HTTP / OSC), a Captions title, second-language translation (on-device in Chrome), and TXT / SRT transcripts.
- Replay export: save any replay event as MP4 / WebM at 100 / 50 / 25 % speed, one angle or all.
- Spout (Windows) and Syphon (macOS) built into the desktop app: send outputs, and use other apps' senders as sources.

**Reliability and scale**
- Main / backup failover: manual takeover and hand-control-to-backup, takeover and hand-back actions, the backup stays in control when the main machine returns until you hand back (the show, including changes made meanwhile, goes back with it), the main machine is read-only while the backup is in control, and controllers follow to the backup and back.
- Render nodes: extra PIXORA machines follow the show and clock and drive more outputs. The main machine shows each node's outputs, frame rate and drift.
- Fixed: the Sync panel never showed outputs' drift (the server dropped it).
- Fixed: changing backup settings could leave two connections to the main machine.

## PIXORA 1.5.0

**Live production**
- Views that change the layout for the job (VJ, LED, Show Operator, Production, Replay, Stream, Signage, Setup, Perform), plus custom saved views (Ctrl+Alt+1–9).
- Switcher with preview / program, CUT, AUTO and a T-bar; fade, dip, wipe, split and stinger transitions.
- Four overlay channels, shared timers ({{timer.Name}}) and a keyboard shortcut editor.
- Audio mixer: per-layer faders, meters, mute and audio-follows-video.
- Instant replay: four angles, events, slow motion from 5%, jog and auto-take.
- Playlists of videos and stills as one input (list, folder, .m3u / .pls / .txt).
- Remote guests: presenters join from a browser link and become sources.
- Live streaming to YouTube, Facebook, Twitch, Vimeo, Kick, custom RTMP and SRT at once; Blackmagic Streaming XML import.

**Devices**
- Blackmagic ATEM (incl. camera control), HyperDeck, Videohub, Web Presenter / Streaming Encoder, cameras via REST.
- DeckLink / UltraStudio inputs and outputs in the desktop app.
- BirdDog, Panasonic (with Auto Tracking), VISCA-over-IP and NDI PTZ cameras.

**Show control**
- Pioneer PRO DJ LINK, direct or through PRO DJ LINK Bridge (TCNet): tempo and phase follow, clips locked to decks, track titles.
- Ableton Link.
- QForge: QForge's PIXORA cue fires PIXORA, and PIXORA sends clip progress back.
- grandMA3: a USB package with the GDTF, a plugin and a macro for every PIXORA action (thumbnails as appearances), plus a "grandMA3 command" action.

**Reliability**
- Automatic updates from GitHub Releases. PIXORA asks before installing and never restarts during a show. Updating from 1.4.x to 1.5.0 is a one-time manual install; later versions update themselves.
- The server restarts itself if it crashes, and output windows reload. Then PIXORA offers an opt-in crash report: a pre-filled GitHub issue you check before you send it.
- Fixed: the timecode display could show a frame or two behind when timecode stopped.
- Fixed: the Ableton Link helper (Carabiner) could keep running after PIXORA quit, or after changing Link settings, and show up as an extra Link peer.
- PIXORA's server now shuts down cleanly when the desktop app quits, on `docker stop` and on Ctrl+C.
- Every build runs the automatic tests first.

The startup splash and Help ▸ About list the licensed technologies (NDI®, Blackmagic Design, Art-Net™, TCNet / PRO DJ LINK™, Ableton Link, FFmpeg). The Carabiner (Ableton Link, GPL-2.0) source is attached as `carabiner-source.tar.gz`.
