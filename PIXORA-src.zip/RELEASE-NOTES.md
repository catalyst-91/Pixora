## PIXORA 1.5.0

**Live production**
- Views that change the layout for the job (VJ, LED, Show Operator, Production, Replay, Stream, Signage, Setup, Perform), plus custom saved views (Ctrl+Alt+1–9).
- Switcher with preview / program, CUT, AUTO and a T-bar; fade, dip, wipe, split and stinger transitions.
- Four overlay channels, shared timers ({{timer.Name}}) and a keyboard shortcut editor.
- Audio mixer: per-layer faders, meters, mute and audio-follows-video.
- Instant replay: four angles, events, slow motion from 5%, jog and auto-take.
- Playlists of videos and stills as one input (list, folder, .m3u / .pls / .txt).
- Remote guests: presenters join from a browser link and become sources.
- Live streaming to YouTube, Facebook, Twitch, Vimeo, Kick, custom RTMP and SRT at once; Blackmagic Streaming XML import.

**Devices**
- Blackmagic ATEM (incl. camera control), HyperDeck, Videohub, Web Presenter / Streaming Encoder, cameras via REST.
- DeckLink / UltraStudio inputs and outputs in the desktop app.
- BirdDog, Panasonic (with Auto Tracking), VISCA-over-IP and NDI PTZ cameras.

**Show control**
- Pioneer PRO DJ LINK, direct or through PRO DJ LINK Bridge (TCNet): tempo and phase follow, clips locked to decks, track titles.
- Ableton Link.
- QForge: QForge's PIXORA cue fires PIXORA, and PIXORA sends clip progress back.
- grandMA3: a USB package with the GDTF, a plugin and a macro for every PIXORA action (thumbnails as appearances), plus a "grandMA3 command" action.

**Reliability**
- Automatic updates from GitHub Releases. PIXORA asks before installing and never restarts during a show. Updating from 1.4.x to 1.5.0 is a one-time manual install; later versions update themselves.
- The server restarts itself if it crashes, and output windows reload. Then PIXORA offers an opt-in crash report: a pre-filled GitHub issue you check before you send it.
- Fixed: the timecode display could show a frame or two behind when timecode stopped.
- Fixed: the Ableton Link helper (Carabiner) could keep running after PIXORA quit, or after changing Link settings, and show up as an extra Link peer.
- PIXORA's server now shuts down cleanly when the desktop app quits, on `docker stop` and on Ctrl+C.
- Every build runs the automatic tests first.

The startup splash and Help ▸ About list the licensed technologies (NDI®, Blackmagic Design, Art-Net™, TCNet / PRO DJ LINK™, Ableton Link, FFmpeg). The Carabiner (Ableton Link, GPL-2.0) source is attached as `carabiner-source.tar.gz`.
