'use strict';
// Audience interaction: phones join with a QR code (no app, no PIN — a join key of its own, like the guest key) and can
//   vote in a poll, ask questions (upvote others' questions) and post to a social wall. Questions and posts wait for the
//   operator unless moderation is off; words on the block list are always held back. Results reach the outputs as the
//   "audience" data feed, drawn by the Audience overlay generator. Votes and posts stay on this machine (DATA/audience.json).
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const clean = (s, n) => String(s == null ? '' : s).replace(/[\u0000-\u001f\u007f​-‏‪-‮]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, n);
const rid = () => crypto.randomBytes(4).toString('hex');

function defaults() { return { on: false, title: 'Join in on your phone', publicUrl: '', poll: { question: '', options: ['', ''] }, pollOpen: false, showResults: true,
  qaOn: true, wallOn: true, moderate: true, allowNames: true, blockWords: '' }; }
function normalize(st) {
  const a = st.audience = Object.assign(defaults(), st.audience && typeof st.audience === 'object' ? st.audience : {});
  if (!a.poll || typeof a.poll !== 'object') a.poll = { question: '', options: ['', ''] };
  if (!Array.isArray(a.poll.options)) a.poll.options = ['', '']; a.poll.options = a.poll.options.slice(0, 8).map(o => clean(o, 80)); a.poll.question = clean(a.poll.question, 200);
}

module.exports = function (o) { // o: { DATA, getState, setFeed, broadcast, monitor, joinBase }
  const FILE = path.join(o.DATA, 'audience.json');
  let db; try { db = JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { db = {}; }
  db = Object.assign({ key: crypto.randomBytes(6).toString('base64url'), pollId: rid(), votes: {}, qa: [], wall: [], ups: {} }, db);
  let saveT = null; const save = () => { clearTimeout(saveT); saveT = setTimeout(() => { try { fs.writeFileSync(FILE, JSON.stringify(db)); } catch {} }, 300); };
  save();
  const A = () => o.getState().audience || defaults();
  const opts = () => A().poll.options.map((t, i) => ({ i, t })).filter(x => x.t);
  const tally = () => { const counts = {}; for (const c of Object.values(db.votes)) counts[c] = (counts[c] || 0) + 1;
    const list = opts().map(x => ({ text: x.t, votes: counts[x.i] || 0 })); const total = list.reduce((s, x) => s + x.votes, 0);
    return { list: list.map(x => ({ ...x, pct: total ? Math.round(x.votes / total * 100) : 0 })), total }; };
  const joinUrl = () => { const a = A(); const base = (a.publicUrl || '').trim().replace(/\/+$/, '') || o.joinBase(); return `${base}/join?k=${db.key}`; };
  const blocked = text => { const w = String(A().blockWords || '').toLowerCase().split(/[,\n]/).map(s => s.trim()).filter(Boolean); const t = text.toLowerCase(); return w.some(x => t.includes(x)); };

  /* ---------- views */
  function feedView() { // what the outputs draw
    const a = A(), t = tally(), live = db.qa.find(q => q.status === 'live');
    return { url: joinUrl(), title: a.title, on: !!a.on, poll: { question: a.poll.question, open: a.pollOpen, options: t.list, total: t.total },
      qa: live ? { text: live.text, name: live.name, up: live.up } : null,
      wall: db.wall.filter(p => p.status === 'live' || p.status === 'approved').slice(-12).reverse().map(p => ({ text: p.text, name: p.name, live: p.status === 'live' })) };
  }
  function adminView() { return { key: db.key, url: joinUrl(), pollId: db.pollId, tally: tally(), qa: db.qa.slice(-200), wall: db.wall.slice(-200) }; }
  let pushT = null, lastPush = 0;
  function changed() { save(); const go = () => { pushT = null; lastPush = Date.now(); o.setFeed('audience', feedView()); o.broadcast({ t: 'audience', data: adminView() }); };
    if (pushT) return; const wait = Math.max(0, 250 - (Date.now() - lastPush)); pushT = setTimeout(go, wait); }
  setTimeout(changed, 500);

  /* ---------- operator actions */
  function action(b) {
    const list = b.what === 'wall' ? db.wall : db.qa;
    switch (b.action) {
      case 'pollReset': db.votes = {}; db.pollId = rid(); break; // a new poll: phones may vote again
      case 'status': { const it = list.find(x => x.id === b.id); if (!it) throw new Error('not found'); if (!['pending', 'approved', 'live', 'hidden', 'done'].includes(b.status)) throw new Error('bad status');
        if (b.status === 'live' && b.what !== 'wall') for (const q of db.qa) if (q.status === 'live') q.status = 'done'; // one question on screen at a time
        it.status = b.status; break; }
      case 'clear': if (b.what === 'wall') db.wall = []; else { db.qa = []; db.ups = {}; } break;
      case 'newKey': db.key = crypto.randomBytes(6).toString('base64url'); o.monitor('audience', 'new join link — old QR codes stop working'); break;
      default: throw new Error('unknown action');
    }
    changed(); return adminView();
  }

  /* ---------- phones */
  const rate = new Map(); // device|ip → recent post times
  const limit = (who, n, ms) => { const now = Date.now(), l = (rate.get(who) || []).filter(t => now - t < ms); if (l.length >= n) return false; l.push(now); rate.set(who, l); return true; };
  setInterval(() => { const now = Date.now(); for (const [k, l] of rate) if (!l.some(t => now - t < 3600e3)) rate.delete(k); }, 600e3).unref();
  function info(dev) { const a = A(), t = tally();
    return { title: a.title, on: !!a.on, pollId: db.pollId, poll: a.poll.question && opts().length >= 2 ? { question: a.poll.question, options: opts().map(x => ({ i: x.i, text: x.t })), open: !!a.pollOpen,
        results: a.showResults ? t : null, mine: db.votes[dev] ?? null } : null,
      qaOn: !!a.qaOn, wallOn: !!a.wallOn, allowNames: !!a.allowNames, moderate: !!a.moderate,
      questions: a.qaOn ? db.qa.filter(q => q.status === 'approved' || q.status === 'live').sort((x, y) => y.up - x.up).slice(0, 30).map(q => ({ id: q.id, text: q.text, name: q.name, up: q.up, mine: (db.ups[q.id] || []).includes(dev), live: q.status === 'live' })) : [] };
  }
  async function route(req, res, p, url, send, readBody) {
    if (!p.startsWith('/api/join/')) return false;
    const q = url.searchParams; let b = {}; if (req.method === 'POST') { try { b = JSON.parse((await readBody(req, 8192)).toString() || '{}'); } catch { return send(res, 400, { error: 'bad request' }), true; } }
    const key = b.k || q.get('k'); if (!key || key !== db.key) return send(res, 403, { error: 'This join link has expired — scan the QR code again.' }), true;
    if (!A().on) return send(res, 200, { off: true, title: A().title }), true;
    const dev = clean(b.d || q.get('d'), 40) || 'anon', ip = (req.socket.remoteAddress || '').replace('::ffff:', ''), who = dev + '|' + ip;
    if (p === '/api/join/info') return send(res, 200, info(dev)), true;
    if (req.method !== 'POST') return send(res, 405, { error: 'POST' }), true;
    const a = A(), name = a.allowNames ? clean(b.name, 40) : '';
    if (p === '/api/join/vote') { if (!a.pollOpen) return send(res, 409, { error: 'Voting is closed' }), true;
      if (b.pollId && b.pollId !== db.pollId) return send(res, 409, { error: 'That poll has finished — here is the new one.' }), true;
      const c = +b.choice; if (!opts().some(x => x.i === c)) return send(res, 400, { error: 'bad choice' }), true;
      if (!limit(who + ':v', 20, 60e3)) return send(res, 429, { error: 'Slow down a little' }), true;
      if (Object.keys(db.votes).length > 50000 && db.votes[dev] == null) return send(res, 429, { error: 'poll full' }), true;
      db.votes[dev] = c; changed(); return send(res, 200, info(dev)), true; }
    if (p === '/api/join/ask' || p === '/api/join/post') { const wall = p === '/api/join/post';
      if (wall ? !a.wallOn : !a.qaOn) return send(res, 409, { error: wall ? 'The wall is closed' : 'Questions are closed' }), true;
      const text = clean(b.text, wall ? 200 : 280); if (text.length < 2) return send(res, 400, { error: 'Write something first' }), true;
      if (!limit(who + (wall ? ':pw' : ':pq'), 1, 8e3) || !limit(who + ':h', 30, 3600e3)) return send(res, 429, { error: 'Please wait a moment before sending again' }), true;
      const list = wall ? db.wall : db.qa; if (list.length >= 2000) list.splice(0, list.length - 1999);
      const it = { id: rid(), text, name, at: Date.now(), up: 0, dev, status: blocked(text) || blocked(name) ? 'hidden' : a.moderate ? 'pending' : 'approved' };
      list.push(it); changed(); o.monitor('audience', `${wall ? 'wall post' : 'question'}${it.status === 'hidden' ? ' (held: blocked word)' : ''}: ${text.slice(0, 60)}`);
      return send(res, 200, { ok: true, status: it.status === 'hidden' ? 'pending' : it.status }), true; } // a held post looks like one waiting for approval
    if (p === '/api/join/up') { const it = db.qa.find(x => x.id === b.id && (x.status === 'approved' || x.status === 'live')); if (!it) return send(res, 404, { error: 'gone' }), true;
      const ups = db.ups[it.id] = db.ups[it.id] || []; const i = ups.indexOf(dev); if (i >= 0) ups.splice(i, 1); else if (limit(who + ':u', 60, 60e3)) ups.push(dev); it.up = ups.length; changed(); return send(res, 200, info(dev)), true; }
    return send(res, 404, { error: 'not found' }), true;
  }
  return { route, action, adminView, feedView, joinUrl, changed, key: () => db.key };
};
module.exports.normalize = normalize; module.exports.defaults = defaults;
