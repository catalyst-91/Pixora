// Third-party technology shown on the PIXORA splash screen and in About ▸ Licences.
// "splash: true" = brands whose licence or trademark terms ask for visible credit; shown as plain text wordmarks
// (no copied logos — drop official artwork in only when the brand's partner programme supplies it).
module.exports = [
  { mark: 'NDI®', splash: true, url: 'https://ndi.video/',
    notice: 'This product uses NDI® technology. NDI® is a registered trademark of Vizrt NDI AB (https://ndi.video/). The NDI runtime is © Vizrt NDI AB.' },
  { mark: 'Blackmagic Design', splash: true, url: 'https://www.blackmagicdesign.com/',
    notice: 'Blackmagic Design, ATEM, DeckLink, HyperDeck, Videohub and Web Presenter are trademarks of Blackmagic Design Pty. Ltd. Device control uses the Blackmagic Design developer protocols and SDKs under their licence terms. ATEM network control follows the open-source atem-connection library (Sofie / NRK, MIT licence).' },
  { mark: 'Art-Net™', splash: true, url: 'https://art-net.org.uk/',
    notice: 'Art-Net™ Designed by and Copyright Artistic Licence Holdings Ltd.' },
  { mark: 'TCNet · PRO DJ LINK™', splash: true, url: 'https://www.tc-supply.com/tcnet',
    notice: 'TCNet is an open protocol by Event Imagineering Group. PRO DJ LINK™, rekordbox™ and Pioneer DJ are trademarks of AlphaTheta Corporation; PRO DJ LINK Bridge is their software. PIXORA is not affiliated with or endorsed by AlphaTheta. Direct Pro DJ Link support follows the protocol research published by Deep Symmetry (beat-link, https://github.com/Deep-Symmetry/beat-link, Eclipse Public License 2.0); PIXORA uses its own implementation and contains no beat-link code.' },
  { mark: 'Ableton Link', splash: true, url: 'https://www.ableton.com/link/',
    notice: 'Ableton Link support runs Carabiner by Deep Symmetry (https://github.com/Deep-Symmetry/carabiner), which contains Ableton Link (https://github.com/Ableton/link), as a separate program under the GNU GPL v2. Its source code is published with each PIXORA release. Ableton and Link are trademarks of Ableton AG.' },
  { mark: 'FFmpeg', splash: true, url: 'https://ffmpeg.org/',
    notice: 'Includes FFmpeg (https://ffmpeg.org/), licensed under the GPL. FFmpeg is a trademark of Fabrice Bellard.' },
  { mark: 'BirdDog / Panasonic / Sony VISCA', splash: false,
    notice: 'BirdDog is a trademark of BirdDog Australia Pty Ltd. Panasonic is a trademark of Panasonic Holdings Corporation. VISCA is a trademark of Sony Group Corporation. Camera control uses their published protocols.' },
  { mark: 'Spout', splash: false, url: 'https://spout.zeal.co/',
    notice: 'Spout texture sharing on Windows uses the Spout SDK (SpoutLibrary) by Lynn Jarvis (leadedge), BSD-2-Clause, https://github.com/leadedge/Spout2.' },
  { mark: 'Syphon', splash: false, url: 'https://syphon.github.io/',
    notice: 'Syphon texture sharing on macOS uses Syphon.framework by Tom Butterworth and Anton Marini, BSD-2-Clause, https://github.com/Syphon/Syphon-Framework.' },
  { mark: 'Novastar / Megapixel / PJLink', splash: false,
    notice: 'Novastar is a trademark of Xi\'an NovaStar Tech Co., Ltd. HELIOS is a trademark of Megapixel VR. PJLink is a trademark of the Japan Business Machine and Information System Industries Association (JBMIA). PIXORA uses their published control protocols and is not affiliated with them. The Novastar controller command tables are taken from Bitfocus Companion\'s companion-module-novastar-controller (MIT License, Copyright (c) 2020 Bitfocus AS).' },
  { mark: 'grandMA3 / CITP / MVR', splash: false,
    notice: 'grandMA3 is a trademark of MA Lighting Technology GmbH. MVR and GDTF are open standards (DIN SPEC 15800).' },
  { mark: 'MediaPipe', splash: false, url: 'https://ai.google.dev/edge/mediapipe',
    notice: 'AI background removal uses Google MediaPipe Tasks Vision and the MediaPipe selfie segmentation model, © Google LLC, licensed under the Apache License 2.0.' },
];
