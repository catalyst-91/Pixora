// PIXORA — native texture sharing: Spout (Windows) / Syphon (macOS), from native/texshare (built by build/texshare-prepare.js).
// Output windows can be published as Spout/Syphon senders, and senders from other apps can be used as layer sources.
'use strict';
const path = require('path'), fs = require('fs');
const exists = f => { try { return fs.statSync(f).isFile(); } catch { return false; } };
function open({ resourcesPath } = {}) {
  const tag = `${process.platform}-${process.arch}`, kind = process.platform === 'win32' ? 'Spout' : process.platform === 'darwin' ? 'Syphon' : '';
  const api = { kind, available: false, error: kind ? '' : 'Spout / Syphon are Windows / macOS technologies', senders: () => [] };
  if (!kind) return api;
  const dirs = [process.env.PIXORA_TEXSHARE_DIR, resourcesPath && path.join(resourcesPath, 'texshare'), path.join(__dirname, 'texshare-dist')].filter(Boolean);
  let mod = null;
  for (const d of dirs) { const f = path.join(d, `pixora_texshare-${tag}.node`); if (!exists(f)) continue;
    if (process.platform === 'win32') process.env.PATH = d + path.delimiter + (process.env.PATH || ''); // SpoutLibrary.dll sits next to the module
    try { mod = require(f); break; } catch (e) { api.error = `${kind} module failed to load: ${e.message}`; } }
  if (!mod) { api.error = api.error || `${kind} support is not included in this build`; return api; }
  api.mod = mod; api.available = (() => { try { return mod.available(); } catch { return false; } })();
  if (!api.available) api.error = (() => { try { return `${kind}: ${mod.lastError() || 'not available'}`; } catch { return kind + ' not available'; } })();
  api.senders = () => { try { return mod.senders(); } catch { return []; } };
  // same shape as the old plugin hook: create(name) → { send(bgra, w, h), close() }
  api.create = name => { const id = mod.createSender(name); return { send: (b, w, h) => mod.send(id, b, w, h), close: () => mod.close(id) }; };
  return api;
}
module.exports = { open };
