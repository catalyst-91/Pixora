'use strict';
// PIXORA desktop updates from GitHub Releases (catalyst-91/Pixora) — Booth Productions.
// Checks the latest release, downloads this computer's installer in the background (checked against GitHub's SHA-256),
// and installs it when the operator says so — never while outputs are on air unless asked. No Apple code signing needed:
//   macOS     the .app is swapped in place from the .dmg by a small script after PIXORA quits (falls back to opening the .dmg)
//   Windows   installed build → the NSIS installer runs silently into the same folder; portable .exe → the file is replaced
//   Linux     the AppImage file is replaced
// Ported from QForge's updater (same behaviour, same prompts).
const { app, net, dialog, shell, BrowserWindow } = require('electron');
const fs = require('fs'), path = require('path'), os = require('os'), crypto = require('crypto');
const { spawn } = require('child_process');

const REPO = process.env.PIXORA_UPDATE_REPO || 'catalyst-91/Pixora';
const CHECK_EVERY = 6 * 3600e3;
const parseVer = v => String(v || '').replace(/^v/i, '').split(/[.+-]/).slice(0, 3).map(n => parseInt(n, 10) || 0);
const newer = (a, b) => { const x = parseVer(a), y = parseVer(b); for (let i = 0; i < 3; i++) if (x[i] !== y[i]) return x[i] > y[i]; return false; };
const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const plainNotes = md => String(md || '').replace(/\r/g, '').replace(/^#+\s*/gm, '').replace(/\*\*([^*]+)\*\*/g, '$1').replace(/`([^`]+)`/g, '$1')
  .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1').replace(/^\s*[-*]\s+/gm, '• ').replace(/\|.*\|\n?/g, '').replace(/\n{3,}/g, '\n\n').trim();

// which file in a release this computer needs — names come from desktop/package.json "build"
function pickAsset(assets, env = {}) {
  const plat = env.platform || process.platform, arch = env.arch || process.arch, portable = env.portable != null ? env.portable : !!process.env.PORTABLE_EXECUTABLE_FILE;
  const V = '(\\d+\\.\\d+\\.\\d+)';
  let re;
  if (plat === 'win32') re = portable ? new RegExp(`^PIXORA-${V}-(portable|win-x64)\\.exe$`) : new RegExp(`^PIXORA-Setup-${V}\\.exe$`);
  else if (plat === 'darwin') re = new RegExp(`^PIXORA-${V}-mac-${arch === 'arm64' || env.rosetta ? 'arm64' : 'x64'}\\.dmg$`);
  else if (plat === 'linux') re = new RegExp(`^PIXORA-${V}-linux-(${arch === 'arm64' ? 'arm64|aarch64' : 'x86_64|x64|amd64'})\\.AppImage$`);
  else return null;
  return (assets || []).find(a => re.test(a.name)) || null;
}

class Updater {
  constructor({ isBusy, log, onState } = {}) {
    this.name = 'PIXORA';
    this.isBusy = isBusy || (async () => false);
    this.log = log || (m => console.log(`[update] ${m}`));
    this.onState = onState || (() => {});
    this.dir = path.join(app.getPath('userData'), 'updates');
    this.cfgFile = path.join(this.dir, 'settings.json');
    this._state = { status: 'idle' };
    this.pending = null;
  }
  get state() { return this._state; }
  set state(s) { this._state = s; try { this.onState(this.view()); } catch {} }
  view() { const s = this._state; return { status: s.status, version: s.version || null, current: app.getVersion(), error: s.error || null, got: s.got || 0, size: s.asset ? s.asset.size : 0, notes: s.notes || '', url: s.url || '', auto: this.cfg.auto, skip: this.cfg.skip, repo: REPO, checked: s.checked || null }; }
  get cfg() { try { return { auto: true, skip: '', ...JSON.parse(fs.readFileSync(this.cfgFile, 'utf8')) }; } catch { return { auto: true, skip: '' }; } }
  setCfg(p) { try { fs.mkdirSync(this.dir, { recursive: true }); fs.writeFileSync(this.cfgFile, JSON.stringify({ ...this.cfg, ...p })); } catch {} this.onState(this.view()); }
  menuItems() {
    return [
      { label: 'Check for Updates…', click: () => this.check({ manual: true }) },
      { label: 'Check for Updates Automatically', type: 'checkbox', checked: this.cfg.auto, click: mi => { this.setCfg({ auto: mi.checked }); if (mi.checked) this.check(); } },
    ];
  }
  start() {
    if (!app.isPackaged) { this.log('not packaged — automatic update checks are off'); return; }
    this.cleanOld();
    app.on('will-quit', () => this.installOnQuit());
    setTimeout(() => { if (this.cfg.auto) this.check(); }, 30000);
    setInterval(() => { if (this.cfg.auto && ['idle', 'error'].includes(this._state.status)) this.check(); }, CHECK_EVERY);
  }
  async check({ manual = false } = {}) {
    if (['checking', 'downloading'].includes(this._state.status)) { if (manual) this.info('An update check is already running.'); return this.view(); }
    if (this._state.status === 'ready' && this.pending) { if (manual) this.promptInstall(); return this.view(); }
    this.state = { status: 'checking' };
    try {
      const r = await net.fetch(`https://api.github.com/repos/${REPO}/releases/latest`, { headers: { Accept: 'application/vnd.github+json' } });
      if (!r.ok) throw new Error(`GitHub answered ${r.status}`);
      const rel = await r.json();
      const version = String(rel.tag_name || '').replace(/^v/i, '');
      const asset = pickAsset(rel.assets, { rosetta: app.runningUnderARM64Translation });
      if (!newer(version, app.getVersion()) || !asset) {
        this.state = { status: 'idle', checked: Date.now() };
        this.log(`up to date (${app.getVersion()}, latest ${version || '?'}${asset ? '' : ', no installer for this computer'})`);
        if (manual) this.info(newer(version, app.getVersion()) ? `PIXORA ${version} is out, but it has no installer for this computer yet.` : `PIXORA ${app.getVersion()} is the latest version.`);
        return this.view();
      }
      this.state = { status: 'available', version, asset, notes: plainNotes(rel.body), url: rel.html_url, checked: Date.now() };
      this.log(`version ${version} is available`);
      if (!manual && this.cfg.skip === version) return this.view();
      if (manual) {
        const { response } = await this.ask(`PIXORA ${version} is available`, `You have ${app.getVersion()}.\n\n${this.trimNotes(this._state.notes)}`, ['Download and install', 'Later', 'Skip this version']);
        if (response === 1) return this.view();
        if (response === 2) { this.setCfg({ skip: version }); return this.view(); }
      }
      await this.download(manual);
    } catch (e) {
      this.state = { status: 'error', error: e.message };
      this.log(`check failed: ${e.message}`);
      if (manual) this.info(`Couldn’t check for updates: ${e.message}`, 'warning');
    }
    return this.view();
  }
  async download(manual) {
    const { asset, version } = this._state;
    fs.mkdirSync(this.dir, { recursive: true });
    const file = path.join(this.dir, asset.name);
    if (fs.existsSync(file) && fs.statSync(file).size === asset.size && (await this.verify(file, asset))) return this.ready(file, version, manual);
    this.state = { ...this._state, status: 'downloading', got: 0 };
    const part = `${file}.part`;
    try {
      const r = await net.fetch(asset.browser_download_url);
      if (!r.ok || !r.body) throw new Error(`download failed (${r.status})`);
      const out = fs.createWriteStream(part), reader = r.body.getReader();
      let got = 0, lastUi = 0;
      for (;;) {
        const { done, value } = await reader.read(); if (done) break;
        if (!out.write(Buffer.from(value))) await new Promise(res => out.once('drain', res));
        got += value.length;
        if (Date.now() - lastUi > 400) { lastUi = Date.now(); this.progress(asset.size ? got / asset.size : 2); this.state = { ...this._state, got }; }
      }
      await new Promise((res, rej) => out.end(err => (err ? rej(err) : res())));
      this.progress(-1);
      if (asset.size && fs.statSync(part).size !== asset.size) throw new Error('the download was incomplete');
      if (!(await this.verify(part, asset))) throw new Error('the download didn’t match GitHub’s checksum');
      fs.renameSync(part, file);
      this.ready(file, version, manual);
    } catch (e) {
      this.progress(-1);
      try { fs.rmSync(part, { force: true }); } catch {}
      this.state = { status: 'error', error: e.message };
      this.log(`download failed: ${e.message}`);
      if (manual) this.info(`The update couldn’t be downloaded: ${e.message}`, 'warning');
    }
  }
  async verify(file, asset) {
    const m = String(asset.digest || '').match(/^sha256:([0-9a-f]{64})$/i);
    if (!m) return true; // older releases carry no checksum
    const h = crypto.createHash('sha256');
    await new Promise((res, rej) => fs.createReadStream(file).on('data', d => h.update(d)).on('end', res).on('error', rej));
    return h.digest('hex').toLowerCase() === m[1].toLowerCase();
  }
  ready(file, version, manual) {
    this.state = { ...this._state, status: 'ready', file, version };
    this.pending = { file, version, relaunch: false, armed: false };
    this.log(`version ${version} downloaded`);
    this.whenQuiet(() => this.promptInstall(), manual);
  }
  async whenQuiet(fn, now) { // outputs on air → wait (re-checks every minute); the operator can still install from the menu
    if (now || !(await this.isBusy().catch(() => false))) return fn();
    setTimeout(() => this.whenQuiet(fn, false), 60000);
  }
  async promptInstall() {
    if (!this.pending) return;
    const v = this.pending.version;
    const { response } = await this.ask(`PIXORA ${v} is ready to install`,
      `${this.trimNotes(this._state.notes)}\n\nInstalling takes a few seconds, then PIXORA opens again. Shows, settings and media are kept.`,
      ['Restart and install', 'Install when I quit', 'Skip this version']);
    if (response === 0) { this.pending.relaunch = true; this.pending.armed = true; app.isQuitting = true; app.quit(); }
    else if (response === 1) this.pending.armed = true;
    else { this.setCfg({ skip: v }); this.pending = null; this.state = { status: 'idle' }; }
  }
  installOnQuit() {
    const p = this.pending;
    if (!p || !p.armed || !fs.existsSync(p.file)) return;
    this.pending = null;
    try {
      if (process.platform === 'win32') process.env.PORTABLE_EXECUTABLE_FILE ? this.replaceFile(p, process.env.PORTABLE_EXECUTABLE_FILE) : this.installWindows(p);
      else if (process.platform === 'darwin') this.installMac(p);
      else if (process.env.APPIMAGE) this.replaceFile(p, process.env.APPIMAGE);
      else shell.showItemInFolder(p.file);
    } catch (e) { this.log(`install failed: ${e.message}`); }
  }
  installWindows(p) {
    const args = ['/S', '--updated', ...(p.relaunch ? ['--force-run'] : []), `/D=${path.dirname(process.execPath)}`]; // /D last, unquoted
    spawn(p.file, args, { detached: true, stdio: 'ignore', windowsVerbatimArguments: true }).unref();
    this.log(`running installer ${path.basename(p.file)} ${args.join(' ')}`);
  }
  // portable .exe / AppImage: wait for PIXORA to quit, swap the file, reopen
  replaceFile(p, target) {
    const logf = path.join(this.dir, 'install.log');
    if (process.platform === 'win32') {
      const script = path.join(os.tmpdir(), `pixora-update-${process.pid}.cmd`);
      fs.writeFileSync(script, `@echo off\r\n:wait\r\ntasklist /FI "PID eq ${process.pid}" | find "${process.pid}" >nul && (timeout /t 1 /nobreak >nul & goto wait)\r\n` +
        `copy /Y "${p.file}" "${target}" >>"${logf}" 2>&1\r\n${p.relaunch ? `start "" "${target}"\r\n` : ''}del "%~f0"\r\n`);
      spawn('cmd.exe', ['/c', script], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
    } else {
      const script = path.join(os.tmpdir(), `pixora-update-${process.pid}.sh`);
      fs.writeFileSync(script, `#!/bin/sh\nexec >>"${logf}" 2>&1\nfor i in $(seq 1 300); do kill -0 ${process.pid} 2>/dev/null || break; sleep 0.2; done\n` +
        `cp "${p.file}" "${target}.updating" && chmod +x "${target}.updating" && mv -f "${target}.updating" "${target}" && echo "updated ${target}"\n${p.relaunch ? `"${target}" >/dev/null 2>&1 &\n` : ''}rm -f "$0"\n`, { mode: 0o755 });
      spawn('/bin/sh', [script], { detached: true, stdio: 'ignore' }).unref();
    }
    this.log(`replacing ${target} after quit`);
  }
  appBundle() { return path.resolve(process.execPath, '..', '..', '..'); } // …/PIXORA.app
  canReplaceBundle() {
    const b = this.appBundle();
    if (!b.endsWith('.app') || b.includes('/AppTranslocation/') || b.startsWith('/Volumes/')) return false;
    try { fs.accessSync(path.dirname(b), fs.constants.W_OK); fs.accessSync(b, fs.constants.W_OK); return true; } catch { return false; }
  }
  installMac(p) {
    const bundle = this.appBundle();
    if (!this.canReplaceBundle()) { shell.openPath(p.file); return; } // run from Downloads / the disk image: open the installer instead
    const script = path.join(os.tmpdir(), `pixora-update-${process.pid}.sh`), logf = path.join(this.dir, 'install.log');
    fs.writeFileSync(script, `#!/bin/bash
# PIXORA updater: waits for the app to quit, then replaces it with the new version from the disk image
PID="$1"; DMG="$2"; TARGET="$3"; REOPEN="$4"
exec >>"${logf}" 2>&1
echo "---- $(date) update $TARGET from $DMG"
for i in $(seq 1 300); do kill -0 "$PID" 2>/dev/null || break; sleep 0.2; done
MNT="$(mktemp -d /tmp/pixora-update.XXXXXX)"
if ! hdiutil attach -nobrowse -noautoopen -noverify -mountpoint "$MNT" "$DMG"; then echo "attach failed"; open "$DMG"; exit 1; fi
SRC="$(find "$MNT" -maxdepth 1 -name '*.app' -print -quit)"
OK=0
if [ -n "$SRC" ] && ditto "$SRC" "$TARGET.updating"; then
  rm -rf "$TARGET.previous" && mv "$TARGET" "$TARGET.previous" && mv "$TARGET.updating" "$TARGET" && OK=1
  if [ "$OK" = 1 ]; then rm -rf "$TARGET.previous"; else mv "$TARGET.previous" "$TARGET" 2>/dev/null; fi
  xattr -dr com.apple.quarantine "$TARGET" 2>/dev/null
fi
rm -rf "$TARGET.updating"
hdiutil detach "$MNT" -quiet || hdiutil detach "$MNT" -force -quiet
rmdir "$MNT" 2>/dev/null
if [ "$OK" = 1 ]; then echo "updated"; [ "$REOPEN" = 1 ] && open "$TARGET"; else echo "update failed — opening the disk image"; open "$DMG"; fi
rm -f "$0"
`, { mode: 0o755 });
    spawn('/bin/bash', [script, String(process.pid), p.file, bundle, p.relaunch ? '1' : '0'], { detached: true, stdio: 'ignore' }).unref();
    this.log(`update script started for ${bundle}`);
  }
  cleanOld() {
    try { for (const f of fs.readdirSync(this.dir)) { const m = f.match(/-(\d+\.\d+\.\d+)[-.]/); if ((m && !newer(m[1], app.getVersion())) || f.endsWith('.part')) fs.rmSync(path.join(this.dir, f), { force: true }); } } catch {}
  }
  win() { return BrowserWindow.getFocusedWindow() || BrowserWindow.getAllWindows().find(w => w.isVisible() && !w.pixoraOutput) || null; }
  progress(v) { for (const w of BrowserWindow.getAllWindows()) { try { if (w.isVisible() && !w.pixoraOutput) w.setProgressBar(v); } catch {} } }
  trimNotes(n) { const t = String(n || '').trim(); return t.length > 700 ? `${t.slice(0, 700).replace(/\s+\S*$/, '')}…` : t || 'Bug fixes and improvements.'; }
  ask(message, detail, buttons) { const w = this.win(), o = { type: 'info', message, detail, buttons, defaultId: 0, cancelId: 1, noLink: true }; return w ? dialog.showMessageBox(w, o) : dialog.showMessageBox(o); }
  info(message, type = 'info') { const w = this.win(), o = { type, message, buttons: ['OK'] }; return w ? dialog.showMessageBox(w, o) : dialog.showMessageBox(o); }
}
module.exports = { Updater, newer, pickAsset, plainNotes };
