/* PIXORA Spout plugin template — rename to spout.js to activate (Windows only).
 *
 * PIXORA calls:
 *   create(name)                 -> sender object, once per Output when "Send as Spout" is ticked
 *   sender.send(bgra, w, h)      -> every rendered frame; bgra is a Buffer, tightly packed, width*4 bytes per row
 *   sender.close()               -> when the output closes or Spout is turned off
 *
 * Wire it to any native Spout binding you have built for your Electron version, e.g. a small N-API addon
 * around Spout2's SpoutDX "SendImage" (CPU buffer) call. Until then, the simplest route needs no code:
 * tick "Send as NDI" and run the free "NDI to Spout" tool that ships with Spout (spout.zeal.co).
 */
module.exports = {
  create(name) {
    // const addon = require('./spout-addon.node');            // your native binding
    // const s = new addon.Sender(name);
    return {
      send(bgra, width, height) { /* s.sendImage(bgra, width, height, 'BGRA'); */ },
      close() { /* s.release(); */ },
    };
  },
};
