// PIXORA NDI® — loads PIXORA's own NDI module (desktop/native/ndi) and the NDI runtime.
// Runtime search order: bundled with PIXORA (resources/ndi) → PIXORA_NDI_RUNTIME → the installed NDI Runtime
// (NDI Tools / NDI Redist) → the system library path. NDI® is a registered trademark of Vizrt NDI AB — https://ndi.video/
'use strict';
const path = require('path'), fs = require('fs');

const LIB = process.platform === 'win32' ? (process.arch === 'arm64' ? 'Processing.NDI.Lib.arm64.dll' : 'Processing.NDI.Lib.x64.dll')
  : process.platform === 'darwin' ? 'libndi.dylib' : 'libndi.so.6';
const REDIST_URL = process.platform === 'darwin' ? 'https://ndi.link/NDIRedistV6Apple' : 'https://ndi.link/NDIRedistV6';
const exists = f => { try { return fs.statSync(f).isFile(); } catch { return false; } };

function addonPaths(res) {
  const tag = `${process.platform}-${process.arch}`;
  return [process.env.PIXORA_NDI_ADDON,
    res && path.join(res, 'ndi', `pixora_ndi-${tag}.node`),
    path.join(__dirname, 'native', 'ndi', 'build', 'Release', 'pixora_ndi.node'),
    path.join(__dirname, 'native', 'ndi', `pixora_ndi-${tag}.node`)].filter(Boolean);
}
function runtimePaths(res) {
  const p = [process.env.PIXORA_NDI_RUNTIME, res && path.join(res, 'ndi', LIB)];
  const envDir = process.env.NDI_RUNTIME_DIR_V6; if (envDir) p.push(path.join(envDir, LIB));
  if (process.platform === 'win32') p.push(path.join(process.env.ProgramFiles || 'C:\\Program Files', 'NDI', 'NDI 6 Runtime', 'v6', LIB), path.join(process.env.ProgramFiles || 'C:\\Program Files', 'NDI', 'NDI 6 Tools', 'Runtime', LIB));
  else if (process.platform === 'darwin') p.push('/usr/local/lib/libndi.dylib', '/Library/NDI SDK for Apple/lib/macOS/libndi.dylib', '/Library/NDI SDK for Apple/lib/macos/libndi.dylib');
  else p.push('/usr/lib/x86_64-linux-gnu/libndi.so.6', '/usr/local/lib/libndi.so.6', '/usr/lib/libndi.so.6');
  const found = p.filter(f => f && exists(f));
  if (process.platform === 'linux') found.push(LIB); // let the dynamic loader search LD_LIBRARY_PATH too
  return [...new Set(found)];
}

function open({ resourcesPath } = {}) {
  const api = { available: false, error: '', version: '', path: '', redistUrl: REDIST_URL, info: 'https://ndi.video/', trademark: 'NDI® is a registered trademark of Vizrt NDI AB' };
  let mod = null;
  for (const a of addonPaths(resourcesPath)) { if (!exists(a)) continue; try { mod = require(a); break; } catch (e) { api.error = 'NDI module failed to load: ' + e.message; } }
  if (!mod) { api.error = api.error || 'PIXORA NDI module is not included in this build'; return api; }
  try { const r = mod.load(runtimePaths(resourcesPath)); Object.assign(api, { available: true, error: '', version: r.version, path: r.path }); }
  catch (e) { api.error = /not found/.test(e.message) ? 'NDI runtime not found — install it from ' + REDIST_URL : e.message; return api; }

  api.find = async (waitMs = 1500, extraIps = '') => (await mod.find(waitMs, String(extraIps || '').replace(/\s+/g, ''))).filter(s => s.name);
  api.sender = (name, o = {}) => {
    const h = mod.sendCreate(name, o.groups || '', !!o.clockVideo); let open = true;
    return {
      name,
      // returns false when NDI is still busy with the previous frame (the frame is dropped, never queued)
      video: (buf, w, h2, opt = {}) => open ? mod.sendVideo(h, buf, w, h2, opt.fourCC || 'BGRA', opt.frameRateN || 60, opt.frameRateD || 1, opt.lineStrideBytes || 0) : Promise.resolve(false),
      audio: (f32, sampleRate = 48000, channels = 2) => { if (open) mod.sendAudio(h, f32, sampleRate, channels); },
      connections: () => open ? mod.sendConnections(h) : 0,
      destroy: () => { if (open) { open = false; mod.sendDestroy(h); } },
    };
  };
  api.receiver = (source, o = {}) => {
    const h = mod.recvCreate(source.name || '', source.url || '', o.colorFormat || 'rgba', o.bandwidth || 'highest', o.name || 'PIXORA'); let open = true;
    return {
      capture: (timeoutMs = 100) => open ? mod.recvCapture(h, timeoutMs) : Promise.resolve({ type: 'closed' }),
      connections: () => open ? mod.recvConnections(h) : 0,
      destroy: () => { if (open) { open = false; mod.recvDestroy(h); } },
    };
  };
  return api;
}
module.exports = { open, LIB, REDIST_URL };
