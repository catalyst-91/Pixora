# PIXORA desktop app

PIXORA as a real installed application for Windows, macOS (Apple Silicon and Intel) and Linux. It has its own windows, menus, Dock/taskbar icon, splash screen, `.pixora` file association, native open/save dialogs and notifications. The video engine is built in, so there's no browser and no Node.js install.

**Get the installers without any tools:** see `../BUILD-DESKTOP-APP.md`. GitHub builds the `.exe`, `.dmg` and `.AppImage` for you.

**Build on this computer:** install Node.js 22, then run `npm install` and `npm run dist`. Output goes to `desktop/dist/`.

| File | Role |
|---|---|
| `main.js` | starts the engine, controller and output windows, tray, NDI/Spout |
| `native.js` | application menu, splash, show dialogs, file association, notifications, window memory, free-port picker |
| `preload.js` | the bridge for NDI frames and off-screen web pages |


Runs PIXORA as native software. You don't need a browser or a terminal.

| Feature | How |
|---|---|
| Built-in server | Starts PIXORA automatically (data in your user profile, media in `Videos/PIXORA`) |
| Output windows on any display | Tray ▸ Outputs ▸ *name* ▸ Full screen on display N (remembered, can auto-open at launch) |
| Start at login / keep awake | Tray menu toggles |
| **NDI output** | Tray ▸ Outputs ▸ *name* ▸ Send as NDI (needs the free NDI Runtime; the `grandi` NDI module is installed by `npm install`) |
| **Spout output** (Windows) | Send as NDI, then run Spout's free **NDI to Spout** tool, or install a native Spout plugin (see below) |
| **NDI input** | NDI sources appear in Library ▸ Inputs & Web as clips |
| **Web pages through effects** | Inside the desktop app, web clips are rendered off-screen and become GPU textures, so effects, masks and mapping apply |
| Audio autoplay | No "click to start" needed on outputs |

## Build
```
cd desktop
npm install          # installs Electron + the optional grandi NDI module
npm start            # run from source
npm run dist:win     # Windows installer (.exe) in desktop/dist
npm run dist:mac     # macOS .dmg
```

## Spout
Electron has no maintained Spout binding, so PIXORA doesn't depend on one:

1. **No code (recommended):** tick *Send as NDI*, then run **NDI to Spout** from the Spout download (spout.zeal.co). Spout apps see a normal sender.
2. **Native plugin:** copy `plugins/spout.example.js` to `plugins/spout.js` (or `%APPDATA%/PIXORA/plugins/spout.js`) and wire its three functions (`create(name)`, `send(bgra, w, h)`, `close()`) to a Spout2 addon built for your Electron version. The tray then shows *Send as Spout (plugin)*.

## Testing status
- `main.js` and `preload.js` are covered by `tests/desktop_harness.js`, which runs them against a mocked Electron and a mocked `grandi` that follows grandi's documented API. It checks:
  - the server fork
  - output windows
  - the NDI sender frame fields (BGRA, stride, progressive)
  - back-pressure (frames are dropped, not queued, while NDI is busy)
  - NDI discovery through the `Finder` object
  - NDI receive with padded lines and RGBA
  - off-screen web pages
  - the Spout plugin hook
  - the preload's BGRA/RGBA repacking
- Still to do on real hardware: build with `npm run dist:win` / `dist:mac`, and confirm the stream in NDI Studio Monitor. The NDI module and Electron can't be installed in the build sandbox, so this hasn't been done yet.
