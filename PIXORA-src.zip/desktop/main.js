/* PIXORA desktop app (Electron) — Booth Productions
 * Runs the PIXORA server locally, opens the controller, places Output windows full-screen on chosen displays,
 * keeps the computer awake, can start at login, and adds native features browsers can't do:
 *   • NDI® output of any Output (video + clip audio; in a window or NDI-only off-screen)   • NDI input as a clip source
 *     NDI® is a registered trademark of Vizrt NDI AB — https://ndi.video/  (PIXORA's own module: desktop/ndi.js + native/ndi)
 *   • web pages rendered off-screen as GPU textures (so effects apply to them)
 * native.js adds the application menu, splash, show-file dialogs, file association, notifications and window memory.
 */
const { app, BrowserWindow, Tray, Menu, screen, powerSaveBlocker, ipcMain, nativeImage, dialog, shell } = require('electron');
const path = require('path'), fs = require('fs'), { fork } = require('child_process'), http = require('http');

app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
app.commandLine.appendSwitch('ignore-gpu-blocklist');
app.commandLine.appendSwitch('enable-gpu-rasterization');
if (!app.requestSingleInstanceLock()) app.quit();

let PORT = +process.env.PORT || 8080;
let BASE = `http://localhost:${PORT}`;
const CFG_FILE = path.join(app.getPath('userData'), 'desktop.json');
let cfg = { outputs: [], autostart: false, preventSleep: true, openController: true, runServer: true, recent: [], windows: {} };
try { cfg = Object.assign(cfg, JSON.parse(fs.readFileSync(CFG_FILE, 'utf8'))); } catch {}
const saveCfg = () => { try { fs.mkdirSync(path.dirname(CFG_FILE), { recursive: true }); fs.writeFileSync(CFG_FILE, JSON.stringify(cfg, null, 1)); } catch (e) { console.warn('settings', e.message); } };

let server = null, tray = null, controller = null, sleepId = null; const outWins = new Map();
// NDI®: PIXORA's own Node-API module + the NDI runtime bundled in resources/ndi (or an installed NDI Runtime)
const ndi = require('./ndi.js').open({ resourcesPath: process.resourcesPath });
if (!ndi.available) console.warn('NDI:', ndi.error); else console.log('NDI runtime', ndi.version, 'from', ndi.path);
// Spout: Electron has no maintained Spout binding, so PIXORA ships a plugin hook instead of a hard dependency.
// Drop a module at <userData>/plugins/spout.js (or desktop/plugins/spout.js) exporting
//   { create(name) -> { send(bgraBuffer, width, height), close() } }
// Without a plugin, enable "Send as NDI" and use NDI's free "NDI to Spout" tool (Spout's official bridge).
let spout = null;
for (const p of [path.join(app.getPath('userData'), 'plugins', 'spout.js'), path.join(__dirname, 'plugins', 'spout.js')]) { try { if (fs.existsSync(p)) { const m = require(p); if (m && typeof m.create === 'function') { spout = m; break; } } } catch (e) { console.warn('Spout plugin', e.message); } }
async function ndiSources(waitMs = 1500) { return ndi.available ? ndi.find(waitMs, cfg.ndiExtraIps || '') : []; }

/* ---------------- server */
function startServer() {
  if (!cfg.runServer) return;
  const script = [path.join(process.resourcesPath || '', 'pixora-app', 'server.js'), path.join(__dirname, 'pixora-app', 'server.js'), path.join(__dirname, '..', 'server.js')].find(f => { try { return fs.existsSync(f); } catch { return false; } });
  const data = path.join(app.getPath('userData'), 'data'), media = path.join(app.getPath('videos'), 'PIXORA');
  fs.mkdirSync(media, { recursive: true });
  // ffmpeg bundled with the app (resources/ffmpeg) unless the user points FFMPEG_PATH at their own
  const bundledFf = [path.join(process.resourcesPath || '', 'ffmpeg', process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg'), path.join(__dirname, 'node_modules', 'ffmpeg-static', process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg')].find(f => { try { return fs.statSync(f).size > 1e6; } catch { return false; } });
  if (bundledFf && process.platform !== 'win32') { try { fs.chmodSync(bundledFf, 0o755); } catch {} }
  server = fork(script, [], { env: Object.assign({}, process.env, bundledFf && !process.env.FFMPEG_PATH ? { FFMPEG_PATH: bundledFf } : {}, { PORT: String(PORT), DATA_DIR: process.env.DATA_DIR || data, MEDIA_DIR: process.env.MEDIA_DIR || media, PIXORA_LAUNCHER: '1', PIXORA_APP_TOKEN: nat.TOKEN, PIXORA_NATIVE: app.isPackaged ? process.platform : '' }), stdio: 'inherit' });
  server.on('exit', code => { if (app.isQuitting) return; if (code === 75) { process.env.PIXORA_RESTART_WAIT = '1'; return startServer(); } dialog.showErrorBox('PIXORA', `The PIXORA server stopped (code ${code}). Is port ${PORT} already in use?`); });
}
function waitForServer(cb, tries = 0) { http.get(BASE + '/api/info', r => { r.resume(); cb(); }).on('error', () => tries < 100 ? setTimeout(() => waitForServer(cb, tries + 1), 200) : cb()); }

/* ---------------- windows */
const webPrefs = { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, backgroundThrottling: false };
function openController() {
  if (controller && !controller.isDestroyed()) return controller.focus();
  controller = new BrowserWindow({ width: 1680, height: 1000, minWidth: 1100, minHeight: 680, backgroundColor: '#08080b', title: 'PIXORA', icon: path.join(__dirname, 'icon.png'), show: false, webPreferences: webPrefs });
  nat.restoreBounds('controller', controller); nat.trackBounds('controller', controller);
  controller.once('ready-to-show', () => { controller.show(); nat.closeSplash(); });
  controller.loadURL(BASE + '/');
  const own = nat.guardLinks(controller);
  controller.on('close', () => { if (!app.isQuitting && !cfg.trayHintShown && process.platform !== 'darwin') { cfg.trayHintShown = true; saveCfg(); try { new (require('electron').Notification)({ title: 'PIXORA is still running', body: 'Outputs keep playing. Use the tray icon to reopen the controller, or File ▸ Exit to quit.' }).show(); } catch {} } });
  controller.webContents.setWindowOpenHandler(({ url }) => { if (/\/output|\/clean/.test(url)) { const u = new URL(url); openOutput(u.searchParams.get('out') || 'main', null, u.pathname.startsWith('/clean')); return { action: 'deny' }; } if (own(url)) { const u = new URL(url); nat.openAppWindow(u.pathname + u.search + u.hash, 'PIXORA'); return { action: 'deny' }; } shell.openExternal(url); return { action: 'deny' }; });
}
function openOutput(outId, displayId, clean) {
  const key = outId; if (outWins.has(key) && !outWins.get(key).win.isDestroyed()) { const e = outWins.get(key); if (!e.offscreen) { e.win.focus(); return; } e.win.destroy(); outWins.delete(key); } // a visible window replaces the NDI-only one
  const d = screen.getAllDisplays().find(x => String(x.id) === String(displayId)) || null;
  const b = d ? d.bounds : { x: 80, y: 80, width: 1280, height: 720 };
  const win = new BrowserWindow({ x: b.x, y: b.y, width: b.width, height: b.height, frame: !d, fullscreen: !!d, kiosk: !!d, backgroundColor: '#000000', title: 'PIXORA Output — ' + outId, icon: path.join(__dirname, 'icon.png'), webPreferences: webPrefs });
  win.setMenuBarVisibility(false); win.loadURL(`${BASE}/${clean ? 'clean' : 'output'}?out=${encodeURIComponent(outId)}&fs=0`);
  const entry = { win, outId, ndi: null, spout: null }; outWins.set(key, entry);
  win.on('closed', () => { stopSenders(entry); if (outWins.get(key) === entry) outWins.delete(key); buildTray(); nat.build(); ndiOnlyCheck(outId); });
  const conf = cfg.outputs.find(o => o.outId === outId); if (conf && conf.ndi) startNdiSend(entry); if (conf && conf.spout && spout) startSpoutSend(entry);
  buildTray(); nat.build();
}
// NDI-only output: rendered off-screen at the composition size — no display or visible window needed
async function openNdiOnly(outId) {
  if (outWins.has(outId)) return outWins.get(outId);
  const st = await new Promise(res => http.get(BASE + '/api/state', r => { let b = ''; r.on('data', c => b += c); r.on('end', () => { try { res(JSON.parse(b)); } catch { res({}); } }); }).on('error', () => res({})));
  const out = (st.outputs || []).find(o => o.id === outId) || {}, W = out.w || (st.comp && st.comp.w) || 1920, H = out.h || (st.comp && st.comp.h) || 1080;
  const win = new BrowserWindow({ show: false, width: W, height: H, useContentSize: true, title: 'PIXORA NDI — ' + outId, webPreferences: Object.assign({}, webPrefs, { offscreen: true }) });
  win.webContents.setFrameRate(Math.min(60, Math.max(24, +cfg.ndiFps || 60)));
  win.loadURL(`${BASE}/output?out=${encodeURIComponent(outId)}&fs=0&ndi=1`);
  win.webContents.setAudioMuted(true); // its sound goes to NDI only, not to this computer's speakers
  const entry = { win, outId, ndi: null, spout: null, offscreen: true }; outWins.set(outId, entry);
  win.on('closed', () => { stopSenders(entry); if (outWins.get(outId) === entry) outWins.delete(outId); buildTray(); nat.build(); });
  startNdiSend(entry); buildTray(); nat.build(); return entry;
}
function ndiOnlyCheck(outId) { const conf = cfg.outputs.find(o => o.outId === outId); if (conf && conf.ndi && conf.ndiOnly && !app.isQuitting) setTimeout(() => { if (!outWins.has(outId)) openNdiOnly(outId); }, 500); }

/* ---------------- NDI / Spout senders: capture frames of an Output window */
function onFrame(entry, image) {
  if (!entry.ndi && !entry.spout) return;
  const { width, height } = image.getSize(); if (!width || !height) return;
  if (entry.ndi && entry.ndiBusy) { entry.ndiDropped = (entry.ndiDropped || 0) + 1; if (!entry.spout) return; } // NDI still compressing: drop, never queue
  const bgra = image.toBitmap(); // raw BGRA, width*4 stride
  if (entry.ndi && !entry.ndiBusy) {
    entry.ndiBusy = true; const fps = Math.min(60, Math.max(24, +cfg.ndiFps || 60));
    entry.ndi.video(bgra, width, height, { fourCC: 'BGRA', frameRateN: fps, frameRateD: 1 })
      .then(ok => { if (ok) { entry.ndiFrames = (entry.ndiFrames || 0) + 1; entry.ndiSize = width + '×' + height; } })
      .catch(e => { if (!entry.ndiWarned) { entry.ndiWarned = true; console.warn('NDI send', e && e.message); } }).finally(() => { entry.ndiBusy = false; });
  }
  if (entry.spout) { try { entry.spout.send(bgra, width, height); } catch (e) { console.warn('Spout', e.message); } }
}
function frameSub(entry) {
  if (entry.sub) return; entry.sub = true;
  if (entry.offscreen) { entry.paint = (_e, _d, image) => onFrame(entry, image); entry.win.webContents.on('paint', entry.paint); }
  else entry.win.webContents.beginFrameSubscription(false, image => onFrame(entry, image));
}
const ndiName = outId => { const c = cfg.outputs.find(o => o.outId === outId) || {}; return (c.ndiName || '').trim() || 'PIXORA ' + outId; };
function startNdiSend(entry) {
  if (!ndi.available) return dialog.showMessageBox({ type: 'warning', message: 'NDI® is not available', detail: ndi.error + '\n\nNDI® is a registered trademark of Vizrt NDI AB — https://ndi.video/', buttons: ['OK', 'Get the NDI Runtime'] }).then(r => { if (r.response === 1) shell.openExternal(ndi.redistUrl); });
  if (entry.ndi) return;
  try { entry.ndi = ndi.sender(ndiName(entry.outId), { groups: cfg.ndiGroups || '' }); entry.ndiFrames = 0; entry.ndiDropped = 0; frameSub(entry); setNdiAudio(entry, true); }
  catch (e) { entry.ndi = null; dialog.showErrorBox('NDI', e.message); }
}
// clip audio from the output window rides along with the NDI video (output.html streams PCM over IPC)
function setNdiAudio(entry, on) { try { if (!entry.win.isDestroyed()) entry.win.webContents.send('native-ndi-audio', { on: on && cfg.ndiAudio !== false }); } catch {} }
ipcMain.on('native-ndi-audio-ready', e => { for (const en of outWins.values()) if (!en.win.isDestroyed() && en.win.webContents === e.sender && en.ndi) setNdiAudio(en, true); });
ipcMain.on('native-ndi-pcm', (e, { data, sampleRate, channels }) => {
  for (const en of outWins.values()) if (en.ndi && !en.win.isDestroyed() && en.win.webContents === e.sender) {
    try { en.ndi.audio(new Float32Array(data.buffer || data, data.byteOffset || 0, (data.byteLength || data.length * 4) / 4), sampleRate || 48000, channels || 2); en.ndiAudioOn = Date.now(); } catch {}
  }
});
function startSpoutSend(entry) {
  if (process.platform !== 'win32') return dialog.showMessageBox({ message: 'Spout is a Windows technology.', detail: 'On macOS use NDI, or Syphon via the free NDI→Syphon bridge.' });
  if (!spout) return dialog.showMessageBox({ message: 'Spout via NDI', detail: 'Turn on "Send as NDI" for this output, then run the free "NDI to Spout" tool from the Spout download (spout.zeal.co) — it republishes the NDI stream as a Spout sender with no extra latency to speak of on the same machine.\n\nDevelopers can install a native Spout plugin at ' + path.join(app.getPath('userData'), 'plugins', 'spout.js') + ' — see desktop/README.md.' });
  if (entry.spout) return;
  try { entry.spout = spout.create('PIXORA ' + entry.outId); frameSub(entry); } catch (e) { entry.spout = null; dialog.showErrorBox('Spout', e.message); }
}
function stopSenders(entry, which) {
  if (!which || which === 'ndi') { if (entry.ndi) setNdiAudio(entry, false); try { entry.ndi && entry.ndi.destroy(); } catch {} entry.ndi = null; }
  if (!which || which === 'spout') { try { entry.spout && entry.spout.close && entry.spout.close(); } catch {} entry.spout = null; }
  if (!entry.ndi && !entry.spout) { try { if (entry.paint) entry.win.webContents.removeListener('paint', entry.paint); else entry.win.webContents.endFrameSubscription(); } catch {} entry.sub = false; entry.paint = null; }
  if (entry.offscreen && !entry.ndi && !which && !entry.win.isDestroyed()) entry.win.destroy();
}
/* ---------------- NDI control for the controller (Output tab ▸ NDI) */
function ndiState() {
  const outs = {};
  for (const c of cfg.outputs) outs[c.outId] = { ndi: !!c.ndi, ndiOnly: !!c.ndiOnly, name: ndiName(c.outId) };
  for (const [id, en] of outWins) outs[id] = Object.assign(outs[id] || { name: ndiName(id) }, { window: !en.offscreen, offscreen: !!en.offscreen, sending: !!en.ndi,
    receivers: en.ndi ? en.ndi.connections() : 0, frames: en.ndiFrames || 0, dropped: en.ndiDropped || 0, size: en.ndiSize || '', audio: !!(en.ndiAudioOn && Date.now() - en.ndiAudioOn < 2000) });
  return { available: ndi.available, error: ndi.error, version: ndi.version, path: ndi.path, redistUrl: ndi.redistUrl, info: ndi.info, trademark: ndi.trademark,
    extraIps: cfg.ndiExtraIps || '', groups: cfg.ndiGroups || '', fps: +cfg.ndiFps || 60, audio: cfg.ndiAudio !== false, outputs: outs };
}
ipcMain.handle('native-ndi-state', () => ndiState());
ipcMain.handle('native-ndi-set', async (_e, p = {}) => {
  if (p.outId) {
    const prevName = ndiName(p.outId), patch = {};
    for (const k of ['ndi', 'ndiOnly']) if (k in p) patch[k] = !!p[k];
    if ('name' in p) patch.ndiName = String(p.name || '').slice(0, 60);
    setOutCfg(p.outId, patch); const conf = cfg.outputs.find(o => o.outId === p.outId);
    let en = outWins.get(p.outId);
    if (en && en.ndi && 'name' in p && ndiName(p.outId) !== prevName) { stopSenders(en, 'ndi'); en = outWins.get(p.outId); } // rename = new sender
    if (conf.ndi) { if (en && !en.win.isDestroyed()) startNdiSend(en); else if (conf.ndiOnly) await openNdiOnly(p.outId); }
    else if (en) { if (en.offscreen) stopSenders(en); else stopSenders(en, 'ndi'); }
    if (conf.ndi && !conf.ndiOnly && en && en.offscreen) stopSenders(en); // NDI-only turned off and no window: stop
  } else {
    if ('extraIps' in p) cfg.ndiExtraIps = String(p.extraIps || '').replace(/\s+/g, '');
    if ('groups' in p) cfg.ndiGroups = String(p.groups || '').replace(/\s+/g, '');
    if ('fps' in p) cfg.ndiFps = Math.min(60, Math.max(24, +p.fps || 60));
    if ('audio' in p) { cfg.ndiAudio = !!p.audio; for (const en of outWins.values()) if (en.ndi) setNdiAudio(en, true); }
    saveCfg();
    for (const en of outWins.values()) if (en.offscreen) en.win.webContents.setFrameRate(+cfg.ndiFps || 60);
  }
  buildTray(); nat.build(); return ndiState();
});
function setOutCfg(outId, patch) { let o = cfg.outputs.find(x => x.outId === outId); if (!o) { o = { outId }; cfg.outputs.push(o); } Object.assign(o, patch); saveCfg(); }

/* ---------------- native sources for the renderer: off-screen web pages and NDI receive */
const natives = new Map(); let natId = 1;
ipcMain.on('native-open-web', (e, { url, w, h }) => {
  const id = natId++; const owner = e.sender;
  const win = new BrowserWindow({ show: false, width: Math.max(16, w | 0), height: Math.max(16, h | 0), webPreferences: { offscreen: true, backgroundThrottling: false } });
  win.webContents.setFrameRate(30); win.loadURL(url);
  win.webContents.on('paint', (_ev, _dirty, image) => { if (owner.isDestroyed()) return; const { width, height } = image.getSize(); owner.send('native-frame', { id, width, height, stride: width * 4, fmt: 'bgra', data: image.toBitmap() }); });
  natives.set(id, { close: () => { if (!win.isDestroyed()) win.destroy(); } }); e.returnValue = id;
});
ipcMain.on('native-open-ndi', (e, { name }) => {
  const id = natId++; const owner = e.sender; e.returnValue = id;
  if (!ndi.available) { setTimeout(() => { if (!owner.isDestroyed()) owner.send('native-status', { id, error: 'NDI unavailable: ' + ndi.error }); }, 50); return; }
  const st = { alive: true, rx: null };
  natives.set(id, { close: () => { st.alive = false; try { st.rx && st.rx.destroy && st.rx.destroy(); } catch {} } });
  (async () => {
    try {
      const srcs = await ndiSources(2000); const src = srcs.find(s => s.name === name) || (name ? null : srcs[0]);
      if (!src) { if (!owner.isDestroyed()) owner.send('native-status', { id, error: 'NDI source not found: ' + name }); return; }
      // RGBA from NDI so the renderer uploads without swizzling
      st.rx = ndi.receiver(src, { colorFormat: 'rgba', bandwidth: 'highest', name: 'PIXORA' });
      if (!st.alive) { st.rx.destroy(); return; }
      while (st.alive && !owner.isDestroyed()) {
        const f = await st.rx.capture(1000); // 'none' = no frame this second
        if (f.type === 'closed') break;
        if (!st.alive || owner.isDestroyed() || f.type !== 'video' || !f.data) continue;
        owner.send('native-frame', { id, width: f.xres, height: f.yres, stride: f.lineStrideBytes || f.xres * 4, fmt: /^RGB/.test(f.fourCC) ? 'rgba' : 'bgra', data: f.data });
      }
    } catch (er) { console.warn('NDI receive', er.message); }
  })();
});
ipcMain.on('native-close', (_e, { id }) => { const n = natives.get(id); if (n) n.close(); natives.delete(id); });
ipcMain.handle('native-list-ndi', async () => { try { return (await ndiSources(1500)).map(s => s.name); } catch { return []; } });
ipcMain.handle('native-pick-folder', async (e, { start } = {}) => { const r = await dialog.showOpenDialog(BrowserWindow.fromWebContents(e.sender), { title: 'Save recordings to', buttonLabel: 'Use this folder', defaultPath: start || app.getPath('videos'), properties: ['openDirectory', 'createDirectory'] }); return r.canceled ? '' : r.filePaths[0] || ''; });
ipcMain.on('native-reveal', (_e, { file } = {}) => { if (typeof file === 'string' && file && fs.existsSync(file)) shell.showItemInFolder(file); });
ipcMain.handle('native-displays', () => screen.getAllDisplays().map(d => ({ id: d.id, label: d.label, bounds: d.bounds, primary: d.id === screen.getPrimaryDisplay().id })));

/* ---------------- tray menu */
async function fetchOutputs() { return new Promise(res => http.get(BASE + '/api/state', r => { let b = ''; r.on('data', c => b += c); r.on('end', () => { try { res(JSON.parse(b).outputs || []); } catch { res([{ id: 'main', name: 'Main' }]); } }); }).on('error', () => res([{ id: 'main', name: 'Main' }]))); }
async function buildTray() {
  if (!tray) return; const outs = await fetchOutputs(); const displays = screen.getAllDisplays();
  const outMenus = outs.map(o => { const conf = cfg.outputs.find(x => x.outId === o.id) || {}; const open = outWins.get(o.id);
    return { label: `${o.name}${open ? '  ●' : ''}`, submenu: [
      { label: 'Open in a window', click: () => openOutput(o.id, null) },
      { type: 'separator' },
      ...displays.map((d, i) => ({ label: `Full screen on display ${i + 1} — ${d.bounds.width}×${d.bounds.height}${d.id === screen.getPrimaryDisplay().id ? ' (main)' : ''}`, type: 'radio', checked: String(conf.displayId) === String(d.id),
        click: () => { setOutCfg(o.id, { displayId: d.id, auto: true }); const w = outWins.get(o.id); if (w) w.win.close(); setTimeout(() => openOutput(o.id, d.id), 300); } })),
      { type: 'separator' },
      { label: 'Open automatically at launch', type: 'checkbox', checked: !!conf.auto, click: m => setOutCfg(o.id, { auto: m.checked }) },
      { label: 'Send as NDI®', type: 'checkbox', checked: !!conf.ndi, click: m => { setOutCfg(o.id, { ndi: m.checked }); const w = outWins.get(o.id); if (w) { if (m.checked) startNdiSend(w); else stopSenders(w, w.offscreen ? undefined : 'ndi'); } else if (m.checked && conf.ndiOnly) openNdiOnly(o.id); } },
      { label: 'NDI® only (no window needed)', type: 'checkbox', checked: !!conf.ndiOnly, click: m => { setOutCfg(o.id, { ndiOnly: m.checked, ndi: m.checked ? true : conf.ndi }); if (m.checked && !outWins.has(o.id)) openNdiOnly(o.id); else if (!m.checked) { const w = outWins.get(o.id); if (w && w.offscreen) stopSenders(w); } buildTray(); } },
      { label: spout ? 'Send as Spout (plugin)' : 'Send as Spout (via NDI bridge)…', type: spout ? 'checkbox' : 'normal', checked: !!conf.spout, enabled: process.platform === 'win32', click: m => { if (!spout) { const w = outWins.get(o.id); return startSpoutSend(w || { outId: o.id }); } setOutCfg(o.id, { spout: m.checked }); const w = outWins.get(o.id); if (w) { if (m.checked) startSpoutSend(w); else stopSenders(w, 'spout'); } } },
      { label: 'Close output', enabled: !!open, click: () => open && open.win.close() }] }; });
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Open PIXORA controller', click: openController },
    { label: 'Outputs', submenu: outMenus.length ? outMenus : [{ label: 'No outputs', enabled: false }] },
    { label: 'Refresh outputs list', click: buildTray },
    { type: 'separator' },
    { label: 'Start at login', type: 'checkbox', checked: cfg.autostart, click: m => { cfg.autostart = m.checked; saveCfg(); app.setLoginItemSettings({ openAtLogin: m.checked }); } },
    { label: 'Keep display awake', type: 'checkbox', checked: cfg.preventSleep, click: m => { cfg.preventSleep = m.checked; saveCfg(); applySleep(); } },
    { label: `NDI®: ${ndi.available ? 'ready (v' + (String(ndi.version).match(/\d+\.\d+\.\d+/) || [''])[0] + ')' : 'runtime not found'} · Spout: ${spout ? 'plugin loaded' : process.platform === 'win32' ? 'via NDI bridge' : 'n/a'}`, enabled: false },
    ...(ndi.available ? [] : [{ label: 'Get the NDI® Runtime…', click: () => shell.openExternal(ndi.redistUrl) }]),
    { label: 'About NDI® — ndi.video', click: () => shell.openExternal('https://ndi.video/') },
    { label: 'Open media folder', click: () => shell.openPath(path.join(app.getPath('videos'), 'PIXORA')) },
    { label: 'Open in web browser', click: () => shell.openExternal(BASE) },
    { type: 'separator' },
    { label: 'Quit PIXORA', click: () => { app.isQuitting = true; app.quit(); } }]));
}
function applySleep() { if (cfg.preventSleep && sleepId == null) sleepId = powerSaveBlocker.start('prevent-display-sleep'); if (!cfg.preventSleep && sleepId != null) { powerSaveBlocker.stop(sleepId); sleepId = null; } }

const nat = require('./native.js')({
  getBase: () => BASE, cfg, saveCfg, openController, openOutput, outWins, controllerRef: () => controller, fetchOutputs,
  setOutCfg: (id, p) => setOutCfg(id, p), icon: path.join(__dirname, 'icon.png'),
});

app.whenReady().then(async () => {
  if (process.platform === 'darwin' && app.dock) try { app.dock.setIcon(path.join(__dirname, 'icon.png')); } catch {}
  nat.showSplash(); nat.build();
  if (cfg.runServer && !process.env.PORT) { PORT = await nat.freePort(cfg.port || 8080); BASE = `http://localhost:${PORT}`; } // another app on 8080? use the next free port
  startServer(); applySleep();
  tray = new Tray(nativeImage.createFromPath(path.join(__dirname, 'icon.png')).resize({ width: 18, height: 18 })); tray.setToolTip('PIXORA');
  tray.on('click', openController);
  waitForServer(() => {
    if (cfg.openController !== false) openController(); else nat.closeSplash();
    for (const o of cfg.outputs) if (o.auto) openOutput(o.outId, o.displayId);
    for (const o of cfg.outputs) if (o.ndi && o.ndiOnly && !o.auto) openNdiOnly(o.outId); // NDI-only outputs need no display
    buildTray(); nat.onReady();
  });
  screen.on('display-added', () => { buildTray(); nat.build(); }); screen.on('display-removed', () => { buildTray(); nat.build(); });
  app.on('activate', openController); // macOS: clicking the dock icon
});
app.on('second-instance', (e, argv) => { openController(); nat.onSecondInstance(argv); });
app.on('window-all-closed', e => { /* keep running in the tray */ });
app.on('before-quit', () => { app.isQuitting = true; for (const e of outWins.values()) stopSenders(e); if (server) server.kill(); });
