/* PIXORA desktop app (Electron) — Booth Productions
 * Runs the PIXORA server locally, opens the controller, places Output windows full-screen on chosen displays,
 * keeps the computer awake, can start at login, and adds native features browsers can't do:
 *   • NDI® output of any Output (video + clip audio; in a window or NDI-only off-screen)   • NDI input as a clip source
 *     NDI® is a registered trademark of Vizrt NDI AB — https://ndi.video/  (PIXORA's own module: desktop/ndi.js + native/ndi)
 *   • web pages rendered off-screen as GPU textures (so effects apply to them)
 * native.js adds the application menu, splash, show-file dialogs, file association, notifications and window memory.
 */
const { app, BrowserWindow, Tray, Menu, screen, powerSaveBlocker, ipcMain, nativeImage, dialog, shell } = require('electron');
const path = require('path'), fs = require('fs'), { fork } = require('child_process'), http = require('http');

app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
app.commandLine.appendSwitch('ignore-gpu-blocklist');
app.commandLine.appendSwitch('enable-gpu-rasterization');
if (!app.requestSingleInstanceLock()) app.quit();

let PORT = +process.env.PORT || 8080;
let BASE = `http://localhost:${PORT}`;
const CFG_FILE = path.join(app.getPath('userData'), 'desktop.json');
let cfg = { outputs: [], autostart: false, preventSleep: true, openController: true, runServer: true, recent: [], windows: {} };
try { cfg = Object.assign(cfg, JSON.parse(fs.readFileSync(CFG_FILE, 'utf8'))); } catch {}
const saveCfg = () => { try { fs.mkdirSync(path.dirname(CFG_FILE), { recursive: true }); fs.writeFileSync(CFG_FILE, JSON.stringify(cfg, null, 1)); } catch (e) { console.warn('settings', e.message); } };

let server = null, tray = null, controller = null, sleepId = null; const outWins = new Map();
// NDI®: PIXORA's own Node-API module + the NDI runtime bundled in resources/ndi (or an installed NDI Runtime)
const ndi = require('./ndi.js').open({ resourcesPath: process.resourcesPath });
const decklink = require('./decklink.js').open({ resourcesPath: process.resourcesPath }); // Blackmagic DeckLink / UltraStudio
if (!ndi.available) console.warn('NDI:', ndi.error); else console.log('NDI runtime', ndi.version, 'from', ndi.path);
// Spout: Electron has no maintained Spout binding, so PIXORA ships a plugin hook instead of a hard dependency.
// Drop a module at <userData>/plugins/spout.js (or desktop/plugins/spout.js) exporting
//   { create(name) -> { send(bgraBuffer, width, height), close() } }
// Without a plugin, enable "Send as NDI" and use NDI's free "NDI to Spout" tool (Spout's official bridge).
let spout = null;
for (const p of [path.join(app.getPath('userData'), 'plugins', 'spout.js'), path.join(__dirname, 'plugins', 'spout.js')]) { try { if (fs.existsSync(p)) { const m = require(p); if (m && typeof m.create === 'function') { spout = m; break; } } } catch (e) { console.warn('Spout plugin', e.message); } }
// built-in Spout (Windows) / Syphon (macOS) — a plugin above still takes priority
const texshare = require('./texshare.js').open({ resourcesPath: process.resourcesPath });
const TS = texshare.kind || 'Spout'; // label used in menus
if (!spout && texshare.available) spout = texshare;
async function ndiSources(waitMs = 1500) { return ndi.available ? ndi.find(waitMs, cfg.ndiExtraIps || '') : []; }

/* ---------------- server */
let serverTail = '', restarts = [];
const crash = require('./crash.js')({ app, dialog, shell, BrowserWindow, cfg, saveCfg: () => saveCfg() });
process.on('uncaughtException', e => { try { crash.record('PIXORA app', { message: e && e.message, stack: e && e.stack }); } catch {} console.error(e); });
app.on('render-process-gone', (e, wc, d) => { if (app.isQuitting || d.reason === 'clean-exit') return;
  const w = BrowserWindow.fromWebContents(wc); const isOut = w && w.pixoraOutput;
  crash.record(isOut ? 'output window' : w === controller ? 'controller window' : 'window', { message: `renderer ${d.reason} (exit code ${d.exitCode})` });
  if (w && !w.isDestroyed() && (isOut || w === controller)) setTimeout(() => { try { wc.reload(); } catch {} }, 500); }); // outputs come straight back
app.on('child-process-gone', (e, d) => { if (!app.isQuitting && d.type === 'GPU' && d.reason !== 'clean-exit') crash.record('graphics (GPU) process', { message: `GPU process ${d.reason} (exit code ${d.exitCode})` }); });
function startServer() {
  if (!cfg.runServer) return;
  const script = [path.join(process.resourcesPath || '', 'pixora-app', 'server.js'), path.join(__dirname, 'pixora-app', 'server.js'), path.join(__dirname, '..', 'server.js')].find(f => { try { return fs.existsSync(f); } catch { return false; } });
  const data = path.join(app.getPath('userData'), 'data'), media = path.join(app.getPath('videos'), 'PIXORA');
  fs.mkdirSync(media, { recursive: true });
  // ffmpeg bundled with the app (resources/ffmpeg) unless the user points FFMPEG_PATH at their own
  const bundledFf = [path.join(process.resourcesPath || '', 'ffmpeg', process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg'), path.join(__dirname, 'node_modules', 'ffmpeg-static', process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg')].find(f => { try { return fs.statSync(f).size > 1e6; } catch { return false; } });
  if (bundledFf && process.platform !== 'win32') { try { fs.chmodSync(bundledFf, 0o755); } catch {} }
  server = fork(script, [], { env: Object.assign({}, process.env, bundledFf && !process.env.FFMPEG_PATH ? { FFMPEG_PATH: bundledFf } : {}, { PORT: String(PORT), DATA_DIR: process.env.DATA_DIR || data, MEDIA_DIR: process.env.MEDIA_DIR || media, PIXORA_LAUNCHER: '1', PIXORA_APP_TOKEN: nat.TOKEN, PIXORA_NATIVE: app.isPackaged ? process.platform : '', PIXORA_CARABINER_DIR: app.isPackaged ? path.join(process.resourcesPath, 'link') : path.join(__dirname, 'link-dist') }), stdio: ['inherit', 'inherit', 'pipe', 'ipc'] });
  serverTail = ''; if (server.stderr) server.stderr.on('data', d => { process.stderr.write(d); serverTail = (serverTail + d.toString()).slice(-8000); });
  server.on('exit', (code, signal) => {
    if (app.isQuitting) return;
    if (code === 75) { process.env.PIXORA_RESTART_WAIT = '1'; return startServer(); } // asked to restart (update / settings)
    if (/EADDRINUSE/.test(serverTail)) return dialog.showErrorBox('PIXORA', `The PIXORA server couldn't start: port ${PORT} is already in use by another program.`);
    const err = (serverTail.match(/^(?:\w*Error|Uncaught)[^\n]*$/m) || [])[0] || `exited with ${signal ? 'signal ' + signal : 'code ' + code}`;
    crash.record('server', { message: err, tail: serverTail });
    restarts = restarts.filter(t => Date.now() - t < 60000);
    if (restarts.length < 3) { restarts.push(Date.now()); process.env.PIXORA_RESTART_WAIT = '1'; setTimeout(startServer, 1000); } // keep the show running; outputs reconnect by themselves
    else dialog.showErrorBox('PIXORA', `The PIXORA server keeps stopping (${err}). Restart PIXORA; if it happens again, send the crash report from Help ▸ Crash Reports.`);
  });
}
function stopServer() { // ask first, so the server stops its helpers (Carabiner); force it if it doesn't go
  const s = server; if (!s) return; server = null;
  try { if (s.connected) s.send({ t: 'quit' }); } catch {}
  setTimeout(() => { try { if (s.exitCode == null && s.signalCode == null) s.kill(); } catch {} }, 1500);
}
function waitForServer(cb, tries = 0) { http.get(BASE + '/api/info', r => { r.resume(); cb(); }).on('error', () => tries < 100 ? setTimeout(() => waitForServer(cb, tries + 1), 200) : cb()); }

/* ---------------- windows */
const webPrefs = { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, backgroundThrottling: false };
function openController() {
  if (controller && !controller.isDestroyed()) return controller.focus();
  controller = new BrowserWindow({ width: 1680, height: 1000, minWidth: 1100, minHeight: 680, backgroundColor: '#08080b', title: 'PIXORA', icon: path.join(__dirname, 'icon.png'), show: false, webPreferences: webPrefs });
  nat.restoreBounds('controller', controller); nat.trackBounds('controller', controller);
  controller.once('ready-to-show', () => { controller.show(); nat.closeSplash(); });
  controller.loadURL(BASE + '/');
  const own = nat.guardLinks(controller);
  controller.on('close', () => { if (!app.isQuitting && !cfg.trayHintShown && process.platform !== 'darwin') { cfg.trayHintShown = true; saveCfg(); try { new (require('electron').Notification)({ title: 'PIXORA is still running', body: 'Outputs keep playing. Use the tray icon to reopen the controller, or File ▸ Exit to quit.' }).show(); } catch {} } });
  controller.webContents.setWindowOpenHandler(({ url }) => { if (/\/output|\/clean/.test(url)) { const u = new URL(url); openOutput(u.searchParams.get('out') || 'main', null, u.pathname.startsWith('/clean')); return { action: 'deny' }; } if (own(url)) { const u = new URL(url); nat.openAppWindow(u.pathname + u.search + u.hash, 'PIXORA'); return { action: 'deny' }; } shell.openExternal(url); return { action: 'deny' }; });
}
// background timecode reader: a hidden window that reads LTC / MTC whenever Timecode ▸ "Read in the desktop app" is chosen
let tcReaderWin = null;
function openTcReader() {
  if (tcReaderWin && !tcReaderWin.isDestroyed()) return;
  tcReaderWin = new BrowserWindow({ show: false, width: 420, height: 160, title: 'PIXORA timecode reader', webPreferences: Object.assign({}, webPrefs, { backgroundThrottling: false }) });
  if (tcReaderWin.webContents.setAudioMuted) tcReaderWin.webContents.setAudioMuted(true); tcReaderWin.loadURL(BASE + '/tcreader');
  tcReaderWin.webContents.on('render-process-gone', () => { tcReaderWin = null; setTimeout(openTcReader, 2000); });
  tcReaderWin.on('closed', () => { tcReaderWin = null; });
}
function openOutput(outId, displayId, clean) {
  const key = outId; if (outWins.has(key) && !outWins.get(key).win.isDestroyed()) { const e = outWins.get(key); if (!e.offscreen) { e.win.focus(); return; } e.win.destroy(); outWins.delete(key); } // a visible window replaces the NDI-only one
  const d = screen.getAllDisplays().find(x => String(x.id) === String(displayId)) || null;
  const b = d ? d.bounds : { x: 80, y: 80, width: 1280, height: 720 };
  const win = new BrowserWindow({ x: b.x, y: b.y, width: b.width, height: b.height, frame: !d, fullscreen: !!d, kiosk: !!d, backgroundColor: '#000000', title: 'PIXORA Output — ' + outId, icon: path.join(__dirname, 'icon.png'), webPreferences: webPrefs });
  win.pixoraOutput = true; // on air: no update progress bar or dialogs on it
  win.setMenuBarVisibility(false); win.loadURL(`${BASE}/${clean ? 'clean' : 'output'}?out=${encodeURIComponent(outId)}&fs=0`);
  const entry = { win, outId, ndi: null, spout: null }; outWins.set(key, entry);
  win.on('closed', () => { stopSenders(entry); if (outWins.get(key) === entry) outWins.delete(key); buildTray(); nat.build(); ndiOnlyCheck(outId); });
  const conf = cfg.outputs.find(o => o.outId === outId); if (conf && conf.ndi) startNdiSend(entry); if (conf && conf.spout && spout) startSpoutSend(entry); if (conf && conf.decklink) startDecklink(entry);
  buildTray(); nat.build();
}
// NDI-only output: rendered off-screen at the composition size — no display or visible window needed
async function openNdiOnly(outId) {
  if (outWins.has(outId)) return outWins.get(outId);
  const st = await new Promise(res => http.get(BASE + '/api/state', r => { let b = ''; r.on('data', c => b += c); r.on('end', () => { try { res(JSON.parse(b)); } catch { res({}); } }); }).on('error', () => res({})));
  const conf0 = cfg.outputs.find(o => o.outId === outId) || {}, dlm = conf0.decklink && dlModeSize(conf0.decklink);
  const out = (st.outputs || []).find(o => o.id === outId) || {}, W = dlm ? dlm.w : out.w || (st.comp && st.comp.w) || 1920, H = dlm ? dlm.h : out.h || (st.comp && st.comp.h) || 1080;
  const win = new BrowserWindow({ show: false, width: W, height: H, useContentSize: true, title: 'PIXORA NDI — ' + outId, webPreferences: Object.assign({}, webPrefs, { offscreen: true }) });
  win.webContents.setFrameRate(Math.min(60, Math.max(24, +cfg.ndiFps || 60)));
  win.loadURL(`${BASE}/output?out=${encodeURIComponent(outId)}&fs=0&ndi=1`);
  win.webContents.setAudioMuted(true); // its sound goes to NDI only, not to this computer's speakers
  const entry = { win, outId, ndi: null, spout: null, offscreen: true }; outWins.set(outId, entry);
  win.on('closed', () => { stopSenders(entry); if (outWins.get(outId) === entry) outWins.delete(outId); buildTray(); nat.build(); });
  const confN = cfg.outputs.find(o => o.outId === outId) || {}; if (confN.ndi) startNdiSend(entry); if (confN.decklink) startDecklink(entry); buildTray(); nat.build(); return entry;
}
/* ---------------- extra NDI® feeds: multiview, preview (switcher PVW), isolated layers, more program copies — each its own off-screen render + sender */
const FEED_KINDS = { program: 'Program', preview: 'Preview (PVW)', multiview: 'Multiview', layer: 'Layer' };
const feedKey = id => 'feed:' + id;
function feedName(f) { return (String(f.name || '').trim() || ('PIXORA ' + (f.kind === 'layer' ? 'Layer ' + ((+f.layer || 0) + 1) : FEED_KINDS[f.kind] || f.kind))).slice(0, 60); }
function feedUrl(f) {
  const out = encodeURIComponent(f.out || 'main');
  if (f.kind === 'multiview') return `${BASE}/multiview?ndi=1&feed=1`;
  if (f.kind === 'preview') return `${BASE}/clean?out=${out}&fs=0&ndi=1&feed=1&view=preview`;
  if (f.kind === 'layer') return `${BASE}/clean?out=${out}&fs=0&ndi=1&feed=1&view=layer&layer=${+f.layer || 0}`;
  return `${BASE}/clean?out=${out}&fs=0&ndi=1&feed=1`;
}
function feedSize(f) { const m = /^(\d{3,4})x(\d{3,4})$/.exec(String(f.size || '')); return m ? { w: +m[1], h: +m[2] } : { w: 1920, h: 1080 }; }
function normFeed(f, i) {
  const kind = FEED_KINDS[f && f.kind] ? f.kind : 'program';
  return { id: String((f && f.id) || ('f' + Date.now().toString(36) + i)).replace(/[^\w-]/g, '').slice(0, 24) || 'f' + i, kind, name: String((f && f.name) || '').slice(0, 60),
    on: !!(f && f.on), size: feedSize(f).w + 'x' + feedSize(f).h, layer: Math.max(0, Math.min(63, +(f && f.layer) || 0)), out: String((f && f.out) || 'main').slice(0, 40) };
}
function openFeed(f) {
  const key = feedKey(f.id); if (outWins.has(key)) return outWins.get(key);
  const { w, h } = feedSize(f);
  const win = new BrowserWindow({ show: false, width: w, height: h, useContentSize: true, title: 'PIXORA NDI — ' + feedName(f), webPreferences: Object.assign({}, webPrefs, { offscreen: true }) });
  win.webContents.setFrameRate(Math.min(60, Math.max(24, +cfg.ndiFps || 60)));
  win.loadURL(feedUrl(f)); win.webContents.setAudioMuted(true);
  const entry = { win, outId: key, feed: f, ndi: null, spout: null, offscreen: true }; outWins.set(key, entry);
  win.webContents.on('render-process-gone', () => { if (!win.isDestroyed()) win.destroy(); });
  win.on('closed', () => { stopSenders(entry); if (outWins.get(key) === entry) outWins.delete(key);
    const still = (cfg.ndiFeeds || []).find(x => x.id === f.id && x.on); if (still && !app.isQuitting && !entry.removed) setTimeout(() => { if (!outWins.has(key)) openFeed(still); }, 1000); });
  startNdiSend(entry); return entry;
}
function closeFeed(id) { const en = outWins.get(feedKey(id)); if (en) { en.removed = true; stopSenders(en); if (!en.win.isDestroyed()) en.win.destroy(); outWins.delete(feedKey(id)); } }
function syncFeeds() {
  const want = new Map((cfg.ndiFeeds || []).filter(f => f.on).map(f => [f.id, f]));
  for (const [key, en] of [...outWins]) if (en.feed) { const f = want.get(en.feed.id);
    if (!f || JSON.stringify(f) !== JSON.stringify(en.feed)) closeFeed(en.feed.id); } // changed = reopen with the new name / size / view
  if (!ndi.available) return; for (const f of want.values()) if (!outWins.has(feedKey(f.id))) openFeed(f);
}
ipcMain.handle('native-ndi-feeds', (_e, list) => { if (Array.isArray(list)) { cfg.ndiFeeds = list.slice(0, 16).map(normFeed); saveCfg(); syncFeeds(); buildTray(); nat.build(); } return ndiState(); });
function ndiOnlyCheck(outId) { const conf = cfg.outputs.find(o => o.outId === outId); if (conf && ((conf.ndi && conf.ndiOnly) || (conf.decklink && conf.dlOnly)) && !app.isQuitting) setTimeout(() => { if (!outWins.has(outId)) openNdiOnly(outId); }, 500); }

/* ---------------- NDI / Spout senders: capture frames of an Output window */
function onFrame(entry, image) {
  if (!entry.ndi && !entry.spout && !entry.dl) return;
  const { width, height } = image.getSize(); if (!width || !height) return;
  if (entry.dl) { // SDI / HDMI out: frames must match the video mode exactly
    try { const img = width === entry.dl.w && height === entry.dl.h ? image : image.resize({ width: entry.dl.w, height: entry.dl.h, quality: 'good' });
      if (entry.dl.scheduled) { const r = decklink.mod.schedule(entry.dl.handle, img.toBitmap(), entry.dl.w, entry.dl.h); if (r && r.ok) entry.dl.frames++; else entry.dl.dropped++; } // genlock: queued, played on the card's reference clock
      else if (decklink.mod.display(entry.dl.handle, img.toBitmap(), entry.dl.w, entry.dl.h)) entry.dl.frames++; else entry.dl.dropped++; } catch (e) { if (!entry.dl.warned) { entry.dl.warned = true; console.warn('DeckLink out', e.message); } }
    if (!entry.ndi && !entry.spout) return;
  }
  if (entry.ndi && entry.ndiBusy) { entry.ndiDropped = (entry.ndiDropped || 0) + 1; if (!entry.spout) return; } // NDI still compressing: drop, never queue
  const bgra = image.toBitmap(); // raw BGRA, width*4 stride
  if (entry.ndi && !entry.ndiBusy) {
    entry.ndiBusy = true; const fps = Math.min(60, Math.max(24, +cfg.ndiFps || 60));
    entry.ndi.video(bgra, width, height, { fourCC: 'BGRA', frameRateN: fps, frameRateD: 1 })
      .then(ok => { if (ok) { entry.ndiFrames = (entry.ndiFrames || 0) + 1; entry.ndiSize = width + '×' + height; } })
      .catch(e => { if (!entry.ndiWarned) { entry.ndiWarned = true; console.warn('NDI send', e && e.message); } }).finally(() => { entry.ndiBusy = false; });
  }
  if (entry.spout) { try { entry.spout.send(bgra, width, height); } catch (e) { console.warn('Spout', e.message); } }
}
function frameSub(entry) {
  if (entry.sub) return; entry.sub = true;
  if (entry.offscreen) { entry.paint = (_e, _d, image) => onFrame(entry, image); entry.win.webContents.on('paint', entry.paint); }
  else entry.win.webContents.beginFrameSubscription(false, image => onFrame(entry, image));
}
const ndiName = outId => { const c = cfg.outputs.find(o => o.outId === outId) || {}; return (c.ndiName || '').trim() || 'PIXORA ' + outId; };
function startNdiSend(entry) {
  if (!ndi.available) return dialog.showMessageBox({ type: 'warning', message: 'NDI® is not available', detail: ndi.error + '\n\nNDI® is a registered trademark of Vizrt NDI AB — https://ndi.video/', buttons: ['OK', 'Get the NDI Runtime'] }).then(r => { if (r.response === 1) shell.openExternal(ndi.redistUrl); });
  if (entry.ndi) return;
  try { entry.ndi = ndi.sender(entry.feed ? feedName(entry.feed) : ndiName(entry.outId), { groups: cfg.ndiGroups || '' }); entry.ndiFrames = 0; entry.ndiDropped = 0; frameSub(entry); setNdiAudio(entry, true); }
  catch (e) { entry.ndi = null; dialog.showErrorBox('NDI', e.message); }
}
// clip audio from the output window rides along with the NDI video (output.html streams PCM over IPC)
function setNdiAudio(entry, on) { try { if (!entry.win.isDestroyed()) entry.win.webContents.send('native-ndi-audio', { on: on && cfg.ndiAudio !== false }); } catch {} }
ipcMain.on('native-ndi-audio-ready', e => { for (const en of outWins.values()) if (!en.win.isDestroyed() && en.win.webContents === e.sender && en.ndi) setNdiAudio(en, true); });
ipcMain.on('native-ndi-pcm', (e, { data, sampleRate, channels }) => {
  for (const en of outWins.values()) if (en.ndi && !en.win.isDestroyed() && en.win.webContents === e.sender) {
    try { en.ndi.audio(new Float32Array(data.buffer || data, data.byteOffset || 0, (data.byteLength || data.length * 4) / 4), sampleRate || 48000, channels || 2); en.ndiAudioOn = Date.now(); } catch {}
  }
});
function startSpoutSend(entry) {
  if (process.platform !== 'win32' && process.platform !== 'darwin') return dialog.showMessageBox({ message: 'Spout and Syphon are Windows and macOS technologies.', detail: 'On Linux use NDI.' });
  if (!spout && process.platform === 'darwin') return dialog.showMessageBox({ message: 'Syphon via NDI', detail: (texshare.error ? texshare.error + '\n\n' : '') + 'Turn on "Send as NDI" for this output, then use the free NDI → Syphon tool.' });
  if (!spout) return dialog.showMessageBox({ message: 'Spout via NDI', detail: 'Turn on "Send as NDI" for this output, then run the free "NDI to Spout" tool from the Spout download (spout.zeal.co) — it republishes the NDI stream as a Spout sender with no extra latency to speak of on the same machine.\n\nDevelopers can install a native Spout plugin at ' + path.join(app.getPath('userData'), 'plugins', 'spout.js') + ' — see desktop/README.md.' });
  if (entry.spout) return;
  try { const o = cfg.outputs.find(x => x.outId === entry.outId) || {}; entry.spout = spout.create('PIXORA ' + (o.name || entry.outId)); frameSub(entry); } catch (e) { entry.spout = null; dialog.showErrorBox(TS, e.message); }
}
function stopSenders(entry, which) {
  if (!which || which === 'ndi') { if (entry.ndi) setNdiAudio(entry, false); try { entry.ndi && entry.ndi.destroy(); } catch {} entry.ndi = null; }
  if (!which || which === 'spout') { try { entry.spout && entry.spout.close && entry.spout.close(); } catch {} entry.spout = null; }
  if (!which || which === 'decklink') { try { entry.dl && decklink.mod.close(entry.dl.handle); } catch {} entry.dl = null; }
  if (!entry.ndi && !entry.spout && !entry.dl) { try { if (entry.paint) entry.win.webContents.removeListener('paint', entry.paint); else entry.win.webContents.endFrameSubscription(); } catch {} entry.sub = false; entry.paint = null; }
  if (entry.offscreen && !entry.ndi && !entry.dl && (!which || which === 'decklink') && !entry.win.isDestroyed()) entry.win.destroy();
}
/* ---------------- Blackmagic DeckLink: SDI / HDMI output of an Output window, and capture inputs for layers */
function dlModeSize(c) { if (!decklink.available) return null; const d = decklink.devices().find(x => x.index === +c.index); const m = d && d.outputModes.find(x => x.id === c.mode); return m ? { w: m.width, h: m.height } : null; }
function startDecklink(entry) {
  const c = (cfg.outputs.find(o => o.outId === entry.outId) || {}).decklink; if (!c || entry.dl) return;
  if (!decklink.available) return dialog.showMessageBox({ type: 'warning', message: 'DeckLink is not available', detail: decklink.error, buttons: ['OK', 'Get Desktop Video'] }).then(r => { if (r.response === 1) shell.openExternal(decklink.driverUrl); });
  try { const o = decklink.mod.openOutput(+c.index, c.mode || '1080p50'); entry.dl = { handle: o.handle, w: o.width, h: o.height, mode: o.mode, frames: 0, dropped: 0 };
    if (c.genlock && decklink.mod.startScheduled) { try { entry.dl.scheduled = decklink.mod.startScheduled(o.handle, c.preroll || 3); } catch (e) { console.warn('DeckLink genlock', e.message); } }
    applyGenlock(entry, c); frameSub(entry); }
  catch (e) { entry.dl = null; dialog.showErrorBox('DeckLink', e.message); }
}
// genlock: the output page renders a little ahead (the frames waiting in the card's queue) and on exact frame boundaries,
// so every machine locked to the same reference shows the same picture on the same frame
function applyGenlock(entry, c) {
  const st = entry.dl && entry.dl.scheduled && decklink.mod.status ? decklink.mod.status(entry.dl.handle) : null;
  const g = st ? { fps: st.fps, lead: ((c.preroll || 3) + 1) / st.fps * 1000 } : null;
  try { entry.win.webContents.executeJavaScript(`window.PXGenlock = ${JSON.stringify(g)};`).catch(() => {}); } catch {}
}
setInterval(() => { // reference status → controller panel and the server's Health page
  const list = [];
  for (const en of outWins.values()) { if (!en.dl || !decklink.mod.status) continue; try { en.dl.status = decklink.mod.status(en.dl.handle); } catch {} if (en.dl.scheduled) list.push({ outId: en.outId, locked: !!(en.dl.status && en.dl.status.referenceLocked), reference: en.dl.status && en.dl.status.reference || '', late: en.dl.status ? en.dl.status.late + en.dl.status.dropped : 0, underruns: en.dl.status ? en.dl.status.underruns : 0, mode: en.dl.mode }); }
  const sig = JSON.stringify(list); if (sig === applyGenlock.last && Date.now() - (applyGenlock.at || 0) < 10000) return; applyGenlock.last = sig; applyGenlock.at = Date.now();
  if (list.length || applyGenlock.had) { applyGenlock.had = list.length > 0; fetch(BASE + '/api/native/genlock', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ outputs: list }) }).catch(() => {}); }
}, 1000);
const dlInputs = new Map(); // device index → { handle, owners: Map(nativeId → webContents), timer }
const tsInputs = new Map(); // Spout / Syphon receivers shared by every layer using the same sender
ipcMain.handle('native-texshare-list', () => ({ kind: texshare.kind, available: texshare.available, error: texshare.error, senders: texshare.senders() }));
ipcMain.on('native-open-texshare', (e, { name }) => {
  const id = natId++, owner = e.sender; e.returnValue = id; const key = String(name || '');
  if (!texshare.available) { setTimeout(() => { if (!owner.isDestroyed()) owner.send('native-status', { id, error: texshare.error }); }, 50); return; }
  let inp = tsInputs.get(key);
  if (!inp) { try { inp = { handle: texshare.mod.openReceiver(key), owners: new Map() }; } catch (er) { setTimeout(() => { if (!owner.isDestroyed()) owner.send('native-status', { id, error: er.message }); }, 50); return; }
    inp.timer = setInterval(() => { let f = null; try { f = texshare.mod.receive(inp.handle); } catch {} if (!f) return;
      for (const [nid, wc] of inp.owners) { if (wc.isDestroyed()) { inp.owners.delete(nid); continue; } wc.send('native-frame', { id: nid, width: f.width, height: f.height, stride: f.width * 4, fmt: 'bgra', data: f.data }); } }, 8);
    tsInputs.set(key, inp); }
  inp.owners.set(id, owner);
  natives.set(id, { close: () => { inp.owners.delete(id); if (!inp.owners.size) { clearInterval(inp.timer); try { texshare.mod.close(inp.handle); } catch {} tsInputs.delete(key); } } });
});
ipcMain.on('native-open-decklink', (e, { index }) => {
  const id = natId++, owner = e.sender; e.returnValue = id; const ix = +index || 0;
  if (!decklink.available) { setTimeout(() => { if (!owner.isDestroyed()) owner.send('native-status', { id, error: decklink.error }); }, 50); return; }
  let inp = dlInputs.get(ix);
  if (!inp) { try { inp = { handle: decklink.mod.openInput(ix), owners: new Map() }; } catch (er) { setTimeout(() => { if (!owner.isDestroyed()) owner.send('native-status', { id, error: er.message }); }, 50); return; }
    inp.timer = setInterval(() => { const f = decklink.mod.capture(inp.handle); if (!f) return; inp.mode = f.mode; inp.frames = f.frames;
      for (const [nid, wc] of inp.owners) { if (wc.isDestroyed()) { inp.owners.delete(nid); continue; } wc.send('native-frame', { id: nid, width: f.width, height: f.height, stride: f.width * 4, fmt: 'bgra', data: f.data }); } }, 4);
    dlInputs.set(ix, inp); }
  inp.owners.set(id, owner);
  natives.set(id, { close: () => { inp.owners.delete(id); if (!inp.owners.size) { clearInterval(inp.timer); try { decklink.mod.close(inp.handle); } catch {} dlInputs.delete(ix); } } });
});
// ---- automatic updates from GitHub Releases (desktop/updater.js)
const { Updater } = require('./updater.js');
const updater = new Updater({
  isBusy: async () => [...outWins.values()].some(e => e && e.win && !e.win.isDestroyed() && (e.offscreen || e.win.isVisible())), // outputs (incl. NDI/DeckLink-only) on air
  onState: v => { if (controller && !controller.isDestroyed()) controller.webContents.send('native-update', v); },
});
ipcMain.handle('native-update-state', () => updater.view());
ipcMain.handle('native-update-check', () => updater.check({ manual: true }));
ipcMain.handle('native-update-auto', (e, on) => { updater.setCfg({ auto: !!on }); if (on) updater.check(); return updater.view(); });
ipcMain.handle('native-update-install', () => { if (updater.pending) updater.promptInstall(); return updater.view(); });
ipcMain.handle('native-decklink-state', () => ({ available: decklink.available, error: decklink.error, driverUrl: decklink.driverUrl, devices: decklink.devices(),
  outputs: Object.fromEntries(cfg.outputs.filter(o => o.decklink).map(o => { const en = outWins.get(o.outId); return [o.outId, Object.assign({}, o.decklink, { only: !!o.dlOnly, running: !!(en && en.dl), frames: en && en.dl ? en.dl.frames : 0, dropped: en && en.dl ? en.dl.dropped : 0, scheduled: !!(en && en.dl && en.dl.scheduled), status: en && en.dl ? en.dl.status || null : null })]; })),
  inputs: [...dlInputs.entries()].map(([ix, i]) => ({ index: ix, mode: i.mode || '', frames: i.frames || 0 })) }));
ipcMain.handle('native-decklink-set', async (_e, { outId, decklink: c, only }) => {
  const patch = {}; if (c !== undefined) patch.decklink = c && c.index != null ? { index: +c.index, mode: String(c.mode || '1080p50'), genlock: !!c.genlock, preroll: Math.max(2, Math.min(8, +c.preroll || 3)) } : null; if (only !== undefined) patch.dlOnly = !!only;
  setOutCfg(outId, patch); const conf = cfg.outputs.find(o => o.outId === outId); let en = outWins.get(outId);
  if (en && en.dl) stopSenders(en, 'decklink'); en = outWins.get(outId);
  if (conf.decklink) { if (en && !en.win.isDestroyed()) startDecklink(en); else if (conf.dlOnly) await openNdiOnly(outId); }
  return true;
});
/* ---------------- NDI control for the controller (Output tab ▸ NDI) */
function ndiState() {
  const outs = {};
  for (const c of cfg.outputs) outs[c.outId] = { ndi: !!c.ndi, ndiOnly: !!c.ndiOnly, name: ndiName(c.outId) };
  for (const [id, en] of outWins) if (!en.feed) outs[id] = Object.assign(outs[id] || { name: ndiName(id) }, { window: !en.offscreen, offscreen: !!en.offscreen, sending: !!en.ndi,
    receivers: en.ndi ? en.ndi.connections() : 0, tally: en.ndi ? en.ndi.tally(0) : null, frames: en.ndiFrames || 0, dropped: en.ndiDropped || 0, size: en.ndiSize || '', audio: !!(en.ndiAudioOn && Date.now() - en.ndiAudioOn < 2000) });
  return { available: ndi.available, error: ndi.error, version: ndi.version, path: ndi.path, redistUrl: ndi.redistUrl, info: ndi.info, trademark: ndi.trademark,
    extraIps: cfg.ndiExtraIps || '', groups: cfg.ndiGroups || '', fps: +cfg.ndiFps || 60, audio: cfg.ndiAudio !== false, inAudio: cfg.ndiInAudio !== false, outputs: outs,
    feeds: (cfg.ndiFeeds || []).map(f => { const en = outWins.get(feedKey(f.id)); return Object.assign({}, f, { ndiName: feedName(f), sending: !!(en && en.ndi), receivers: en && en.ndi ? en.ndi.connections() : 0,
      frames: en ? en.ndiFrames || 0 : 0, dropped: en ? en.ndiDropped || 0 : 0, size: en ? en.ndiSize || '' : '', audio: !!(en && en.ndiAudioOn && Date.now() - en.ndiAudioOn < 2000) }); }), kinds: FEED_KINDS,
    receivers: [...rxById.values()].filter(x => x.rx).map(x => ({ name: x.name, tally: x.tally || null })) };
}
ipcMain.handle('native-ndi-state', () => ndiState());
ipcMain.handle('native-ndi-set', async (_e, p = {}) => {
  if (p.outId) {
    const prevName = ndiName(p.outId), patch = {};
    for (const k of ['ndi', 'ndiOnly']) if (k in p) patch[k] = !!p[k];
    if ('name' in p) patch.ndiName = String(p.name || '').slice(0, 60);
    setOutCfg(p.outId, patch); const conf = cfg.outputs.find(o => o.outId === p.outId);
    let en = outWins.get(p.outId);
    if (en && en.ndi && 'name' in p && ndiName(p.outId) !== prevName) { stopSenders(en, 'ndi'); en = outWins.get(p.outId); } // rename = new sender
    if (conf.ndi) { if (en && !en.win.isDestroyed()) startNdiSend(en); else if (conf.ndiOnly) await openNdiOnly(p.outId); }
    else if (en) { if (en.offscreen) stopSenders(en); else stopSenders(en, 'ndi'); }
    if (conf.ndi && !conf.ndiOnly && en && en.offscreen) stopSenders(en); // NDI-only turned off and no window: stop
  } else {
    if ('extraIps' in p) cfg.ndiExtraIps = String(p.extraIps || '').replace(/\s+/g, '');
    if ('groups' in p) cfg.ndiGroups = String(p.groups || '').replace(/\s+/g, '');
    if ('fps' in p) cfg.ndiFps = Math.min(60, Math.max(24, +p.fps || 60));
    if ('inAudio' in p) cfg.ndiInAudio = !!p.inAudio;
    if ('audio' in p) { cfg.ndiAudio = !!p.audio; for (const en of outWins.values()) if (en.ndi) setNdiAudio(en, true); }
    saveCfg();
    for (const en of outWins.values()) if (en.offscreen) en.win.webContents.setFrameRate(+cfg.ndiFps || 60);
  }
  buildTray(); nat.build(); return ndiState();
});
function setOutCfg(outId, patch) { let o = cfg.outputs.find(x => x.outId === outId); if (!o) { o = { outId }; cfg.outputs.push(o); } Object.assign(o, patch); saveCfg(); }

/* ---------------- native sources for the renderer: off-screen web pages and NDI receive */
const natives = new Map(); let natId = 1;
ipcMain.on('native-open-web', (e, { url, w, h }) => {
  const id = natId++; const owner = e.sender;
  const win = new BrowserWindow({ show: false, width: Math.max(16, w | 0), height: Math.max(16, h | 0), webPreferences: { offscreen: true, backgroundThrottling: false } });
  win.webContents.setFrameRate(30); win.loadURL(url);
  win.webContents.on('paint', (_ev, _dirty, image) => { if (owner.isDestroyed()) return; const { width, height } = image.getSize(); owner.send('native-frame', { id, width, height, stride: width * 4, fmt: 'bgra', data: image.toBitmap() }); });
  natives.set(id, { close: () => { if (!win.isDestroyed()) win.destroy(); } }); e.returnValue = id;
});
ipcMain.on('native-open-ndi', (e, { name }) => {
  const id = natId++; const owner = e.sender; e.returnValue = id;
  if (!ndi.available) { setTimeout(() => { if (!owner.isDestroyed()) owner.send('native-status', { id, error: 'NDI unavailable: ' + ndi.error }); }, 50); return; }
  const st = { alive: true, rx: null, name, owner };
  rxById.set(id, st);
  natives.set(id, { close: () => { st.alive = false; rxById.delete(id); try { st.rx && st.rx.destroy && st.rx.destroy(); } catch {} } });
  (async () => {
    try {
      const srcs = await ndiSources(2000); const src = srcs.find(s => s.name === name) || (name ? null : srcs[0]);
      if (!src) { if (!owner.isDestroyed()) owner.send('native-status', { id, error: 'NDI source not found: ' + name }); return; }
      // RGBA from NDI so the renderer uploads without swizzling
      st.rx = ndi.receiver(src, { colorFormat: 'rgba', bandwidth: 'highest', name: 'PIXORA' });
      if (!st.alive) { st.rx.destroy(); return; }
      while (st.alive && !owner.isDestroyed()) {
        const f = await st.rx.capture(1000); // 'none' = no frame this second
        if (f.type === 'closed') break;
        if (!st.alive || owner.isDestroyed() || !f.data) continue;
        if (f.type === 'audio') { if (cfg.ndiInAudio !== false) owner.send('native-audio', { id, data: f.data, sampleRate: f.sampleRate, channels: f.channels }); continue; }
        if (f.type !== 'video') continue;
        owner.send('native-frame', { id, width: f.xres, height: f.yres, stride: f.lineStrideBytes || f.xres * 4, fmt: /^RGB/.test(f.fourCC) ? 'rgba' : 'bgra', data: f.data });
      }
    } catch (er) { console.warn('NDI receive', er.message); }
  })();
});
// NDI receivers by id (tally + PTZ address them); several output windows may each hold one for the same source
const rxById = new Map();
ipcMain.on('native-tally', (_e, { id, program, preview }) => { const st = rxById.get(id); if (st && st.rx) { try { st.rx.setTally(program, preview); st.tally = { program, preview }; } catch {} } });
function ndiPtz(nameOrId, action, a, b) { // first live receiver for that source answers
  const st = typeof nameOrId === 'number' ? rxById.get(nameOrId) : [...rxById.values()].find(x => x.rx && (x.name === nameOrId || (x.name || '').endsWith('(' + nameOrId + ')')));
  if (!st || !st.rx) return { ok: false, error: 'that NDI source is not open in an output (put it on a layer first)' };
  try { return { ok: !!st.rx.ptz(action, a, b) }; } catch (e) { return { ok: false, error: e.message }; }
}
ipcMain.handle('native-ptz', (_e, { source, action, a, b }) => ndiPtz(source, action, a, b));
ipcMain.handle('native-ndi-receivers', () => [...rxById.values()].filter(x => x.rx).map(x => ({ name: x.name, tally: x.tally || null, ptz: (() => { try { return !!x.rx.ptz('supported'); } catch { return false; } })() })));
// Server → desktop bridge (cues, OSC and the HTTP API driving NDI PTZ): long-poll, run, post the result back
async function nativeBridge() {
  while (!app.isQuitting) {
    try {
      const job = await new Promise((res, rej) => { const r = http.request(BASE + '/api/native/poll', { method: 'GET', headers: { 'x-app-token': TOKEN }, timeout: 30000 }, rs => { let b = ''; rs.on('data', c => b += c); rs.on('end', () => { try { res(rs.statusCode === 200 ? JSON.parse(b) : null); } catch { res(null); } }); }); r.on('error', rej); r.on('timeout', () => { r.destroy(); res(null); }); r.end(); });
      if (!job || !job.id) continue;
      let result = { ok: false, error: 'unknown job' };
      if (job.type === 'ptz') result = ndiPtz(job.source, job.action, job.a, job.b);
      else if (job.type === 'receivers') result = { ok: true, receivers: [...rxById.values()].filter(x => x.rx).map(x => x.name) };
      const body = JSON.stringify({ id: job.id, result });
      await new Promise(res => { const r = http.request(BASE + '/api/native/result', { method: 'POST', headers: { 'x-app-token': TOKEN, 'Content-Type': 'application/json' } }, rs => { rs.resume(); rs.on('end', res); }); r.on('error', res); r.end(body); });
    } catch { await new Promise(r => setTimeout(r, 2000)); }
  }
}
ipcMain.on('native-close', (_e, { id }) => { const n = natives.get(id); if (n) n.close(); natives.delete(id); });
ipcMain.handle('native-list-ndi', async () => { try { return (await ndiSources(1500)).map(s => s.name); } catch { return []; } });
ipcMain.handle('native-pick-folder', async (e, { start } = {}) => { const r = await dialog.showOpenDialog(BrowserWindow.fromWebContents(e.sender), { title: 'Save recordings to', buttonLabel: 'Use this folder', defaultPath: start || app.getPath('videos'), properties: ['openDirectory', 'createDirectory'] }); return r.canceled ? '' : r.filePaths[0] || ''; });
ipcMain.on('native-reveal', (_e, { file } = {}) => { if (typeof file === 'string' && file && fs.existsSync(file)) shell.showItemInFolder(file); });
ipcMain.handle('native-displays', () => screen.getAllDisplays().map(d => ({ id: d.id, label: d.label, bounds: d.bounds, primary: d.id === screen.getPrimaryDisplay().id })));

/* ---------------- tray menu */
async function fetchOutputs() { return new Promise(res => http.get(BASE + '/api/state', r => { let b = ''; r.on('data', c => b += c); r.on('end', () => { try { res(JSON.parse(b).outputs || []); } catch { res([{ id: 'main', name: 'Main' }]); } }); }).on('error', () => res([{ id: 'main', name: 'Main' }]))); }
async function buildTray() {
  if (!tray) return; const outs = await fetchOutputs(); const displays = screen.getAllDisplays();
  const outMenus = outs.map(o => { const conf = cfg.outputs.find(x => x.outId === o.id) || {}; const open = outWins.get(o.id);
    return { label: `${o.name}${open ? '  ●' : ''}`, submenu: [
      { label: 'Open in a window', click: () => openOutput(o.id, null) },
      { type: 'separator' },
      ...displays.map((d, i) => ({ label: `Full screen on display ${i + 1} — ${d.bounds.width}×${d.bounds.height}${d.id === screen.getPrimaryDisplay().id ? ' (main)' : ''}`, type: 'radio', checked: String(conf.displayId) === String(d.id),
        click: () => { setOutCfg(o.id, { displayId: d.id, auto: true }); const w = outWins.get(o.id); if (w) w.win.close(); setTimeout(() => openOutput(o.id, d.id), 300); } })),
      { type: 'separator' },
      { label: 'Open automatically at launch', type: 'checkbox', checked: !!conf.auto, click: m => setOutCfg(o.id, { auto: m.checked }) },
      { label: 'Send as NDI®', type: 'checkbox', checked: !!conf.ndi, click: m => { setOutCfg(o.id, { ndi: m.checked }); const w = outWins.get(o.id); if (w) { if (m.checked) startNdiSend(w); else stopSenders(w, w.offscreen ? undefined : 'ndi'); } else if (m.checked && conf.ndiOnly) openNdiOnly(o.id); } },
      { label: 'NDI® only (no window needed)', type: 'checkbox', checked: !!conf.ndiOnly, click: m => { setOutCfg(o.id, { ndiOnly: m.checked, ndi: m.checked ? true : conf.ndi }); if (m.checked && !outWins.has(o.id)) openNdiOnly(o.id); else if (!m.checked) { const w = outWins.get(o.id); if (w && w.offscreen) stopSenders(w); } buildTray(); } },
      { label: spout ? `Send as ${TS}` : `Send as ${TS} (via NDI bridge)…`, type: spout ? 'checkbox' : 'normal', checked: !!conf.spout, enabled: process.platform === 'win32' || process.platform === 'darwin', click: m => { if (!spout) { const w = outWins.get(o.id); return startSpoutSend(w || { outId: o.id }); } setOutCfg(o.id, { spout: m.checked }); const w = outWins.get(o.id); if (w) { if (m.checked) startSpoutSend(w); else stopSenders(w, 'spout'); } } },
      { label: 'Close output', enabled: !!open, click: () => open && open.win.close() }] }; });
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Open PIXORA controller', click: openController },
    { label: 'Outputs', submenu: outMenus.length ? outMenus : [{ label: 'No outputs', enabled: false }] },
    { label: 'Refresh outputs list', click: buildTray },
    { type: 'separator' },
    { label: 'Start at login', type: 'checkbox', checked: cfg.autostart, click: m => { cfg.autostart = m.checked; saveCfg(); app.setLoginItemSettings({ openAtLogin: m.checked }); } },
    { label: 'Keep display awake', type: 'checkbox', checked: cfg.preventSleep, click: m => { cfg.preventSleep = m.checked; saveCfg(); applySleep(); } },
    { label: `NDI®: ${ndi.available ? 'ready (v' + (String(ndi.version).match(/\d+\.\d+\.\d+/) || [''])[0] + ')' : 'runtime not found'} · ${TS}: ${spout ? (spout === texshare ? 'built in' : 'plugin loaded') : (process.platform === 'win32' || process.platform === 'darwin') ? 'via NDI bridge' : 'n/a'}`, enabled: false },
    ...(ndi.available ? [] : [{ label: 'Get the NDI® Runtime…', click: () => shell.openExternal(ndi.redistUrl) }]),
    { label: 'About NDI® — ndi.video', click: () => shell.openExternal('https://ndi.video/') },
    { label: 'Open media folder', click: () => shell.openPath(path.join(app.getPath('videos'), 'PIXORA')) },
    { label: 'Open in web browser', click: () => shell.openExternal(BASE) },
    { type: 'separator' },
    { label: 'Quit PIXORA', click: () => { app.isQuitting = true; app.quit(); } }]));
}
function applySleep() { if (cfg.preventSleep && sleepId == null) sleepId = powerSaveBlocker.start('prevent-display-sleep'); if (!cfg.preventSleep && sleepId != null) { powerSaveBlocker.stop(sleepId); sleepId = null; } }

const nat = require('./native.js')({
  getBase: () => BASE, cfg, saveCfg, updater: () => updater, crash: () => crash, openController, openOutput, outWins, controllerRef: () => controller, fetchOutputs,
  setOutCfg: (id, p) => setOutCfg(id, p), icon: path.join(__dirname, 'icon.png'),
});

app.whenReady().then(async () => {
  if (process.platform === 'darwin' && app.dock) try { app.dock.setIcon(path.join(__dirname, 'icon.png')); } catch {}
  nat.showSplash(); nat.build();
  if (cfg.runServer && !process.env.PORT) { PORT = await nat.freePort(cfg.port || 8080); BASE = `http://localhost:${PORT}`; } // another app on 8080? use the next free port
  startServer(); applySleep();
  tray = new Tray(nativeImage.createFromPath(path.join(__dirname, 'icon.png')).resize({ width: 18, height: 18 })); tray.setToolTip('PIXORA');
  tray.on('click', openController);
  waitForServer(() => {
    if (cfg.openController !== false) openController(); else nat.closeSplash();
    for (const o of cfg.outputs) if (o.auto) openOutput(o.outId, o.displayId);
    for (const o of cfg.outputs) if (((o.ndi && o.ndiOnly) || (o.decklink && o.dlOnly)) && !o.auto) openNdiOnly(o.outId); syncFeeds(); // NDI- / DeckLink-only outputs need no display
    nativeBridge(); openTcReader();
    buildTray(); nat.onReady(); updater.start(); crash.offerPending();
  });
  screen.on('display-added', () => { buildTray(); nat.build(); }); screen.on('display-removed', () => { buildTray(); nat.build(); });
  app.on('activate', openController); // macOS: clicking the dock icon
});
app.on('second-instance', (e, argv) => { openController(); nat.onSecondInstance(argv); });
app.on('window-all-closed', e => { /* keep running in the tray */ });
app.on('before-quit', () => { app.isQuitting = true; for (const e of outWins.values()) stopSenders(e); stopServer(); });
