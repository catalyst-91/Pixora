/* PIXORA desktop app (Electron) — Booth Productions
 * Runs the PIXORA server locally, opens the controller, places Output windows full-screen on chosen displays,
 * keeps the computer awake, can start at login, and adds native features browsers can't do:
 *   • NDI output of any Output window (Spout via the free NDI→Spout bridge, or a Spout plugin)   • NDI input as a clip source
 *   • web pages rendered off-screen as GPU textures (so effects apply to them)
 * native.js adds the application menu, splash, show-file dialogs, file association, notifications and window memory.
 */
const { app, BrowserWindow, Tray, Menu, screen, powerSaveBlocker, ipcMain, nativeImage, dialog, shell } = require('electron');
const path = require('path'), fs = require('fs'), { fork } = require('child_process'), http = require('http');

app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
app.commandLine.appendSwitch('ignore-gpu-blocklist');
app.commandLine.appendSwitch('enable-gpu-rasterization');
if (!app.requestSingleInstanceLock()) app.quit();

let PORT = +process.env.PORT || 8080;
let BASE = `http://localhost:${PORT}`;
const CFG_FILE = path.join(app.getPath('userData'), 'desktop.json');
let cfg = { outputs: [], autostart: false, preventSleep: true, openController: true, runServer: true, recent: [], windows: {} };
try { cfg = Object.assign(cfg, JSON.parse(fs.readFileSync(CFG_FILE, 'utf8'))); } catch {}
const saveCfg = () => { try { fs.mkdirSync(path.dirname(CFG_FILE), { recursive: true }); fs.writeFileSync(CFG_FILE, JSON.stringify(cfg, null, 1)); } catch (e) { console.warn('settings', e.message); } };

let server = null, tray = null, controller = null, sleepId = null; const outWins = new Map();
// NDI: 'grandi' (maintained fork of grandiose; same API family). Older installs with 'grandiose' still load.
let ndi = null; for (const m of ['grandi', 'grandiose']) { try { ndi = require(m); ndi.__name = m; break; } catch {} }
// Spout: Electron has no maintained Spout binding, so PIXORA ships a plugin hook instead of a hard dependency.
// Drop a module at <userData>/plugins/spout.js (or desktop/plugins/spout.js) exporting
//   { create(name) -> { send(bgraBuffer, width, height), close() } }
// Without a plugin, enable "Send as NDI" and use NDI's free "NDI to Spout" tool (Spout's official bridge).
let spout = null;
for (const p of [path.join(app.getPath('userData'), 'plugins', 'spout.js'), path.join(__dirname, 'plugins', 'spout.js')]) { try { if (fs.existsSync(p)) { const m = require(p); if (m && typeof m.create === 'function') { spout = m; break; } } } catch (e) { console.warn('Spout plugin', e.message); } }
// NDI sources: grandi.find() resolves to a Finder (sources()/wait()/destroy()); very old grandiose returned an array.
async function ndiSources(waitMs = 1500) {
  if (!ndi) return [];
  const f = await ndi.find({ showLocalSources: true }, waitMs);
  if (Array.isArray(f)) return f;
  try { if (typeof f.wait === 'function') { try { await f.wait(waitMs); } catch {} } return (f.sources() || []).slice(); } finally { try { f.destroy && f.destroy(); } catch {} }
}

/* ---------------- server */
function startServer() {
  if (!cfg.runServer) return;
  const script = [path.join(process.resourcesPath || '', 'pixora-app', 'server.js'), path.join(__dirname, 'pixora-app', 'server.js'), path.join(__dirname, '..', 'server.js')].find(f => { try { return fs.existsSync(f); } catch { return false; } });
  const data = path.join(app.getPath('userData'), 'data'), media = path.join(app.getPath('videos'), 'PIXORA');
  fs.mkdirSync(media, { recursive: true });
  // ffmpeg bundled with the app (resources/ffmpeg) unless the user points FFMPEG_PATH at their own
  const bundledFf = [path.join(process.resourcesPath || '', 'ffmpeg', process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg'), path.join(__dirname, 'node_modules', 'ffmpeg-static', process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg')].find(f => { try { return fs.statSync(f).size > 1e6; } catch { return false; } });
  if (bundledFf && process.platform !== 'win32') { try { fs.chmodSync(bundledFf, 0o755); } catch {} }
  server = fork(script, [], { env: Object.assign({}, process.env, bundledFf && !process.env.FFMPEG_PATH ? { FFMPEG_PATH: bundledFf } : {}, { PORT: String(PORT), DATA_DIR: process.env.DATA_DIR || data, MEDIA_DIR: process.env.MEDIA_DIR || media, PIXORA_LAUNCHER: '1', PIXORA_APP_TOKEN: nat.TOKEN, PIXORA_NATIVE: app.isPackaged ? process.platform : '' }), stdio: 'inherit' });
  server.on('exit', code => { if (app.isQuitting) return; if (code === 75) { process.env.PIXORA_RESTART_WAIT = '1'; return startServer(); } dialog.showErrorBox('PIXORA', `The PIXORA server stopped (code ${code}). Is port ${PORT} already in use?`); });
}
function waitForServer(cb, tries = 0) { http.get(BASE + '/api/info', r => { r.resume(); cb(); }).on('error', () => tries < 100 ? setTimeout(() => waitForServer(cb, tries + 1), 200) : cb()); }

/* ---------------- windows */
const webPrefs = { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, backgroundThrottling: false };
function openController() {
  if (controller && !controller.isDestroyed()) return controller.focus();
  controller = new BrowserWindow({ width: 1680, height: 1000, minWidth: 1100, minHeight: 680, backgroundColor: '#08080b', title: 'PIXORA', icon: path.join(__dirname, 'icon.png'), show: false, webPreferences: webPrefs });
  nat.restoreBounds('controller', controller); nat.trackBounds('controller', controller);
  controller.once('ready-to-show', () => { controller.show(); nat.closeSplash(); });
  controller.loadURL(BASE + '/');
  const own = nat.guardLinks(controller);
  controller.on('close', () => { if (!app.isQuitting && !cfg.trayHintShown && process.platform !== 'darwin') { cfg.trayHintShown = true; saveCfg(); try { new (require('electron').Notification)({ title: 'PIXORA is still running', body: 'Outputs keep playing. Use the tray icon to reopen the controller, or File ▸ Exit to quit.' }).show(); } catch {} } });
  controller.webContents.setWindowOpenHandler(({ url }) => { if (/\/output|\/clean/.test(url)) { const u = new URL(url); openOutput(u.searchParams.get('out') || 'main', null, u.pathname.startsWith('/clean')); return { action: 'deny' }; } if (own(url)) { const u = new URL(url); nat.openAppWindow(u.pathname + u.search + u.hash, 'PIXORA'); return { action: 'deny' }; } shell.openExternal(url); return { action: 'deny' }; });
}
function openOutput(outId, displayId, clean) {
  const key = outId; if (outWins.has(key) && !outWins.get(key).win.isDestroyed()) { outWins.get(key).win.focus(); return; }
  const d = screen.getAllDisplays().find(x => String(x.id) === String(displayId)) || null;
  const b = d ? d.bounds : { x: 80, y: 80, width: 1280, height: 720 };
  const win = new BrowserWindow({ x: b.x, y: b.y, width: b.width, height: b.height, frame: !d, fullscreen: !!d, kiosk: !!d, backgroundColor: '#000000', title: 'PIXORA Output — ' + outId, icon: path.join(__dirname, 'icon.png'), webPreferences: webPrefs });
  win.setMenuBarVisibility(false); win.loadURL(`${BASE}/${clean ? 'clean' : 'output'}?out=${encodeURIComponent(outId)}&fs=0`);
  const entry = { win, outId, ndi: null, spout: null }; outWins.set(key, entry);
  win.on('closed', () => { stopSenders(entry); outWins.delete(key); buildTray(); nat.build(); });
  const conf = cfg.outputs.find(o => o.outId === outId); if (conf && conf.ndi) startNdiSend(entry); if (conf && conf.spout && spout) startSpoutSend(entry);
  buildTray(); nat.build();
}

/* ---------------- NDI / Spout senders: capture frames of an Output window */
function frameSub(entry) {
  if (entry.sub) return; entry.sub = true;
  entry.win.webContents.beginFrameSubscription(false, image => {
    if (!entry.ndi && !entry.spout) return;
    const { width, height } = image.getSize(); if (!width || !height) return;
    const bgra = image.toBitmap(); // raw BGRA, width*4 stride
    if (entry.ndi && !entry.ndiBusy) { // sender.video() returns a Promise; drop frames rather than queue if NDI is behind
      entry.ndiBusy = true;
      Promise.resolve().then(() => entry.ndi.video({ type: 'video', xres: width, yres: height, frameRateN: 60000, frameRateD: 1001, pictureAspectRatio: width / height,
        frameFormatType: ndi.FORMAT_TYPE_PROGRESSIVE, fourCC: ndi.FOURCC_BGRA, lineStrideBytes: width * 4, data: bgra }))
        .catch(e => { if (!entry.ndiWarned) { entry.ndiWarned = true; console.warn('NDI send', e && e.message); } }).finally(() => { entry.ndiBusy = false; });
    }
    if (entry.spout) { try { entry.spout.send(bgra, width, height); } catch (e) { console.warn('Spout', e.message); } }
  });
}
async function startNdiSend(entry) {
  if (!ndi || !ndi.send) return dialog.showMessageBox({ message: 'NDI output needs the optional NDI module.', detail: 'Install the NDI Runtime from ndi.video, then run "npm install" in the desktop folder (it installs the grandi NDI module) and rebuild PIXORA.' });
  if (entry.ndi) return;
  try { entry.ndi = await ndi.send({ name: 'PIXORA ' + entry.outId, clockVideo: false, clockAudio: false }); frameSub(entry); } catch (e) { entry.ndi = null; dialog.showErrorBox('NDI', e.message); }
}
function startSpoutSend(entry) {
  if (process.platform !== 'win32') return dialog.showMessageBox({ message: 'Spout is a Windows technology.', detail: 'On macOS use NDI, or Syphon via the free NDI→Syphon bridge.' });
  if (!spout) return dialog.showMessageBox({ message: 'Spout via NDI', detail: 'Turn on "Send as NDI" for this output, then run the free "NDI to Spout" tool from the Spout download (spout.zeal.co) — it republishes the NDI stream as a Spout sender with no extra latency to speak of on the same machine.\n\nDevelopers can install a native Spout plugin at ' + path.join(app.getPath('userData'), 'plugins', 'spout.js') + ' — see desktop/README.md.' });
  if (entry.spout) return;
  try { entry.spout = spout.create('PIXORA ' + entry.outId); frameSub(entry); } catch (e) { entry.spout = null; dialog.showErrorBox('Spout', e.message); }
}
function stopSenders(entry, which) {
  if (!which || which === 'ndi') { try { entry.ndi && entry.ndi.destroy && entry.ndi.destroy(); } catch {} entry.ndi = null; }
  if (!which || which === 'spout') { try { entry.spout && entry.spout.close && entry.spout.close(); } catch {} entry.spout = null; }
  if (!entry.ndi && !entry.spout) { try { entry.win.webContents.endFrameSubscription(); } catch {} entry.sub = false; }
}
function setOutCfg(outId, patch) { let o = cfg.outputs.find(x => x.outId === outId); if (!o) { o = { outId }; cfg.outputs.push(o); } Object.assign(o, patch); saveCfg(); }

/* ---------------- native sources for the renderer: off-screen web pages and NDI receive */
const natives = new Map(); let natId = 1;
ipcMain.on('native-open-web', (e, { url, w, h }) => {
  const id = natId++; const owner = e.sender;
  const win = new BrowserWindow({ show: false, width: Math.max(16, w | 0), height: Math.max(16, h | 0), webPreferences: { offscreen: true, backgroundThrottling: false } });
  win.webContents.setFrameRate(30); win.loadURL(url);
  win.webContents.on('paint', (_ev, _dirty, image) => { if (owner.isDestroyed()) return; const { width, height } = image.getSize(); owner.send('native-frame', { id, width, height, stride: width * 4, fmt: 'bgra', data: image.toBitmap() }); });
  natives.set(id, { close: () => { if (!win.isDestroyed()) win.destroy(); } }); e.returnValue = id;
});
ipcMain.on('native-open-ndi', (e, { name }) => {
  const id = natId++; const owner = e.sender; e.returnValue = id;
  if (!ndi) return; const st = { alive: true, rx: null };
  natives.set(id, { close: () => { st.alive = false; try { st.rx && st.rx.destroy && st.rx.destroy(); } catch {} } });
  (async () => {
    try {
      const srcs = await ndiSources(2000); const src = srcs.find(s => s.name === name) || (name ? null : srcs[0]);
      if (!src) { if (!owner.isDestroyed()) owner.send('native-status', { id, error: 'NDI source not found: ' + name }); return; }
      // Ask NDI for RGBA so the renderer can upload without swizzling (falls back to "fastest" = UYVY/BGRA when absent)
      const rgba = ndi.COLOR_FORMAT_RGBX_RGBA !== undefined;
      st.rx = await ndi.receive({ source: src, colorFormat: rgba ? ndi.COLOR_FORMAT_RGBX_RGBA : ndi.COLOR_FORMAT_BGRX_BGRA, bandwidth: ndi.BANDWIDTH_HIGHEST, allowVideoFields: false, name: 'PIXORA' });
      while (st.alive && !owner.isDestroyed()) {
        let f; try { f = await st.rx.video(1000); } catch { continue; } // timeout = no frame this second
        if (!st.alive || owner.isDestroyed() || !f || !f.data) continue;
        const fmt = f.fourCC == null ? (rgba ? 'rgba' : 'bgra') : (f.fourCC === ndi.FOURCC_RGBA || f.fourCC === ndi.FOURCC_RGBX) ? 'rgba' : 'bgra';
        owner.send('native-frame', { id, width: f.xres, height: f.yres, stride: f.lineStrideBytes || f.xres * 4, fmt, data: f.data });
      }
    } catch (er) { console.warn('NDI receive', er.message); }
  })();
});
ipcMain.on('native-close', (_e, { id }) => { const n = natives.get(id); if (n) n.close(); natives.delete(id); });
ipcMain.handle('native-list-ndi', async () => { try { return (await ndiSources(1500)).map(s => s.name); } catch { return []; } });
ipcMain.handle('native-pick-folder', async (e, { start } = {}) => { const r = await dialog.showOpenDialog(BrowserWindow.fromWebContents(e.sender), { title: 'Save recordings to', buttonLabel: 'Use this folder', defaultPath: start || app.getPath('videos'), properties: ['openDirectory', 'createDirectory'] }); return r.canceled ? '' : r.filePaths[0] || ''; });
ipcMain.on('native-reveal', (_e, { file } = {}) => { if (typeof file === 'string' && file && fs.existsSync(file)) shell.showItemInFolder(file); });
ipcMain.handle('native-displays', () => screen.getAllDisplays().map(d => ({ id: d.id, label: d.label, bounds: d.bounds, primary: d.id === screen.getPrimaryDisplay().id })));

/* ---------------- tray menu */
async function fetchOutputs() { return new Promise(res => http.get(BASE + '/api/state', r => { let b = ''; r.on('data', c => b += c); r.on('end', () => { try { res(JSON.parse(b).outputs || []); } catch { res([{ id: 'main', name: 'Main' }]); } }); }).on('error', () => res([{ id: 'main', name: 'Main' }]))); }
async function buildTray() {
  if (!tray) return; const outs = await fetchOutputs(); const displays = screen.getAllDisplays();
  const outMenus = outs.map(o => { const conf = cfg.outputs.find(x => x.outId === o.id) || {}; const open = outWins.get(o.id);
    return { label: `${o.name}${open ? '  ●' : ''}`, submenu: [
      { label: 'Open in a window', click: () => openOutput(o.id, null) },
      { type: 'separator' },
      ...displays.map((d, i) => ({ label: `Full screen on display ${i + 1} — ${d.bounds.width}×${d.bounds.height}${d.id === screen.getPrimaryDisplay().id ? ' (main)' : ''}`, type: 'radio', checked: String(conf.displayId) === String(d.id),
        click: () => { setOutCfg(o.id, { displayId: d.id, auto: true }); const w = outWins.get(o.id); if (w) w.win.close(); setTimeout(() => openOutput(o.id, d.id), 300); } })),
      { type: 'separator' },
      { label: 'Open automatically at launch', type: 'checkbox', checked: !!conf.auto, click: m => setOutCfg(o.id, { auto: m.checked }) },
      { label: 'Send as NDI', type: 'checkbox', checked: !!conf.ndi, click: m => { setOutCfg(o.id, { ndi: m.checked }); const w = outWins.get(o.id); if (w) { if (m.checked) startNdiSend(w); else stopSenders(w, 'ndi'); } } },
      { label: spout ? 'Send as Spout (plugin)' : 'Send as Spout (via NDI bridge)…', type: spout ? 'checkbox' : 'normal', checked: !!conf.spout, enabled: process.platform === 'win32', click: m => { if (!spout) { const w = outWins.get(o.id); return startSpoutSend(w || { outId: o.id }); } setOutCfg(o.id, { spout: m.checked }); const w = outWins.get(o.id); if (w) { if (m.checked) startSpoutSend(w); else stopSenders(w, 'spout'); } } },
      { label: 'Close output', enabled: !!open, click: () => open && open.win.close() }] }; });
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Open PIXORA controller', click: openController },
    { label: 'Outputs', submenu: outMenus.length ? outMenus : [{ label: 'No outputs', enabled: false }] },
    { label: 'Refresh outputs list', click: buildTray },
    { type: 'separator' },
    { label: 'Start at login', type: 'checkbox', checked: cfg.autostart, click: m => { cfg.autostart = m.checked; saveCfg(); app.setLoginItemSettings({ openAtLogin: m.checked }); } },
    { label: 'Keep display awake', type: 'checkbox', checked: cfg.preventSleep, click: m => { cfg.preventSleep = m.checked; saveCfg(); applySleep(); } },
    { label: `NDI: ${ndi ? 'available (' + ndi.__name + ')' : 'module not installed'} · Spout: ${spout ? 'plugin loaded' : process.platform === 'win32' ? 'via NDI bridge' : 'n/a'}`, enabled: false },
    { label: 'Open media folder', click: () => shell.openPath(path.join(app.getPath('videos'), 'PIXORA')) },
    { label: 'Open in web browser', click: () => shell.openExternal(BASE) },
    { type: 'separator' },
    { label: 'Quit PIXORA', click: () => { app.isQuitting = true; app.quit(); } }]));
}
function applySleep() { if (cfg.preventSleep && sleepId == null) sleepId = powerSaveBlocker.start('prevent-display-sleep'); if (!cfg.preventSleep && sleepId != null) { powerSaveBlocker.stop(sleepId); sleepId = null; } }

const nat = require('./native.js')({
  getBase: () => BASE, cfg, saveCfg, openController, openOutput, outWins, controllerRef: () => controller, fetchOutputs,
  setOutCfg: (id, p) => setOutCfg(id, p), icon: path.join(__dirname, 'icon.png'),
});

app.whenReady().then(async () => {
  if (process.platform === 'darwin' && app.dock) try { app.dock.setIcon(path.join(__dirname, 'icon.png')); } catch {}
  nat.showSplash(); nat.build();
  if (cfg.runServer && !process.env.PORT) { PORT = await nat.freePort(cfg.port || 8080); BASE = `http://localhost:${PORT}`; } // another app on 8080? use the next free port
  startServer(); applySleep();
  tray = new Tray(nativeImage.createFromPath(path.join(__dirname, 'icon.png')).resize({ width: 18, height: 18 })); tray.setToolTip('PIXORA');
  tray.on('click', openController);
  waitForServer(() => {
    if (cfg.openController !== false) openController(); else nat.closeSplash();
    for (const o of cfg.outputs) if (o.auto) openOutput(o.outId, o.displayId);
    buildTray(); nat.onReady();
  });
  screen.on('display-added', () => { buildTray(); nat.build(); }); screen.on('display-removed', () => { buildTray(); nat.build(); });
  app.on('activate', openController); // macOS: clicking the dock icon
});
app.on('second-instance', (e, argv) => { openController(); nat.onSecondInstance(argv); });
app.on('window-all-closed', e => { /* keep running in the tray */ });
app.on('before-quit', () => { app.isQuitting = true; for (const e of outWins.values()) stopSenders(e); if (server) server.kill(); });
