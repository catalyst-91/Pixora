// Exposes native features to PIXORA pages running inside the desktop app.
const { contextBridge, ipcRenderer } = require('electron');
const listeners = new Map();
ipcRenderer.on('native-frame', (_e, f) => {
  const cb = listeners.get(f.id); if (!cb) return;
  const src = new Uint8Array(f.data.buffer || f.data, f.data.byteOffset || 0, f.data.byteLength || f.data.length);
  const w = f.width, h = f.height, stride = f.stride || w * 4, out = new Uint8ClampedArray(w * h * 4);
  // Repack to tight rows (NDI may pad lines) and convert BGRA (Chromium bitmaps / NDI BGRA) to RGBA for WebGL
  for (let y = 0; y < h; y++) {
    const so = y * stride, d = y * w * 4;
    if (f.fmt === 'rgba') { out.set(src.subarray(so, so + w * 4), d); for (let i = d + 3; i < d + w * 4; i += 4) out[i] = 255; }
    else for (let x = 0; x < w * 4; x += 4) { out[d + x] = src[so + x + 2]; out[d + x + 1] = src[so + x + 1]; out[d + x + 2] = src[so + x]; out[d + x + 3] = 255; }
  }
  cb(new ImageData(out, w, h));
});
ipcRenderer.on('native-status', (_e, s) => { const cb = statusListeners.get(s.id); if (cb) cb(s); });
const statusListeners = new Map();
contextBridge.exposeInMainWorld('pixoraNative', {
  version: '1.1.0', autoStart: true,
  openWeb: (url, w, h) => ipcRenderer.sendSync('native-open-web', { url, w, h }),
  openNdi: (name) => ipcRenderer.sendSync('native-open-ndi', { name }),
  listNdi: () => ipcRenderer.invoke('native-list-ndi'),
  onFrame: (id, cb) => listeners.set(id, cb),
  onStatus: (id, cb) => statusListeners.set(id, cb),
  close: (id) => { listeners.delete(id); statusListeners.delete(id); ipcRenderer.send('native-close', { id }); },
  displays: () => ipcRenderer.invoke('native-displays'),
});
