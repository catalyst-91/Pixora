// Exposes native features to PIXORA pages running inside the desktop app.
const { contextBridge, ipcRenderer } = require('electron');
const listeners = new Map();
ipcRenderer.on('native-frame', (_e, f) => {
  const cb = listeners.get(f.id); if (!cb) return;
  const src = new Uint8Array(f.data.buffer || f.data, f.data.byteOffset || 0, f.data.byteLength || f.data.length);
  const w = f.width, h = f.height, stride = f.stride || w * 4, out = new Uint8ClampedArray(w * h * 4);
  // Repack to tight rows (NDI may pad lines) and convert BGRA (Chromium bitmaps / NDI BGRA) to RGBA for WebGL
  for (let y = 0; y < h; y++) {
    const so = y * stride, d = y * w * 4;
    if (f.fmt === 'rgba') { out.set(src.subarray(so, so + w * 4), d); for (let i = d + 3; i < d + w * 4; i += 4) out[i] = 255; }
    else for (let x = 0; x < w * 4; x += 4) { out[d + x] = src[so + x + 2]; out[d + x + 1] = src[so + x + 1]; out[d + x + 2] = src[so + x]; out[d + x + 3] = 255; }
  }
  cb(new ImageData(out, w, h));
});
ipcRenderer.on('native-status', (_e, s) => { const cb = statusListeners.get(s.id); if (cb) cb(s); });
const statusListeners = new Map(), audioListeners = new Map();
ipcRenderer.on('native-audio', (_e, a) => { const cb = audioListeners.get(a.id); if (cb) cb({ data: new Float32Array(a.data.buffer || a.data, a.data.byteOffset || 0, (a.data.byteLength || a.data.length * 4) / 4), sampleRate: a.sampleRate, channels: a.channels }); });
let ndiAudioCb = null;
ipcRenderer.on('native-ndi-audio', (_e, m) => { if (ndiAudioCb) ndiAudioCb(!!(m && m.on)); });
contextBridge.exposeInMainWorld('pixoraNative', {
  version: '1.9.0', autoStart: true,
  openWeb: (url, w, h) => ipcRenderer.sendSync('native-open-web', { url, w, h }),
  openNdi: (name) => ipcRenderer.sendSync('native-open-ndi', { name }),
  openDecklink: (index) => ipcRenderer.sendSync('native-open-decklink', { index }),
  openTexShare: (name) => ipcRenderer.sendSync('native-open-texshare', { name }),
  texShareList: () => ipcRenderer.invoke('native-texshare-list'),
  decklinkState: () => ipcRenderer.invoke('native-decklink-state'),
  updateState: () => ipcRenderer.invoke('native-update-state'), updateCheck: () => ipcRenderer.invoke('native-update-check'),
  updateAuto: on => ipcRenderer.invoke('native-update-auto', on), updateInstall: () => ipcRenderer.invoke('native-update-install'),
  onUpdate: fn => ipcRenderer.on('native-update', (e, v) => fn(v)),
  decklinkSet: (patch) => ipcRenderer.invoke('native-decklink-set', patch),
  listNdi: () => ipcRenderer.invoke('native-list-ndi'),
  onFrame: (id, cb) => listeners.set(id, cb),
  onAudio: (id, cb) => audioListeners.set(id, cb),
  setTally: (id, program, preview) => ipcRenderer.send('native-tally', { id, program: !!program, preview: !!preview }),
  ptz: (source, action, a, b) => ipcRenderer.invoke('native-ptz', { source, action, a, b }),
  ndiReceivers: () => ipcRenderer.invoke('native-ndi-receivers'),
  onStatus: (id, cb) => statusListeners.set(id, cb),
  close: (id) => { listeners.delete(id); statusListeners.delete(id); audioListeners.delete(id); ipcRenderer.send('native-close', { id }); },
  displays: () => ipcRenderer.invoke('native-displays'),
  pickFolder: (start) => ipcRenderer.invoke('native-pick-folder', { start }),
  revealFile: (file) => ipcRenderer.send('native-reveal', { file }),
  // NDI®: status/settings for the controller; PCM from the output window for NDI audio
  ndiState: () => ipcRenderer.invoke('native-ndi-state'),
  ndiSet: (patch) => ipcRenderer.invoke('native-ndi-set', patch),
  ndiFeeds: (list) => ipcRenderer.invoke('native-ndi-feeds', list),
  onNdiAudio: (cb) => { ndiAudioCb = cb; ipcRenderer.send('native-ndi-audio-ready'); },
  ndiPcm: (f32, sampleRate, channels) => ipcRenderer.send('native-ndi-pcm', { data: f32, sampleRate, channels }),
  dl10: (bytes, w, h, rowBytes) => ipcRenderer.send('native-dl10', { data: bytes, w, h, rowBytes }), // 10-bit DeckLink frames (v210, packed on the GPU)
});
