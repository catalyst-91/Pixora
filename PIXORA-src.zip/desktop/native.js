/* PIXORA native app layer — Booth Productions
 * Turns the Electron shell into a full desktop application: application menu (File / Edit / View / Show / Outputs /
 * Window / Help), splash screen, automatic free-port selection, native open/save dialogs for show files, add media
 * folders and drives from a folder picker, .pixora file association, in-app windows for the manual and remote (never a
 * browser), remembered window positions, dock menu, and native notifications for show incidents.
 */
const { app, BrowserWindow, Menu, dialog, shell, Notification, screen, nativeImage } = require('electron');
const path = require('path'), fs = require('fs'), http = require('http'), net = require('net'), crypto = require('crypto');

module.exports = function native(ctx) {
  // ctx: { getBase, cfg, saveCfg, openController, openOutput, outWins, controllerRef, fetchOutputs, icon, onPortChosen }
  const TOKEN = crypto.randomBytes(18).toString('hex'); // lets the app's own menu commands talk to its own server even when sign-in is required
  const isMac = process.platform === 'darwin';

  /* ---------- talk to the local server */
  function req(method, p, body, raw) {
    return new Promise((res, rej) => {
      const u = new URL(ctx.getBase() + p); const data = body == null ? null : Buffer.isBuffer(body) ? body : Buffer.from(JSON.stringify(body));
      const r = http.request({ hostname: u.hostname, port: u.port, path: u.pathname + u.search, method, headers: { 'x-app-token': TOKEN, ...(data ? { 'Content-Type': Buffer.isBuffer(body) ? 'application/octet-stream' : 'application/json', 'Content-Length': data.length } : {}) } }, rs => {
        const chunks = []; rs.on('data', c => chunks.push(c)); rs.on('end', () => { const b = Buffer.concat(chunks); if (raw) return res({ status: rs.statusCode, body: b, headers: rs.headers }); let j = {}; try { j = JSON.parse(b.toString() || '{}'); } catch {} rs.statusCode >= 400 ? rej(new Error(j.error || 'HTTP ' + rs.statusCode)) : res(j); });
      }); r.on('error', rej); if (data) r.write(data); r.end();
    });
  }
  const cmd = c => req('POST', '/api/cmd', c);
  const ui = js => { const c = ctx.controllerRef(); if (c && !c.isDestroyed()) { c.show(); c.focus(); c.webContents.executeJavaScript(js).catch(() => {}); } else { ctx.openController(); setTimeout(() => ui(js), 2500); } };
  const tab = t => ui(`window.UI && UI.setRtab(${JSON.stringify(t)})`);
  const err = e => dialog.showErrorBox('PIXORA', String(e && e.message || e));

  /* ---------- free port: 8080 unless something else already has it */
  function freePort(start) {
    return new Promise(res => { const tryP = p => { const s = net.createServer(); s.once('error', () => tryP(p + 1)); s.once('listening', () => s.close(() => res(p))); s.listen(p, '0.0.0.0'); }; tryP(start); });
  }

  /* ---------- splash */
  let splash = null;
  function showSplash() {
    splash = new BrowserWindow({ width: 460, height: 280, frame: false, resizable: false, transparent: false, backgroundColor: '#07060c', center: true, show: false, alwaysOnTop: true, skipTaskbar: true, icon: ctx.icon });
    const logo = [path.join(process.resourcesPath || '', 'pixora-app', 'public', 'pixora-logo.png'), path.join(__dirname, 'pixora-app', 'public', 'pixora-logo.png'), path.join(__dirname, '..', 'public', 'pixora-logo.png')].find(f => { try { return fs.existsSync(f); } catch { return false; } }) || ''; const logoUrl = fs.existsSync(logo) ? 'file://' + logo.replace(/\\/g, '/') : '';
    splash.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(`<html><body style="margin:0;height:100vh;display:grid;place-items:center;background:radial-gradient(500px 300px at 50% 0%,#2a0f4a,transparent 70%),#07060c;color:#bdb8d6;font:13px system-ui;-webkit-app-region:drag">
      <div style="text-align:center">${logoUrl ? `<img src="${logoUrl}" style="width:260px">` : '<div style="font:800 44px system-ui;color:#fff">PIXORA</div>'}
      <div id="m" style="margin-top:18px;letter-spacing:.08em">Starting the video engine…</div>
      <div style="margin:14px auto 0;width:180px;height:3px;background:#1d1a2b;border-radius:3px;overflow:hidden"><div style="width:40%;height:100%;background:linear-gradient(90deg,#ff2fd0,#a828ff,#2fb8ff);animation:s 1.1s infinite ease-in-out"></div></div>
      <div style="margin-top:22px;font-size:10px;letter-spacing:.14em;color:#6d6888">BOOTH PRODUCTIONS · v${app.getVersion()}</div></div>
      <style>@keyframes s{0%{transform:translateX(-120%)}100%{transform:translateX(320%)}}</style></body></html>`));
    splash.once('ready-to-show', () => splash && splash.show());
  }
  function closeSplash() { if (splash && !splash.isDestroyed()) splash.close(); splash = null; }

  /* ---------- show files */
  async function openShow(file) {
    try {
      if (!file) { const r = await dialog.showOpenDialog({ title: 'Open show', filters: [{ name: 'PIXORA show', extensions: ['pixora', 'json'] }], properties: ['openFile'] }); if (r.canceled || !r.filePaths[0]) return; file = r.filePaths[0]; }
      const rep = await req('POST', '/api/show/import', fs.readFileSync(file));
      ctx.cfg.lastShow = file; ctx.cfg.recent = [file, ...(ctx.cfg.recent || []).filter(f => f !== file)].slice(0, 8); ctx.saveCfg(); app.addRecentDocument(file); build();
      const missing = rep.missing && rep.missing.length;
      new Notification({ title: 'Show opened', body: path.basename(file) + (missing ? ` — ${missing} media file(s) missing: see Show ▸ Preflight` : '') }).show();
    } catch (e) { err(e); }
  }
  async function saveShow(as) {
    try {
      let file = !as && ctx.cfg.lastShow;
      if (!file) { const r = await dialog.showSaveDialog({ title: 'Save show as', defaultPath: path.join(app.getPath('documents'), 'PIXORA Show.pixora'), filters: [{ name: 'PIXORA show', extensions: ['pixora'] }] }); if (r.canceled || !r.filePath) return; file = r.filePath; }
      const r = await req('GET', '/api/show/export?name=' + encodeURIComponent(path.basename(file, '.pixora')), null, true); if (r.status !== 200) throw new Error('Could not export the show');
      fs.writeFileSync(file, r.body); ctx.cfg.lastShow = file; ctx.cfg.recent = [file, ...(ctx.cfg.recent || []).filter(f => f !== file)].slice(0, 8); ctx.saveCfg(); app.addRecentDocument(file); build();
      new Notification({ title: 'Show saved', body: file }).show();
    } catch (e) { err(e); }
  }
  async function newShow() {
    const r = await dialog.showMessageBox({ type: 'question', buttons: ['New show', 'Cancel'], defaultId: 0, cancelId: 1, message: 'Start a new, empty show?', detail: 'Unsaved changes to the current show will be lost (it is still in Undo until you quit).' });
    if (r.response !== 0) return; try { await cmd({ op: 'newComp' }); ctx.cfg.lastShow = ''; ctx.saveCfg(); } catch (e) { tab('comp'); }
  }
  async function addMediaFolder() {
    const r = await dialog.showOpenDialog({ title: 'Add a media folder or drive', buttonLabel: 'Add to library', properties: ['openDirectory', 'multiSelections'] }); if (r.canceled) return;
    for (const p of r.filePaths) { try { await req('POST', '/api/sources', { path: p, name: path.basename(p) || p }); } catch (e) { err(e); } }
    tab('library');
  }
  async function exportReport() {
    const day = new Date().toISOString().slice(0, 10);
    const r = await dialog.showSaveDialog({ title: 'Save show report', defaultPath: path.join(app.getPath('documents'), `PIXORA report ${day}.pdf`), filters: [{ name: 'PDF', extensions: ['pdf'] }] }); if (r.canceled) return;
    try { const res = await req('GET', `/api/report?from=${day}&to=${day}`, null, true); fs.writeFileSync(r.filePath, res.body); shell.openPath(r.filePath); } catch (e) { err(e); }
  }

  /* ---------- in-app windows (manual, remote, anything on our own server) */
  const appWins = new Map();
  function openAppWindow(p, title, w = 1200, h = 860) {
    const ex = appWins.get(p); if (ex && !ex.isDestroyed()) return ex.focus();
    const win = new BrowserWindow({ width: w, height: h, title, backgroundColor: '#08080b', icon: ctx.icon, webPreferences: { contextIsolation: true } });
    win.setMenuBarVisibility(false); win.loadURL(ctx.getBase() + p); guardLinks(win); appWins.set(p, win); win.on('closed', () => appWins.delete(p));
  }
  function guardLinks(win) { // our pages stay in the app; everything else goes to the system browser
    const own = u => { try { return new URL(u).origin === new URL(ctx.getBase()).origin; } catch { return false; } };
    win.webContents.on('will-navigate', (e, u) => { if (!own(u) && !/^(data|about):/.test(u)) { e.preventDefault(); shell.openExternal(u); } });
    return own;
  }

  /* ---------- window state */
  function restoreBounds(key, win) {
    const b = (ctx.cfg.windows || {})[key]; if (!b) return;
    const vis = screen.getAllDisplays().some(d => b.x < d.bounds.x + d.bounds.width - 50 && b.x + b.width > d.bounds.x + 50 && b.y < d.bounds.y + d.bounds.height - 50 && b.y + 30 > d.bounds.y);
    if (vis) win.setBounds(b); if (b.max) win.maximize();
  }
  function trackBounds(key, win) {
    const save = () => { if (win.isDestroyed() || win.isFullScreen()) return; ctx.cfg.windows = ctx.cfg.windows || {}; ctx.cfg.windows[key] = { ...(win.isMaximized() ? (ctx.cfg.windows[key] || win.getBounds()) : win.getBounds()), max: win.isMaximized() }; ctx.saveCfg(); };
    let t; const deb = () => { clearTimeout(t); t = setTimeout(save, 400); }; win.on('resize', deb); win.on('move', deb); win.on('close', save);
  }

  /* ---------- notifications for show incidents */
  let lastStats = new Map(), notified = new Set();
  async function pollHealth() {
    try {
      const { list } = await req('GET', '/api/ostats'); const now = new Map(list.map(o => [o.id, o]));
      for (const o of list) {
        if (o.safe && !(lastStats.get(o.id) || {}).safe) notify('safe' + o.id, 'Safe loop engaged', `${o.name}: ${(o.errors || [])[0] || 'clip failed or stalled'}`);
        if (o.glLost) notify('gl' + o.id, 'Graphics reset on ' + o.name, 'The output is recovering automatically.');
      }
      for (const [id, o] of lastStats) if (!now.has(id) && ctx.cfg.notifyDisconnect !== false) notify('gone' + id + Date.now(), 'Output disconnected', `${o.name} closed or lost its connection.`);
      lastStats = now;
    } catch {}
  }
  function notify(key, title, body) { if (notified.has(key) || !Notification.isSupported()) return; notified.add(key); setTimeout(() => notified.delete(key), 60000); new Notification({ title, body, silent: false }).show(); }

  /* ---------- application menu */
  let outputsCache = [];
  async function refreshOutputs() { outputsCache = await ctx.fetchOutputs(); build(); }
  function outputsMenu() {
    const displays = screen.getAllDisplays();
    const items = outputsCache.map(o => { const conf = (ctx.cfg.outputs || []).find(x => x.outId === o.id) || {}; const open = ctx.outWins.get(o.id);
      return { label: `${o.name}${open ? '  ●' : ''}`, submenu: [
        { label: 'Open in a window', click: () => ctx.openOutput(o.id, null) },
        ...displays.map((d, i) => ({ label: `Full screen on display ${i + 1} (${d.bounds.width}×${d.bounds.height}${d.id === screen.getPrimaryDisplay().id ? ', main' : ''})`, click: () => { ctx.setOutCfg(o.id, { displayId: d.id, auto: true }); const w = ctx.outWins.get(o.id); if (w) w.win.close(); setTimeout(() => ctx.openOutput(o.id, d.id), 300); } })),
        { type: 'separator' },
        { label: 'Open automatically at launch', type: 'checkbox', checked: !!conf.auto, click: m => ctx.setOutCfg(o.id, { auto: m.checked }) },
        { label: 'Close', enabled: !!open, click: () => open && open.win.close() }] }; });
    return [...(items.length ? items : [{ label: 'No outputs yet — add one in the Output tab', enabled: false }]), { type: 'separator' },
      { label: 'Open all at their displays', accelerator: 'CmdOrCtrl+Shift+O', click: () => { for (const o of outputsCache) { const c = (ctx.cfg.outputs || []).find(x => x.outId === o.id); ctx.openOutput(o.id, c && c.displayId); } } },
      { label: 'Close all outputs', click: () => { for (const e of ctx.outWins.values()) e.win.close(); } },
      { type: 'separator' },
      { label: 'Start / Stop Recording', accelerator: 'CmdOrCtrl+Shift+R', click: () => req('POST', '/api/rec/toggle').then(r => notify('rec' + Date.now(), r.on ? 'Recording' : 'Recording stopped', r.on ? r.file || '' : 'Finishing the file…')).catch(err) },
      { label: 'Recording Settings…', click: () => tab('output') },
      { label: 'Open Recordings Folder', click: () => req('GET', '/api/rec/formats').then(d => shell.openPath((d.prefs && d.prefs.folder) || d.defaultFolder)).catch(err) },
      { label: 'Identify displays', click: identifyDisplays },
      { label: 'Refresh list', click: refreshOutputs }];
  }
  function identifyDisplays() {
    screen.getAllDisplays().forEach((d, i) => { const w = new BrowserWindow({ x: d.bounds.x + d.bounds.width / 2 - 160, y: d.bounds.y + d.bounds.height / 2 - 110, width: 320, height: 220, frame: false, alwaysOnTop: true, backgroundColor: '#a828ff', skipTaskbar: true, focusable: false });
      w.loadURL('data:text/html,' + encodeURIComponent(`<body style="margin:0;display:grid;place-items:center;height:100vh;font:800 120px system-ui;color:#fff;background:linear-gradient(135deg,#ff2fd0,#a828ff,#2fb8ff)">${i + 1}<div style="position:fixed;bottom:10px;font:600 14px system-ui">${d.bounds.width}×${d.bounds.height}</div></body>`)); setTimeout(() => !w.isDestroyed() && w.close(), 2500); });
  }
  function build() {
    const recent = (ctx.cfg.recent || []).filter(f => { try { return fs.existsSync(f); } catch { return false; } });
    const tpl = [
      ...(isMac ? [{ label: 'PIXORA', submenu: [
        { label: 'About PIXORA', click: about }, { label: 'Check for Updates…', click: () => tab('update') }, { type: 'separator' },
        { label: 'Settings…', accelerator: 'Cmd+,', click: () => tab('comp') }, { type: 'separator' }, { role: 'services' }, { type: 'separator' },
        { role: 'hide' }, { role: 'hideOthers' }, { role: 'unhide' }, { type: 'separator' }, { label: 'Quit PIXORA', accelerator: 'Cmd+Q', click: () => { app.isQuitting = true; app.quit(); } }] }] : []),
      { label: 'File', submenu: [
        { label: 'New Show', accelerator: 'CmdOrCtrl+N', click: newShow },
        { label: 'Open Show…', accelerator: 'CmdOrCtrl+O', click: () => openShow() },
        { label: 'Open Recent', submenu: recent.length ? [...recent.map(f => ({ label: path.basename(f), click: () => openShow(f) })), { type: 'separator' }, { label: 'Clear Menu', click: () => { ctx.cfg.recent = []; ctx.saveCfg(); app.clearRecentDocuments(); build(); } }] : [{ label: 'No recent shows', enabled: false }] },
        { type: 'separator' },
        { label: 'Save Show', accelerator: 'CmdOrCtrl+S', click: () => saveShow(false) },
        { label: 'Save Show As…', accelerator: 'CmdOrCtrl+Shift+S', click: () => saveShow(true) },
        { type: 'separator' },
        { label: 'Add Media Folder or Drive…', accelerator: 'CmdOrCtrl+Shift+A', click: addMediaFolder },
        { label: 'Show Media Folder', click: () => shell.openPath(path.join(app.getPath('videos'), 'PIXORA')) },
        { label: 'Import Stage (MVR)…', click: () => tab('console') },
        { label: 'Export Show Report (PDF)…', click: exportReport },
        ...(isMac ? [] : [{ type: 'separator' }, { label: 'Settings', accelerator: 'Ctrl+,', click: () => tab('comp') }, { type: 'separator' }, { label: 'Exit', click: () => { app.isQuitting = true; app.quit(); } }])] },
      { label: 'Edit', submenu: [
        // the controller handles Ctrl/Cmd+Z itself (text fields keep their own undo), so the shortcut isn't captured here
        { label: 'Undo', accelerator: 'CmdOrCtrl+Z', registerAccelerator: false, click: () => cmd({ op: 'undo' }).catch(() => {}) },
        { label: 'Redo', accelerator: isMac ? 'Cmd+Shift+Z' : 'Ctrl+Y', registerAccelerator: false, click: () => cmd({ op: 'redo' }).catch(() => {}) },
        { type: 'separator' }, { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' }] },
      { label: 'View', submenu: [
        { label: 'Controller', accelerator: 'CmdOrCtrl+1', click: ctx.openController },
                { label: 'Phone Remote (preview)', click: () => openAppWindow('/remote', 'PIXORA Remote', 420, 860) },
        { label: '3D Stage', click: () => tab('stage') },
        { type: 'separator' }, { role: 'resetZoom' }, { role: 'zoomIn' }, { role: 'zoomOut' }, { type: 'separator' }, { role: 'togglefullscreen' },
        { type: 'separator' }, { label: 'Reload Controller', accelerator: 'CmdOrCtrl+R', click: () => { const c = ctx.controllerRef(); c && !c.isDestroyed() && c.reload(); } },
        { label: 'Developer Tools', accelerator: isMac ? 'Alt+Cmd+I' : 'Ctrl+Shift+I', click: (m, w) => w && w.webContents.toggleDevTools() }] },
      { label: 'Show', submenu: [
        { label: 'Blackout', accelerator: 'Shift+B', registerAccelerator: false, click: () => cmd({ op: 'blackout' }).catch(err) },
        { label: 'Cue GO', accelerator: 'Space', registerAccelerator: false, click: () => cmd({ op: 'cueGo' }).catch(err) },
        { type: 'separator' },
        { label: 'Lock Show', accelerator: 'CmdOrCtrl+L', click: () => cmd({ op: 'lockShow' }).then(() => notify('lock' + Date.now(), 'Show locked', 'Playback still works; setup changes are blocked.')).catch(err) },
        { label: 'Unlock Show…', click: () => tab('show') },
        { label: 'Engage Safe Loop', accelerator: 'CmdOrCtrl+Shift+E', click: () => cmd({ op: 'safeLoop', on: true }).catch(err) },
        { label: 'Release Safe Loop', click: () => cmd({ op: 'safeLoop', on: false }).catch(err) },
        { type: 'separator' },
        { label: 'Content Preflight', click: () => tab('preflight') }, { label: 'Output Health', click: () => tab('show') }, { label: 'Timecode', click: () => tab('tc') },
        { label: 'Users & Remote Access', click: () => tab('access') }] },
      { label: 'Outputs', submenu: outputsMenu() },
      { label: 'Window', submenu: [{ role: 'minimize' }, ...(isMac ? [{ role: 'zoom' }, { type: 'separator' }, { role: 'front' }] : [{ role: 'close' }])] },
      { role: 'help', label: 'Help', submenu: [
        { label: 'PIXORA User Manual', accelerator: 'F1', click: () => openAppWindow('/manual/', 'PIXORA Manual') },
        { label: 'Keyboard Shortcuts', click: () => openAppWindow('/manual/#keys', 'PIXORA Manual') },
        { label: 'Open Log Folder', click: () => shell.openPath(app.getPath('userData')) },
        { type: 'separator' }, { label: 'Booth Productions Website', click: () => shell.openExternal('https://booth-productions.com') },
        ...(isMac ? [] : [{ type: 'separator' }, { label: 'About PIXORA', click: about }])] },
    ];
    Menu.setApplicationMenu(Menu.buildFromTemplate(tpl));
    if (isMac && app.dock) app.dock.setMenu(Menu.buildFromTemplate([{ label: 'Controller', click: ctx.openController }, { label: 'Open all outputs', click: () => { for (const o of outputsCache) { const c = (ctx.cfg.outputs || []).find(x => x.outId === o.id); ctx.openOutput(o.id, c && c.displayId); } } }, { label: 'Lock Show', click: () => cmd({ op: 'lockShow' }).catch(err) }]));
  }
  function about() {
    dialog.showMessageBox({ title: 'About PIXORA', message: `PIXORA ${app.getVersion()}`, buttons: ['OK', 'Licences…', 'ndi.video'], defaultId: 0,
      detail: `Real-time video, LED mapping and show control.\n© Booth Productions. All rights reserved.\n\nThis product uses NDI® technology. NDI® is a registered trademark of Vizrt NDI AB (https://ndi.video/). The NDI runtime is © Vizrt NDI AB.\nIncludes FFmpeg (https://ffmpeg.org/), licensed under the GPL.\n\nElectron ${process.versions.electron} · Chromium ${process.versions.chrome} · Node ${process.versions.node}\nServer: ${ctx.getBase()}`,
      icon: ctx.icon ? nativeImage.createFromPath(ctx.icon) : undefined })
      .then(r => { if (r.response === 1) { const f = [path.join(process.resourcesPath || '', 'EULA.txt'), path.join(__dirname, 'build', 'EULA.txt')].find(x => { try { return require('fs').existsSync(x); } catch { return false; } }); if (f) shell.openPath(f); } else if (r.response === 2) shell.openExternal('https://ndi.video/'); });
  }

  /* ---------- .pixora file association */
  const pending = [];
  app.on('open-file', (e, f) => { e.preventDefault(); if (ready) openShow(f); else pending.push(f); }); // macOS
  const argShow = argv => argv.find(a => /\.pixora$/i.test(a));
  let ready = false;
  function onReady() {
    ready = true; refreshOutputs(); setInterval(refreshOutputs, 15000); setInterval(pollHealth, 3000);
    const f = pending.shift() || argShow(process.argv); if (f) openShow(f);
  }
  function onSecondInstance(argv) { const f = argShow(argv); if (f) openShow(f); }

  return { TOKEN, freePort, showSplash, closeSplash, build, onReady, onSecondInstance, guardLinks, restoreBounds, trackBounds, openAppWindow, openShow, saveShow, req };
};
