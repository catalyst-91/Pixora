// PIXORA — Blackmagic DeckLink / UltraStudio: loads PIXORA's DeckLink module (native/decklink).
// The Blackmagic Desktop Video driver must be installed for devices to appear; without it everything reports "unavailable".
'use strict';
const path = require('path'), fs = require('fs');
const exists = f => { try { return fs.statSync(f).isFile(); } catch { return false; } };
function open({ resourcesPath } = {}) {
  const tag = `${process.platform}-${process.arch}`, api = { available: false, error: '', devices: () => [], driverUrl: 'https://www.blackmagicdesign.com/support/family/capture-and-playback' };
  const paths = [process.env.PIXORA_DECKLINK_ADDON, resourcesPath && path.join(resourcesPath, 'decklink', `pixora_decklink-${tag}.node`),
    path.join(__dirname, 'native', 'decklink', 'build', 'Release', 'pixora_decklink.node'), path.join(__dirname, 'native', 'decklink', `pixora_decklink-${tag}.node`)].filter(Boolean);
  let mod = null; for (const p of paths) { if (!exists(p)) continue; try { mod = require(p); break; } catch (e) { api.error = 'DeckLink module failed to load: ' + e.message; } }
  if (!mod) { api.error = api.error || 'DeckLink support is not included in this build'; return api; }
  api.mod = mod;
  api.available = (() => { try { return mod.available(); } catch { return false; } })();
  if (!api.available) api.error = 'Blackmagic Desktop Video is not installed (needed for DeckLink / UltraStudio devices)';
  api.devices = () => { try { return mod.devices().map(d => Object.assign(d, { outputModes: d.output ? mod.modes(d.index, 'output') : [] })); } catch { return []; } };
  return api;
}
module.exports = { open };
