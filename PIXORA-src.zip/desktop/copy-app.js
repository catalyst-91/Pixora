// Copies the PIXORA server + web app into ./pixora-app so electron-builder can bundle it.
const fs = require('fs'), path = require('path');
const src = path.join(__dirname, '..'), dst = path.join(__dirname, 'pixora-app');
fs.rmSync(dst, { recursive: true, force: true }); fs.mkdirSync(dst, { recursive: true });
for (const f of ['server.js', 'server-pro3.js', 'package.json']) fs.copyFileSync(path.join(src, f), path.join(dst, f));
fs.cpSync(path.join(src, 'public'), path.join(dst, 'public'), { recursive: true });
fs.copyFileSync(path.join(src, 'public', 'pixora-icon.png'), path.join(__dirname, 'icon.png'));
console.log('PIXORA app copied into desktop/pixora-app');
