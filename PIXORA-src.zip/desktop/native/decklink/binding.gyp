{
  "targets": [{
    "target_name": "pixora_decklink",
    "defines": ["NAPI_VERSION=8"],
    "conditions": [
      ["OS=='linux'", { "sources": ["pixora_decklink.cpp", "include/linux/DeckLinkAPIDispatch.cpp"], "include_dirs": ["include/linux"],
        "libraries": ["-ldl", "-lpthread"], "cflags_cc": ["-O2", "-std=c++17", "-Wno-deprecated-declarations"] }],
      ["OS=='mac'", { "sources": ["pixora_decklink.cpp", "include/mac/DeckLinkAPIDispatch.cpp"], "include_dirs": ["include/mac"],
        "libraries": ["-framework CoreFoundation"],
        "xcode_settings": { "MACOSX_DEPLOYMENT_TARGET": "11.0", "CLANG_CXX_LANGUAGE_STANDARD": "c++17", "OTHER_CPLUSPLUSFLAGS": ["-O2", "-Wno-deprecated-declarations"] } }]
    ]
  }]
}
