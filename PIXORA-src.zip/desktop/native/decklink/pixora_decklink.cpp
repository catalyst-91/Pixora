// PIXORA — Blackmagic DeckLink / UltraStudio capture and playout (N-API). Booth Productions.
// Built against the Blackmagic DeckLink SDK include files (redistributable under their own licence, kept in ./include).
// The DeckLink driver (Desktop Video) is loaded at run time: without it, devices() returns [] and nothing else happens.
//
//   devices()                                → [{ index, name, model, input, output }]
//   modes(index, 'input'|'output')            → [{ id, name, width, height, fps }]
//   openInput(index)                          → handle      (format detection on; 8-bit YUV converted to BGRA)
//   capture(handle)                           → { width, height, data:Buffer(BGRA), mode, frames } | null when no new frame
//   openOutput(index, modeName)               → handle      (e.g. '1080p50', '2160p25', '1080i59.94')
//   display(handle, Buffer BGRA, w, h)        → true        (synchronous display, scaled frames are rejected)
//   close(handle)
#if defined(_WIN32) && !defined(NOMINMAX)
#define NOMINMAX // windows.h must not define min / max macros
#endif
#include <node_api.h>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <mutex>
#include <vector>
#include <string>
#include <map>
#include <cmath>
#include <algorithm>
#ifdef _WIN32
  #include <windows.h>
  #include "DeckLinkAPI_h.h" // generated from include/win/DeckLinkAPI.idl by MIDL at build time
  typedef BSTR dlstring_t;
  static std::string dlstr(dlstring_t s) { if (!s) return ""; int n = WideCharToMultiByte(CP_UTF8, 0, s, -1, nullptr, 0, nullptr, nullptr); std::string r(n > 0 ? n - 1 : 0, '\0'); if (n > 1) WideCharToMultiByte(CP_UTF8, 0, s, -1, &r[0], n, nullptr, nullptr); SysFreeString(s); return r; }
#elif defined(__APPLE__)
  #include <CoreFoundation/CoreFoundation.h>
  #include "DeckLinkAPI.h"
  typedef CFStringRef dlstring_t;
  static std::string dlstr(dlstring_t s) { if (!s) return ""; char buf[512] = {0}; CFStringGetCString(s, buf, sizeof buf, kCFStringEncodingUTF8); CFRelease(s); return buf; }
#else
  #include "DeckLinkAPI.h"
  typedef const char* dlstring_t;
  static std::string dlstr(dlstring_t s) { if (!s) return ""; std::string r(s); free((void*)s); return r; }
#endif

static bool sameIID(const void* a, const void* b) { return memcmp(a, b, 16) == 0; }

static IDeckLinkIterator* makeIterator() {
#ifdef _WIN32
  static bool com = false; if (!com) { CoInitializeEx(nullptr, COINIT_MULTITHREADED); com = true; }
  IDeckLinkIterator* it = nullptr;
  if (CoCreateInstance(CLSID_CDeckLinkIterator, nullptr, CLSCTX_ALL, IID_IDeckLinkIterator, (void**)&it) != S_OK) return nullptr;
  return it;
#else
  return CreateDeckLinkIteratorInstance(); // DeckLinkAPIDispatch.cpp: dlopen()s the driver library, nullptr if absent
#endif
}
static IDeckLink* deviceAt(int index) {
  IDeckLinkIterator* it = makeIterator(); if (!it) return nullptr;
  IDeckLink* dl = nullptr; int i = 0; IDeckLink* found = nullptr;
  while (it->Next(&dl) == S_OK) { if (i++ == index) { found = dl; break; } dl->Release(); }
  it->Release(); return found;
}
static double modeFps(IDeckLinkDisplayMode* m) { BMDTimeValue d = 0; BMDTimeScale s = 0; m->GetFrameRate(&d, &s); return d ? (double)s / (double)d : 0; }
static std::string modeName(IDeckLinkDisplayMode* m) { dlstring_t n = nullptr; m->GetName(&n); return dlstr(n); }
// '1080p50' style label used by PIXORA
static std::string modeLabel(IDeckLinkDisplayMode* m) {
  char b[64]; double f = modeFps(m); bool inter = m->GetFieldDominance() == bmdLowerFieldFirst || m->GetFieldDominance() == bmdUpperFieldFirst;
  double shown = inter ? f * 2 : f; char fs[16]; if (std::fabs(shown - std::round(shown)) < 0.005) snprintf(fs, sizeof fs, "%d", (int)std::round(shown)); else snprintf(fs, sizeof fs, "%.2f", shown);
  snprintf(b, sizeof b, "%ld%c%s", (long)m->GetHeight(), inter ? 'i' : 'p', fs); return b;
}

/* ---------------- capture */
static inline uint8_t clamp8(int v) { return v < 0 ? 0 : v > 255 ? 255 : (uint8_t)v; }
static void uyvyToBgra(const uint8_t* src, int rowBytes, int w, int h, uint8_t* dst, bool hd) {
  // BT.709 for HD/UHD, BT.601 for SD; video range in, full range out
  const int cr_r = hd ? 459 : 409, cb_g = hd ? 55 : 100, cr_g = hd ? 136 : 208, cb_b = hd ? 541 : 516;
  for (int y = 0; y < h; y++) {
    const uint8_t* s = src + (size_t)y * rowBytes; uint8_t* d = dst + (size_t)y * w * 4;
    for (int x = 0; x < w; x += 2, s += 4, d += 8) {
      int u = s[0] - 128, y0 = (s[1] - 16) * 298, v = s[2] - 128, y1 = (s[3] - 16) * 298;
      int r = cr_r * v, g = -cb_g * u - cr_g * v, b = cb_b * u;
      d[0] = clamp8((y0 + b + 128) >> 8); d[1] = clamp8((y0 + g + 128) >> 8); d[2] = clamp8((y0 + r + 128) >> 8); d[3] = 255;
      d[4] = clamp8((y1 + b + 128) >> 8); d[5] = clamp8((y1 + g + 128) >> 8); d[6] = clamp8((y1 + r + 128) >> 8); d[7] = 255;
    }
  }
}

class Capture : public IDeckLinkInputCallback {
 public:
  IDeckLink* dl = nullptr; IDeckLinkInput* in = nullptr; std::mutex mx; std::vector<uint8_t> frame; int w = 0, h = 0; bool fresh = false; uint64_t frames = 0; std::string mode; std::string error;
  int refs = 1;
  HRESULT STDMETHODCALLTYPE QueryInterface(REFIID iid, LPVOID* ppv) override {
    if (sameIID(&iid, &IID_IDeckLinkInputCallback)) { *ppv = this; AddRef(); return S_OK; } *ppv = nullptr; return E_NOINTERFACE; }
  ULONG STDMETHODCALLTYPE AddRef() override { return ++refs; }
  ULONG STDMETHODCALLTYPE Release() override { return --refs; } // owned by the JS handle
  HRESULT STDMETHODCALLTYPE VideoInputFormatChanged(BMDVideoInputFormatChangedEvents, IDeckLinkDisplayMode* m, BMDDetectedVideoInputFormatFlags) override {
    in->PauseStreams(); in->EnableVideoInput(m->GetDisplayMode(), bmdFormat8BitYUV, bmdVideoInputEnableFormatDetection); in->FlushStreams(); in->StartStreams();
    std::lock_guard<std::mutex> g(mx); mode = modeLabel(m); return S_OK;
  }
  HRESULT STDMETHODCALLTYPE VideoInputFrameArrived(IDeckLinkVideoInputFrame* f, IDeckLinkAudioInputPacket*) override {
    if (!f || (f->GetFlags() & bmdFrameHasNoInputSource)) return S_OK;
    IDeckLinkVideoBuffer* buf = nullptr; if (f->QueryInterface(IID_IDeckLinkVideoBuffer, (void**)&buf) != S_OK || !buf) return S_OK;
    void* bytes = nullptr;
    if (buf->StartAccess(bmdBufferAccessRead) == S_OK) {
      if (buf->GetBytes(&bytes) == S_OK && bytes) {
        int fw = (int)f->GetWidth(), fh = (int)f->GetHeight(), rb = (int)f->GetRowBytes();
        std::lock_guard<std::mutex> g(mx);
        frame.resize((size_t)fw * fh * 4); w = fw; h = fh;
        if (f->GetPixelFormat() == bmdFormat8BitBGRA) for (int y = 0; y < fh; y++) memcpy(&frame[(size_t)y * fw * 4], (uint8_t*)bytes + (size_t)y * rb, (size_t)fw * 4);
        else uyvyToBgra((const uint8_t*)bytes, rb, fw, fh, frame.data(), fh >= 720);
        fresh = true; frames++;
      }
      buf->EndAccess(bmdBufferAccessRead);
    }
    buf->Release(); return S_OK;
  }
};

// Output. Two ways to play: DisplayVideoFrameSync (simple, shows the newest frame), or scheduled playback (genlock):
// frames are queued a few frames ahead and the card plays one per frame of its own clock, which follows the house
// reference (black burst / tri-level) on the REF input when one is connected — so outputs on every machine on that
// reference change frame at the same instant.
class Playout : public IDeckLinkVideoOutputCallback {
 public:
  IDeckLink* dl = nullptr; IDeckLinkOutput* out = nullptr; int w = 0, h = 0; std::string mode;
  BMDTimeValue dur = 1000; BMDTimeScale scale = 50000; bool scheduled = false, started = false; int64_t next = 0; int preroll = 3;
  std::mutex mx; uint64_t completed = 0, late = 0, dropped = 0, flushed = 0, underruns = 0; int refs = 1;
  HRESULT STDMETHODCALLTYPE QueryInterface(REFIID iid, LPVOID* ppv) override {
    if (sameIID(&iid, &IID_IDeckLinkVideoOutputCallback)) { *ppv = this; AddRef(); return S_OK; } *ppv = nullptr; return E_NOINTERFACE; }
  ULONG STDMETHODCALLTYPE AddRef() override { return ++refs; }
  ULONG STDMETHODCALLTYPE Release() override { return --refs; } // owned by the JS handle
  HRESULT STDMETHODCALLTYPE ScheduledFrameCompleted(IDeckLinkVideoFrame*, BMDOutputFrameCompletionResult r) override {
    std::lock_guard<std::mutex> g(mx); completed++;
    if (r == bmdOutputFrameDisplayedLate) late++; else if (r == bmdOutputFrameDropped) dropped++; else if (r == bmdOutputFrameFlushed) flushed++;
    return S_OK; }
  HRESULT STDMETHODCALLTYPE ScheduledPlaybackHasStopped() override { return S_OK; }
};

static std::map<int, Capture*> caps; static std::map<int, Playout*> outs; static int nextHandle = 1;

/* ---------------- N-API glue */
#define CHECK(x) if ((x) != napi_ok) { napi_throw_error(env, nullptr, "N-API call failed"); return nullptr; }
static napi_value str(napi_env env, const std::string& s) { napi_value v; napi_create_string_utf8(env, s.c_str(), s.size(), &v); return v; }
static napi_value numv(napi_env env, double d) { napi_value v; napi_create_double(env, d, &v); return v; }
static napi_value boolv(napi_env env, bool b) { napi_value v; napi_get_boolean(env, b, &v); return v; }
static void set(napi_env env, napi_value o, const char* k, napi_value v) { napi_set_named_property(env, o, k, v); }
static int argInt(napi_env env, napi_value v, int def = 0) { int32_t r = def; napi_get_value_int32(env, v, &r); return r; }
static std::string argStr(napi_env env, napi_value v) { size_t n = 0; char buf[128] = {0}; if (napi_get_value_string_utf8(env, v, buf, sizeof buf, &n) != napi_ok) return ""; return std::string(buf, n); }
static napi_value fail(napi_env env, const char* msg) { napi_throw_error(env, nullptr, msg); return nullptr; }

static napi_value Devices(napi_env env, napi_callback_info) {
  napi_value arr; napi_create_array(env, &arr);
  IDeckLinkIterator* it = makeIterator(); if (!it) return arr;
  IDeckLink* dl = nullptr; uint32_t i = 0;
  while (it->Next(&dl) == S_OK) {
    napi_value o; napi_create_object(env, &o);
    dlstring_t n = nullptr, m = nullptr; dl->GetDisplayName(&n); dl->GetModelName(&m);
    int64_t io = 0; IDeckLinkProfileAttributes* at = nullptr;
    if (dl->QueryInterface(IID_IDeckLinkProfileAttributes, (void**)&at) == S_OK && at) { at->GetInt(BMDDeckLinkVideoIOSupport, &io); at->Release(); }
    set(env, o, "index", numv(env, i)); set(env, o, "name", str(env, dlstr(n))); set(env, o, "model", str(env, dlstr(m)));
    set(env, o, "input", boolv(env, io & bmdDeviceSupportsCapture)); set(env, o, "output", boolv(env, io & bmdDeviceSupportsPlayback));
    napi_set_element(env, arr, i++, o); dl->Release();
  }
  it->Release(); return arr;
}
static napi_value Modes(napi_env env, napi_callback_info info) {
  size_t argc = 2; napi_value a[2]; napi_get_cb_info(env, info, &argc, a, nullptr, nullptr);
  napi_value arr; napi_create_array(env, &arr); IDeckLink* dl = deviceAt(argInt(env, a[0])); if (!dl) return arr;
  bool wantOut = argc > 1 && argStr(env, a[1]) == "output"; IDeckLinkDisplayModeIterator* mi = nullptr;
  if (wantOut) { IDeckLinkOutput* o = nullptr; if (dl->QueryInterface(IID_IDeckLinkOutput, (void**)&o) == S_OK) { o->GetDisplayModeIterator(&mi); o->Release(); } }
  else { IDeckLinkInput* in = nullptr; if (dl->QueryInterface(IID_IDeckLinkInput, (void**)&in) == S_OK) { in->GetDisplayModeIterator(&mi); in->Release(); } }
  if (mi) { IDeckLinkDisplayMode* m = nullptr; uint32_t i = 0;
    while (mi->Next(&m) == S_OK) { napi_value o; napi_create_object(env, &o); set(env, o, "id", str(env, modeLabel(m))); set(env, o, "name", str(env, modeName(m)));
      set(env, o, "width", numv(env, m->GetWidth())); set(env, o, "height", numv(env, m->GetHeight())); set(env, o, "fps", numv(env, modeFps(m))); napi_set_element(env, arr, i++, o); m->Release(); }
    mi->Release(); }
  dl->Release(); return arr;
}
static napi_value OpenInput(napi_env env, napi_callback_info info) {
  size_t argc = 1; napi_value a[1]; napi_get_cb_info(env, info, &argc, a, nullptr, nullptr);
  IDeckLink* dl = deviceAt(argInt(env, a[0])); if (!dl) return fail(env, "DeckLink device not found (is Blackmagic Desktop Video installed?)");
  Capture* c = new Capture(); c->dl = dl;
  if (dl->QueryInterface(IID_IDeckLinkInput, (void**)&c->in) != S_OK || !c->in) { dl->Release(); delete c; return fail(env, "this DeckLink device has no input"); }
  c->in->SetCallback(c);
  // start in 1080p25; format detection switches to whatever arrives
  HRESULT hr = c->in->EnableVideoInput(bmdModeHD1080p25, bmdFormat8BitYUV, bmdVideoInputEnableFormatDetection);
  if (hr != S_OK) hr = c->in->EnableVideoInput(bmdModeHD1080i50, bmdFormat8BitYUV, 0);
  if (hr != S_OK || c->in->StartStreams() != S_OK) { c->in->SetCallback(nullptr); c->in->Release(); dl->Release(); delete c; return fail(env, "DeckLink input is busy or not supported (close other capture software)"); }
  int h = nextHandle++; caps[h] = c; return numv(env, h);
}
static napi_value CaptureFrame(napi_env env, napi_callback_info info) {
  size_t argc = 1; napi_value a[1]; napi_get_cb_info(env, info, &argc, a, nullptr, nullptr);
  auto it = caps.find(argInt(env, a[0])); napi_value nul; napi_get_null(env, &nul); if (it == caps.end()) return nul;
  Capture* c = it->second; std::lock_guard<std::mutex> g(c->mx); if (!c->fresh) return nul; c->fresh = false;
  napi_value o, buf; void* data; napi_create_object(env, &o); napi_create_buffer_copy(env, c->frame.size(), c->frame.data(), &data, &buf);
  set(env, o, "width", numv(env, c->w)); set(env, o, "height", numv(env, c->h)); set(env, o, "data", buf); set(env, o, "mode", str(env, c->mode)); set(env, o, "frames", numv(env, (double)c->frames));
  return o;
}
static napi_value OpenOutput(napi_env env, napi_callback_info info) {
  size_t argc = 2; napi_value a[2]; napi_get_cb_info(env, info, &argc, a, nullptr, nullptr);
  IDeckLink* dl = deviceAt(argInt(env, a[0])); if (!dl) return fail(env, "DeckLink device not found (is Blackmagic Desktop Video installed?)");
  std::string want = argc > 1 ? argStr(env, a[1]) : "1080p50";
  Playout* p = new Playout(); p->dl = dl;
  if (dl->QueryInterface(IID_IDeckLinkOutput, (void**)&p->out) != S_OK || !p->out) { dl->Release(); delete p; return fail(env, "this DeckLink device has no output"); }
  IDeckLinkDisplayModeIterator* mi = nullptr; IDeckLinkDisplayMode* m = nullptr; BMDDisplayMode chosen = bmdModeUnknown;
  if (p->out->GetDisplayModeIterator(&mi) == S_OK) { while (mi->Next(&m) == S_OK) { if (chosen == bmdModeUnknown && modeLabel(m) == want) { chosen = m->GetDisplayMode(); p->w = (int)m->GetWidth(); p->h = (int)m->GetHeight(); p->mode = want; m->GetFrameRate(&p->dur, &p->scale); } m->Release(); } mi->Release(); }
  if (chosen == bmdModeUnknown) { p->out->Release(); dl->Release(); delete p; return fail(env, ("output mode " + want + " is not available on this device").c_str()); }
  if (p->out->EnableVideoOutput(chosen, bmdVideoOutputFlagDefault) != S_OK) { p->out->Release(); dl->Release(); delete p; return fail(env, "DeckLink output is busy (close other playout software)"); }
  int h = nextHandle++; outs[h] = p;
  napi_value o; napi_create_object(env, &o); set(env, o, "handle", numv(env, h)); set(env, o, "width", numv(env, p->w)); set(env, o, "height", numv(env, p->h)); set(env, o, "mode", str(env, p->mode)); return o;
}
static napi_value Display(napi_env env, napi_callback_info info) {
  size_t argc = 4; napi_value a[4]; napi_get_cb_info(env, info, &argc, a, nullptr, nullptr);
  auto it = outs.find(argInt(env, a[0])); if (it == outs.end()) return boolv(env, false); Playout* p = it->second;
  void* src = nullptr; size_t len = 0; napi_get_buffer_info(env, a[1], &src, &len); int w = argInt(env, a[2]), h = argInt(env, a[3]);
  if (w != p->w || h != p->h || len < (size_t)w * h * 4) return boolv(env, false);
  IDeckLinkMutableVideoFrame* f = nullptr; if (p->out->CreateVideoFrame(w, h, w * 4, bmdFormat8BitBGRA, bmdFrameFlagDefault, &f) != S_OK || !f) return boolv(env, false);
  IDeckLinkVideoBuffer* buf = nullptr; bool ok = false;
  if (f->QueryInterface(IID_IDeckLinkVideoBuffer, (void**)&buf) == S_OK && buf) { void* dst = nullptr;
    if (buf->StartAccess(bmdBufferAccessWrite) == S_OK) { if (buf->GetBytes(&dst) == S_OK && dst) { memcpy(dst, src, (size_t)w * h * 4); ok = true; } buf->EndAccess(bmdBufferAccessWrite); } buf->Release(); }
  if (ok) ok = p->out->DisplayVideoFrameSync(f) == S_OK;
  f->Release(); return boolv(env, ok);
}
static IDeckLinkMutableVideoFrame* makeFrame(Playout* p, const void* src, int w, int h) {
  IDeckLinkMutableVideoFrame* f = nullptr; if (p->out->CreateVideoFrame(w, h, w * 4, bmdFormat8BitBGRA, bmdFrameFlagDefault, &f) != S_OK || !f) return nullptr;
  IDeckLinkVideoBuffer* buf = nullptr; bool ok = false;
  if (f->QueryInterface(IID_IDeckLinkVideoBuffer, (void**)&buf) == S_OK && buf) { void* dst = nullptr;
    if (buf->StartAccess(bmdBufferAccessWrite) == S_OK) { if (buf->GetBytes(&dst) == S_OK && dst) { memcpy(dst, src, (size_t)w * h * 4); ok = true; } buf->EndAccess(bmdBufferAccessWrite); } buf->Release(); }
  if (!ok) { f->Release(); return nullptr; } return f;
}
// startScheduled(handle, prerollFrames): switch this output to scheduled (genlock) playback
static napi_value StartScheduled(napi_env env, napi_callback_info info) {
  size_t argc = 2; napi_value a[2]; napi_get_cb_info(env, info, &argc, a, nullptr, nullptr);
  auto it = outs.find(argInt(env, a[0])); if (it == outs.end()) return boolv(env, false); Playout* p = it->second;
  if (p->scheduled) return boolv(env, true);
  p->preroll = argc > 1 ? (std::max)(2, (std::min)(8, argInt(env, a[1], 3))) : 3;
  if (p->out->SetScheduledFrameCompletionCallback(p) != S_OK) return fail(env, "DeckLink: scheduled playback is not available on this device");
  p->scheduled = true; p->started = false; p->next = 0; return boolv(env, true);
}
// schedule(handle, bgra, w, h) → { buffered, streamFrame } : queue the newest picture for the next free frame slot
static napi_value Schedule(napi_env env, napi_callback_info info) {
  size_t argc = 4; napi_value a[4]; napi_get_cb_info(env, info, &argc, a, nullptr, nullptr);
  auto it = outs.find(argInt(env, a[0])); napi_value nul; napi_get_null(env, &nul); if (it == outs.end()) return nul; Playout* p = it->second; if (!p->scheduled) return nul;
  void* src = nullptr; size_t len = 0; napi_get_buffer_info(env, a[1], &src, &len); int w = argInt(env, a[2]), h = argInt(env, a[3]);
  if (w != p->w || h != p->h || len < (size_t)w * h * 4) return nul;
  uint32_t buffered = 0; p->out->GetBufferedVideoFrameCount(&buffered);
  BMDTimeValue now = 0; double speed = 0; int64_t streamFrame = 0;
  if (p->started && p->out->GetScheduledStreamTime(p->scale, &now, &speed) == S_OK) streamFrame = (int64_t)(now / p->dur);
  if (p->started && p->next <= streamFrame) { std::lock_guard<std::mutex> g(p->mx); p->underruns++; p->next = streamFrame + 1; } // fell behind: rejoin just ahead of the card
  if (p->started && (int)buffered >= p->preroll + 2) { napi_value o; napi_create_object(env, &o); set(env, o, "buffered", numv(env, buffered)); set(env, o, "skipped", boolv(env, true)); return o; } // queue full: drop this picture
  IDeckLinkMutableVideoFrame* f = makeFrame(p, src, w, h); if (!f) return nul;
  HRESULT hr = p->out->ScheduleVideoFrame(f, p->next * p->dur, p->dur, p->scale); f->Release(); // the card keeps its own reference until the frame is shown
  if (hr == S_OK) p->next++;
  if (!p->started && p->next >= p->preroll) { if (p->out->StartScheduledPlayback(0, p->scale, 1.0) == S_OK) p->started = true; }
  napi_value o; napi_create_object(env, &o); set(env, o, "buffered", numv(env, buffered + (hr == S_OK ? 1 : 0))); set(env, o, "streamFrame", numv(env, (double)streamFrame)); set(env, o, "ok", boolv(env, hr == S_OK)); return o;
}
// status(handle) → reference lock, reference format, frame counters
static napi_value Status(napi_env env, napi_callback_info info) {
  size_t argc = 1; napi_value a[1]; napi_get_cb_info(env, info, &argc, a, nullptr, nullptr);
  auto it = outs.find(argInt(env, a[0])); napi_value nul; napi_get_null(env, &nul); if (it == outs.end()) return nul; Playout* p = it->second;
  napi_value o; napi_create_object(env, &o);
  IDeckLinkStatus* st = nullptr; bool locked = false; int64_t refMode = 0; bool known = false;
  if (p->dl->QueryInterface(IID_IDeckLinkStatus, (void**)&st) == S_OK && st) {
#ifdef _WIN32
    BOOL b = FALSE;
#else
    bool b = false;
#endif
    if (st->GetFlag(bmdDeckLinkStatusReferenceSignalLocked, &b) == S_OK) { locked = !!b; known = true; }
    if (locked) { st->GetInt(bmdDeckLinkStatusReferenceSignalMode, &refMode); }
    st->Release();
  }
  std::string refLabel;
  if (locked && refMode) { IDeckLinkDisplayModeIterator* mi = nullptr; IDeckLinkDisplayMode* m = nullptr;
    if (p->out->GetDisplayModeIterator(&mi) == S_OK) { while (mi->Next(&m) == S_OK) { if ((int64_t)m->GetDisplayMode() == refMode && refLabel.empty()) refLabel = modeLabel(m); m->Release(); } mi->Release(); } }
  uint32_t buffered = 0; if (p->scheduled) p->out->GetBufferedVideoFrameCount(&buffered);
  set(env, o, "referenceKnown", boolv(env, known)); set(env, o, "referenceLocked", boolv(env, locked)); set(env, o, "reference", str(env, refLabel));
  set(env, o, "scheduled", boolv(env, p->scheduled)); set(env, o, "started", boolv(env, p->started)); set(env, o, "buffered", numv(env, buffered));
  set(env, o, "fps", numv(env, (double)p->scale / (double)p->dur)); set(env, o, "mode", str(env, p->mode));
  { std::lock_guard<std::mutex> g(p->mx); set(env, o, "completed", numv(env, (double)p->completed)); set(env, o, "late", numv(env, (double)p->late)); set(env, o, "dropped", numv(env, (double)p->dropped)); set(env, o, "underruns", numv(env, (double)p->underruns)); }
  return o;
}
static napi_value Close(napi_env env, napi_callback_info info) {
  size_t argc = 1; napi_value a[1]; napi_get_cb_info(env, info, &argc, a, nullptr, nullptr); int h = argInt(env, a[0]);
  auto c = caps.find(h); if (c != caps.end()) { Capture* x = c->second; x->in->StopStreams(); x->in->SetCallback(nullptr); x->in->DisableVideoInput(); x->in->Release(); x->dl->Release(); delete x; caps.erase(c); }
  auto o = outs.find(h); if (o != outs.end()) { Playout* x = o->second; if (x->started) x->out->StopScheduledPlayback(0, nullptr, 0); if (x->scheduled) x->out->SetScheduledFrameCompletionCallback(nullptr); x->out->DisableVideoOutput(); x->out->Release(); x->dl->Release(); delete x; outs.erase(o); }
  return boolv(env, true);
}
static napi_value Available(napi_env env, napi_callback_info) { IDeckLinkIterator* it = makeIterator(); if (it) it->Release(); return boolv(env, it != nullptr); }

static napi_value Init(napi_env env, napi_value exports) {
  napi_property_descriptor d[] = {
    { "available", nullptr, Available, nullptr, nullptr, nullptr, napi_default, nullptr }, { "devices", nullptr, Devices, nullptr, nullptr, nullptr, napi_default, nullptr },
    { "modes", nullptr, Modes, nullptr, nullptr, nullptr, napi_default, nullptr }, { "openInput", nullptr, OpenInput, nullptr, nullptr, nullptr, napi_default, nullptr },
    { "capture", nullptr, CaptureFrame, nullptr, nullptr, nullptr, napi_default, nullptr }, { "openOutput", nullptr, OpenOutput, nullptr, nullptr, nullptr, napi_default, nullptr },
    { "display", nullptr, Display, nullptr, nullptr, nullptr, napi_default, nullptr }, { "close", nullptr, Close, nullptr, nullptr, nullptr, napi_default, nullptr },
    { "startScheduled", nullptr, StartScheduled, nullptr, nullptr, nullptr, napi_default, nullptr }, { "schedule", nullptr, Schedule, nullptr, nullptr, nullptr, napi_default, nullptr },
    { "status", nullptr, Status, nullptr, nullptr, nullptr, napi_default, nullptr } };
  napi_define_properties(env, exports, sizeof d / sizeof *d, d); return exports;
}
NAPI_MODULE(NODE_GYP_MODULE_NAME, Init)
