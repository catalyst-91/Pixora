{
  "targets": [{
    "target_name": "pixora_ndi",
    "sources": ["pixora_ndi.c"],
    "include_dirs": ["include"],
    "defines": ["NAPI_VERSION=8"],
    "conditions": [
      ["OS=='linux'", { "libraries": ["-ldl"], "cflags": ["-O2", "-Wno-deprecated-declarations"] }],
      ["OS=='mac'", { "xcode_settings": { "MACOSX_DEPLOYMENT_TARGET": "11.0", "OTHER_CFLAGS": ["-O2", "-Wno-deprecated-declarations"] } }],
      ["OS=='win'", { "msvs_settings": { "VCCLCompilerTool": { "Optimization": 2, "DisableSpecificWarnings": ["4996"] } } }]
    ]
  }]
}
