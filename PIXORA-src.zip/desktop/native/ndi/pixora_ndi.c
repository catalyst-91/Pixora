/*
 * PIXORA NDI module — Booth Productions.
 * Node-API (ABI-stable) addon that loads the NDI® runtime at run time through the SDK's dynamic-loading
 * entry point (NDIlib_v6_load), so it compiles without the NDI libraries and works in Node and Electron.
 * NDI® is a registered trademark of Vizrt NDI AB — https://ndi.video/
 *
 * JS API (wrapped by desktop/ndi.js):
 *   load(paths[])                       -> { path, version }        tries each library path in turn
 *   find(timeoutMs, extraIps)           -> Promise<[{ name, url }]> persistent finder, local sources included;
 *                                          extraIps = "10.0.0.5,10.0.0.6" for networks without mDNS
 *   sendCreate(name, groups, clockVideo)-> sender
 *   sendVideo(sender, buf, w, h, fourcc, frN, frD, stride) -> Promise<bool>  false = previous frame still sending
 *   sendAudio(sender, Float32Array interleaved, sampleRate, channels)
 *   sendConnections(sender)             -> number of receivers
 *   sendDestroy(sender)
 *   recvCreate(name, url, colorFormat, bandwidth, recvName) -> receiver
 *   recvCapture(receiver, timeoutMs)    -> Promise<{ type:'video'|'audio'|'none'|'status'|'error', ... }>
 *   recvConnections(receiver)
 *   recvDestroy(receiver)
 *   sendTally(sender, timeoutMs)       -> { program, preview, changed }   tally from receivers (vision mixers)
 *   recvSetTally(receiver, program, preview)                          tell the source it is on air / in preview
 *   recvPtz(receiver, action, a, b)     -> bool   supported|zoom|zoomSpeed|panTilt|panTiltSpeed|storePreset|recallPreset|
 *                                                 autoFocus|focus|focusSpeed|wbAuto|wbIndoor|wbOutdoor|wbOneshot|wbManual|exposureAuto|exposureManual
 */
#define NAPI_VERSION 8
#ifdef _WIN32
#  define _CRT_SECURE_NO_WARNINGS
#endif
#include <stdio.h>
#include <node_api.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include "Processing.NDI.Lib.h"

#ifdef _WIN32
#  include <windows.h>
#  define strdup _strdup
#  define LIBHANDLE HMODULE
static LIBHANDLE lib_open(const char *p) { return LoadLibraryA(p); }
static void *lib_sym(LIBHANDLE h, const char *s) { return (void *)GetProcAddress(h, s); }
#else
#  include <dlfcn.h>
#  define LIBHANDLE void *
static LIBHANDLE lib_open(const char *p) { return dlopen(p, RTLD_LOCAL | RTLD_LAZY); }
static void *lib_sym(LIBHANDLE h, const char *s) { return dlsym(h, s); }
#endif

static const NDIlib_v6 *ndi = NULL;
static char loaded_path[2048] = "";
static NDIlib_find_instance_t finder = NULL;

#define CHECK(call) do { if ((call) != napi_ok) { napi_throw_error(env, NULL, "N-API call failed: " #call); return NULL; } } while (0)
#define NEED_NDI() do { if (!ndi) { napi_throw_error(env, "ENDI", "NDI runtime not loaded"); return NULL; } } while (0)

static napi_value str(napi_env env, const char *s) { napi_value v; napi_create_string_utf8(env, s ? s : "", NAPI_AUTO_LENGTH, &v); return v; }
static napi_value num(napi_env env, double d) { napi_value v; napi_create_double(env, d, &v); return v; }
static napi_value jsbool(napi_env env, bool b) { napi_value v; napi_get_boolean(env, b, &v); return v; }
static void set(napi_env env, napi_value o, const char *k, napi_value v) { napi_set_named_property(env, o, k, v); }
static char *get_string(napi_env env, napi_value v) { // malloc'd, NULL if not a string
  napi_valuetype t; if (napi_typeof(env, v, &t) != napi_ok || t != napi_string) return NULL;
  size_t n = 0; napi_get_value_string_utf8(env, v, NULL, 0, &n); char *s = malloc(n + 1); napi_get_value_string_utf8(env, v, s, n + 1, &n); return s;
}
static double get_num(napi_env env, napi_value v, double dflt) { double d; return napi_get_value_double(env, v, &d) == napi_ok ? d : dflt; }
static bool get_bool(napi_env env, napi_value v, bool dflt) { bool b; return napi_get_value_bool(env, v, &b) == napi_ok ? b : dflt; }

/* ---------------------------------------------------------------- load */
static napi_value Load(napi_env env, napi_callback_info info) {
  size_t argc = 1; napi_value argv[1]; CHECK(napi_get_cb_info(env, info, &argc, argv, NULL, NULL));
  if (ndi) { napi_value o; napi_create_object(env, &o); set(env, o, "path", str(env, loaded_path)); set(env, o, "version", str(env, ndi->version())); return o; }
  bool isArr = false; if (argc < 1 || napi_is_array(env, argv[0], &isArr) != napi_ok || !isArr) { napi_throw_type_error(env, NULL, "load(paths[])"); return NULL; }
  uint32_t n = 0; napi_get_array_length(env, argv[0], &n);
  char tried[4096] = "";
  for (uint32_t i = 0; i < n && !ndi; i++) {
    napi_value e; napi_get_element(env, argv[0], i, &e); char *p = get_string(env, e); if (!p) continue;
    LIBHANDLE h = lib_open(p);
    if (h) {
      const NDIlib_v6 *(*load)(void) = (const NDIlib_v6 *(*)(void))lib_sym(h, "NDIlib_v6_load");
      const NDIlib_v6 *t = load ? load() : NULL;
      if (t && t->initialize && t->initialize()) { ndi = t; strncpy(loaded_path, p, sizeof loaded_path - 1); }
      else if (t && t->is_supported_CPU && !t->is_supported_CPU()) { free(p); napi_throw_error(env, "ECPU", "This CPU is not supported by NDI"); return NULL; }
    }
    if (!ndi && strlen(tried) + strlen(p) + 3 < sizeof tried) { strcat(tried, p); strcat(tried, "; "); }
    free(p);
  }
  if (!ndi) { char msg[4200]; snprintf(msg, sizeof msg, "NDI runtime not found (tried: %s)", tried); napi_throw_error(env, "ENOTFOUND", msg); return NULL; }
  napi_value o; napi_create_object(env, &o); set(env, o, "path", str(env, loaded_path)); set(env, o, "version", str(env, ndi->version())); return o;
}

/* ---------------------------------------------------------------- find (async) */
typedef struct { napi_async_work work; napi_deferred def; uint32_t timeout; uint32_t count; char **names; char **urls; char *extra; } FindJob;
static char finder_extra[1024] = "";
static void find_exec(napi_env env, void *d) {
  FindJob *j = d; (void)env;
  const char *want = j->extra ? j->extra : "";
  if (finder && strcmp(want, finder_extra)) { ndi->find_destroy(finder); finder = NULL; } // extra IPs changed: new finder
  if (!finder) { NDIlib_find_create_t c; memset(&c, 0, sizeof c); c.show_local_sources = true; c.p_extra_ips = *want ? want : NULL;
    finder = ndi->find_create_v2(&c); strncpy(finder_extra, want, sizeof finder_extra - 1); }
  if (!finder) return;
  ndi->find_wait_for_sources(finder, j->timeout);
  uint32_t n = 0; const NDIlib_source_t *s = ndi->find_get_sources(finder, &n, 0);
  j->count = n; j->names = calloc(n ? n : 1, sizeof(char *)); j->urls = calloc(n ? n : 1, sizeof(char *));
  for (uint32_t i = 0; i < n; i++) { j->names[i] = strdup(s[i].p_ndi_name ? s[i].p_ndi_name : ""); j->urls[i] = strdup(s[i].p_url_address ? s[i].p_url_address : ""); }
}
static void find_done(napi_env env, napi_status st, void *d) {
  FindJob *j = d; napi_value arr; napi_create_array_with_length(env, j->count, &arr);
  for (uint32_t i = 0; i < j->count; i++) { napi_value o; napi_create_object(env, &o); set(env, o, "name", str(env, j->names[i])); set(env, o, "url", str(env, j->urls[i])); napi_set_element(env, arr, i, o); free(j->names[i]); free(j->urls[i]); }
  if (st == napi_ok) napi_resolve_deferred(env, j->def, arr); else napi_reject_deferred(env, j->def, str(env, "find failed"));
  free(j->names); free(j->urls); free(j->extra); napi_delete_async_work(env, j->work); free(j);
}
static napi_value Find(napi_env env, napi_callback_info info) {
  NEED_NDI(); size_t argc = 2; napi_value argv[2]; CHECK(napi_get_cb_info(env, info, &argc, argv, NULL, NULL));
  FindJob *j = calloc(1, sizeof *j); j->timeout = (uint32_t)(argc ? get_num(env, argv[0], 1000) : 1000); j->extra = argc > 1 ? get_string(env, argv[1]) : NULL;
  napi_value p, name; CHECK(napi_create_promise(env, &j->def, &p)); napi_create_string_utf8(env, "ndi-find", NAPI_AUTO_LENGTH, &name);
  CHECK(napi_create_async_work(env, NULL, name, find_exec, find_done, j, &j->work)); CHECK(napi_queue_async_work(env, j->work)); return p;
}

/* ---------------------------------------------------------------- sender */
typedef struct { NDIlib_send_instance_t inst; volatile int busy; int dead; float *planar; size_t planar_n; } Sender;
static void sender_free(Sender *s) { if (s->inst && ndi) ndi->send_destroy(s->inst); s->inst = NULL; free(s->planar); s->planar = NULL; }
static void sender_finalize(napi_env env, void *data, void *hint) { (void)env; (void)hint; Sender *s = data; if (s->busy) { s->dead = 1; return; } sender_free(s); free(s); }
static Sender *get_sender(napi_env env, napi_value v) { void *p = NULL; if (napi_get_value_external(env, v, &p) != napi_ok || !p) { napi_throw_type_error(env, NULL, "not an NDI sender"); return NULL; } return p; }

static napi_value SendCreate(napi_env env, napi_callback_info info) {
  NEED_NDI(); size_t argc = 3; napi_value argv[3]; CHECK(napi_get_cb_info(env, info, &argc, argv, NULL, NULL));
  char *name = argc > 0 ? get_string(env, argv[0]) : NULL, *groups = argc > 1 ? get_string(env, argv[1]) : NULL;
  NDIlib_send_create_t c; memset(&c, 0, sizeof c); c.p_ndi_name = name ? name : "PIXORA"; c.p_groups = (groups && *groups) ? groups : NULL;
  c.clock_video = argc > 2 ? get_bool(env, argv[2], false) : false; c.clock_audio = false;
  Sender *s = calloc(1, sizeof *s); s->inst = ndi->send_create(&c); free(name); free(groups);
  if (!s->inst) { free(s); napi_throw_error(env, NULL, "NDI sender could not be created"); return NULL; }
  napi_value ext; CHECK(napi_create_external(env, s, sender_finalize, NULL, &ext)); return ext;
}

typedef struct { napi_async_work work; napi_deferred def; napi_ref bufref; Sender *s; NDIlib_video_frame_v2_t f; } VideoJob;
static void video_exec(napi_env env, void *d) { VideoJob *j = d; (void)env; if (j->s->inst && !j->s->dead) ndi->send_send_video_v2(j->s->inst, &j->f); }
static void video_done(napi_env env, napi_status st, void *d) {
  VideoJob *j = d; napi_delete_reference(env, j->bufref); j->s->busy = 0;
  if (j->s->dead) { sender_free(j->s); free(j->s); }
  napi_resolve_deferred(env, j->def, jsbool(env, st == napi_ok)); napi_delete_async_work(env, j->work); free(j);
}
static NDIlib_FourCC_video_type_e fourcc_of(const char *s) {
  if (!s) return NDIlib_FourCC_video_type_BGRA;
  if (!strcmp(s, "RGBA")) return NDIlib_FourCC_video_type_RGBA;
  if (!strcmp(s, "RGBX")) return NDIlib_FourCC_video_type_RGBX;
  if (!strcmp(s, "BGRX")) return NDIlib_FourCC_video_type_BGRX;
  if (!strcmp(s, "UYVY")) return NDIlib_FourCC_video_type_UYVY;
  return NDIlib_FourCC_video_type_BGRA;
}
static napi_value SendVideo(napi_env env, napi_callback_info info) {
  NEED_NDI(); size_t argc = 8; napi_value argv[8]; CHECK(napi_get_cb_info(env, info, &argc, argv, NULL, NULL));
  if (argc < 4) { napi_throw_type_error(env, NULL, "sendVideo(sender, buffer, width, height, fourcc, frN, frD, stride)"); return NULL; }
  Sender *s = get_sender(env, argv[0]); if (!s) return NULL;
  napi_value p; napi_deferred def; CHECK(napi_create_promise(env, &def, &p));
  if (s->busy || !s->inst) { napi_resolve_deferred(env, def, jsbool(env, false)); return p; } // drop the frame rather than queue
  void *data = NULL; size_t len = 0; bool isBuf = false, isTA = false;
  napi_is_buffer(env, argv[1], &isBuf); napi_is_typedarray(env, argv[1], &isTA);
  if (isBuf) napi_get_buffer_info(env, argv[1], &data, &len);
  else if (isTA) { napi_typedarray_type t; size_t n; napi_value ab; size_t off; napi_get_typedarray_info(env, argv[1], &t, &n, &data, &ab, &off); len = n; }
  else { napi_throw_type_error(env, NULL, "frame data must be a Buffer or Uint8Array"); return NULL; }
  int w = (int)get_num(env, argv[2], 0), h = (int)get_num(env, argv[3], 0);
  char *fc = argc > 4 ? get_string(env, argv[4]) : NULL; int frN = argc > 5 ? (int)get_num(env, argv[5], 60) : 60, frD = argc > 6 ? (int)get_num(env, argv[6], 1) : 1;
  int stride = argc > 7 ? (int)get_num(env, argv[7], 0) : 0; if (stride <= 0) stride = w * 4;
  if (w <= 0 || h <= 0 || (size_t)stride * (size_t)h > len) { free(fc); napi_throw_range_error(env, NULL, "frame buffer smaller than width × height × 4"); return NULL; }
  VideoJob *j = calloc(1, sizeof *j); j->def = def; j->s = s;
  j->f.xres = w; j->f.yres = h; j->f.FourCC = fourcc_of(fc); free(fc);
  j->f.frame_rate_N = frN; j->f.frame_rate_D = frD; j->f.picture_aspect_ratio = (float)w / (float)h;
  j->f.frame_format_type = NDIlib_frame_format_type_progressive; j->f.timecode = NDIlib_send_timecode_synthesize;
  j->f.p_data = data; j->f.line_stride_in_bytes = stride;
  napi_create_reference(env, argv[1], 1, &j->bufref); // keep the pixels alive while NDI compresses them
  napi_value name; napi_create_string_utf8(env, "ndi-send-video", NAPI_AUTO_LENGTH, &name);
  s->busy = 1; CHECK(napi_create_async_work(env, NULL, name, video_exec, video_done, j, &j->work)); CHECK(napi_queue_async_work(env, j->work));
  return p;
}
static napi_value SendAudio(napi_env env, napi_callback_info info) { // interleaved float32 → NDI planar float
  NEED_NDI(); size_t argc = 4; napi_value argv[4]; CHECK(napi_get_cb_info(env, info, &argc, argv, NULL, NULL));
  if (argc < 2) { napi_throw_type_error(env, NULL, "sendAudio(sender, Float32Array, sampleRate, channels)"); return NULL; }
  Sender *s = get_sender(env, argv[0]); if (!s || !s->inst) return NULL;
  napi_typedarray_type t; size_t n = 0; void *data = NULL; napi_value ab; size_t off; bool isTA = false;
  napi_is_typedarray(env, argv[1], &isTA); if (!isTA) { napi_throw_type_error(env, NULL, "audio must be a Float32Array"); return NULL; }
  napi_get_typedarray_info(env, argv[1], &t, &n, &data, &ab, &off); if (t != napi_float32_array) { napi_throw_type_error(env, NULL, "audio must be a Float32Array"); return NULL; }
  int sr = argc > 2 ? (int)get_num(env, argv[2], 48000) : 48000, ch = argc > 3 ? (int)get_num(env, argv[3], 2) : 2; if (ch < 1) ch = 1;
  int frames = (int)(n / (size_t)ch); if (frames <= 0) return NULL;
  if (s->planar_n < n) { free(s->planar); s->planar = malloc(n * sizeof(float)); s->planar_n = n; }
  const float *in = data; for (int c = 0; c < ch; c++) for (int i = 0; i < frames; i++) s->planar[c * frames + i] = in[i * ch + c];
  NDIlib_audio_frame_v3_t a; memset(&a, 0, sizeof a);
  a.sample_rate = sr; a.no_channels = ch; a.no_samples = frames; a.timecode = NDIlib_send_timecode_synthesize;
  a.FourCC = NDIlib_FourCC_audio_type_FLTP; a.p_data = (uint8_t *)s->planar; a.channel_stride_in_bytes = frames * (int)sizeof(float);
  ndi->send_send_audio_v3(s->inst, &a); return NULL;
}
static napi_value SendConnections(napi_env env, napi_callback_info info) {
  NEED_NDI(); size_t argc = 1; napi_value argv[1]; CHECK(napi_get_cb_info(env, info, &argc, argv, NULL, NULL));
  Sender *s = get_sender(env, argv[0]); if (!s) return NULL; return num(env, s->inst ? ndi->send_get_no_connections(s->inst, 0) : 0);
}
static napi_value SendTally(napi_env env, napi_callback_info info) { // is this source on program / preview at a receiver (vision mixer)?
  NEED_NDI(); size_t argc = 2; napi_value argv[2]; CHECK(napi_get_cb_info(env, info, &argc, argv, NULL, NULL));
  Sender *s = get_sender(env, argv[0]); if (!s) return NULL;
  NDIlib_tally_t t; memset(&t, 0, sizeof t); bool changed = s->inst ? ndi->send_get_tally(s->inst, &t, argc > 1 ? (uint32_t)get_num(env, argv[1], 0) : 0) : false;
  napi_value o; napi_create_object(env, &o); set(env, o, "program", jsbool(env, t.on_program)); set(env, o, "preview", jsbool(env, t.on_preview)); set(env, o, "changed", jsbool(env, changed)); return o;
}
static napi_value SendDestroy(napi_env env, napi_callback_info info) {
  size_t argc = 1; napi_value argv[1]; CHECK(napi_get_cb_info(env, info, &argc, argv, NULL, NULL));
  Sender *s = get_sender(env, argv[0]); if (!s) return NULL;
  if (s->busy) s->dead = 1; else sender_free(s); // the finalizer frees the struct itself
  return NULL;
}

/* ---------------------------------------------------------------- receiver */
typedef struct { NDIlib_recv_instance_t inst; volatile int busy; int dead; } Receiver;
static void recv_free(Receiver *r) { if (r->inst && ndi) ndi->recv_destroy(r->inst); r->inst = NULL; }
static void recv_finalize(napi_env env, void *data, void *hint) { (void)env; (void)hint; Receiver *r = data; if (r->busy) { r->dead = 2; return; } recv_free(r); free(r); }
static Receiver *get_recv(napi_env env, napi_value v) { void *p = NULL; if (napi_get_value_external(env, v, &p) != napi_ok || !p) { napi_throw_type_error(env, NULL, "not an NDI receiver"); return NULL; } return p; }

static napi_value RecvCreate(napi_env env, napi_callback_info info) {
  NEED_NDI(); size_t argc = 5; napi_value argv[5]; CHECK(napi_get_cb_info(env, info, &argc, argv, NULL, NULL));
  char *name = argc > 0 ? get_string(env, argv[0]) : NULL, *url = argc > 1 ? get_string(env, argv[1]) : NULL;
  char *color = argc > 2 ? get_string(env, argv[2]) : NULL, *bw = argc > 3 ? get_string(env, argv[3]) : NULL, *rname = argc > 4 ? get_string(env, argv[4]) : NULL;
  NDIlib_recv_create_v3_t c; memset(&c, 0, sizeof c);
  c.source_to_connect_to.p_ndi_name = (name && *name) ? name : NULL; c.source_to_connect_to.p_url_address = (url && *url) ? url : NULL;
  c.color_format = (color && !strcmp(color, "bgra")) ? NDIlib_recv_color_format_BGRX_BGRA : (color && !strcmp(color, "fastest")) ? NDIlib_recv_color_format_fastest : NDIlib_recv_color_format_RGBX_RGBA;
  c.bandwidth = (bw && !strcmp(bw, "lowest")) ? NDIlib_recv_bandwidth_lowest : (bw && !strcmp(bw, "audio")) ? NDIlib_recv_bandwidth_audio_only : NDIlib_recv_bandwidth_highest;
  c.allow_video_fields = false; c.p_ndi_recv_name = rname ? rname : "PIXORA";
  Receiver *r = calloc(1, sizeof *r); r->inst = ndi->recv_create_v3(&c);
  free(name); free(url); free(color); free(bw); free(rname);
  if (!r->inst) { free(r); napi_throw_error(env, NULL, "NDI receiver could not be created"); return NULL; }
  napi_value ext; CHECK(napi_create_external(env, r, recv_finalize, NULL, &ext)); return ext;
}

typedef struct { napi_async_work work; napi_deferred def; Receiver *r; uint32_t timeout; NDIlib_frame_type_e type;
  int xres, yres, stride, frN, frD, fourcc, sr, ch, samples; uint8_t *data; size_t size; } CapJob;
static void cap_exec(napi_env env, void *d) {
  CapJob *j = d; (void)env; j->type = NDIlib_frame_type_none;
  if (!j->r->inst || j->r->dead) return;
  NDIlib_video_frame_v2_t v; NDIlib_audio_frame_v3_t a; NDIlib_metadata_frame_t m;
  memset(&v, 0, sizeof v); memset(&a, 0, sizeof a); memset(&m, 0, sizeof m);
  j->type = ndi->recv_capture_v3(j->r->inst, &v, &a, &m, j->timeout);
  if (j->type == NDIlib_frame_type_video) {
    j->xres = v.xres; j->yres = v.yres; j->frN = v.frame_rate_N; j->frD = v.frame_rate_D; j->fourcc = (int)v.FourCC;
    int bpp = (v.FourCC == NDIlib_FourCC_video_type_UYVY) ? 2 : 4; j->stride = v.xres * bpp; j->size = (size_t)j->stride * v.yres;
    j->data = malloc(j->size);
    if (j->data) { if (v.line_stride_in_bytes == j->stride) memcpy(j->data, v.p_data, j->size); else for (int y = 0; y < v.yres; y++) memcpy(j->data + (size_t)y * j->stride, v.p_data + (size_t)y * v.line_stride_in_bytes, (size_t)j->stride); }
    ndi->recv_free_video_v2(j->r->inst, &v);
  } else if (j->type == NDIlib_frame_type_audio) { // planar float → interleaved float
    j->sr = a.sample_rate; j->ch = a.no_channels; j->samples = a.no_samples; j->size = (size_t)a.no_channels * a.no_samples * sizeof(float);
    j->data = malloc(j->size ? j->size : 1); float *out = (float *)j->data;
    if (out && a.FourCC == NDIlib_FourCC_audio_type_FLTP) for (int c = 0; c < a.no_channels; c++) { const float *src = (const float *)(a.p_data + (size_t)c * a.channel_stride_in_bytes); for (int i = 0; i < a.no_samples; i++) out[(size_t)i * a.no_channels + c] = src[i]; }
    ndi->recv_free_audio_v3(j->r->inst, &a);
  } else if (j->type == NDIlib_frame_type_metadata) ndi->recv_free_metadata(j->r->inst, &m);
}
static void free_data(napi_env env, void *data, void *hint) { (void)env; (void)hint; free(data); }
static void cap_done(napi_env env, napi_status st, void *d) {
  CapJob *j = d; napi_value o; napi_create_object(env, &o); (void)st;
  const char *type = j->type == NDIlib_frame_type_video ? "video" : j->type == NDIlib_frame_type_audio ? "audio" : j->type == NDIlib_frame_type_status_change ? "status" : j->type == NDIlib_frame_type_error ? "error" : j->type == NDIlib_frame_type_metadata ? "metadata" : "none";
  set(env, o, "type", str(env, type));
  if (j->data && j->type == NDIlib_frame_type_video) {
    napi_value buf; napi_create_external_buffer(env, j->size, j->data, free_data, NULL, &buf); j->data = NULL;
    set(env, o, "xres", num(env, j->xres)); set(env, o, "yres", num(env, j->yres)); set(env, o, "lineStrideBytes", num(env, j->stride));
    set(env, o, "frameRateN", num(env, j->frN)); set(env, o, "frameRateD", num(env, j->frD));
    char fc[5] = { (char)(j->fourcc & 0xff), (char)((j->fourcc >> 8) & 0xff), (char)((j->fourcc >> 16) & 0xff), (char)((j->fourcc >> 24) & 0xff), 0 };
    set(env, o, "fourCC", str(env, fc)); set(env, o, "data", buf);
  } else if (j->data && j->type == NDIlib_frame_type_audio) {
    napi_value ab, f32; void *ptr; napi_create_arraybuffer(env, j->size, &ptr, &ab); memcpy(ptr, j->data, j->size);
    napi_create_typedarray(env, napi_float32_array, j->size / sizeof(float), ab, 0, &f32);
    set(env, o, "sampleRate", num(env, j->sr)); set(env, o, "channels", num(env, j->ch)); set(env, o, "samples", num(env, j->samples)); set(env, o, "data", f32);
  }
  free(j->data); j->r->busy = 0;
  if (j->r->dead == 1) recv_free(j->r); else if (j->r->dead == 2) { recv_free(j->r); free(j->r); }
  napi_resolve_deferred(env, j->def, o); napi_delete_async_work(env, j->work); free(j);
}
static napi_value RecvCapture(napi_env env, napi_callback_info info) {
  NEED_NDI(); size_t argc = 2; napi_value argv[2]; CHECK(napi_get_cb_info(env, info, &argc, argv, NULL, NULL));
  Receiver *r = get_recv(env, argv[0]); if (!r) return NULL;
  napi_value p; napi_deferred def; CHECK(napi_create_promise(env, &def, &p));
  if (r->busy || !r->inst || r->dead) { napi_value o; napi_create_object(env, &o); set(env, o, "type", str(env, r->inst && !r->dead ? "busy" : "closed")); napi_resolve_deferred(env, def, o); return p; }
  CapJob *j = calloc(1, sizeof *j); j->def = def; j->r = r; j->timeout = (uint32_t)(argc > 1 ? get_num(env, argv[1], 100) : 100);
  napi_value name; napi_create_string_utf8(env, "ndi-recv", NAPI_AUTO_LENGTH, &name);
  r->busy = 1; CHECK(napi_create_async_work(env, NULL, name, cap_exec, cap_done, j, &j->work)); CHECK(napi_queue_async_work(env, j->work)); return p;
}
static napi_value RecvConnections(napi_env env, napi_callback_info info) {
  NEED_NDI(); size_t argc = 1; napi_value argv[1]; CHECK(napi_get_cb_info(env, info, &argc, argv, NULL, NULL));
  Receiver *r = get_recv(env, argv[0]); if (!r) return NULL; return num(env, r->inst ? ndi->recv_get_no_connections(r->inst) : 0);
}
static napi_value RecvSetTally(napi_env env, napi_callback_info info) { // tell the source (camera/mixer) it is on air / in preview here
  NEED_NDI(); size_t argc = 3; napi_value argv[3]; CHECK(napi_get_cb_info(env, info, &argc, argv, NULL, NULL));
  Receiver *r = get_recv(env, argv[0]); if (!r) return NULL;
  NDIlib_tally_t t; t.on_program = argc > 1 && get_bool(env, argv[1], false); t.on_preview = argc > 2 && get_bool(env, argv[2], false);
  return jsbool(env, r->inst && !r->dead ? ndi->recv_set_tally(r->inst, &t) : false);
}
// PTZ: recvPtz(receiver, action, a, b) — values are NDI's normalised ranges (pan/tilt/speeds -1..1, zoom/focus 0..1)
static napi_value RecvPtz(napi_env env, napi_callback_info info) {
  NEED_NDI(); size_t argc = 4; napi_value argv[4]; CHECK(napi_get_cb_info(env, info, &argc, argv, NULL, NULL));
  Receiver *r = get_recv(env, argv[0]); if (!r) return NULL;
  char *act = argc > 1 ? get_string(env, argv[1]) : NULL; float a = argc > 2 ? (float)get_num(env, argv[2], 0) : 0, b = argc > 3 ? (float)get_num(env, argv[3], 0) : 0;
  bool ok = false; NDIlib_recv_instance_t i = (r->inst && !r->dead) ? r->inst : NULL;
  if (i && act) {
    if (!strcmp(act, "supported")) ok = ndi->recv_ptz_is_supported(i);
    else if (!strcmp(act, "zoom")) ok = ndi->recv_ptz_zoom(i, a);
    else if (!strcmp(act, "zoomSpeed")) ok = ndi->recv_ptz_zoom_speed(i, a);
    else if (!strcmp(act, "panTilt")) ok = ndi->recv_ptz_pan_tilt(i, a, b);
    else if (!strcmp(act, "panTiltSpeed")) ok = ndi->recv_ptz_pan_tilt_speed(i, a, b);
    else if (!strcmp(act, "storePreset")) ok = ndi->recv_ptz_store_preset(i, (int)a);
    else if (!strcmp(act, "recallPreset")) ok = ndi->recv_ptz_recall_preset(i, (int)a, argc > 3 ? b : 1.0f);
    else if (!strcmp(act, "autoFocus")) ok = ndi->recv_ptz_auto_focus(i);
    else if (!strcmp(act, "focus")) ok = ndi->recv_ptz_focus(i, a);
    else if (!strcmp(act, "focusSpeed")) ok = ndi->recv_ptz_focus_speed(i, a);
    else if (!strcmp(act, "wbAuto")) ok = ndi->recv_ptz_white_balance_auto(i);
    else if (!strcmp(act, "wbIndoor")) ok = ndi->recv_ptz_white_balance_indoor(i);
    else if (!strcmp(act, "wbOutdoor")) ok = ndi->recv_ptz_white_balance_outdoor(i);
    else if (!strcmp(act, "wbOneshot")) ok = ndi->recv_ptz_white_balance_oneshot(i);
    else if (!strcmp(act, "wbManual")) ok = ndi->recv_ptz_white_balance_manual(i, a, b);
    else if (!strcmp(act, "exposureAuto")) ok = ndi->recv_ptz_exposure_auto(i);
    else if (!strcmp(act, "exposureManual")) ok = ndi->recv_ptz_exposure_manual(i, a);
  }
  free(act); return jsbool(env, ok);
}
static napi_value RecvDestroy(napi_env env, napi_callback_info info) {
  size_t argc = 1; napi_value argv[1]; CHECK(napi_get_cb_info(env, info, &argc, argv, NULL, NULL));
  Receiver *r = get_recv(env, argv[0]); if (!r) return NULL;
  if (r->busy) { if (!r->dead) r->dead = 1; } else recv_free(r);
  return NULL;
}

/* ---------------------------------------------------------------- module */
static napi_value Init(napi_env env, napi_value exports) {
  napi_property_descriptor d[] = {
    { "load", 0, Load, 0, 0, 0, napi_default, 0 }, { "find", 0, Find, 0, 0, 0, napi_default, 0 },
    { "sendCreate", 0, SendCreate, 0, 0, 0, napi_default, 0 }, { "sendVideo", 0, SendVideo, 0, 0, 0, napi_default, 0 },
    { "sendAudio", 0, SendAudio, 0, 0, 0, napi_default, 0 }, { "sendConnections", 0, SendConnections, 0, 0, 0, napi_default, 0 },
    { "sendDestroy", 0, SendDestroy, 0, 0, 0, napi_default, 0 }, { "sendTally", 0, SendTally, 0, 0, 0, napi_default, 0 },
    { "recvSetTally", 0, RecvSetTally, 0, 0, 0, napi_default, 0 }, { "recvPtz", 0, RecvPtz, 0, 0, 0, napi_default, 0 },
    { "recvCreate", 0, RecvCreate, 0, 0, 0, napi_default, 0 }, { "recvCapture", 0, RecvCapture, 0, 0, 0, napi_default, 0 },
    { "recvConnections", 0, RecvConnections, 0, 0, 0, napi_default, 0 }, { "recvDestroy", 0, RecvDestroy, 0, 0, 0, napi_default, 0 },
  };
  napi_define_properties(env, exports, sizeof d / sizeof d[0], d);
  return exports;
}
NAPI_MODULE(NODE_GYP_MODULE_NAME, Init)
