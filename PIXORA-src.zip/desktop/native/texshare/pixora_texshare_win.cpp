// PIXORA texture sharing — Windows: Spout (https://spout.zeal.co, BSD-2-Clause, Lynn Jarvis / leadedge).
// Talks to SpoutLibrary.dll (built from the Spout2 SDK in CI and shipped next to this module) through its C++ interface
// header SpoutLibrary.h, loaded at run time so PIXORA still starts if the DLL is missing.
//   available() → bool          senders() → [{ name, width, height }]
//   createSender(name) → id     send(id, bgraBuffer, width, height) → bool
//   openReceiver(name) → id     receive(id) → { width, height, data(Buffer BGRA), name } | null
//   close(id)
#include <node_api.h>
#include <windows.h>
#include <string>
#include <map>
#include <vector>
#include <cstring>
#include "SpoutLibrary.h"

#ifndef GL_BGRA_EXT
#define GL_BGRA_EXT 0x80E1
#endif

typedef SPOUTLIBRARY* (WINAPI* GetSpoutFn)(void);
static HMODULE g_dll = nullptr;
static GetSpoutFn g_get = nullptr;
static std::string g_err;

static bool loadDll() {
  if (g_get) return true;
  if (!g_dll) {
    // look next to this .node first (SetDllDirectory is set by the JS loader), then the normal search path
    g_dll = LoadLibraryA("SpoutLibrary.dll");
    if (!g_dll) { g_err = "SpoutLibrary.dll not found"; return false; }
  }
  g_get = (GetSpoutFn)GetProcAddress(g_dll, "GetSpout");
  if (!g_get) { g_err = "SpoutLibrary.dll has no GetSpout()"; return false; }
  return true;
}

struct Item { SPOUTLIBRARY* sp = nullptr; bool sender = false; std::string name; std::vector<unsigned char> buf; unsigned int w = 0, h = 0; bool gl = false; };
static std::map<int, Item> g_items;
static int g_next = 1;
static SPOUTLIBRARY* g_list = nullptr; // a spare instance for listing senders

static napi_value str(napi_env env, const std::string& s) { napi_value v; napi_create_string_utf8(env, s.c_str(), s.size(), &v); return v; }
static napi_value num(napi_env env, double d) { napi_value v; napi_create_double(env, d, &v); return v; }
static napi_value boolv(napi_env env, bool b) { napi_value v; napi_get_boolean(env, b, &v); return v; }
static napi_value nullv(napi_env env) { napi_value v; napi_get_null(env, &v); return v; }
static void set(napi_env env, napi_value o, const char* k, napi_value v) { napi_set_named_property(env, o, k, v); }
static std::string argStr(napi_env env, napi_value v) { char buf[256] = {0}; size_t n = 0; napi_get_value_string_utf8(env, v, buf, sizeof buf, &n); return std::string(buf, n); }
static int argInt(napi_env env, napi_value v) { int32_t r = 0; napi_get_value_int32(env, v, &r); return r; }
static napi_value fail(napi_env env, const std::string& m) { napi_throw_error(env, nullptr, m.c_str()); return nullptr; }
#define ARGS(n) size_t argc = n; napi_value a[n]; napi_get_cb_info(env, info, &argc, a, nullptr, nullptr)

static napi_value Available(napi_env env, napi_callback_info) { return boolv(env, loadDll()); }
static napi_value LastError(napi_env env, napi_callback_info) { return str(env, g_err); }

static napi_value Senders(napi_env env, napi_callback_info) {
  napi_value arr; napi_create_array(env, &arr); if (!loadDll()) return arr;
  if (!g_list) g_list = g_get(); if (!g_list) return arr;
  int n = g_list->GetSenderCount(); uint32_t k = 0;
  for (int i = 0; i < n; i++) {
    char name[256] = {0}; if (!g_list->GetSender(i, name, 256)) continue;
    unsigned int w = 0, h = 0; HANDLE share = nullptr; DWORD fmt = 0; g_list->GetSenderInfo(name, w, h, share, fmt);
    napi_value o; napi_create_object(env, &o); set(env, o, "name", str(env, name)); set(env, o, "width", num(env, w)); set(env, o, "height", num(env, h));
    napi_set_element(env, arr, k++, o);
  }
  return arr;
}

static napi_value CreateSender(napi_env env, napi_callback_info info) {
  ARGS(1); if (!loadDll()) return fail(env, g_err);
  Item it; it.sp = g_get(); if (!it.sp) return fail(env, "Spout: could not create an instance");
  it.sender = true; it.name = argStr(env, a[0]); if (it.name.empty()) it.name = "PIXORA";
  if (!it.sp->CreateOpenGL()) { it.sp->Release(); return fail(env, "Spout: could not create an OpenGL context"); }
  it.gl = true; it.sp->SetSenderName(it.name.c_str());
  int id = g_next++; g_items[id] = it; return num(env, id);
}

static napi_value Send(napi_env env, napi_callback_info info) {
  ARGS(4); auto f = g_items.find(argInt(env, a[0])); if (f == g_items.end() || !f->second.sender) return boolv(env, false);
  void* data = nullptr; size_t len = 0; if (napi_get_buffer_info(env, a[1], &data, &len) != napi_ok) return boolv(env, false);
  unsigned int w = (unsigned int)argInt(env, a[2]), h = (unsigned int)argInt(env, a[3]); if (!w || !h || len < (size_t)w * h * 4) return boolv(env, false);
  // Electron gives top-down BGRA rows; Spout's SendImage takes the GL format and flips when bInvert is true
  bool ok = f->second.sp->SendImage((const unsigned char*)data, w, h, GL_BGRA_EXT, true, 0);
  return boolv(env, ok);
}

static napi_value OpenReceiver(napi_env env, napi_callback_info info) {
  ARGS(1); if (!loadDll()) return fail(env, g_err);
  Item it; it.sp = g_get(); if (!it.sp) return fail(env, "Spout: could not create an instance");
  if (!it.sp->CreateOpenGL()) { it.sp->Release(); return fail(env, "Spout: could not create an OpenGL context"); }
  it.gl = true; it.name = argStr(env, a[0]); if (!it.name.empty()) it.sp->SetReceiverName(it.name.c_str());
  int id = g_next++; g_items[id] = it; return num(env, id);
}

static napi_value Receive(napi_env env, napi_callback_info info) {
  ARGS(1); auto f = g_items.find(argInt(env, a[0])); if (f == g_items.end() || f->second.sender) return nullv(env);
  Item& it = f->second;
  // first call connects; IsUpdated() reports a size change, after which the buffer is resized and the next call reads
  if (!it.sp->ReceiveImage(it.buf.empty() ? nullptr : it.buf.data(), GL_BGRA_EXT, true, 0)) return nullv(env);
  if (it.sp->IsUpdated() || it.buf.empty()) {
    it.w = it.sp->GetSenderWidth(); it.h = it.sp->GetSenderHeight(); if (!it.w || !it.h) return nullv(env);
    it.buf.assign((size_t)it.w * it.h * 4, 0); return nullv(env);
  }
  if (!it.sp->IsFrameNew()) return nullv(env);
  napi_value o, b; napi_create_object(env, &o); void* out = nullptr;
  napi_create_buffer_copy(env, it.buf.size(), it.buf.data(), &out, &b);
  set(env, o, "width", num(env, it.w)); set(env, o, "height", num(env, it.h)); set(env, o, "data", b); set(env, o, "name", str(env, it.sp->GetSenderName()));
  return o;
}

static napi_value Close(napi_env env, napi_callback_info info) {
  ARGS(1); auto f = g_items.find(argInt(env, a[0])); if (f == g_items.end()) return boolv(env, false);
  Item& it = f->second;
  if (it.sender) it.sp->ReleaseSender(); else it.sp->ReleaseReceiver();
  if (it.gl) it.sp->CloseOpenGL(); it.sp->Release(); g_items.erase(f); return boolv(env, true);
}

static napi_value Init(napi_env env, napi_value exports) {
  napi_property_descriptor d[] = {
    { "available", 0, Available, 0, 0, 0, napi_default, 0 }, { "lastError", 0, LastError, 0, 0, 0, napi_default, 0 },
    { "senders", 0, Senders, 0, 0, 0, napi_default, 0 }, { "createSender", 0, CreateSender, 0, 0, 0, napi_default, 0 },
    { "send", 0, Send, 0, 0, 0, napi_default, 0 }, { "openReceiver", 0, OpenReceiver, 0, 0, 0, napi_default, 0 },
    { "receive", 0, Receive, 0, 0, 0, napi_default, 0 }, { "close", 0, Close, 0, 0, 0, napi_default, 0 },
  };
  napi_define_properties(env, exports, sizeof d / sizeof d[0], d);
  napi_value t; napi_create_string_utf8(env, "spout", NAPI_AUTO_LENGTH, &t); napi_set_named_property(env, exports, "kind", t);
  return exports;
}
NAPI_MODULE(NODE_GYP_MODULE_NAME, Init)
