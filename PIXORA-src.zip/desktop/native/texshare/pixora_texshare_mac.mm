// PIXORA texture sharing — macOS: Syphon (https://syphon.github.io, BSD-2-Clause, Tom Butterworth & Anton Marini).
// Linked against Syphon.framework (built from Syphon-Framework in CI, shipped with the app). OpenGL is deprecated on
// macOS but still what Syphon's GL server/client use; a private CGL context does the uploads and read-backs.
// Same JS interface as the Windows (Spout) module.
#include <node_api.h>
#import <Foundation/Foundation.h>
#import <AppKit/AppKit.h>
#import <OpenGL/OpenGL.h>
#import <OpenGL/gl.h>
#import <OpenGL/glext.h>
#import <Syphon/Syphon.h>
#include <map>
#include <string>
#include <vector>

static CGLContextObj g_ctx = nullptr;
static std::string g_err;
static bool ensureContext() {
  if (g_ctx) return true;
  CGLPixelFormatAttribute attrs[] = { kCGLPFAAccelerated, kCGLPFAAllowOfflineRenderers, (CGLPixelFormatAttribute)0 };
  CGLPixelFormatObj pf = nullptr; GLint n = 0;
  if (CGLChoosePixelFormat(attrs, &pf, &n) != kCGLNoError || !pf) { g_err = "no OpenGL pixel format"; return false; }
  CGLError e = CGLCreateContext(pf, nullptr, &g_ctx); CGLDestroyPixelFormat(pf);
  if (e != kCGLNoError || !g_ctx) { g_err = "could not create an OpenGL context"; g_ctx = nullptr; return false; }
  return true;
}

struct Item { bool sender = false; SyphonOpenGLServer* server = nil; SyphonOpenGLClient* client = nil; GLuint tex = 0, fbo = 0, rtex = 0; int w = 0, h = 0; std::string name; uint64_t lastFrame = 0; std::vector<unsigned char> buf; };
static std::map<int, Item> g_items;
static int g_next = 1;

static napi_value str(napi_env env, const std::string& s) { napi_value v; napi_create_string_utf8(env, s.c_str(), s.size(), &v); return v; }
static napi_value num(napi_env env, double d) { napi_value v; napi_create_double(env, d, &v); return v; }
static napi_value boolv(napi_env env, bool b) { napi_value v; napi_get_boolean(env, b, &v); return v; }
static napi_value nullv(napi_env env) { napi_value v; napi_get_null(env, &v); return v; }
static void set(napi_env env, napi_value o, const char* k, napi_value v) { napi_set_named_property(env, o, k, v); }
static std::string argStr(napi_env env, napi_value v) { char buf[256] = {0}; size_t n = 0; napi_get_value_string_utf8(env, v, buf, sizeof buf, &n); return std::string(buf, n); }
static int argInt(napi_env env, napi_value v) { int32_t r = 0; napi_get_value_int32(env, v, &r); return r; }
static napi_value fail(napi_env env, const std::string& m) { napi_throw_error(env, nullptr, m.c_str()); return nullptr; }
#define ARGS(n) size_t argc = n; napi_value a[n]; napi_get_cb_info(env, info, &argc, a, nullptr, nullptr)

static napi_value Available(napi_env env, napi_callback_info) { return boolv(env, ensureContext()); }
static napi_value LastError(napi_env env, napi_callback_info) { return str(env, g_err); }

static napi_value Senders(napi_env env, napi_callback_info) {
  napi_value arr; napi_create_array(env, &arr); uint32_t k = 0;
  @autoreleasepool {
    for (NSDictionary* d in [[SyphonServerDirectory sharedDirectory] servers]) {
      NSString* nm = d[SyphonServerDescriptionNameKey] ?: @""; NSString* app = d[SyphonServerDescriptionAppNameKey] ?: @"";
      std::string label = nm.length ? std::string(app.UTF8String) + " – " + nm.UTF8String : std::string(app.UTF8String);
      napi_value o; napi_create_object(env, &o); set(env, o, "name", str(env, label)); set(env, o, "uuid", str(env, [(NSString*)(d[SyphonServerDescriptionUUIDKey] ?: @"") UTF8String]));
      set(env, o, "width", num(env, 0)); set(env, o, "height", num(env, 0)); napi_set_element(env, arr, k++, o);
    }
  }
  return arr;
}

static napi_value CreateSender(napi_env env, napi_callback_info info) {
  ARGS(1); if (!ensureContext()) return fail(env, "Syphon: " + g_err);
  Item it; it.sender = true; it.name = argStr(env, a[0]); if (it.name.empty()) it.name = "PIXORA";
  @autoreleasepool { it.server = [[SyphonOpenGLServer alloc] initWithName:[NSString stringWithUTF8String:it.name.c_str()] context:g_ctx options:nil]; }
  if (!it.server) return fail(env, "Syphon: could not create a server");
  CGLSetCurrentContext(g_ctx); glGenTextures(1, &it.tex);
  int id = g_next++; g_items[id] = it; return num(env, id);
}

static napi_value Send(napi_env env, napi_callback_info info) {
  ARGS(4); auto f = g_items.find(argInt(env, a[0])); if (f == g_items.end() || !f->second.sender) return boolv(env, false);
  void* data = nullptr; size_t len = 0; if (napi_get_buffer_info(env, a[1], &data, &len) != napi_ok) return boolv(env, false);
  int w = argInt(env, a[2]), h = argInt(env, a[3]); if (w <= 0 || h <= 0 || len < (size_t)w * h * 4) return boolv(env, false);
  Item& it = f->second; CGLSetCurrentContext(g_ctx);
  glBindTexture(GL_TEXTURE_RECTANGLE_EXT, it.tex);
  if (w != it.w || h != it.h) { glTexImage2D(GL_TEXTURE_RECTANGLE_EXT, 0, GL_RGBA8, w, h, 0, GL_BGRA, GL_UNSIGNED_INT_8_8_8_8_REV, data); it.w = w; it.h = h; }
  else glTexSubImage2D(GL_TEXTURE_RECTANGLE_EXT, 0, 0, 0, w, h, GL_BGRA, GL_UNSIGNED_INT_8_8_8_8_REV, data);
  glBindTexture(GL_TEXTURE_RECTANGLE_EXT, 0);
  // rows arrive top-down, so the texture is upside down in GL terms: flipped:YES tells clients
  [it.server publishFrameTexture:it.tex textureTarget:GL_TEXTURE_RECTANGLE_EXT imageRegion:NSMakeRect(0, 0, w, h) textureDimensions:NSMakeSize(w, h) flipped:YES];
  glFlush(); return boolv(env, true);
}

static napi_value OpenReceiver(napi_env env, napi_callback_info info) {
  ARGS(1); if (!ensureContext()) return fail(env, "Syphon: " + g_err);
  std::string want = argStr(env, a[0]); NSDictionary* pick = nil;
  @autoreleasepool {
    for (NSDictionary* d in [[SyphonServerDirectory sharedDirectory] servers]) {
      NSString* nm = d[SyphonServerDescriptionNameKey] ?: @""; NSString* app = d[SyphonServerDescriptionAppNameKey] ?: @"";
      std::string label = nm.length ? std::string(app.UTF8String) + " – " + nm.UTF8String : std::string(app.UTF8String);
      if (want.empty() || want == label || want == nm.UTF8String || want == [(NSString*)(d[SyphonServerDescriptionUUIDKey] ?: @"") UTF8String]) { pick = d; break; }
    }
    if (!pick) return fail(env, "Syphon: no server called \"" + want + "\"");
    Item it; it.name = want; it.client = [[SyphonOpenGLClient alloc] initWithServerDescription:pick context:g_ctx options:nil newFrameHandler:nil];
    if (!it.client) return fail(env, "Syphon: could not connect");
    CGLSetCurrentContext(g_ctx); glGenFramebuffersEXT(1, &it.fbo);
    int id = g_next++; g_items[id] = it; return num(env, id);
  }
}

static napi_value Receive(napi_env env, napi_callback_info info) {
  ARGS(1); auto f = g_items.find(argInt(env, a[0])); if (f == g_items.end() || f->second.sender) return nullv(env);
  Item& it = f->second; if (!it.client.hasNewFrame) return nullv(env);
  napi_value result = nullptr;
  @autoreleasepool {
    CGLSetCurrentContext(g_ctx);
    SyphonOpenGLImage* img = [it.client newFrameImage]; if (!img) return nullv(env);
    int w = (int)img.textureSize.width, h = (int)img.textureSize.height;
    if (w > 0 && h > 0) {
      it.buf.resize((size_t)w * h * 4);
      glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, it.fbo);
      glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT, GL_TEXTURE_RECTANGLE_EXT, img.textureName, 0);
      glPixelStorei(GL_PACK_ALIGNMENT, 4); glReadPixels(0, 0, w, h, GL_BGRA, GL_UNSIGNED_INT_8_8_8_8_REV, it.buf.data());
      glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
      // GL rows are bottom-up: flip to top-down for PIXORA
      std::vector<unsigned char> row((size_t)w * 4); for (int y = 0; y < h / 2; y++) { unsigned char *p = &it.buf[(size_t)y * w * 4], *q = &it.buf[(size_t)(h - 1 - y) * w * 4]; memcpy(row.data(), p, row.size()); memcpy(p, q, row.size()); memcpy(q, row.data(), row.size()); }
      napi_value o, b; napi_create_object(env, &o); void* out = nullptr; napi_create_buffer_copy(env, it.buf.size(), it.buf.data(), &out, &b);
      set(env, o, "width", num(env, w)); set(env, o, "height", num(env, h)); set(env, o, "data", b); set(env, o, "name", str(env, it.name)); result = o;
    }
    [img release];
  }
  return result ? result : nullv(env);
}

static napi_value Close(napi_env env, napi_callback_info info) {
  ARGS(1); auto f = g_items.find(argInt(env, a[0])); if (f == g_items.end()) return boolv(env, false);
  Item& it = f->second; CGLSetCurrentContext(g_ctx);
  if (it.server) { [it.server stop]; [it.server release]; }
  if (it.client) { [it.client stop]; [it.client release]; }
  if (it.tex) glDeleteTextures(1, &it.tex); if (it.fbo) glDeleteFramebuffersEXT(1, &it.fbo);
  g_items.erase(f); return boolv(env, true);
}

static napi_value Init(napi_env env, napi_value exports) {
  napi_property_descriptor d[] = {
    { "available", 0, Available, 0, 0, 0, napi_default, 0 }, { "lastError", 0, LastError, 0, 0, 0, napi_default, 0 },
    { "senders", 0, Senders, 0, 0, 0, napi_default, 0 }, { "createSender", 0, CreateSender, 0, 0, 0, napi_default, 0 },
    { "send", 0, Send, 0, 0, 0, napi_default, 0 }, { "openReceiver", 0, OpenReceiver, 0, 0, 0, napi_default, 0 },
    { "receive", 0, Receive, 0, 0, 0, napi_default, 0 }, { "close", 0, Close, 0, 0, 0, napi_default, 0 },
  };
  napi_define_properties(env, exports, sizeof d / sizeof d[0], d);
  napi_value t; napi_create_string_utf8(env, "syphon", NAPI_AUTO_LENGTH, &t); napi_set_named_property(env, exports, "kind", t);
  return exports;
}
NAPI_MODULE(NODE_GYP_MODULE_NAME, Init)
