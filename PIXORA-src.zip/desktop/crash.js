'use strict';
// PIXORA crash reports — opt-in, Booth Productions.
// When the server, a window or the app itself crashes, PIXORA keeps a short report on this computer (crash-reports/ in the
// app's data folder) and asks whether to send it. "Send report…" opens a pre-filled GitHub issue on catalyst-91/Pixora in the
// browser: the operator sees exactly what is sent and submits it with their own GitHub sign-in. Nothing is sent by itself,
// and no access token ships inside the app. Home folders, user names, IP addresses, stream URLs and keys are removed first.
const fs = require('fs'), path = require('path'), os = require('os');
const REPO = process.env.PIXORA_ISSUES_REPO || 'catalyst-91/Pixora';
const MAX_URL = 7600; // GitHub (and browsers) cope with ~8 KB URLs

function sanitize(text) {
  let t = String(text || '');
  const home = os.homedir(), user = (() => { try { return os.userInfo().username; } catch { return ''; } })();
  if (home) t = t.split(home).join('~').split(home.replace(/\\/g, '/')).join('~');
  t = t.replace(/\b(rtmps?|srt|rtsp|https?):\/\/[^\s"'<>)]+/gi, m => { try { const u = new URL(m); return /^https?:$/.test(u.protocol) && /github\.com|ndi\.video|booth-productions\.com/.test(u.hostname) ? m : `${u.protocol}//<removed>`; } catch { return '<url removed>'; } });
  t = t.replace(/\b(?:\d{1,3}\.){3}\d{1,3}\b/g, 'x.x.x.x').replace(/\b(?:[0-9a-f]{1,4}:){4,7}[0-9a-f]{1,4}\b/gi, 'x:x::x');
  t = t.replace(/((?:token|key|pin|password|passwd|secret|auth)[\w-]*["']?\s*[:=]\s*["']?)[^\s"'&,;]+/gi, '$1<removed>');
  t = t.replace(/[\w.+-]+@[\w-]+\.[\w.-]+/g, '<email>');
  if (user && user.length > 2) t = t.replace(new RegExp(`\\b${user.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'g'), '<user>');
  return t;
}

function issueUrl(r) {
  const title = `Crash: ${r.kind} — ${String(r.message || '').split('\n')[0].slice(0, 90)}`;
  const head = `**PIXORA ${r.version}** · ${r.platform} ${r.arch} (${r.osRelease}) · Electron ${r.electron || '?'} · ${r.at}\n**What crashed:** ${r.kind}\n\n**What were you doing?**\n_(please add a line — it helps a lot)_\n\n`;
  const block = (label, s) => s ? `**${label}**\n\`\`\`\n${s}\n\`\`\`\n` : '';
  let stack = sanitize(r.stack || ''), tail = sanitize(r.tail || ''), msg = sanitize(r.message || '');
  const build = () => head + block('Error', msg) + block('Stack', stack) + block('Last log lines', tail) + '\n_Sent from PIXORA’s crash report dialog._';
  const url = () => `https://github.com/${REPO}/issues/new?labels=crash&title=${encodeURIComponent(sanitize(title))}&body=${encodeURIComponent(build())}`;
  while (url().length > MAX_URL && (tail || stack)) { if (tail) tail = tail.split('\n').slice(Math.ceil(tail.split('\n').length / 3)).join('\n'); else stack = stack.split('\n').slice(0, -3).join('\n'); if (tail.length < 40) tail = ''; if (stack.length < 40) stack = ''; }
  return url();
}

module.exports = function crashReports({ app, dialog, shell, BrowserWindow, cfg, saveCfg, log = console.log }) {
  const dir = path.join(app.getPath('userData'), 'crash-reports');
  let asking = false, seq = 0; const queue = [];
  const mode = () => cfg.crashReports || 'ask'; // 'ask' | 'off'
  function record(kind, info = {}) {
    const r = { id: Date.now().toString(36) + '-' + (seq++ % 1000).toString().padStart(3, '0'), at: new Date().toISOString(), kind, version: app.getVersion(), platform: process.platform, arch: process.arch, osRelease: os.release(),
      electron: process.versions.electron, message: String(info.message || '').slice(0, 2000), stack: String(info.stack || '').slice(0, 6000), tail: String(info.tail || '').slice(-6000), asked: false };
    try { fs.mkdirSync(dir, { recursive: true }); fs.writeFileSync(path.join(dir, `${r.id}.json`), JSON.stringify(r, null, 1)); prune(); } catch {}
    log(`crash recorded: ${kind}: ${r.message.split('\n')[0]}`);
    if (mode() !== 'off') { queue.push(r); setTimeout(next, 1500); }
    return r;
  }
  function prune() { try { const f = fs.readdirSync(dir).filter(x => x.endsWith('.json')).sort(); for (const x of f.slice(0, Math.max(0, f.length - 20))) fs.rmSync(path.join(dir, x), { force: true }); } catch {} }
  function markAsked(r) { r.asked = true; try { fs.writeFileSync(path.join(dir, `${r.id}.json`), JSON.stringify(r, null, 1)); } catch {} }
  async function next() {
    if (asking || !queue.length || mode() === 'off') return;
    const r = queue.pop(); queue.length = 0; asking = true; // several crashes in a row → one question about the latest
    try {
      const w = BrowserWindow.getAllWindows().find(x => !x.isDestroyed() && x.isVisible() && !x.pixoraOutput);
      const o = { type: 'warning', message: r.kind === 'server' ? 'The PIXORA server crashed and was restarted' : `PIXORA: ${r.kind} crashed`,
        detail: `${sanitize(r.message).split('\n')[0].slice(0, 300)}\n\nSend a crash report to Booth Productions? It opens a pre-filled GitHub issue in your browser so you can check exactly what is sent (paths, IP addresses and keys are removed) and submit it with your GitHub sign-in.`,
        buttons: ['Send report…', 'Save report…', 'Don’t send'], defaultId: 0, cancelId: 2, noLink: true, checkboxLabel: 'Don’t ask about crash reports again', checkboxChecked: false };
      const { response, checkboxChecked } = w ? await dialog.showMessageBox(w, o) : await dialog.showMessageBox(o);
      markAsked(r);
      if (checkboxChecked) { cfg.crashReports = 'off'; saveCfg(); }
      if (response === 0) shell.openExternal(issueUrl(r));
      else if (response === 1) { const { filePath } = await dialog.showSaveDialog(w, { defaultPath: `PIXORA-crash-${r.id}.txt` }); if (filePath) fs.writeFileSync(filePath, sanitize(JSON.stringify(r, null, 2))); }
    } catch (e) { log('crash dialog: ' + e.message); }
    asking = false; if (queue.length) setTimeout(next, 500);
  }
  // reports from a run that ended in a crash (the app itself) are offered at the next start
  function offerPending() {
    if (mode() === 'off') return;
    try { const f = fs.readdirSync(dir).filter(x => x.endsWith('.json')).sort(); const last = f.length && JSON.parse(fs.readFileSync(path.join(dir, f[f.length - 1]), 'utf8'));
      if (last && !last.asked && Date.now() - Date.parse(last.at) < 7 * 864e5) { queue.push(last); setTimeout(next, 8000); } } catch {}
  }
  function menuItems() {
    return [{ label: 'Crash Reports', submenu: [
      { label: 'Ask to send a report after a crash', type: 'radio', checked: mode() === 'ask', click: () => { cfg.crashReports = 'ask'; saveCfg(); } },
      { label: 'Never ask', type: 'radio', checked: mode() === 'off', click: () => { cfg.crashReports = 'off'; saveCfg(); } },
      { type: 'separator' }, { label: 'Open Crash Reports Folder', click: () => { fs.mkdirSync(dir, { recursive: true }); shell.openPath(dir); } }] }];
  }
  return { record, offerPending, menuItems, dir };
};
module.exports.sanitize = sanitize;
module.exports.issueUrl = issueUrl;
