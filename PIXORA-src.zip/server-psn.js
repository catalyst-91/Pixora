'use strict';
// PosiStageNet (PSN 2) receiver: positions of performers, moving set pieces and flown screens from BlackTrax, Stage Precision,
// Zactrack, disguise, Kinesys bridges, lighting desks… over UDP multicast (236.10.10.10:56565 by default).
// Trackers reach the output windows; expressions read them with track(id, "x") so anything can follow a tracker.
const dgram = require('dgram');
function chunks(buf, off, end, fn) { // PSN chunk: u32 LE header = id (16 bits) | data length (15 bits) | has-sub-chunks (1 bit)
  while (off + 4 <= end) { const h = buf.readUInt32LE(off), id = h & 0xffff, len = (h >>> 16) & 0x7fff, sub = (h >>> 31) === 1; const d = off + 4; if (d + len > end) return; fn(id, d, d + len, sub); off = d + len; }
}
function parse(buf, into) { // fills into[trackerId] = { name, pos, speed, ori, status, target }; returns 'data' | 'info' | null
  if (!buf || buf.length < 4) return null; let kind = null;
  chunks(buf, 0, buf.length, (id, s, e) => {
    if (id === 0x6755) { kind = 'data'; chunks(buf, s, e, (cid, cs, ce) => { if (cid !== 0x0001) return; // tracker list
        chunks(buf, cs, ce, (tid, ts, te) => { const t = into[tid] || (into[tid] = { id: tid, name: '' });
          chunks(buf, ts, te, (fid, fs, fe) => { const v3 = () => [buf.readFloatLE(fs), buf.readFloatLE(fs + 4), buf.readFloatLE(fs + 8)];
            if (fe - fs >= 12 && fid === 0x0000) t.pos = v3(); else if (fe - fs >= 12 && fid === 0x0001) t.speed = v3(); else if (fe - fs >= 12 && fid === 0x0002) t.ori = v3();
            else if (fe - fs >= 4 && fid === 0x0003) t.status = buf.readFloatLE(fs); else if (fe - fs >= 12 && fid === 0x0005) t.target = v3(); });
          t.at = Date.now(); }); }); }
    else if (id === 0x6756) { kind = 'info'; chunks(buf, s, e, (cid, cs, ce) => { if (cid === 0x0001) into._system = buf.toString('utf8', cs, ce); if (cid !== 0x0002) return;
        chunks(buf, cs, ce, (tid, ts, te) => { const t = into[tid] || (into[tid] = { id: tid, name: '' }); chunks(buf, ts, te, (fid, fs, fe) => { if (fid === 0x0000) t.name = buf.toString('utf8', fs, fe); }); }); }); }
  });
  return kind;
}
// encoder, for tests and the panel's simulator: trackers [{ id, name, pos:[x,y,z] }] → [data packet, info packet]
function build(trackers, frame = 0) {
  const ch = (id, payload, sub) => { const h = Buffer.alloc(4); h.writeUInt32LE(((id & 0xffff) | ((payload.length & 0x7fff) << 16) | (sub ? 0x80000000 : 0)) >>> 0); return Buffer.concat([h, payload]); };
  const f3 = v => { const b = Buffer.alloc(12); b.writeFloatLE(v[0], 0); b.writeFloatLE(v[1], 4); b.writeFloatLE(v[2], 8); return b; };
  const hdr = Buffer.alloc(12); hdr.writeBigUInt64LE(BigInt(Date.now()) * 1000n, 0); hdr[8] = 2; hdr[9] = 3; hdr[10] = frame & 255; hdr[11] = 1;
  const data = ch(0x6755, Buffer.concat([ch(0x0000, hdr), ch(0x0001, Buffer.concat(trackers.map(t => ch(t.id, Buffer.concat([ch(0x0000, f3(t.pos || [0, 0, 0])), ch(0x0001, f3(t.speed || [0, 0, 0]))]), true))), true)]), true);
  const info = ch(0x6756, Buffer.concat([ch(0x0000, hdr), ch(0x0001, Buffer.from('PIXORA test')), ch(0x0002, Buffer.concat(trackers.map(t => ch(t.id, ch(0x0000, Buffer.from(t.name || 'Tracker ' + t.id)), true))), true)]), true);
  return [data, info];
}

module.exports = function (o) { // o: { getState, broadcast(obj, role), monitor }
  let sock = null, key = '', err = ''; const trackers = {}, stats = { packets: 0, rate: 0, from: '' }; let count = 0, last = Date.now(), pushT = null, lastPush = 0;
  const view = () => Object.values(trackers).filter(t => t && typeof t === 'object' && t.id != null).map(t => ({ id: t.id, name: t.name, pos: t.pos || [0, 0, 0], speed: t.speed, ori: t.ori, at: t.at || 0 }));
  function push() { if (pushT) return; pushT = setTimeout(() => { pushT = null; lastPush = Date.now(); const list = view(); o.broadcast({ t: 'psn', trackers: list }, 'output'); o.broadcast({ t: 'psn', trackers: list }, 'control'); }, Math.max(0, 33 - (Date.now() - lastPush))); }
  function listen() {
    const c = (o.getState().psn) || {}; const want = c.on ? `${c.group || '236.10.10.10'}:${Math.max(1, Math.min(65535, +c.port || 56565))}` : '';
    if (want === key) return; if (sock) { try { sock.close(); } catch {} sock = null; } key = want; err = ''; if (!want) return;
    const [group, port] = [want.split(':')[0], +want.split(':')[1]];
    sock = dgram.createSocket({ type: 'udp4', reuseAddr: true });
    sock.on('message', (msg, r) => { if (parse(msg, trackers)) { stats.packets++; count++; stats.from = r.address; push(); } });
    sock.on('error', e => { err = e.message; o.monitor('psn', e.message); try { sock.close(); } catch {} sock = null; key = ''; });
    sock.bind(port, () => { try { if (/^2(2[4-9]|3\d)\./.test(group)) sock.addMembership(group); } catch (e) { err = 'multicast: ' + e.message; } o.monitor('psn', `listening for PosiStageNet on ${group}:${port}`); });
  }
  const t = setInterval(() => { const n = Date.now(); stats.rate = Math.round(count * 1000 / Math.max(1, n - last)); count = 0; last = n; listen(); }, 1000); if (t.unref) t.unref();
  setTimeout(listen, 300);
  return { status: () => ({ on: !!key, listen: key, error: err, ...stats, trackers: view() }), listen, trackers: view };
};
module.exports.parse = parse; module.exports.build = build;
