/* PIXORA — stream inputs: SRT (caller / listener), RTMP (pull / listen for OBS), HLS, RTSP and UDP feeds pulled in with ffmpeg
 * and re-wrapped as live fragmented MP4, which output windows play through Media Source Extensions like any other video.
 * One ffmpeg per source however many outputs watch it; started on demand, kept alive while watched, restarted if the
 * feed drops. H.264 passes straight through ("copy") unless low-latency re-encoding is asked for. */
'use strict';
const { spawn } = require('child_process'), crypto = require('crypto');

const ALLOWED = /^(srt|rtmps?|https?|rtsp|udp|rtp):\/\//i;
const WHITELIST = 'srt,rtmp,rtmps,rtmpt,tcp,tls,http,https,crypto,udp,rtp,rtsp,hls,httpproxy';

function boxes(buf) { // top-level MP4 boxes in a buffer → [{ type, start, end }] (only complete ones)
  const out = []; let i = 0;
  while (i + 8 <= buf.length) {
    let size = buf.readUInt32BE(i); const type = buf.toString('latin1', i + 4, i + 8); let hdr = 8;
    if (size === 1) { if (i + 16 > buf.length) break; size = Number(buf.readBigUInt64BE(i + 8)); hdr = 16; }
    if (size < hdr) throw new Error('bad MP4 box ' + type);
    if (i + size > buf.length) break; out.push({ type, start: i, end: i + size }); i += size;
  }
  return { list: out, used: i };
}
function codecsFromInit(init) { // avc1.PPCCLL / hvc1 / mp4a.40.2 / opus from the moov
  const s = init.toString('latin1'); const c = [];
  const a = s.indexOf('avcC'); if (a > 0) c.push('avc1.' + [init[a + 5], init[a + 6], init[a + 7]].map(x => x.toString(16).padStart(2, '0')).join(''));
  else if (s.indexOf('hvcC') > 0) c.push('hvc1.1.6.L93.B0');
  if (s.indexOf('mp4a') > 0) c.push('mp4a.40.2'); else if (s.indexOf('Opus') > 0) c.push('opus');
  return c.join(',');
}
const describe = url => { try { const u = new URL(url); const listen = /mode=listener/.test(u.search) || u.searchParams.get('listen') === '1';
  return `${u.protocol.replace(':', '').toUpperCase()} ${listen ? 'listening on port ' + (u.port || '?') : (u.hostname + (u.port ? ':' + u.port : ''))}`; } catch { return url.slice(0, 60); } };

module.exports = function (ctx) {
  // ctx: { FFMPEG, ffmpegOk(), monitor(), broadcast() }
  const ins = new Map();
  const keyOf = (url, mode, mbps) => crypto.createHash('sha1').update(`${url}|${mode}|${mbps}`).digest('hex').slice(0, 12);

  // Two stages so a codec decision never drops the sender: ingest (protocol → MPEG-TS, video untouched) feeds the
  // packager (TS → fragmented MP4, video copied or re-encoded). Switching to re-encode restarts only the packager.
  function ingestArgs(s) {
    const u = s.url, live = /^(srt|udp|rtp|rtmp)/i.test(u), a = ['-hide_banner', '-loglevel', 'warning', '-nostdin', '-protocol_whitelist', WHITELIST, '-probesize', '2000000', '-analyzeduration', '1500000', '-fflags', live ? '+nobuffer+genpts' : '+genpts'];
    if (live) a.push('-flags', 'low_delay'); else if (/^https?:/i.test(u)) a.push('-re'); // HLS / files over HTTP: read at the stream's own pace, not as fast as the network allows
    if (/^rtmps?:\/\//i.test(u) && /[?&]listen=1/.test(u)) a.push('-listen', '1', '-i', u.replace(/[?&]listen=1/, '').replace(/\?$/, ''));
    else { if (/^rtmp/i.test(u)) a.push('-rw_timeout', '15000000'); if (/^rtsp/i.test(u)) a.push('-rtsp_transport', 'tcp'); a.push('-i', u); }
    a.push('-map', '0:v:0', '-map', '0:a:0?', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-ac', '2', '-f', 'mpegts', 'pipe:1');
    return a;
  }
  function packArgs(s) {
    const a = ['-hide_banner', '-loglevel', 'warning', '-fflags', '+genpts+nobuffer', '-probesize', '1000000', '-analyzeduration', '1000000', '-f', 'mpegts', '-i', 'pipe:0', '-map', '0:v:0', '-map', '0:a:0?'];
    if (s.mode === 'encode' || s.forceEncode) a.push('-c:v', 'libx264', '-preset', 'veryfast', '-tune', 'zerolatency', '-pix_fmt', 'yuv420p', '-profile:v', 'high', '-g', '30', '-keyint_min', '30', '-sc_threshold', '0', '-b:v', `${s.mbps}M`, '-maxrate', `${s.mbps}M`, '-bufsize', `${s.mbps}M`);
    else a.push('-c:v', 'copy');
    a.push('-c:a', 'aac', '-b:a', '160k', // re-encode: with empty_moov a copied ADTS stream leaves esds without its AudioSpecificConfig and Chrome's MSE rejects it
       '-f', 'mp4', '-movflags', 'frag_keyframe+empty_moov+default_base_moof', '-frag_duration', '500000', 'pipe:1');
    return a;
  }
  function startPack(s) {
    if (s.pack) { const old = s.pack; s.pack = null; old.removeAllListeners('close'); old.kill('SIGKILL'); }
    s.buf = Buffer.alloc(0); s.init = null; s.ftyp = null; s.last = null; s.pend = null; s.codecs = '';
    for (const v of s.viewers) try { v.end(); } catch {} s.viewers.clear(); // a new init segment: players reconnect
    const p = s.pack = spawn(ctx.FFMPEG, packArgs(s), { windowsHide: true });
    p.stdin.on('error', () => {}); p.stdout.on('data', d => { try { feed(s, d); } catch (e) { s.error = e.message; p.kill('SIGKILL'); } });
    p.stderr.on('data', d => { const t = String(d).trim().split('\n').pop(); if (t) s.lastLog = t.slice(0, 300); });
    p.on('close', () => { if (s.pack === p) { s.pack = null; if (s.proc && !s.closed) setTimeout(() => s.proc && !s.pack && startPack(s), 500); } });
  }
  function start(s) {
    if (s.proc || s.closed) return; s.status = 'connecting'; s.error = '';
    const p = s.proc = spawn(ctx.FFMPEG, ingestArgs(s), { windowsHide: true }); s.startedAt = Date.now(); s.bytes = 0;
    startPack(s);
    p.stdout.on('data', d => { if (s.pack && s.pack.stdin.writable) s.pack.stdin.write(d); });
    p.stderr.on('data', d => { const t = String(d).trim().split('\n').pop(); if (t) s.lastLog = t.slice(0, 300); });
    p.on('error', e => { s.error = e.code === 'ENOENT' ? 'ffmpeg is not installed — stream inputs need it (Comp ▸ Media)' : e.message; });
    p.on('close', code => { s.proc = null; const was = s.status; s.status = s.closed ? 'stopped' : 'reconnecting';
      if (s.pack) { const k = s.pack; s.pack = null; k.removeAllListeners('close'); k.kill('SIGKILL'); }
      if (!s.error && s.lastLog && code) s.error = s.lastLog; for (const v of s.viewers) try { v.end(); } catch {} s.viewers.clear();
      if (was === 'live') ctx.monitor('stream', `stream input lost: ${describe(s.url)}${s.error ? ' — ' + s.error : ''}`);
      if (!s.closed) s.retry = setTimeout(() => start(s), Math.min(10000, 1000 * (1 + s.fails++))); });
  }
  function feed(s, d) {
    s.buf = s.buf.length ? Buffer.concat([s.buf, d]) : d; const { list, used } = boxes(s.buf);
    for (const b of list) { const chunk = s.buf.subarray(b.start, b.end);
      if (b.type === 'ftyp') s.ftyp = Buffer.from(chunk);
      else if (b.type === 'moov') { s.init = Buffer.concat([s.ftyp || Buffer.alloc(0), chunk]); s.codecs = codecsFromInit(s.init);
        const prof = (/avc1\.([0-9a-f]{2})/.exec(s.codecs) || [])[1]; // browsers decode Baseline / Main / High 8-bit 4:2:0, not High 10 / 4:2:2 / 4:4:4
        if (s.mode === 'auto' && (!prof || !['42', '4d', '58', '64'].includes(prof)) && !s.forceEncode) { s.forceEncode = true; s.error = ''; startPack(s); return; } // not playable H.264: re-encode, the sender stays connected
        for (const w of s.waiting.splice(0)) w(); }
      else if (b.type === 'moof') s.pend = Buffer.from(chunk);
      else if (b.type === 'mdat' && s.pend) { const frag = Buffer.concat([s.pend, chunk]); s.pend = null; s.last = frag; s.frags++; s.bytes += frag.length; s.lastAt = Date.now();
        if (s.status !== 'live') { s.status = 'live'; s.error = ''; s.fails = 0; ctx.monitor('stream', `stream input live: ${describe(s.url)} (${s.codecs})`); }
        for (const v of s.viewers) { if (!v.started) { v.write(s.init); v.started = true; } if (v.writableLength < 8e6) v.write(frag); else { v.end(); s.viewers.delete(v); } } } }
    s.buf = used >= s.buf.length ? Buffer.alloc(0) : s.buf.subarray(used);
  }
  function get(url, mode, mbps) {
    url = String(url || '').trim(); if (!ALLOWED.test(url)) throw Object.assign(new Error('stream URLs start with srt://, rtmp://, rtmps://, http(s):// (HLS), rtsp:// or udp://'), { status: 400 });
    mode = ['auto', 'copy', 'encode'].includes(mode) ? mode : 'auto'; mbps = Math.max(1, Math.min(50, +mbps || 8));
    const k = keyOf(url, mode, mbps); let s = ins.get(k);
    if (!s) { s = { key: k, url, mode, mbps, viewers: new Set(), waiting: [], fails: 0, frags: 0, bytes: 0, closed: false }; ins.set(k, s); }
    s.touched = Date.now(); clearTimeout(s.idle); start(s); return s;
  }
  function release(s) { clearTimeout(s.idle); s.idle = setTimeout(() => { if (s.viewers.size || Date.now() - s.touched < 15000) return; stop(s); }, 20000); }
  function stop(s) { s.closed = true; clearTimeout(s.retry); if (s.pack) { s.pack.removeAllListeners('close'); s.pack.kill('SIGKILL'); } if (s.proc) s.proc.kill('SIGKILL'); for (const v of s.viewers) try { v.end(); } catch {} ins.delete(s.key); }
  const view = s => ({ key: s.key, url: s.url.replace(/(passphrase|streamid|key)=[^&]*/gi, '$1=•••'), label: describe(s.url), mode: s.forceEncode ? 'encode' : s.mode, status: s.status, codecs: s.codecs, viewers: s.viewers.size,
    error: s.error || '', kbps: s.lastAt && Date.now() - s.lastAt < 3000 ? Math.round(s.bytes * 8 / 1000 / Math.max(1, (Date.now() - s.startedAt) / 1000)) : 0, live: s.status === 'live' && Date.now() - (s.lastAt || 0) < 3000 });

  async function route(req, res, p, url, send) {
    if (!p.startsWith('/api/streamin')) return false;
    if (p === '/api/streamin/list') { send(res, 200, { ffmpeg: ctx.ffmpegOk(), inputs: [...ins.values()].map(view) }); return true; }
    let s; try { s = get(url.searchParams.get('url'), url.searchParams.get('mode'), url.searchParams.get('mbps')); } catch (e) { send(res, e.status || 500, { error: e.message }); return true; }
    if (p === '/api/streamin/info') { // waits (up to the timeout) for the first picture so the player knows the codecs
      if (!s.init) await new Promise(r => { const t = setTimeout(r, Math.max(500, Math.min(20000, +url.searchParams.get('wait') || 8000))); s.waiting.push(() => { clearTimeout(t); r(); }); });
      release(s); send(res, 200, Object.assign(view(s), { mime: s.codecs ? `video/mp4; codecs="${s.codecs}"` : '' })); return true; }
    if (p === '/api/streamin/live') {
      res.writeHead(200, { 'Content-Type': 'video/mp4', 'Cache-Control': 'no-store', 'X-Codecs': s.codecs || '', 'X-Accel-Buffering': 'no' });
      if (s.init && s.last) { res.write(s.init); res.write(s.last); res.started = true; } // join at the newest fragment (each starts on a keyframe)
      s.viewers.add(res); s.touched = Date.now();
      req.on('close', () => { s.viewers.delete(res); release(s); }); return true; }
    if (p === '/api/streamin/stop' && req.method === 'POST') { stop(s); send(res, 200, { ok: true }); return true; }
    return false;
  }
  return { route, list: () => [...ins.values()].map(view), stopAll: () => { for (const s of [...ins.values()]) stop(s); }, boxes, codecsFromInit };
};
