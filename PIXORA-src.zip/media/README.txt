Put your videos and images here (or add external drives in the app under Sources & Drives).
