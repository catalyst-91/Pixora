/* PIXORA — live captions.
   Speech-to-text arrives from a browser controller (Web Speech), from any external captioner over HTTP / OSC, or from a
   CART writer. Lines are wrapped for the screen and published as the push data feed "captions", so any title can show
   them with {{captions.text}} / {{captions.line1}} / {{captions.line2}} / {{captions.partial}}. A transcript is kept
   (TXT / SRT download). */
'use strict';

module.exports = function captions(ctx) {
  const { setFeed, getState, markDirty, monitor } = ctx;
  const lanes = { 1: { lines: [], partial: '', partialAt: 0 }, 2: { lines: [], partial: '', partialAt: 0 } }; // lane 2 = second language (translation)
  const lines = lanes[1].lines; let partial = '', partialAt = 0, startedAt = 0, lastPush = 0, pushT = null, source = '', active = false, clearT = null;
  const opts = () => Object.assign({ lines: 2, chars: 42, clearAfter: 6, upper: false, censor: true }, (getState().captions || {}));

  const BAD = /\b(fuck\w*|shit\w*|cunt\w*|bitch\w*|motherfuck\w*)\b/gi;
  const clean = t => { let s = String(t || '').replace(/\s+/g, ' ').trim(); const o = opts(); if (o.censor) s = s.replace(BAD, w => w[0] + '*'.repeat(w.length - 1)); if (o.upper) s = s.toUpperCase(); return s; };
  function wrap(text, width) { // greedy word wrap
    const out = []; let cur = '';
    for (const w of text.split(' ')) { if (!w) continue; if (!cur) cur = w; else if ((cur + ' ' + w).length <= width) cur += ' ' + w; else { out.push(cur); cur = w; } while (cur.length > width) { out.push(cur.slice(0, width)); cur = cur.slice(width); } }
    if (cur) out.push(cur); return out;
  }
  function rowsOf(L, part) { const o = opts(); let k = L.length; while (k > 0 && !L[k - 1].gap && L.length - k < 6) k--; const recent = L.slice(k).map(l => l.text).join(' '); // nothing from before the last clear
    return wrap((recent + (part ? ' ' + part : '')).trim(), Math.max(10, o.chars | 0)).slice(-Math.max(1, o.lines | 0)); }
  function view() { // what the screen shows: the last N wrapped rows of recent finished text + the words in progress
    const o = opts(), n = Math.max(2, o.lines | 0); const rows = rowsOf(lines, partial), L2 = lanes[2], rows2 = rowsOf(L2.lines, L2.partial);
    const v = { text: rows.join('\n'), partial, last: lines.length ? lines[lines.length - 1].text : '', on: active, source, count: lines.length,
      text2: rows2.join('\n'), partial2: L2.partial, last2: L2.lines.length ? L2.lines[L2.lines.length - 1].text : '' };
    for (let i = 0; i < n; i++) { v['line' + (i + 1)] = rows[i] || ''; v['line' + (i + 1) + 'b'] = rows2[i] || ''; }
    return v;
  }
  function push(now) {
    clearTimeout(pushT); pushT = null;
    const gap = Date.now() - lastPush; if (!now && gap < 120) { pushT = setTimeout(() => push(true), 120 - gap); return; }
    lastPush = Date.now(); ensureFeed(); setFeed('captions', view(), 'captions');
  }
  function ensureFeed() { const s = getState(); if (!s.feeds.find(f => f.id === 'captions')) { s.feeds.push({ id: 'captions', name: 'Live captions', type: 'push', url: '', interval: 5, on: true }); markDirty(); } }
  function scheduleClear() { // blank the captions after a pause in speech
    clearTimeout(clearT); const s = +opts().clearAfter; if (!(s > 0)) return;
    clearT = setTimeout(() => { if (partial) return; gap(); push(true); }, s * 1000);
  }
  const gap = () => { for (const L of [lanes[1], lanes[2]]) { L.lines.push({ text: '', start: Date.now(), end: Date.now(), gap: true }); L.partial = ''; } };
  function add(text, final, src, lane) {
    if (+lane === 2) { const L = lanes[2], t = clean(text); if (final) { if (t) L.lines.push({ text: t, start: L.partialAt || Date.now(), end: Date.now() }); L.partial = ''; L.partialAt = 0; if (L.lines.length > 5000) L.lines.splice(0, L.lines.length - 5000); }
      else { if (!L.partial && t) L.partialAt = Date.now(); L.partial = t; } push(final); return true; }
    const t = clean(text); source = src || source || 'external'; if (!startedAt) startedAt = Date.now(); active = true;
    if (final) { if (t) lines.push({ text: t, start: partialAt || Date.now(), end: Date.now() }); partial = ''; partialAt = 0; if (lines.length > 5000) lines.splice(0, lines.length - 5000); }
    else { if (!partial && t) partialAt = Date.now(); partial = t; }
    push(final); scheduleClear(); return true;
  }
  function clear() { partial = ''; gap(); push(true); }
  function reset() { lines.length = 0; lanes[2].lines.length = 0; lanes[2].partial = ''; partial = ''; startedAt = 0; push(true); }
  function setActive(on, src) { active = !!on; if (src) source = src; if (on) monitor('captions', 'live captions started (' + (src || 'external') + ')'); push(true); }

  const pad = (n, w = 2) => String(n).padStart(w, '0');
  const ts = ms => { ms = Math.max(0, ms); return `${pad(Math.floor(ms / 3600000))}:${pad(Math.floor(ms / 60000) % 60)}:${pad(Math.floor(ms / 1000) % 60)},${pad(ms % 1000, 3)}`; };
  function transcript(fmt, lane) {
    const real = (+lane === 2 ? lanes[2].lines : lines).filter(l => l.text && !l.gap); const t0 = startedAt || (real[0] && real[0].start) || Date.now();
    if (fmt === 'srt') return real.map((l, i) => `${i + 1}\n${ts(l.start - t0)} --> ${ts(Math.max(l.end, l.start + 1200) - t0)}\n${wrap(l.text, 42).join('\n')}\n`).join('\n');
    return real.map(l => `[${new Date(l.start).toLocaleTimeString()}] ${l.text}`).join('\n') + '\n';
  }
  return { add, clear, reset, setActive, view, transcript, count: () => lines.filter(l => l.text).length };
};
