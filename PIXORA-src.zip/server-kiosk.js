'use strict';
// Kiosk / digital-signage mode
//  - day-parts: "what plays when" windows (weekdays, times — overnight is fine — and optional campaign dates). The server
//    keeps the right one on air: it applies a day-part's action when its window starts AND whenever PIXORA starts up or the
//    kiosk is switched on inside the window (after a power cut the screen comes back with the right content, unlike a
//    one-shot scheduled action). Outside every window the "otherwise" action runs.
//  - lock: control screens show a lock until someone enters the unlock PIN; the server refuses their commands meanwhile.
const DAY = 1440;
const mins = s => { const m = /^(\d{1,2}):(\d{2})$/.exec(String(s || '')); return m ? Math.min(DAY, +m[1] * 60 + +m[2]) : null; };
const ymd = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

function defaults() { return { on: false, locked: false, dayparts: [], otherwise: { type: 'none' }, relockMin: 10 }; }
function normalize(st) {
  const k = st.kiosk = Object.assign(defaults(), st.kiosk && typeof st.kiosk === 'object' ? st.kiosk : {});
  if (!Array.isArray(k.dayparts)) k.dayparts = [];
  k.dayparts = k.dayparts.filter(d => d && typeof d === 'object').slice(0, 200).map((d, i) => Object.assign({ id: 'dp' + i, name: 'Day-part', on: true, days: [0, 1, 2, 3, 4, 5, 6], from: '09:00', to: '17:00', dateFrom: '', dateTo: '', action: { type: 'none' } }, d));
  for (const d of k.dayparts) { if (!Array.isArray(d.days)) d.days = []; d.days = d.days.map(Number).filter(x => x >= 0 && x <= 6); }
  if (!k.otherwise || typeof k.otherwise !== 'object') k.otherwise = { type: 'none' };
  k.relockMin = Math.max(1, Math.min(240, +k.relockMin || 10));
}
// is day-part d on air at date `t`? A window that ends before it starts runs past midnight; it belongs to the day it starts on
function inWindow(d, t) {
  if (!d || d.on === false) return false;
  const a = mins(d.from), b = mins(d.to); if (a == null || b == null) return false;
  const m = t.getHours() * 60 + t.getMinutes(), day = t.getDay(), startDay = new Date(t);
  let ok;
  if (a < b) ok = d.days.includes(day) && m >= a && m < b;
  else if (a === b) ok = d.days.includes(day); // 00:00–00:00 → all day
  else if (m >= a) ok = d.days.includes(day);
  else if (m < b) { startDay.setDate(startDay.getDate() - 1); ok = d.days.includes(startDay.getDay()); }
  else ok = false;
  if (!ok) return false;
  const date = ymd(startDay); // campaign dates follow the day the window started
  if (d.dateFrom && date < d.dateFrom) return false; if (d.dateTo && date > d.dateTo) return false;
  return true;
}
const current = (k, t) => (k.dayparts || []).find(d => inWindow(d, t)) || null; // the first matching day-part wins, so order = priority
function nextChange(k, t) { // when the on-air day-part next changes (minute resolution, up to 8 days ahead)
  const id = (current(k, t) || {}).id || null; const x = new Date(t); x.setSeconds(0, 0);
  for (let i = 1; i <= 8 * DAY; i++) { x.setMinutes(x.getMinutes() + 1); const c = current(k, x); if (((c && c.id) || null) !== id) return { at: x.getTime(), to: c ? c.name : null }; }
  return null;
}

module.exports = function (o) { // o: { getState, run(action, why), monitor, broadcast, now }
  const now = o.now || (() => new Date());
  let lastKey = null, lastOn = false;
  const view = () => { const k = o.getState().kiosk, t = now(), c = current(k, t); return { on: k.on, locked: k.locked, current: c ? { id: c.id, name: c.name } : null, next: k.on ? nextChange(k, t) : null, clock: t.getTime() }; };
  function tick(force) {
    const k = o.getState().kiosk; if (!k) return;
    if (!k.on) { lastOn = false; lastKey = null; return; }
    const c = current(k, now()), key = c ? c.id + ':' + JSON.stringify(c.action) : 'otherwise:' + JSON.stringify(k.otherwise);
    if (!force && lastOn && key === lastKey) return;
    lastOn = true; lastKey = key;
    const act = c ? c.action : k.otherwise;
    o.monitor('kiosk', c ? `day-part “${c.name}” on air` : 'outside every day-part — running “otherwise”');
    if (act && act.type && act.type !== 'none') { try { o.run(act, 'kiosk'); } catch (e) { o.monitor('kiosk', 'error ' + e.message); } }
    o.broadcast({ t: 'kiosk', status: view() });
  }
  const timer = setInterval(() => tick(false), 5000); if (timer.unref) timer.unref();
  return {
    tick, view, current: t => current(o.getState().kiosk, t || now()),
    // lock: true when this client may not send commands right now
    blocked(c, peek) { const k = o.getState().kiosk; if (!k || !k.on || !k.locked || !c || typeof c !== 'object' || c.role === 'mirror') return false;
      if (c.kioskUntil && Date.now() < c.kioskUntil) { if (!peek) c.kioskUntil = Date.now() + k.relockMin * 60000; return false; } return true; }, // peek: just look, don't count as activity
    unlock(c, pin, expected) { if (expected && String(pin || '') !== String(expected)) return false; const k = o.getState().kiosk; c.kioskUntil = Date.now() + (k ? k.relockMin : 10) * 60000; return true; },
    relock(c) { c.kioskUntil = 0; },
  };
};
module.exports.normalize = normalize; module.exports.inWindow = inWindow; module.exports.current = current; module.exports.nextChange = nextChange; module.exports.defaults = defaults;
