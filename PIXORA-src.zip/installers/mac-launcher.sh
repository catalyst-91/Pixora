#!/bin/bash
# PIXORA.app launcher — Booth Productions
# Starts the PIXORA engine in the background and opens the controller. Opening the app again while PIXORA is
# running shows the PIXORA menu (controller, output, manual, media folder, stop).

APP_CONTENTS="$(cd "$(dirname "$0")/.." && pwd)"
APP_DIR="$APP_CONTENTS/Resources/app"
SUPPORT="$HOME/Library/Application Support/PIXORA"
LOGDIR="$HOME/Library/Logs/PIXORA"
LOG="$LOGDIR/pixora.log"
MEDIA="${PIXORA_MEDIA:-$HOME/Movies/PIXORA}"
SETTINGS="$SUPPORT/launcher.conf"
mkdir -p "$SUPPORT/data" "$LOGDIR" "$MEDIA"

# Apps opened from Finder get a bare PATH — add the usual Node / ffmpeg locations (Homebrew, installer, nvm, Volta, asdf)
export PATH="/opt/homebrew/bin:/usr/local/bin:$HOME/.volta/bin:$HOME/.asdf/shims:$HOME/.local/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"
if [ -d "$HOME/.nvm/versions/node" ]; then
  NVM_NODE="$(ls -d "$HOME"/.nvm/versions/node/v*/bin 2>/dev/null | tail -1)"
  [ -n "$NVM_NODE" ] && export PATH="$NVM_NODE:$PATH"
fi

PORT=8080
[ -f "$SETTINGS" ] && . "$SETTINGS"   # may set PORT=..., PIN=..., MEDIA_DIRS=...
URL="http://localhost:$PORT"

say_dialog() { # $1 message, $2 buttons (AppleScript list), $3 default button → prints the button pressed
  /usr/bin/osascript -e "on run argv" -e "display dialog (item 1 of argv) with title \"PIXORA\" buttons {$2} default button \"$3\" with icon (POSIX file \"$APP_CONTENTS/Resources/PIXORA.icns\")" -e "button returned of result" -e "end run" "$1" 2>/dev/null
}
notify() { /usr/bin/osascript -e "display notification \"$1\" with title \"PIXORA\"" >/dev/null 2>&1; }

open_app_window() { # open a URL in a clean Chrome/Edge/Brave app window when available, otherwise the default browser
  local u="$1"
  for b in "Google Chrome" "Microsoft Edge" "Brave Browser" "Chromium"; do
    if [ -d "/Applications/$b.app" ] || [ -d "$HOME/Applications/$b.app" ]; then
      /usr/bin/open -na "$b" --args --app="$u" --autoplay-policy=no-user-gesture-required >/dev/null 2>&1 && return
    fi
  done
  /usr/bin/open "$u"
}

is_pixora_running() { /usr/bin/curl -fs --max-time 1 "$URL/api/info" 2>/dev/null | grep -q '"pinRequired"'; }
port_in_use() { /usr/bin/curl -s --max-time 1 -o /dev/null "$URL/" 2>/dev/null || /usr/sbin/lsof -nP -iTCP:"$PORT" -sTCP:LISTEN >/dev/null 2>&1; }

pixora_menu() {
  local choice
  choice=$(/usr/bin/osascript <<OSA 2>/dev/null
set opts to {"Open controller", "Open output window", "Open manual", "Show media folder", "Show log", "Stop PIXORA"}
set r to choose from list opts with title "PIXORA" with prompt "PIXORA is running on port $PORT" default items {"Open controller"} OK button name "Go" cancel button name "Close"
if r is false then return ""
return item 1 of r
OSA
)
  case "$choice" in
    "Open controller") open_app_window "$URL/" ;;
    "Open output window") open_app_window "$URL/output" ;;
    "Open manual") /usr/bin/open "$URL/manual/" ;;
    "Show media folder") /usr/bin/open "$MEDIA" ;;
    "Show log") /usr/bin/open -a Console "$LOG" 2>/dev/null || /usr/bin/open "$LOG" ;;
    "Stop PIXORA")
      if [ -f "$SUPPORT/pixora.pid" ]; then kill "$(cat "$SUPPORT/pixora.pid")" 2>/dev/null; rm -f "$SUPPORT/pixora.pid"; fi
      /usr/bin/pkill -f "PIXORA.app/Contents/Resources/app/server.js" 2>/dev/null
      sleep 0.5; is_pixora_running && sleep 1.5
      if is_pixora_running; then say_dialog "PIXORA did not stop. It may have been started from a Terminal — stop it there with Ctrl+C." '"OK"' "OK" >/dev/null
      else notify "PIXORA stopped"; fi ;;
  esac
}

# Already running → menu
if is_pixora_running; then pixora_menu; exit 0; fi

if port_in_use; then
  say_dialog "Port $PORT is already used by another program, so PIXORA can't start.

To use a different port, create this file:
~/Library/Application Support/PIXORA/launcher.conf
containing the line:  PORT=8090" '"OK"' "OK" >/dev/null
  exit 1
fi

# Node.js (18+; 22 recommended): a runtime bundled inside the app wins (installer builds), then the system one
NODE=""
for cand in "$APP_CONTENTS/Resources/node/$(uname -m)/bin/node" "$APP_CONTENTS/Resources/node/bin/node"; do [ -x "$cand" ] && NODE="$cand" && break; done
[ -z "$NODE" ] && NODE="$(command -v node)"
NODE_MAJOR=0; [ -n "$NODE" ] && NODE_MAJOR="$("$NODE" -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)"
if [ -z "$NODE" ] || [ "$NODE_MAJOR" -lt 18 ]; then
  r=$(say_dialog "PIXORA needs Node.js (free) to run its video engine.

Download the macOS installer (LTS), run it, then open PIXORA again." '"Cancel", "Download Node.js"' "Download Node.js")
  [ "$r" = "Download Node.js" ] && /usr/bin/open "https://nodejs.org/en/download"
  exit 1
fi

# first run: tell the user about ffmpeg once (only needed for AVI/WMV/MPEG-2/ProRes conversion)
if ! command -v ffmpeg >/dev/null && [ ! -f "$SUPPORT/.ffmpeg-tip" ]; then
  touch "$SUPPORT/.ffmpeg-tip"
  say_dialog "Tip: MP4, MOV (H.264/HEVC) and WebM play straight away.

To also play AVI, WMV, MPEG-2, ProRes and MXF files, install ffmpeg (free). With Homebrew:  brew install ffmpeg" '"OK"' "OK" >/dev/null
fi

# Start the engine (detached, survives this launcher exiting); data in Application Support, media in ~/Movies/PIXORA
cd "$APP_DIR" || exit 1
echo "---- PIXORA start $(date) · node $("$NODE" -v) · port $PORT" >> "$LOG"
PORT="$PORT" DATA_DIR="$SUPPORT/data" MEDIA_DIR="$MEDIA" PIN="${PIN:-}" MEDIA_DIRS="${MEDIA_DIRS:-}" \
  /usr/bin/nohup "$NODE" "$APP_DIR/server.js" >> "$LOG" 2>&1 &
echo $! > "$SUPPORT/pixora.pid"

for i in $(seq 1 40); do is_pixora_running && break; sleep 0.25; done
if ! is_pixora_running; then
  r=$(say_dialog "PIXORA couldn't start. The log has the details." '"Close", "Show log"' "Show log")
  [ "$r" = "Show log" ] && /usr/bin/open "$LOG"
  exit 1
fi
notify "Running on port $PORT — open PIXORA again for the menu"
open_app_window "$URL/"
exit 0
