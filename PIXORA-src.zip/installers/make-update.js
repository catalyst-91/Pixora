#!/usr/bin/env node
// Packages the current PIXORA app files as an in-app update and writes the feed manifest.
//   node installers/make-update.js [https://your-site/pixora/]   → dist/update/PIXORA-<ver>.zip + latest.json
// Upload both files to your website; set that latest.json URL in PIXORA ▸ More ▸ Updates on each machine.
const fs = require('fs'), path = require('path'), zlib = require('zlib'), crypto = require('crypto');
const ROOT = path.join(__dirname, '..'), OUT = path.join(ROOT, 'dist', 'update');
const ver = require(path.join(ROOT, 'package.json')).version, base = process.argv[2] || '';
const crcTable = new Uint32Array(256).map((_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; return c >>> 0; });
const crc32 = b => { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = crcTable[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
const files = [];
const add = rel => { const abs = path.join(ROOT, rel); if (fs.statSync(abs).isDirectory()) fs.readdirSync(abs).forEach(f => add(path.join(rel, f))); else files.push(rel.split(path.sep).join('/')); };
fs.readdirSync(ROOT).filter(f => /^server[\w-]*\.js$/.test(f)).concat(['package.json', 'README.md', 'public']).forEach(add);
const parts = [], central = []; let off = 0;
for (const rel of files) {
  const data = fs.readFileSync(path.join(ROOT, rel)), name = Buffer.from('PIXORA/' + rel), def = zlib.deflateRawSync(data, { level: 9 }), crc = crc32(data);
  const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x0800, 6); lh.writeUInt16LE(8, 8); lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(def.length, 18); lh.writeUInt32LE(data.length, 22); lh.writeUInt16LE(name.length, 26);
  const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x0800, 8); ch.writeUInt16LE(8, 10); ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(def.length, 20); ch.writeUInt32LE(data.length, 24); ch.writeUInt16LE(name.length, 28); ch.writeUInt32LE(off, 42);
  parts.push(lh, name, def); central.push(ch, name); off += 30 + name.length + def.length;
}
const cd = Buffer.concat(central), end = Buffer.alloc(22); end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10); end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(off, 16);
const zip = Buffer.concat([...parts, cd, end]); fs.mkdirSync(OUT, { recursive: true });
const zipName = `PIXORA-${ver}.zip`; fs.writeFileSync(path.join(OUT, zipName), zip);
const manifest = { version: ver, url: base ? base.replace(/\/?$/, '/') + zipName : zipName, sha256: crypto.createHash('sha256').update(zip).digest('hex'), size: zip.length, released: new Date().toISOString().slice(0, 10), notes: process.env.NOTES || `PIXORA ${ver}`,
  // desktop-app installers (from the GitHub build) — the installed app offers these instead of patching itself
  installers: { win: `PIXORA-Setup-${ver}.exe`, 'mac-arm64': `PIXORA-${ver}-mac-arm64.dmg`, 'mac-x64': `PIXORA-${ver}-mac-x64.dmg`, linux: `PIXORA-${ver}-linux-x86_64.AppImage` } };
fs.writeFileSync(path.join(OUT, 'latest.json'), JSON.stringify(manifest, null, 2));
console.log(`✓ ${files.length} files → dist/update/${zipName} (${(zip.length / 1048576).toFixed(1)} MB)\n✓ dist/update/latest.json  sha256 ${manifest.sha256.slice(0, 16)}…`);
