#!/bin/bash
# Build PIXORA.app + PIXORA-<version>.dmg with Node.js bundled (no separate install), for Intel and Apple Silicon.
# Run on a Mac from the PIXORA folder:   bash installers/build-mac.sh
# Optional signing & notarisation (removes the "can't verify" warning) — set before running:
#   export PIXORA_SIGN_ID="Developer ID Application: Booth Productions (TEAMID)"
#   export PIXORA_NOTARY_PROFILE="pixora-notary"   # created once with: xcrun notarytool store-credentials pixora-notary
set -euo pipefail
cd "$(dirname "$0")/.."
VER=$(node -p "require('./package.json').version")
NODE_VER="${NODE_VER:-v22.11.0}"
OUT="dist/mac"; APP="$OUT/PIXORA.app"; C="$APP/Contents"
rm -rf "$OUT"; mkdir -p "$C/MacOS" "$C/Resources/app" "$C/Resources/node"

echo "▸ App files"
cp installers/mac-launcher.sh "$C/MacOS/PIXORA"; chmod 755 "$C/MacOS/PIXORA"
sed "s#<string>1.1.0</string>#<string>$VER</string>#g" installers/mac-Info.plist > "$C/Info.plist"
printf 'APPL????' > "$C/PkgInfo"; cp installers/PIXORA.icns "$C/Resources/"
cp -R server*.js package.json README.md public "$C/Resources/app/"

echo "▸ Node.js $NODE_VER (arm64 + x86_64)"
for A in arm64 x64; do
  T="node-$NODE_VER-darwin-$A"; curl -fsSL "https://nodejs.org/dist/$NODE_VER/$T.tar.gz" -o "/tmp/$T.tar.gz"
  curl -fsSL "https://nodejs.org/dist/$NODE_VER/SHASUMS256.txt" | grep " $T.tar.gz\$" | (cd /tmp && shasum -a 256 -c -)
  D="$C/Resources/node/$([ $A = x64 ] && echo x86_64 || echo arm64)/bin"; mkdir -p "$D"
  tar -xzf "/tmp/$T.tar.gz" -C /tmp "$T/bin/node"; mv "/tmp/$T/bin/node" "$D/node"; chmod 755 "$D/node"
done

if [ -n "${PIXORA_SIGN_ID:-}" ]; then
  echo "▸ Signing with $PIXORA_SIGN_ID"
  cat > /tmp/pixora-ent.plist <<EOF
<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict><key>com.apple.security.cs.allow-jit</key><true/><key>com.apple.security.cs.allow-unsigned-executable-memory</key><true/><key>com.apple.security.network.server</key><true/><key>com.apple.security.network.client</key><true/></dict></plist>
EOF
  for n in "$C"/Resources/node/*/bin/node; do codesign --force --options runtime --timestamp --entitlements /tmp/pixora-ent.plist --sign "$PIXORA_SIGN_ID" "$n"; done
  codesign --force --options runtime --timestamp --entitlements /tmp/pixora-ent.plist --sign "$PIXORA_SIGN_ID" "$APP"
  codesign --verify --deep --strict "$APP"
fi

echo "▸ Disk image"
STAGE="$OUT/dmg"; mkdir -p "$STAGE"; cp -R "$APP" "$STAGE/"; ln -s /Applications "$STAGE/Applications"
cp PIXORA-User-Manual.pdf "$STAGE/" 2>/dev/null || true
hdiutil create -volname "PIXORA $VER" -srcfolder "$STAGE" -ov -format UDZO "$OUT/PIXORA-$VER.dmg"
rm -rf "$STAGE"

if [ -n "${PIXORA_SIGN_ID:-}" ] && [ -n "${PIXORA_NOTARY_PROFILE:-}" ]; then
  echo "▸ Notarising"
  codesign --sign "$PIXORA_SIGN_ID" --timestamp "$OUT/PIXORA-$VER.dmg"
  xcrun notarytool submit "$OUT/PIXORA-$VER.dmg" --keychain-profile "$PIXORA_NOTARY_PROFILE" --wait
  xcrun stapler staple "$OUT/PIXORA-$VER.dmg"
fi
echo "✓ $OUT/PIXORA-$VER.dmg"
