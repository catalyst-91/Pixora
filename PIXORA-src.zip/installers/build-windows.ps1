# Build PIXORA-Setup-<version>.exe with Node.js bundled (no separate install).
# Run in PowerShell from the PIXORA folder:   powershell -ExecutionPolicy Bypass -File installers\build-windows.ps1
# Needs Inno Setup 6 (free: winget install JRSoftware.InnoSetup). Optional: Go (to rebuild PIXORA.exe), ffmpeg to bundle.
# Optional code signing (removes the SmartScreen warning):
#   $env:PIXORA_SIGN_PFX = "C:\certs\booth.pfx"; $env:PIXORA_SIGN_PASS = "…"
$ErrorActionPreference = 'Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
$ver = (Get-Content package.json | ConvertFrom-Json).version
$nodeVer = if ($env:NODE_VER) { $env:NODE_VER } else { 'v22.11.0' }
$out = 'dist\win'; $pkg = "$out\PIXORA"
if (Test-Path $out) { Remove-Item $out -Recurse -Force }
New-Item -ItemType Directory -Force "$pkg\app", "$pkg\node" | Out-Null

Write-Host '> Launcher'
if (Get-Command go -ErrorAction SilentlyContinue) {
  Push-Location windows
  python mkres.py icon_win.png rsrc_windows_amd64.syso $ver
  $env:GOOS = 'windows'; $env:GOARCH = 'amd64'; go build -trimpath -ldflags "-H=windowsgui -s -w" -o "..\$pkg\PIXORA.exe" .
  Pop-Location
} elseif (Test-Path 'windows\PIXORA.exe') { Copy-Item 'windows\PIXORA.exe' "$pkg\" } else { throw 'Install Go, or put a built PIXORA.exe in the windows folder' }
Copy-Item installers\PIXORA.ico "$pkg\"

Write-Host '> App files'
Copy-Item server.js, server-pro3.js, package.json, README.md "$pkg\app\"
Copy-Item public "$pkg\app\public" -Recurse
if (Test-Path PIXORA-User-Manual.pdf) { Copy-Item PIXORA-User-Manual.pdf "$pkg\" }

Write-Host "> Node.js $nodeVer"
$zip = "node-$nodeVer-win-x64.zip"
Invoke-WebRequest "https://nodejs.org/dist/$nodeVer/$zip" -OutFile "$env:TEMP\$zip"
$sums = (Invoke-WebRequest "https://nodejs.org/dist/$nodeVer/SHASUMS256.txt").Content
$want = ($sums -split "`n" | Where-Object { $_ -match " $zip$" }).Split(' ')[0]
$have = (Get-FileHash "$env:TEMP\$zip" -Algorithm SHA256).Hash.ToLower()
if ($want -ne $have) { throw "Node.js checksum mismatch" }
Expand-Archive "$env:TEMP\$zip" "$env:TEMP\nodex" -Force
Copy-Item "$env:TEMP\nodex\node-$nodeVer-win-x64\node.exe" "$pkg\node\"

$ff = Get-Command ffmpeg.exe -ErrorAction SilentlyContinue
if ($ff -and $env:PIXORA_BUNDLE_FFMPEG) { New-Item -ItemType Directory -Force "$pkg\ffmpeg\bin" | Out-Null; Copy-Item $ff.Source "$pkg\ffmpeg\bin\"; $fp = Join-Path (Split-Path $ff.Source) 'ffprobe.exe'; if (Test-Path $fp) { Copy-Item $fp "$pkg\ffmpeg\bin\" } }

function Sign($f) { if ($env:PIXORA_SIGN_PFX) { & signtool sign /f $env:PIXORA_SIGN_PFX /p $env:PIXORA_SIGN_PASS /fd SHA256 /tr http://timestamp.digicert.com /td SHA256 $f } }
Sign "$pkg\PIXORA.exe"

Write-Host '> Installer'
$iscc = @("${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe", "$env:ProgramFiles\Inno Setup 6\ISCC.exe", "$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $iscc) { Write-Warning 'Inno Setup not found - leaving the portable folder in dist\win\PIXORA'; exit 0 }
& $iscc "/DAppVersion=$ver" "/DSrcDir=$((Resolve-Path $pkg).Path)" "/O$((Resolve-Path $out).Path)" installers\pixora.iss
Sign "$out\PIXORA-Setup-$ver.exe"
Write-Host "Done: $out\PIXORA-Setup-$ver.exe"
