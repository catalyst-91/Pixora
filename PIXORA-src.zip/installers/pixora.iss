; PIXORA installer (Inno Setup 6). Built by build-windows.ps1 — per-user install so in-app updates can write to it.
#ifndef AppVersion
  #define AppVersion "1.2.0"
#endif
#ifndef SrcDir
  #define SrcDir "..\dist\win\PIXORA"
#endif

[Setup]
AppId={{6A2B3F0E-9C1D-4E5B-8A77-50B0071E5A12}
AppName=PIXORA
AppVersion={#AppVersion}
AppPublisher=Booth Productions
AppPublisherURL=https://booth-productions.com
DefaultDirName={localappdata}\Programs\PIXORA
DisableDirPage=auto
DefaultGroupName=PIXORA
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputBaseFilename=PIXORA-Setup-{#AppVersion}
SetupIconFile={#SrcDir}\PIXORA.ico
UninstallDisplayIcon={app}\PIXORA.exe
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
CloseApplications=yes

[Files]
Source: "{#SrcDir}\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion

[Icons]
Name: "{autoprograms}\PIXORA"; Filename: "{app}\PIXORA.exe"
Name: "{autoprograms}\PIXORA Manual"; Filename: "{app}\PIXORA-User-Manual.pdf"; Check: FileExists(ExpandConstant('{app}\PIXORA-User-Manual.pdf'))
Name: "{autodesktop}\PIXORA"; Filename: "{app}\PIXORA.exe"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Shortcuts:"
Name: "autostart"; Description: "Start PIXORA when Windows starts"; GroupDescription: "Options:"; Flags: unchecked

[Registry]
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "PIXORA"; ValueData: """{app}\PIXORA.exe"" --background"; Tasks: autostart; Flags: uninsdeletevalue

[Run]
Filename: "{app}\PIXORA.exe"; Description: "Start PIXORA now"; Flags: nowait postinstall skipifsilent

[UninstallRun]
Filename: "{cmd}"; Parameters: "/C taskkill /IM PIXORA.exe /F"; Flags: runhidden; RunOnceId: "StopPixora"
