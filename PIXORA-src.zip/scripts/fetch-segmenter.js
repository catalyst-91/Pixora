// Fetches Google MediaPipe's image-segmentation runtime and the selfie segmenter model (both Apache 2.0) into
// public/vendor/mediapipe, for PIXORA's AI background removal. Run by the desktop build (CI); offline it leaves the
// feature switched off ("unavailable") rather than failing the build.
//   node scripts/fetch-segmenter.js
const { execSync } = require('child_process'), fs = require('fs'), path = require('path'), os = require('os');
const OUT = path.join(__dirname, '..', 'public', 'vendor', 'mediapipe'), PKG = '@mediapipe/tasks-vision@0.10';
const MODEL = 'https://storage.googleapis.com/mediapipe-models/image_segmenter/selfie_segmenter/float16/latest/selfie_segmenter.tflite';
(async () => {
  try {
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'pxmp-'));
    const tgz = execSync(`npm pack ${PKG} --silent`, { cwd: tmp, encoding: 'utf8' }).trim().split('\n').pop();
    execSync(`tar -xzf "${tgz}"`, { cwd: tmp });
    const pkg = path.join(tmp, 'package'); fs.mkdirSync(path.join(OUT, 'wasm'), { recursive: true });
    fs.copyFileSync(path.join(pkg, 'vision_bundle.mjs'), path.join(OUT, 'vision_bundle.mjs'));
    for (const f of fs.readdirSync(path.join(pkg, 'wasm'))) fs.copyFileSync(path.join(pkg, 'wasm', f), path.join(OUT, 'wasm', f));
    for (const f of ['LICENSE', 'README.md']) if (fs.existsSync(path.join(pkg, f))) fs.copyFileSync(path.join(pkg, f), path.join(OUT, f));
    const r = await fetch(MODEL); if (!r.ok) throw new Error('model download: HTTP ' + r.status);
    const buf = Buffer.from(await r.arrayBuffer()); if (buf.length < 100000) throw new Error('model download looks wrong (' + buf.length + ' bytes)');
    fs.writeFileSync(path.join(OUT, 'selfie_segmenter.tflite'), buf);
    const ver = JSON.parse(fs.readFileSync(path.join(pkg, 'package.json'), 'utf8')).version;
    fs.writeFileSync(path.join(OUT, 'VERSION.txt'), `@mediapipe/tasks-vision ${ver}\nselfie_segmenter.tflite (float16) from ${MODEL}\nApache License 2.0\n`);
    console.log(`AI background removal: MediaPipe tasks-vision ${ver} + selfie segmenter (${(buf.length / 1e6).toFixed(1)} MB) in public/vendor/mediapipe`);
  } catch (e) { console.log('::warning::AI background removal not bundled: ' + e.message); }
})();
