'use strict';
// Virtual production: FreeD camera tracking over UDP (type D1 messages, as sent by Mo-Sys, Stype, Ncam, Vive Mars, PTZ
// cameras with FreeD out, Unreal LiveLink bridges…). Each 29-byte message carries pan / tilt / roll (degrees), X / Y / Z
// position (mm), zoom and focus (raw encoder counts). The latest pose per camera id goes to the output windows, which
// render 3D scenes for the LED walls from that eye point (off-axis), up to 60 times a second.
const dgram = require('dgram');
const s24 = (b, o) => { const v = (b[o] << 16) | (b[o + 1] << 8) | b[o + 2]; return v & 0x800000 ? v - 0x1000000 : v; };
const u24 = (b, o) => (b[o] << 16) | (b[o + 1] << 8) | b[o + 2];
function parse(b) { // → pose or null
  if (!b || b.length < 29 || b[0] !== 0xD1) return null;
  let sum = 0x40; for (let i = 0; i < 28; i++) sum = (sum - b[i]) & 0xff; if (sum !== b[28]) return null;
  return { cam: b[1], pan: s24(b, 2) / 32768, tilt: s24(b, 5) / 32768, roll: s24(b, 8) / 32768, x: s24(b, 11) / 64, y: s24(b, 14) / 64, z: s24(b, 17) / 64, zoom: u24(b, 20), focus: u24(b, 23) };
}
function build(p) { // for tests and the simulator: pose → 29-byte message
  const b = Buffer.alloc(29); b[0] = 0xD1; b[1] = p.cam & 0xff;
  const w24 = (o, v) => { v = Math.round(v) & 0xffffff; b[o] = v >> 16 & 255; b[o + 1] = v >> 8 & 255; b[o + 2] = v & 255; };
  w24(2, (p.pan || 0) * 32768); w24(5, (p.tilt || 0) * 32768); w24(8, (p.roll || 0) * 32768); w24(11, (p.x || 0) * 64); w24(14, (p.y || 0) * 64); w24(17, (p.z || 0) * 64); w24(20, p.zoom || 0); w24(23, p.focus || 0);
  let sum = 0x40; for (let i = 0; i < 28; i++) sum = (sum - b[i]) & 0xff; b[28] = sum; return b;
}

module.exports = function (o) { // o: { getState, broadcast(obj, role), monitor }
  let sock = null, port = 0, err = '';
  const cams = {}, stats = { packets: 0, bad: 0, rate: 0, from: '' }; let count = 0, lastRate = Date.now(), pushT = null, lastPush = 0;
  function push() { const go = () => { pushT = null; lastPush = Date.now(); o.broadcast({ t: 'track', cams }, 'output'); }; if (pushT) return; const w = Math.max(0, 16 - (Date.now() - lastPush)); pushT = setTimeout(go, w); }
  function listen() {
    const vp = (o.getState().vp) || {}; const want = vp.on ? Math.max(1, Math.min(65535, +vp.port || 40000)) : 0;
    if (want === port) return; if (sock) { try { sock.close(); } catch {} sock = null; } port = want; err = ''; if (!want) return;
    sock = dgram.createSocket({ type: 'udp4', reuseAddr: true });
    sock.on('message', (msg, rinfo) => { for (let off = 0; off + 29 <= msg.length; off += 29) { const p = parse(msg.subarray(off, off + 29)); if (!p) { stats.bad++; continue; }
        p.at = Date.now(); cams[p.cam] = p; stats.packets++; count++; stats.from = rinfo.address; } push(); });
    sock.on('error', e => { err = e.message; o.monitor('vp', `FreeD on UDP ${want}: ${e.message}`); try { sock.close(); } catch {} sock = null; port = 0; });
    sock.bind(want, () => o.monitor('vp', `listening for FreeD tracking on UDP ${want}`));
  }
  const t = setInterval(() => { const n = Date.now(); stats.rate = Math.round(count * 1000 / Math.max(1, n - lastRate)); count = 0; lastRate = n; listen(); }, 1000); if (t.unref) t.unref();
  setTimeout(listen, 300);
  return { status: () => ({ port, error: err, ...stats, cams }), cams: () => cams, listen, stop() { if (sock) try { sock.close(); } catch {} sock = null; port = 0; },
    inject(p) { p.at = Date.now(); cams[p.cam] = p; push(); } }; // the panel's camera simulator
};
module.exports.parse = parse; module.exports.build = build;
