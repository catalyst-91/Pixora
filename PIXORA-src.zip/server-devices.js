// PIXORA device control — Booth Productions.
// Production gear on the network, driven from cues, rules, OSC, HTTP and the Devices panel:
//   Blackmagic Videohub (TCP 9990) · HyperDeck (TCP 9993) · Streaming Encoder / Web Presenter (TCP 9977)
//   Blackmagic cameras (REST /control/api/v1) · BirdDog (REST :8080) · Panasonic AW PTZ (HTTP aw_ptz / aw_cam)
//   Panasonic Auto Tracking (HTTP :1337) · VISCA over IP (UDP 52381, or raw TCP) · NDI® PTZ (via the desktop app)
//   ATEM switchers (network protocol on UDP 9910, server-atem.js)
'use strict';
const net = require('net'), dgram = require('dgram'), http = require('http'), crypto = require('crypto');

const TYPES = {
  videohub: { label: 'Blackmagic Videohub', port: 9990 },
  hyperdeck: { label: 'Blackmagic HyperDeck', port: 9993 },
  streamer: { label: 'Blackmagic Streaming Encoder / Web Presenter', port: 9977 },
  bmcamera: { label: 'Blackmagic camera (REST)', port: 80 },
  birddog: { label: 'BirdDog camera / converter', port: 8080 },
  panasonic: { label: 'Panasonic AW PTZ camera', port: 80 },
  pantrack: { label: 'Panasonic Auto Tracking', port: 1337 },
  visca: { label: 'VISCA over IP camera', port: 52381 },
  ndiptz: { label: 'NDI® PTZ camera', port: 0 },
  atem: { label: 'Blackmagic ATEM switcher', port: 9910 },
};

/* ---------------------------------------------------------------- shared helpers */
function httpReq(host, port, method, path, body, { timeout = 4000, type = 'application/json', auth } = {}) {
  return new Promise((ok, bad) => {
    const data = body == null ? null : typeof body === 'string' ? body : JSON.stringify(body);
    const r = http.request({ host, port, method, path, timeout, headers: Object.assign(data != null ? { 'Content-Type': type, 'Content-Length': Buffer.byteLength(data) } : {}, auth ? { Authorization: 'Basic ' + Buffer.from(auth).toString('base64') } : {}) }, res => {
      let b = ''; res.setEncoding('utf8'); res.on('data', c => b += c);
      res.on('end', () => { if (res.statusCode >= 400) return bad(new Error(`HTTP ${res.statusCode} ${path}`)); let j = b; try { j = b ? JSON.parse(b) : null; } catch {} ok(j); });
    });
    r.on('timeout', () => r.destroy(new Error('timed out'))); r.on('error', bad); if (data != null) r.write(data); r.end();
  });
}
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

// Text "block" protocols (Videohub, Streaming Encoder): HEADER:\n key...\n\n
class BlockClient {
  constructor(dev, port, onBlock) { this.dev = dev; this.port = port; this.onBlock = onBlock; this.buf = ''; this.waiters = []; }
  connect() {
    this.closeSock(); const s = this.sock = net.connect({ host: this.dev.host, port: this.dev.port || this.port });
    s.setEncoding('utf8'); s.setKeepAlive(true, 5000); s.setTimeout(15000, () => s.destroy(new Error('no response')));
    s.on('connect', () => { s.setTimeout(0); this.dev._online(true); });
    s.on('data', d => { this.buf += d.replace(/\r/g, ''); let i; while ((i = this.buf.indexOf('\n\n')) >= 0) { const blk = this.buf.slice(0, i); this.buf = this.buf.slice(i + 2); this._block(blk); } });
    s.on('error', e => this.dev._error(e)); s.on('close', () => this.dev._online(false));
  }
  _block(text) {
    const lines = text.split('\n').filter((l, i) => l.length || i); if (!lines.length) return;
    const head = lines[0].trim();
    if (head === 'ACK' || head === 'NAK' || head === 'NACK') { const w = this.waiters.shift(); if (w) (head === 'ACK' ? w.ok : w.bad)(new Error(head)); return; }
    this.onBlock(head.replace(/:$/, ''), lines.slice(1));
  }
  send(header, lines) {
    return new Promise((ok, bad) => {
      if (!this.sock || this.sock.destroyed || !this.dev.state.online) return bad(new Error('not connected'));
      const t = setTimeout(() => { const i = this.waiters.indexOf(w); if (i >= 0) this.waiters.splice(i, 1); bad(new Error('no ACK')); }, 4000);
      const w = { ok: v => { clearTimeout(t); ok(v); }, bad: e => { clearTimeout(t); bad(e); } }; this.waiters.push(w);
      this.sock.write(header + ':\n' + (lines.length ? lines.join('\n') + '\n' : '') + '\n');
    });
  }
  closeSock() { if (this.sock) { this.sock.removeAllListeners(); this.sock.on('error', () => {}); this.sock.destroy(); this.sock = null; } this.buf = ''; for (const w of this.waiters.splice(0)) w.bad(new Error('disconnected')); }
}

/* ---------------------------------------------------------------- base device */
class Device {
  constructor(cfg, hub) { this.cfg = cfg; this.hub = hub; this.state = { online: false, error: '', info: {} }; this.timers = []; }
  get host() { return this.cfg.host; } get port() { return +this.cfg.port || TYPES[this.cfg.type].port; }
  start() {} stop() { for (const t of this.timers) clearInterval(t), clearTimeout(t); this.timers = []; }
  every(ms, fn) { const t = setInterval(() => fn().catch(e => this._error(e)), ms); this.timers.push(t); fn().catch(e => this._error(e)); }
  _online(on) { const was = this.state.online; this.state.online = on; if (on) this.state.error = ''; this.changed(); if (was !== on) this.hub.monitor('device', `${this.cfg.name}: ${on ? 'online' : 'offline'}`); if (!on && !this.stopped) this.retry(); }
  _error(e) { const m = String(e && e.message || e); if (this.state.error !== m) { this.state.error = m; this.changed(); } }
  retry() { clearTimeout(this._rt); this._rt = setTimeout(() => { if (!this.stopped) this.connect && this.connect(); }, 3000); this.timers.push(this._rt); }
  changed() { this.hub.changed(this); }
  actions() { return []; }
  async act(name) { throw new Error(`${this.cfg.name}: unknown action "${name}"`); }
  view() { const c = this.cfg; return { id: c.id, name: c.name, type: c.type, host: c.host, port: c.port, camId: c.camId, tcp: c.tcp, source: c.source, user: c.user, hasPassword: !!c.password, opts: c.opts || {}, led: !!(TYPES[c.type] || {}).led, projector: !!(TYPES[c.type] || {}).projector, state: this.state, actions: this.actions() }; }
}

/* ---------------------------------------------------------------- Blackmagic Videohub */
class Videohub extends Device {
  start() { Object.assign(this.state, { inputs: [], outputs: [], routing: [], locks: [] }); this.c = new BlockClient(this, 9990, (h, l) => this.block(h, l)); this.connect(); }
  connect() { this.c.connect(); }
  stop() { this.stopped = true; super.stop(); this.c && this.c.closeSock(); }
  block(h, lines) {
    const st = this.state, kv = () => Object.fromEntries(lines.map(l => [l.slice(0, l.indexOf(':')).trim(), l.slice(l.indexOf(':') + 1).trim()]));
    const idx = (arr, conv) => { for (const l of lines) { const m = /^(\d+) (.*)$/.exec(l); if (m) arr[+m[1]] = conv ? conv(m[2]) : m[2]; } };
    if (h === 'VIDEOHUB DEVICE') { const d = kv(); st.info = { model: d['Model name'], present: d['Device present'], inputs: +d['Video inputs'] || 0, outputs: +d['Video outputs'] || 0 }; }
    else if (h === 'INPUT LABELS') idx(st.inputs);
    else if (h === 'OUTPUT LABELS') idx(st.outputs);
    else if (h === 'VIDEO OUTPUT ROUTING') idx(st.routing, Number);
    else if (h === 'VIDEO OUTPUT LOCKS') idx(st.locks);
    else return;
    this.changed();
  }
  actions() { return [['route', 'Route input → output', ['output', 'input']], ['label', 'Rename port', ['kind', 'index', 'name']], ['lock', 'Lock / unlock output', ['output', 'on']], ['salvo', 'Salvo (many routes)', ['routes']]]; }
  async act(name, a = {}) {
    const o = n => clamp((+n || 1) - 1, 0, 287); // ports are 1-based in PIXORA, 0-based on the wire
    if (name === 'route') return this.c.send('VIDEO OUTPUT ROUTING', [`${o(a.output)} ${o(a.input)}`]);
    if (name === 'salvo') return this.c.send('VIDEO OUTPUT ROUTING', (a.routes || []).map(r => `${o(r.output)} ${o(r.input)}`));
    if (name === 'label') return this.c.send(a.kind === 'input' ? 'INPUT LABELS' : 'OUTPUT LABELS', [`${o(a.index)} ${String(a.name || '').replace(/\n/g, ' ')}`]);
    if (name === 'lock') return this.c.send('VIDEO OUTPUT LOCKS', [`${o(a.output)} ${a.on === false || a.on === 0 ? 'U' : 'O'}`]);
    return super.act(name);
  }
}

/* ---------------------------------------------------------------- Blackmagic HyperDeck */
class HyperDeck extends Device {
  start() { Object.assign(this.state, { transport: {}, clips: [], slots: {} }); this.q = []; this.buf = ''; this.connect(); }
  connect() {
    if (this.s) { this.s.removeAllListeners(); this.s.on('error', () => {}); this.s.destroy(); }
    const s = this.s = net.connect({ host: this.host, port: this.port }); s.setEncoding('utf8'); s.setKeepAlive(true, 5000);
    s.setTimeout(15000, () => s.destroy(new Error('no response')));
    s.on('connect', async () => { s.setTimeout(0); this._online(true); this.buf = '';
      try { await this.cmd('notify: transport: true slot: true remote: true'); await this.refresh(); } catch (e) { this._error(e); } });
    s.on('data', d => this.data(d)); s.on('error', e => this._error(e)); s.on('close', () => { for (const w of this.q.splice(0)) w.bad(new Error('disconnected')); this._online(false); });
    if (!this.poll) { this.poll = setInterval(() => { if (this.state.online) this.cmd('transport info').catch(() => {}); }, 2000); this.timers.push(this.poll); }
  }
  stop() { this.stopped = true; super.stop(); if (this.s) { this.s.removeAllListeners(); this.s.on('error', () => {}); this.s.destroy(); } }
  data(d) {
    this.buf += d.replace(/\r/g, '');
    for (;;) {
      const nl = this.buf.indexOf('\n'); if (nl < 0) return;
      const first = this.buf.slice(0, nl), m = /^(\d{3}) ([^:]*)(:?)$/.exec(first);
      if (!m) { this.buf = this.buf.slice(nl + 1); continue; }
      let body = [];
      if (m[3]) { const end = this.buf.indexOf('\n\n', nl); if (end < 0) return; body = this.buf.slice(nl + 1, end).split('\n'); this.buf = this.buf.slice(end + 2); }
      else this.buf = this.buf.slice(nl + 1);
      this.reply(+m[1], m[2], body);
    }
  }
  reply(code, text, body) {
    const kv = Object.fromEntries(body.filter(l => /^[^:]+: /.test(l)).map(l => [l.slice(0, l.indexOf(':')), l.slice(l.indexOf(':') + 2)]));
    if (code >= 500 && code < 600) { // asynchronous notifications
      if (code === 500) { this.state.info.protocol = kv['protocol version']; this.state.info.model = kv.model; }
      if (code === 508) Object.assign(this.state.transport, kv);
      if (code === 502) { this.state.slots[kv['slot id']] = kv; this.refresh().catch(() => {}); }
      this.changed(); return;
    }
    const w = this.q.shift(); if (!w) return;
    if (code >= 100 && code < 200) return w.bad(new Error(`${code} ${text}`));
    if (code === 208) Object.assign(this.state.transport, kv);
    if (code === 204) Object.assign(this.state.info, kv);
    if (code === 205) this.state.clips = body.filter(l => /^\d+: /.test(l)).map(l => { const id = +l.slice(0, l.indexOf(':')); const rest = l.slice(l.indexOf(':') + 2).trim().split(' ');
      const dur = rest.pop(), start = rest.pop(); return { id, name: rest.join(' '), start, duration: dur }; });
    this.changed(); w.ok({ code, text, kv, body });
  }
  cmd(line) { return new Promise((ok, bad) => { if (!this.s || !this.state.online) return bad(new Error('not connected')); const t = setTimeout(() => { const i = this.q.indexOf(w); if (i >= 0) this.q.splice(i, 1); bad(new Error('no reply to ' + line)); }, 5000);
    const w = { ok: v => { clearTimeout(t); ok(v); }, bad: e => { clearTimeout(t); bad(e); } }; this.q.push(w); this.s.write(line + '\n'); }); }
  async refresh() { await this.cmd('device info'); await this.cmd('transport info'); await this.cmd('clips get'); }
  actions() { return [['play', 'Play', ['speed', 'loop', 'single']], ['stop', 'Stop'], ['record', 'Record', ['name']], ['goto', 'Go to clip', ['clip']],
    ['next', 'Next clip'], ['prev', 'Previous clip'], ['playClip', 'Play clip', ['clip', 'loop']], ['preview', 'Show input (preview)', ['on']], ['slot', 'Select slot', ['slot']], ['raw', 'Raw command', ['command']]]; }
  async act(name, a = {}) {
    switch (name) {
      case 'play': return this.cmd('play' + (a.speed != null || a.loop != null || a.single != null ? ':' + (a.speed != null ? ` speed: ${clamp(+a.speed | 0, -5000, 5000)}` : '') + (a.loop != null ? ` loop: ${!!a.loop}` : '') + (a.single != null ? ` single clip: ${!!a.single}` : '') : ''));
      case 'stop': return this.cmd('stop');
      case 'record': return this.cmd(a.name ? `record: name: ${String(a.name).replace(/\n/g, ' ')}` : 'record');
      case 'goto': return this.cmd(`goto: clip id: ${Math.max(1, +a.clip | 0)}`);
      case 'next': return this.cmd('goto: clip id: +1'); case 'prev': return this.cmd('goto: clip id: -1');
      case 'playClip': await this.cmd(`goto: clip id: ${Math.max(1, +a.clip | 0)}`); return this.cmd(`play: single clip: true loop: ${!!a.loop}`);
      case 'preview': return this.cmd(`preview: enable: ${a.on !== false}`);
      case 'slot': return this.cmd(`slot select: slot id: ${Math.max(1, +a.slot | 0)}`);
      case 'raw': return this.cmd(String(a.command || '').split('\n')[0]);
    }
    return super.act(name);
  }
}

/* ---------------------------------------------------------------- Blackmagic Streaming Encoder / Web Presenter */
class Streamer extends Device {
  start() { Object.assign(this.state, { stream: {}, settings: {} }); this.c = new BlockClient(this, 9977, (h, l) => this.block(h, l)); this.connect(); }
  connect() { this.c.connect(); }
  stop() { this.stopped = true; super.stop(); this.c && this.c.closeSock(); }
  block(h, lines) {
    const kv = Object.fromEntries(lines.filter(l => l.includes(':')).map(l => [l.slice(0, l.indexOf(':')).trim(), l.slice(l.indexOf(':') + 1).trim()]));
    if (h === 'IDENTITY') Object.assign(this.state.info, { model: kv.Model, label: kv.Label });
    else if (h === 'STREAM STATE') Object.assign(this.state.stream, kv);
    else if (h === 'STREAM SETTINGS') Object.assign(this.state.settings, kv);
    else if (h === 'VERSION') this.state.info.software = kv['Software Release'];
    else return; this.changed();
  }
  actions() { return [['start', 'Start streaming'], ['stop', 'Stop streaming'], ['platform', 'Set platform / server / key', ['platform', 'server', 'key', 'quality']]]; }
  async act(name, a = {}) {
    if (name === 'start') return this.c.send('STREAM STATE', ['Action: Start']);
    if (name === 'stop') return this.c.send('STREAM STATE', ['Action: Stop']);
    if (name === 'platform') { const l = []; if (a.platform) l.push('Current Platform: ' + a.platform); if (a.server) l.push('Current Server: ' + a.server); if (a.key != null) l.push('Stream Key: ' + a.key); if (a.quality) l.push('Current Quality Level: ' + a.quality); return this.c.send('STREAM SETTINGS', l); }
    return super.act(name);
  }
}

/* ---------------------------------------------------------------- Blackmagic camera (REST API) */
class BMCamera extends Device {
  api(method, path, body) { return httpReq(this.host, this.port, method, '/control/api/v1' + path, body); }
  start() { this.every(3000, async () => {
    try { const [prod, rec] = await Promise.all([this.api('GET', '/system/product').catch(() => null), this.api('GET', '/transports/0/record')]);
      if (prod) this.state.info = { model: prod.productName || prod.name, ...prod }; this.state.recording = !!(rec && rec.recording); if (!this.state.online) this._online(true); else this.changed();
    } catch (e) { if (this.state.online) this._online(false); this._error(e); } }); }
  stop() { this.stopped = true; super.stop(); }
  retry() {}
  actions() { return [['record', 'Record on/off', ['on']], ['autoFocus', 'Auto focus'], ['focus', 'Focus (0–1)', ['value']], ['iris', 'Iris (0–1)', ['value']], ['autoIris', 'Auto iris'],
    ['zoom', 'Zoom (0–1)', ['value']], ['whiteBalance', 'White balance (K)', ['kelvin']], ['autoWhiteBalance', 'Auto white balance'], ['iso', 'ISO', ['value']], ['shutter', 'Shutter speed (1/x)', ['value']], ['gain', 'Gain (dB)', ['value']], ['preset', 'Load preset', ['name']]]; }
  async act(name, a = {}) {
    const v = +a.value;
    switch (name) {
      case 'record': return this.api('POST', '/transports/0/record', { recording: a.on !== false }).catch(() => this.api('PUT', '/transports/0/record', { recording: a.on !== false }));
      case 'autoFocus': return this.api('PUT', '/lens/focus/doAutoFocus');
      case 'focus': return this.api('PUT', '/lens/focus', { normalised: clamp(v, 0, 1) });
      case 'iris': return this.api('PUT', '/lens/iris', { normalised: clamp(v, 0, 1) });
      case 'autoIris': return this.api('PUT', '/lens/iris/doAutoIris').catch(() => this.api('PUT', '/video/autoExposure', { mode: 'Continuous', type: 'Iris' }));
      case 'zoom': return this.api('PUT', '/lens/zoom', { normalised: clamp(v, 0, 1) });
      case 'whiteBalance': return this.api('PUT', '/video/whiteBalance', { whiteBalance: clamp(+a.kelvin | 0, 2500, 10000) });
      case 'autoWhiteBalance': return this.api('PUT', '/video/whiteBalance/doAuto');
      case 'iso': return this.api('PUT', '/video/iso', { iso: v | 0 });
      case 'shutter': return this.api('PUT', '/video/shutter', { shutterSpeed: v | 0 });
      case 'gain': return this.api('PUT', '/video/gain', { gain: v });
      case 'preset': return this.api('PUT', '/presets/active', { preset: String(a.name || '') });
    }
    return super.act(name);
  }
}

/* ---------------------------------------------------------------- BirdDog (REST API, port 8080) */
class BirdDog extends Device {
  api(method, path, body, type) { return httpReq(this.host, this.port, method, path, body, { type: type || 'application/json' }); }
  start() { Object.assign(this.state, { sources: [], mode: '' }); this.every(5000, async () => {
    try { const about = await this.api('GET', '/about'); this.state.info = about || {}; this.state.mode = String(await this.api('GET', '/operationmode').catch(() => '') || '').trim();
      if (this.state.mode === 'decode') { const l = await this.api('GET', '/List').catch(() => null); this.state.sources = l && typeof l === 'object' ? Object.keys(l).filter(k => k !== 'None') : []; }
      if (!this.state.online) this._online(true); else this.changed();
    } catch (e) { if (this.state.online) this._online(false); this._error(e); } }); }
  stop() { this.stopped = true; super.stop(); } retry() {}
  actions() { return [['recall', 'Recall preset (1–9)', ['preset']], ['save', 'Save preset (1–9)', ['preset']], ['ptzSpeed', 'PTZ speeds', ['pan', 'tilt', 'zoom']], ['source', 'Decode NDI source', ['source']],
    ['refresh', 'Refresh NDI list'], ['mode', 'Encode / decode mode', ['mode']], ['tally', 'Tally mode', ['mode']], ['exposure', 'Exposure mode', ['mode']], ['whiteBalance', 'White balance mode', ['mode']], ['reboot', 'Reboot']]; }
  async act(name, a = {}) {
    const p = n => 'Preset-' + clamp(+n | 0 || 1, 1, 9);
    switch (name) {
      case 'recall': return this.api('POST', '/recall', { Preset: p(a.preset) });
      case 'save': return this.api('POST', '/save', { Preset: p(a.preset) });
      case 'ptzSpeed': return this.api('POST', '/birddogptzsetup', { PanSpeed: String(clamp(+a.pan | 0, 0, 21)), TiltSpeed: String(clamp(+a.tilt | 0, 0, 18)), ZoomSpeed: String(clamp(+a.zoom | 0, 0, 7)) });
      case 'source': return this.api('POST', '/connectTo', { sourceName: String(a.source || 'None') });
      case 'refresh': return this.api('POST', '/refresh');
      case 'mode': return this.api('POST', '/operationmode', a.mode === 'decode' ? 'decode' : 'encode', 'text/plain');
      case 'tally': return this.api('POST', '/encodesetup', { TallyMode: a.mode || 'TallyOn' });
      case 'exposure': return this.api('POST', '/birddogexpsetup', { ExpMode: a.mode || 'FULL-AUTO' });
      case 'whiteBalance': return this.api('POST', '/birddogwbsetup', { WbMode: a.mode || 'AUTO' });
      case 'reboot': return this.api('POST', '/reboot');
    }
    return super.act(name);
  }
}

/* ---------------------------------------------------------------- Panasonic AW PTZ (AW protocol over HTTP) */
class Panasonic extends Device {
  // /cgi-bin/aw_ptz?cmd=%23...&res=1 for pan/tilt/zoom/presets; /cgi-bin/aw_cam?cmd=...&res=1 for camera settings
  aw(kind, cmd) { const a = this.cfg.user ? `${this.cfg.user}:${this.cfg.password || ''}` : undefined;
    return httpReq(this.host, this.port, 'GET', `/cgi-bin/aw_${kind}?cmd=${encodeURIComponent(cmd)}&res=1`, null, { auth: a }); }
  start() { this.every(5000, async () => {
    try { const r = await this.aw('ptz', '#O'); this.state.power = /p1/.test(String(r)); this.state.info.model = this.state.info.model || String(await this.aw('cam', 'QID').catch(() => '') || '').replace(/^OID:/, '').trim();
      if (!this.state.online) this._online(true); else this.changed();
    } catch (e) { if (this.state.online) this._online(false); this._error(e); } }); }
  stop() { this.stopped = true; super.stop(); } retry() {}
  actions() { return [['recall', 'Recall preset (1–100)', ['preset']], ['save', 'Save preset (1–100)', ['preset']], ['move', 'Pan/tilt speed (-1…1)', ['pan', 'tilt']], ['stop', 'Stop moving'],
    ['zoom', 'Zoom speed (-1…1)', ['speed']], ['focus', 'Focus speed (-1…1)', ['speed']], ['autoFocus', 'Auto focus on/off', ['on']], ['presetSpeed', 'Preset speed (1–30)', ['speed']],
    ['power', 'Power on/off', ['on']], ['tally', 'Tally red/green', ['red', 'green']], ['home', 'Home position'], ['raw', 'Raw AW command', ['kind', 'command']]]; }
  async act(name, a = {}) {
    const two = n => String(n).padStart(2, '0'), sp = v => two(clamp(Math.round(50 + clamp(+v || 0, -1, 1) * 49), 1, 99));
    switch (name) {
      case 'recall': return this.aw('ptz', '#R' + two(clamp((+a.preset | 0 || 1) - 1, 0, 99)));
      case 'save': return this.aw('ptz', '#M' + two(clamp((+a.preset | 0 || 1) - 1, 0, 99)));
      case 'move': return this.aw('ptz', '#PTS' + sp(a.pan) + sp(-(+a.tilt || 0)));
      case 'stop': await this.aw('ptz', '#PTS5050'); return this.aw('ptz', '#Z50');
      case 'zoom': return this.aw('ptz', '#Z' + sp(a.speed));
      case 'focus': return this.aw('ptz', '#F' + sp(a.speed));
      case 'autoFocus': return this.aw('ptz', '#D1' + (a.on === false ? '0' : '1'));
      case 'presetSpeed': return this.aw('ptz', '#UPVS' + String(clamp(+a.speed | 0 || 15, 1, 30) * 33).padStart(3, '0'));
      case 'power': return this.aw('ptz', '#O' + (a.on === false ? '0' : '1'));
      case 'tally': await this.aw('cam', 'TLR:' + (a.red ? 1 : 0)); return this.aw('cam', 'TLG:' + (a.green ? 1 : 0));
      case 'home': return this.aw('ptz', '#APC80008000');
      case 'raw': return this.aw(a.kind === 'cam' ? 'cam' : 'ptz', String(a.command || ''));
    }
    return super.act(name);
  }
}

/* ---------------------------------------------------------------- Panasonic Auto Tracking (web API, port 1337) */
class PanTrack extends Device {
  q(params) { return httpReq(this.host, this.port, 'GET', '/cgi-bin/auto_tracking?' + new URLSearchParams(params), null).then(r => { const s = String(r == null ? '' : typeof r === 'string' ? r : JSON.stringify(r)); if (/nack/i.test(s)) throw new Error('camera refused: ' + s.slice(0, 80)); return s; }); }
  get cam() { return String(this.cfg.camId || 1); }
  start() { this.every(5000, async () => { try { this.state.cameraState = await this.q({ cmd: 'CameraState', id: this.cam }); if (!this.state.online) this._online(true); else this.changed(); } catch (e) { if (this.state.online) this._online(false); this._error(e); } }); }
  stop() { this.stopped = true; super.stop(); } retry() {}
  actions() { return [['tracking', 'Tracking on/off', ['on']], ['angle', 'Framing (upper/body/full/off)', ['mode']], ['preset', 'Preset recall/set/clear', ['mode', 'preset']],
    ['target', 'Pick target at x,y (640×360)', ['x', 'y']], ['autoZoom', 'Auto zoom on/off', ['on']], ['faceRecognition', 'Face recognition on/off', ['on']], ['connect', 'Connect camera on/off', ['on']]]; }
  async act(name, a = {}) {
    const id = this.cam;
    switch (name) {
      case 'tracking': return this.q({ cmd: 'TrackingControl', id, enable: a.on === false ? 'off' : 'on' });
      case 'angle': return this.q({ cmd: 'Angle', id, mode: ['upper', 'body', 'full', 'off'].includes(a.mode) ? a.mode : 'upper' });
      case 'preset': return this.q({ cmd: 'Preset', id, mode: ['set', 'clear', 'recall'].includes(a.mode) ? a.mode : 'recall', preset_num: clamp(+a.preset | 0 || 1, 1, 100) });
      case 'target': return this.q({ cmd: 'Target', id, position_x: clamp(+a.x | 0, 0, 639), position_y: clamp(+a.y | 0, 0, 359) });
      case 'autoZoom': return this.q({ cmd: 'AutoZoom', id, mode: a.on === false ? 0 : 1 });
      case 'faceRecognition': return this.q({ cmd: 'FaceRecognition', id, mode: a.on === false ? 0 : 1 });
      case 'connect': return this.q({ cmd: 'CameraControl', id, control: a.on === false ? 'stop' : 'start' });
    }
    return super.act(name);
  }
}

/* ---------------------------------------------------------------- VISCA over IP (Sony framing on UDP 52381, or raw VISCA over TCP) */
class Visca extends Device {
  start() { this.seq = 1; if (this.cfg.tcp) this.connect(); else { this.sock = dgram.createSocket('udp4'); this.sock.on('error', e => this._error(e)); this.sock.on('message', m => this.reply(m)); this.sock.bind(0, () => { this._online(true); this.send([0x01, 0x00, 0x01], 0x0200).catch(() => {}); /* reset sequence */ }); } }
  connect() { if (this.tcp) { this.tcp.removeAllListeners(); this.tcp.destroy(); } this.tcp = net.connect({ host: this.host, port: this.port || 5678 }); this.tcp.on('connect', () => this._online(true)); this.tcp.on('data', m => this.reply(m)); this.tcp.on('error', e => this._error(e)); this.tcp.on('close', () => this._online(false)); }
  stop() { this.stopped = true; super.stop(); try { this.sock && this.sock.close(); } catch {} if (this.tcp) { this.tcp.removeAllListeners(); this.tcp.on('error', () => {}); this.tcp.destroy(); } }
  reply(m) { this.state.lastReply = m.toString('hex'); if (/9[0-9a-f]6[0-9a-f]/i.test(this.state.lastReply.slice(-8))) this._error(new Error('camera error ' + this.state.lastReply)); }
  send(bytes, type = 0x0100) {
    const addr = 0x80 | clamp(+this.cfg.camId || 1, 1, 7), pkt = Buffer.from(type === 0x0100 ? [addr, ...bytes, 0xff] : bytes);
    if (this.cfg.tcp) { if (!this.tcp || !this.state.online) return Promise.reject(new Error('not connected')); this.tcp.write(pkt); return Promise.resolve(); }
    const h = Buffer.alloc(8); h.writeUInt16BE(type, 0); h.writeUInt16BE(pkt.length, 2); h.writeUInt32BE(this.seq++ >>> 0, 4);
    return new Promise((ok, bad) => this.sock.send(Buffer.concat([h, pkt]), this.port, this.host, e => e ? bad(e) : ok()));
  }
  actions() { return [['move', 'Pan/tilt speed (-1…1)', ['pan', 'tilt']], ['stop', 'Stop'], ['zoom', 'Zoom speed (-1…1)', ['speed']], ['recall', 'Recall preset (0–127)', ['preset']], ['save', 'Save preset (0–127)', ['preset']],
    ['home', 'Home'], ['autoFocus', 'Auto focus on/off', ['on']], ['onePushAF', 'One-push focus'], ['power', 'Power on/off', ['on']], ['raw', 'Raw VISCA bytes (hex, no 8x/FF)', ['hex']]]; }
  async act(name, a = {}) {
    switch (name) {
      case 'move': { const p = clamp(+a.pan || 0, -1, 1), t = clamp(+a.tilt || 0, -1, 1); const vv = Math.max(1, Math.round(Math.abs(p) * 0x18)), ww = Math.max(1, Math.round(Math.abs(t) * 0x17));
        return this.send([0x01, 0x06, 0x01, vv, ww, p < 0 ? 0x01 : p > 0 ? 0x02 : 0x03, t > 0 ? 0x01 : t < 0 ? 0x02 : 0x03]); }
      case 'stop': await this.send([0x01, 0x06, 0x01, 0x01, 0x01, 0x03, 0x03]); return this.send([0x01, 0x04, 0x07, 0x00]);
      case 'zoom': { const s = clamp(+a.speed || 0, -1, 1), n = Math.max(0, Math.min(7, Math.round(Math.abs(s) * 7))); return this.send([0x01, 0x04, 0x07, s > 0 ? 0x20 | n : s < 0 ? 0x30 | n : 0x00]); }
      case 'recall': return this.send([0x01, 0x04, 0x3f, 0x02, clamp(+a.preset | 0, 0, 127)]);
      case 'save': return this.send([0x01, 0x04, 0x3f, 0x01, clamp(+a.preset | 0, 0, 127)]);
      case 'home': return this.send([0x01, 0x06, 0x04]);
      case 'autoFocus': return this.send([0x01, 0x04, 0x38, a.on === false ? 0x03 : 0x02]);
      case 'onePushAF': return this.send([0x01, 0x04, 0x18, 0x01]);
      case 'power': return this.send([0x01, 0x04, 0x00, a.on === false ? 0x03 : 0x02]);
      case 'raw': return this.send(String(a.hex || '').replace(/[^0-9a-f]/gi, '').match(/../g).map(x => parseInt(x, 16)));
    }
    return super.act(name);
  }
}

/* ---------------------------------------------------------------- NDI® PTZ (the desktop app holds the NDI receivers) */
class NdiPtz extends Device {
  start() { this._online(true); }
  stop() { this.stopped = true; super.stop(); } retry() {}
  actions() { return [['move', 'Pan/tilt speed (-1…1)', ['pan', 'tilt']], ['stop', 'Stop'], ['zoom', 'Zoom (0–1)', ['value']], ['zoomSpeed', 'Zoom speed (-1…1)', ['speed']], ['recall', 'Recall preset (0–99)', ['preset', 'speed']],
    ['save', 'Save preset (0–99)', ['preset']], ['autoFocus', 'Auto focus'], ['focus', 'Focus (0–1)', ['value']], ['wbAuto', 'Auto white balance'], ['exposureAuto', 'Auto exposure']]; }
  async act(name, a = {}) {
    const job = (action, x, y) => this.hub.native({ type: 'ptz', source: this.cfg.source || this.cfg.name, action, a: x, b: y }).then(r => { if (!r || !r.ok) throw new Error((r && r.error) || 'camera did not accept the command'); return r; });
    switch (name) {
      case 'move': return job('panTiltSpeed', clamp(+a.pan || 0, -1, 1), clamp(+a.tilt || 0, -1, 1));
      case 'stop': await job('panTiltSpeed', 0, 0); return job('zoomSpeed', 0);
      case 'zoom': return job('zoom', clamp(+a.value || 0, 0, 1)); case 'zoomSpeed': return job('zoomSpeed', clamp(+a.speed || 0, -1, 1));
      case 'recall': return job('recallPreset', clamp(+a.preset | 0, 0, 99), a.speed == null ? 1 : clamp(+a.speed, 0, 1));
      case 'save': return job('storePreset', clamp(+a.preset | 0, 0, 99));
      case 'autoFocus': return job('autoFocus'); case 'focus': return job('focus', clamp(+a.value || 0, 0, 1));
      case 'wbAuto': return job('wbAuto'); case 'exposureAuto': return job('exposureAuto');
    }
    return super.act(name);
  }
}

/* ---------------------------------------------------------------- ATEM switcher (network protocol, server-atem.js) */
class Atem extends Device {
  start() { const { AtemClient } = require('./server-atem.js'); this.a = new AtemClient(this.host, this.port);
    this.a.on('state', () => { this.sync(); this.changed(); }); this.a.on('ready', () => this._online(true)); this.a.on('disconnected', () => { this.state.online = false; this.changed(); this.hub.monitor('device', `${this.cfg.name}: offline`); });
    this.a.on('error', e => this._error(e)); this.a.connect(); }
  retry() {}
  sync() { const S = this.a.state; Object.assign(this.state, { info: { model: S.model, mes: S.mes, dsks: S.dsks, auxes: S.auxes },
      inputs: Object.values(S.inputs).filter(i => i.id === 0 || (i.id > 0 && i.id < 1000) || (i.id >= 3010 && i.id <= 3040) || i.id === 1000 || i.id === 2001 || i.id === 2002).map(i => ({ id: i.id, name: i.name, short: i.short })),
      program: S.program[0], preview: S.preview[0], ftb: !!(S.ftb[0] && S.ftb[0].black), dsk: S.dsk, aux: S.aux, macros: Object.values(S.macros), tally: S.tally, recording: S.recording, streaming: S.streaming, programs: S.program, previews: S.preview }); }
  stop() { this.stopped = true; super.stop(); this.a && this.a.close(); }
  actions() { return [['program', 'Program input', ['input', 'me']], ['preview', 'Preview input', ['input', 'me']], ['cut', 'Cut', ['me']], ['auto', 'Auto transition', ['me']], ['ftb', 'Fade to black', ['me']],
    ['transition', 'Transition style / mix rate', ['style', 'frames', 'me']], ['dsk', 'Downstream key on/off', ['key', 'on']], ['dskAuto', 'Downstream key auto', ['key']], ['usk', 'Upstream key on/off', ['key', 'on', 'me']],
    ['aux', 'Aux output source', ['aux', 'input']], ['macro', 'Run macro', ['macro']], ['macroStop', 'Stop macro'], ['camera', 'Camera control', ['camera', 'param', 'value']],
    ['record', 'Record on/off', ['on']], ['stream', 'Stream on/off', ['on']]]; }
  async act(name, a = {}) {
    const A = this.a, me = Math.max(0, (+a.me || 1) - 1), inp = v => { const n = +v; if (Number.isFinite(n)) return n; const f = Object.values(A.state.inputs).find(i => [i.name, i.short].some(x => x && x.toLowerCase() === String(v).toLowerCase())); if (!f) throw new Error('no ATEM input "' + v + '"'); return f.id; };
    const on = v => !(v === false || v === 0 || v === '0' || v === 'false' || v === 'off');
    switch (name) {
      case 'program': return A.program(inp(a.input), me); case 'preview': return A.preview(inp(a.input), me);
      case 'cut': return A.cut(me); case 'auto': return A.auto(me); case 'ftb': return A.ftb(me);
      case 'transition': { const st = { mix: 0, dip: 1, wipe: 2, dve: 3, sting: 4, stinger: 4 }[String(a.style || '').toLowerCase()]; if (st != null) await A.transitionStyle(st, me); if (a.frames) await A.mixRate(+a.frames, me); return; }
      case 'dsk': { const k = Math.max(0, (+a.key || 1) - 1); return A.dskOnAir(k, a.on == null ? !(A.state.dsk[k] && A.state.dsk[k].onAir) : on(a.on)); }
      case 'dskAuto': return A.dskAuto(Math.max(0, (+a.key || 1) - 1));
      case 'usk': { const k = Math.max(0, (+a.key || 1) - 1); return A.uskOnAir(k, a.on == null ? !A.state.usk[`${me}:${k}`] : on(a.on), me); }
      case 'aux': return A.aux(Math.max(0, (+a.aux || 1) - 1), inp(a.input));
      case 'macro': return A.macro(Math.max(0, +a.macro || 0), 0); case 'macroStop': return A.macro(0, 1);
      case 'camera': { const v = a.value == null ? [] : String(a.value).split(',').map(Number); return A.camera(+a.camera || 1, a.param, a.param === 'whiteBalance' && v.length === 1 ? [v[0], 0] : v); }
      case 'record': return A.record(on(a.on == null ? A.state.recording !== 'recording' : a.on));
      case 'stream': return A.stream(on(a.on == null ? A.state.streaming !== 'streaming' : a.on));
    }
    return super.act(name);
  }
}

const CLASSES = { videohub: Videohub, hyperdeck: HyperDeck, streamer: Streamer, bmcamera: BMCamera, birddog: BirdDog, panasonic: Panasonic, pantrack: PanTrack, visca: Visca, ndiptz: NdiPtz, atem: Atem };
// LED processors (Novastar COEX / controllers / H series, Megapixel HELIOS, DMX-controlled) — server-ledproc.js
const LEDPROC = require('./server-ledproc.js')({ Device, httpReq, clamp, net, dgram, crypto }); Object.assign(TYPES, LEDPROC.TYPES); Object.assign(CLASSES, LEDPROC.CLASSES);
// projectors over PJLink — server-pjlink.js
const PJ = require('./server-pjlink.js')({ Device, net, dgram, crypto }); Object.assign(TYPES, PJ.TYPES); Object.assign(CLASSES, PJ.CLASSES);

/* ---------------------------------------------------------------- hub */
module.exports = function devices(ctx) {
  // ctx: { settings, saveSettings(), broadcast(), monitor() }
  const list = new Map(); let pushT = null;
  // jobs for the desktop app (NDI PTZ, ATEM): long-polled by the app's main process
  const jobs = [], waiting = [], pending = new Map();
  const hub = {
    monitor: (...a) => ctx.monitor(...a),
    dmx: a => { if (!ctx.dmx) throw new Error('DMX output unavailable'); return ctx.dmx(a); },
    changed: () => { if (!pushT) pushT = setTimeout(() => { pushT = null; ctx.broadcast({ t: 'devices', devices: views() }); }, 150); },
    native: (job, timeout = 5000) => new Promise((ok, bad) => {
      const id = crypto.randomBytes(6).toString('hex'); job.id = id;
      const t = setTimeout(() => { pending.delete(id); const i = jobs.indexOf(job); if (i >= 0) jobs.splice(i, 1); bad(new Error('the PIXORA desktop app did not answer (NDI PTZ needs the desktop app running)')); }, timeout);
      pending.set(id, r => { clearTimeout(t); ok(r); });
      const w = waiting.shift(); if (w) w(job); else jobs.push(job);
    }),
  };
  const views = () => [...list.values()].map(d => d.view());
  const cfgs = () => (ctx.settings.devices = ctx.settings.devices || []);
  function startOne(cfg) { const C = CLASSES[cfg.type]; if (!C) return; const d = new C(cfg, hub); list.set(cfg.id, d); try { d.start(); } catch (e) { d._error(e); } }
  function stopOne(id) { const d = list.get(id); if (d) { d.stopped = true; try { d.stop(); } catch {} list.delete(id); } }
  for (const c of cfgs()) startOne(c);

  function upsert(c) {
    if (!TYPES[c.type]) throw new Error('unknown device type ' + c.type);
    const all = cfgs(); const id = c.id || crypto.randomBytes(4).toString('hex');
    const clean = { id, type: c.type, name: String(c.name || TYPES[c.type].label).slice(0, 60), host: String(c.host || '').trim().slice(0, 200), port: c.port ? +c.port : undefined,
      camId: c.camId ? +c.camId : undefined, tcp: !!c.tcp || undefined, source: c.source ? String(c.source).slice(0, 200) : undefined, user: c.user || undefined, password: c.password || undefined,
      opts: c.opts && typeof c.opts === 'object' ? Object.fromEntries(Object.entries(c.opts).slice(0, 30).filter(([k, v]) => /^\w{1,30}$/.test(k) && ['string', 'number', 'boolean'].includes(typeof v)).map(([k, v]) => [k, typeof v === 'string' ? v.slice(0, 200) : v])) : undefined };
    if (!['ndiptz', 'led-dmx'].includes(c.type) && !clean.host) throw new Error('enter the device IP address or host name');
    const i = all.findIndex(x => x.id === id); if (i >= 0 && !c.password && all[i].password) clean.password = all[i].password; // blank = keep the saved password
    if (i >= 0) all[i] = clean; else all.push(clean);
    ctx.saveSettings(); stopOne(id); startOne(clean); hub.changed(); return list.get(id).view();
  }
  function remove(id) { const all = cfgs(); const i = all.findIndex(x => x.id === id); if (i >= 0) all.splice(i, 1); ctx.saveSettings(); stopOne(id); hub.changed(); }
  function find(ref) { if (list.has(ref)) return list.get(ref); const r = String(ref || '').toLowerCase(); return [...list.values()].find(d => d.cfg.name.toLowerCase() === r) || null; }
  async function run(ref, action, args) {
    const d = find(ref); if (!d) throw new Error('no device called "' + ref + '"');
    try { const r = await d.act(action, args || {}); ctx.monitor('device', `${d.cfg.name} ▸ ${action} ${args && Object.keys(args).length ? JSON.stringify(args) : ''}`); return r; }
    catch (e) { ctx.monitor('device', `${d.cfg.name} ▸ ${action} failed: ${e.message}`); throw e; }
  }

  async function http(p, req, res, url, send, readBody) {
    if (!p.startsWith('/api/devices') && !p.startsWith('/api/native/')) return false;
    try {
      if (p === '/api/native/poll') { // desktop app long-poll
        if (!req.headers['x-app-token']) { send(res, 403, { error: 'desktop app only' }); return true; }
        if (jobs.length) { send(res, 200, jobs.shift()); return true; }
        let done = false; const w = job => { if (done) return; done = true; send(res, 200, job); };
        waiting.push(w); setTimeout(() => { if (done) return; done = true; const i = waiting.indexOf(w); if (i >= 0) waiting.splice(i, 1); send(res, 200, {}); }, 25000); return true;
      }
      if (p === '/api/native/result' && req.method === 'POST') { const b = JSON.parse((await readBody(req)).toString() || '{}'); const f = pending.get(b.id); if (f) { pending.delete(b.id); f(b.result); } send(res, 200, { ok: true }); return true; }
      if (p === '/api/devices/pjlink-search') { send(res, 200, { found: await PJ.discover(+url.searchParams.get('ms') || 2000) }); return true; }
      if (p === '/api/devices' && req.method === 'GET') { send(res, 200, { devices: views(), types: TYPES }); return true; }
      if (p === '/api/devices' && req.method === 'POST') { send(res, 200, upsert(JSON.parse((await readBody(req)).toString() || '{}'))); return true; }
      let m = /^\/api\/devices\/([^/]+)$/.exec(p);
      if (m && req.method === 'DELETE') { remove(decodeURIComponent(m[1])); send(res, 200, { ok: true }); return true; }
      m = /^\/api\/devices\/([^/]+)\/([A-Za-z]+)$/.exec(p);
      if (m) { let args = Object.fromEntries(url.searchParams); if (req.method === 'POST') { try { args = Object.assign(args, JSON.parse((await readBody(req)).toString() || '{}')); } catch {} }
        const r = await run(decodeURIComponent(m[1]), m[2], args); send(res, 200, { ok: true, result: r && r.kv ? r.kv : r && r.state ? r.state : undefined }); return true; }
    } catch (e) { send(res, 400, { error: e.message }); return true; }
    return false;
  }
  // OSC: /pixora/device/<name|id>/<action> [args as "k=v" strings or numbers in action order]
  function osc(addr, args) {
    const m = /^\/(?:pixora|bvj)\/device\/([^/]+)\/([A-Za-z]+)$/.exec(addr); if (!m) return false;
    const d = find(decodeURIComponent(m[1])); if (!d) { ctx.monitor('device', 'OSC: no device ' + m[1]); return true; }
    const spec = (d.actions().find(x => x[0] === m[2]) || [])[2] || []; const a = {};
    args.forEach((v, i) => { if (typeof v === 'string' && v.includes('=')) { const [k, ...r] = v.split('='); a[k] = r.join('='); } else if (spec[i]) a[spec[i]] = v; });
    run(d.cfg.id, m[2], a).catch(() => {});
    return true;
  }
  return { TYPES, views, upsert, remove, run, http, osc, find, native: hub.native };
};
