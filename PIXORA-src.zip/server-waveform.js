/* PIXORA — audio waveform peaks for the timeline: ffmpeg decodes a media file's audio to 8 kHz mono, we keep one peak
 * per 10 ms (0–255), cached on disk by path + size + mtime. Without ffmpeg the controller decodes in the browser and
 * posts its peaks here, so every controller shares one cache. */
'use strict';
const fs = require('fs'), fsp = fs.promises, path = require('path'), crypto = require('crypto'), { spawn } = require('child_process');
const RATE = 100; // peaks per second

module.exports = function (ctx) {
  const { FFMPEG, ffmpegOk, resolveMedia, DATA } = ctx; const DIR = path.join(DATA, 'waves');
  const pending = new Map();
  const keyFor = async abs => { const st = await fsp.stat(abs).catch(() => null); if (!st || !st.isFile()) return null; return crypto.createHash('sha1').update(abs + '|' + st.size + '|' + st.mtimeMs).digest('hex').slice(0, 20); };

  function decode(abs) {
    return new Promise((ok, bad) => {
      const ff = spawn(FFMPEG, ['-v', 'error', '-nostdin', '-i', abs, '-vn', '-ac', '1', '-ar', '8000', '-f', 's16le', '-'], { windowsHide: true });
      const per = 8000 / RATE, peaks = []; let cur = 0, n = 0, carry = null, err = '';
      ff.stdout.on('data', b => { if (carry) { b = Buffer.concat([carry, b]); carry = null; } const even = b.length & ~1; if (even < b.length) carry = b.subarray(even);
        for (let i = 0; i < even; i += 2) { const v = Math.abs(b.readInt16LE(i)); if (v > cur) cur = v; if (++n >= per) { peaks.push(Math.min(255, Math.round(Math.sqrt(cur / 32768) * 255))); cur = 0; n = 0; } } });
      ff.stderr.on('data', d => { err += d; if (err.length > 4000) err = err.slice(-4000); });
      ff.on('error', bad);
      ff.on('close', code => { if (n) peaks.push(Math.min(255, Math.round(Math.sqrt(cur / 32768) * 255)));
        if (code !== 0 && !peaks.length) { if (/does not contain any stream|Output file #0 does not contain|matches no streams/i.test(err)) return ok(null); return bad(new Error(err.trim().split('\n').pop() || 'ffmpeg failed')); }
        ok(Buffer.from(peaks)); });
    });
  }
  // peaks are sqrt-scaled so quiet passages still show; drawing uses them as-is
  async function get(src) {
    const abs = resolveMedia(src); if (!abs) return { status: 404, body: { error: 'no such media' } };
    const key = await keyFor(abs); if (!key) return { status: 404, body: { error: 'no such media' } }; const file = path.join(DIR, key + '.json');
    try { return { status: 200, body: JSON.parse(await fsp.readFile(file, 'utf8')) }; } catch {}
    if (!ffmpegOk()) return { status: 202, body: { pending: false, needClient: true, key } }; // the controller decodes and posts
    if (!pending.has(key)) pending.set(key, decode(abs).then(async buf => {
      const out = buf ? { rate: RATE, duration: buf.length / RATE, peaks: buf.toString('base64') } : { rate: RATE, duration: 0, none: true };
      await fsp.mkdir(DIR, { recursive: true }); await fsp.writeFile(file, JSON.stringify(out)); return out;
    }).finally(() => pending.delete(key)));
    try { return { status: 200, body: await pending.get(key) }; } catch (e) { return { status: 500, body: { error: String(e.message || e) } }; }
  }
  async function put(src, body) {
    const abs = resolveMedia(src); if (!abs) return { status: 404, body: { error: 'no such media' } };
    const key = await keyFor(abs); if (!key) return { status: 404, body: { error: 'no such media' } }; let j; try { j = JSON.parse(body); } catch { return { status: 400, body: { error: 'bad JSON' } }; }
    const peaks = Buffer.from(String(j.peaks || ''), 'base64'); if (!j.none && (!peaks.length || peaks.length > RATE * 60 * 60 * 6)) return { status: 400, body: { error: 'bad peaks' } };
    const out = j.none ? { rate: RATE, duration: 0, none: true } : { rate: RATE, duration: peaks.length / RATE, peaks: peaks.toString('base64') };
    await fsp.mkdir(DIR, { recursive: true }); await fsp.writeFile(path.join(DIR, key + '.json'), JSON.stringify(out)); return { status: 200, body: { ok: true } };
  }
  return { get, put, RATE };
};
