# HDR / 10-bit in real Chrome: the per-output Rec.2020 / PQ / HLG transform (code values checked against the formulas),
# the 16-bit float pipeline, and the GPU v210 packer (decoded back to Y'CbCr, Rec.709 and Rec.2020 matrices, line padding).
#   python3 tests/hdr_check.py [path-to-chrome]
import json, urllib.request, subprocess, os, time, sys, tempfile, signal, math
from playwright.sync_api import sync_playwright
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); CHROME = sys.argv[1] if len(sys.argv) > 1 else '/usr/bin/google-chrome'
B = 'http://127.0.0.1:8995'; tmp = tempfile.mkdtemp()
srv = subprocess.Popen(['node', 'server.js'], cwd=ROOT, env=dict(os.environ, PORT='8995', OSC_PORT='8996', DATA_DIR=tmp + '/d', MEDIA_DIR=tmp + '/m'), stdout=open(tmp + '/log', 'w'), stderr=subprocess.STDOUT)
def cmd(b): return json.loads(urllib.request.urlopen(urllib.request.Request(B + '/api/cmd', data=json.dumps(b).encode(), headers={'Content-Type': 'application/json'})).read() or b'{}')
for _ in range(60):
  try: urllib.request.urlopen(B + '/api/info'); break
  except Exception: time.sleep(0.2)
ok = lambda m: print('✓ ' + m)
def pq(nits): y = nits / 10000; p = y ** 0.1593017578125; return ((0.8359375 + 18.8515625 * p) / (1 + 18.6875 * p)) ** 78.84375
def hlg(L): return math.sqrt(3 * L) if L <= 1 / 12 else 0.17883277 * math.log(12 * L - 0.28466892) + 0.55991073
try:
  W, H = 100, 8  # not a multiple of 48: the last v210 group is padding
  for k, v in [('comp.width', W), ('comp.height', H)]: cmd({'op': 'set', 'path': k, 'value': v})
  solid = lambda c: {'type': 'gen', 'name': c, 'gen': {'kind': 'solid', 'params': {'c1': c}}}
  cmd({'op': 'assign', 'layer': 0, 'slot': 0, 'clip': solid('#ff0000')}); cmd({'op': 'assign', 'layer': 0, 'slot': 1, 'clip': solid('#ffffff')}); cmd({'op': 'trigger', 'layer': 0, 'clip': 1})
  with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=['--use-gl=swiftshader', '--enable-unsafe-swiftshader']); pg = b.new_page(viewport={'width': 320, 'height': 180}); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(B + '/clean?out=main&fs=0'); time.sleep(2)
    px = lambda: pg.evaluate("() => { const gl = engine.gl, a = new Uint8Array(4); gl.bindFramebuffer(gl.FRAMEBUFFER, engine.fH.f); gl.readPixels(4, 4, 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, a); return Array.from(a) }")
    def setc(**kw):
      for k, v in kw.items(): cmd({'op': 'set', 'path': 'outputs.0.color.' + k, 'value': v})
      time.sleep(1.2)
    setc(space='2020', eotf='pq', paper=203, peak=1000); c = px(); want = round(pq(203) * 255)
    assert all(abs(x - want) <= 2 for x in c[:3]), (c, want); ok(f'PQ: SDR white at 203 nits → code {c[0]} (formula {want})')
    setc(eotf='hlg'); c = px(); want = round(hlg(0.2627) * 255); assert all(abs(x - want) <= 2 for x in c[:3]), (c, want); ok(f'HLG: SDR white → code {c[0]} (≈75 %, formula {want})')
    cmd({'op': 'trigger', 'layer': 0, 'clip': 0}); setc(eotf='sdr', space='2020'); c = px()
    lin = [0.6274, 0.0691, 0.0164]; want = [round(x ** (1 / 2.4) * 255) for x in lin]; assert all(abs(a - b) <= 3 for a, b in zip(c, want)), (c, want, pg.evaluate('() => { const r = engine.layers[0]; return [r.cur && r.cur.clip.gen.params, !!r.pending, !!r.prev, r.transMode, r.transDur, performance.now() - r.transStart, engine.fps, r.cur.ready] }')); ok(f'Rec.709 red in Rec.2020 SDR: {c[:3]} (formula {want})')
    setc(space='709', eotf='sdr')
    cmd({'op': 'set', 'path': 'comp.precision', 'value': '16f'}); time.sleep(0.8)
    fmt = pg.evaluate("() => { const gl = engine.gl; gl.bindFramebuffer(gl.FRAMEBUFFER, engine.cF.f); return [engine.hiPrec, gl.getFramebufferAttachmentParameter(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE) === gl.FLOAT] }")
    assert fmt == [True, True], fmt; ok('16-bit float pipeline: the comp buffers are half-float')
    def v210(m2020):
      d = pg.evaluate(f"() => {{ const r = engine.packV210({str(m2020).lower()}); return {{ b: Array.from(r.bytes), rb: r.rowBytes }} }}"); bs, rb = bytes(d['b']), d['rb']
      assert rb == math.ceil(W / 48) * 128 and len(bs) == rb * H, (rb, len(bs))
      row = bs[2 * rb:3 * rb]; words = [int.from_bytes(row[i:i + 4], 'little') for i in range(0, rb, 4)]; f = lambda w: (w & 1023, w >> 10 & 1023, w >> 20 & 1023)
      cb0, y0, cr0 = f(words[0]); y1, cb2, y2 = f(words[1]); last = f(words[(W // 6) * 4 - 1]); return (y0, cb0, cr0, y1, y2), words
    (y0, cb, cr, y1, y2), _ = v210(False); kr, kb = 0.2126, 0.0722; e = (round(64 + 876 * kr), round(512 + 896 * (-kr) / (2 * (1 - kb))), round(512 + 896 * (1 - kr) / (2 * (1 - kr))))
    assert abs(y0 - e[0]) <= 2 and y0 == y1 == y2 and abs(cb - e[1]) <= 2 and abs(cr - e[2]) <= 2, ((y0, cb, cr), e); ok(f"v210 Rec.709: red → Y' {y0} Cb {cb} Cr {cr} (expected {e})")
    (y0, cb, cr, _, _), _ = v210(True); kr, kb = 0.2627, 0.0593; e = (round(64 + 876 * kr), round(512 + 896 * (-kr) / (2 * (1 - kb))), round(512 + 896 * (1 - kr) / (2 * (1 - kr))))
    assert abs(y0 - e[0]) <= 2 and abs(cb - e[1]) <= 2 and abs(cr - e[2]) <= 2, ((y0, cb, cr), e); ok(f"v210 Rec.2020 matrix: Y' {y0} Cb {cb} Cr {cr} (expected {e})")
    cmd({'op': 'trigger', 'layer': 0, 'clip': 1}); time.sleep(0.6); (y0, cb, cr, _, _), words = v210(False)
    assert abs(y0 - 940) <= 1 and abs(cb - 512) <= 1 and abs(cr - 512) <= 1, (y0, cb, cr); ok(f"white → Y' {y0} / Cb {cb} / Cr {cr} (limited range 940 / 512)")
    assert not errs, errs; b.close()
  print('HDR check passed')
finally: srv.send_signal(signal.SIGTERM)
