// Timeline events and actions out: OSC and DMX (Art-Net) fired as the playhead passes; seek skips; loop re-fires.
//   node tests/timeline_events_test.js
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert'), dgram = require('dgram');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
function oscParse(b) { const s = o => { const e = b.indexOf(0, o); return [b.toString('latin1', o, e), (e + 4) & ~3]; }; let [addr, o] = s(0); let tags; [tags, o] = s(o); const args = [];
  for (const t of tags.slice(1)) { if (t === 'i') { args.push(b.readInt32BE(o)); o += 4; } else if (t === 'f') { args.push(+b.readFloatBE(o).toFixed(4)); o += 4; } else if (t === 's') { let v; [v, o] = s(o); args.push(v); } } return { addr, tags, args }; }
(async () => {
  const osc = [], dmx = [];
  const o = dgram.createSocket('udp4'); o.on('message', b => osc.push({ at: Date.now(), ...oscParse(b) })); await new Promise(r => o.bind(8849, '127.0.0.1', r));
  const a = dgram.createSocket({ type: 'udp4', reuseAddr: true }); a.on('message', b => { if (b.toString('latin1', 0, 7) === 'Art-Net' && b.readUInt16LE(8) === 0x5000) dmx.push({ at: Date.now(), uni: b[14], ch: [b[18], b[19], b[20]] }); }); await new Promise(r => a.bind(6454, '127.0.0.1', r));
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8847, OSC_PORT: 8848, DATA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxtl-')), MEDIA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxtlm-')) }, stdio: 'ignore' }); kids.push(srv);
  const B = 'http://127.0.0.1:8847';
  for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const cmd = c => fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(c) }); const st = () => fetch(B + '/api/state').then(r => r.json());
  // actions on their own
  await cmd({ op: 'runAction', action: { type: 'osc', host: '127.0.0.1', port: 8849, address: '/cue/7/start', args: '1 0.5 "two words" true' } }); await tick(200);
  assert.deepStrictEqual(osc[0] && [osc[0].addr, osc[0].tags, osc[0].args], ['/cue/7/start', ',ifsi', [1, 0.5, 'two words', 1]]); ok('Send OSC action: address and typed arguments (int, float, "string", true)');
  await cmd({ op: 'runAction', action: { type: 'dmx', protocol: 'artnet', host: '127.0.0.1', universe: 3, channel: 1, values: '255 50% 7' } }); await tick(200);
  assert.deepStrictEqual(dmx.slice(-1)[0], { at: dmx.slice(-1)[0].at, uni: 3, ch: [255, 128, 7] }); ok('Set DMX action: Art-Net universe 3, channels 1–3 = 255 50% 7');
  dmx.length = 0; await cmd({ op: 'runAction', action: { type: 'dmx', protocol: 'artnet', host: '127.0.0.1', universe: 3, channel: 1, values: '0', fade: 0.6 } }); await tick(300);
  const mid = dmx.filter(d => d.ch[0] > 0 && d.ch[0] < 255); await tick(500); assert.ok(mid.length >= 3, 'fade steps'); assert.strictEqual(dmx.slice(-1)[0].ch[0], 0); ok(`DMX fade 255 → 0 over 0.6 s (${mid.length} steps in between)`);
  await tick(1200); const keep = dmx.filter(d => Date.now() - d.at < 1300).length; assert.ok(keep >= 1, 'keep-alive'); ok('DMX held and re-sent (keep-alive for Art-Net nodes)');
  // timeline events
  osc.length = 0;
  await cmd({ op: 'set', path: 'timeline.duration', value: 2 });
  await cmd({ op: 'tlAddEvent', at: 0.5, name: 'Go haze', action: { type: 'osc', host: '127.0.0.1', port: 8849, address: '/haze', args: '1' } });
  await cmd({ op: 'tlAddEvent', at: 1.2, name: 'Lights', action: { type: 'osc', host: '127.0.0.1', port: 8849, address: '/lights', args: '2' } });
  let s = await st(); assert.deepStrictEqual(s.timeline.events.map(e => [e.name, e.at]), [['Go haze', 0.5], ['Lights', 1.2]]);
  const t0 = Date.now(); await cmd({ op: 'tlPlay' }); await tick(1700);
  const fired = osc.map(m => [m.addr, Math.round((m.at - t0) / 100) / 10]); assert.deepStrictEqual(fired.map(f => f[0]), ['/haze', '/lights'], JSON.stringify(fired));
  assert.ok(Math.abs(fired[0][1] - 0.5) < 0.15 && Math.abs(fired[1][1] - 1.2) < 0.15, JSON.stringify(fired)); ok(`events fire as the playhead passes them (${fired.map(f => f[0] + ' @' + f[1] + 's').join(', ')})`);
  await tick(500); osc.length = 0;
  await cmd({ op: 'tlStop' }); await cmd({ op: 'tlSeek', pos: 0.8 }); await cmd({ op: 'tlPlay' }); await tick(800);
  assert.deepStrictEqual(osc.map(m => m.addr), ['/lights'], 'seek past the first event'); ok('seeking past an event skips it; later events still fire');
  await cmd({ op: 'tlStop' }); osc.length = 0;
  await cmd({ op: 'set', path: 'timeline.loop', value: true }); await cmd({ op: 'tlSeek', pos: 1.5 }); await cmd({ op: 'tlPlay' }); await tick(1400); await cmd({ op: 'tlStop' });
  assert.deepStrictEqual(osc.map(m => m.addr), ['/haze'], JSON.stringify(osc.map(m => m.addr))); ok('looping fires events again on the next pass');
  s = await st(); const id = s.timeline.events[0].id; await cmd({ op: 'tlMoveEvent', id, at: 1.9 }); s = await st(); assert.deepStrictEqual(s.timeline.events.map(e => e.name), ['Lights', 'Go haze']); ok('moving an event keeps the list in time order');
  await cmd({ op: 'tlRemoveEvent', id }); s = await st(); assert.strictEqual(s.timeline.events.length, 1); ok('events can be removed');
  o.close(); a.close(); console.log('timeline_events_test: all passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
