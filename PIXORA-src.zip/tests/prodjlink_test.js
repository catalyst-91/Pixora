// PIXORA direct Pro DJ Link test (no Bridge): two simulated CDJs announce themselves, send beat / status / precise
// position packets, and one serves track metadata over the dbserver protocol (UTF-16BE strings), as documented by
// Deep Symmetry's beat-link research.   node tests/prodjlink_test.js
const { spawn } = require('child_process'); const dgram = require('dgram'), net = require('net'), path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const until = async (fn, ms = 6000) => { const t = Date.now(); while (Date.now() - t < ms) { const v = await fn(); if (v) return v; await tick(50); } throw new Error('timed out waiting'); };
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
const MAGIC = [0x51, 0x73, 0x70, 0x74, 0x31, 0x57, 0x6d, 0x4a, 0x4f, 0x4c];
const put = (b, o, v, n) => { for (let i = n - 1; i >= 0; i--) { b[o + i] = v & 255; v = Math.floor(v / 256); } };

function keepAlive(n, name) { const b = Buffer.alloc(0x36); b.set(MAGIC); b[0x0a] = 0x06; b.write(name, 0x0c, 'latin1'); b[0x20] = 1; b[0x21] = 2; b[0x23] = 0x36; b[0x24] = n; b.set([127, 0, 0, 1], 0x2c); return b; }
function beat(n, bpm, pitchPct, inBar) { const b = Buffer.alloc(0x60); b.set(MAGIC); b[0x0a] = 0x28; b.write('CDJ-3000', 0x0b, 'latin1'); b[0x21] = n; put(b, 0x55, Math.round(0x100000 * (1 + pitchPct / 100)), 3); put(b, 0x5a, Math.round(bpm * 100), 2); b[0x5c] = inBar; return b; }
function status(n, o) { const b = Buffer.alloc(0x11c); b.set(MAGIC); b[0x0a] = 0x0a; b.write('CDJ-3000', 0x0b, 'latin1'); b[0x21] = n; b[0x28] = o.srcPlayer; b[0x29] = 3; b[0x2a] = 1; put(b, 0x2c, o.id, 4);
  b[0x7b] = o.play; b[0x89] = (o.playing ? 0x40 : 0) | (o.master ? 0x20 : 0) | (o.onAir ? 0x08 : 0); put(b, 0x8d, 0x100000, 3); put(b, 0x92, Math.round(o.bpm * 100), 2); put(b, 0xa0, o.beatNo, 4); b[0xa6] = o.inBar; return b; }
function precise(n, lenS, posMs, bpm) { const b = Buffer.alloc(0x3c); b.set(MAGIC); b[0x0a] = 0x0b; b.write('CDJ-3000', 0x0b, 'latin1'); b[0x21] = n; put(b, 0x24, lenS, 4); put(b, 0x28, posMs, 4); put(b, 0x2c, 0, 4); put(b, 0x38, Math.round(bpm * 10), 4); return b; }

/* ---- dbserver mock (field encoding per beat-link's dbserver package) */
const n4 = v => { const b = Buffer.alloc(5); b[0] = 0x11; b.writeUInt32BE(v >>> 0, 1); return b; };
const n2 = v => { const b = Buffer.alloc(3); b[0] = 0x10; b.writeUInt16BE(v, 1); return b; };
const str = s => { const u = Buffer.from(s + '\0', 'utf16le'); for (let i = 0; i < u.length; i += 2) { const x = u[i]; u[i] = u[i + 1]; u[i + 1] = x; } const h = Buffer.alloc(5); h[0] = 0x26; h.writeUInt32BE(u.length / 2, 1); return Buffer.concat([h, u]); };
function msg(txn, type, args, tags) { const t = Buffer.alloc(12); tags.forEach((x, i) => t[i] = x); const bin = Buffer.concat([Buffer.from([0x14, 0, 0, 0, 12]), t]); return Buffer.concat([n4(0x872349ae), n4(txn), n2(type), Buffer.from([0x0f, args.length]), bin, ...args]); }
const item = (type, label, id = 0) => msg(2, 0x4101, [n4(0), n4(id), n4(0), str(label), n4(0), str(''), n4(type), n4(0), n4(0), n4(0)], [6, 6, 6, 2, 6, 2, 6, 6, 6, 6]);
const dbReqs = [];
const portSrv = net.createServer(s => s.once('data', d => { assert.ok(d.toString('latin1').includes('RemoteDBServer')); s.end(Buffer.from([0x2f, 0x2c])); /* 12076 */ }));
const dbSrv = net.createServer(s => { let buf = Buffer.alloc(0), greeted = false;
  s.on('data', d => { buf = Buffer.concat([buf, d]);
    if (!greeted) { if (buf.length < 5) return; s.write(n4(1)); buf = buf.subarray(5); greeted = true; }
    while (buf.length >= 30) { // our requests are small and arrive whole: parse type and the first args
      const type = buf.readUInt16BE(11), argc = buf[14]; let p = 15 + 17, args = []; for (let i = 0; i < argc; i++) { args.push(buf.readUInt32BE(p + 1)); p += 5; } buf = buf.subarray(p); dbReqs.push([type, args]);
      if (type === 0x0000) s.write(msg(0xfffffffe, 0x4000, [n4(0), n4(args[0])], [6, 6]));
      else if (type === 0x2002) s.write(msg(1, 0x4000, [n4(0x2002), n4(6)], [6, 6]));
      else if (type === 0x3000) s.write(Buffer.concat([msg(2, 0x4001, [], []), item(0x04, 'Strobe (Club Edit)'), item(0x07, 'deadmau5'), item(0x02, 'For Lack of a Better Name'),
        item(0x0f, '7A'), item(0x0b, '', 634), item(0x0d, '', 12800), msg(2, 0x4201, [], [])]));
      else if (type === 0x0100) s.end();
    } });
});

(async () => {
  await new Promise(r => portSrv.listen(12523, '127.0.0.1', r)); await new Promise(r => dbSrv.listen(12076, '127.0.0.1', r));
  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxpdl-')), MEDIA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxpdlm-'));
  fs.writeFileSync(path.join(DATA, 'settings.json'), JSON.stringify({ tcnet: { on: true, source: 'direct' } }));
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8883, OSC_PORT: 8884, DATA_DIR: DATA, MEDIA_DIR: MEDIA }, stdio: ['ignore', 'pipe', 'pipe'] }); kids.push(srv);
  let log = ''; srv.stdout.on('data', d => log += d); srv.stderr.on('data', d => log += d);
  const B = 'http://127.0.0.1:8883';
  for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const api = async p => (await fetch(B + p)).json();
  const cdj = dgram.createSocket('udp4'); await new Promise(r => cdj.bind(0, '127.0.0.1', r));
  const send = (b, port) => cdj.send(b, port, '127.0.0.1');
  const st1 = { srcPlayer: 1, id: 812, play: 3, playing: true, master: true, onAir: true, bpm: 128, beatNo: 129, inBar: 1 };
  const st2 = { srcPlayer: 1, id: 0, play: 0, playing: false, master: false, onAir: false, bpm: 0xffff / 100, beatNo: 0xffffffff, inBar: 0 };
  const pump = setInterval(() => { send(keepAlive(1, 'CDJ-3000'), 50000); send(keepAlive(2, 'CDJ-3000'), 50000); send(status(1, st1), 50002); send(status(2, st2), 50002); }, 200);

  let v = await until(async () => { const x = await api('/api/tcnet'); return x.nodes.length === 2 ? x : null; });
  assert.strictEqual(v.status, 'listening'); assert.ok(v.number >= 7); ok(`PIXORA is virtual CDJ #${v.number} and sees ${v.nodes.map(n => n.name + ' ' + n.vendor).join(', ')}`);
  v = await until(async () => { const x = await api('/api/tcnet'); return x.decks[0].title ? x : null; });
  const setup = dbReqs.find(r => r[0] === 0); const md = dbReqs.find(r => r[0] === 0x2002);
  assert.strictEqual(setup[1][0], 1, 'poses as the target player number'); assert.strictEqual(md[1][1], 812); assert.strictEqual(md[1][0], (1 << 24 | 1 << 16 | 3 << 8 | 1) >>> 0);
  assert.strictEqual(v.decks[0].title, 'Strobe (Club Edit)'); assert.strictEqual(v.decks[0].artist, 'deadmau5');
  ok(`dbserver metadata from player 1's USB: "${v.decks[0].artist} – ${v.decks[0].title}" (rekordbox id 812, posing as player 1)`);
  assert.strictEqual(v.master, '1'); assert.strictEqual(v.decks[0].onAir, true); assert.strictEqual(v.decks[0].playing, true); ok('status flags: deck 1 playing, tempo master, on air');

  // beat packets: tempo with pitch, downbeat sets the bar
  const s0 = await api('/api/state'); const e0 = s0.comp.beatEpoch;
  for (let i = 1; i <= 4; i++) { send(beat(1, 128, 2, i), 50001); await tick(460); }
  const t1 = Date.now(); send(beat(1, 128, 2, 1), 50001);
  // the bar start may be the latest downbeat or an earlier one (PIXORA only nudges it when it has drifted >15 ms): either way t1 must sit on a bar line
  const offBar = st => { const bar = 4 * 60000 / st.comp.bpm, ph = (((t1 - st.comp.beatEpoch) % bar) + bar) % bar; return Math.min(ph, bar - ph); };
  const s1 = await until(async () => { const s = await api('/api/state'); return s.comp.beatEpoch !== e0 && s.comp.bpm === 130.56 && offBar(s) < 80 ? s : null; });
  assert.strictEqual(s1.comp.bpm, 130.56); ok(`beat packets: 128 BPM at +2% pitch → PIXORA at ${s1.comp.bpm} BPM, bar lined up with the downbeat (${Math.round(offBar(s1))} ms)`);

  // CDJ-3000 precise position drives timecode
  const post = c => fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(c) });
  await post({ op: 'set', path: 'comp.timecode.source', value: 'tcnet' }); await post({ op: 'set', path: 'cues', value: [{ name: 'Breakdown', tc: '00:02:00:00', layers: [], fade: 0 }] });
  await tick(200); for (let ms = 119000; ms <= 121000; ms += 100) { send(precise(1, 634, ms, 130.56), 50001); await tick(20); }
  await until(async () => (await api('/api/state')).cueIndex === 0, 3000);
  v = await api('/api/tcnet'); assert.strictEqual(v.decks[0].length, 634); ok('CDJ-3000 precise position (2:00 of 10:34) fires the timecode cue at 00:02:00:00');
  const f = await api('/api/feeds'); assert.strictEqual(f.values.djlink.master.title, 'Strobe (Club Edit)'); ok('djlink feed for titles and rules works the same as with the Bridge');

  clearInterval(pump); srv.kill(); cdj.close(); portSrv.close(); dbSrv.close(); console.log('\nAll Pro DJ Link tests passed.'); process.exit(0);
})().catch(e => { console.error('✗', e); process.exit(1); });
