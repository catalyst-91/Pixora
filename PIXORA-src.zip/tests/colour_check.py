# Colour management in real Chrome: 18 % grey encoded in each camera log curve (LogC3, LogC4, S-Log3, V-Log, ACEScct) and
# in PQ / HLG decodes back to scene grey 0.18; tone mapping None → 0.18^(1/2.4), ACES → the fitted ACES curve; exposure works.
import json, urllib.request, subprocess, os, time, sys, tempfile, signal, math
from playwright.sync_api import sync_playwright
from PIL import Image
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); CHROME = sys.argv[1] if len(sys.argv) > 1 else '/usr/bin/google-chrome'
B = 'http://127.0.0.1:9051'; tmp = tempfile.mkdtemp(); os.makedirs(tmp + '/m')
def logc3(x): return 0.247190 * math.log10(5.555556 * x + 0.052272) + 0.385537
def logc4(x): a = (2**18 - 16) / 117.45; b = (1023 - 95) / 1023; c = 95 / 1023; return (math.log2(a * x + 64) - 6) / 14 * b + c
def slog3(x): return (420 + math.log10((x + 0.01) / 0.19) * 261.5) / 1023
def vlog(x): return 0.241514 * math.log10(x + 0.00873) + 0.598206
def acescct(x): return (math.log2(x) + 9.72) / 17.52
def pq(x): y = x * 203 / 10000; p = y ** 0.1593017578125; return ((0.8359375 + 18.8515625 * p) / (1 + 18.6875 * p)) ** 78.84375
def hlg(x): L = x * 0.2627; return math.sqrt(3 * L) if L <= 1 / 12 else 0.17883277 * math.log(12 * L - 0.28466892) + 0.55991073
CASES = {'logc3': logc3, 'logc4': logc4, 'slog3': slog3, 'vlog': vlog, 'acescct': acescct, 'pq': pq, 'hlg': hlg}
for k, f in CASES.items(): v = round(f(0.18) * 255); Image.new('RGB', (64, 36), (v, v, v)).save(f'{tmp}/m/{k}.png')
srv = subprocess.Popen(['node', 'server.js'], cwd=ROOT, env=dict(os.environ, PORT='9051', OSC_PORT='9052', DATA_DIR=tmp + '/d', MEDIA_DIR=tmp + '/m'), stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
def cmd(b): return json.loads(urllib.request.urlopen(urllib.request.Request(B + '/api/cmd', data=json.dumps(b).encode(), headers={'Content-Type': 'application/json'})).read() or b'{}')
for _ in range(60):
  try: urllib.request.urlopen(B + '/api/info'); break
  except Exception: time.sleep(0.2)
ok = lambda m: print('✓ ' + m)
aces = lambda x: (x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14)
try:
  for k, v in [('comp.width', 320), ('comp.height', 180), ('layers.0.transition', 'cut')]: cmd({'op': 'set', 'path': k, 'value': v})
  for i, k in enumerate(CASES): cmd({'op': 'assign', 'layer': 0, 'slot': i, 'clip': {'type': 'image', 'name': k, 'src': f'local/{k}.png', 'fit': 'stretch', 'cs': {'space': k, 'tonemap': 'none', 'exposure': 0, 'saturation': 1, 'gamut': '709'}}})
  with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=['--use-gl=swiftshader', '--enable-unsafe-swiftshader']); pg = b.new_page(viewport={'width': 320, 'height': 180}); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(B + '/clean?out=main&fs=0'); time.sleep(1.5)
    def px(): pg.screenshot(path=tmp + '/c.png'); return Image.open(tmp + '/c.png').convert('RGB').getpixel((160, 90))
    want = round(0.18 ** (1 / 2.4) * 255); got = {}
    for i, k in enumerate(CASES):
      cmd({'op': 'trigger', 'layer': 0, 'clip': i}); time.sleep(0.9); c = px(); got[k] = c[0]
      assert all(abs(x - want) <= 6 for x in c), (k, c, want)
    ok(f'18 % grey in {", ".join(CASES)} decodes to scene grey: {got} (expected {want})')
    cmd({'op': 'set', 'path': 'layers.0.clips.0.cs.tonemap', 'value': 'aces'}); cmd({'op': 'trigger', 'layer': 0, 'clip': 0}); time.sleep(0.9); c = px(); w2 = round(aces(0.18) ** (1 / 2.4) * 255)
    assert abs(c[0] - w2) <= 5, (c, w2); ok(f'ACES tone mapping: {c[0]} (expected {w2})')
    cmd({'op': 'set', 'path': 'layers.0.clips.0.cs.exposure', 'value': 1}); time.sleep(0.9); c = px(); w3 = round(aces(0.36) ** (1 / 2.4) * 255)
    assert abs(c[0] - w3) <= 5, (c, w3); ok(f'+1 stop exposure: {c[0]} (expected {w3})')
    cmd({'op': 'set', 'path': 'layers.0.clips.0.cs.space', 'value': 'rec709'}); time.sleep(0.9); c = px(); assert abs(c[0] - round(logc3(0.18) * 255)) <= 3, c; ok('Rec.709 = untouched (the flat log picture)')
    # 2.5D depth: colour (left red / right blue) beside a depth map; near pixels shift with the camera, far ones don't
    from PIL import ImageDraw
    for name, dv in (('near', 255), ('far', 0)):
      im = Image.new('RGB', (128, 36)); dr = ImageDraw.Draw(im); dr.rectangle([0, 0, 31, 35], fill=(255, 0, 0)); dr.rectangle([32, 0, 63, 35], fill=(0, 0, 255)); dr.rectangle([64, 0, 127, 35], fill=(dv, dv, dv)); im.save(f'{tmp}/m/rgbd_{name}.png')
    res = {}
    for i, name in enumerate(('near', 'far')):
      cmd({'op': 'assign', 'layer': 1, 'slot': i, 'clip': {'type': 'image', 'name': name, 'src': f'local/rgbd_{name}.png', 'fit': 'stretch', 'depth': {'on': True, 'layout': 'sbs', 'amount': 0.1, 'focus': 0, 'invert': False, 'offX': 1, 'offY': 0, 'swayX': 0, 'swayY': 0, 'swaySpeed': 0.2, 'follow': ''}}})
      cmd({'op': 'set', 'path': 'layers.1.transition', 'value': 'cut'}); cmd({'op': 'trigger', 'layer': 1, 'clip': i}); time.sleep(0.9); pg.screenshot(path=tmp + '/c.png'); im = Image.open(tmp + '/c.png').convert('RGB'); res[name] = (im.getpixel((176, 90)), im.getpixel((100, 90)))
    assert res['near'][0][0] > 200 and res['near'][0][2] < 60 and res['far'][0][2] > 200 and res['far'][0][0] < 60 and res['near'][1][0] > 200, res
    ok(f'2.5D depth: side-by-side RGB-D shows only the colour half; near pixels shift with the camera, far ones stay {res}')
    assert not errs, errs; b.close()
  print('Colour check passed')
finally: srv.send_signal(signal.SIGTERM)
