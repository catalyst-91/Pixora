// Timecode chase from a reader (the desktop app's background reader or a browser): 29.97 drop-frame labels, cues
// firing on drop-frame times, freewheel through a dropout, then "lost", and relock. Plus the reader's status reaching
// controllers.
//   node tests/timecode_chase_test.js
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const T = require(path.join(ROOT, 'public', 'tc-decoders.js'));
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
(async () => {
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8961, OSC_PORT: 8962, DATA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxtc-')), MEDIA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxtcm-')) }, stdio: 'ignore' }); kids.push(srv);
  const B = 'http://127.0.0.1:8961'; for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const cmd = c => fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(c) });
  await cmd({ op: 'set', path: 'comp.timecode.source', value: 'ltc' }); await cmd({ op: 'set', path: 'comp.timecode.reader', value: 'app' }); await cmd({ op: 'set', path: 'comp.timecode.freewheel', value: 10 });
  await cmd({ op: 'cueAdd' }); await cmd({ op: 'set', path: 'cues.0.tc', value: '00:01:00;02' }); await cmd({ op: 'set', path: 'cues.0.name', value: 'Act 2' });
  const ctl = new WebSocket(B.replace('http', 'ws') + '/ws?role=control'); const seen = []; let readerMsg = null; ctl.onmessage = e => { try { const m = JSON.parse(e.data); if (m.t === 'tc') seen.push(m); if (m.t === 'tcreader') readerMsg = m.reader; } catch {} };
  const rd = new WebSocket(B.replace('http', 'ws') + '/ws?role=tcreader'); await new Promise(r => rd.onopen = r); await new Promise(r => ctl.readyState === 1 ? r() : (ctl.onopen = r));
  rd.send(JSON.stringify({ t: 'tcreaderStatus', running: 'ltc:', devices: { audio: ['Scarlett 2i2 USB'], midi: [] }, level: 0.42, label: '' })); await tick(200);
  assert.deepStrictEqual(readerMsg.devices.audio, ['Scarlett 2i2 USB']); ok('the desktop reader reports its inputs to controllers');
  const start = T.toFrames(0, 0, 59, 20, 29.97, true);
  for (let k = 0; k < 20; k++) { rd.send(JSON.stringify({ t: 'tc', src: 'ltc', frames: start + k, fps: 29.97, drop: true, level: 0.4 })); await tick(33); }
  await tick(40); let last = seen.filter(m => m.status === 'locked').pop();
  assert.strictEqual(last.status, 'locked'); assert.strictEqual(last.drop, true); assert.strictEqual(last.fps, 29.97); assert.strictEqual(last.label, T.label(T.fromFrames(last.frames, 29.97, true), true)); assert.ok(/^00:01:00;(0[2-9]|1[01])$/.test(last.label), last.label); ok(`locked to 29.97 DF LTC (${last.label})`);
  const st2 = await fetch(B + '/api/state').then(r => r.json()); assert.strictEqual(st2.cueIndex, 0, 'cue 0 fired at 00:01:00;02'); ok('cue at 00:01:00;02 fired as the drop-frame clock passed it');
  // dropout → freewheel → lost
  seen.length = 0; await tick(230); assert.ok(seen.some(m => m.status === 'freewheel' && m.frames > start + 19), 'freewheel ' + JSON.stringify(seen.slice(-2)));
  await tick(500); assert.strictEqual(seen[seen.length - 1].status, 'lost'); const lostAt = seen[seen.length - 1].frames; assert.ok(lostAt <= start + 19 + 11, 'stops after the freewheel window'); ok(`dropout: freewheels ${lostAt - (start + 19)} frames, then reports lost`);
  seen.length = 0; rd.send(JSON.stringify({ t: 'tc', src: 'ltc', frames: start + 100, fps: 29.97, drop: true })); await tick(60); assert.ok(seen.some(m => m.status === 'locked' && m.frames === start + 100)); ok('relocks when timecode returns');
  // a browser-side reader for a different source is ignored
  seen.length = 0; rd.send(JSON.stringify({ t: 'tc', src: 'mtc', frames: 5, fps: 25 })); await tick(150); assert.ok(!seen.some(m => m.frames === 5)); ok('readers for another source are ignored');
  process.exit(0);
})().catch(e => { console.error('✗', e.stack || e.message); process.exit(1); });
