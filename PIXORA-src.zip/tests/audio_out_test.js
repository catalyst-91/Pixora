// Audio outputs: buses in the show (always a Main), add / remove / rename, layer and clip routes, routes to a removed bus
// fall back to Main, older shows get a Main bus, and the output window's device report reaches controllers.
//   node tests/audio_out_test.js      (routing in a real browser: tests/audio_check.py)
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
(async () => {
  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxao-'));
  const start = () => { const k = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8921, OSC_PORT: 8922, DATA_DIR: DATA, MEDIA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxaom-')) }, stdio: 'ignore' }); kids.push(k); return k; };
  let srv = start(); const B = 'http://127.0.0.1:8921', up = async () => { for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150); }; await up();
  const cmd = c => fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(c) }).then(r => r.json());
  const state = () => fetch(B + '/api/state').then(r => r.json());
  let st = await state(); assert.deepStrictEqual(st.comp.audioOuts.map(a => [a.id, a.name, a.ch]), [['main', 'Main', 1]]); assert.strictEqual(st.layers[0].audioOut, 'main');
  await cmd({ op: 'audioOutAdd', name: 'Record feed', ch: 3 }); await cmd({ op: 'audioOutAdd', name: 'Monitors' });
  st = await state(); const [m, rec, mon] = st.comp.audioOuts; assert.deepStrictEqual([rec.name, rec.ch, mon.name, mon.gain, mon.delay, mon.mono], ['Record feed', 3, 'Monitors', 1, 0, false]);
  await cmd({ op: 'set', path: 'comp.audioOuts.1.device', value: 'dante-id' }); await cmd({ op: 'set', path: 'comp.audioOuts.1.deviceLabel', value: 'Dante Virtual Soundcard' });
  await cmd({ op: 'set', path: 'comp.audioOuts.1.delay', value: 120 }); await cmd({ op: 'set', path: 'layers.1.audioOut', value: rec.id });
  await cmd({ op: 'assign', layer: 0, slot: 0, clip: { type: 'video', name: 'Walk-in', src: 'local/a.mp4' } }); await cmd({ op: 'clipAudioOut', layer: 0, slot: 0, out: mon.id });
  st = await state(); assert.strictEqual(st.layers[1].audioOut, rec.id); assert.strictEqual(st.layers[0].clips[0].audioOut, mon.id); assert.strictEqual(st.comp.audioOuts[1].delay, 120);
  await cmd({ op: 'clipAudioOut', layer: 0, slot: 0, out: 'nope' }); st = await state(); assert.ok(!('audioOut' in st.layers[0].clips[0]), 'unknown output → follow layer');
  await cmd({ op: 'clipAudioOut', layer: 0, slot: 0, out: mon.id });
  ok('add outputs (device, channel pair, delay), route a layer and a clip; an unknown output means “follow layer”');
  let r = await cmd({ op: 'audioOutDel', id: 'main' }); assert.ok(r.error || r.ok === false, 'Main cannot be removed');
  await cmd({ op: 'audioOutDel', id: mon.id }); await cmd({ op: 'audioOutDel', id: rec.id }); st = await state();
  assert.deepStrictEqual(st.comp.audioOuts.map(a => a.id), ['main']); assert.strictEqual(st.layers[1].audioOut, 'main'); assert.ok(!('audioOut' in st.layers[0].clips[0]));
  ok('removing an output sends its layers and clips back to Main; Main stays');
  // older show without buses / with junk
  const show = await state(); delete show.comp.audioOuts; show.layers[0].audioOut = 'gone'; show.comp.audioOuts = [{ id: 'x y', name: 'X', ch: 999, gain: 'loud' }, { id: 'x y' }];
  fs.writeFileSync(path.join(DATA, 'state.json'), JSON.stringify(show)); srv.kill(); await tick(400); srv = start(); await up(); st = await state();
  assert.deepStrictEqual(st.comp.audioOuts.map(a => [a.id, a.ch, a.gain]), [['main', 1, 1], ['xy', 63, 1]]); assert.strictEqual(st.layers[0].audioOut, 'main');
  ok('older / damaged shows: Main added, ids cleaned and de-duplicated, channel and gain clamped, dangling routes fixed');
  // device report from the primary output → controllers
  const WS = globalThis.WebSocket; if (WS) {
    const ctl = new WS('ws://127.0.0.1:8921/ws?role=control'), out = new WS('ws://127.0.0.1:8921/ws?role=output'); const got = [];
    ctl.onmessage = e => { const m = JSON.parse(e.data); if (m.t === 'audiodev') got.push(m); };
    await new Promise(r => out.onopen = r); await new Promise(r => ctl.readyState === 1 ? r() : ctl.onopen = r); await tick(300);
    out.send(JSON.stringify({ t: 'audioDevices', devices: [{ id: 'default', label: 'Default output' }, { id: 'd1', label: 'Dante Virtual Soundcard', channels: 64 }], buses: [{ id: 'main', ok: true, channels: 2, device: 'Default output' }] }));
    await tick(300); assert.ok(got.length && got[0].devices[1].channels === 64, JSON.stringify(got));
    const api = await fetch(B + '/api/audio/devices').then(r => r.json()); assert.strictEqual(api.devices[1].label, 'Dante Virtual Soundcard'); ctl.close(); out.close();
    ok('the output window\'s device list and bus status reach every controller (and /api/audio/devices)');
  }
  console.log('Audio outputs test passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
