// LUTs: .cube 3D / 1D and .3dl parsing (domains, bit depth, blue-fastest order), trilinear lookup, GPU atlas layout,
// half floats, and the server (import, replace by name, serve, rename, delete, per-output display LUT defaults).
//   node tests/lut_test.js      (GPU side: tests/render_check.py)
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const L = require('../public/lut.js'), S = require('../public/schema.js');
const FIX = path.join(__dirname, 'fixtures', 'lut'), rd = f => fs.readFileSync(path.join(FIX, f), 'utf8');
const near = (a, b, e = 0.002) => a.every((x, i) => Math.abs(x - b[i]) < e);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));

(async () => {
  let lut = L.parse(rd('Swap RB.cube'), 'Swap RB.cube');
  assert.deepStrictEqual([lut.kind, lut.size, lut.title], ['3d', 17, 'Swap RB']); assert.ok(near(L.apply(lut, [1, 0.5, 0]), [0, 0.5, 1]));
  assert.ok(near(L.apply(lut, [0.3, 0.6, 0.9]), [0.9, 0.6, 0.3]), 'trilinear between grid points');
  lut = L.parse(rd('Invert 1D.cube')); assert.deepStrictEqual([lut.kind, lut.size], ['1d', 256]); assert.ok(near(L.apply(lut, [0, 0.25, 1]), [1, 0.75, 0]));
  lut = L.parse(rd('Half Green.3dl'), 'x.3dl'); assert.strictEqual(lut.size, 9); assert.ok(near(L.apply(lut, [1, 0, 1]), [0.5, 0.25, 0.5], 0.001) && near(L.apply(lut, [0, 1, 0]), [0, 0.75, 0], 0.001), '12-bit scale + blue-fastest order');
  ok('.cube 3D (17³) and 1D (256) and 12-bit .3dl with an input mesh row parse and look up correctly');
  // domain, comments, keywords, errors
  const dom = L.parseCube('TITLE "d"\n# c\nLUT_1D_SIZE 2\nDOMAIN_MIN 0 0 0\nDOMAIN_MAX 2 2 2\n0 0 0\n1 1 1\n'); assert.ok(near(L.apply(dom, [1, 1, 1]), [0.5, 0.5, 0.5]));
  const rng = L.parseCube('LUT_1D_SIZE 2\nLUT_1D_INPUT_RANGE 0 4\n0 0 0\n1 1 1\n'); assert.deepStrictEqual(rng.dmax, [4, 4, 4]);
  assert.throws(() => L.parseCube('LUT_3D_SIZE 2\n0 0 0\n'), /expected 8 entries/); assert.throws(() => L.parseCube('hello'), /bad data line/);
  assert.throws(() => L.parseCube('LUT_3D_SIZE 99\n'), /out of range/); assert.throws(() => L.parse3dl('0 0 0\n1 1 1\n'), /not a cube/);
  assert.throws(() => L.parseCube('LUT_1D_SIZE 2\nDOMAIN_MIN 1 1 1\nDOMAIN_MAX 0 0 0\n0 0 0\n1 1 1'), /DOMAIN/);
  assert.strictEqual(L.parse('LUT_3D_SIZE 2\n' + '0 0 0\n'.repeat(8), 'noext').kind, '3d', 'sniffed without an extension');
  ok('DOMAIN_MIN/MAX and LUT_1D_INPUT_RANGE honoured; wrong counts, sizes, domains and junk rejected with a reason');
  // atlas + half
  const id = L.identity(4), a = L.atlas(id); assert.deepStrictEqual([a.w, a.h], [16, 4]);
  const px = (x, y) => [...a.px.slice((y * a.w + x) * 4, (y * a.w + x) * 4 + 3)];
  assert.ok(near(px(2 * 4 + 1, 3), [1 / 3, 1, 2 / 3]), 'slice b=2, r=1, row g=3'); assert.strictEqual(L.atlas(L.parse(rd('Invert 1D.cube'))).w, 256);
  assert.strictEqual(L.toHalf(1), 0x3c00); assert.strictEqual(L.toHalf(0.5), 0x3800); assert.strictEqual(L.toHalf(0), 0); assert.strictEqual(L.toHalf(-2), 0xc000);
  const back = L.parseCube(L.toCube(L.parse(rd('Half Green.3dl'), 'a.3dl'))); assert.ok(near(L.apply(back, [1, 0, 1]), [0.5, 0.25, 0.5], 0.001), '.3dl → .cube round trip');
  ok('GPU atlas: blue slices side by side, green rows, red columns; half-float encoding; .cube writer round-trips');
  // schema
  assert.deepStrictEqual(S.outputDefaults().lut, { on: false, lut: '', mix: 1, exposure: 0, contrast: 1, saturation: 1, temp: 0, tint: 0, gain: 1 });
  assert.ok(S.newState().luts && S.fxDefaults().lut.mix === 1);

  // server
  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxlut-'));
  const start = () => { const k = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8901, OSC_PORT: 8902, DATA_DIR: DATA, MEDIA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxlutm-')) }, stdio: 'ignore' }); kids.push(k); return k; };
  let srv = start(); const B = 'http://127.0.0.1:8901'; const up = async () => { for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150); }; await up();
  const imp = (name, body) => fetch(B + '/api/luts?name=' + encodeURIComponent(name), { method: 'POST', body }).then(async r => ({ status: r.status, j: await r.json() }));
  const cmd = c => fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(c) }).then(r => r.json());
  const state = () => fetch(B + '/api/state').then(r => r.json());
  let r = await imp('Swap RB.cube', rd('Swap RB.cube')); assert.strictEqual(r.status, 200); const sw = r.j.lut; assert.deepStrictEqual([sw.kind, sw.size, sw.name, sw.ext], ['3d', 17, 'Swap RB', 'cube']);
  r = await imp('Half Green.3dl', rd('Half Green.3dl')); assert.strictEqual(r.j.lut.ext, '3dl');
  r = await imp('broken.cube', 'LUT_3D_SIZE 3\n0 0 0\n'); assert.strictEqual(r.status, 400); assert.ok(/broken.cube: expected 27/.test(r.j.error), r.j.error);
  r = await imp('photo.png', 'x'); assert.strictEqual(r.status, 400);
  let st = await state(); assert.strictEqual(st.luts.length, 2);
  const txt = await fetch(B + '/api/luts/' + sw.id).then(r => r.text()); assert.ok(near(L.apply(L.parse(txt, 'a.cube'), [1, 0, 0]), [0, 0, 1]));
  assert.strictEqual((await fetch(B + '/api/luts/nope')).status, 404); assert.strictEqual((await fetch(B + '/api/luts/..%2Fstate')).status, 404);
  ok('import .cube / .3dl over HTTP, bad files refused with the reason, tables served back by id (no path tricks)');
  // re-import same name → same id, new rev, new contents
  const inv = rd('Invert 1D.cube'); r = await imp('Swap RB.cube', inv); assert.strictEqual(r.j.lut.id, sw.id); assert.ok(r.j.lut.rev > sw.rev); assert.strictEqual(r.j.lut.kind, '1d');
  st = await state(); assert.strictEqual(st.luts.length, 2); assert.strictEqual((await fetch(B + '/api/luts/' + sw.id).then(r => r.text())), inv);
  await cmd({ op: 'lutRename', id: sw.id, name: 'Invert' }); await cmd({ op: 'set', path: 'outputs.0.lut.lut', value: sw.id }); await cmd({ op: 'set', path: 'outputs.0.lut.on', value: true });
  await cmd({ op: 'set', path: 'layers.0.fx.lut.lut', value: sw.id }); await cmd({ op: 'set', path: 'layers.0.fx.lut.exposure', value: -1 });
  st = await state(); assert.strictEqual(st.luts.find(l => l.id === sw.id).name, 'Invert'); assert.ok(st.outputs[0].lut.on && st.outputs[0].lut.gain === 1); assert.strictEqual(st.layers[0].fx.lut.exposure, -1);
  ok('re-importing a name replaces the table in place (same id, new revision); rename; output and effect LUT settings stored');
  // older show without output LUT settings → defaults; delete removes the file
  const show = await state(); delete show.outputs[0].lut; delete show.luts; fs.writeFileSync(path.join(DATA, 'state.json'), JSON.stringify(show)); srv.kill(); await tick(400);
  srv = start(); await up(); st = await state(); assert.deepStrictEqual(st.luts, []); assert.strictEqual(st.outputs[0].lut.mix, 1);
  r = await imp('Half Green.3dl', rd('Half Green.3dl')); const hg = r.j.lut; await cmd({ op: 'lutDelete', id: hg.id }); await tick(200);
  st = await state(); assert.ok(!st.luts.length); assert.ok(!fs.existsSync(path.join(DATA, 'luts', hg.id + '.3dl')));
  ok('older shows get output LUT defaults; delete removes the entry and its file');
  console.log('LUT test passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
