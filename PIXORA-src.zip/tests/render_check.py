# GPU checks in real Chrome: ISF (generators, filters, multi-pass + persistent feedback, ISF 1.0 buffers, imported image + custom
# vertex shader, audio input), LUTs (layer, comp, per-output display LUT) and dome / 360 output projections.
# Needs Python Playwright and Chrome:  python3 tests/render_check.py [path-to-chrome]
import json, urllib.request, urllib.parse, subprocess, os, time, sys, tempfile
from playwright.sync_api import sync_playwright
from PIL import Image
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); FIX = os.path.join(ROOT, 'tests', 'fixtures', 'isf')
CHROME = sys.argv[1] if len(sys.argv) > 1 else '/usr/bin/google-chrome'
B = 'http://127.0.0.1:8899'; tmp = tempfile.mkdtemp()
env = dict(os.environ, PORT='8899', OSC_PORT='8900', DATA_DIR=tmp + '/data', MEDIA_DIR=tmp + '/media')
srv = subprocess.Popen(['node', 'server.js'], cwd=ROOT, env=env, stdout=open(tmp + '/srv.log', 'w'), stderr=subprocess.STDOUT)
def req(path, body=None, method=None, raw=None):
  data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
  r = urllib.request.Request(B + path, data=data, method=method, headers={'Content-Type': 'application/octet-stream' if raw is not None else 'application/json'})
  return json.loads(urllib.request.urlopen(r).read() or b'{}')
for _ in range(60):
  try: req('/api/info'); break
  except Exception: time.sleep(0.2)
cmd = lambda c: req('/api/cmd', c)
rd = lambda f: open(os.path.join(FIX, f)).read()
def ok(m): print('✓ ' + m)
def near(a, b, tol=40): return all(abs(x - y) <= tol for x, y in zip(a, b))
try:
  logo = req('/api/upload?name=logo.png&folder=ISF', raw=open(os.path.join(FIX, 'logo.png'), 'rb').read(), method='PUT')['src']
  for i, (n, f, vs, files) in enumerate([('gen', 'Solid Pulse.fs', None, None), ('swap', 'Swap RB.fs', None, None), ('acc', 'Accumulate.fs', None, None),
      ('trail', 'Old Trails.fs', None, None), ('spec', 'Spectrum Bars.fs', None, None), ('wob', 'Logo Wobble.fs', 'Logo Wobble.vs', {'logo': logo})]):
    cmd({'op': 'shaderSave', 'shader': {'id': n, 'name': f[:-3], 'code': rd(f), 'vs': rd(vs) if vs else '', 'files': files or {}}})
  gen = lambda sid, vals=None: {'type': 'gen', 'name': sid, 'gen': {'kind': 'shader', 'params': {'shader': sid, 'p1': .5, 'p2': .5, 'p3': .5, 'p4': .5, 'isf': vals or {}}}}
  cmd({'op': 'set', 'path': 'comp.width', 'value': 640}); cmd({'op': 'set', 'path': 'comp.height', 'value': 360})
  cmd({'op': 'assign', 'layer': 0, 'slot': 0, 'clip': gen('gen')}); cmd({'op': 'trigger', 'layer': 0, 'clip': 0})
  with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=['--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--autoplay-policy=no-user-gesture-required'])
    pg = b.new_page(viewport={'width': 640, 'height': 360}); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(B + '/clean?out=main&fs=0'); time.sleep(1); pg.mouse.click(320, 180); time.sleep(1.5)
    def px(*pts):
      pg.screenshot(path=tmp + '/s.png'); im = Image.open(tmp + '/s.png').convert('RGB'); return [im.getpixel((int(x * 639), int(y * 359))) for x, y in pts]
    serr = lambda: pg.evaluate('() => engine.shaderErrors')
    c = px((0.25, 0.5), (0.75, 0.5)); assert near(c[0], (255, 0, 0)) and near(c[1], (255, 0, 0)), (c, serr()); ok('ISF generator renders with its defaults (red)')
    cmd({'op': 'isfVals', 'path': 'layers.0.clips.0.gen.params', 'key': 'isf', 'vals': {'side': 1, 'level': 1, 'tint': '#00ff00', 'invert': False, 'spot': [0, 0]}}); time.sleep(0.6)
    c = px((0.25, 0.5), (0.75, 0.5)); assert near(c[0], (0, 255, 0)) and near(c[1], (0, 0, 0)), c; ok('long + color inputs: left half green, right half black')
    cmd({'op': 'set', 'path': 'layers.0.clips.0.gen.params.isf.invert', 'value': True}); cmd({'op': 'isfVals', 'path': 'layers.0.clips.0.gen.params', 'key': 'isf', 'vals': {'spot': [0.75, 0.5]}}); time.sleep(0.6)
    c = px((0.25, 0.5), (0.75, 0.5), (0.6, 0.2)); assert near(c[0], (255, 0, 255)) and near(c[1], (255, 255, 255)) and near(c[2], (255, 255, 255)), c; ok('bool + point2D inputs: inverted colours and a white spot where the point is')
    # filter as a layer effect over a red solid
    cmd({'op': 'assign', 'layer': 0, 'slot': 1, 'clip': {'type': 'gen', 'name': 'Red', 'gen': {'kind': 'solid', 'params': {'c1': '#ff0000'}}}}); cmd({'op': 'trigger', 'layer': 0, 'clip': 1})
    cmd({'op': 'set', 'path': 'layers.0.fx.isf.shader', 'value': 'swap'}); cmd({'op': 'set', 'path': 'layers.0.fx.isf.on', 'value': True}); time.sleep(1.5)
    c = px((0.5, 0.5)); assert near(c[0], (0, 0, 255)), (c, serr()); ok('ISF filter on a layer effect slot: red → blue')
    cmd({'op': 'set', 'path': 'layers.0.fx.isf.mix', 'value': 0.5}); time.sleep(0.5)
    c = px((0.5, 0.5)); assert near(c[0], (128, 0, 128)), c; ok('effect Mix 50% blends with the input')
    cmd({'op': 'isfVals', 'path': 'layers.0.fx.isf', 'key': 'v', 'vals': {'amount': 0}}); cmd({'op': 'set', 'path': 'layers.0.fx.isf.mix', 'value': 1}); time.sleep(0.5)
    c = px((0.5, 0.5)); assert near(c[0], (255, 0, 0)), c; ok('filter input value (amount 0) passes the picture through')
    # second slot + comp-level
    cmd({'op': 'isfVals', 'path': 'layers.0.fx.isf', 'key': 'v', 'vals': {'amount': 1}}); cmd({'op': 'set', 'path': 'comp.fx.isf2.shader', 'value': 'swap'}); cmd({'op': 'set', 'path': 'comp.fx.isf2.on', 'value': True}); time.sleep(0.6)
    c = px((0.5, 0.5)); assert near(c[0], (255, 0, 0)), c; ok('layer ISF effect then comp ISF Effect 2: swapped twice → red again')
    cmd({'op': 'set', 'path': 'comp.fx.isf2.on', 'value': False}); cmd({'op': 'set', 'path': 'layers.0.fx.isf.on', 'value': False})
    # multi-pass + persistent
    cmd({'op': 'assign', 'layer': 0, 'slot': 2, 'clip': gen('acc')}); cmd({'op': 'trigger', 'layer': 0, 'clip': 2}); time.sleep(0.7)
    c1 = px((0.5, 0.5))[0]; time.sleep(1.5); c2 = px((0.5, 0.5))[0]
    assert c2[0] >= 250 and c1[0] < c2[0] and near((0, c2[1], c2[2]), (0, 128, int(320 / 1000 * 255)), 12), (c1, c2, serr()); ok(f'multi-pass: half-size pass ({c2[2]}/255 ≈ 320 px wide) and a persistent buffer that accumulates frame to frame ({c1[0]} → {c2[0]})')
    # ISF 1.0 trails filter
    cmd({'op': 'trigger', 'layer': 0, 'clip': 1}); cmd({'op': 'set', 'path': 'layers.0.fx.isf.shader', 'value': 'trail'}); cmd({'op': 'set', 'path': 'layers.0.fx.isf.on', 'value': True}); time.sleep(1.2)
    c = px((0.5, 0.5)); assert near(c[0], (255, 0, 0)), (c, serr()); ok('ISF 1.0 shader (PERSISTENT_BUFFERS, vv_FragNormCoord) runs as an effect')
    cmd({'op': 'set', 'path': 'layers.0.fx.isf.on', 'value': False})
    # imported image + custom vertex shader
    cmd({'op': 'assign', 'layer': 0, 'slot': 3, 'clip': gen('wob')}); cmd({'op': 'trigger', 'layer': 0, 'clip': 3}); time.sleep(1.5)
    c = px((0.5, 0.5)); assert near(c[0], (0, 0, 255)), (c, serr()); ok('IMPORTED image (uploaded with the shader) sampled through a varying from the .vs')
    # audioFFT + event compile and run
    cmd({'op': 'assign', 'layer': 0, 'slot': 4, 'clip': gen('spec')}); cmd({'op': 'trigger', 'layer': 0, 'clip': 4}); time.sleep(1)
    e = serr(); assert not e.get('spec'), e; pg.evaluate('() => { engine.fft = new Uint8Array(1024).fill(255); }'); time.sleep(0.5)
    c = px((0.5, 0.9)); assert c[0][0] > 200, c; ok('audioFFT input: a full spectrum fills the bars')
    cmd({'op': 'isfVals', 'path': 'layers.0.clips.4.gen.params', 'key': 'isf', 'vals': {'flash': 'beat'}}); time.sleep(0.3)
    # broken shader reports an error instead of breaking the frame
    cmd({'op': 'shaderSave', 'shader': {'id': 'gen', 'code': rd('Solid Pulse.fs').replace('gl_FragColor = vec4(c.rgb, 1.0);', 'gl_FragColor = nope;')}})
    cmd({'op': 'trigger', 'layer': 0, 'clip': 0}); time.sleep(1)
    e = serr(); assert 'nope' in (e.get('gen') or ''), e; assert not errs, errs; ok('a compile error is reported per shader and the output keeps running')
    # ---- LUTs
    LF = os.path.join(ROOT, 'tests', 'fixtures', 'lut'); lid = {}
    for f in ['Swap RB.cube', 'Invert 1D.cube', 'Half Green.3dl']: lid[f] = req('/api/luts?name=' + urllib.parse.quote(f), raw=open(os.path.join(LF, f), 'rb').read(), method='POST')['lut']['id']
    cmd({'op': 'trigger', 'layer': 0, 'clip': 1}); cmd({'op': 'set', 'path': 'layers.0.fx.lut.lut', 'value': lid['Swap RB.cube']}); cmd({'op': 'set', 'path': 'layers.0.fx.lut.on', 'value': True}); time.sleep(1.5)
    c = px((0.5, 0.5)); assert near(c[0], (0, 0, 255), 12), (c, serr()); ok('3D .cube LUT on a layer: red → blue')
    cmd({'op': 'set', 'path': 'layers.0.fx.lut.mix', 'value': 0.5}); time.sleep(0.5); c = px((0.5, 0.5)); assert near(c[0], (128, 0, 128), 12), c; ok('LUT intensity 50%')
    cmd({'op': 'set', 'path': 'layers.0.fx.lut.mix', 'value': 1}); cmd({'op': 'set', 'path': 'layers.0.fx.lut.exposure', 'value': -1}); time.sleep(0.5)
    c = px((0.5, 0.5)); assert near(c[0], (0, 0, 128), 12), c; ok('pre-LUT exposure −1 stop halves the input')
    cmd({'op': 'set', 'path': 'layers.0.fx.lut.exposure', 'value': 0}); cmd({'op': 'set', 'path': 'layers.0.fx.lut.saturation', 'value': 0}); time.sleep(0.5)
    c = px((0.5, 0.5)); assert near(c[0], (54, 54, 54), 14), c; ok('saturation 0 before the LUT gives Rec.709 grey')
    cmd({'op': 'set', 'path': 'layers.0.fx.lut.on', 'value': False}); cmd({'op': 'set', 'path': 'comp.fx.lut2.lut', 'value': lid['Invert 1D.cube']}); cmd({'op': 'set', 'path': 'comp.fx.lut2.on', 'value': True}); time.sleep(1.2)
    c = px((0.5, 0.5)); assert near(c[0], (0, 255, 255), 12), (c, serr()); ok('1D LUT in the composition LUT 2 slot: red → cyan')
    cmd({'op': 'set', 'path': 'comp.fx.lut2.on', 'value': False}); cmd({'op': 'set', 'path': 'outputs.0.lut.lut', 'value': lid['Half Green.3dl']}); cmd({'op': 'set', 'path': 'outputs.0.lut.on', 'value': True}); time.sleep(1.2)
    c = px((0.5, 0.5)); assert near(c[0], (128, 64, 0), 12), (c, serr()); ok('per-output display LUT (.3dl, 12-bit) applied at the output')
    cmd({'op': 'set', 'path': 'outputs.0.lut.gain', 'value': 2}); time.sleep(0.5); c = px((0.5, 0.5)); assert near(c[0], (255, 128, 0), 12), c; ok('output gain after the LUT')
    cmd({'op': 'set', 'path': 'outputs.0.lut.on', 'value': False})
    # ---- dome / 360: an ISF gradient (R = u, G = v) as the composition, read back through each projection
    cmd({'op': 'shaderSave', 'shader': {'id': 'grad', 'name': 'Gradient', 'code': '/*{}*/ void main(){ gl_FragColor = vec4(isf_FragNormCoord, 0.0, 1.0); }'}})
    cmd({'op': 'set', 'path': 'comp.height', 'value': 320}); cmd({'op': 'assign', 'layer': 0, 'slot': 5, 'clip': gen('grad')}); cmd({'op': 'trigger', 'layer': 0, 'clip': 5})
    for k in ['isf', 'lut']: cmd({'op': 'set', 'path': 'layers.0.fx.%s.on' % k, 'value': False})
    def view(mode, w, h, **kw):
      cmd({'op': 'set', 'path': 'outputs.0.width', 'value': w}); cmd({'op': 'set', 'path': 'outputs.0.height', 'value': h})
      d = {'mode': mode, 'input': 'equirect', 'fov': 180, 'yaw': 0, 'pitch': 0, 'roll': 0, 'pfov': 90, 'flatAz': 0, 'flatEl': 0, 'flatFov': 90}; d.update(kw)
      for k, v in d.items(): cmd({'op': 'set', 'path': 'outputs.0.dome.' + k, 'value': v})
      pg.set_viewport_size({'width': w, 'height': h}); time.sleep(0.8)
    def at(*pts):
      pg.screenshot(path=tmp + '/d.png'); im = Image.open(tmp + '/d.png').convert('RGB'); W, H = im.size; return [im.getpixel((min(W - 1, int(x * W)), min(H - 1, int((1 - y) * H)))) for x, y in pts]
    view('fisheye', 400, 400)
    zen, front, right, corner = at((0.5, 0.5), (0.5, 0.012), (0.988, 0.5), (0.02, 0.02))
    assert zen[1] > 245 and near(front[:2], (128, 128), 10) and near(right[:2], (191, 128), 10) and corner == (0, 0, 0), (zen, front, right, corner); ok('fisheye domemaster: zenith in the centre, front at the bottom, right at the right, black outside the circle')
    view('fisheye', 400, 400, pitch=30); f2 = at((0.5, 0.5))[0]; assert near(f2[1:2], (int(255 * (0.5 + 60 / 180)),), 10), f2; ok('dome tilt 30°: the centre now looks 60° up')
    view('equirect', 640, 320); e = at((0.25, 0.75), (0.8, 0.3)); assert near(e[0][:2], (64, 191), 8) and near(e[1][:2], (204, 77), 8), e; ok('equirect → equirect is the identity')
    view('perspective', 640, 360); p0 = at((0.5, 0.5))[0]; view('perspective', 640, 360, yaw=90); p1 = at((0.5, 0.5))[0]
    assert near(p0[:2], (128, 128), 8) and near(p1[:2], (191, 128), 8), (p0, p1); ok('perspective camera: looks forward, yaw 90° looks right')
    view('fisheye', 400, 400, input='flat', flatEl=0); fl = at((0.5, 0.03))[0]; view('fisheye', 400, 400, input='flat', flatEl=60); fl2 = at((0.5, 0.03), (0.5, 0.5))
    assert near(fl[:2], (128, 151), 8) and fl2[0] == (0, 0, 0) and fl2[1] == (0, 0, 0), (fl, fl2); ok('flat content placed on the dome at azimuth / elevation, black around it')
    cmd({'op': 'set', 'path': 'outputs.0.dome.mode', 'value': 'off'})
    b.close()
  print('Render check passed')
finally:
  srv.terminate()
