// Camera projector alignment (public/align.js) with a simulated camera: two keystoned, overlapping projectors on a
// screen seen in perspective. Dots are decoded from the coded frames, the camera→projector homographies fitted with
// RANSAC (with stray reflections), and the slices planned: corner pins, covered areas and edge blends.
//   node tests/align_test.js
const path = require('path'), assert = require('assert'); const A = require(path.join(__dirname, '..', 'public', 'align.js'));
const ok = m => console.log('✓ ' + m);
const near = (a, b, tol, what) => assert.ok(Math.abs(a - b) <= tol, `${what}: ${a} vs ${b}`);
// ground truth
const CW = 1280, CH = 720; // camera
const screenCam = [[180, 110], [1130, 80], [1180, 640], [140, 600]]; // the screen as the camera sees it (perspective)
const Hsc = A.fit([[0, 0], [1, 0], [1, 1], [0, 1]], screenCam); // screen uv → camera px
const PW = 1920, PH = 1080;
const projGT = [ // projector px → screen uv: left projector covers u ≈ -0.03..0.58, right ≈ 0.42..1.04 (16 % overlap), slight keystone
  { id: 'left', Hps: A.fit([[0, 0], [PW, 0], [PW, PH], [0, PH]], [[-0.03, -0.04], [0.58, -0.02], [0.57, 1.03], [-0.02, 1.05]]) },
  { id: 'right', Hps: A.fit([[0, 0], [PW, 0], [PW, PH], [0, PH]], [[0.42, -0.03], [1.04, -0.05], [1.05, 1.04], [0.43, 1.02]]) }];
function camera(P, frame, L) { // render what the camera sees: dots as soft blobs, plus ambient light and noise
  const img = new Float32Array(CW * CH); let seed = 7 + frame; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  for (let p = 0; p < img.length; p++) img[p] = 18 + rnd() * 6;
  const Hpc = A.mul3(Hsc, P.Hps);
  for (const i of A.dotsOn(L, frame)) { const [cx, cy] = A.apply(Hpc, L.pts[i]); const r = 2.6;
    for (let y = Math.floor(cy - 3 * r); y <= cy + 3 * r; y++) for (let x = Math.floor(cx - 3 * r); x <= cx + 3 * r; x++) { if (x < 0 || y < 0 || x >= CW || y >= CH) continue; img[y * CW + x] = Math.min(255, img[y * CW + x] + 220 * Math.exp(-((x - cx) ** 2 + (y - cy) ** 2) / (2 * r * r))); } }
  if (frame >= 1) for (let y = 40; y < 44; y++) for (let x = 40; x < 44; x++) img[y * CW + x] = 250; // a stray reflection that is lit in every frame (wrong code)
  return { w: CW, h: CH, data: img };
}
const L = A.layout(PW, PH); assert.strictEqual(L.pts.length, 96); assert.strictEqual(L.bits, 7); assert.strictEqual(L.frames, 9);
for (let i = 0; i < 96; i++) assert.ok(A.dotsOn(L, 1).includes(i) && [2, 3, 4, 5, 6, 7, 8].some(f => A.dotsOn(L, f).includes(i)), 'every dot lit in some bit frame');
ok('96 dots, 9 frames (black, all, 7 Gray-code bits); every dot has a non-zero code');
const projectors = [];
for (const P of projGT) {
  const frames = Array.from({ length: L.frames }, (_, f) => camera(P, f, L));
  const d = A.decode(frames, L); assert.ok(d.pairs.length >= 90, `${P.id}: decoded ${d.pairs.length}`);
  const R = A.ransac(d.pairs); assert.ok(R && R.error < 0.6, `${P.id}: reprojection ${R && R.error}`);
  // check against the truth: camera → projector
  const Htrue = A.inv3(A.mul3(Hsc, P.Hps)); for (const c of [[300, 200], [900, 500], [640, 360]]) { const a = A.apply(R.H, c), b = A.apply(Htrue, c); near(Math.hypot(a[0] - b[0], a[1] - b[1]), 0, 1.5, P.id + ' mapping px'); }
  ok(`${P.id}: ${d.pairs.length}/96 dots decoded (reflection rejected), ${R.inliers} inliers, reprojection ${R.error.toFixed(2)} px`);
  projectors.push({ id: P.id, W: PW, H: PH, camToProj: R.H });
}
const plan = A.plan(projectors, screenCam); const [Lp, Rp] = plan;
assert.ok(!Lp.empty && !Rp.empty);
near(Lp.slice.src.x, 0, 0.002, 'left starts at the screen edge'); near(Lp.slice.src.x + Lp.slice.src.w, 0.57, 0.01, 'left inner right edge');
near(Rp.slice.src.x, 0.43, 0.01, 'right inner left edge'); near(Rp.slice.src.x + Rp.slice.src.w, 1, 0.002, 'right ends at the screen edge');
ok(`covered areas: left u 0–${(Lp.slice.src.x + Lp.slice.src.w).toFixed(3)}, right u ${Rp.slice.src.x.toFixed(3)}–1`);
const ov = (Lp.slice.src.x + Lp.slice.src.w) - Rp.slice.src.x;
near(Lp.slice.soft.r, ov / Lp.slice.src.w, 0.002, 'left blend'); near(Rp.slice.soft.l, ov / Rp.slice.src.w, 0.002, 'right blend'); assert.strictEqual(Lp.slice.soft.l, 0); assert.strictEqual(Rp.slice.soft.r, 0);
ok(`edge blends: left fades its right ${(Lp.slice.soft.r * 100).toFixed(1)} %, right fades its left ${(Rp.slice.soft.l * 100).toFixed(1)} % (overlap ${(ov * 100).toFixed(1)} % of the screen)`);
// the corner pins put the screen-space rectangle exactly where the projector must draw it
for (const [P, pl] of [[projGT[0], Lp], [projGT[1], Rp]]) { const Hsp = A.inv3(P.Hps), s = pl.slice.src;
  [[s.x, s.y], [s.x + s.w, s.y], [s.x + s.w, s.y + s.h], [s.x, s.y + s.h]].forEach((uv, k) => { const want = A.apply(Hsp, uv); near(pl.slice.dst[k][0] * PW, want[0], 2, P.id + ' dst x'); near(pl.slice.dst[k][1] * PH, want[1], 2, P.id + ' dst y'); }); }
ok('corner pins within 2 px of the true positions on both projectors');
assert.throws(() => A.plan(projectors, [[0, 0], [1, 0], [2, 0], [3, 0]]), /usable shape/); ok('bad screen corners refused');
const dark = A.decode(Array.from({ length: L.frames }, () => ({ w: 10, h: 10, data: new Float32Array(100).fill(20) })), L); assert.ok(/no dots seen/.test(dark.error)); ok('no projection seen → clear message');

// ---- blend tuning against a simulated pair of projectors (unequal brightness, display gamma 2.5, native black) ----
{
  const IW = 400, IH = 100, screen = [[0, 0], [IW - 1, 0], [IW - 1, IH - 1], [0, IH - 1]];
  const P = [{ id: 'L', x0: 0, x1: 0.56, gain: 1.0 }, { id: 'R', x0: 0.44, x1: 1, gain: 0.82 }];
  const slices = { L: { gamma: 2.2, black: 0, cal: { brightness: 1 }, soft: { l: 0, r: 0.12 / 0.56 } }, R: { gamma: 2.2, black: 0, cal: { brightness: 1 }, soft: { l: 0.12 / 0.56, r: 0 } } };
  const light = (u, white) => { let sum = 0; for (const p of P) { if (u < p.x0 || u > p.x1) continue; const sl = slices[p.id], w = p.x1 - p.x0, uv = (u - p.x0) / w;
      let f = 1; if (sl.soft.l) f *= Math.min(1, uv / sl.soft.l); if (sl.soft.r) f *= Math.min(1, (1 - uv) / sl.soft.r);
      let c = (white ? 1 : 0) * sl.cal.brightness; const lift = f >= 0.999 ? sl.black : 0; c = c + lift * (1 - c); const out = Math.min(1, c) * Math.pow(f, 1 / sl.gamma);
      sum += p.gain * Math.pow(out, 2.5) + 0.012; } return sum; };
  const shot = white => { const d = new Float32Array(IW * IH); for (let x = 0; x < IW; x++) { const v = Math.min(255, 200 * light(x / (IW - 1), white) + 2); for (let y = 0; y < IH; y++) d[y * IW + x] = v; } return { w: IW, h: IH, data: d }; };
  const plan = [{ id: 'L', rect: { x0: 0, x1: 0.56 } }, { id: 'R', rect: { x0: 0.44, x1: 1 } }];
  const regs = A.regions(plan); assert.deepStrictEqual(regs.map(r => r.kind), ['single', 'overlap', 'single']);
  const before = A.measure(shot(true), screen, regs); const ratio0 = before[1].lum / ((before[0].lum + before[2].lum) / 2);
  let r, rounds = 0; do { r = A.tune(slices, A.measure(shot(true), screen, regs), A.measure(shot(false), screen, regs)); rounds++; if (process.env.DBG) console.log(rounds, r.notes.join(' ; ')); } while (!r.done && rounds < 8);
  const W2 = A.measure(shot(true), screen, regs), K2 = A.measure(shot(false), screen, regs);
  assert.ok(r.done, 'converged'); near(W2[0].lum / W2[2].lum, 1, 0.04, 'projectors matched'); near(W2[1].lum / ((W2[0].lum + W2[2].lum) / 2), 1, 0.07, 'overlap = rest');
  assert.ok(K2[1].lum - (K2[0].lum + K2[2].lum) / 2 <= 1.6, 'black band gone');
  ok(`blend tuning in ${rounds} rounds: brightness matched (R ${Math.round(slices.L.cal.brightness * 100)}/${Math.round(slices.R.cal.brightness * 100)} %), overlap ${Math.round(ratio0 * 100)} % → ${Math.round(W2[1].lum / ((W2[0].lum + W2[2].lum) / 2) * 100)} % (gamma ${slices.L.gamma}), black level ${slices.L.black}`);
}
