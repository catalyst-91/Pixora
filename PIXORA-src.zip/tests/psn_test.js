// PosiStageNet: packet build / parse (data + info, positions, names), the receiver, trackers reaching outputs and control.
//   node tests/psn_test.js
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), dgram = require('dgram'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
const P = require('../server-psn.js');
(async () => {
  const [data, info] = P.build([{ id: 1, name: 'Singer', pos: [1.5, 0, -2.25] }, { id: 7, name: 'Truss L', pos: [-3, 6.5, 0] }]); const into = {};
  assert.strictEqual(P.parse(data, into), 'data'); assert.strictEqual(P.parse(info, into), 'info');
  assert.deepStrictEqual(into[1].pos, [1.5, 0, -2.25]); assert.deepStrictEqual(into[7].pos, [-3, 6.5, 0]); assert.strictEqual(into[1].name, 'Singer'); assert.strictEqual(into[7].name, 'Truss L');
  assert.strictEqual(P.parse(Buffer.from([1, 2, 3]), {}), null); const cut = data.subarray(0, data.length - 5); assert.doesNotThrow(() => P.parse(cut, {}));
  ok('PSN 2 data + info packets: tracker positions and names; truncated / junk packets are ignored safely');
  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxp-'));
  kids.push(spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 9061, OSC_PORT: 9062, DATA_DIR: DATA, MEDIA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxpm-')) }, stdio: 'ignore' }));
  const B = 'http://127.0.0.1:9061'; for (let i = 0; i < 80 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const cmd = x => fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(x) }).then(r => r.json());
  await cmd({ op: 'set', path: 'psn.port', value: 56999 }); await cmd({ op: 'set', path: 'psn.group', value: '127.0.0.1' }); await cmd({ op: 'set', path: 'psn.on', value: true }); await tick(600);
  const ws = new WebSocket(B.replace('http', 'ws') + '/ws?role=output'); const got = []; ws.onmessage = e => { if (typeof e.data === 'string') { const m = JSON.parse(e.data); if (m.t === 'psn') got.push(m); } }; await new Promise(r => ws.onopen = r);
  const u = dgram.createSocket('udp4'); for (let i = 0; i < 20; i++) { const [d, inf] = P.build([{ id: 1, name: 'Singer', pos: [i / 10, 0, 1] }], i); await new Promise(r => u.send(d, 56999, '127.0.0.1', r)); if (i % 5 === 0) await new Promise(r => u.send(inf, 56999, '127.0.0.1', r)); await tick(15); }
  await tick(1200); const st = await fetch(B + '/api/psn').then(r => r.json());
  assert.ok(st.on && st.packets >= 20 && st.trackers.length === 1 && Math.abs(st.trackers[0].pos[0] - 1.9) < 1e-5 && st.trackers[0].name === 'Singer', JSON.stringify(st));
  assert.ok(got.length >= 3 && got.length <= 25 && Math.abs(got[got.length - 1].trackers[0].pos[0] - 1.9) < 1e-5, got.length);
  ok(`receiver: ${st.packets} packets, tracker “Singer” at x ${st.trackers[0].pos[0].toFixed(2)} m; outputs got ${got.length} updates (≤ 30/s)`);
  await cmd({ op: 'set', path: 'psn.on', value: false }); await tick(500); assert.strictEqual((await fetch(B + '/api/psn').then(r => r.json())).on, false); ok('switching it off closes the socket');
  ws.close(); u.close(); console.log('PosiStageNet test passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
