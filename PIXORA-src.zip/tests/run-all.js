// Runs PIXORA's automatic tests one after another and stops the build if any fail.
//   node tests/run-all.js            all tests that need no special hardware or runtimes
//   node tests/run-all.js stream ma3 only tests whose names contain these words
// Tests that need extra things skip themselves when they're missing: link_test (a built Carabiner),
// qforge_e2e_test (a QForge checkout in QFORGE_DIR). Not run here: desktop_harness / ndi_live_test (NDI runtime),
// desktop_decklink_test (DeckLink module + fake driver), companion_harness (a running server).
'use strict';
const { spawnSync } = require('child_process'), path = require('path'), fs = require('fs');
const NEEDS_EXTRA = ['desktop_harness.js', 'ndi_live_test.js', 'desktop_decklink_test.js', 'companion_harness.js'];
const want = process.argv.slice(2);
const tests = fs.readdirSync(__dirname).filter(f => /_test\.js$/.test(f) && !NEEDS_EXTRA.includes(f) && (!want.length || want.some(w => f.includes(w)))).sort();
const results = [];
for (const t of tests) {
  const t0 = Date.now(), run = () => spawnSync(process.execPath, [path.join(__dirname, t)], { cwd: path.join(__dirname, '..'), encoding: 'utf8', timeout: 180000, env: process.env });
  let r = run(), retried = false, first = '';
  if (r.status !== 0) { first = (r.stdout || '') + (r.stderr || ''); retried = true; spawnSync(process.execPath, ['-e', 'setTimeout(()=>{},2000)']); r = run(); } // one retry for timing flakes on busy CI machines
  const secs = ((Date.now() - t0) / 1000).toFixed(1), out = (r.stdout || '') + (r.stderr || ''), pass = r.status === 0;
  const skipped = pass && /skipp/i.test(out.split('\n').filter(Boolean).pop() || '');
  results.push({ t, pass, skipped, secs, retried });
  console.log(`${pass ? (skipped ? '–' : '✓') : '✗'} ${t.padEnd(28)} ${secs.padStart(5)}s${skipped ? '  (skipped)' : ''}${pass && retried ? '  (passed on retry — first run below)' : ''}`);
  if (retried) console.log(first.split('\n').slice(-12).map(l => '    ' + l).join('\n'));
  if (!pass) console.log(out.split('\n').slice(-30).map(l => '    ' + l).join('\n') + (r.error ? '\n    ' + r.error.message : ''));
}
const failed = results.filter(r => !r.pass);
console.log(`\n${results.length - failed.length}/${results.length} passed${results.some(r => r.skipped) ? ` (${results.filter(r => r.skipped).length} skipped)` : ''}${results.some(r => r.pass && r.retried) ? `, ${results.filter(r => r.pass && r.retried).length} on retry` : ''}`);
process.exit(failed.length ? 1 : 0);
