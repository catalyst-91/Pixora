# ISF transitions as layer transitions in real Chrome: the switcher T-bar holds the change part-way so the shader's split can be
# measured, a bool input flips it, a clip can carry its own ISF transition, and a missing shader falls back to a crossfade.
#   python3 tests/transition_check.py [path-to-chrome]
import json, urllib.request, subprocess, os, time, sys, tempfile, signal
from playwright.sync_api import sync_playwright
from PIL import Image
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); FIX = os.path.join(ROOT, 'tests', 'fixtures', 'isf')
CHROME = sys.argv[1] if len(sys.argv) > 1 else '/usr/bin/google-chrome'; B = 'http://127.0.0.1:8933'; tmp = tempfile.mkdtemp()
srv = subprocess.Popen(['node', 'server.js'], cwd=ROOT, env=dict(os.environ, PORT='8933', OSC_PORT='8934', DATA_DIR=tmp + '/d', MEDIA_DIR=tmp + '/m'), stdout=open(tmp + '/log', 'w'), stderr=subprocess.STDOUT)
def req(path, body=None):
  r = urllib.request.Request(B + path, data=json.dumps(body).encode() if body is not None else None, headers={'Content-Type': 'application/json'}); return json.loads(urllib.request.urlopen(r).read() or b'{}')
for _ in range(60):
  try: req('/api/info'); break
  except Exception: time.sleep(0.2)
cmd = lambda c: req('/api/cmd', c); rd = lambda f: open(os.path.join(FIX, f)).read(); ok = lambda m: print('✓ ' + m)
near = lambda a, b, tol=40: all(abs(x - y) <= tol for x, y in zip(a, b))
try:
  cmd({'op': 'shaderSave', 'shader': {'id': 'flat', 'name': 'Flat', 'code': rd('Flat.fs')}}); cmd({'op': 'shaderSave', 'shader': {'id': 'hw', 'name': 'Hard Wipe', 'code': rd('Hard Wipe.fs')}})
  st = req('/api/state'); kinds = {s['id']: (s.get('isf') or {}).get('kind') for s in st['shaders']}; assert kinds['hw'] == 'transition' and kinds['flat'] == 'generator', kinds; ok('an ISF file with startImage / endImage / progress is recognised as a transition')
  flat = lambda col: {'type': 'gen', 'name': col, 'gen': {'kind': 'shader', 'params': {'shader': 'flat', 'isf': {'col': col}}}}
  for k, v in [('comp.width', 640), ('comp.height', 360), ('layers.0.transition', 'isf:hw'), ('layers.0.transitionDur', 3)]: cmd({'op': 'set', 'path': k, 'value': v})
  cmd({'op': 'assign', 'layer': 0, 'slot': 0, 'clip': flat('#ff0000')}); cmd({'op': 'assign', 'layer': 0, 'slot': 1, 'clip': flat('#0000ff')}); cmd({'op': 'trigger', 'layer': 0, 'clip': 0})
  with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=['--use-gl=swiftshader', '--enable-unsafe-swiftshader'])
    pg = b.new_page(viewport={'width': 640, 'height': 360}); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(B + '/clean?out=main&fs=0'); time.sleep(2)
    def px(*xs):
      pg.screenshot(path=tmp + '/s.png'); im = Image.open(tmp + '/s.png').convert('RGB'); return [im.getpixel((int(x * 639), 180)) for x in xs]
    c = px(0.5); assert near(c[0], (255, 0, 0)), c
    cmd({'op': 'switcher', 'a': 'set', 'on': True, 'layer': 0}); cmd({'op': 'switcher', 'a': 'preview', 'clip': 1}); cmd({'op': 'switcher', 'a': 'tbar', 'value': 0.3}); time.sleep(1.2)
    c = px(0.2, 0.4); assert near(c[0], (0, 0, 255)) and near(c[1], (255, 0, 0)), (c, pg.evaluate('() => engine.shaderErrors')); ok(f'T-bar at 30 %: the shader shows blue left of 0.3, red right of it {c}')
    cmd({'op': 'switcher', 'a': 'tbar', 'value': 0.7}); time.sleep(0.8); c = px(0.6, 0.8); assert near(c[0], (0, 0, 255)) and near(c[1], (255, 0, 0)), c; ok('T-bar at 70 %: the split follows')
    cmd({'op': 'isfVals', 'path': 'layers.0', 'key': 'transitionIsf', 'vals': {'flip': True}}); time.sleep(0.8)
    c = px(0.2, 0.4); assert near(c[0], (255, 0, 0)) and near(c[1], (0, 0, 255)), c; ok('a bool input of the transition (flip) wipes from the right instead')
    cmd({'op': 'switcher', 'a': 'preview', 'clip': None}); cmd({'op': 'switcher', 'a': 'set', 'on': False}); time.sleep(0.5)
    cmd({'op': 'set', 'path': 'layers.0.transitionIsf.flip', 'value': False})
    cmd({'op': 'trigger', 'layer': 0, 'clip': 1}); time.sleep(1.4); c = px(0.1, 0.9); assert near(c[0], (0, 0, 255)) and near(c[1], (255, 0, 0)), (c, pg.evaluate('() => { const r = engine.layers[0]; const gl = engine.gl, rp = f => { gl.bindFramebuffer(gl.FRAMEBUFFER, f.f); const a = new Uint8Array(4); gl.readPixels(10, 10, 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, a); return Array.from(a) }; return [r.transMode, r.transDur, performance.now() - r.transStart, !!r.prev, r.prev && r.prev.clip && r.prev.clip.gen.params.isf, r.prev && r.prev.ready, rp(engine.fT1), rp(engine.fT2)] }'), req('/api/state')['layers'][0]['active']); ok(f'triggered clip: a timed 3 s ISF wipe, part-way after 1.4 s {c}')
    time.sleep(2.2); c = px(0.9); assert near(c[0], (0, 0, 255)), c; ok('…and fully on the new clip at the end')
    cmd({'op': 'set', 'path': 'layers.0.clips.0.transition', 'value': 'isf:hw'}); cmd({'op': 'isfVals', 'path': 'layers.0.clips.0', 'key': 'transitionIsf', 'vals': {'flip': True}}); cmd({'op': 'set', 'path': 'layers.0.clips.0.transitionDur', 'value': 3}); cmd({'op': 'set', 'path': 'layers.0.transition', 'value': 'cut'})
    cmd({'op': 'trigger', 'layer': 0, 'clip': 0}); time.sleep(1.4); c = px(0.1, 0.9); assert near(c[0], (0, 0, 255)) and near(c[1], (255, 0, 0)), (c, pg.evaluate('() => { const r = engine.layers[0]; return [r.transMode, r.transDur, r.transVals] }'), req('/api/state')['layers'][0]['clips'][0].get('transition')); ok('a clip with its own ISF transition and values (flipped) overrides the layer’s cut')
    time.sleep(2.2)
    cmd({'op': 'set', 'path': 'layers.0.transition', 'value': 'isf:gone'}); cmd({'op': 'set', 'path': 'layers.0.transitionDur', 'value': 2}); cmd({'op': 'trigger', 'layer': 0, 'clip': 1}); time.sleep(1)
    c = px(0.1, 0.9); assert abs(c[0][0] - c[1][0]) < 30 and c[0][0] > 60 and c[0][2] > 60, c; ok(f'a deleted transition shader falls back to a crossfade {c[0]}')
    assert not errs, errs; b.close()
  print('Transition check passed')
finally: srv.send_signal(signal.SIGTERM)
