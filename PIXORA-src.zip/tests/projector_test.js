// Projector tools: mesh warp grids, black-level, masks and test patterns are kept, validated and edited through ops.
//   node tests/projector_test.js
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const S = require(path.join(ROOT, 'public/schema.js'));
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
(async () => {
  // mesh starts exactly on the corner pin (bilinear), row-major, (cols+1)×(rows+1)
  const dst = [[0.1, 0], [0.9, 0.1], [1, 1], [0, 0.9]], m = S.meshFromCorners(dst, 4, 3);
  assert.strictEqual(m.length, 20); assert.deepStrictEqual(m[0], dst[0]); assert.deepStrictEqual(m[4], dst[1]); assert.deepStrictEqual(m[19], dst[2]); assert.deepStrictEqual(m[15], dst[3]);
  assert.deepStrictEqual(m[2], [0.5, 0.05]); ok('mesh grid starts on the slice corner pin');

  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxproj-'));
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8871, OSC_PORT: 8872, DATA_DIR: DATA, MEDIA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxprojm-')) }, stdio: 'ignore' }); kids.push(srv);
  const B = 'http://127.0.0.1:8871';
  for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const cmd = c => fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(c) }).then(async r => { if (!r.ok) throw new Error(await r.text()); return r; });
  const st = () => fetch(B + '/api/state').then(r => r.json());

  await cmd({ op: 'sliceTemplate', output: 'main', n: 2, dir: 'h' }); await tick(100);
  let s = await st(); const o = s.outputs[0]; const sl = o.slices[0];
  assert.deepStrictEqual(o.masks, []); assert.strictEqual(o.test, 'off'); assert.strictEqual(sl.black, 0);
  assert.strictEqual(sl.mesh.on, false); assert.strictEqual(sl.mesh.pts.length, 16); ok('outputs and slices get masks, test pattern, black level and a 3×3 mesh by default');

  await cmd({ op: 'meshReset', output: 'main', slice: sl.id, cols: 8, rows: 6, on: true }); await tick(100);
  s = await st(); let me = s.outputs[0].slices[0].mesh;
  assert.strictEqual(me.on, true); assert.strictEqual(me.pts.length, 63); assert.deepStrictEqual(me.pts[0], [0, 0]); assert.deepStrictEqual(me.pts[62], [0.5, 1]); ok('meshReset resizes to 8×6 on the slice corners');

  await cmd({ op: 'set', path: 'outputs.0.slices.0.mesh.pts.10', value: [0.2, 0.3] }); await tick(100);
  s = await st(); assert.deepStrictEqual(s.outputs[0].slices[0].mesh.pts[10], [0.2, 0.3]); ok('dragging one mesh point updates only that point');

  await cmd({ op: 'maskAdd', output: 'main' }); await cmd({ op: 'maskAdd', output: 'main', pts: [[0, 0], [0.2, 0], [0.1, 0.3]] }); await tick(100);
  s = await st(); assert.strictEqual(s.outputs[0].masks.length, 2); assert.strictEqual(s.outputs[0].masks[1].pts.length, 3); assert.ok(s.outputs[0].masks.every(m => m.on && m.id && m.name));
  await cmd({ op: 'maskRemove', output: 'main', id: s.outputs[0].masks[0].id }); await tick(100);
  s = await st(); assert.strictEqual(s.outputs[0].masks.length, 1); assert.strictEqual(s.outputs[0].masks[0].name, 'Mask 2'); ok('masks add (default square or given polygon) and remove');

  await cmd({ op: 'set', path: 'outputs.0.test', value: 'grid' }); await tick(100); s = await st(); assert.strictEqual(s.outputs[0].test, 'grid'); ok('test pattern set');

  // a saved show with junk values is repaired on load
  const show = JSON.parse(JSON.stringify(s)); show.outputs[0].test = 'bogus'; show.outputs[0].slices[0].black = 5; show.outputs[0].slices[0].mesh = { on: true, cols: 99, rows: 2, pts: [[0, 0]] }; delete show.outputs[0].masks;
  fs.mkdirSync(path.join(DATA, 'compositions'), { recursive: true }); fs.writeFileSync(path.join(DATA, 'compositions', 'junk.json'), JSON.stringify(show));
  await cmd({ op: 'loadComp', name: 'junk' }); await tick(150);
  s = await st(); const r = s.outputs[0];
  assert.strictEqual(r.test, 'off'); assert.deepStrictEqual(r.masks, []); assert.strictEqual(r.slices[0].black, 0.35);
  assert.strictEqual(r.slices[0].mesh.cols, 16); assert.strictEqual(r.slices[0].mesh.pts.length, 17 * 3); ok('bad saved values are clamped and a mismatched mesh is rebuilt');

  // renderer has the warp/mask/test code paths wired
  const R = fs.readFileSync(path.join(ROOT, 'public/renderer.js'), 'utf8');
  for (const k of ['meshVerts(', 'maskCanvas(', 'testCanvas(', 'u_black', 'FS_MESH']) assert.ok(R.includes(k), k);
  ok('renderer: mesh, mask, test-pattern and black-level paths present');
  process.exit(0);
})().catch(e => { console.error('✗', e.message); process.exit(1); });
