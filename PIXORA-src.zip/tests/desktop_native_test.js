// Desktop app (native layer) test: runs desktop/main.js + native.js against a mocked Electron, with the REAL PIXORA
// server forked as the app would. Checks menus, splash, show save/open dialogs, add-media-folder, file association,
// in-app windows vs external links, free-port selection, the app's internal auth token, and output windows.
const Module = require('module'), path = require('path'), fs = require('fs'), os = require('os'), net = require('net'), assert = require('assert'), EventEmitter = require('events');
const realCP = require('child_process');
const DESK = path.join(__dirname, '..', 'desktop'), tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'pxnat-'));
const tick = ms => new Promise(r => setTimeout(r, ms));
const wins = [], opened = [], dialogs = { open: [], save: [], msg: [] }; let appMenu = null, notes = [];
class WC extends EventEmitter { constructor() { super(); this.js = []; } setWindowOpenHandler(f) { this.openHandler = f; } executeJavaScript(j) { this.js.push(j); return Promise.resolve(); } beginFrameSubscription() {} endFrameSubscription() {} setFrameRate() {} send() {} isDestroyed() { return false; } isFocused() { return false; } toggleDevTools() {} reload() {} }
class BW extends EventEmitter { constructor(o) { super(); this.opts = o; this.webContents = new WC(); this.destroyed = false; this.bounds = { x: 0, y: 0, width: o.width, height: o.height }; wins.push(this); }
  loadURL(u) { this.url = u; setTimeout(() => this.emit('ready-to-show'), 5); } show() { this.shown = true; } focus() {} setMenuBarVisibility() {} isDestroyed() { return this.destroyed; } close() { if (this.destroyed) return; this.emit('close'); this.destroyed = true; this.emit('closed'); }
  setBounds(b) { this.bounds = b; } getBounds() { return this.bounds; } isMaximized() { return false; } maximize() {} isFullScreen() { return false; } reload() {} }
const appOn = {};
const electron = {
  app: { getVersion: () => '1.2.0', isPackaged: false, addRecentDocument() {}, clearRecentDocuments() {}, commandLine: { appendSwitch() {} }, requestSingleInstanceLock: () => true, quit() {}, getPath: k => path.join(tmp, k), whenReady: () => Promise.resolve(), on: (e, f) => appOn[e] = f, setLoginItemSettings() {} },
  BrowserWindow: BW, Tray: class { setToolTip() {} on() {} setContextMenu(m) { this.menu = m; } }, nativeImage: { createFromPath: () => ({ resize: () => ({}) }) },
  Menu: { buildFromTemplate: t => t, setApplicationMenu: m => appMenu = m }, Notification: class { constructor(o) { this.o = o; } show() { notes.push(this.o); } static isSupported() { return true; } },
  screen: { getAllDisplays: () => [{ id: 1, bounds: { x: 0, y: 0, width: 1920, height: 1080 } }, { id: 2, bounds: { x: 1920, y: 0, width: 1280, height: 720 } }], getPrimaryDisplay: () => ({ id: 1 }), on() {} },
  powerSaveBlocker: { start: () => 1, stop() {} }, shell: { openPath: p => opened.push('path:' + p), openExternal: u => opened.push('ext:' + u) },
  dialog: { showOpenDialog: async o => ({ canceled: false, filePaths: [dialogs.open.shift()] }), showSaveDialog: async o => ({ canceled: false, filePath: dialogs.save.shift() }), showMessageBox: async o => { dialogs.msg.push(o.message); return { response: 0 }; }, showErrorBox: (a, b) => { throw new Error('error box: ' + b); } },
  ipcMain: { on() {}, handle() {} },
};
let serverChild = null;
const real = Module._load;
Module._load = function (r) {
  if (r === 'electron') return electron;
  if (r === 'child_process') return { ...realCP, fork: (s, a, o) => (serverChild = realCP.fork(s, a, { ...o, stdio: 'ignore' })) };
  return real.apply(this, arguments);
};
const item = (menu, ...labels) => { let m = menu; for (const l of labels) { m = (Array.isArray(m) ? m : m.submenu).find(x => x.label === l || (x.label || '').startsWith(l)); if (!m) throw new Error('menu item missing: ' + labels.join(' ▸ ')); } return m; };
(async () => {
  // free port on purpose: occupy one and check the app's picker skips it
  const blocker = net.createServer(); await new Promise(r => blocker.listen(0, '0.0.0.0', r)); const bp = blocker.address().port;
  const port = await new Promise(r => { const s = net.createServer(); s.listen(0, () => { const p = s.address().port; s.close(() => r(p)); }); });
  process.env.PORT = String(port); process.env.DATA_DIR = path.join(tmp, 'data'); process.env.MEDIA_DIR = path.join(tmp, 'media'); process.env.OSC_PORT = '7031';
  require(path.join(DESK, 'main.js'));
  for (let i = 0; i < 60 && !wins.find(w => w.url === `http://localhost:${port}/`); i++) await tick(200);
  const ctl = wins.find(w => w.url === `http://localhost:${port}/`); assert.ok(ctl, 'controller window'); await tick(100);
  const splash = wins.find(w => /^data:text\/html/.test(w.url || '') && w.opts.frame === false); assert.ok(splash && splash.destroyed, 'splash shown then closed'); assert.ok(ctl.shown);
  console.log('✓ splash → real server started → controller window shown');
  const tops = appMenu.map(m => m.label || m.role); for (const t of ['File', 'Edit', 'View', 'Show', 'Outputs', 'Window', 'Help']) assert.ok(tops.includes(t), t);
  console.log('✓ application menu:', tops.join(' · '));
  // port picker (a second native instance re-registers app handlers, so keep the app's own)
  const appHandlers = { ...appOn };
  const pick = require(path.join(DESK, 'native.js'))({ getBase: () => '', cfg: {}, saveCfg() {}, outWins: new Map(), controllerRef: () => null, fetchOutputs: async () => [] }).freePort;
  Object.assign(appOn, appHandlers); const got = await pick(bp); assert.notStrictEqual(got, bp); console.log(`✓ free-port picker skipped busy port ${bp} → ${got}`); blocker.close();
  // users exist → menu commands still work through the app token
  const B = `http://127.0.0.1:${port}`; let r = await fetch(B + '/api/users', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ user: 'admin', pass: 'secret12', role: 'admin' }) }); assert.strictEqual(r.status, 200);
  assert.strictEqual((await fetch(B + '/api/state')).status, 401, 'sign-in required for others');
  // Save Show As
  const showFile = path.join(tmp, 'My Show.pixora'); dialogs.save.push(showFile);
  await item(appMenu, 'File', 'Save Show As').click(); await tick(400);
  const doc = JSON.parse(fs.readFileSync(showFile, 'utf8')); assert.match(doc.format, /-show$/); console.log(`✓ File ▸ Save Show As → ${path.basename(showFile)} (${fs.statSync(showFile).size} B, format ${doc.format})`);
  // Open Show (edited name) + recent list
  doc.state.comp.name = 'Opened From Disk'; fs.writeFileSync(showFile, JSON.stringify(doc)); dialogs.open.push(showFile);
  await item(appMenu, 'File', 'Open Show').click(); await tick(500);
  const tok = { headers: {} }; const nat = require(path.join(DESK, 'native.js')); // fetch state via token-less admin login instead:
  const login = await fetch(B + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ user: 'admin', pass: 'secret12' }) }); const ck = login.headers.get('set-cookie').split(';')[0];
  const state = async () => (await fetch(B + '/api/state', { headers: { Cookie: ck } })).json();
  let s = await state(); assert.strictEqual(s.comp.name, 'Opened From Disk'); assert.ok(item(appMenu, 'File', 'Open Recent').submenu.some(x => x.label === 'My Show.pixora'));
  console.log('✓ File ▸ Open Show → show loaded into the engine; Open Recent updated; notification:', JSON.stringify(notes.slice(-1)[0].title));
  // .pixora file association (macOS open-file)
  doc.state.comp.name = 'Double-clicked'; const f2 = path.join(tmp, 'Second.pixora'); fs.writeFileSync(f2, JSON.stringify(doc));
  appOn['open-file']({ preventDefault() {} }, f2); await tick(700); s = await state(); assert.strictEqual(s.comp.name, 'Double-clicked'); console.log('✓ double-clicking a .pixora file opens it');
  // Add media folder
  const mf = path.join(tmp, 'USB Drive'); fs.mkdirSync(mf); dialogs.open.push(mf);
  await item(appMenu, 'File', 'Add Media Folder').click(); await tick(400);
  const lib = await (await fetch(B + '/api/library', { headers: { Cookie: ck } })).json(); assert.ok(lib.sources.some(x => x.name === 'USB Drive')); console.log('✓ File ▸ Add Media Folder or Drive → "USB Drive" added to the library');
  // Show menu → lock (via token, while sign-in is required)
  await item(appMenu, 'Show', 'Lock Show').click(); await tick(300); s = await state(); assert.strictEqual(s.show.lock, true);
  r = await fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-app-token': 'wrong' }, body: JSON.stringify({ op: 'unlockShow' }) }); assert.strictEqual(r.status, 401, 'bad token refused');
  await fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: ck }, body: JSON.stringify({ op: 'unlockShow' }) });
  console.log('✓ Show ▸ Lock Show works through the app token with sign-in on; a wrong token is refused');
  // Outputs menu
  await tick(200); const outs = item(appMenu, 'Outputs'); const main = outs.submenu.find(x => /Main/.test(x.label || '')); assert.ok(main, 'Main output listed');
  item(main, 'Full screen on display 2').click(); await tick(500);
  const ow = wins.find(w => /\/output\?out=main/.test(w.url || '') && !w.destroyed); assert.ok(ow && ow.opts.fullscreen && ow.opts.x === 1920); console.log('✓ Outputs ▸ Main ▸ Full screen on display 2 → borderless output at x=1920');
  // window.open handling: own pages in-app, external to the system browser
  ctl.webContents.openHandler({ url: `http://localhost:${port}/manual/` }); await tick(50);
  assert.ok(wins.some(w => w.url === `http://localhost:${port}/manual/`), 'manual in an app window');
  ctl.webContents.openHandler({ url: 'https://booth-productions.com/' }); assert.ok(opened.includes('ext:https://booth-productions.com/'));
  const ev = { preventDefault() { this.p = true; } }; ctl.webContents.emit('will-navigate', ev, 'https://example.com/'); assert.ok(ev.p);
  console.log('✓ manual/remote open in app windows; outside links go to the system browser; the controller can\'t navigate away');
  // Help ▸ Manual, View ▸ tab shortcuts
  item(appMenu, 'Show', 'Content Preflight').click(); await tick(50); assert.ok(ctl.webContents.js.some(j => /setRtab\("preflight"\)/.test(j))); console.log('✓ Show ▸ Content Preflight jumps the controller to that tab');
  // window memory
  ctl.setBounds({ x: 100, y: 120, width: 1500, height: 900 }); ctl.emit('resize'); await tick(500);
  const cfg = JSON.parse(fs.readFileSync(path.join(tmp, 'userData', 'desktop.json'), 'utf8')); assert.deepStrictEqual([cfg.windows.controller.x, cfg.windows.controller.width], [100, 1500]); console.log('✓ controller position/size remembered');
  console.log('\nDESKTOP NATIVE TEST PASS');
  try { serverChild.kill(); } catch {} fs.rmSync(tmp, { recursive: true, force: true }); process.exit(0);
})().catch(e => { console.error('FAIL', e); try { serverChild && serverChild.kill(); } catch {} process.exit(1); });
