// Show templates: each one builds a valid show the server accepts and keeps (layers, clips, overlays, timers, cues, view, feeds).
//   node tests/templates_test.js
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
(async () => {
  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxtpl-'));
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8861, OSC_PORT: 8862, DATA_DIR: DATA, MEDIA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxtplm-')) }, stdio: 'ignore' }); kids.push(srv);
  const B = 'http://127.0.0.1:8861';
  for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const cmd = c => fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(c) }).then(async r => { if (!r.ok) throw new Error(await r.text()); return r; });
  const list = await fetch(B + '/api/templates').then(r => r.json());
  assert.deepStrictEqual(list.map(t => t.id), ['wedding', 'conference', 'sports', 'dj', 'corporate', 'theatre']); assert.ok(list.every(t => t.name && t.desc && t.view)); ok('6 templates listed with names, descriptions and views');
  for (const t of list) {
    await cmd({ op: 'newFromTemplate', id: t.id }); await tick(150);
    const s = await fetch(B + '/api/state').then(r => r.json());
    assert.strictEqual(s.template && s.template.id, t.id, t.id + ' kept');
    assert.ok(s.layers.length >= 2 && s.layers.every(l => l.name && !/^Layer \d$/.test(l.name)), t.id + ' named layers');
    assert.ok(s.layers.some(l => l.clips.some(Boolean)), t.id + ' placeholder clips');
    assert.ok(s.cues.length >= 4 && s.cues.every(q => q.type === 'column' && q.data.col < s.comp.columns), t.id + ' cues');
    for (const o of s.overlays.filter(o => o.clip)) assert.ok(o.clip.type === 'gen' && o.clip.gen.kind === 'title' && typeof o.clip.gen.params.tpl === 'number' && o.clip.gen.params.tpl >= 0, t.id + ' overlay is a title');
    ok(`${t.name}: ${s.layers.length} layers, ${s.layers.reduce((n, l) => n + l.clips.filter(Boolean).length, 0)} clips, ${s.overlays.filter(o => o.clip).length} overlays, ${s.timers.length} timers, ${s.cues.length} cues → ${t.view} view`);
    if (t.id === 'conference' || t.id === 'sports') assert.strictEqual(s.switcher.on, true);
    if (t.id === 'sports') { const f = await fetch(B + '/api/feeds').then(r => r.json()); assert.strictEqual(f.values.score.home, 'HOME'); assert.ok(s.feeds.find(x => x.id === 'score' && x.type === 'push' && !('sample' in x))); ok('sports: score feed ready for pushes, with starting values'); }
    if (t.id === 'dj') assert.strictEqual(s.react.enabled, true);
  }
  // a cue from a template actually runs
  await cmd({ op: 'newFromTemplate', id: 'wedding' }); await cmd({ op: 'cueGo' }); await tick(200);
  const s = await fetch(B + '/api/state').then(r => r.json()); assert.strictEqual(s.cueIndex, 0); ok('template cues run (GO → “Guests arrive”)');
  let threw = false; try { await cmd({ op: 'newFromTemplate', id: 'nope' }); } catch { threw = true; } assert.ok(threw, 'unknown template refused'); ok('unknown template refused');
  console.log('templates_test: all passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
