// PIXORA ⇄ QForge over real UDP: QForge's OSC encoder (lib/osc.js) drives PIXORA, and PIXORA's feedback decodes in QForge.
//   QFORGE_DIR=/path/to/qforge node tests/qforge_e2e_test.js   (skipped when QForge isn't checked out)
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert'), dgram = require('dgram');
const QF = process.env.QFORGE_DIR || path.join(__dirname, '..', '..', 'qforge');
if (!fs.existsSync(path.join(QF, 'lib', 'osc.js'))) { console.log('qforge_e2e_test: skipped (QFORGE_DIR not found)'); process.exit(0); }
const osc = require(path.join(QF, 'lib', 'osc.js'));
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
(async () => {
  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxqf-')), MEDIA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxqfm-'));
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8871, OSC_PORT: 8872, DATA_DIR: DATA, MEDIA_DIR: MEDIA }, stdio: 'ignore' }); kids.push(srv);
  const B = 'http://127.0.0.1:8871';
  for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const cmd = c => fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(c) }), st = () => fetch(B + '/api/state').then(r => r.json());
  // "QForge" listening for feedback
  const got = []; const qf = dgram.createSocket('udp4'); qf.on('message', b => { try { got.push(...osc.decode(b)); } catch {} }); await new Promise(r => qf.bind(8873, '127.0.0.1', r));
  const send = (address, args) => new Promise(r => qf.send(osc.encode(address, args), 8872, '127.0.0.1', r));
  const I1 = [{ type: 'i', value: 1 }];
  // QForge → PIXORA
  for (const [i, n] of ['A', 'B'].entries()) await cmd({ op: 'set', path: `layers.0.clips.${i}`, value: { type: 'gen', name: n, gen: { kind: 'solid', params: { c1: '#f00' } } } });
  await send('/pixora/trigger/1/2', I1); await tick(150); let s = await st(); assert.strictEqual(s.layers[0].active, 1); ok('PIXORA cue “Trigger clip 1/2”');
  await send('/pixora/timer/Walk%20in/start', I1); await tick(150); s = await st(); assert.ok(s.timers.find(t => t.name === 'Walk in' && t.running)); ok('PIXORA cue “Timer start” (name with a space)');
  await send('/pixora/master', [{ type: 'f', value: 0.5 }]); await tick(150); s = await st(); assert.strictEqual(s.comp.master, 0.5); ok('PIXORA cue “Master 50%”');
  await send('/pixora/blackout', I1); await tick(150); s = await st(); assert.strictEqual(s.comp.blackout, true);
  await send('/pixora/blackout', [{ type: 'i', value: 0 }]); await tick(150); s = await st(); assert.strictEqual(s.comp.blackout, false); ok('PIXORA cues “Blackout on/off”');
  await send('/pixora/column/1', I1); await tick(150); s = await st(); assert.strictEqual(s.layers[0].active, 0); ok('PIXORA cue “Trigger column 1”');
  await send('/pixora/clear/1', I1); await tick(150); s = await st(); assert.strictEqual(s.layers[0].active, null); ok('PIXORA cue “Clear layer 1”');
  // PIXORA → QForge feedback
  const r = await fetch(B + '/api/qforge', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ on: true, host: '127.0.0.1', port: 8873 }) }).then(x => x.json());
  assert.deepStrictEqual([r.on, r.port, r.oscIn], [true, 8873, 8872]);
  await cmd({ op: 'trigger', layer: 0, clip: 1 });
  const out = new WebSocket('ws://127.0.0.1:8871/ws?role=output'); await new Promise(res => out.onopen = res); await tick(300);
  out.send(JSON.stringify({ t: 'pos', layers: [{ pos: 0.25, t: 2.5, dur: 10 }] })); await tick(200);
  const L = got.find(m => m.address === '/pixora/fb/layer/1'); assert.ok(L, 'progress arrived ' + JSON.stringify(got.map(m => m.address)));
  const v = L.args.map(a => a && typeof a === 'object' && 'value' in a ? a.value : a);
  assert.ok(Math.abs(v[0] - 0.25) < 1e-3 && Math.abs(v[1] - 7.5) < 1e-2 && Math.abs(v[2] - 2.5) < 1e-2 && v[3] === 'B' && v[4] === 1, JSON.stringify(v)); ok('QForge receives clip progress, time left, elapsed and name');
  const trig = (await st()).layers[0].trig; out.send(JSON.stringify({ t: 'ended', layer: 0, trig })); await tick(200);
  assert.ok(got.find(m => m.address === '/pixora/fb/ended/1'), 'ended'); ok('QForge receives clip-ended');
  for (let i = 0; i < 40 && !got.find(m => m.address === '/pixora/fb/hello'); i++) await tick(150);
  assert.ok(got.find(m => m.address === '/pixora/fb/hello')); ok('hello heartbeat');
  out.close(); qf.close(); console.log('qforge_e2e_test: all passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
