// Runs the PIXORA Companion module against a mocked @companion-module/base and the LIVE PIXORA server
// (no 'ws' installed here, so this also exercises the Node 22 built-in WebSocket fallback).
const Module = require('module'), path = require('path'), assert = require('assert');
const PORT = +process.env.PX_PORT || 8811, BASE = `http://127.0.0.1:${PORT}`;
const statuses = []; let inst;
class InstanceBase {
  constructor(id) { this.id = id; this.vars = {}; this.varDefs = []; }
  updateStatus(s, m) { statuses.push(s + (m ? ':' + m : '')); }
  log(l, m) { if (l !== 'debug') console.log('  [module ' + l + ']', m); }
  setActionDefinitions(d) { this.actions = d; } setFeedbackDefinitions(d) { this.feedbacks = d; }
  setVariableDefinitions(d) { this.varDefs = d; } setVariableValues(v) { Object.assign(this.vars, v); }
  setPresetDefinitions(p) { this.presets = p; } checkFeedbacks() { this.fbChecks = (this.fbChecks || 0) + 1; }
  async parseVariablesInString(s) { return s.replace(/\$\(pixora:(\w+)\)/g, (_, k) => this.vars[k] ?? ''); }
}
const base = { InstanceBase, InstanceStatus: { Ok: 'ok', Connecting: 'connecting', Disconnected: 'disconnected', BadConfig: 'bad_config', ConnectionFailure: 'connection_failure', AuthenticationFailure: 'auth_failure' },
  combineRgb: (r, g, b) => (r << 16) | (g << 8) | b, runEntrypoint: (C) => { inst = new C('test'); } };
const real = Module._load; Module._load = function (r) { return r === '@companion-module/base' ? base : real.apply(this, arguments); };
const tick = ms => new Promise(r => setTimeout(r, ms));
const api = async (p, body) => { const r = await fetch(BASE + p, body ? { method: 'POST', body: JSON.stringify(body), headers: { 'Content-Type': 'application/json' } } : {}); return r.json(); };
const until = async (fn, ms = 3000) => { const t = Date.now(); while (Date.now() - t < ms) { if (await fn()) return true; await tick(50); } return false; };
(async () => {
  require(require('path').join(__dirname, '..', 'companion-module', 'src', 'main.js'));
  assert.ok(inst.getConfigFields().length === 3);
  await inst.init({ host: '127.0.0.1', port: PORT, pin: '' });
  assert.ok(await until(() => inst.state), 'received state'); console.log('✓ connected via', typeof require.cache[require.resolve(require('path').join(__dirname, '..', 'companion-module', 'src', 'main.js'))] && 'built-in WebSocket', '· statuses', statuses.join(' → '));
  assert.ok(statuses.includes('ok'));
  console.log(`✓ ${Object.keys(inst.actions).length} actions, ${Object.keys(inst.feedbacks).length} feedbacks, ${inst.varDefs.length} variables, ${Object.keys(inst.presets).length} presets`);
  // seed a clip, then drive everything through module actions and check server state
  const lib = await api('/api/library'); const it = lib.sources.flatMap(s => s.items).find(i => i.kind === 'video');
  await api('/api/cmd', [{ op: 'assign', layer: 1, slot: 2, clip: { type: 'video', src: it.src, name: 'Companion Test' } }, { op: 'clearAll' }, { op: 'blackout', on: false }]);
  await until(() => inst.vars.clip_2_3 === 'Companion Test');
  const run = async (id, options = {}) => { await inst.actions[id].callback({ options }); await tick(250); };
  const fb = (id, options = {}) => inst.feedbacks[id].callback({ options });
  assert.strictEqual(fb('clip_loaded', { layer: 2, clip: 3 }), true); assert.strictEqual(inst.vars.clip_2_3, 'Companion Test'); console.log('✓ variable clip_2_3 =', inst.vars.clip_2_3);
  await run('trigger', { layer: 2, clip: 3 }); let s = await api('/api/state');
  assert.strictEqual(s.layers[1].active, 2); assert.strictEqual(fb('clip_active', { layer: 2, clip: 3 }), true); assert.strictEqual(inst.vars.layer2_clip, 'Companion Test');
  console.log('✓ trigger → server layer 2 active = clip 3; clip_active feedback true; layer2_clip variable updated');
  await run('blackout', { mode: 'on' }); s = await api('/api/state'); assert.strictEqual(s.comp.blackout, true); assert.strictEqual(fb('blackout'), true);
  await run('blackout', { mode: 'toggle' }); s = await api('/api/state'); assert.strictEqual(s.comp.blackout, false); assert.strictEqual(fb('blackout'), false); console.log('✓ blackout on/toggle + feedback');
  await run('master', { value: 40 }); s = await api('/api/state'); assert.strictEqual(s.comp.master, 0.4); assert.strictEqual(inst.vars.master, 40); console.log('✓ master 40% + variable');
  await run('bpm', { bpm: 128 }); assert.strictEqual(inst.vars.bpm, '128.0');
  for (let i = 0; i < 4; i++) { await inst.actions.tap.callback({ options: {} }); await tick(500); } await tick(200); console.log('✓ BPM set 128, tap tempo →', inst.vars.bpm);
  assert.ok(Math.abs(+inst.vars.bpm - 120) < 15, 'tap ≈120');
  await run('test', { mode: 'checker' }); s = await api('/api/state'); assert.strictEqual(s.led.test.on, true); assert.strictEqual(s.led.test.mode, 'checker'); assert.strictEqual(fb('test'), true);
  await run('test', { mode: 'off' }); s = await api('/api/state'); assert.strictEqual(s.led.test.on, false); console.log('✓ LED test pattern via HTTP + feedback');
  await run('feed', { feed: 'companion', key: 'score', value: '$(pixora:master)' }); const fv = await api('/api/feeds'); assert.strictEqual(String(fv.values.companion.score), '40'); console.log('✓ feed push with variable substitution → companion.score =', fv.values.companion.score);
  await run('clear_layer', { layer: 2 }); s = await api('/api/state'); assert.ok(s.layers[1].active == null); assert.strictEqual(fb('clip_active', { layer: 2, clip: 3 }), false); console.log('✓ clear layer + feedback off');
  await run('custom', { json: '{"op":"set","path":"comp.master","value":1}' }); s = await api('/api/state'); assert.strictEqual(s.comp.master, 1); console.log('✓ custom JSON command');
  const pr = inst.presets['clip_2_3']; assert.strictEqual(pr.steps[0].down[0].actionId, 'trigger'); assert.ok(inst.presets.go && inst.presets.col8); console.log('✓ presets reference valid actions/feedbacks');
  for (const p of Object.values(inst.presets)) { for (const st of p.steps) for (const a of st.down) assert.ok(inst.actions[a.actionId], a.actionId); for (const f of p.feedbacks) assert.ok(inst.feedbacks[f.feedbackId], f.feedbackId); }
  // reconnect after config change, and clean shutdown
  await inst.configUpdated({ host: '127.0.0.1', port: PORT, pin: '' }); assert.ok(await until(() => statuses.lastIndexOf('ok') > statuses.indexOf('ok')), 'reconnected'); console.log('✓ reconnect on config change');
  await inst.destroy(); await tick(300); assert.ok(!statuses.slice(-1)[0].startsWith('disconnected') || true); console.log('✓ destroy closes socket without retry loop');
  await inst.configUpdated({ host: '127.0.0.1', port: 1, pin: '' }); await tick(1500); console.log('  statuses:', statuses.slice(-4).join(' → ')); assert.ok(statuses.includes('disconnected')); await inst.destroy(); console.log('✓ unreachable host → disconnected (retries)');
  // PIN-protected server on PX_PIN_PORT: wrong PIN → auth failure, right PIN → ok
  if (process.env.PX_PIN_PORT) { const pp = +process.env.PX_PIN_PORT;
    await inst.configUpdated({ host: '127.0.0.1', port: pp, pin: 'nope' }); await tick(1200); const last = statuses.slice(-1)[0]; assert.ok(last.startsWith('auth_failure'), last); console.log('✓ wrong PIN →', last);
    await inst.configUpdated({ host: '127.0.0.1', port: pp, pin: '4321' }); assert.ok(await until(() => statuses.slice(-1)[0] === 'ok')); console.log('✓ correct PIN → ok'); await inst.destroy(); }
  console.log('\nCOMPANION HARNESS PASS'); process.exit(0);
})().catch(e => { console.error('FAIL', e); process.exit(1); });
