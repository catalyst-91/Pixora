// PIXORA local recording tests: every format, with and without ffmpeg. A fake output window answers the
// server's 'rec' message by uploading a capture made with ffmpeg (what MediaRecorder / the PCM worklet send).
// node tests/rec_test.js   (needs ffmpeg + ffprobe)
const { spawn, execFileSync } = require('child_process');
const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert');
const ROOT = path.join(__dirname, '..');
const tick = ms => new Promise(r => setTimeout(r, ms));
const ok = m => console.log('✓ ' + m);
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'pxrec-'));

// captures like the browser makes them: 3 s of test pattern + tone
const cap = {};
function mk(name, args) { const f = path.join(TMP, name); execFileSync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', ...args, f]); return fs.readFileSync(f); }
cap.webm = mk('c.webm', ['-f', 'lavfi', '-i', 'testsrc2=s=640x360:r=30:d=3', '-f', 'lavfi', '-i', 'sine=f=440:d=3:r=48000', '-ac', '2', '-c:v', 'libvpx-vp9', '-deadline', 'realtime', '-cpu-used', '8', '-c:a', 'libopus', '-shortest']);
cap.mp4 = mk('c.mp4', ['-f', 'lavfi', '-i', 'testsrc2=s=642x362:r=30:d=3', '-f', 'lavfi', '-i', 'sine=f=440:d=3:r=48000', '-ac', '2', '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p', '-vf', 'scale=642:362', '-c:a', 'aac', '-shortest', '-movflags', 'frag_keyframe+empty_moov']);
cap.f32 = mk('c.f32', ['-f', 'lavfi', '-i', 'sine=f=1000:d=3:r=48000', '-ac', '2', '-f', 'f32le', '-c:a', 'pcm_f32le']);
const probe = f => JSON.parse(execFileSync('ffprobe', ['-v', 'error', '-show_entries', 'stream=codec_name,codec_type,width,height,sample_rate,channels:format=duration,format_name', '-of', 'json', f]).toString());

const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
async function server(port, env) {
  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxrecd-')), MEDIA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxrecm-'));
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: port, OSC_PORT: port + 1, DATA_DIR: DATA, MEDIA_DIR: MEDIA, ...env }, stdio: ['ignore', 'pipe', 'pipe'] });
  kids.push(srv); let log = ''; srv.stdout.on('data', d => log += d); srv.stderr.on('data', d => log += d);
  const B = `http://127.0.0.1:${port}`;
  for (let i = 0; i < 50 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const api = async (p, opt = {}) => { const r = await fetch(B + p, { ...opt, headers: { 'Content-Type': 'application/json' }, body: opt.body && typeof opt.body !== 'string' ? JSON.stringify(opt.body) : opt.body }); return { status: r.status, body: await r.json().catch(() => ({})) }; };
  // fake output window: uploads the matching capture in 64 kB chunks when asked to record
  const out = new WebSocket(`ws://127.0.0.1:${port}/ws?role=output`); const errors = [];
  let pending = null;
  out.onmessage = async e => { const m = JSON.parse(e.data);
    if (m.t === 'rec' && m.on) pending = m;
    if (m.t === 'rec' && !m.on && pending) { const p = pending; pending = null;
      const ext = p.kind === 'audio' ? 'f32' : p.prefer === 'webm' ? 'webm' : 'mp4'; const buf = cap[ext];
      for (let o = 0; o < buf.length; o += 65536) await fetch(`${B}/api/rec/chunk?id=${p.id}&ext=${ext}${ext === 'f32' ? '&sr=48000&ch=2' : ''}`, { method: 'POST', body: buf.subarray(o, o + 65536) });
      await fetch(`${B}/api/rec/done?id=${p.id}`, { method: 'POST' }); }
  };
  const ctl = new WebSocket(`ws://127.0.0.1:${port}/ws?role=control`); const states = [];
  ctl.onmessage = e => { const m = JSON.parse(e.data); if (m.t === 'recstate') states.push(m.rec); if (m.t === 'error') errors.push(m.msg); };
  await new Promise(r => out.onopen = r); await tick(300);
  return { api, srv, MEDIA, DATA, errors, states, close: () => { out.close(); ctl.close(); srv.kill(); }, log: () => log };
}
async function record(S, body, waitMs = 400) {
  const st = await S.api('/api/rec/start', { method: 'POST', body }); assert.ok(st.body.on, 'start: ' + JSON.stringify(st.body));
  await tick(waitMs); await S.api('/api/rec/stop');
  let v; for (let i = 0; i < 150; i++) { v = (await S.api('/api/rec/status')).body; if (!v.on && !v.finishing && v.last && v.last.at > st.body.since) break; if (v.error && !v.on && !v.finishing) break; await tick(200); }
  assert.ok(v.last && v.last.at > st.body.since, 'finished: ' + JSON.stringify(v) + '\n' + S.errors.join('\n'));
  return v.last;
}

(async () => {
  /* ---------------- with ffmpeg */
  const S = await server(8841, {});
  const F = (await S.api('/api/rec/formats')).body;
  assert.strictEqual(F.formats.length, 8); assert.ok(F.formats.every(f => f.ok), JSON.stringify(F.formats.filter(f => !f.ok)));
  ok(`formats (ffmpeg): ${F.formats.map(f => f.id).join(', ')} — default folder ${path.relative(S.MEDIA, F.defaultFolder)}`);

  const expect = {
    mp4: { fmt: /mp4/, v: 'h264', a: 'aac' }, 'mov-prores': { fmt: /mov/, v: 'prores', a: 'pcm_s24le' }, 'mov-hap': { fmt: /mov/, v: 'hap', a: 'pcm_s16le' },
    mkv: { fmt: /matroska/, v: 'h264', a: 'flac' }, webm: { fmt: /webm|matroska/, v: 'vp9', a: 'opus' },
    wav: { fmt: /wav/, a: 'pcm_s24le' }, mp3: { fmt: /mp3/, a: 'mp3' }, flac: { fmt: /flac/, a: 'flac' } };
  for (const [id, e] of Object.entries(expect)) {
    const last = await record(S, { format: id, audio: 'clips' });
    const pr = probe(last.path); const v = pr.streams.find(s => s.codec_type === 'video'), a = pr.streams.find(s => s.codec_type === 'audio');
    assert.match(pr.format.format_name, e.fmt); assert.ok(Math.abs(+pr.format.duration - 3) < 0.3, 'duration ' + pr.format.duration);
    if (e.v) { assert.strictEqual(v.codec_name, e.v); if (id === 'mov-hap') assert.strictEqual(v.width % 4, 0); } else assert.ok(!v, 'audio only has no video');
    assert.strictEqual(a.codec_name, e.a); assert.strictEqual(+a.channels, 2); if (id !== 'mp3' && id !== 'webm') assert.strictEqual(+a.sample_rate, 48000);
    assert.ok(last.file.startsWith('PIXORA ') && last.file.endsWith(path.extname(last.path)));
    ok(`${id.padEnd(10)} → ${last.file}  ${v ? `${v.codec_name} ${v.width}×${v.height} + ` : ''}${a.codec_name} ${a.sample_rate} Hz · ${(+pr.format.duration).toFixed(2)} s · ${Math.round(last.bytes / 1024)} kB`);
  }
  // nothing left behind in the temp capture folder
  assert.deepStrictEqual(fs.readdirSync(path.join(S.DATA, 'rec-tmp')), []); ok('temp capture files cleaned up');

  // custom folder, name, keep master, prefs persisted
  const dest = path.join(TMP, 'Show Night', 'Recs');
  await S.api('/api/rec/prefs', { method: 'POST', body: { folder: dest, prefix: 'Rocky NYE', keepMaster: true, format: 'mov-prores', audio: 'clips+input', fps: 25 } });
  const pf = (await S.api('/api/rec/formats')).body.prefs; assert.strictEqual(pf.folder, dest); assert.strictEqual(pf.fps, 25);
  const last = await record(S, {});
  assert.strictEqual(path.dirname(last.path), dest); assert.ok(last.file.startsWith('Rocky NYE ') && last.file.endsWith('.mov'));
  const files = fs.readdirSync(dest); assert.ok(files.some(f => f.includes('(master).webm')), files.join(', '));
  assert.strictEqual(probe(last.path).streams.find(s => s.codec_type === 'video').codec_name, 'prores');
  ok(`custom folder + name + keep master: ${files.join(' | ')}`);
  await tick(300); const settings = JSON.parse(fs.readFileSync(path.join(S.DATA, 'settings.json'), 'utf8')); assert.strictEqual(settings.rec.prefix, 'Rocky NYE'); ok('recording settings saved on this machine');

  // audio-only with "No audio" is upgraded to clips+input; bad folder is refused cleanly
  await S.api('/api/rec/prefs', { method: 'POST', body: { folder: '', prefix: 'PIXORA', keepMaster: false } });
  let r = await S.api('/api/rec/start', { method: 'POST', body: { format: 'wav', audio: 'none' } }); assert.strictEqual(r.body.audio, 'clips+input'); await S.api('/api/rec/stop'); await tick(1500);
  const blocker = path.join(TMP, 'afile'); fs.writeFileSync(blocker, 'x');
  r = await S.api('/api/rec/start', { method: 'POST', body: { format: 'mp4', folder: path.join(blocker, 'sub') } }); assert.ok(r.status >= 400 && /Cannot write/.test(r.body.error)); ok('audio-only never records silence; unwritable folder refused: ' + r.body.error.split(' (')[0]);

  // HTTP toggle + OSC start/stop + auto-stop timer
  r = await S.api('/api/rec/toggle'); assert.ok(r.body.on); r = await S.api('/api/rec/toggle'); assert.ok(!r.body.on); await tick(1500);
  const dg = require('dgram').createSocket('udp4'); const osc = (addr, s) => { const pad = b => Buffer.concat([b, Buffer.alloc(4 - (b.length % 4))]); const parts = [pad(Buffer.from(addr)), pad(Buffer.from(s ? ',s' : ','))]; if (s) parts.push(pad(Buffer.from(s))); dg.send(Buffer.concat(parts), 8842, '127.0.0.1'); };
  osc('/pixora/rec/start', 'mp3'); await tick(500); let v = (await S.api('/api/rec/status')).body; assert.ok(v.on && v.format === 'mp3', JSON.stringify(v));
  osc('/pixora/rec/stop'); for (let i = 0; i < 40 && ((await S.api('/api/rec/status')).body.on); i++) await tick(100);
  r = await S.api('/api/rec/start', { method: 'POST', body: { format: 'mp4' } }); if ((await S.api('/api/rec/status')).body.stopping) { assert.ok(r.status >= 400 && /still being saved/.test(r.body.error)); ok('start while the last file is still saving is refused clearly'); } v = (await S.api('/api/rec/status')).body; assert.ok(!v.on); ok('HTTP toggle and OSC /pixora/rec/start mp3 · /pixora/rec/stop');
  const idle = async () => { for (let i = 0; i < 80; i++) { const x = (await S.api('/api/rec/status')).body; if (!x.on && !x.stopping && !x.finishing) return; await tick(150); } };
  await idle();
  r = await S.api('/api/rec/start', { method: 'POST', body: { format: 'webm', stopAfter: 0.02 } }); assert.ok(r.body.on); await tick(2200); v = (await S.api('/api/rec/status')).body; assert.ok(!v.on, 'auto-stop'); ok('auto-stop timer');
  await idle();

  // the recording shows up in the Local Library
  await tick(500); const lib = (await S.api('/api/library?refresh=1')).body; const names = lib.sources.flatMap(s => s.items).map(i => i.name);
  assert.ok(names.some(n => /^PIXORA .*\.mp4$/.test(n)), names.join(', ')); ok(`recordings appear in the Library (${names.filter(n => /^PIXORA /.test(n)).length} files)`);

  // output window closing mid-recording is reported, not hung
  r = await S.api('/api/rec/start', { method: 'POST', body: { format: 'mp4' } }); assert.ok(r.body.on);
  S.close(); ok('(server stopped)');

  /* ---------------- without ffmpeg */
  const N = await server(8851, { FFMPEG_PATH: path.join(TMP, 'no-ffmpeg-here') });
  const NF = (await N.api('/api/rec/formats')).body; const avail = NF.formats.filter(f => f.ok).map(f => f.id);
  assert.deepStrictEqual(avail, ['mp4', 'webm', 'wav']); ok('formats without ffmpeg: ' + avail.join(', ') + ' (others say "needs ffmpeg")');
  r = await N.api('/api/rec/start', { method: 'POST', body: { format: 'mov-prores' } }); assert.ok(r.status >= 400 && /needs ffmpeg/.test(r.body.error)); ok('ProRes refused with a clear message');
  let l = await record(N, { format: 'webm' }); assert.strictEqual(probe(l.path).streams[0].codec_name, 'vp9'); ok('WebM saved directly: ' + l.file);
  l = await record(N, { format: 'mp4' }); assert.strictEqual(probe(l.path).streams.find(s => s.codec_type === 'video').codec_name, 'h264'); ok('MP4 saved directly: ' + l.file);
  l = await record(N, { format: 'wav' }); const pw = probe(l.path); assert.strictEqual(pw.streams[0].codec_name, 'pcm_f32le'); assert.ok(Math.abs(+pw.format.duration - 3) < 0.05); ok(`WAV written without ffmpeg (32-bit float, ${(+pw.format.duration).toFixed(2)} s): ${l.file}`);
  N.close();
  console.log('\nAll recording tests passed.'); process.exit(0);
})().catch(e => { console.error('✗', e); process.exit(1); });
