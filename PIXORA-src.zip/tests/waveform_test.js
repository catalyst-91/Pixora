// Timeline audio waveforms: peaks from ffmpeg (10 ms buckets, cached by file identity), files with no audio, and the
// browser-decode fallback when the server has no ffmpeg (peaks posted back and shared).
//   node tests/waveform_test.js   (needs ffmpeg on PATH)
const { spawn, spawnSync } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
(async () => {
  if (spawnSync('ffmpeg', ['-version']).status !== 0) { console.log('ffmpeg not found — skipped'); process.exit(0); }
  const MEDIA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxwm-')), DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxwd-'));
  fs.mkdirSync(path.join(MEDIA, 'local'), { recursive: true });
  const mk = (name, args) => assert.strictEqual(spawnSync('ffmpeg', ['-v', 'error', '-y', ...args, path.join(MEDIA, 'local', name)]).status, 0, name);
  // 1 s silence then 1 s of a loud tone, with video; a video with no audio at all
  mk('tone.mp4', ['-f', 'lavfi', '-i', 'color=c=blue:s=64x36:d=2', '-f', 'lavfi', '-i', 'aevalsrc=if(lt(t\\,1)\\,0\\,0.8*sin(2*PI*440*t)):s=48000:d=2', '-shortest', '-c:v', 'libx264', '-c:a', 'aac']);
  mk('silent.mp4', ['-f', 'lavfi', '-i', 'color=c=red:s=64x36:d=1', '-c:v', 'libx264']);
  const start = env => { const k = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8905, OSC_PORT: 8906, DATA_DIR: DATA, MEDIA_DIR: MEDIA, ...env }, stdio: 'ignore' }); kids.push(k); return k; };
  const B = 'http://127.0.0.1:8905', up = async () => { for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150); };
  let srv = start({}); await up();
  const lib = await fetch(B + '/api/library').then(r => r.json()); const all = (lib.sources || []).flatMap(s => s.items || []);
  const src = n => (all.find(i => i.name === n) || {}).src; assert.ok(src('tone.mp4') && src('silent.mp4'), JSON.stringify(all.map(i => i.src)));
  const get = s => fetch(B + '/api/waveform?src=' + encodeURIComponent(s)).then(async r => ({ status: r.status, j: await r.json() }));
  let t0 = Date.now(), r = await get(src('tone.mp4')); const first = Date.now() - t0;
  assert.strictEqual(r.status, 200); const pk = Buffer.from(r.j.peaks, 'base64'); assert.strictEqual(r.j.rate, 100); assert.ok(Math.abs(r.j.duration - 2) < 0.1, r.j.duration);
  const avg = (a, b) => [...pk.subarray(a, b)].reduce((x, y) => x + y, 0) / (b - a);
  assert.ok(avg(5, 90) < 10 && avg(110, 195) > 150, `silent half ${avg(5, 90)}, tone half ${avg(110, 195)}`);
  ok(`ffmpeg peaks: 100 per second, silence ≈ ${avg(5, 90).toFixed(0)}, tone ≈ ${avg(110, 195).toFixed(0)} (first decode ${first} ms)`);
  t0 = Date.now(); r = await get(src('tone.mp4')); assert.strictEqual(r.status, 200); assert.ok(Date.now() - t0 < first + 50 && fs.readdirSync(path.join(DATA, 'waves')).length === 1, 'served from the cache');
  r = await get(src('silent.mp4')); assert.deepStrictEqual([r.status, r.j.none], [200, true]);
  r = await get('local/nope.mp4'); assert.strictEqual(r.status, 404); r = await get('../etc/passwd'); assert.strictEqual(r.status, 404);
  ok('cached on disk; a video with no audio says so; unknown / escaping paths refused');
  // touching the file invalidates the cache
  fs.utimesSync(path.join(MEDIA, 'local', 'tone.mp4'), new Date(), new Date(Date.now() + 5000)); r = await get(src('tone.mp4')); assert.strictEqual(fs.readdirSync(path.join(DATA, 'waves')).length, 3, 'new entry after the file changed');
  ok('editing the file makes a fresh waveform');
  // no ffmpeg: the controller decodes and posts; others then get the shared copy
  srv.kill(); await tick(400); fs.rmSync(path.join(DATA, 'waves'), { recursive: true }); srv = start({ FFMPEG_PATH: '/nonexistent/ffmpeg' }); await up();
  r = await get(src('tone.mp4')); assert.deepStrictEqual([r.status, r.j.needClient], [202, true]);
  const peaks = Buffer.alloc(150, 99).toString('base64');
  let pr = await fetch(B + '/api/waveform?src=' + encodeURIComponent(src('tone.mp4')), { method: 'POST', body: JSON.stringify({ rate: 100, peaks }) }); assert.strictEqual(pr.status, 200);
  pr = await fetch(B + '/api/waveform?src=' + encodeURIComponent(src('tone.mp4')), { method: 'POST', body: '{nope' }); assert.strictEqual(pr.status, 400);
  r = await get(src('tone.mp4')); assert.strictEqual(r.status, 200); assert.strictEqual(r.j.duration, 1.5); assert.strictEqual(Buffer.from(r.j.peaks, 'base64')[0], 99);
  ok('without ffmpeg: asks the controller to decode, stores the posted peaks and serves them to everyone');
  console.log('Waveform test passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
