// LTC and MTC decoders (public/tc-decoders.js): every frame rate incl. 29.97 drop-frame, quiet and noisy signals,
// inverted polarity, timecode played backwards, MTC quarter frames (both directions) and full-frame SysEx.
//   node tests/timecode_readers_test.js
const path = require('path'), assert = require('assert'); const T = require(path.join(__dirname, '..', 'public', 'tc-decoders.js'));
const ok = m => console.log('✓ ' + m);
// drop-frame arithmetic
assert.strictEqual(T.toFrames(0, 1, 0, 2, 29.97, true), 1800); assert.deepStrictEqual(T.fromFrames(1800, 29.97, true), { h: 0, m: 1, s: 0, f: 2 });
assert.deepStrictEqual(T.fromFrames(17982, 29.97, true), { h: 0, m: 10, s: 0, f: 0 }); assert.strictEqual(T.toFrames(1, 0, 0, 0, 29.97, true), 107892);
for (const n of [0, 1799, 1800, 17981, 17982, 107891, 123456]) { const t = T.fromFrames(n, 29.97, true); assert.strictEqual(T.toFrames(t.h, t.m, t.s, t.f, 29.97, true), n, 'round trip ' + n); }
ok('drop-frame counting: ;00 and ;01 skipped each minute except every tenth, round-trips exactly');
const decode = (sig, sr = 48000) => { const out = []; const d = new T.LtcDecoder(sr, f => out.push(f)); for (let i = 0; i < sig.length; i += 1024) d.push(sig.subarray(i, i + 1024)); return out; };
for (const [fps, drop] of [[24, false], [25, false], [29.97, true], [30, false]]) {
  const start = T.toFrames(10, 59, 58, 0, fps, drop);
  const out = decode(T.renderLtc({ fps, drop, start, count: 91 })); // (the last frame of a stream completes on the next frame's first edge)
  assert.ok(out.length >= 85, `${fps}: decoded ${out.length}/90`);
  const last = out[out.length - 1]; assert.strictEqual(last.fps, fps); assert.strictEqual(last.drop, drop); assert.strictEqual(last.reverse, false);
  for (let i = 1; i < out.length; i++) assert.strictEqual(out[i].frames - out[i - 1].frames, 1, `${fps}: consecutive`);
  assert.ok(out.some(o => o.frames === start + 89));
  ok(`LTC ${fps}${drop ? ' DF' : ''}: ${out.length}/90 frames, rate detected, across the hour boundary (${out[out.length - 1].label})`);
}
{ // 29.97 drop-frame label skips at the minute
  const out = decode(T.renderLtc({ fps: 29.97, drop: true, start: T.toFrames(0, 0, 59, 25, 29.97, true), count: 10 }));
  const labels = out.map(o => o.label); assert.ok(labels.includes('00:00:59;29') && labels.includes('00:01:00;02') && !labels.includes('00:01:00;00'), labels.join(' ')); ok('DF labels jump 00:00:59;29 → 00:01:00;02');
}
{ // quiet, noisy and inverted
  const sig = T.renderLtc({ fps: 25, start: 1000, count: 61, amp: 0.02 }); let seed = 9; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647 - 0.5;
  for (let i = 0; i < sig.length; i++) sig[i] = -(sig[i] + rnd() * 0.012); // -34 dBFS, noise at ~30% of the signal, polarity flipped
  const out = decode(sig, 48000); assert.ok(out.length >= 50, 'quiet/noisy decoded ' + out.length); assert.ok(out.some(o => o.frames === 1059)); ok(`quiet (−34 dBFS), noisy and inverted LTC: ${out.length}/60 frames`);
}
{ // 44.1 kHz input
  const out = decode(T.renderLtc({ sampleRate: 44100, fps: 30, start: 500, count: 40 }), 44100); assert.ok(out.length >= 36); assert.strictEqual(out[out.length - 1].fps, 30); ok('44.1 kHz sound cards');
}
{ // reverse
  const out = decode(T.renderLtc({ fps: 25, start: 2000, count: 40, reverse: true }));
  assert.ok(out.length >= 36, 'reverse decoded ' + out.length); assert.ok(out.every(o => o.reverse)); for (let i = 1; i < out.length; i++) assert.strictEqual(out[i].frames - out[i - 1].frames, -1);
  ok(`LTC played backwards: ${out.length}/40 frames, counting down, flagged reverse`);
}
{ // MTC
  const got = []; const M = new T.MtcDecoder(f => got.push(f));
  const qf = (n, fps, drop) => { const t = T.fromFrames(n, fps, drop); const code = T.RATES.indexOf(fps); return [t.f & 15, t.f >> 4, t.s & 15, t.s >> 4, t.m & 15, t.m >> 4, t.h & 15, (t.h >> 4) | (code << 1)].map((v, i) => (i << 4) | v); };
  for (let n = 100; n < 120; n += 2) qf(n, 25, false).forEach(b => M.quarter(b));
  assert.strictEqual(got.length, 10); assert.strictEqual(got[0].frames, 102); assert.strictEqual(got[9].frames, 120); assert.strictEqual(got[9].fps, 25); ok('MTC quarter frames at 25 fps (two-frame lag compensated)');
  got.length = 0; for (let n = 1798; n < 1806; n += 2) qf(n, 29.97, true).forEach(b => M.quarter(b)); assert.ok(got.every(g => g.drop && g.fps === 29.97)); assert.strictEqual(got[got.length - 1].label, '00:01:00;08'); ok('MTC 29.97 drop-frame');
  got.length = 0; for (let n = 200; n > 180; n -= 2) qf(n, 30, false).reverse().forEach(b => M.quarter(b)); assert.ok(got.length >= 9 && got.every(g => g.reverse)); assert.ok(got[1].frames < got[0].frames); ok('MTC running backwards (quarter frames in reverse order)');
  got.length = 0; assert.ok(M.sysex([0xF0, 0x7F, 0x7F, 0x01, 0x01, (1 << 5) | 2, 3, 4, 5, 0xF7])); assert.strictEqual(got[0].label, '02:03:04:05'); assert.strictEqual(got[0].fps, 25); ok('MTC full-frame SysEx (locate)');
}
