// Show versions: save / list / rename / delete, automatic versions (timer only when changed, on Save, before open / import /
// restore), compare (layers, clip slots, effects, outputs, cues, timeline; live-only state ignored), full restore that keeps
// what's on air, bringing back single items, and pruning of automatic versions.
//   node tests/versions_test.js
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
const VERS = require('../server-versions.js'), S = require('../public/schema.js');
(async () => {
  // ---- pure diff
  const a = S.newState(), b = JSON.parse(JSON.stringify(a));
  b.layers[0].clips[0] = { type: 'video', name: 'Intro', src: 'local/intro.mp4' }; b.layers[1].name = 'Lower thirds'; b.layers[1].fx.blur.on = true; b.layers[1].fx.blur.radius = 9;
  b.layers[0].active = 3; b.layers[0].trig = 99; b.comp.beatEpoch = 12345; b.timeline.play.pos = 50; // live-only: ignored
  b.outputs.push(S.outputDefaults('o2', 'Side screen')); b.cues = [{ id: 'c1', name: 'Walk-in', num: 1 }]; b.comp.width = 3840;
  const L1 = b.layers.splice(2, 1)[0]; // layer removed
  let d = VERS.diff(a, b); const has = (kind, re) => d.some(x => x.kind === kind && re.test(x.label));
  assert.ok(has('added', /Layer 1 .* slot 1: Intro/) && has('changed', /Lower thirds” settings/) && has('added', /effect blur/) && has('added', /Output “Side screen”/) && has('added', /Cue 1 “Walk-in”/), JSON.stringify(d, null, 1));
  assert.ok(has('removed', new RegExp('Layer “' + L1.name + '”')) && d.find(x => x.label === 'Composition settings').fields.some(f => f.path === 'width' && f.to === '3840'));
  assert.ok(!JSON.stringify(d).includes('beatEpoch') && !JSON.stringify(d).includes('"trig"') && !d.some(x => x.area === 'timeline'), 'live state ignored');
  const c = JSON.parse(JSON.stringify(b)); c.layers[0].clips[0].src = 'local/other.mp4'; c.layers[0].clips[0].speed = 2; d = VERS.diff(b, c);
  assert.ok(d.length === 1 && d[0].kind === 'replaced' && d[0].fields.some(f => f.path === 'speed'));
  assert.deepStrictEqual(VERS.diff(a, JSON.parse(JSON.stringify(a))), []);
  ok('compare: clip slots, layer settings, effects, outputs, cues, removed layers, comp settings; playing state ignored; identical shows → nothing');
  // pick
  const live = JSON.parse(JSON.stringify(b)); live.layers[0].clips[0] = null; live.cues = []; live.layers[1].fx.blur = { on: false };
  VERS.pick(live, b, `layers/${b.layers[0].id}/clips/0`); VERS.pick(live, b, 'cues/c1'); VERS.pick(live, b, `layers/${b.layers[1].id}/fx/blur`);
  assert.strictEqual(live.layers[0].clips[0].name, 'Intro'); assert.strictEqual(live.cues[0].name, 'Walk-in'); assert.strictEqual(live.layers[1].fx.blur.radius, 9);
  VERS.pick(live, a, 'outputs/o2'); assert.ok(!live.outputs.find(o => o.id === 'o2'), 'picking an item the older version lacks removes it');
  assert.throws(() => VERS.pick(live, a, 'nonsense/x'), /nothing to bring back/);
  ok('bring back a clip slot, a cue, an effect; an item added since is removed again');

  // ---- server
  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxver-'));
  const start = () => { const k = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8911, OSC_PORT: 8912, DATA_DIR: DATA, MEDIA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxverm-')) }, stdio: 'ignore' }); kids.push(k); return k; };
  let srv = start(); const B = 'http://127.0.0.1:8911', up = async () => { for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150); }; await up();
  const cmd = x => fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(x) }).then(r => r.json());
  const api = p => fetch(B + p).then(r => r.json()), state = () => api('/api/state'), vers = async () => (await api('/api/versions')).versions;
  await cmd({ op: 'set', path: 'comp.name', value: 'Rocky NYE' });
  await cmd({ op: 'assign', layer: 0, slot: 0, clip: { type: 'gen', name: 'Red', gen: { kind: 'solid', params: { c1: '#ff0000' } } } }); await cmd({ op: 'trigger', layer: 0, clip: 0 });
  await cmd({ op: 'versionSave', label: 'Soundcheck', note: 'before the client changes' });
  let v = await vers(); assert.strictEqual(v.length, 1); assert.deepStrictEqual([v[0].label, v[0].note, v[0].auto, v[0].clips, v[0].show], ['Soundcheck', 'before the client changes', false, 1, 'Rocky NYE']);
  const v1 = v[0].id;
  // edit: replace the clip, add one, add a cue
  await cmd({ op: 'assign', layer: 0, slot: 0, clip: { type: 'gen', name: 'Blue', gen: { kind: 'solid', params: { c1: '#0000ff' } } } });
  await cmd({ op: 'assign', layer: 1, slot: 2, clip: { type: 'gen', name: 'Logo', gen: { kind: 'solid', params: { c1: '#ffffff' } } } });
  await cmd({ op: 'set', path: 'layers.1.opacity', value: 0.4 });
  let cmp = await api(`/api/versions/compare?a=${v1}&b=current`);
  assert.ok(cmp.changes.some(x => /slot 1: Red → Blue/.test(x.label)) && cmp.changes.some(x => x.kind === 'added' && /slot 3: Logo/.test(x.label)) && cmp.changes.some(x => /Layer 2.* settings/.test(x.label) && x.fields.some(f => f.path === 'opacity')), JSON.stringify(cmp.changes));
  ok(`server compare: ${cmp.changes.length} changes (${Object.entries(cmp.counts).map(([k, n]) => n + ' ' + k).join(', ')})`);
  // bring back the old clip only
  const pickRed = cmp.changes.find(x => /Red → Blue/.test(x.label)).pick; await cmd({ op: 'versionPick', id: v1, pick: pickRed });
  let st = await state(); assert.strictEqual(st.layers[0].clips[0].name, 'Red'); assert.strictEqual(st.layers[1].clips[2].name, 'Logo', 'other edits kept');
  await cmd({ op: 'undo' }); st = await state(); assert.strictEqual(st.layers[0].clips[0].name, 'Blue', 'bring back is undoable');
  ok('bring back one clip from a version; everything else stays; undo works');
  // full restore keeps what's on air and makes a safety version first
  const nBefore = (await vers()).length; await cmd({ op: 'versionRestore', id: v1 });
  st = await state(); assert.strictEqual(st.layers[0].clips[0].name, 'Red'); assert.ok(!st.layers[1].clips[2]); assert.strictEqual(st.layers[0].active, 0, 'playing clip kept'); assert.strictEqual(st.comp.name, 'Rocky NYE');
  v = await vers(); assert.strictEqual(v.length, nBefore + 1); assert.ok(v[0].auto && /Before restoring/.test(v[0].label) && v[0].clips === 2);
  ok('restore: show back to the version, on-air clip untouched, “Before restoring” safety version saved');
  // Save (saveComp) → version; no-change timer version skipped; rename keeps; delete
  await cmd({ op: 'saveComp', name: 'Rocky NYE' }); v = await vers(); assert.ok(v.some(x => x.label === 'Saved' && x.auto));
  const n2 = v.length; await cmd({ op: 'versionEvery', minutes: 0 }); assert.strictEqual((await api('/api/versions')).every, 0);
  await cmd({ op: 'versionRename', id: v.find(x => x.label === 'Saved').id, label: 'Final', note: 'signed off' }); v = await vers(); assert.ok(v.some(x => x.label === 'Final' && !x.auto && x.note === 'signed off'));
  await cmd({ op: 'versionDelete', id: v1 }); v = await vers(); assert.strictEqual(v.length, n2 - 1); assert.ok(!v.some(x => x.id === v1));
  assert.strictEqual((await fetch(B + '/api/versions/compare?a=nope&b=current')).status, 404); assert.strictEqual((await fetch(B + '/api/versions/compare?a=..%2F..%2Fstate&b=current')).status, 404);
  const ex = await fetch(B + '/api/versions/export?id=' + v[0].id); assert.strictEqual(ex.status, 200); const doc = await ex.json(); assert.ok(/-show$/.test(doc.format) && doc.state.layers.length);
  ok('Save makes a version; rename keeps an automatic one; delete; bad ids refused; a version exports as a .pixora show');
  // per-show folders: loading another composition switches the list; a safety version is taken first
  await cmd({ op: 'set', path: 'comp.name', value: 'Polo Day' }); assert.strictEqual((await vers()).length, 0, 'versions are per show name');
  await cmd({ op: 'loadComp', name: 'Rocky NYE' }); st = await state(); assert.strictEqual(st.comp.name, 'Rocky NYE');
  const polo = fs.readdirSync(path.join(DATA, 'versions', 'Polo Day')).filter(f => f.endsWith('.meta')).map(f => JSON.parse(fs.readFileSync(path.join(DATA, 'versions', 'Polo Day', f))));
  assert.ok(polo.length === 1 && /Before opening “Rocky NYE”/.test(polo[0].label));
  ok('versions are kept per show; opening another show versions the one you leave');
  // automatic timer: only when something changed; pruned to 40
  const V = VERS({ DATA, state: () => st2, safeName: n => n, autoMinutes: () => 0 }); let st2 = S.newState(); st2.comp.name = 'Auto';
  assert.ok(V.save({ auto: true })); assert.strictEqual(V.save({ auto: true }), null, 'unchanged → no new version');
  st2.layers[0].active = 2; assert.strictEqual(V.save({ auto: true }), null, 'a clip being triggered is not an edit');
  for (let i = 0; i < 45; i++) { st2.comp.bpm = 100 + i; V.save({ auto: true }); } V.save({ label: 'Keep me' });
  const all = V.list('Auto'); assert.strictEqual(all.filter(x => x.auto).length, 40); assert.ok(all.some(x => x.label === 'Keep me'));
  ok('automatic versions only when the show changed (not when clips are triggered), newest 40 kept, named ones always kept');
  console.log('Versions test passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
