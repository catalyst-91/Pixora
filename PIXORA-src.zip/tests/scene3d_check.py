# 3D Scene generator in real Chrome: .glb upload (bad files refused), a lit cube on a transparent background, a background
# colour, texture orientation (glTF UVs) on an unlit textured quad, node animation, and the model's own animated camera.
#   python3 tests/scene3d_check.py [path-to-chrome]
import json, urllib.request, subprocess, os, time, sys, tempfile, signal, math
from playwright.sync_api import sync_playwright
from PIL import Image
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, os.path.join(ROOT, 'tests', 'fixtures', 'gltf')); import make_glb
CHROME = sys.argv[1] if len(sys.argv) > 1 else '/usr/bin/google-chrome'; B = 'http://127.0.0.1:8981'; tmp = tempfile.mkdtemp(); SHOT = os.environ.get('PX_SHOT_DIR', tmp)
srv = subprocess.Popen(['node', 'server.js'], cwd=ROOT, env=dict(os.environ, PORT='8981', OSC_PORT='8982', DATA_DIR=tmp + '/d', MEDIA_DIR=tmp + '/m'), stdout=open(tmp + '/log', 'w'), stderr=subprocess.STDOUT)
def req(p, body=None, raw=None, method=None):
  r = urllib.request.Request(B + p, data=raw if raw is not None else (json.dumps(body).encode() if body is not None else None), method=method, headers={'Content-Type': 'application/json'})
  try: return json.loads(urllib.request.urlopen(r).read() or b'{}')
  except urllib.error.HTTPError as e: return {'status': e.code, **json.loads(e.read() or b'{}')}
for _ in range(60):
  try: req('/api/info'); break
  except Exception: time.sleep(0.2)
cmd = lambda c: req('/api/cmd', c); ok = lambda m: print('✓ ' + m)
try:
  assert req('/api/models?name=x.glb', raw=b'not a model', method='POST').get('status') == 400
  assert 'separate' in req('/api/models?name=x.gltf', raw=json.dumps({'asset': {'version': '2.0'}, 'buffers': [{'uri': 'x.bin', 'byteLength': 4}]}).encode(), method='POST').get('error', '')
  cube = req('/api/models?name=Cube.glb', raw=make_glb.animated_cube(), method='POST')['model']; quad = req('/api/models?name=Quad.glb', raw=make_glb.textured_quad(), method='POST')['model']
  assert len(req('/api/state')['models']) == 2; ok('upload .glb; non-glTF and .gltf with external files refused')
  for k, v in [('comp.width', 640), ('comp.height', 360)]: cmd({'op': 'set', 'path': k, 'value': v})
  base = {'camMode': 0, 'spin': 0, 'orbit': 0, 'elev': 0, 'dist': 2.4, 'fov': 40, 'scale': 1, 'rotate': 0, 'animSpeed': 0, 'bounce': 0, 'camIndex': 0, 'light': 1.2, 'lightColor': '#ffffff', 'lightAz': 0, 'lightEl': 0, 'ambient': 0.35, 'tint': '#ffffff', 'bgOn': 0, 'bg': '#000000'}
  clip = lambda model, **kw: {'type': 'gen', 'name': '3D', 'gen': {'kind': 'scene3d', 'params': dict(base, model=model, **kw)}}
  cmd({'op': 'assign', 'layer': 0, 'slot': 0, 'clip': clip(cube['id'])}); cmd({'op': 'trigger', 'layer': 0, 'clip': 0})
  with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=['--use-gl=swiftshader', '--enable-unsafe-swiftshader']); pg = b.new_page(viewport={'width': 640, 'height': 360}); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(B + '/clean?out=main&fs=0'); time.sleep(1); pg.mouse.click(320, 180); time.sleep(2)
    def shot(n): pg.screenshot(path=f'{SHOT}/{n}.png'); return Image.open(f'{SHOT}/{n}.png').convert('RGB')
    im = shot('s3d-cube'); c, corner = im.getpixel((320, 180)), im.getpixel((10, 10))
    st = pg.evaluate("() => { const s = engine.layers[0].cur; return s && s.s3d && { state: s.s3d.state, error: s.s3d.error, tris: s.s3d.tris } }")
    assert c[0] > 150 and c[0] - c[1] > 100 and c[0] - c[2] > 100 and corner == (0, 0, 0), (c, corner, st); assert st['tris'] == 12, st
    ok(f'lit red cube in the middle {c}, transparent around it {corner}; 12 triangles')
    cmd({'op': 'set', 'path': 'layers.0.clips.0.gen.params.bgOn', 'value': 1}); cmd({'op': 'set', 'path': 'layers.0.clips.0.gen.params.bg', 'value': '#0000ff'}); time.sleep(0.8)
    corner = shot('s3d-bg').getpixel((10, 10)); assert corner[2] > 200 and corner[0] < 30, corner; ok('background colour')
    cmd({'op': 'set', 'path': 'layers.0.clips.0.gen.params.bgOn', 'value': 0}); cmd({'op': 'set', 'path': 'layers.0.clips.0.gen.params.animSpeed', 'value': 1}); time.sleep(0.3)
    xs = []
    for k in range(4):
      im = shot(f's3d-anim{k}'); row = [x for x in range(0, 640, 4) if im.getpixel((x, 180))[0] > 120]; xs.append(sum(row) / len(row) if row else -1); time.sleep(0.45)
    assert max(xs) - min(xs) > 60, xs; ok(f'node animation moves the cube (centre x over time {[round(x) for x in xs]})')
    cmd({'op': 'set', 'path': 'layers.0.clips.0.gen.params.animSpeed', 'value': 0}); cmd({'op': 'set', 'path': 'layers.0.clips.0.gen.params.camMode', 'value': 1}); time.sleep(0.8)
    im = shot('s3d-cam'); w1 = sum(1 for x in range(0, 640, 2) if im.getpixel((x, 180))[0] > 120)
    cmd({'op': 'set', 'path': 'layers.0.clips.0.gen.params.camMode', 'value': 0}); time.sleep(0.8); im2 = shot('s3d-orbit'); w2 = sum(1 for x in range(0, 640, 2) if im2.getpixel((x, 180))[0] > 120)
    assert w1 > 10 and abs(w1 - w2) > 5, (w1, w2); ok(f'the model\'s own camera frames the cube differently from the orbit camera ({w1} vs {w2} px wide)')
    for k, v in [('orbit', 35), ('elev', 25), ('lightAz', -45), ('lightEl', 50), ('light', 1), ('ambient', 0.25)]: cmd({'op': 'set', 'path': 'layers.0.clips.0.gen.params.' + k, 'value': v})
    time.sleep(0.8); im = shot('s3d-34'); reds = sorted({sum(im.getpixel((x, y))) // 25 for x in range(200, 440, 10) for y in range(80, 300, 10) if im.getpixel((x, y))[0] > 40})
    assert len(reds) >= 3, reds; ok(f'three-quarter view: faces shaded differently by the key light ({len(reds)} brightness levels)')
    cmd({'op': 'assign', 'layer': 0, 'slot': 1, 'clip': clip(quad['id'], dist=1.4)}); cmd({'op': 'trigger', 'layer': 0, 'clip': 1}); time.sleep(2)
    im = shot('s3d-tex'); L, R, T = im.getpixel((250, 200)), im.getpixel((390, 200)), im.getpixel((320, 12))
    assert L[0] > 200 and L[1] > 150 and L[2] < 80 and R[2] > 200 and R[0] < 60, (L, R); assert min(T) > 200, T
    ok(f'texture the right way round: yellow left {L}, blue right {R}, white strip at the top {T}')
    # virtual production: tracked camera, one wall, the cube 2 m behind it; walking right moves the cube right on the wall (parallax)
    cmd({'op': 'set', 'path': 'vp.walls', 'value': [{'id': 'w1', 'name': 'Back', 'cx': 0, 'cy': 1, 'cz': 0, 'w': 4, 'h': 2.25, 'yaw': 0, 'pitch': 0, 'rx': 0, 'ry': 0, 'rw': 640, 'rh': 360}]})
    cmd({'op': 'set', 'path': 'vp.scene', 'value': {'x': 1, 'y': 1, 'z': -3}}); cmd({'op': 'set', 'path': 'vp.sim', 'value': True})
    cmd({'op': 'assign', 'layer': 0, 'slot': 2, 'clip': clip(cube['id'], camMode=2, scale=0.5)}); cmd({'op': 'trigger', 'layer': 0, 'clip': 2})
    xs = []
    for ex in (-2000, 0, 2000):
      cmd({'op': 'set', 'path': 'vp.simPose', 'value': {'x': ex, 'y': -6000, 'z': 1000}}); time.sleep(0.9); im = shot(f's3d-vp{ex}')
      row = [x for x in range(0, 640, 2) if im.getpixel((x, 180))[0] > 100]; xs.append(sum(row) / len(row) if row else None)
    st = pg.evaluate("() => { const s = engine.layers[0].cur; return s && s.s3d && { walls: s.s3d.walls, eye: s.s3d.eye } }")
    assert all(x is not None for x in xs) and xs[0] < xs[1] < xs[2] and xs[2] - xs[0] > 60 and abs(xs[1] - 320) < 12, (xs, st)
    ok(f'virtual production: off-axis wall view from the tracked camera — cube centre x {[round(x) for x in xs]} as the camera walks left → right (parallax)')
    # inner frustum: the camera's view of the wall stays, outside goes black; pan moves it; the lens table changes its width
    cmd({'op': 'set', 'path': 'layers.0.clips.2.gen.params.bgOn', 'value': 1}); cmd({'op': 'set', 'path': 'layers.0.clips.2.gen.params.bg', 'value': '#ffffff'})
    cmd({'op': 'set', 'path': 'vp.inner', 'value': {'mode': 'black', 'margin': 0, 'softness': 0.001, 'dim': 0.3, 'color': '#000000'}}); cmd({'op': 'set', 'path': 'vp.fov', 'value': 20})
    def lit(pan=0, zoom=0):
      cmd({'op': 'set', 'path': 'vp.simPose', 'value': {'x': 0, 'y': -6000, 'z': 1000, 'pan': pan, 'tilt': 0, 'zoom': zoom}}); time.sleep(0.9); im = shot('s3d-inner')
      row = [x for x in range(0, 640, 2) if sum(im.getpixel((x, 180))) > 600]; return (min(row), max(row)) if row else None
    a = lit(); expect = 640 / 4 * 6 * math.tan(math.radians(10))   # half-width in px: wall 4 m = 640 px, 6 m away, 10° half angle
    assert a and abs((a[1] - a[0]) / 2 - expect) < 14 and abs((a[0] + a[1]) / 2 - 320) < 8, (a, expect); ok(f'inner frustum 20° from 6 m: lit {a} on a 4 m wall (expected ±{expect:.0f} px)')
    b2 = lit(pan=8); assert b2[0] > a[0] + 60, (a, b2); ok(f'pan 8° right moves the frustum right {b2}')
    cmd({'op': 'set', 'path': 'vp.lens', 'value': [{'zoom': 0, 'fov': 10}, {'zoom': 1000, 'fov': 30}]}); c = lit(zoom=500); assert abs((c[1] - c[0]) - (a[1] - a[0])) < 12, (a, c); ok(f'lens table: zoom 500 → 20° (interpolated) {c}')
    cmd({'op': 'set', 'path': 'vp.inner.mode', 'value': 'off'}); time.sleep(0.8); assert lit() == (0, 638), lit(); ok('frustum off: the whole wall shows the scene')
    assert not errs, errs; b.close()
  print('3D scene check passed')
finally: srv.send_signal(signal.SIGTERM)
