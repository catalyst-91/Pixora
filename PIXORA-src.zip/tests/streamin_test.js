// Stream inputs: SRT listener and caller, RTMP receive (OBS-style push), HLS pull; one ffmpeg shared by every viewer, live
// fragmented MP4 (init + keyframe-aligned fragments), codecs reported for the player, reconnect after the sender drops,
// non-H.264 re-encoded automatically, unsafe URLs refused.   node tests/streamin_test.js   (needs ffmpeg with SRT)
const { spawn, spawnSync } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), http = require('http'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill('SIGTERM'); } catch {} }));
const SI = require('../server-streamin.js');
(async () => {
  if (!/\bsrt\b/.test(spawnSync('ffmpeg', ['-hide_banner', '-protocols']).stdout || '')) { console.log('ffmpeg without SRT — skipped'); process.exit(0); }
  // pure: box parser + codec string
  const box = (t, body) => { const b = Buffer.alloc(8 + body.length); b.writeUInt32BE(8 + body.length); b.write(t, 4, 'latin1'); body.copy(b, 8); return b; };
  const avcC = Buffer.concat([Buffer.from('avcC', 'latin1'), Buffer.from([1, 0x64, 0x00, 0x28])]);
  const bx = SI({}).boxes(Buffer.concat([box('ftyp', Buffer.alloc(4)), box('moov', avcC), box('moof', Buffer.alloc(2)).subarray(0, 6)]));
  assert.deepStrictEqual(bx.list.map(b => b.type), ['ftyp', 'moov']); assert.strictEqual(bx.used, 12 + 16);
  assert.strictEqual(SI({}).codecsFromInit(box('moov', Buffer.concat([avcC, Buffer.from('mp4a', 'latin1')]))), 'avc1.640028,mp4a.40.2');
  ok('MP4 box splitting (partial boxes wait) and codec strings from the moov');

  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxsi-')), MEDIA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxsim-'));
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8925, OSC_PORT: 8926, DATA_DIR: DATA, MEDIA_DIR: MEDIA }, stdio: 'ignore' }); kids.push(srv);
  const B = 'http://127.0.0.1:8925'; for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const q = (url, extra = '') => `url=${encodeURIComponent(url)}${extra}`;
  const send = (dest, fmt, extra = []) => { const k = spawn('ffmpeg', ['-v', 'error', '-re', '-f', 'lavfi', '-i', 'testsrc=size=320x180:rate=30', '-f', 'lavfi', '-i', 'sine=f=440', ...extra, '-g', '30', '-c:a', 'aac', '-f', fmt, dest], { stdio: 'ignore' }); kids.push(k); return k; };
  const watch = async (url, ms = 2500, extra = '') => { const ctl = new AbortController(); const r = await fetch(`${B}/api/streamin/live?${q(url, extra)}`, { signal: ctl.signal }); const rd = r.body.getReader(); const chunks = []; const t0 = Date.now();
    try { while (Date.now() - t0 < ms) { const x = await Promise.race([rd.read(), tick(ms).then(() => ({ done: true }))]); if (x.done) break; chunks.push(Buffer.from(x.value)); } } catch {} ctl.abort(); const all = Buffer.concat(chunks); return { all, types: SI({}).boxes(all).list.map(b => b.type) }; };
  // SRT listener: PIXORA waits, a sender calls in
  const srtL = 'srt://0.0.0.0:9101?mode=listener&latency=120000';
  let info = await fetch(`${B}/api/streamin/info?${q(srtL, '&wait=600')}`).then(r => r.json()); assert.ok(!info.mime && ['connecting', 'reconnecting'].includes(info.status), JSON.stringify(info));
  let tx = send('srt://127.0.0.1:9101?mode=caller', 'mpegts', ['-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p']);
  info = await fetch(`${B}/api/streamin/info?${q(srtL, '&wait=10000')}`).then(r => r.json());
  assert.ok(/^video\/mp4; codecs="avc1\.(42|4d|64)[0-9a-f]{4},mp4a\.40\.2"$/.test(info.mime), JSON.stringify(info));
  const [w1, w2] = await Promise.all([watch(srtL), watch(srtL)]);
  for (const w of [w1, w2]) { assert.deepStrictEqual(w.types.slice(0, 2), ['ftyp', 'moov']); assert.ok(w.types.filter(t => t === 'moof').length >= 2 && w.types.includes('mdat'), w.types.join(',')); }
  let list = await fetch(B + '/api/streamin/list').then(r => r.json()); assert.strictEqual(list.inputs.length, 1, 'one ffmpeg for both viewers'); assert.ok(list.inputs[0].live && list.inputs[0].mode === 'auto', 'H.264 4:2:0 passes straight through');
  ok(`SRT listener: sender calls in → ${info.mime}; two viewers share one ffmpeg, each gets init + live fragments`);
  // sender drops → reconnecting → comes back
  tx.kill('SIGKILL'); for (let i = 0; i < 40; i++) { list = await fetch(B + '/api/streamin/list').then(r => r.json()); if (!list.inputs[0].live) break; await tick(250); }
  assert.ok(!list.inputs[0].live, 'drop noticed'); tx = send('srt://127.0.0.1:9101?mode=caller', 'mpegts', ['-c:v', 'libx264', '-preset', 'ultrafast']);
  const w3 = await watch(srtL, 6000); assert.ok(w3.types.includes('moov') && w3.types.includes('mdat'), w3.types.join(',')); tx.kill('SIGKILL');
  ok('the sender drops and calls back: PIXORA listens again and the picture returns');
  // RTMP receive (OBS pushes to PIXORA)
  const rtmpL = 'rtmp://0.0.0.0:19350/live/show?listen=1';
  await fetch(`${B}/api/streamin/info?${q(rtmpL, '&wait=500')}`); await tick(1200); tx = send('rtmp://127.0.0.1:19350/live/show', 'flv', ['-c:v', 'libx264', '-preset', 'ultrafast']);
  for (let i = 0; i < 30; i++) { const x = await fetch(`${B}/api/streamin/info?${q(rtmpL, '&wait=2000')}`).then(r => r.json()); if (x.mode === 'encode' && x.mime) break; await tick(300); }
  const r1 = await watch(rtmpL, 3500); assert.ok(r1.types.includes('moov') && r1.types.filter(t => t === 'mdat').length >= 2, r1.types.join(','));
  list = await fetch(B + '/api/streamin/list').then(r => r.json()); const rin = list.inputs.find(x => /RTMP/.test(x.label)); assert.ok(rin.mode === 'encode' && /avc1\.(42|4d|64)/.test(rin.codecs), JSON.stringify(rin)); tx.kill('SIGKILL');
  ok('RTMP receive: an encoder pushes rtmp://host:port/live/<key> straight into PIXORA (its H.264 4:4:4 is re-encoded to a profile browsers play)');
  // HLS pull from a local web server; HEVC video so "auto" has to re-encode
  const hdir = fs.mkdtempSync(path.join(os.tmpdir(), 'pxhls-'));
  const mkHls = vc => spawnSync('ffmpeg', ['-v', 'error', '-y', '-f', 'lavfi', '-i', 'testsrc=size=320x180:rate=25:d=8', '-f', 'lavfi', '-i', 'sine=d=8', ...vc, '-c:a', 'aac', '-f', 'hls', '-hls_time', '2', '-hls_list_size', '0', path.join(hdir, 'x.m3u8')]);
  let made = mkHls(['-c:v', 'libx265', '-preset', 'ultrafast', '-tag:v', 'hvc1', '-x265-params', 'log-level=error']); // one keyframe at the very start: the server has to begin again from the top // HEVC: browsers' MSE can't take it → the server must re-encode
  if (made.status !== 0 || !fs.existsSync(path.join(hdir, 'x.m3u8'))) made = mkHls(['-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv444p']); // ffmpeg without x265: H.264 4:4:4 needs re-encoding too
  assert.strictEqual(made.status, 0, 'HLS fixture: ' + String(made.stderr));
  const hreq = []; const hs = http.createServer((req, res) => { hreq.push(req.url); const f = path.join(hdir, path.basename(req.url.split('?')[0]));
    if (!fs.existsSync(f)) { res.statusCode = 404; return res.end(); } res.setHeader('Content-Type', f.endsWith('.m3u8') ? 'application/vnd.apple.mpegurl' : 'video/mp2t'); fs.createReadStream(f).pipe(res); }).listen(8927);
  const hls = 'http://127.0.0.1:8927/x.m3u8'; info = await fetch(`${B}/api/streamin/info?${q(hls, '&wait=15000')}`).then(r => r.json());
  if (!(/avc1/.test(info.mime) && info.mode === 'encode')) { const l = await fetch(B + '/api/streamin/list').then(r => r.json()); assert.fail(JSON.stringify({ info, list: l.inputs, requests: hreq.slice(-12), files: fs.readdirSync(hdir) })); } hs.close();
  ok('HLS pull; a non-H.264 stream (HEVC) is re-encoded automatically so browsers can play it');
  // unsafe URLs
  for (const bad of ['file:///etc/passwd', 'concat:/etc/passwd', '/etc/passwd', 'pipe:0']) { const r = await fetch(`${B}/api/streamin/info?${q(bad)}`); assert.strictEqual(r.status, 400, bad); }
  ok('file:, concat:, pipe: and bare paths are refused');
  console.log('Stream input test passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
