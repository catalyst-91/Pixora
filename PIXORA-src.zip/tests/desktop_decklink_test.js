// Desktop DeckLink test: runs desktop/main.js against mocked Electron with the REAL PIXORA DeckLink module and a fake
// Desktop Video driver (libDeckLinkAPI.so that simulates a DeckLink Duo 2). Checks the controller API, SDI out from an
// output window (scaled to the video mode), the "no window" off-screen output, and SDI capture frames for layers.
//   LD_LIBRARY_PATH=/path/to/fake-driver PIXORA_DECKLINK_ADDON=/path/to/pixora_decklink.node node tests/desktop_decklink_test.js
const Module = require('module'), path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert'), EventEmitter = require('events');
const DESK = path.join(__dirname, '..', 'desktop'); const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'pxdl-')); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const ipcHandlers = {}, ipcOn = {}, wins = [], log = [];
class WebContents extends EventEmitter { constructor() { super(); this.sent = []; } executeJavaScript() { return Promise.resolve(); } isFocused() { return false; } setWindowOpenHandler(f) { this.openHandler = f; } beginFrameSubscription(_o, cb) { this.frameCb = cb; } endFrameSubscription() { this.frameCb = null; } setFrameRate(f) { this.fps = f; } setAudioMuted() {} send(ch, m) { this.sent.push([ch, m]); } isDestroyed() { return false; } toggleDevTools() {} reload() {} }
class BrowserWindow extends EventEmitter { constructor(o) { super(); this.opts = o; this.webContents = new WebContents(); this.destroyed = false; wins.push(this); } loadURL(u) { this.url = u; setTimeout(() => this.emit('ready-to-show'), 5); } show() {} setBounds() {} getBounds() { return { x: 0, y: 0, width: 800, height: 600 }; } isMaximized() { return false; } maximize() {} isFullScreen() { return false; } setMenuBarVisibility() {} focus() {} isDestroyed() { return this.destroyed; } destroy() { this.destroyed = true; this.emit('closed'); } close() { this.destroy(); } reload() {} }
const image = (w, h, bgra) => ({ getSize: () => ({ width: w, height: h }), toBitmap: () => { const b = Buffer.alloc(w * h * 4); for (let i = 0; i < b.length; i += 4) b.set(bgra, i); return b; }, resize: ({ width, height }) => image(width, height, bgra) });
const electron = {
  app: { getVersion: () => '1.5.0', isPackaged: false, addRecentDocument() {}, clearRecentDocuments() {}, getAppPath: () => DESK, commandLine: { appendSwitch() {} }, requestSingleInstanceLock: () => true, quit() {}, getPath: k => path.join(tmp, k), whenReady: () => Promise.resolve(), on() {}, setLoginItemSettings() {} },
  BrowserWindow, Tray: class { setToolTip() {} on() {} setContextMenu() {} }, Menu: { buildFromTemplate: t => t, setApplicationMenu() {} }, Notification: class { show() {} static isSupported() { return false; } },
  screen: { getAllDisplays: () => [{ id: 1, label: 'Built-in', bounds: { x: 0, y: 0, width: 1920, height: 1080 }, size: { width: 1920, height: 1080 } }], getPrimaryDisplay: () => ({ id: 1, bounds: { x: 0, y: 0, width: 1920, height: 1080 } }), on() {} },
  powerSaveBlocker: { start: () => 1, stop() {} }, nativeImage: { createFromPath: () => ({ resize: () => ({}) }) },
  dialog: { showMessageBox: o => { log.push('msgbox ' + o.message); return Promise.resolve({}); }, showErrorBox: (a, b) => log.push('errbox ' + a + ' ' + b) }, shell: { openPath() {}, openExternal() {} },
  ipcMain: { on: (c, f) => ipcOn[c] = f, handle: (c, f) => ipcHandlers[c] = f },
};
const realCP = require('child_process'), realLoad = Module._load;
Module._load = function (req) { if (req === 'electron') return electron; if (req === 'child_process') return { ...realCP, fork: () => { const e = new EventEmitter(); e.kill = () => {}; return e; } }; return realLoad.apply(this, arguments); };
const http = require('http');
const genlockPosts = [];
const srv = http.createServer((q, r) => { if (q.url === '/api/native/genlock') { let b = ''; q.on('data', d => b += d); q.on('end', () => { try { genlockPosts.push(JSON.parse(b)); } catch {} r.end('{}'); }); return; } r.setHeader('content-type', 'application/json'); r.end(q.url.startsWith('/api/state') ? JSON.stringify({ outputs: [{ id: 'main', name: 'Main' }, { id: 'led', name: 'LED wall' }], comp: { w: 1920, h: 1080 } }) : '{}'); });
(async () => {
  await new Promise(r => srv.listen(0, r)); process.env.PORT = srv.address().port; try { fs.unlinkSync('/tmp/dlfake/out.bin'); } catch {}
  require(path.join(DESK, 'main.js')); await tick(400);
  let st = await ipcHandlers['native-decklink-state']();
  assert.strictEqual(st.available, true, st.error); assert.strictEqual(st.devices[0].name, 'DeckLink Duo 2 (1)'); assert.ok(st.devices[0].outputModes.some(m => m.id === '1080i59.94'));
  ok(`controller sees "${st.devices[0].name}" with output modes ${st.devices[0].outputModes.map(m => m.id).join(', ')}`);

  // SDI out from a visible output window: 1280×720 frames scaled to 1080p50
  const ctl = wins.find(w => w.url && w.url.endsWith('/')); ctl.webContents.openHandler({ url: `http://localhost:${process.env.PORT}/output?out=led` }); await tick(50);
  const out = wins.find(w => /out=led/.test(w.url || ''));
  await ipcHandlers['native-decklink-set']({}, { outId: 'led', decklink: { index: 0, mode: '1080p50' } });
  assert.ok(out.webContents.frameCb, 'frame subscription active');
  out.webContents.frameCb(image(1280, 720, [10, 200, 30, 255])); await tick(20);
  const got = fs.readFileSync('/tmp/dlfake/out.bin'); assert.strictEqual(got.length, 1920 * 1080 * 4); assert.deepStrictEqual([...got.subarray(0, 4)], [10, 200, 30, 255]);
  st = await ipcHandlers['native-decklink-state'](); assert.strictEqual(st.outputs.led.running, true); assert.strictEqual(st.outputs.led.frames, 1);
  ok('output window → DeckLink at 1080p50 (1280×720 frame scaled to 1920×1080), shown in the controller as on air');

  // "no window": off-screen output sized to the video mode
  await ipcHandlers['native-decklink-set']({}, { outId: 'main', decklink: { index: 0, mode: '720p50' }, only: true }); await tick(100);
  const off = wins.find(w => w.opts.webPreferences && w.opts.webPreferences.offscreen && /out=main/.test(w.url || ''));
  assert.ok(off, 'off-screen window'); assert.deepStrictEqual([off.opts.width, off.opts.height], [1280, 720]); ok('"no window" output renders off-screen at 1280×720 for 720p50 — no display needed');
  await ipcHandlers['native-decklink-set']({}, { outId: 'main', decklink: null }); await tick(20); assert.ok(off.destroyed, 'off-screen window closed when DeckLink is turned off'); ok('turning DeckLink off closes the off-screen output');

  // capture for a layer: frames arrive as native-frame BGRA, shared between windows
  const a = new WebContents(), b = new WebContents(); const ea = { sender: a }, eb = { sender: b };
  ipcOn['native-open-decklink'](ea, { index: 0 }); ipcOn['native-open-decklink'](eb, { index: 0 });
  for (let i = 0; i < 50 && !(a.sent.some(s => s[1].width === 1280) && b.sent.length); i++) await tick(40);
  const fa = a.sent.filter(s => s[0] === 'native-frame').pop()[1];
  assert.strictEqual(fa.fmt, 'bgra'); assert.strictEqual(fa.id, ea.returnValue); assert.ok(b.sent.length > 0, 'second window gets frames too');
  st = await ipcHandlers['native-decklink-state'](); assert.strictEqual(st.inputs.length, 1); assert.strictEqual(st.inputs[0].mode, '720p50');
  ok(`SDI capture → layers: ${fa.width}×${fa.height} BGRA frames to two output windows from one input (${st.inputs[0].mode})`);
  ipcOn['native-close']({ sender: a }, { id: ea.returnValue }); ipcOn['native-close']({ sender: b }, { id: eb.returnValue }); await tick(30);
  st = await ipcHandlers['native-decklink-state'](); assert.strictEqual(st.inputs.length, 0); ok('input released when the last layer closes it');
  // genlock: scheduled playback on the card's reference clock, renderer told to render ahead, status to controller + server
  try { fs.unlinkSync('/tmp/dlfake/sched.log'); } catch {}
  const js = []; out.webContents.executeJavaScript = code => { js.push(code); return Promise.resolve(); };
  await ipcHandlers['native-decklink-set']({}, { outId: 'led', decklink: { index: 0, mode: '1080p50', genlock: true, preroll: 3 } }); await tick(30);
  const g = js.map(c => /PXGenlock = (.*);/.exec(c)).filter(Boolean).pop(); assert.ok(g, 'renderer told about genlock'); const gl = JSON.parse(g[1]); assert.strictEqual(gl.fps, 50); assert.strictEqual(gl.lead, 80);
  for (let i = 0; i < 60; i++) { out.webContents.frameCb(image(1920, 1080, [i, 0, 0, 255])); await tick(17); }
  st = await ipcHandlers['native-decklink-state'](); await tick(1100); st = await ipcHandlers['native-decklink-state']();
  const so = st.outputs.led; assert.strictEqual(so.genlock, true); assert.strictEqual(so.scheduled, true); assert.ok(so.status && so.status.started, 'scheduled playback started');
  assert.strictEqual(so.status.referenceLocked, process.env.FAKE_REF === '1');
  const shown = fs.readFileSync('/tmp/dlfake/sched.log', 'utf8').trim().split('\n').map(l => +l.split(' ')[0]); let gaps = 0; for (let i = 1; i < shown.length; i++) { assert.ok(shown[i] > shown[i - 1], 'in order'); if (shown[i] !== shown[i - 1] + 1) gaps++; } assert.ok(shown.length >= 30, 'pictures shown: ' + shown.length); // (the test builds each 1080p picture in JS, slower than the card's 50 fps: the card holds the last picture on the frames between)
  assert.ok(genlockPosts.length && genlockPosts[genlockPosts.length - 1].outputs[0].outId === 'led', 'genlock status posted to the server');
  ok(`genlock: frames queued and played in order on ${shown.length} card frames (the card holds the last picture when the source is slower); renderer renders ${gl.lead} ms ahead on frame boundaries; reference ${so.status.referenceLocked ? 'locked (' + so.status.reference + ')' : 'not connected'} reported to the server`);
  assert.ok(!log.some(l => l.startsWith('errbox')), log.join('\n'));
  console.log('\nDesktop DeckLink test passed.'); process.exit(0);
})().catch(e => { console.error('✗', e, log); process.exit(1); });
