// LED processor setup pack: port planning along each screen's data chain, by pixel capacity or cabinet limit; CSV / SVG / sheet.
//   node tests/ledsetup_test.js
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert'), zlib = require('zlib');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
function unzip(buf) { const out = {}; let e = buf.length - 22; while (e > 0 && buf.readUInt32LE(e) !== 0x06054b50) e--; let p = buf.readUInt32LE(e + 16); const n = buf.readUInt16LE(e + 10);
  for (let i = 0; i < n; i++) { const m = buf.readUInt16LE(p + 10), cs = buf.readUInt32LE(p + 20), nl = buf.readUInt16LE(p + 28), xl = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), lo = buf.readUInt32LE(p + 42);
    const name = buf.slice(p + 46, p + 46 + nl).toString(); const ds = lo + 30 + buf.readUInt16LE(lo + 26) + buf.readUInt16LE(lo + 28); const raw = buf.slice(ds, ds + cs); out[name] = m === 8 ? zlib.inflateRawSync(raw) : raw; p += 46 + nl + xl + cl; } return out; }
(async () => {
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8836, OSC_PORT: 8837, DATA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxls-')), MEDIA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxlsm-')) }, stdio: 'ignore' }); kids.push(srv);
  const B = 'http://127.0.0.1:8836';
  for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const cmd = c => fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(c) });
  // screen A: 4×2 cabinets of 500×500 px (250k px each), snake by rows from bottom-left; screen B: 3×1 of 256×256, rows from top-right
  await cmd({ op: 'ledAddScreen', screen: { name: 'Main', panelW: 500, panelH: 500, panelMmW: 500, panelMmH: 500, cols: 4, rows: 2, x: 0, y: 0, outX: 0, outY: 0, chain: 'snake-rows', start: 'bl' } });
  await cmd({ op: 'ledAddScreen', screen: { name: 'Side', panelW: 256, panelH: 256, cols: 3, rows: 1, x: 2000, y: 0, outX: 2000, outY: 0, chain: 'rows', start: 'tr' } });
  await cmd({ op: 'set', path: 'led.processor', value: 'brompton-s4' }); await tick(200); // 4 ports, 525k px each
  let P = await fetch(B + '/api/led/setup-plan').then(r => r.json());
  assert.strictEqual(P.processor.name, 'Brompton Tessera S4'); assert.strictEqual(P.perPort, 525000);
  const main = P.cabinets.filter(c => c.screen === 'Main');
  assert.deepStrictEqual(main.map(c => [c.col, c.row]), [[1, 2], [2, 2], [3, 2], [4, 2], [4, 1], [3, 1], [2, 1], [1, 1]], 'snake from bottom-left');
  assert.deepStrictEqual(main.map(c => `P${c.port}.${c.onPort}`), ['P1.1', 'P1.2', 'P2.1', 'P2.2', 'P3.1', 'P3.2', 'P4.1', 'P4.2'], '2 × 250k px per 525k port');
  assert.deepStrictEqual(main.find(c => c.col === 3 && c.row === 1), { screen: 'Main', screenId: main[0].screenId, col: 3, row: 1, x: 1000, y: 0, w: 500, h: 500, mmX: 1000, mmY: 0, port: 3, onPort: 2, chainIndex: 6 });
  ok('Main: snake by rows from bottom-left; 2 cabinets (500 k px) per 525 k-px port; raster x/y per cabinet');
  const side = P.cabinets.filter(c => c.screen === 'Side'); assert.deepStrictEqual(side.map(c => [c.col, c.x, c.port, c.onPort]), [[3, 2512, 5, 1], [2, 2256, 5, 2], [1, 2000, 5, 3]]); ok('Side: rows from top-right; a new screen starts a new port (P5)');
  assert.ok(P.warnings.some(w => /5 ports needed — the Brompton Tessera S4 has 4/.test(w))); ok('warns when the processor runs out of ports');
  assert.deepStrictEqual([P.raster.w, P.raster.h], [2768, 1000]);
  P = await fetch(B + '/api/led/setup-plan?maxCabinets=1').then(r => r.json()); assert.strictEqual(P.ports.length, 11); ok('max cabinets per port: 1 → 11 ports');
  // the pack
  const z = unzip(Buffer.from(await (await fetch(B + '/api/led/setup-pack')).arrayBuffer()));
  for (const f of ['README.txt', 'setup-sheet.html', 'screens.csv', 'cabinets.csv', 'ports.csv', 'layout.json', 'overview.svg', 'Main-cabling.svg', 'Side-cabling.svg']) assert.ok(z[f], f);
  const cab = z['cabinets.csv'].toString().trim().split('\r\n'); assert.strictEqual(cab.length, 12); assert.strictEqual(cab[0], 'screen,col,row,raster_x,raster_y,width_px,height_px,x_mm,y_mm,port,position_on_port,chain_index');
  assert.strictEqual(cab[1], 'Main,1,2,0,500,500,500,0,500,1,1,1');
  assert.ok(/Port  5  Side .* 3 cabinets/.test(z['README.txt'].toString())); assert.ok(z['setup-sheet.html'].toString().includes('<svg') && z['Main-cabling.svg'].toString().includes('P3·2'));
  ok('pack: README, printable sheet, screens / cabinets / ports CSV, layout.json and a cabling SVG per screen');
  console.log('ledsetup_test: all passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
