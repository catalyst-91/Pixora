"""Structural check of PIXORA's GDTF description.xml against the GDTF 1.1/1.2 rules
(node order, required attributes, reference resolution, DMX offset collisions,
InitialFunction resolution, one-attribute-per-geometry). Usage: gdtf_check.py file.gdtf"""
import sys, zipfile, re
from lxml import etree

errs = []
def err(m): errs.append(m)

z = zipfile.ZipFile(sys.argv[1])
assert 'description.xml' in z.namelist(), 'description.xml missing at zip root'
root = etree.fromstring(z.read('description.xml'))
if root.tag != 'GDTF': err('root must be GDTF')
if root.get('DataVersion') not in ('1.0', '1.1', '1.2'): err('bad DataVersion')
ft = root.find('FixtureType')
for a in ('Name', 'ShortName', 'LongName', 'Manufacturer', 'Description', 'FixtureTypeID'):
    if ft.get(a) is None: err(f'FixtureType missing {a}')
if not re.fullmatch(r'[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}', ft.get('FixtureTypeID', ''), re.I): err('FixtureTypeID not a GUID')

order = ['AttributeDefinitions', 'Wheels', 'PhysicalDescriptions', 'Models', 'Geometries', 'DMXModes', 'Revisions', 'FTPresets', 'Protocols']
kids = [c.tag for c in ft]
idx = [order.index(k) if k in order else err(f'unknown FixtureType child {k}') for k in kids]
if idx != sorted(i for i in idx if i is not None): err(f'FixtureType children out of order: {kids}')
for req in ('AttributeDefinitions', 'Geometries', 'DMXModes'):
    if req not in kids: err(f'missing {req}')

ad = ft.find('AttributeDefinitions')
if [c.tag for c in ad] != [t for t in ('ActivationGroups', 'FeatureGroups', 'Attributes') if ad.find(t) is not None]: err('AttributeDefinitions child order')
features = {f'{g.get("Name")}.{f.get("Name")}' for g in ad.find('FeatureGroups') for f in g}
groups = {g.get('Name') for g in ad.find('ActivationGroups')}
attrs = {}
for a in ad.find('Attributes'):
    n = a.get('Name'); attrs[n] = a
    for r in ('Name', 'Pretty', 'Feature'):
        if not a.get(r): err(f'Attribute {n} missing {r}')
    if a.get('Feature') not in features: err(f'Attribute {n} Feature {a.get("Feature")} unresolved')
    if a.get('ActivationGroup') and a.get('ActivationGroup') not in groups: err(f'Attribute {n} ActivationGroup unresolved')

models = {m.get('Name') for m in (ft.find('Models') if ft.find('Models') is not None else [])}
for m in ft.iter('Model'):
    if m.get('PrimitiveType') not in ('Undefined', 'Cube', 'Cylinder', 'Sphere', 'Base', 'Yoke', 'Head', 'Scanner', 'Conventional', 'Pigtail', 'Base1_1', 'Scanner1_1', 'Conventional1_1'): err(f'Model {m.get("Name")} bad PrimitiveType')
geoms = {}
for g in ft.find('Geometries').iter('Geometry'):
    n = g.get('Name')
    if n in geoms: err(f'duplicate Geometry {n}')
    geoms[n] = g
    if g.get('Model') and g.get('Model') not in models: err(f'Geometry {n} Model unresolved')
    if g.get('Position') and not re.fullmatch(r'(\{[-0-9.e]+(,[-0-9.e]+){3}\}){4}', g.get('Position')): err(f'Geometry {n} bad Position')

dmxval = re.compile(r'^\d+/[1-4]$|^None$')
for mode in ft.find('DMXModes'):
    mn = mode.get('Name')
    if not mn or mode.get('Geometry') not in geoms: err(f'DMXMode {mn} Name/Geometry invalid')
    used, pairs, chnames = {}, set(), {}
    for ch in mode.find('DMXChannels'):
        if ch.get('Default') is not None: err(f'{mn}: DMXChannel Default is GDTF 1.0 only (moved to ChannelFunction in 1.1)')
        g = ch.get('Geometry')
        if g not in geoms: err(f'{mn}: channel geometry {g} unresolved')
        for o in (ch.get('Offset') or '').split(','):
            if not o: continue
            key = (ch.get('DMXBreak', '1'), int(o))
            if key in used: err(f'{mn}: offset {o} used twice')
            used[key] = 1
        lcs = ch.findall('LogicalChannel')
        if not lcs: err(f'{mn}: channel without LogicalChannel')
        a = lcs[0].get('Attribute')
        if (g, a) in pairs: err(f'{mn}: attribute {a} used twice in geometry {g}')
        pairs.add((g, a)); cname = f'{g}_{a}'; chnames[cname] = ch
        if ch.get('Highlight') and not dmxval.match(ch.get('Highlight')): err(f'{mn}: bad Highlight')
        for lc in lcs:
            if lc.get('Attribute') not in attrs: err(f'{mn}: LogicalChannel attribute {lc.get("Attribute")} unresolved')
            if lc.get('Snap') not in (None, 'No', 'Yes', 'On', 'Off'): err('bad Snap')
            if lc.get('Master') not in (None, 'None', 'Grand', 'Group'): err('bad Master')
            prev = -1
            for cf in lc.findall('ChannelFunction'):
                if cf.get('Attribute') not in attrs and cf.get('Attribute') != 'NoFeature': err(f'{mn}: ChannelFunction attribute unresolved')
                for k in ('DMXFrom', 'Default'):
                    if cf.get(k) and not dmxval.match(cf.get(k)): err(f'{mn}: bad {k} {cf.get(k)}')
                v = int(cf.get('DMXFrom', '0/1').split('/')[0])
                if v <= prev: err(f'{mn}: ChannelFunctions not ascending')
                prev = v
        init = ch.get('InitialFunction')
        if init:
            p = init.split('.')
            if len(p) != 3 or p[0] != cname or p[1] != a or not any(cf.get('Name') == p[2] for cf in lcs[0].findall('ChannelFunction')):
                err(f'{mn}: InitialFunction {init} does not resolve')
    offs = sorted(o for (_, o) in used)
    if offs and offs != list(range(1, len(offs) + 1)): err(f'{mn}: offsets not contiguous from 1')
    print(f'mode "{mn}": {len(offs)} channels OK' if not errs else f'mode "{mn}" checked')

for r in ft.iter('Revision'):
    if not re.fullmatch(r'\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d', r.get('Date', '')): err('Revision Date format')
print('\n'.join(errs) if errs else 'GDTF structure: PASS')
sys.exit(1 if errs else 0)
