// Expressions (the maths language) and macros (action lists with waits, webhooks, macros calling macros, OSC).
//   node tests/expr_test.js
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), http = require('http'), dgram = require('dgram'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
const X = require('../public/expr.js'); const ev = (s, c) => X.compile(s)(c);
(async () => {
  assert.strictEqual(ev('1 + 2 * 3'), 7); assert.strictEqual(ev('(1 + 2) * 3'), 9); assert.strictEqual(ev('2 ^ 3 ^ 2'), 512); assert.strictEqual(ev('-2 ^ 2'), -4);
  assert.strictEqual(ev('10 % 4'), 2); assert.strictEqual(ev('1 / 0'), 0); assert.strictEqual(ev('3 > 2 ? 5 : 6'), 5); assert.strictEqual(ev('1 && 0 || 1'), 1); assert.strictEqual(ev('!1'), 0);
  assert.strictEqual(ev('clamp(1.5)'), 1); assert.strictEqual(ev('lerp(0, 10, 0.25)'), 2.5); assert.strictEqual(ev('smoothstep(0, 1, 0.5)'), 0.5); assert.ok(Math.abs(ev('sin(pi / 2)') - 1) < 1e-12);
  assert.strictEqual(ev('beat * 2 + value', { beat: 3, value: 1 }), 7); assert.strictEqual(ev('feed("score") + 1', { feed: k => (k === 'score' ? 4 : 0) }), 5); assert.strictEqual(ev('param("a.b") * 2', { param: p => (p === 'a.b' ? 0.5 : 0) }), 1);
  assert.strictEqual(ev('tri(0.25)'), 0.5); assert.ok(ev('noise(1.5)') >= 0 && ev('noise(1.5)') <= 1); assert.strictEqual(ev('rand(3)'), ev('rand(3)'));
  for (const [bad, re] of [['1 +', /end/], ['foo + 1', /unknown name/], ['alert(1)', /unknown function/], ['window', /unknown name/], ['1 ) 2', /unexpected/], ['"abc', /unclosed/], ['constructor', /unknown/], ['a.b', /unknown|unexpected/]]) assert.throws(() => X.compile(bad), re, bad);
  assert.strictEqual(ev('"x"'), 0, 'non-numbers become 0'); assert.ok(X.get('1 +').error && X.get('1 + 1').fn);
  ok('expressions: precedence (^ right-assoc, unary minus), safe division, ternary / logic, functions, variables, feed() and param(); unknown names, JS globals and bad syntax are refused with a position');

  // macros + webhooks on the server
  const hits = []; const hs = http.createServer((req, res) => { let b = ''; req.on('data', d => b += d); req.on('end', () => { hits.push({ m: req.method, u: req.url, b, t: Date.now(), ct: req.headers['content-type'] }); res.end('ok'); }); }).listen(9031);
  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxe-'));
  kids.push(spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 9021, OSC_PORT: 9022, DATA_DIR: DATA, MEDIA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxem-')) }, stdio: 'ignore' }));
  const B = 'http://127.0.0.1:9021'; for (let i = 0; i < 80 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const cmd = x => fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(x) }).then(r => r.json()); const st = () => fetch(B + '/api/state').then(r => r.json());
  await cmd({ op: 'set', path: 'macros', value: [
    { id: 'a', name: 'Opening', steps: [{ wait: 0, action: { type: 'blackoutOn' } }, { wait: 0.6, action: { type: 'http', method: 'POST', url: 'http://127.0.0.1:9031/go', body: '{"scene":1}' } }, { wait: 0.3, action: { type: 'macro', macro: 'Lights' } }, { wait: 0, action: { type: 'macro', macro: 'Opening' } }] },
    { id: 'b', name: 'Lights', steps: [{ wait: 0.2, action: { type: 'http', url: 'http://127.0.0.1:9031/lights?x=1' } }, { wait: 0, action: { type: 'blackoutOff' } }] }] });
  const t0 = Date.now(); await cmd({ op: 'macroRun', name: 'Opening' }); await tick(250); assert.strictEqual((await st()).comp.blackout, true, 'first step at once');
  await tick(1500); assert.strictEqual(hits.length, 2, JSON.stringify(hits)); assert.ok(hits[0].m === 'POST' && hits[0].u === '/go' && hits[0].b === '{"scene":1}' && /json/.test(hits[0].ct) && hits[0].t - t0 >= 550, JSON.stringify(hits[0]));
  assert.ok(hits[1].m === 'GET' && hits[1].u === '/lights?x=1' && hits[1].t - hits[0].t >= 450); assert.strictEqual((await st()).comp.blackout, false);
  ok('macro: steps in order with waits, a webhook POST (JSON) and GET, a macro calling another macro, no self-recursion');
  const u = dgram.createSocket('udp4'); const osc = (addr, s) => { const pad = b => Buffer.concat([b, Buffer.alloc(4 - (b.length % 4))]); return Buffer.concat([pad(Buffer.from(addr)), pad(Buffer.from(',s')), pad(Buffer.from(s))]); };
  hits.length = 0; await new Promise(r => u.send(osc('/pixora/macro', 'Lights'), 9022, '127.0.0.1', r)); await tick(700); assert.strictEqual(hits.length, 1, 'OSC /pixora/macro'); u.close();
  ok('OSC /pixora/macro "name" runs a macro');
  await cmd({ op: 'set', path: 'exprs', value: [{ path: 'layers.0.opacity', expr: 'sin(time)' }, { path: 'layers.0.speed', expr: 'x'.repeat(600) }] }); const ex = (await st()).exprs;
  assert.ok(ex[0].id && ex[0].on === true && ex[1].expr.length === 500); ok('expressions are stored with the show (ids added, length capped)');
  hs.close(); console.log('Expressions & macros test passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
