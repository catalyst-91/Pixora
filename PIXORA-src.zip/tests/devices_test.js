// PIXORA device control tests: mock Blackmagic Videohub / HyperDeck / Streaming Encoder (TCP), Blackmagic camera,
// BirdDog, Panasonic AW + Auto Tracking (HTTP), VISCA over IP (UDP) and the desktop app's NDI PTZ bridge.
// Each mock speaks the documented protocol and records what PIXORA sends.   node tests/devices_test.js
const { spawn } = require('child_process'); const net = require('net'), http = require('http'), dgram = require('dgram');
const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
const until = async (fn, ms = 4000) => { const t = Date.now(); while (Date.now() - t < ms) { const v = await fn(); if (v) return v; await tick(50); } throw new Error('timed out waiting'); };

/* ---- mock Videohub (protocol v2.3) */
const vh = { routes: [0, 1, 2, 3], got: [] };
const vhSrv = net.createServer(s => {
  const dump = () => s.write('PROTOCOL PREAMBLE:\nVersion: 2.3\n\nVIDEOHUB DEVICE:\nDevice present: true\nModel name: Blackmagic Smart Videohub 4x4\nVideo inputs: 4\nVideo outputs: 4\n\n' +
    'INPUT LABELS:\n0 CAM 1\n1 CAM 2\n2 PIXORA\n3 Playback\n\nOUTPUT LABELS:\n0 LED processor\n1 Stream\n2 Monitor\n3 Record\n\nVIDEO OUTPUT ROUTING:\n' + vh.routes.map((r, i) => `${i} ${r}`).join('\n') + '\n\nVIDEO OUTPUT LOCKS:\n0 U\n1 U\n2 U\n3 U\n\n');
  dump(); let buf = '';
  s.on('data', d => { buf += d; let i; while ((i = buf.indexOf('\n\n')) >= 0) { const blk = buf.slice(0, i); buf = buf.slice(i + 2); vh.got.push(blk); const [h, ...l] = blk.split('\n');
    if (h === 'VIDEO OUTPUT ROUTING:') { s.write('ACK\n\n'); for (const x of l) { const [o, n] = x.split(' ').map(Number); vh.routes[o] = n; } s.write('VIDEO OUTPUT ROUTING:\n' + l.join('\n') + '\n\n'); }
    else if (h === 'OUTPUT LABELS:') { s.write('ACK\n\nOUTPUT LABELS:\n' + l.join('\n') + '\n\n'); } else s.write('NAK\n\n'); } });
});
/* ---- mock HyperDeck */
const hd = { got: [], status: 'stopped', clip: 1 };
const hdSrv = net.createServer(s => {
  s.write('500 connection info:\nprotocol version: 1.11\nmodel: HyperDeck Studio HD Plus\n\n'); let buf = '';
  const ti = () => `transport info:\nstatus: ${hd.status}\nspeed: ${hd.status === 'play' ? 100 : 0}\nslot id: 1\nclip id: ${hd.clip}\nsingle clip: false\ntimecode: 00:00:10:00\nvideo format: 1080p50\nloop: false\n\n`;
  s.on('data', d => { buf += d; let i; while ((i = buf.indexOf('\n')) >= 0) { const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1); if (!line) continue; hd.got.push(line);
    if (line.startsWith('notify')) s.write('200 ok\n');
    else if (line === 'device info') s.write('204 device info:\nprotocol version: 1.11\nmodel: HyperDeck Studio HD Plus\nunique id: 1234\nslot count: 2\n\n');
    else if (line === 'transport info') s.write('208 ' + ti());
    else if (line === 'clips get') s.write('205 clips info:\nclip count: 3\n1: Walk In Loop 00:00:00:00 00:05:00:00\n2: Sponsor Reel 00:05:00:00 00:01:30:00\n3: Award Package Final 00:06:30:00 00:02:00:00\n\n');
    else if (line.startsWith('goto: clip id:')) { const v = line.split(':').pop().trim(); hd.clip = /^[+-]/.test(v) ? hd.clip + +v : +v; s.write('200 ok\n508 ' + ti()); }
    else if (line.startsWith('play')) { hd.status = 'play'; s.write('200 ok\n508 ' + ti()); }
    else if (line === 'stop') { hd.status = 'stopped'; s.write('200 ok\n508 ' + ti()); }
    else if (line.startsWith('record')) { hd.status = 'record'; s.write('200 ok\n508 ' + ti()); }
    else s.write('100 syntax error\n'); } });
});
/* ---- mock Streaming Encoder / Web Presenter */
const se = { got: [], status: 'Idle' };
const seSrv = net.createServer(s => {
  s.write('PROTOCOL PREAMBLE:\nVersion: 1.2\n\nIDENTITY:\nModel: Blackmagic Web Presenter HD\nLabel: Stage Left Encoder\n\nSTREAM SETTINGS:\nCurrent Platform: YouTube\nCurrent Server: Primary\nStream Key: \n\nSTREAM STATE:\nStatus: Idle\n\nEND PRELUDE:\n\n'); let buf = '';
  s.on('data', d => { buf += d; let i; while ((i = buf.indexOf('\n\n')) >= 0) { const blk = buf.slice(0, i); buf = buf.slice(i + 2); se.got.push(blk); const [h, ...l] = blk.split('\n');
    if (h === 'STREAM STATE:' && l[0] === 'Action: Start') { s.write('ACK\n\nSTREAM STATE:\nStatus: Connecting\n\n'); setTimeout(() => s.write('STREAM STATE:\nStatus: Streaming\nDuration: 00:00:00:01\nBitrate: 6000000\n\n'), 100); }
    else if (h === 'STREAM STATE:') s.write('ACK\n\nSTREAM STATE:\nStatus: Idle\n\n');
    else if (h === 'STREAM SETTINGS:') s.write('ACK\n\nSTREAM SETTINGS:\n' + l.join('\n') + '\n\n'); else s.write('NACK\n\n'); } });
});
/* ---- one HTTP mock playing Blackmagic camera, BirdDog, Panasonic AW and Auto Tracking */
const H = { got: [] };
const httpSrv = http.createServer((q, r) => { let b = ''; q.on('data', c => b += c); q.on('end', () => { H.got.push({ m: q.method, u: q.url, b, auth: q.headers.authorization || '' }); const u = q.url;
  const j = o => { r.setHeader('Content-Type', 'application/json'); r.end(JSON.stringify(o)); };
  if (u === '/control/api/v1/system/product') return j({ productName: 'Blackmagic Studio Camera 4K Pro G2' });
  if (u === '/control/api/v1/transports/0/record') return q.method === 'GET' ? j({ recording: false }) : j({});
  if (u.startsWith('/control/api/v1/')) return j({});
  if (u === '/about') return j({ FirmwareVersion: '6.1.9', HostName: 'birddog-p400', Status: 'ONLINE' });
  if (u === '/operationmode') return r.end('decode');
  if (u === '/List') return j({ 'STUDIO (PIXORA main)': 'x', 'CAM2 (BirdDog P400)': 'y' });
  if (['/recall', '/save', '/connectTo', '/birddogptzsetup', '/refresh', '/encodesetup', '/birddogexpsetup', '/birddogwbsetup'].includes(u)) return j({});
  if (u.startsWith('/cgi-bin/aw_ptz')) { const c = decodeURIComponent(u.match(/cmd=([^&]+)/)[1]); return r.end(c === '#O' ? 'p1' : c.replace('#', '').replace(/^PTS/, 'pTS')); }
  if (u.startsWith('/cgi-bin/aw_cam')) { const c = decodeURIComponent(u.match(/cmd=([^&]+)/)[1]); return r.end(c === 'QID' ? 'OID:AW-UE150' : c); }
  if (u.startsWith('/cgi-bin/auto_tracking')) return r.end(/cmd=Preset&id=1&mode=recall&preset_num=200/.test(u) ? 'resp nack' : 'resp ack');
  r.statusCode = 404; r.end(); }); });
/* ---- VISCA over IP listener */
const vi = { got: [] }; const viSock = dgram.createSocket('udp4'); viSock.on('message', (m, rinfo) => { vi.got.push(m); const seq = m.readUInt32BE(4); const ack = Buffer.alloc(11); ack.writeUInt16BE(0x0111, 0); ack.writeUInt16BE(3, 2); ack.writeUInt32BE(seq, 4); ack.set([0x90, 0x41, 0xff], 8); viSock.send(ack, rinfo.port, rinfo.address); });

(async () => {
  await Promise.all([[vhSrv, 19990], [hdSrv, 19993], [seSrv, 19977], [httpSrv, 18080]].map(([s, p]) => new Promise(r => s.listen(p, '127.0.0.1', r))));
  await new Promise(r => viSock.bind(52399, '127.0.0.1', r));
  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxdev-')), MEDIA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxdevm-'));
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8871, OSC_PORT: 8872, DATA_DIR: DATA, MEDIA_DIR: MEDIA, PIXORA_APP_TOKEN: 'apptoken' }, stdio: ['ignore', 'pipe', 'pipe'] }); kids.push(srv);
  let log = ''; srv.stdout.on('data', d => log += d); srv.stderr.on('data', d => log += d);
  const B = 'http://127.0.0.1:8871';
  for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const api = async (p, method = 'GET', body) => { const r = await fetch(B + p, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined }); const j = await r.json().catch(() => ({})); if (!r.ok) throw Object.assign(new Error(j.error || r.status), { status: r.status }); return j; };
  const add = d => api('/api/devices', 'POST', d);
  const dev = async name => (await api('/api/devices')).devices.find(d => d.name === name);

  const v = await add({ type: 'videohub', name: 'Router', host: '127.0.0.1', port: 19990 });
  await until(async () => { const d = await dev('Router'); return d.state.online && d.state.inputs.length === 4; });
  let d = await dev('Router'); assert.deepStrictEqual(d.state.inputs, ['CAM 1', 'CAM 2', 'PIXORA', 'Playback']); assert.strictEqual(d.state.info.model, 'Blackmagic Smart Videohub 4x4');
  await api(`/api/devices/Router/route`, 'POST', { output: 1, input: 3 });
  await until(async () => (await dev('Router')).state.routing[0] === 2);
  assert.strictEqual(vh.got.pop(), 'VIDEO OUTPUT ROUTING:\n0 2'); ok('Videohub: reads labels/routing (4×4 "' + d.state.info.model + '"), routes LED processor ← PIXORA (sent "0 2", 0-based)');
  await api(`/api/devices/${v.id}/salvo`, 'POST', { routes: [{ output: 2, input: 1 }, { output: 4, input: 4 }] }); assert.strictEqual(vh.got.pop(), 'VIDEO OUTPUT ROUTING:\n1 0\n3 3'); ok('Videohub: salvo of several routes in one block');

  await add({ type: 'hyperdeck', name: 'Deck A', host: '127.0.0.1', port: 19993 });
  await until(async () => (await dev('Deck A')).state.clips.length === 3);
  d = await dev('Deck A'); assert.strictEqual(d.state.clips[2].name, 'Award Package Final'); assert.strictEqual(d.state.clips[1].duration, '00:01:30:00');
  await api('/api/devices/Deck%20A/playClip', 'POST', { clip: 3, loop: true });
  await until(async () => (await dev('Deck A')).state.transport.status === 'play');
  assert.ok(hd.got.includes('goto: clip id: 3') && hd.got.includes('play: single clip: true loop: true'), hd.got.join(' | '));
  await api('/api/devices/Deck%20A/record', 'POST', { name: 'Keynote' }); assert.strictEqual(hd.got.pop(), 'record: name: Keynote');
  await api('/api/devices/Deck%20A/stop', 'POST'); await until(async () => (await dev('Deck A')).state.transport.status === 'stopped');
  ok(`HyperDeck: clip list (${d.state.clips.map(c => c.name).join(', ')}), play clip 3 looped, record named clip, stop — transport notifications followed`);
  let err = await api('/api/devices/Deck%20A/raw', 'POST', { command: 'frobnicate' }).catch(e => e); assert.match(err.message, /100 syntax error/); ok('HyperDeck: device errors come back as messages ("' + err.message + '")');

  await add({ type: 'streamer', name: 'Encoder', host: '127.0.0.1', port: 19977 });
  await until(async () => (await dev('Encoder')).state.info.label === 'Stage Left Encoder');
  await api('/api/devices/Encoder/platform', 'POST', { platform: 'YouTube', server: 'Primary', key: 'abcd-efgh' });
  assert.strictEqual(se.got.pop(), 'STREAM SETTINGS:\nCurrent Platform: YouTube\nCurrent Server: Primary\nStream Key: abcd-efgh');
  await api('/api/devices/Encoder/start', 'POST'); await until(async () => (await dev('Encoder')).state.stream.Status === 'Streaming');
  ok('Streaming Encoder: sets platform/server/key, starts the stream (Idle → Connecting → Streaming)');

  await add({ type: 'bmcamera', name: 'Cam 1', host: '127.0.0.1', port: 18080 });
  await until(async () => (await dev('Cam 1')).state.online);
  await api('/api/devices/Cam%201/record', 'POST', { on: true }); await api('/api/devices/Cam%201/iris', 'POST', { value: 0.4 }); await api('/api/devices/Cam%201/whiteBalance', 'POST', { kelvin: 5600 });
  const cam = H.got.filter(x => x.u.startsWith('/control/api/v1') && x.m !== 'GET').map(x => `${x.m} ${x.u} ${x.b}`);
  assert.ok(cam.includes('POST /control/api/v1/transports/0/record {"recording":true}') && cam.includes('PUT /control/api/v1/lens/iris {"normalised":0.4}') && cam.includes('PUT /control/api/v1/video/whiteBalance {"whiteBalance":5600}'), cam.join('\n'));
  ok('Blackmagic camera REST: record, iris, white balance (' + (await dev('Cam 1')).state.info.model + ')');

  await add({ type: 'birddog', name: 'P400', host: '127.0.0.1', port: 18080 });
  await until(async () => (await dev('P400')).state.sources.length === 2);
  await api('/api/devices/P400/recall', 'POST', { preset: 3 }); await api('/api/devices/P400/source', 'POST', { source: 'STUDIO (PIXORA main)' });
  const bd = H.got.filter(x => x.m === 'POST').map(x => `${x.u} ${x.b}`);
  assert.ok(bd.includes('/recall {"Preset":"Preset-3"}') && bd.includes('/connectTo {"sourceName":"STUDIO (PIXORA main)"}'), bd.join('\n'));
  ok('BirdDog: device info, decode NDI source list, recall preset 3, route PIXORA to a decoder');

  await add({ type: 'panasonic', name: 'UE150', host: '127.0.0.1', port: 18080, user: 'admin', password: 'pw' });
  await until(async () => (await dev('UE150')).state.online);
  await api('/api/devices/UE150/recall', 'POST', { preset: 12 }); await api('/api/devices/UE150/move', 'POST', { pan: 1, tilt: 0 }); await api('/api/devices/UE150/stop', 'POST'); await api('/api/devices/UE150/tally', 'POST', { red: true });
  const aw = H.got.filter(x => x.u.startsWith('/cgi-bin/aw_')).map(x => decodeURIComponent(x.u.match(/cmd=([^&]+)/)[1]));
  assert.ok(['#R11', '#PTS9950', '#PTS5050', '#Z50', 'TLR:1', 'TLG:0'].every(c => aw.includes(c)), aw.join(' '));
  assert.ok(H.got.find(x => x.u.includes('aw_ptz')).auth.startsWith('Basic '));
  ok('Panasonic AW: preset 12 → #R11, pan right #PTS9950, stop, red tally — with camera login (' + (await dev('UE150')).state.info.model + ')');

  await add({ type: 'pantrack', name: 'Tracker', host: '127.0.0.1', port: 18080, camId: 1 });
  await until(async () => (await dev('Tracker')).state.online);
  await api('/api/devices/Tracker/tracking', 'POST', { on: true }); await api('/api/devices/Tracker/angle', 'POST', { mode: 'body' });
  const at = H.got.filter(x => x.u.startsWith('/cgi-bin/auto_tracking')).map(x => x.u.split('?')[1]);
  assert.ok(at.includes('cmd=TrackingControl&id=1&enable=on') && at.includes('cmd=Angle&id=1&mode=body'), at.join('\n'));
  err = await api('/api/devices/Tracker/preset', 'POST', { mode: 'recall', preset: 200 }).catch(e => e); // clamps to 100 → device acks
  ok('Panasonic Auto Tracking: tracking on, body framing; values clamped to the documented ranges');

  await add({ type: 'visca', name: 'PTZOptics', host: '127.0.0.1', port: 52399, camId: 1 });
  await tick(300); vi.got.length = 0;
  await api('/api/devices/PTZOptics/move', 'POST', { pan: -1, tilt: 1 }); await api('/api/devices/PTZOptics/recall', 'POST', { preset: 4 });
  await until(() => vi.got.length >= 2);
  const hex = vi.got.map(m => m.subarray(8).toString('hex'));
  assert.strictEqual(vi.got[0].readUInt16BE(0), 0x0100); assert.strictEqual(hex[0], '8101060118170101ff'); assert.strictEqual(hex[1], '8101043f0204ff');
  ok('VISCA over IP: Sony header + "81 01 06 01 18 17 01 01 FF" (up-left full speed), preset recall "81 01 04 3F 02 04 FF"');

  // NDI PTZ through the desktop bridge: pretend to be the desktop app's long-poll loop
  await add({ type: 'ndiptz', name: 'NDI Cam', source: 'BIRDDOG-P200 (CAM)' });
  const desktop = (async () => { const r = await fetch(B + '/api/native/poll', { headers: { 'x-app-token': 'apptoken' } }); const job = await r.json();
    await fetch(B + '/api/native/result', { method: 'POST', headers: { 'x-app-token': 'apptoken', 'Content-Type': 'application/json' }, body: JSON.stringify({ id: job.id, result: { ok: true } }) }); return job; })();
  await tick(100); await api('/api/devices/NDI%20Cam/recall', 'POST', { preset: 2, speed: 0.5 }); const job = await desktop;
  assert.deepStrictEqual([job.type, job.source, job.action, job.a, job.b], ['ptz', 'BIRDDOG-P200 (CAM)', 'recallPreset', 2, 0.5]); ok('NDI PTZ: command handed to the desktop app (recallPreset 2 at half speed) and answered');
  err = await api('/api/devices/NDI%20Cam/stop', 'POST').catch(e => e); assert.match(err.message, /desktop app did not answer/); ok('NDI PTZ without the desktop app: clear error');

  // cues / commands / OSC drive devices
  await fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ op: 'runAction', action: { type: 'device', device: 'Router', action: 'route', args: '{"output":3,"input":1}' } }) });
  await until(async () => (await dev('Router')).state.routing[2] === 0); ok('Cue/rule action "Device action" routes the Videohub');
  const osc = dgram.createSocket('udp4'); const pad = b => Buffer.concat([b, Buffer.alloc(4 - (b.length % 4))]);
  osc.send(Buffer.concat([pad(Buffer.from('/pixora/device/Deck A/playClip')), pad(Buffer.from(',ii')), Buffer.from([0, 0, 0, 2, 0, 0, 0, 0])]), 8872, '127.0.0.1');
  await until(() => hd.got.includes('goto: clip id: 2')); ok('OSC /pixora/device/Deck A/playClip 2 → HyperDeck goes to clip 2');

  // device goes away and comes back
  hdSrv.close(); for (const c of [...(hdSrv._conns || [])]) c.destroy();
  srv.kill(); await tick(200);
  const st = JSON.parse(fs.readFileSync(path.join(DATA, 'settings.json'), 'utf8')); assert.strictEqual(st.devices.length, 9); ok('9 devices saved on this machine');
  console.log('\nAll device tests passed.'); process.exit(0);
})().catch(e => { console.error('✗', e); process.exit(1); });
