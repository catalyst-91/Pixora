// Live captions: text in (WebSocket / HTTP / OSC), wrapped rows published as the "captions" feed, second-language lane,
// clearing, profanity mask, transcript TXT/SRT, and the Captions title template.
//   node tests/captions_test.js
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert'), dgram = require('dgram');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
function osc(addr, s) { const pad = b => Buffer.concat([b, Buffer.alloc(4 - (b.length % 4))]); return Buffer.concat([pad(Buffer.from(addr)), pad(Buffer.from(',s')), pad(Buffer.from(s))]); }
(async () => {
  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxcap-'));
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8895, OSC_PORT: 8896, DATA_DIR: DATA, MEDIA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxcapm-')) }, stdio: 'ignore' }); kids.push(srv);
  const B = 'http://127.0.0.1:8895'; for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const cap = b => fetch(B + '/api/captions', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) }).then(r => r.json());
  const feed = async () => { await tick(350); return (await fetch(B + '/api/feeds').then(r => r.json())).values.captions || {}; };
  const cmd = c => fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(c) });
  await cmd({ op: 'set', path: 'captions.clearAfter', value: 0 });

  let v = await cap({ text: 'Good evening everyone and welcome to the annual awards night', final: true });
  assert.strictEqual(v.line1, 'Good evening everyone and welcome to the'); assert.strictEqual(v.line2, 'annual awards night'); assert.strictEqual(v.text, v.line1 + '\n' + v.line2); ok('final text wrapped to 2 lines of 42 characters');
  await cap({ text: 'we have a big show', final: false }); v = await feed(); assert.strictEqual(v.partial, 'we have a big show'); assert.ok(v.line2.endsWith('we have a big show') || v.text.includes('big show')); ok('words in progress show straight away (partial)');
  await cap({ text: 'We have a big show for you tonight.', final: true }); v = await feed(); assert.strictEqual(v.partial, ''); assert.ok(v.text.endsWith('you tonight.'), JSON.stringify(v)); assert.strictEqual(v.text.split('\n').length, 2); ok('the screen scrolls: only the last 2 rows are shown');
  const st = await fetch(B + '/api/state').then(r => r.json()); assert.ok(st.feeds.find(f => f.id === 'captions' && f.type === 'push')); ok('"captions" data feed created for titles');

  // WebSocket from a browser controller
  const ws = new WebSocket(B.replace('http', 'ws') + '/ws?role=control'); await new Promise(r => ws.onopen = r);
  ws.send(JSON.stringify({ t: 'caption', text: 'Please welcome our host', final: true, src: 'browser' })); v = await feed(); assert.strictEqual(v.last, 'Please welcome our host'); assert.strictEqual(v.source, 'browser'); ok('captions from the browser (WebSocket)');
  ws.close();
  // OSC
  const u = dgram.createSocket('udp4'); u.send(osc('/pixora/caption', 'from the OSC captioner'), 8896, '127.0.0.1'); u.send(osc('/pixora/caption2', 'del subtitulador'), 8896, '127.0.0.1'); await tick(200); u.close();
  v = await feed(); assert.strictEqual(v.last, 'from the OSC captioner'); assert.strictEqual(v.text2, 'del subtitulador'); assert.strictEqual(v.line1b, 'del subtitulador'); ok('OSC /pixora/caption and /pixora/caption2 (second language)');
  await cap({ text: 'Bienvenidos a todos', final: true, lane: 2 }); v = await feed(); assert.strictEqual(v.last2, 'Bienvenidos a todos'); ok('translated lane over HTTP → {{captions.text2}}');

  // settings: lines, chars, capitals, profanity
  await cmd({ op: 'set', path: 'captions.lines', value: 1 }); await cmd({ op: 'set', path: 'captions.upper', value: true });
  v = await cap({ text: 'well that was a shit joke', final: true }); assert.ok(!v.text.includes('\n')); assert.strictEqual(v.last, 'WELL THAT WAS A S*** JOKE'); ok('1-line mode, capitals and swear-word masking');
  await cap({ action: 'clear' }); v = await feed(); assert.strictEqual(v.text, ''); assert.strictEqual(v.text2, ''); ok('clear blanks the screen');
  // auto-clear after silence
  await cmd({ op: 'set', path: 'captions.clearAfter', value: 1 }); await cap({ text: 'thank you', final: true }); await tick(1500); v = await feed(); assert.strictEqual(v.text, ''); ok('auto-clears after the silence time');

  const txt = await fetch(B + '/api/captions/transcript?fmt=txt').then(r => r.text()); assert.ok(/Good evening everyone/.test(txt) && /THANK YOU/.test(txt)); assert.strictEqual(txt.trim().split('\n').length, 6);
  const srt = await fetch(B + '/api/captions/transcript?fmt=srt').then(r => r.text()); assert.ok(/^1\n\d\d:\d\d:\d\d,\d{3} --> \d\d:\d\d:\d\d,\d{3}\n/.test(srt)); assert.strictEqual((srt.match(/-->/g) || []).length, 6);
  const srt2 = await fetch(B + '/api/captions/transcript?fmt=srt&lane=2').then(r => r.text()); assert.strictEqual((srt2.match(/-->/g) || []).length, 2); ok('transcript downloads: TXT, SRT and translation SRT');
  await cap({ action: 'reset' }); assert.strictEqual((await fetch(B + '/api/captions/transcript').then(r => r.text())).trim(), ''); ok('new transcript');

  const R = fs.readFileSync(path.join(ROOT, 'public/renderer.js'), 'utf8'), S = require(path.join(ROOT, 'public/schema.js'));
  assert.strictEqual(S.GENERATORS.find(g => g.id === 'title').params.find(p => p.k === 'tpl').options[7], 'Captions'); assert.ok(R.includes('tplId === 7')); ok('Captions title template');
  process.exit(0);
})().catch(e => { console.error('✗', e.stack || e.message); process.exit(1); });
