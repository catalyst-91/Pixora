// ISF import: header parsing (inputs, passes, ISF 1.x keys, imported images), GLSL generation (IMG_* rewrites, built-ins,
// vertex shader), pass-size expressions, value defaults, and the server side (shaderSave metadata, isfVals, effect slots).
//   node tests/isf_test.js        (the GPU side is covered by tests/render_check.py in a real browser)
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const ISF = require('../public/isf.js'), S = require('../public/schema.js');
const FIX = path.join(__dirname, 'fixtures', 'isf'), rd = f => fs.readFileSync(path.join(FIX, f), 'utf8');
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));

(async () => {
  // ---- parser
  let p = ISF.parse(rd('Solid Pulse.fs'));
  assert.ok(p.ok && !p.isFilter, JSON.stringify(p.errors)); assert.strictEqual(p.inputs.length, 5, 'trailing comma in the header tolerated');
  const byName = Object.fromEntries(p.inputs.map(i => [i.name, i]));
  assert.deepStrictEqual([byName.level.type, byName.level.min, byName.level.max, byName.level.def], ['float', 0, 1, 1]);
  assert.deepStrictEqual(byName.tint.def, [1, 0, 0, 1]); assert.deepStrictEqual(byName.side.values, [0, 1, 2]); assert.deepStrictEqual(byName.side.labels, ['Full', 'Left', 'Right']);
  assert.strictEqual(byName.invert.def, false); assert.deepStrictEqual(byName.spot.max, [1, 1]);
  assert.deepStrictEqual(p.categories, ['Generator', 'Test']); assert.strictEqual(p.credit, 'PIXORA tests');
  ok('header: float / color / long (VALUES + LABELS) / bool / point2D inputs, categories, credit');
  p = ISF.parse(rd('Swap RB.fs')); assert.ok(p.isFilter && !p.isTransition); assert.strictEqual(p.inputs[1].def, 1); assert.strictEqual(ISF.parse('/*{"INPUTS":[{"NAME":"a","TYPE":"float"}]}*/').inputs[0].def, 0, 'float with no MIN/DEFAULT → 0');
  p = ISF.parse(rd('Accumulate.fs')); assert.deepStrictEqual(p.passes.map(x => [x.target, x.persistent]), [['small', false], ['acc', true], ['', false]]); assert.deepStrictEqual(p.targets, ['small', 'acc']);
  assert.deepStrictEqual(ISF.passSize(p.passes[0], 1921, 1080, {}), { w: 960, h: 540 }); assert.deepStrictEqual(ISF.passSize(p.passes[2], 640, 360, {}), { w: 640, h: 360 });
  p = ISF.parse(rd('Old Trails.fs')); assert.ok(p.passes[0].persistent && p.version === '1', 'ISF 1.0 PERSISTENT_BUFFERS');
  p = ISF.parse(rd('Logo Wobble.fs'), rd('Logo Wobble.vs')); assert.deepStrictEqual(p.imported, [{ name: 'logo', path: 'logo.png' }]); assert.ok(p.vsBody.includes('isf_vertShaderInit'));
  p = ISF.parse(rd('Spectrum Bars.fs')); assert.strictEqual(p.inputs[0].samples, 64);
  const tr = ISF.parse('/*{"INPUTS":[{"NAME":"startImage","TYPE":"image"},{"NAME":"inputImage","TYPE":"image"},{"NAME":"progress","TYPE":"float"}]}*/void main(){gl_FragColor=vec4(0.0);}');
  assert.ok(tr.isTransition);
  ok('passes (targets, persistent, size expressions), ISF 1.0 buffers, IMPORTED, audio MAX, transitions detected');

  // ---- bad headers / inputs
  assert.throws(() => ISF.parse('void main(){}'), /No ISF JSON header/); assert.throws(() => ISF.parse('/*{ nope }*/'), /not valid JSON/);
  let v = ISF.validate('/*{"INPUTS":[{"NAME":"2bad","TYPE":"float"},{"NAME":"x","TYPE":"weird"}]}*/void main(){}'); assert.ok(!v.ok && v.errors.length === 2, JSON.stringify(v.errors));
  v = ISF.validate('/*{}*/void main(){ gl_FragColor = IMG_PIXEL(inputImage, vec2(1.0); }'); assert.ok(!v.ok && /Unbalanced/.test(v.errors[0]));
  ok('invalid headers, input names, types and unbalanced IMG_ calls rejected with a reason');

  // ---- GLSL generation
  let b = ISF.build(ISF.parse(rd('Swap RB.fs')));
  assert.ok(b.fs.includes('uniform sampler2D inputImage;') && b.fs.includes('uniform vec2 _inputImage_imgSize;') && b.fs.includes('uniform float amount;'));
  assert.ok(b.fs.includes('texture2D(inputImage, (isf_FragNormCoord * _inputImage_imgSize) / _inputImage_imgSize)'), 'nested IMG_SIZE inside IMG_PIXEL');
  assert.ok(b.fs.includes('texture2D(inputImage, isf_FragNormCoord)') && !/IMG_/.test(b.fs));
  for (const u of ['PASSINDEX', 'RENDERSIZE', 'TIME', 'TIMEDELTA', 'DATE', 'FRAMEINDEX']) assert.ok(b.fs.includes(' ' + u + ';'), u);
  assert.ok(!b.vs.includes('sampler2D inputImage'), 'vertex shader only declares the images it uses');
  b = ISF.build(ISF.parse(rd('Solid Pulse.fs'))); assert.ok(b.fs.includes('uniform int side;') && b.fs.includes('uniform bool invert;') && b.fs.includes('uniform vec4 tint;') && b.fs.includes('uniform vec2 spot;'));
  b = ISF.build(ISF.parse(rd('Old Trails.fs'))); assert.ok(!b.fs.includes('vv_FragNormCoord') && b.fs.includes('uniform sampler2D trail;'));
  b = ISF.build(ISF.parse(rd('Logo Wobble.fs'), rd('Logo Wobble.vs'))); assert.ok(b.vs.includes('uniform float wobble;') && b.vs.includes('void isf_vertShaderInit()') && b.vs.match(/void main/g).length === 1 && b.images.includes('logo'));
  b = ISF.build(ISF.parse('/*{}*/\n#extension GL_OES_standard_derivatives : enable\nvoid main(){ gl_FragColor = vec4(fwidth(isf_FragNormCoord.x)); }'));
  assert.ok(/^#extension GL_OES_standard_derivatives : enable\n/.test(b.fs) && b.fs.match(/#extension/g).length === 1, 'extension directive moved to the top once');
  b = ISF.build(ISF.parse('/*{}*/void main(){ gl_FragColor = vec4(dFdx(isf_FragNormCoord.x)); }')); assert.ok(b.fs.startsWith('#extension GL_OES_standard_derivatives'), 'derivatives enabled automatically');
  ok('GLSL: uniforms per input type, IMG_* rewritten (nested), built-ins, vertex shader + varyings, #extension handling');

  // ---- expressions and values
  assert.strictEqual(ISF.evalSize('max($WIDTH/4.0, 64.0)', { WIDTH: 100 }), 64); assert.strictEqual(ISF.evalSize('floor($HEIGHT*$scale)+1', { HEIGHT: 100, scale: 0.333 }), 34);
  assert.strictEqual(ISF.evalSize('alert(1)', {}), null); assert.strictEqual(ISF.evalSize('$WIDTH/0', { WIDTH: 5 }), 0); assert.strictEqual(ISF.evalSize('2*(3+4)', {}), 14);
  const pi = ISF.parse(rd('Solid Pulse.fs')).inputs;
  assert.strictEqual(ISF.value(pi[0], { level: 9 }), 1, 'clamped to MAX'); assert.strictEqual(ISF.value(pi[0], {}), 1); assert.deepStrictEqual(ISF.value(pi[1], { tint: '#00ff00' }), [0, 1, 0, 1]);
  assert.strictEqual(ISF.value(pi[2], { side: '2' }), 2); assert.strictEqual(ISF.hex([1, 0.5, 0, 1]), '#ff8000');
  ok('size expressions evaluated safely (no eval), values clamped / defaulted / hex colours');

  // ---- schema: effect slots
  const fx = S.fxDefaults(); assert.ok(fx.isf && fx.isf2 && fx.lut && fx.lut2); assert.deepStrictEqual(fx.isf.v, {}); assert.strictEqual(fx.isf.mix, 1); assert.deepStrictEqual(S.genDefaults('shader').isf, {});
  ok('ISF Effect 1/2 and LUT 1/2 slots in every effect stack; shader clips carry an ISF value bag');

  // ---- server
  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxisf-'));
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8897, OSC_PORT: 8898, DATA_DIR: DATA, MEDIA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxisfm-')) }, stdio: 'ignore' }); kids.push(srv);
  const B = 'http://127.0.0.1:8897'; for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const cmd = c => fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(c) }).then(r => r.json());
  const state = () => fetch(B + '/api/state').then(r => r.json());
  await cmd({ op: 'shaderSave', shader: { id: 'gen1', name: 'Solid Pulse', code: rd('Solid Pulse.fs') } });
  await cmd({ op: 'shaderSave', shader: { id: 'fx1', name: 'Swap RB', code: rd('Swap RB.fs') } });
  await cmd({ op: 'shaderSave', shader: { id: 'wob', name: 'Logo Wobble', code: rd('Logo Wobble.fs'), vs: rd('Logo Wobble.vs'), files: { logo: 'local/ISF/logo.png', 'bad name': 'x', __proto__: 'y' } } });
  await cmd({ op: 'shaderSave', shader: { id: 'nofile', name: 'No logo', code: rd('Logo Wobble.fs') } });
  await cmd({ op: 'shaderSave', shader: { id: 'broken', name: 'Broken', code: '/*{ "INPUTS": [ { "NAME": "a b", "TYPE": "float" } ] }*/ void main(){}' } });
  let st = await state(); const sh = id => st.shaders.find(x => x.id === id);
  assert.strictEqual(sh('gen1').isf.kind, 'generator'); assert.strictEqual(sh('gen1').isf.inputs, 5); assert.deepStrictEqual(sh('gen1').isf.categories, ['Generator', 'Test']);
  assert.strictEqual(sh('fx1').isf.kind, 'effect'); assert.deepStrictEqual(sh('wob').files, { logo: 'local/ISF/logo.png' }); assert.ok(sh('wob').vs.includes('shifted'));
  assert.deepStrictEqual(sh('wob').isf.missing, []); assert.deepStrictEqual(sh('nofile').isf.missing, ['logo.png']); assert.strictEqual(sh('broken').isf.kind, 'invalid');
  assert.ok(!sh('tunnel').isf, 'Shadertoy-style built-ins are not ISF');
  ok('server: ISF kind / categories / inputs stored, vertex shader + imported files kept (bad keys dropped), missing images and invalid shaders flagged');
  // re-saving the code only keeps the vs and files
  await cmd({ op: 'shaderSave', shader: { id: 'wob', name: 'Logo Wobble', code: rd('Logo Wobble.fs') + '\n' } }); st = await state(); assert.ok(sh('wob').vs && sh('wob').files.logo);
  await cmd({ op: 'shaderSave', shader: { id: 'wob', vs: '' } }); st = await state(); assert.ok(!sh('wob').vs, 'vs removed with an empty string');

  // generator clip + value bag
  await cmd({ op: 'assign', layer: 0, slot: 0, clip: { type: 'gen', name: 'Solid Pulse', gen: { kind: 'shader', params: Object.assign(S.genDefaults('shader'), { shader: 'gen1' }) } } });
  await cmd({ op: 'isfVals', path: 'layers.0.clips.0.gen.params', key: 'isf', vals: { level: 0.5, tint: '#00ff00', side: 1, invert: true, spot: [0.2, 0.3], 'bad-key': 1, nested: { a: 1 }, big: [1, 2, 3, 4, 5] } });
  st = await state(); assert.deepStrictEqual(st.layers[0].clips[0].gen.params.isf, { level: 0.5, tint: '#00ff00', side: 1, invert: true, spot: [0.2, 0.3] });
  await cmd({ op: 'set', path: 'layers.0.clips.0.gen.params.isf.level', value: 0.25 }); await cmd({ op: 'set', path: 'layers.0.clips.0.gen.params.isf.spot.1', value: 0.9 });
  st = await state(); assert.strictEqual(st.layers[0].clips[0].gen.params.isf.level, 0.25); assert.strictEqual(st.layers[0].clips[0].gen.params.isf.spot[1], 0.9);
  // effect slot
  await cmd({ op: 'set', path: 'layers.1.fx.isf.shader', value: 'fx1' }); await cmd({ op: 'set', path: 'layers.1.fx.isf.on', value: true });
  await cmd({ op: 'isfVals', path: 'layers.1.fx.isf', key: 'v', reset: true, vals: { amount: 0.75 } });
  st = await state(); assert.deepStrictEqual(st.layers[1].fx.isf.v, { amount: 0.75 }); assert.ok(st.layers[1].fx.isf.on);
  const bad = await cmd({ op: 'isfVals', path: 'layers.0.__proto__', key: 'isf', vals: { a: 1 } }); assert.ok(bad.error || bad.ok === false || !({}).a, 'prototype path refused');
  ok('isfVals fills / resets value bags (only plain numbers, bools, short strings, small vectors); "set" then drives single inputs and point components');
  // older shows: ISF metadata backfilled on load
  const show = await state(); for (const x of show.shaders) delete x.isf; fs.writeFileSync(path.join(DATA, 'state.json'), JSON.stringify(show)); srv.kill(); await tick(400);
  const srv2 = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8897, OSC_PORT: 8898, DATA_DIR: DATA, MEDIA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxisfm-')) }, stdio: 'ignore' }); kids.push(srv2);
  for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  st = await state(); assert.strictEqual(sh('gen1').isf && sh('gen1').isf.kind, 'generator'); assert.strictEqual(sh('fx1').isf.kind, 'effect');
  ok('ISF metadata backfilled for shaders saved by older versions');
  console.log('ISF test passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
