# Projection onto a 3D object in real Chrome: an output as a projector draws the model (UV-mapped composition) from its
# position; a second projector reaching the same surface halves each one's share (blend); the coverage map counts projectors;
# content-camera mode throws the composition onto the object.
import json, urllib.request, subprocess, os, time, sys, tempfile, signal, copy
from playwright.sync_api import sync_playwright
from PIL import Image
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, os.path.join(ROOT, 'tests', 'fixtures', 'gltf')); import make_glb
CHROME = sys.argv[1] if len(sys.argv) > 1 else '/usr/bin/google-chrome'; B = 'http://127.0.0.1:9071'; tmp = tempfile.mkdtemp()
srv = subprocess.Popen(['node', 'server.js'], cwd=ROOT, env=dict(os.environ, PORT='9071', OSC_PORT='9072', DATA_DIR=tmp + '/d', MEDIA_DIR=tmp + '/m'), stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
def req(p, body=None, raw=None):
  r = urllib.request.Request(B + p, data=raw if raw is not None else (json.dumps(body).encode() if body is not None else None), headers={'Content-Type': 'application/json'}, method='POST' if (raw is not None or body is not None) else 'GET')
  return json.loads(urllib.request.urlopen(r).read() or b'{}')
for _ in range(60):
  try: req('/api/info'); break
  except Exception: time.sleep(0.2)
cmd = lambda c: req('/api/cmd', c); ok = lambda m: print('✓ ' + m)
try:
  quad = req('/api/models?name=Panel.glb', raw=make_glb.textured_quad())['model']
  for k, v in [('comp.width', 640), ('comp.height', 360)]: cmd({'op': 'set', 'path': k, 'value': v})
  cmd({'op': 'assign', 'layer': 0, 'slot': 0, 'clip': {'type': 'gen', 'name': 'r', 'gen': {'kind': 'solid', 'params': {'c1': '#ff0000'}}}}); cmd({'op': 'trigger', 'layer': 0, 'clip': 0})
  outs = req('/api/state')['outputs']; o0 = outs[0]; pj = dict(o0['projector'], on=True, model=quad['id'], pos=[0, 0, 4], target=[0, 0, 0], throwRatio=1.6)
  o0['projector'] = pj; cmd({'op': 'set', 'path': 'outputs', 'value': [o0]})
  with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=['--use-gl=swiftshader', '--enable-unsafe-swiftshader']); pg = b.new_page(viewport={'width': 640, 'height': 360}); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(B + '/clean?out=main&fs=0'); time.sleep(2.5)
    def shot(): pg.screenshot(path=tmp + '/p.png'); return Image.open(tmp + '/p.png').convert('RGB')
    im = shot(); c, edge = im.getpixel((320, 180)), im.getpixel((20, 180)); row = [x for x in range(0, 640, 2) if im.getpixel((x, 180))[0] > 100]
    w = (max(row) - min(row)) / 640 if row else 0
    assert c[0] > 200 and c[1] < 40 and edge == (0, 0, 0) and abs(w - 0.8) < 0.04, (c, edge, w, pg.evaluate('() => engine.projError || null')); ok(f'projector 4 m away, throw 1.6: the 2 m panel fills {w:.0%} of the picture with the composition')
    o1 = copy.deepcopy(o0); o1['id'] = 'p2'; o1['name'] = 'Projector 2'; o1['projector'] = dict(pj, pos=[3, 0, 4]); cmd({'op': 'set', 'path': 'outputs', 'value': [o0, o1]}); time.sleep(1)
    c2 = shot().getpixel((320, 180)); assert 90 < c2[0] < 190, c2; ok(f'a second projector on the same surface: this one\'s share drops ({c[0]} → {c2[0]})')
    cmd({'op': 'set', 'path': 'outputs.0.projector.heat', 'value': True}); time.sleep(0.8); h = shot().getpixel((320, 180)); assert h[0] > 120 and h[1] > 100 and h[2] < 60, h; ok(f'coverage map: yellow where two projectors meet {h}')
    cmd({'op': 'set', 'path': 'outputs.0.projector.heat', 'value': False}); cmd({'op': 'set', 'path': 'outputs.0.projector.blend', 'value': False}); time.sleep(0.8); assert shot().getpixel((320, 180))[0] > 200; ok('blend off: full brightness')
    cmd({'op': 'set', 'path': 'outputs.0.projector.mode', 'value': 'camera'}); time.sleep(0.8); assert shot().getpixel((320, 180))[0] > 200; ok('content-camera mode throws the composition onto the object')
    assert not errs, errs; b.close()
  print('Projection check passed')
finally: srv.send_signal(signal.SIGTERM)
