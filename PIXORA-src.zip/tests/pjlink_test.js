// PJLink projector control against a simulated projector: MD5 password auth, power / input / mute / freeze,
// status polling (power, input, lamp hours, errors, input names), error replies, and the Health alerts.
//   node tests/pjlink_test.js
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert'), net = require('net'), crypto = require('crypto');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
const PJ = require(path.join(ROOT, 'server-pjlink.js'))({ Device: class {}, net, dgram: require('dgram'), crypto });
// --- simulated projector (class 2, password "panasonic") ---
const proj = { power: '0', input: '31', mute: '30', erst: '000000', lamp: '1234 0', freeze: '0', log: [] };
function projector(password) {
  return net.createServer(s => {
    const rnd = crypto.randomBytes(4).toString('hex'); s.write(password ? `PJLINK 1 ${rnd}\r` : 'PJLINK 0\r'); let buf = '';
    s.on('data', d => { buf += d; let k; while ((k = buf.indexOf('\r')) >= 0) { let line = buf.slice(0, k); buf = buf.slice(k + 1);
      if (password) { const want = crypto.createHash('md5').update(rnd + password).digest('hex'); if (line.slice(0, 32) !== want) { s.write('PJLINK ERRA\r'); return s.end(); } line = line.slice(32); }
      proj.log.push(line); const m = /^%(\d)(\w{4}) (.*)$/.exec(line); if (!m) continue; const [, c, cmd, p] = m; const rep = v => s.write(`%${c}${cmd}=${v}\r`);
      if (p === '?') rep({ POWR: proj.power, INPT: proj.input, AVMT: proj.mute, ERST: proj.erst, LAMP: proj.lamp, NAME: 'Hall left', INF1: 'PANASONIC', INF2: 'PT-RZ120', INST: '11 31 32 52', CLSS: '2', FILT: '320', FREZ: proj.freeze }[cmd] ?? 'ERR1');
      else if (cmd === 'INNM') rep({ '?31': 'HDMI 1', '?32': 'HDMI 2', '?11': 'Computer', '?52': 'Digital Link' }[p] || 'ERR2');
      else if (cmd === 'POWR') { proj.power = p === '1' ? '1' : '0'; rep('OK'); }
      else if (cmd === 'INPT') { if (proj.power !== '1') rep('ERR3'); else if (!['11', '31', '32', '52'].includes(p)) rep('ERR2'); else { proj.input = p; rep('OK'); } }
      else if (cmd === 'AVMT') { proj.mute = p; rep('OK'); } else if (cmd === 'FREZ') { proj.freeze = p; rep('OK'); } else rep('ERR1'); } });
  });
}
(async () => {
  const S = projector('panasonic'); await new Promise(r => S.listen(8952, '127.0.0.1', r));
  let r = await PJ.session('127.0.0.1', 8952, 'panasonic', ['%1POWR ?', '%1INF2 ?']); assert.deepStrictEqual(r, ['0', 'PT-RZ120']); ok('MD5 password handshake and queries');
  await assert.rejects(PJ.session('127.0.0.1', 8952, 'wrong', ['%1POWR ?']), /wrong PJLink password/); await assert.rejects(PJ.session('127.0.0.1', 8952, '', ['%1POWR ?']), /needs its PJLink password/); ok('wrong / missing password reported clearly');
  r = await PJ.session('127.0.0.1', 8952, 'panasonic', ['%1INPT 31']); assert.ok(r[0] instanceof Error && r[0].code === 'ERR3'); ok('ERR3 (unavailable while in standby) surfaced as an error');

  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxpj-'));
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8955, OSC_PORT: 8956, DATA_DIR: DATA, MEDIA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxpjm-')) }, stdio: 'ignore' }); kids.push(srv);
  const B = 'http://127.0.0.1:8955'; for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const json = (u, b) => fetch(B + u, b ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) } : undefined).then(async r => { const j = await r.json(); if (!r.ok) throw new Error(j.error); return j; });
  const types = (await json('/api/devices')).types; assert.ok(types.pjlink && types.pjlink.projector && types.pjlink.port === 4352); ok('PJLink device type listed');
  const dev = await json('/api/devices', { type: 'pjlink', name: 'Hall L', host: '127.0.0.1', port: 8952, password: 'panasonic', opts: { lampWarn: 1000 } });
  const id = dev.id || (dev.device && dev.device.id) || (await json('/api/devices')).devices.find(d => d.name === 'Hall L').id;
  const view = async () => (await json('/api/devices')).devices.find(d => d.id === id);
  for (let i = 0; i < 40 && !(await view()).state.online; i++) await tick(150);
  let v = await view(); assert.ok(v.state.online && v.projector); assert.strictEqual(v.state.info.model, 'PT-RZ120'); assert.strictEqual(v.state.info.power, 'standby');
  assert.deepStrictEqual(v.state.inputs.map(x => x.name), ['Computer', 'HDMI 1', 'HDMI 2', 'Digital Link']); assert.strictEqual(v.state.info.filterHours, 320);
  assert.ok(v.state.health.alerts.some(a => /lamp at 1234 h/.test(a.msg))); ok('status: model, power, input names (class 2), filter hours, lamp-hours warning');
  const act = (action, args) => json('/api/devices/' + id + '/' + action, args).catch(e => ({ error: e.message }));
  let a = await act('input', { input: 'HDMI 2' }); assert.ok(a.error && /not possible right now/.test(a.error), JSON.stringify(a)); ok('input change in standby explains why it failed');
  await act('power', { on: true }); assert.strictEqual(proj.power, '1');
  await act('input', { input: 'hdmi 2' }); assert.strictEqual(proj.input, '32');
  await act('mute', { on: true }); assert.strictEqual(proj.mute, '31'); await act('videoMute', { on: false }); assert.strictEqual(proj.mute, '10');
  await act('freeze', { on: true }); assert.strictEqual(proj.freeze, '1');
  a = await act('input', { input: 'SDI 9' }); assert.ok(/unknown input/.test(a.error) && /HDMI 1 \(31\)/.test(a.error)); ok('power on, input by name, picture+sound mute, picture unmute, freeze; unknown input lists the real ones');
  proj.erst = '020100'; await tick(1500); await act('power', { on: true }); await tick(700); v = await view();
  assert.ok(v.state.health.alerts.some(a => a.lvl === 'err' && /lamp error/.test(a.msg)) && v.state.health.alerts.some(a => /cover open warning/.test(a.msg))); ok('projector error status (lamp error, cover warning) raised as Health alerts');
  // via a cue action (Device action)
  await json('/api/cmd', { op: 'runAction', action: { type: 'device', device: 'Hall L', action: 'power', args: { on: false } } }); await tick(500); assert.strictEqual(proj.power, '0'); ok('“Device action” in cues / keys / timeline drives the projector');
  S.close(); process.exit(0);
})().catch(e => { console.error('✗', e.stack || e.message); process.exit(1); });
