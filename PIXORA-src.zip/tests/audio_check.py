# Audio outputs in real Chrome: a clip's sound reaches the bus its layer (or the clip itself) is routed to, re-routes live,
# output gain / mute / delay apply per bus, the program mix (recording, NDI) keeps everything, and a channel pair the device
# doesn't have is reported. Needs Python Playwright, Chrome and ffmpeg:  python3 tests/audio_check.py [path-to-chrome]
import json, urllib.request, subprocess, os, time, sys, tempfile
from playwright.sync_api import sync_playwright
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); CHROME = sys.argv[1] if len(sys.argv) > 1 else '/usr/bin/google-chrome'
B = 'http://127.0.0.1:8923'; tmp = tempfile.mkdtemp(); M = tmp + '/m'; os.makedirs(M)
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=blue:s=160x90:d=30', '-f', 'lavfi', '-i', 'sine=f=440:d=30', '-shortest', '-c:v', 'libx264', '-c:a', 'aac', M + '/tone.mp4'], check=True)
srv = subprocess.Popen(['node', 'server.js'], cwd=ROOT, env=dict(os.environ, PORT='8923', OSC_PORT='8924', DATA_DIR=tmp + '/d', MEDIA_DIR=M), stdout=open(tmp + '/log', 'w'), stderr=subprocess.STDOUT)
def cmd(b): return json.loads(urllib.request.urlopen(urllib.request.Request(B + '/api/cmd', data=json.dumps(b).encode(), headers={'Content-Type': 'application/json'})).read() or b'{}')
def state(): return json.loads(urllib.request.urlopen(B + '/api/state').read())
for _ in range(60):
  try: urllib.request.urlopen(B + '/api/info'); break
  except Exception: time.sleep(0.2)
ok = lambda m: print('✓ ' + m)
try:
  cmd({'op': 'assign', 'layer': 0, 'slot': 0, 'clip': {'type': 'video', 'name': 'Tone', 'src': 'local/tone.mp4'}}); cmd({'op': 'trigger', 'layer': 0, 'clip': 0})
  cmd({'op': 'audioOutAdd', 'name': 'Record feed', 'ch': 1}); cmd({'op': 'audioOutAdd', 'name': 'Far channels', 'ch': 7})
  outs = state()['comp']['audioOuts']; rec, far = outs[1]['id'], outs[2]['id']
  with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=['--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--autoplay-policy=no-user-gesture-required'])
    pg = b.new_page(viewport={'width': 320, 'height': 180}); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(B + '/clean?out=main&fs=0'); time.sleep(1); pg.mouse.click(160, 90); time.sleep(3)
    lv = lambda: pg.evaluate("() => { const o = {}; for (const [id, b] of abus.bus) o[id] = peakDb(b.an); o.program = peakDb(meters.master); return o; }")
    def until(cond, t=5):  # state reaches the output in about a second; poll instead of guessing
      end = time.time() + t
      while True:
        v = lv()
        if cond(v) or time.time() > end: return v
        time.sleep(0.25)
    l = lv(); assert l['main'] > -20 and l.get(rec, -60) <= -59 and l['program'] > -20, l; ok(f'layer on Main: Main {l["main"]} dB, Record feed silent, program mix {l["program"]} dB')
    cmd({'op': 'set', 'path': 'layers.0.audioOut', 'value': rec}); l = until(lambda v: v[rec] > -20 and v['main'] <= -59)
    assert l[rec] > -20 and l['main'] <= -59 and l['program'] > -20, l; ok('layer re-routed live to Record feed; Main goes silent; program mix unchanged')
    cmd({'op': 'clipAudioOut', 'layer': 0, 'slot': 0, 'out': 'main'}); l = until(lambda v: v['main'] > -20 and v[rec] <= -59); time.sleep(0.5); l = lv(); assert l['main'] > -20 and l[rec] <= -59, l; ok('the clip overrides its layer’s output')
    cmd({'op': 'set', 'path': 'comp.audioOuts.0.gain', 'value': 0.5}); time.sleep(1.2); l2 = lv(); assert -9 < l2['main'] - l['main'] < -4, (l, l2); ok(f'output gain 0.5 → {l2["main"] - l["main"]:.1f} dB')
    cmd({'op': 'set', 'path': 'comp.audioOuts.0.mute', 'value': True}); l3 = until(lambda v: v['main'] <= -59); assert l3['main'] <= -59 and l3['program'] > -20, l3; ok('mute an output; the program mix keeps the audio')
    cmd({'op': 'set', 'path': 'comp.audioOuts.0.delay', 'value': 250}); time.sleep(1.2); d = pg.evaluate("() => abus.bus.get('main').delay.delayTime.value"); assert 0.2 < d <= 0.26, d; ok('delay per output (250 ms)')
    st = pg.evaluate("() => abus.status"); assert st['main']['ok'] and st[rec]['ok'] and not st[far]['ok'] and 'channel 7' in st[far]['error'], st; ok(f'channel pair 7–8 on a {st["main"]["channels"]}-channel device is reported: “{st[far]["error"]}”')
    dev = json.loads(urllib.request.urlopen(B + '/api/audio/devices').read()); assert any(x['id'] == far and not x['ok'] for x in dev['buses']), dev; ok('bus status reported to the server for the mixer')
    cmd({'op': 'audioOutDel', 'id': rec}); time.sleep(2.5); assert rec not in pg.evaluate("() => [...abus.bus.keys()]"); ok('removed outputs are torn down')
    assert not errs, errs; b.close()
  print('Audio check passed')
finally: srv.terminate()
