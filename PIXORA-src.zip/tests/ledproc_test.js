// LED processor control against simulated processors: Novastar COEX (HTTP), Novastar controller (TCP 55 AA frames),
// Novastar H series (UDP JSON), Megapixel HELIOS (REST) and a DMX-controlled processor (Art-Net).
//   node tests/ledproc_test.js
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert'), http = require('http'), net = require('net'), dgram = require('dgram');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
const hex = b => [...b].map(x => x.toString(16).padStart(2, '0')).join(' ');
(async () => {
  // --- fake processors
  const coex = [], helios = [], novaTcp = [], novaH = [], art = [];
  const httpFake = (log, handler) => http.createServer((q, r) => { let b = ''; q.on('data', d => b += d); q.on('end', () => { log.push({ m: q.method, p: q.url, b: b ? JSON.parse(b) : null, auth: q.headers.authorization }); const out = handler(q); r.writeHead(200, { 'Content-Type': 'application/json' }); r.end(JSON.stringify(out)); }); });
  const C = httpFake(coex, q => q.url.endsWith('/preset') ? { code: 0, data: { data: [{ sequenceNumber: 3, name: 'Day' }, { sequenceNumber: 4, name: 'Night' }] } } : q.url.endsWith('/input/sources') ? { code: 0, data: { data: [{ groupId: 7, name: 'HDMI 1' }] } } : q.url.endsWith('/monitor/info') ? { code: 0, data: { mainBoardTemperature: { value: 41, status: 0 }, fanInfos: [{ fanSpeed: 3000, status: 0 }, { fanSpeed: 0, status: 1 }],
    controllerPortMonitorInfos: [{ controllerPortID: 0, status: 0 }, { controllerPortID: 1, status: 2 }],
    cabinets: [{ CabinetID: 1, outPutID: 0, index: 0, rvCards: [{ netPortIndex: 0, cabinetIndex: 0, temperature: { value: 52, status: 0 }, voltage: { value: 5, status: 0 }, errorBit: [{ value: 0 }], nextCabinetLinkStatus: { linkStatus: true, status: 0 } }] },
      { CabinetID: 2, outPutID: 0, index: 1, rvCards: [{ netPortIndex: 0, cabinetIndex: 1, temperature: { value: 78, status: 1 }, voltage: { value: 5, status: 0 }, errorBit: [{ value: 12 }], nextCabinetLinkStatus: { linkStatus: false, status: 1 } }] }] } } : { code: 0, data: {} });
  await new Promise(r => C.listen(8841, '127.0.0.1', r));
  const H = httpFake(helios, q => q.url.startsWith('/api/v1/presets/list') ? [{ id: 'p1', name: 'Show' }] : q.url.startsWith('/api/v1/public?') ? { dev: { display: { brightness: 80, blackout: false } }, sys: { description: 'Helios A' } } : q.url === '/api/v1/public' ? { dev: { ingest: { input: { signal: false } }, tiles: [{ temperature: 45 }, { temperature: 74 }], errors: 0 } } : {});
  await new Promise(r => H.listen(8842, '127.0.0.1', r));
  const T = net.createServer(s => s.on('data', d => novaTcp.push(d))); await new Promise(r => T.listen(8843, '127.0.0.1', r));
  const U = dgram.createSocket('udp4'); U.on('message', (m, ri) => { novaH.push(JSON.parse(m.toString())); U.send(Buffer.from('[{"cmd":"W0120","code":0}]'), ri.port, ri.address); }); await new Promise(r => U.bind(8844, '127.0.0.1', r));
  const A = dgram.createSocket({ type: 'udp4', reuseAddr: true }); A.on('message', b => { if (b.toString('latin1', 0, 7) === 'Art-Net') art.push({ uni: b[14], data: b.subarray(18, 30) }); }); await new Promise(r => A.bind(6454, '127.0.0.1', r));
  // --- PIXORA
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8839, OSC_PORT: 8840, DATA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxlp-')), MEDIA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxlpm-')) }, stdio: 'ignore' }); kids.push(srv);
  const B = 'http://127.0.0.1:8839';
  for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const add = d => fetch(B + '/api/devices', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(d) }).then(async r => { if (!r.ok) throw new Error(await r.text()); return r.json(); });
  const act = (id, a, args) => fetch(`${B}/api/devices/${id}/${a}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(args || {}) }).then(async r => { if (!r.ok) throw new Error(await r.text()); return r.json(); });
  const list = await fetch(B + '/api/devices').then(r => r.json()); for (const t of ['nova-coex', 'nova-ctrl', 'nova-h', 'helios', 'led-dmx']) assert.ok(list.types[t] && list.types[t].led, t); ok('5 LED processor types in the Devices hub');
  // Novastar COEX
  const c = await add({ type: 'nova-coex', name: 'MX40', host: '127.0.0.1', port: 8841 }); await tick(600);
  const v = (await fetch(B + '/api/devices').then(r => r.json())).devices.find(d => d.id === c.id); assert.ok(v.state.online, 'coex online'); assert.deepStrictEqual(v.state.presets.map(p => p.name), ['Day', 'Night']);
  await act(c.id, 'brightness', { value: 40 }); await act(c.id, 'blackout', { on: true }); await act(c.id, 'freeze', { on: true }); await act(c.id, 'normal'); await act(c.id, 'preset', { preset: 'Night' }); await act(c.id, 'input', { input: 'HDMI 1' }); await tick(100);
  const W = coex.filter(x => x.m === 'PUT');
  assert.deepStrictEqual(W[0], { m: 'PUT', p: '/api/v1/device/cabinet/brightness', b: { ratio: 0.4, idList: [16777215] }, auth: undefined });
  assert.deepStrictEqual(W.slice(1, 4).map(x => x.b && x.b.value), [1, 2, 0]); assert.ok(W.slice(1, 4).every(x => x.p === '/api/v1/device/screen/displaymode'));
  assert.ok(W.find(x => x.p === '/api/v1/device/currentpreset' && x.b.sequenceNumber === 4)); assert.ok(W.find(x => x.p === '/api/v1/device/screen/input' && x.b.groupId === 7));
  ok('Novastar COEX: presets read; brightness 40 %, blackout, freeze, normal, preset “Night”, input “HDMI 1”');
  // Novastar controller (TCP)
  const n = await add({ type: 'nova-ctrl', name: 'VX', host: '127.0.0.1', port: 8843, opts: { model: 'vxPro' } }); await tick(500);
  await act(n.id, 'brightness', { value: 0 }); await act(n.id, 'brightness', { value: 100 }); await act(n.id, 'preset', { preset: 1 }); await act(n.id, 'blackout', { on: true }); await tick(200);
  const frames = Buffer.concat(novaTcp); const fr = []; for (let o = 0; o < frames.length;) { const len = frames[o + 16] | (frames[o + 17] << 8); fr.push(frames.subarray(o, o + 18 + len + 2)); o += 18 + len + 2; }
  assert.strictEqual(hex(fr[0]), '55 aa 00 00 fe ff 01 ff ff ff 01 00 01 00 00 02 01 00 00 55 5a', '0%');
  assert.strictEqual(hex(fr[1]), '55 aa 00 00 fe ff 01 ff ff ff 01 00 01 00 00 02 01 00 ff 54 5b', '100%');
  assert.strictEqual(hex(fr[2]), '55 aa 00 00 fe 00 00 00 00 00 01 00 00 01 51 13 01 00 00 ba 56', 'preset 1');
  assert.ok(fr[3] && fr[3][0] === 0x55, 'blackout frame'); ok('Novastar VX Pro (TCP): brightness 0 % / 100 % and preset 1 match the published frames byte for byte');
  let bad = null; try { await act(n.id, 'input', { input: 'nope' }); } catch (e) { bad = e.message; } assert.ok(/no input .*nope/.test(bad), bad); ok('unknown input names are refused with the model’s list');
  // Novastar H series (UDP)
  const h = await add({ type: 'nova-h', name: 'H5', host: '127.0.0.1', port: 8844, opts: { screenId: 2 } }); await tick(300);
  await act(h.id, 'brightness', { value: 60 }); await act(h.id, 'preset', { preset: 5 }); await act(h.id, 'freeze', { on: true }); await act(h.id, 'blackout', { on: false }); await tick(300);
  const cmds = novaH.map(x => x[0]).filter(x => x.cmd !== 'R0400');
  assert.deepStrictEqual(cmds, [{ screenId: 2, brightness: 60, cmd: 'W0410', deviceId: 0 }, { screenId: 2, presetId: 5, cmd: 'W0605', deviceId: 0 }, { screenId: 2, enable: 1, cmd: 'W040A', deviceId: 0 }, { screenId: 2, type: 1, cmd: 'W0409', deviceId: 0 }]);
  ok('Novastar H series (UDP JSON): brightness, preset, freeze, blackout off on screen 2');
  // HELIOS
  const x = await add({ type: 'helios', name: 'Helios', host: '127.0.0.1', port: 8842, user: 'admin', password: 'pw' }); await tick(600);
  await act(x.id, 'brightness', { value: 0.25 }); await act(x.id, 'blackout', { on: true }); await act(x.id, 'test', { pattern: 'grid' }); await act(x.id, 'preset', { preset: 'Show' }); await tick(150);
  const hp = helios.filter(r => r.m !== 'GET');
  assert.deepStrictEqual(hp.map(r => [r.m, r.p, r.b]), [['PATCH', '/api/v1/public', { dev: { display: { brightness: 25 } } }], ['PATCH', '/api/v1/public', { dev: { display: { blackout: true } } }], ['PATCH', '/api/v1/public', { dev: { ingest: { testPattern: { enabled: true } } } }], ['POST', '/api/v1/presets/p1/apply', null]]);
  assert.strictEqual(hp[0].auth, 'Basic ' + Buffer.from('admin:pw').toString('base64')); ok('Megapixel HELIOS: brightness 25 %, blackout, test pattern, preset “Show” (with login)');
  // DMX
  const d = await add({ type: 'led-dmx', name: 'Tessera', host: '127.0.0.1', opts: { protocol: 'artnet', universe: 5, chBright: 1, chPreset: 2, presetStep: 10, chBlackout: 3 } }); await tick(200);
  await act(d.id, 'brightness', { value: 50 }); await act(d.id, 'preset', { preset: 3 }); await act(d.id, 'blackout', { on: true }); await tick(300);
  const last = art.filter(a => a.uni === 5).pop(); assert.deepStrictEqual([...last.data.subarray(0, 3)], [128, 30, 255]); ok('DMX-controlled processor: Art-Net universe 5 — brightness 50 % → 128, preset 3 × 10 → 30, blackout → 255');
  let nochan = null; try { await act(d.id, 'freeze', { on: true }); } catch (e) { nochan = e.message; } assert.ok(/no DMX channel/.test(nochan)); ok('a function with no channel set explains what to fill in');
  // the same controls from a cue / key action
  await fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ op: 'runAction', action: { type: 'device', device: 'MX40', action: 'brightness', args: '{"value":70}' } }) }); await tick(200);
  assert.ok(coex.find(r => r.p === '/api/v1/device/cabinet/brightness' && r.b.ratio === 0.7)); ok('“Device action” in cues and keys drives the processor (MX40 brightness 70 %)');
  // health monitoring
  let dv = (await fetch(B + '/api/devices').then(r => r.json())).devices; const hc = dv.find(d => d.type === 'nova-coex').state.health, hh = dv.find(d => d.type === 'helios').state.health;
  assert.ok(hc, 'coex health'); assert.strictEqual(hc.temp, 78); assert.strictEqual(hc.board, 41); assert.strictEqual(hc.cards, 2); assert.strictEqual(hc.cardsBad, 1); assert.strictEqual(hc.ports, 2); assert.strictEqual(hc.portsBad, 1);
  const msgs = hc.alerts.map(a => a.msg).join(' | ');
  for (const k of ['fan 2 fault', 'output port 2 fault', 'port 1 card 2 at 78°C', 'data link broken after port 1 card 2', '12 data bit errors']) assert.ok(msgs.includes(k), k + ' in ' + msgs);
  ok('Novastar COEX monitoring: temperatures, cards, ports, fans, bit errors, broken data link');
  assert.ok(hh && hh.generic); assert.strictEqual(hh.temp, 74); assert.ok(hh.alerts.some(a => /no input signal/.test(a.msg)) && hh.alerts.some(a => /74°C/.test(a.msg))); ok('HELIOS status fields read (hottest tile, input signal)');
  for (const s of [C, H, T]) s.close(); U.close(); A.close(); console.log('ledproc_test: all passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
