// Main/backup failover: mirroring, manual takeover with actions, read-only primary, hand-back with the show synced back,
// automatic takeover when the primary dies, and staying in control when it returns.
//   node tests/failover_test.js
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill('SIGKILL'); } catch {} }));
const P = 'http://127.0.0.1:8881', K = 'http://127.0.0.1:8883';
const DP = fs.mkdtempSync(path.join(os.tmpdir(), 'pxfoP-')), DK = fs.mkdtempSync(path.join(os.tmpdir(), 'pxfoK-')), MEDIA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxfoM-'));
function start(port, osc, data) { const k = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: port, OSC_PORT: osc, DATA_DIR: data, MEDIA_DIR: MEDIA }, stdio: 'ignore' }); kids.push(k); return k; }
const up = async B => { for (let i = 0; i < 80 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150); };
const cmd = (B, c) => fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(c) });
const st = B => fetch(B + '/api/state').then(r => r.json());
const bk = (B, action) => fetch(B + '/api/backup', action ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action }) } : undefined).then(r => r.json());
const until = async (f, ms = 8000, what = 'condition') => { const t0 = Date.now(); while (Date.now() - t0 < ms) { if (await f()) return; await tick(150); } throw new Error('timed out waiting for ' + what); };
(async () => {
  let prim = start(8881, 8882, DP); start(8883, 8884, DK); await up(P); await up(K);
  await fetch(K + '/api/settings', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ backup: { mode: 'backup', primary: P, failoverSec: 1, selfUrl: K } }) });
  await until(async () => (await bk(K)).connected, 8000, 'backup to connect');
  const ps = await bk(P); assert.strictEqual(ps.mirrors.length, 1); assert.strictEqual(ps.mirrors[0].url, K); ok('backup connects; the primary knows its address for controllers to follow');

  await cmd(P, { op: 'set', path: 'comp.master', value: 0.6 });
  await cmd(P, { op: 'set', path: 'failover', value: { onTakeover: [{ type: 'master', value: 0.25 }], onReturn: [{ type: 'master', value: 0.9 }] } });
  await until(async () => { const s = await st(K); return s.comp.master === 0.6 && s.failover.onTakeover.length === 1; }, 5000, 'mirror'); ok('show changes (and takeover actions) mirror to the backup');

  // manual takeover
  const r = await bk(K, 'takeover'); assert.ok(r.ok); let s = await st(K); assert.strictEqual(s.comp.master, 0.25, 'takeover action ran');
  await until(async () => !!(await bk(P)).held, 4000, 'primary to see backup in control'); ok('manual takeover runs the takeover actions; the primary shows the backup in control');
  // primary operators are read-only (WS commands rejected), backup ignores the primary's state now
  const ws = new WebSocket(P.replace('http', 'ws') + '/ws?role=control'); const msgs = []; ws.onmessage = e => { try { msgs.push(JSON.parse(e.data)); } catch {} };
  await new Promise(r => ws.onopen = r); ws.send(JSON.stringify({ t: 'cmd', cmd: { op: 'set', path: 'comp.speed', value: 1.7 } })); await tick(400);
  assert.ok(msgs.some(m => m.t === 'error' && /backup server is in control/.test(m.msg))); assert.notStrictEqual((await st(P)).comp.speed, 1.7); ok('primary controllers are read-only while the backup holds control');
  await cmd(K, { op: 'set', path: 'comp.speed', value: 1.3 }); await tick(300); assert.strictEqual((await st(K)).comp.speed, 1.3); ok('the backup takes commands while in control');

  // hand back: show syncs to the primary, return actions run
  assert.ok((await bk(K, 'handback')).ok); await until(async () => (await st(P)).comp.speed === 1.3, 4000, 'sync back');
  const kb = await bk(K); assert.strictEqual(kb.active, false); assert.strictEqual((await st(K)).comp.master, 0.9); assert.ok(!(await bk(P)).held);
  ok('hand-back sends the show to the primary, runs return actions and goes back to mirroring');
  ws.close();

  // primary dies → automatic takeover
  prim.kill('SIGKILL'); await until(async () => (await bk(K)).active, 6000, 'auto takeover'); assert.strictEqual((await bk(K)).reason, 'primary lost'); ok('primary killed → backup takes over automatically');
  await cmd(K, { op: 'set', path: 'comp.speed', value: 0.7 });
  let e = await bk(K, 'handback').catch(x => x); assert.ok(e.error && /not reachable/.test(e.error)); ok('hand-back refused while the primary is down');
  // primary returns → backup stays in control until handed back
  prim = start(8881, 8882, DP); await up(P);
  await until(async () => (await bk(K)).primaryBack, 8000, 'primary back'); assert.strictEqual((await bk(K)).active, true); await until(async () => !!(await bk(P)).held, 4000, 'held');
  ok('primary returns → backup keeps control and the primary is read-only');
  assert.ok((await bk(K, 'handback')).ok); await until(async () => (await st(P)).comp.speed === 0.7, 4000, 'sync back 2'); ok('changes made during the outage are handed back to the primary');

  // primary-side "hand control to the backup"
  assert.ok((await bk(P, 'handover')).ok); await until(async () => (await bk(K)).active, 4000, 'handover'); assert.strictEqual((await bk(K)).reason, 'requested by the primary'); ok('primary can hand control to the backup');
  process.exit(0);
})().catch(e => { console.error('✗', e.message); process.exit(1); });
