// DeckLink genlock in the native module, against the fake driver in tests/fixtures/decklink-fake (build: see that folder's README).
//   LD_LIBRARY_PATH=<fake driver dir> FAKE_REF=1 PIXORA_DECKLINK_ADDON=<built module> node tests/decklink_genlock_native.js
const d = require(process.env.PIXORA_DECKLINK_ADDON || '/tmp/pixora_decklink-linux-x64.node'), fs = require('fs'), assert = require('assert'); const ok = m => console.log('✓ ' + m);
const tick = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  const o = d.openOutput(0, '1080p50'); let st = d.status(o.handle);
  assert.strictEqual(st.scheduled, false); assert.strictEqual(st.fps, 50); assert.strictEqual(st.referenceKnown, true); assert.strictEqual(st.referenceLocked, process.env.FAKE_REF === '1');
  if (process.env.FAKE_REF === '1') assert.strictEqual(st.reference, '1080p50'); ok(`status: reference ${st.referenceLocked ? 'locked to ' + st.reference : 'not connected'}, ${st.fps} fps`);
  assert.strictEqual(d.startScheduled(o.handle, 3), true);
  const buf = n => { const b = Buffer.alloc(1920 * 1080 * 4); b[0] = n & 255; return b; };
  // the "renderer": a 60 Hz-ish paint loop with jitter, faster than the 50 fps card clock
  let n = 0; const t0 = Date.now();
  while (Date.now() - t0 < 1500) { const r = d.schedule(o.handle, buf(++n), 1920, 1080); await tick(14 + Math.random() * 6); }
  st = d.status(o.handle); const log = fs.readFileSync('/tmp/dlfake/sched.log', 'utf8').trim().split('\n').map(l => l.split(' ').map(Number));
  const frames = log.map(x => x[0]); const shown = log.length;
  for (let i = 1; i < frames.length; i++) assert.strictEqual(frames[i], frames[i - 1] + 1, 'one picture on every card frame, no gaps');
  assert.ok(shown >= 60 && shown <= 80, `~75 card frames in 1.5 s at 50 fps, got ${shown}`); assert.ok(st.buffered <= 5, 'queue stays short: ' + st.buffered); assert.ok(st.started);
  ok(`scheduled playback: ${shown} consecutive card frames, queue ${st.buffered}, ${st.late + st.dropped} late, ${st.underruns} underruns (extra pictures dropped before queueing)`);
  // starve it: the card keeps going, PIXORA rejoins just ahead of the card clock
  await tick(300); const r = d.schedule(o.handle, buf(200), 1920, 1080); assert.ok(r.ok); st = d.status(o.handle); assert.ok(st.underruns >= 1); ok('after a stall, scheduling rejoins ahead of the card (counted as an underrun)');
  d.close(o.handle); ok('stops cleanly');
})().catch(e => { console.error('✗', e.stack); process.exit(1); });
