// PIXORA → QForge feedback module test (no network).
'use strict';
const assert = require('assert');
const sent = [];
const settings = {};
const state = { layers: [{ active: 0, paused: false, clips: [{ type: 'video', name: 'Intro.mp4' }] }, { active: null, clips: [] }], cueIndex: 2, cues: [{}, {}, { name: 'Walk-in' }] };
const q = require('../server-qforge.js')({ settings, saveSettings() {}, state, oscMsg: (a, b) => ({ a, b }), sock: () => ({ send: (m, port, host) => sent.push(Object.assign({ port, host }, m)) }), monitor() {} });
(async () => {
  q.positions([{ pos: 0.5, t: 5, dur: 10 }]); assert.strictEqual(sent.length, 0, 'off by default');
  let out; await q.http('/api/qforge', { method: 'POST' }, null, null, (r, c, b) => (out = b), async () => Buffer.from(JSON.stringify({ on: true, host: '10.0.0.5', port: 53001 })));
  assert.strictEqual(out.on, true); assert.strictEqual(out.port, 53001); assert.strictEqual(out.oscIn, 7000);
  q.positions([{ pos: 0.5, t: 5, dur: 10 }, null]);
  const L1 = sent.find(m => m.a === '/pixora/fb/layer/1'); assert(L1, 'layer feedback');
  assert.strictEqual(L1.host, '10.0.0.5'); assert.strictEqual(L1.port, 53001);
  assert(Math.abs(L1.b[0] - 0.5) < 1e-3 && Math.abs(L1.b[1] - 5) < 1e-2 && Math.abs(L1.b[2] - 5) < 1e-2); assert.strictEqual(L1.b[3], 'Intro.mp4'); assert.strictEqual(L1.b[4], 1);
  assert(!Number.isInteger(L1.b[0]) && !Number.isInteger(L1.b[1]), 'numbers stay floats in OSC');
  const cue = sent.find(m => m.a === '/pixora/fb/cue'); assert.deepStrictEqual(cue.b, [3, 'Walk-in']);
  const n = sent.length; q.positions([{ pos: 0.5, t: 5, dur: 10 }, null]); assert.strictEqual(sent.length, n, 'unchanged positions are not resent');
  q.positions([{ pos: 0.6, t: 6, dur: 10 }, null]); assert.strictEqual(sent.length, n + 1);
  q.ended(0); const e = sent[sent.length - 1]; assert.strictEqual(e.a, '/pixora/fb/ended/1'); assert.deepStrictEqual(e.b, ['Intro.mp4']);
  console.log('qforge_test: all passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
