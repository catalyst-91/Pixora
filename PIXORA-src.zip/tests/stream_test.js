// PIXORA live streaming test (no browser): destinations and masked keys, Blackmagic Streaming XML import, ffmpeg
// arguments for pass-through / re-encode / multi-destination, a real re-encode to a local RTMP receiver, start errors.
//   node tests/stream_test.js
const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert'), { spawn, spawnSync } = require('child_process');
const ok = m => console.log('✓ ' + m); const tick = ms => new Promise(r => setTimeout(r, ms));
const FF = process.env.FFMPEG_PATH || 'ffmpeg', hasFF = spawnSync(FF, ['-version']).status === 0;
const settings = {}, sent = [], mon = [];
const S = require('../server-stream.js')({ FFMPEG: FF, ffmpegOk: () => hasFF, settings, saveSettings() {}, broadcast() {}, monitor: (a, b) => mon.push(b), output: () => ({}), sendToOutput: o => sent.push(o) });
(async () => {
  assert.throws(() => S.start(), /at least one destination/); ok('cannot go live without a destination');
  let v = S.setCfg({ destination: { name: 'YouTube', url: 'rtmp://a.rtmp.youtube.com/live2', key: 'abcd-efgh-ijkl-mnop' } });
  const id = v.destinations[0].id; assert.strictEqual(v.destinations[0].key, '••••mnop'); assert.ok(!JSON.stringify(v).includes('abcd-efgh')); ok('stream key is masked in everything sent to controllers');
  S.setCfg({ destination: { id, key: '••••mnop', name: 'YouTube main' } }); assert.strictEqual(settings.stream.destinations[0].key, 'abcd-efgh-ijkl-mnop'); ok('saving the masked value keeps the real key');
  S.setCfg({ destination: { name: 'Venue SRT', url: 'srt://10.0.0.5:9000?mode=caller&passphrase=a|b' } });
  const xml = `<?xml version="1.0"?><streaming><service><name>Restream</name><servers><server><name>Auto</name><url>rtmp://live.restream.io/live</url></server><server><name>Bad</name><url>http://x</url></server></servers></service>
    <service><name>YouTube</name><servers><server><name>Primary</name><url><![CDATA[rtmp://a.rtmp.youtube.com/live2]]></url></server></servers></service></streaming>`;
  assert.strictEqual(S.importXml(xml), 2); v = S.view(); const rs = v.presets.find(p => p.service === 'Restream'); assert.deepStrictEqual(rs.servers.map(s => s.url), ['rtmp://live.restream.io/live']); ok('Blackmagic Streaming XML imported: Restream + YouTube (non-RTMP/SRT servers skipped)');
  assert.throws(() => S.importXml('<nope/>'), /no streaming services/);
  let a = S._args(true).join(' '); assert.ok(a.includes('-c:v copy') && a.includes('-c:a aac'));
  assert.ok(a.includes('[f=flv:onfail=ignore:flvflags=no_duration_filesize]rtmp://a.rtmp.youtube.com/live2/abcd-efgh-ijkl-mnop'), a);
  assert.ok(a.includes('[f=mpegts:onfail=ignore]srt://10.0.0.5:9000?mode=caller&passphrase=a\\|b'), a); ok('pass-through args: one ffmpeg, FLV to RTMP with the key appended, MPEG-TS to SRT, tee characters escaped');
  S.setCfg({ video: { mode: 'reencode', kbps: 4500, fps: 50, height: 720, preset: 'superfast' } }); a = S._args(false).join(' ');
  assert.ok(/-vf scale=-2:720 -r 50 -c:v libx264 -preset superfast -tune zerolatency -b:v 4500k -maxrate 4500k -bufsize 9000k -g 100/.test(a), a); ok('re-encode args: 720p50, 4.5 Mb/s CBR-style, 2-second keyframes');
  if (!hasFF) { console.log('(ffmpeg not found — skipping the live send)'); process.exit(0); }
  // real send: re-encode a WebM (VP8 + Opus, like the output's fallback) to a local RTMP receiver
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'pxst-')), src = path.join(tmp, 'in.webm'), rx = path.join(tmp, 'rx.flv');
  spawnSync(FF, ['-v', 'error', '-f', 'lavfi', '-i', 'testsrc2=s=640x360:r=25', '-f', 'lavfi', '-i', 'sine=f=440', '-t', '4', '-c:v', 'libvpx', '-b:v', '2M', '-c:a', 'libopus', '-y', src]);
  const recv = spawn(FF, ['-v', 'error', '-listen', '1', '-i', 'rtmp://127.0.0.1:19361/live/key1', '-c', 'copy', '-y', rx]); await tick(700);
  settings.stream.destinations = [{ id: 'x', name: 'Local', kind: 'rtmp', url: 'rtmp://127.0.0.1:19361/live', key: 'key1', on: true }];
  S.start(); assert.strictEqual(sent.pop().on, true);
  const data = fs.readFileSync(src); S.data(Buffer.concat([Buffer.from([0x52]), data.subarray(0, 4096)])); for (let i = 4096; i < data.length; i += 16384) { S.data(data.subarray(i, i + 16384)); await tick(30); }
  for (let i = 0; i < 40 && S.view().state !== 'live'; i++) await tick(100); assert.strictEqual(S.view().state, 'live'); ok('ffmpeg went live (x264 re-encode of the browser’s VP8)');
  S.stop(); await new Promise(r => recv.on('exit', r));
  const pr = spawnSync('ffprobe', ['-v', 'error', '-show_entries', 'stream=codec_name,height:format=duration', '-of', 'json', rx], { encoding: 'utf8' }); const j = JSON.parse(pr.stdout || '{}');
  assert.deepStrictEqual(j.streams.map(s => s.codec_name), ['h264', 'aac']); assert.strictEqual(j.streams[0].height, 720); ok(`receiver got H.264 720p + AAC, ${(+j.format.duration).toFixed(1)} s`);
  console.log('\nAll streaming tests passed.'); process.exit(0);
})().catch(e => { console.error('✗', e, mon.slice(-5)); process.exit(1); });
