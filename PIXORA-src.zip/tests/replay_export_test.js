// Replay export: the server asks the main output for an event's encoded chunks and wraps them (no re-encoding) into a file.
// This test plays the main output's part with real H.264 (and VP8) from ffmpeg, sent in several pieces.
//   node tests/replay_export_test.js   (needs ffmpeg with libx264; VP8 part skips without libvpx)
const { spawn, spawnSync } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
const probe = f => JSON.parse(spawnSync('ffprobe', ['-v', 'error', '-select_streams', 'v:0', '-count_frames', '-show_entries', 'stream=codec_name,width,height,r_frame_rate,nb_read_frames:format=duration', '-of', 'json', f], { encoding: 'utf8' }).stdout);
(async () => {
  if (spawnSync('ffmpeg', ['-version']).status !== 0) { console.log('replay_export_test: skipped (no ffmpeg)'); process.exit(0); }
  const T = fs.mkdtempSync(path.join(os.tmpdir(), 'pxrx-')), MEDIA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxrxm-'));
  spawnSync('ffmpeg', ['-v', 'error', '-f', 'lavfi', '-i', 'testsrc=size=320x180:rate=25:duration=4', '-c:v', 'libx264', '-g', '12', '-bf', '0', '-bsf:v', 'h264_mp4toannexb', '-f', 'h264', path.join(T, 'a.h264')]);
  const hasVpx = spawnSync('ffmpeg', ['-v', 'error', '-f', 'lavfi', '-i', 'testsrc=size=320x180:rate=25:duration=2', '-c:v', 'libvpx', '-f', 'ivf', path.join(T, 'b.ivf')]).status === 0;
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8853, OSC_PORT: 8854, DATA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxrxd-')), MEDIA_DIR: MEDIA }, stdio: 'ignore' }); kids.push(srv);
  const B = 'http://127.0.0.1:8853';
  for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const cmd = c => fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(c) });
  const st = () => fetch(B + '/api/state').then(r => r.json());
  await cmd({ op: 'replay', a: 'unit', unit: 'A', source: 'program' }); await cmd({ op: 'replay', a: 'unit', unit: 'B', source: '0' });
  // the "main output": answers export requests from its (fake) replay buffer
  const out = new WebSocket('ws://127.0.0.1:8853/ws?role=output'); out.binaryType = 'arraybuffer'; await new Promise(r => out.onopen = r);
  const reqs = [];
  const send = (h, data) => { const hj = Buffer.from(JSON.stringify(h)), b = Buffer.alloc(5 + hj.length + (data ? data.length : 0)); b[0] = 4; b.writeUInt32BE(hj.length, 1); hj.copy(b, 5); if (data) data.copy(b, 5 + hj.length); out.send(b); };
  out.onmessage = e => { if (typeof e.data !== 'string') return; const m = JSON.parse(e.data); if (m.t === 'replayExport') reqs.push(m); };
  await tick(300);
  // H.264: split the Annex-B stream into 3 pieces at arbitrary byte offsets (the server just concatenates them)
  await cmd({ op: 'replay', a: 'event', seconds: 4, name: 'Try "line"/1' }); await tick(200);
  let ev = (await st()).replay.events.slice(-1)[0];
  await cmd({ op: 'replayExport', event: ev.id, speed: 1 }); await cmd({ op: 'replayExport', event: ev.id, speed: 0.5 });
  for (let i = 0; i < 20 && reqs.length < 2; i++) await tick(100);
  assert.strictEqual(reqs.length, 2); assert.ok(reqs.every(r => r.unit === 'A' && r.to - r.from > 3900 && r.id)); ok('the main output is asked for the event (unit A, in → out)');
  const h264 = fs.readFileSync(path.join(T, 'a.h264')), cuts = [0, Math.floor(h264.length / 3), Math.floor(h264.length * 2 / 3), h264.length];
  for (const r of reqs) for (let k = 0; k < 3; k++) send({ id: r.id, codec: 'avc1.42001f', fps: 25.4, w: 320, h: 180, part: k, last: k === 2, frames: k === 2 ? 100 : 0 }, h264.subarray(cuts[k], cuts[k + 1]));
  for (let i = 0; i < 40 && !((ev = (await st()).replay.events.slice(-1)[0]).files || []).filter(f => f.unit === 'A').length !== 2; i++) await tick(200);
  for (let i = 0; i < 40 && (ev.files || []).length < 2; i++) { await tick(200); ev = (await st()).replay.events.slice(-1)[0]; }
  assert.strictEqual(ev.files.length, 2, JSON.stringify(ev.files));
  const f1 = ev.files.find(f => f.speed === 1), f2 = ev.files.find(f => f.speed === 0.5);
  assert.strictEqual(f1.file, 'Replays/Try line 1.mp4', 'unsafe characters removed from the file name');
  const p1 = probe(path.join(MEDIA, f1.file)), p2 = probe(path.join(MEDIA, f2.file));
  assert.strictEqual(p1.streams[0].codec_name, 'h264'); assert.strictEqual(+p1.streams[0].nb_read_frames, 100); assert.strictEqual(p1.streams[0].r_frame_rate, '25/1', 'measured 25.4 fps snaps to 25');
  assert.ok(Math.abs(+p1.format.duration - 4) < 0.1 && Math.abs(+p2.format.duration - 8) < 0.2, `${p1.format.duration} / ${p2.format.duration}`);
  ok(`H.264 → ${f1.file}: 100 frames at 25 fps, 4 s (copied, not re-encoded); the 50% file runs 8 s`);
  const lib = await fetch(B + '/api/library').then(r => r.json()); assert.ok(JSON.stringify(lib).includes('Replays/'), 'in library'); ok('exported files appear in the library under Replays');
  const dl = await fetch(B + '/media/local/' + f1.file.split('/').map(encodeURIComponent).join('/')); assert.ok(dl.ok && (await dl.arrayBuffer()).byteLength > 1000); ok('downloadable from the event’s link');
  // errors from the output reach the operator
  const got = []; const ctl = new WebSocket('ws://127.0.0.1:8853/ws?role=control'); ctl.onmessage = e => { if (typeof e.data === 'string') { const m = JSON.parse(e.data); if (m.t === 'replayExportStatus') got.push(m); } }; await new Promise(r => ctl.onopen = r);
  reqs.length = 0; await cmd({ op: 'replayExport', event: ev.id, units: 'B' }); for (let i = 0; i < 20 && !reqs.length; i++) await tick(100);
  send({ id: reqs[0].id, error: 'that part of the replay is no longer in the buffer' }); await tick(300);
  assert.ok(got.find(m => m.state === 'error' && /no longer in the buffer/.test(m.error))); ok('an output error reaches the controllers');
  // VP8 (computers without an H.264 encoder record VP8): IVF frames → [len][frame] pieces → WebM
  if (hasVpx) {
    const ivf = fs.readFileSync(path.join(T, 'b.ivf')); const frames = []; for (let o = 32; o + 12 <= ivf.length;) { const n = ivf.readUInt32LE(o); frames.push(ivf.subarray(o + 12, o + 12 + n)); o += 12 + n; }
    const body = Buffer.concat(frames.map(f => { const l = Buffer.alloc(4); l.writeUInt32BE(f.length); return Buffer.concat([l, f]); }));
    reqs.length = 0; await cmd({ op: 'replayExport', event: ev.id, units: 'A', speed: 1 }); for (let i = 0; i < 20 && !reqs.length; i++) await tick(100);
    send({ id: reqs[0].id, codec: 'vp8', fps: 25, w: 320, h: 180, part: 0, last: true, frames: frames.length }, body);
    let fw; for (let i = 0; i < 40 && !(fw = got.find(m => m.state === 'done' && /\.webm$/.test(m.file || ''))); i++) await tick(200);
    assert.ok(fw, 'webm saved'); const pw = probe(path.join(MEDIA, fw.file)); assert.strictEqual(pw.streams[0].codec_name, 'vp8'); assert.strictEqual(+pw.streams[0].nb_read_frames, 50);
    ok(`VP8 → ${fw.file}: 50 frames (WebM)`);
  } else console.log('– VP8 part skipped (ffmpeg has no libvpx)');
  out.close(); ctl.close(); console.log('replay_export_test: all passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
