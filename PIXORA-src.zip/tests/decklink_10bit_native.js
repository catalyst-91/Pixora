// 10-bit DeckLink frames in the native module, against the fake driver (build: tests/fixtures/decklink-fake/README.txt):
// a buffer of exactly ceil(w/48)*128*h bytes goes out as v210, anything BGRA-sized as 8-bit, both direct and scheduled.
//   LD_LIBRARY_PATH=/tmp/dlfake PIXORA_DECKLINK_ADDON=/tmp/pixora_decklink-linux-x64.node node tests/decklink_10bit_native.js
const d = require(process.env.PIXORA_DECKLINK_ADDON || '/tmp/pixora_decklink-linux-x64.node'), fs = require('fs'), assert = require('assert'); const ok = m => console.log('✓ ' + m);
const fmt = () => fs.readFileSync('/tmp/dlfake/fmt.txt', 'utf8').trim().split(' ').map(Number);
const o = d.openOutput(0, '1080p50'), rb = Math.ceil(1920 / 48) * 128, v = Buffer.alloc(rb * 1080); v.writeUInt32LE(0x3ac00040 >>> 0, 0);
assert.strictEqual(d.display(o.handle, v, 1920, 1080), true); assert.deepStrictEqual(fmt(), [0x76323130, rb]);
const out = fs.readFileSync('/tmp/dlfake/out.bin'); assert.strictEqual(out.length, rb * 1080); assert.strictEqual(out.readUInt32LE(0), 0x3ac00040);
ok(`v210 buffer (${rb} bytes a line) → a 10-bit YUV frame, bytes unchanged`);
assert.strictEqual(d.display(o.handle, Buffer.alloc(1920 * 1080 * 4), 1920, 1080), true); assert.deepStrictEqual(fmt(), [0x42475241, 7680]); ok('BGRA buffer → 8-bit frame as before');
assert.strictEqual(d.display(o.handle, Buffer.alloc(rb * 1080 - 4), 1920, 1080), false); ok('a buffer of the wrong size is refused');
assert.strictEqual(d.startScheduled(o.handle, 3), true); const r = d.schedule(o.handle, v, 1920, 1080); assert.ok(r && r.ok); assert.deepStrictEqual(fmt(), [0x76323130, rb]); ok('genlocked (scheduled) playback takes v210 too');
d.close(o.handle); console.log('DeckLink 10-bit native test passed'); process.exit(0);
