// PIXORA crash reports: what gets removed, the GitHub issue link, recording, asking once, "never ask".
//   node tests/desktop_crash_test.js
const assert = require('assert'), os = require('os'), fs = require('fs'), path = require('path');
const crashMod = require('../desktop/crash.js'), { sanitize, issueUrl } = crashMod;
const home = os.homedir();
const dirty = `Error at ${home}/Videos/PIXORA/show.pixora\nstream rtmp://a.rtmp.youtube.com/live2/abcd-efgh-ijkl failed\nsrt://10.0.0.5:9000?streamid=secret\nconnect 192.168.1.50:7000\nPIN=4321 token: abc123 key="zzz"\njay@booth-productions.com\nhttps://github.com/catalyst-91/Pixora/issues ok`;
const s = sanitize(dirty);
assert(!s.includes(home) && s.includes('~/Videos/PIXORA'), 'home folder');
assert(!/abcd-efgh|youtube\.com\/live2|streamid|secret/.test(s) && s.includes('rtmp://<removed>'), 'stream urls and keys');
assert(!s.includes('192.168.1.50') && !s.includes('10.0.0.5') && s.includes('x.x.x.x'), 'IP addresses');
assert(!/4321|abc123|zzz/.test(s), 'pins, tokens, keys'); assert(!s.includes('jay@') && s.includes('<email>'), 'emails');
assert(s.includes('https://github.com/catalyst-91/Pixora/issues'), 'harmless links kept');
console.log('✓ removes home folders, stream URLs/keys, IP addresses, PINs/tokens and emails');
const r = { kind: 'server', version: '1.5.0', platform: 'win32', arch: 'x64', osRelease: '10.0', electron: '33', at: '2026-11-17T10:00:00Z', message: 'TypeError: x is undefined', stack: 'at a\n'.repeat(400), tail: ('log line with 10.1.1.1 ' + 'x'.repeat(60) + '\n').repeat(400) };
const u = issueUrl(r); assert(u.startsWith('https://github.com/catalyst-91/Pixora/issues/new?labels=crash&title=Crash%3A%20server'));
assert(u.length <= 7600, 'fits in a URL: ' + u.length); const body = decodeURIComponent(u.split('&body=')[1]);
assert(body.includes('PIXORA 1.5.0') && body.includes('TypeError: x is undefined') && !body.includes('10.1.1.1') && body.includes('What were you doing?'));
console.log(`✓ pre-filled GitHub issue link (${u.length} chars, long logs trimmed)`);
(async () => {
  const ud = fs.mkdtempSync(path.join(os.tmpdir(), 'pxcrash-')); const asked = [], opened = [], cfg = {};
  let answer = { response: 0, checkboxChecked: false };
  const c = crashMod({ app: { getPath: () => ud, getVersion: () => '1.5.0' }, dialog: { showMessageBox: async (...a) => (asked.push(a[a.length - 1]), answer) }, shell: { openExternal: x => opened.push(x) },
    BrowserWindow: { getAllWindows: () => [] }, cfg, saveCfg: () => {}, log: () => {} });
  c.record('server', { message: 'TypeError: boom', tail: 'x' }); c.record('server', { message: 'TypeError: boom again' });
  await new Promise(r => setTimeout(r, 2200));
  assert.strictEqual(asked.length, 1, 'two crashes in a row → one question'); assert.match(asked[0].message, /server crashed and was restarted/); assert.strictEqual(opened.length, 1); assert.match(decodeURIComponent(opened[0]), /boom again/);
  const files = fs.readdirSync(path.join(ud, 'crash-reports')); assert.strictEqual(files.length, 2); console.log('✓ reports saved; one question for a burst of crashes; Send opens the issue page');
  answer = { response: 2, checkboxChecked: true }; c.record('output window', { message: 'renderer crashed' }); await new Promise(r => setTimeout(r, 1800));
  assert.strictEqual(cfg.crashReports, 'off'); c.record('server', { message: 'again' }); await new Promise(r => setTimeout(r, 1800)); assert.strictEqual(asked.length, 2, '“Don’t ask again” is respected');
  console.log('✓ “Don’t ask again” turns the question off (reports are still kept locally)');
  for (let i = 0; i < 25; i++) c.record('x', { message: 'm' + i }); assert(fs.readdirSync(path.join(ud, 'crash-reports')).length <= 20); console.log('✓ keeps the last 20 reports');
  console.log('desktop_crash_test: all passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
