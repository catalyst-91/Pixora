// PIXORA playlists-as-one-input test: folder and M3U sources, in-order / shuffle / loop, stills timing, Next/Previous,
// and one advance per item even when several outputs report the end.   node tests/playlist_test.js
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
const until = async (fn, ms = 5000) => { const t = Date.now(); while (Date.now() - t < ms) { const v = await fn(); if (v) return v; await tick(40); } throw new Error('timed out'); };
(async () => {
  const MEDIA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxplm-')), DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxpld-'));
  fs.mkdirSync(path.join(MEDIA, 'shows', 'walkin'), { recursive: true });
  for (const f of ['01-intro.mp4', '02-sponsor.mp4', '03-logo.png']) fs.writeFileSync(path.join(MEDIA, 'shows', 'walkin', f), 'x');
  fs.writeFileSync(path.join(MEDIA, 'shows', 'list.m3u'), '#EXTM3U\n#EXTINF:2,Sponsor first\nwalkin/02-sponsor.mp4\n#EXTINF:1,Logo\nwalkin\\03-logo.png\nhttps://example.com/stream/clip.mp4\nwalkin/missing.mp4\n');
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8887, OSC_PORT: 8888, DATA_DIR: DATA, MEDIA_DIR: MEDIA }, stdio: ['ignore', 'pipe', 'pipe'] }); kids.push(srv);
  const B = 'http://127.0.0.1:8887';
  for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const post = (p, b) => fetch(B + p, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) }).then(r => r.json());
  const cmd = c => post('/api/cmd', c), state = () => fetch(B + '/api/state').then(r => r.json());

  let r = await post('/api/playlist/resolve', { ext: { kind: 'folder', path: 'local/shows/walkin' } });
  assert.deepStrictEqual(r.items.map(i => [i.name, i.kind]), [['01-intro.mp4', 'video'], ['02-sponsor.mp4', 'video'], ['03-logo.png', 'image']]); ok('folder → ' + r.items.map(i => i.name).join(', '));
  r = await post('/api/playlist/resolve', { ext: { kind: 'file', path: 'local/shows/list.m3u' } });
  assert.deepStrictEqual(r.items.map(i => i.src), ['local/shows/walkin/02-sponsor.mp4', 'local/shows/walkin/03-logo.png', 'https://example.com/stream/clip.mp4']);
  assert.strictEqual(r.items[0].name, 'Sponsor first'); assert.strictEqual(r.items[1].dur, 1); ok('M3U → titles and #EXTINF lengths, Windows paths and web URLs; missing files skipped');
  r = await post('/api/playlist/resolve', { ext: { kind: 'file', path: '../../etc/passwd' } }); assert.ok(r.error && !r.items.length); ok('paths outside the media sources are refused (' + r.error + ')');

  // a playlist clip on layer 1, linked to the M3U
  await cmd({ op: 'set', path: 'layers.0.clips.2', value: { type: 'playlist', name: 'Walk-in', ext: { kind: 'file', path: 'local/shows/list.m3u' }, items: r.items.length ? r.items : (await post('/api/playlist/resolve', { ext: { kind: 'file', path: 'local/shows/list.m3u' } })).items, index: 0, order: 'sequential', loop: true, imageSecs: 8, fit: 'fit' } });
  await cmd({ op: 'trigger', layer: 0, clip: 2 }); let s = await state(); const trig0 = s.layers[0].trig;
  // two outputs both report the end of item 1
  const ws = [new WebSocket('ws://127.0.0.1:8887/ws?role=output'), new WebSocket('ws://127.0.0.1:8887/ws?role=output')]; await Promise.all(ws.map(w => new Promise(r => w.onopen = r)));
  ws.forEach(w => w.send(JSON.stringify({ t: 'ended', layer: 0, trig: trig0 }))); await tick(200); s = await state();
  assert.strictEqual(s.layers[0].clips[2].index, 1); assert.strictEqual(s.layers[0].trig, trig0 + 1); ok('end of "Sponsor first" reported by two outputs → advanced once, to "Logo"');
  const t1 = Date.now(); await until(async () => (await state()).layers[0].clips[2].index === 2, 3000); const held = Date.now() - t1;
  assert.ok(held > 600 && held < 1800, 'still held ' + held + 'ms'); ok(`still "Logo" held for its #EXTINF length (~${Math.round(held / 100) / 10} s), then on to the web clip`);
  s = await state(); ws[0].send(JSON.stringify({ t: 'ended', layer: 0, trig: s.layers[0].trig })); await until(async () => (await state()).layers[0].clips[2].index === 0); ok('end of the list loops back to the first item');
  await cmd({ op: 'playlist', layer: 0, a: 'prev' }); s = await state(); assert.strictEqual(s.layers[0].clips[2].index, 2); await cmd({ op: 'playlist', layer: 0, a: 'goto', index: 1 }); s = await state(); assert.strictEqual(s.layers[0].clips[2].index, 1); ok('Previous wraps to the last item; Go to item 2');
  // the M3U is edited on disk → picked up by Refresh, keeping the item on air
  fs.writeFileSync(path.join(MEDIA, 'shows', 'list.m3u'), '#EXTM3U\nwalkin/01-intro.mp4\nwalkin/03-logo.png\n');
  await cmd({ op: 'playlist', layer: 0, a: 'refresh' }); await until(async () => (await state()).layers[0].clips[2].items.length === 2);
  s = await state(); assert.strictEqual(s.layers[0].clips[2].items[s.layers[0].clips[2].index].name, '03-logo.png'); ok('edited M3U picked up; "Logo" stays on air at its new position');
  // shuffle never repeats the same item twice in a row
  await cmd({ op: 'set', path: 'layers.0.clips.2.order', value: 'shuffle' }); let prev = (await state()).layers[0].clips[2].index, rep = 0;
  for (let i = 0; i < 8; i++) { await cmd({ op: 'playlist', layer: 0, a: 'next' }); const n = (await state()).layers[0].clips[2].index; if (n === prev) rep++; prev = n; } assert.strictEqual(rep, 0); ok('shuffle never plays the same item twice in a row');
  ws.forEach(w => w.close()); srv.kill(); console.log('\nAll playlist tests passed.'); process.exit(0);
})().catch(e => { console.error('✗', e); process.exit(1); });
