// Media sync: a backup server and a render node copy the primary's media (clips, a stinger, an ISF image, converted copies,
// LUTs), resume a half-finished copy, skip files they already have, follow new clips, respect the bandwidth cap, serve the
// copies under the primary's paths, report progress to the primary, and the primary only shares media it would play.
//   node tests/mediasync_test.js
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), crypto = require('crypto'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
const tmp = p => fs.mkdtempSync(path.join(os.tmpdir(), p));
function start(port, data, media) { const k = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: port, OSC_PORT: port + 1, DATA_DIR: data, MEDIA_DIR: media }, stdio: 'ignore' }); kids.push(k); return k; }
const up = async B => { for (let i = 0; i < 80 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150); };
const api = (B, p, body) => fetch(B + p, body !== undefined ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : {}).then(async r => { const j = await r.json().catch(() => ({})); if (!r.ok) throw Object.assign(new Error(j.error || r.status), { status: r.status }); return j; });
const sha = b => crypto.createHash('sha1').update(b).digest('hex');
async function until(fn, ms = 20000, what = '') { const end = Date.now() + ms; let v; for (;;) { v = await fn(); if (v) return v; if (Date.now() > end) throw new Error('timed out: ' + what); await tick(200); } }

(async () => {
  const P = 'http://127.0.0.1:8941', K = 'http://127.0.0.1:8943', N = 'http://127.0.0.1:8945';
  const pD = tmp('pxsP-'), pM = tmp('pxsPm-'), kD = tmp('pxsK-'), kM = tmp('pxsKm-'), nD = tmp('pxsN-'), nM = tmp('pxsNm-');
  // primary media: two clips, a stinger, an image used by an ISF shader, and a file that isn't used
  const big = crypto.randomBytes(6 * 1024 * 1024), small = crypto.randomBytes(300 * 1024), sting = crypto.randomBytes(200 * 1024), png = crypto.randomBytes(40 * 1024), unused = crypto.randomBytes(1000);
  fs.mkdirSync(path.join(pM, 'Shows', 'Rocky'), { recursive: true }); fs.mkdirSync(path.join(pM, 'ISF'), { recursive: true });
  fs.writeFileSync(path.join(pM, 'Shows', 'Rocky', 'Big Intro.mp4'), big); fs.writeFileSync(path.join(pM, 'loop.mov'), small); fs.writeFileSync(path.join(pM, 'wipe.webm'), sting);
  fs.writeFileSync(path.join(pM, 'ISF', 'logo.png'), png); fs.writeFileSync(path.join(pM, 'not-in-show.mp4'), unused);
  // the backup already has loop.mov (same path, same size) in its own library: it must not be copied again
  fs.writeFileSync(path.join(kM, 'loop.mov'), small);
  start(8941, pD, pM); await up(P);
  // a converted copy of loop.mov on the primary (as the converter would leave it)
  const transName = crypto.createHash('sha1').update('local/loop.mov').digest('hex') + '.mp4', conv = crypto.randomBytes(120 * 1024);
  fs.writeFileSync(path.join(pD, 'transcodes', transName), conv);
  await api(P, '/api/cmd', { op: 'assign', layer: 0, slot: 0, clip: { type: 'video', name: 'Intro', src: 'local/Shows/Rocky/Big Intro.mp4' } });
  await api(P, '/api/cmd', { op: 'assign', layer: 0, slot: 1, clip: { type: 'video', name: 'Loop', src: 'local/loop.mov' } });
  await api(P, '/api/cmd', { op: 'set', path: 'layers.1.stinger.src', value: 'local/wipe.webm' });
  await api(P, '/api/cmd', { op: 'shaderSave', shader: { id: 'lg', name: 'Logo', code: '/*{"INPUTS":[]}*/ void main(){ gl_FragColor = IMG_NORM_PIXEL(logo, isf_FragNormCoord); }', files: { logo: 'local/ISF/logo.png' } } });
  const cube = 'TITLE "warm"\nLUT_3D_SIZE 2\n' + Array.from({ length: 8 }, (_, i) => `${i & 1} ${(i >> 1) & 1} ${(i >> 2) & 1}`).join('\n') + '\n';
  const lut = (await fetch(P + '/api/luts?name=Warm.cube', { method: 'POST', body: cube }).then(r => r.json())).lut;

  const man = await api(P, '/api/sync/manifest?scope=show'); const srcs = man.files.map(f => f.src).sort();
  assert.deepStrictEqual(srcs, ['local/ISF/logo.png', 'local/Shows/Rocky/Big Intro.mp4', 'local/loop.mov', 'local/wipe.webm'], JSON.stringify(srcs));
  assert.ok(man.files.find(f => f.src === 'local/loop.mov').conv === conv.length && man.luts.length === 1 && man.luts[0].id === lut.id);
  assert.ok((await api(P, '/api/sync/manifest?scope=library')).files.some(f => f.src === 'local/not-in-show.mp4'));
  ok('the primary lists what the show uses — clips, a layer stinger, an image an ISF shader imports — plus converted copies and LUTs; "whole library" adds the rest');
  for (const bad of ['local/../server.js', '../etc/passwd', 'local/missing.mp4', 'nosuchsource/a.mp4']) assert.strictEqual(await fetch(P + '/api/sync/file?src=' + encodeURIComponent(bad)).then(r => r.status), 404, bad);
  ok('only media in the show or the library is shared; paths outside the library are refused');

  // a half-copied Big Intro left over from an earlier, interrupted sync
  const part = path.join(kD, 'synced-media', 'local', 'Shows', 'Rocky', 'Big Intro.mp4.part'); fs.mkdirSync(path.dirname(part), { recursive: true }); fs.writeFileSync(part, big.subarray(0, 4 * 1024 * 1024));
  start(8943, kD, kM); await up(K);
  await api(K, '/api/settings', { backup: { mode: 'backup', primary: P, failoverSec: 30, syncMedia: true, syncScope: 'show' } });
  const kStatus = async () => await api(K, '/api/backup');
  let st = await until(async () => { const s = await kStatus(); return s.media && s.media.state === 'done' && s; }, 30000, 'backup sync');
  const got = f => fs.readFileSync(path.join(kD, 'synced-media', ...f.split('/')));
  assert.strictEqual(sha(got('local/Shows/Rocky/Big Intro.mp4')), sha(big)); assert.strictEqual(sha(got('local/wipe.webm')), sha(sting)); assert.strictEqual(sha(got('local/ISF/logo.png')), sha(png));
  assert.ok(!fs.existsSync(path.join(kD, 'synced-media', 'local', 'loop.mov')), 'loop.mov already on the backup → not copied');
  assert.strictEqual(sha(fs.readFileSync(path.join(kD, 'transcodes', transName))), sha(conv)); assert.ok(fs.existsSync(path.join(kD, 'luts', lut.id + '.cube')));
  assert.ok(st.media.bytes < big.length + sting.length + png.length + conv.length + 2000 - 3 * 1024 * 1024, `resumed: ${st.media.bytes} bytes moved`);
  assert.ok(st.media.have >= 1 && !st.media.errors.length, JSON.stringify(st.media));
  ok(`backup: copied the show's media (${(st.media.bytes / 1e6).toFixed(1)} MB moved — the half-finished copy resumed), the converted copy and the LUT; the file it already had was skipped`);
  const served = Buffer.from(await fetch(K + '/media/' + encodeURI('local/Shows/Rocky/Big Intro.mp4')).then(r => r.arrayBuffer())); assert.strictEqual(sha(served), sha(big));
  const rng = await fetch(K + '/media/local/wipe.webm', { headers: { Range: 'bytes=100-199' } }); assert.strictEqual(rng.status, 206); assert.ok(Buffer.from(await rng.arrayBuffer()).equals(sting.subarray(100, 200)));
  const lt = await fetch(K + '/api/luts/' + lut.id).then(r => r.text()); assert.ok(lt.includes('LUT_3D_SIZE 2'));
  ok('the backup plays the copies under the primary\'s paths (with Range), and outputs can load the LUT from it');
  const pst = await until(async () => { const s = await api(P, '/api/backup'); return s.mirrors.length && s.mirrors[0].media && s.mirrors[0].media.state === 'done' && s; }, 8000, 'primary sees status');
  ok(`the primary sees the backup's media status (${pst.mirrors[0].media.done}/${pst.mirrors[0].media.files} files)`);

  // a new clip on the primary is picked up without pressing anything
  const extra = crypto.randomBytes(500 * 1024); fs.writeFileSync(path.join(pM, 'new clip.mp4'), extra);
  await api(P, '/api/cmd', { op: 'assign', layer: 2, slot: 0, clip: { type: 'video', name: 'New', src: 'local/new clip.mp4' } });
  await until(() => fs.existsSync(path.join(kD, 'synced-media', 'local', 'new clip.mp4')), 20000, 'follow new clip');
  await until(async () => (await kStatus()).media.state === 'done', 10000); assert.strictEqual(sha(got('local/new clip.mp4')), sha(extra));
  ok('a clip added on the primary is copied to the backup on its own');
  // the primary's file changes (same name, new content): the copy is replaced
  const v2 = crypto.randomBytes(260 * 1024); fs.writeFileSync(path.join(pM, 'wipe.webm'), v2); await api(K, '/api/backup', { action: 'syncMedia' });
  await until(() => { try { return sha(got('local/wipe.webm')) === sha(v2); } catch { return false; } }, 15000, 'changed file'); ok('a file changed on the primary is copied again');

  // render node with a bandwidth cap, library scope
  start(8945, nD, nM); await up(N);
  await api(N, '/api/settings', { backup: { mode: 'node', primary: P, syncMedia: true, syncScope: 'library', syncMbps: 20 } }); const t0 = Date.now();
  const nStatus = async () => await api(N, '/api/backup');
  st = await until(async () => { const s = await nStatus(); return s.media && s.media.state === 'done' && s; }, 40000, 'node sync'); const secs = (Date.now() - t0) / 1000;
  const mb = st.media.bytes * 8 / 1e6; assert.ok(mb / secs < 24, `${(mb / secs).toFixed(1)} Mbit/s with a 20 Mbit/s cap`); assert.ok(secs > 2.5, secs);
  assert.ok(fs.existsSync(path.join(nD, 'synced-media', 'local', 'not-in-show.mp4')) && fs.existsSync(path.join(nD, 'synced-media', 'local', 'loop.mov')));
  ok(`render node, whole library, 20 Mbit/s cap: ${(st.media.bytes / 1e6).toFixed(1)} MB in ${secs.toFixed(1)} s (${(mb / secs).toFixed(0)} Mbit/s)`);
  const lib = await api(N, '/api/library'); assert.ok(lib.sources.some(s => s.id === 'synced' && s.items.some(i => i.name === 'Big Intro.mp4')), 'synced folder in the library');
  ok('the copies show up in the node\'s library as "Synced from primary"');

  // switching media sync off stops it; turning a backup back into a primary drops the config
  await api(N, '/api/settings', { backup: { mode: 'node', primary: P, syncMedia: false } }); await assert.rejects(api(N, '/api/backup', { action: 'syncMedia' }), /off/);
  await api(N, '/api/settings', { backup: { mode: 'off' } }); assert.strictEqual((await nStatus()).media, null);
  ok('media sync can be switched off, and a primary has no sync status');
  console.log('Media sync test passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
