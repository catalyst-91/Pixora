// PIXORA ⇄ PRO DJ LINK Bridge test: a simulated Bridge node sends TCNet Opt-IN / Status / Time packets and answers
// PIXORA's Request packets with Metrics and Metadata (UTF-16, TCNet 3.5). Checks tempo + bar phase follow, the djlink
// feed (titles/rules), timecode cues from the deck, and deck playheads streamed to outputs.   node tests/tcnet_test.js
const { spawn } = require('child_process'); const dgram = require('dgram'), path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const until = async (fn, ms = 5000) => { const t = Date.now(); while (Date.now() - t < ms) { const v = await fn(); if (v) return v; await tick(50); } throw new Error('timed out waiting'); };
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));

const BRIDGE_PORT = 65040; let seq = 0;
function hdr(type, size, nodeType = 2) { const b = Buffer.alloc(size); b.writeUInt16LE(0x1234, 0); b[2] = 3; b[3] = 5; b.write('TCN', 4, 'latin1'); b[7] = type; b.write('BRIDGE01', 8, 8, 'latin1'); b[16] = seq++ & 255; b[17] = nodeType; return b; }
const deck = { trackId: 4711, ms: 61000, total: 245000, state: 3, beat: 4, bpm: 126.5 };
const optIn = () => { const b = hdr(2, 68); b.writeUInt16LE(1, 24); b.writeUInt16LE(BRIDGE_PORT, 26); b.write('PIONEER DJ', 32, 'latin1'); b.write('PRO DJ LINK BRDG', 48, 'latin1'); b[64] = 1; b[65] = 2; return b; };
const status = () => { const b = hdr(5, 300); b.writeUInt16LE(BRIDGE_PORT, 26); b[42] = deck.state; b.writeUInt32LE(deck.trackId, 50); b.write('CDJ-3000 #1', 172, 'latin1'); b[83] = 25; return b; };
const time = () => { const b = hdr(254, 162); b.writeUInt32LE(deck.ms, 24); b.writeUInt32LE(deck.total, 56); b[88] = deck.beat; b[96] = deck.state; b[154] = 255; b[106] = 25; return b; };
const metrics = () => { const b = hdr(200, 122); b[24] = 2; b[25] = 1; b[27] = deck.state; b[29] = 1; b[31] = deck.beat; b.writeUInt32LE(deck.total, 32); b.writeUInt32LE(deck.ms, 36); b.writeUInt32LE(32768, 40); b.writeUInt32LE(129, 57); b.writeUInt32LE(Math.round(deck.bpm * 100), 112); b.writeUInt32LE(deck.trackId, 118); return b; };
const meta = () => { const b = hdr(200, 548); b[24] = 4; b[25] = 1; b.write('Røyksopp', 29, 'utf16le'); b.write('Rückenwind (Extended Mix)', 285, 'utf16le'); b.writeUInt32LE(deck.trackId, 543); return b; };

(async () => {
  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxtc-')), MEDIA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxtcm-'));
  fs.writeFileSync(path.join(DATA, 'settings.json'), JSON.stringify({ tcnet: { on: true, source: 'bridge' } }));
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8881, OSC_PORT: 8882, DATA_DIR: DATA, MEDIA_DIR: MEDIA }, stdio: ['ignore', 'pipe', 'pipe'] }); kids.push(srv);
  let log = ''; srv.stdout.on('data', d => log += d); srv.stderr.on('data', d => log += d);
  const B = 'http://127.0.0.1:8881';
  for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const api = async (p, o) => (await fetch(B + p, o)).json();

  // the simulated Bridge
  const reqs = []; const br = dgram.createSocket('udp4'); let pixoraPort = 0;
  br.on('message', (m, r) => { if (m.toString('latin1', 4, 7) !== 'TCN') return;
    if (m[7] === 2) { pixoraPort = m.readUInt16LE(26); assert.strictEqual(m.toString('latin1', 48, 54), 'PIXORA'); }
    if (m[7] === 20) { reqs.push([m[24], m[25]]); const reply = m[24] === 2 ? metrics() : m[24] === 4 ? meta() : null; if (reply) br.send(reply, r.port, r.address); } });
  await new Promise(r => br.bind(BRIDGE_PORT, '127.0.0.1', r));
  const toPixora = (b, port) => br.send(b, port, '127.0.0.1');
  const pump = setInterval(() => { toPixora(optIn(), 60000); toPixora(status(), 60000); }, 300);
  await until(async () => (await api('/api/tcnet')).nodes.length === 1);
  let v = await api('/api/tcnet'); assert.strictEqual(v.nodes[0].app, 'PRO DJ LINK BRDG'); ok(`PIXORA joined TCNet (listener ${v.port}) and found "${v.nodes[0].app}" ${v.nodes[0].version}`);
  await until(() => pixoraPort); ok('PIXORA Opt-IN reaches the Bridge on its unicast port (node "PIXORA", type slave)');

  // a track loads → PIXORA asks for metadata + metrics
  await until(() => reqs.some(r => r[0] === 4 && r[1] === 1) && reqs.some(r => r[0] === 2 && r[1] === 1)); ok('track load on deck 1 → PIXORA requests Metadata (4) and Metrics (2)');
  for (let i = 0; i < 10; i++) { deck.beat = (i % 4) + 1; deck.ms += 120; toPixora(time(), 60001); await tick(30); }
  v = await until(async () => { const x = await api('/api/tcnet'); return x.decks[0].title ? x : null; });
  assert.strictEqual(v.decks[0].title, 'Rückenwind (Extended Mix)'); assert.strictEqual(v.decks[0].artist, 'Røyksopp'); assert.strictEqual(v.master, '1');
  ok(`metadata decoded as UTF-16: "${v.decks[0].artist} – ${v.decks[0].title}", deck 1 is master (sync master, on air)`);
  const st = await api('/api/state'); assert.strictEqual(st.comp.bpm, 126.5); ok('PIXORA tempo follows the master deck: 126.5 BPM');
  const f = await api('/api/feeds'); assert.strictEqual(f.values.djlink.master.title, 'Rückenwind (Extended Mix)'); assert.strictEqual(f.values.djlink.master.bpm, 126.5);
  ok('feed djlink.master.* ready for titles ({{djlink.master.title}}) and rules');

  // bar phase: downbeat moves the beat clock
  const e0 = st.comp.beatEpoch; await tick(400); deck.beat = 4; toPixora(time(), 60001); await tick(20); deck.beat = 1; const t1 = Date.now(); toPixora(time(), 60001);
  const s2 = await until(async () => { const s = await api('/api/state'); return s.comp.beatEpoch !== e0 ? s : null; });
  assert.ok(Math.abs(s2.comp.beatEpoch - t1) < 60, `epoch ${s2.comp.beatEpoch - t1}ms off`); ok(`downbeat from the deck re-aligns PIXORA's bar (within ${Math.abs(s2.comp.beatEpoch - t1)} ms)`);

  // timecode cue from the deck position
  const post = c => fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(c) });
  await post({ op: 'set', path: 'comp.timecode.source', value: 'tcnet' });
  await post({ op: 'set', path: 'cues', value: [{ name: 'Drop visuals', tc: '00:01:05:00', layers: [], fade: 0 }] });
  await tick(200); for (let ms = 64000; ms <= 66000; ms += 200) { deck.ms = ms; toPixora(time(), 60001); await tick(25); }
  const s3 = await until(async () => { const s = await api('/api/state'); return s.cueIndex === 0 ? s : null; }, 3000); ok('timecode cue at 00:01:05:00 fired from deck position (source "DJ deck")');

  // outputs get deck playheads (clip "Follow DJ deck")
  const ws = new WebSocket('ws://127.0.0.1:8881/ws?role=output'); const got = [];
  ws.onmessage = ev => { const m = JSON.parse(ev.data); if (m.t === 'djtime') got.push(m); }; await new Promise(r => ws.onopen = r);
  for (let i = 0; i < 12; i++) { deck.ms += 40; toPixora(time(), 60001); await tick(40); }
  await until(() => got.length > 3); const last = got[got.length - 1];
  assert.strictEqual(last.master, 0); assert.ok(Math.abs(last.layers[0].ms - deck.ms) < 200, last.layers[0].ms + ' vs ' + deck.ms);
  ok(`outputs receive deck playheads at ~25 Hz (deck 1 at ${last.layers[0].ms} ms)`);
  ws.close();

  // turning it off closes the ports
  await fetch(B + '/api/tcnet', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ on: false }) });
  v = await api('/api/tcnet'); assert.strictEqual(v.status, 'off'); ok('switching DJ Link off stops the node');
  clearInterval(pump); br.close(); srv.kill(); console.log('\nAll TCNet tests passed.'); process.exit(0);
})().catch(e => { console.error('✗', e); process.exit(1); });
