Fake Blackmagic Desktop Video driver (Linux) for testing PIXORA's DeckLink module without hardware.
One "DeckLink Duo 2": capture delivers colour bars; DisplayVideoFrameSync writes the last frame to /tmp/dlfake/out.bin;
scheduled playback plays one queued frame per card frame (50 fps) and logs it to /tmp/dlfake/sched.log;
IDeckLinkStatus reports a locked 1080p50 reference when FAKE_REF=1.

  mkdir -p /tmp/dlfake && g++ -std=c++17 -shared -fPIC -I desktop/native/decklink/include/linux -o /tmp/dlfake/libDeckLinkAPI.so tests/fixtures/decklink-fake/fake.cpp -lpthread
  g++ -std=c++17 -shared -fPIC -I <node>/include/node -I desktop/native/decklink/include/linux -DNODE_GYP_MODULE_NAME=pixora_decklink -DNAPI_VERSION=8 \
      desktop/native/decklink/pixora_decklink.cpp desktop/native/decklink/include/linux/DeckLinkAPIDispatch.cpp -o /tmp/pixora_decklink-linux-x64.node -ldl -lpthread
  LD_LIBRARY_PATH=/tmp/dlfake FAKE_REF=1 PIXORA_DECKLINK_ADDON=/tmp/pixora_decklink-linux-x64.node node tests/desktop_decklink_test.js
  LD_LIBRARY_PATH=/tmp/dlfake FAKE_REF=1 PIXORA_DECKLINK_ADDON=/tmp/pixora_decklink-linux-x64.node node tests/decklink_genlock_native.js
