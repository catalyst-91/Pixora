// Fake libDeckLinkAPI.so for testing PIXORA's DeckLink addon without hardware.
// One device "DeckLink Duo 2 (1)": capture delivers UYVY frames (75% colour bars, 1080p25, then a
// format change to 720p50); playout records the last frame displayed into /tmp/dlfake/out.bin.
#include "stubs.h"
#include <thread>
#include <atomic>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <chrono>
#include <mutex>
#include <utility>

static bool eq(REFIID a, REFIID b) { return memcmp(&a, &b, 16) == 0; }
struct Mode : Stub_IDeckLinkDisplayMode { BMDDisplayMode id; long w, h; BMDTimeValue d; BMDTimeScale s; const char* n; BMDFieldDominance fd;
  Mode(BMDDisplayMode i, long W, long H, BMDTimeValue D, BMDTimeScale S, const char* N, BMDFieldDominance F) : id(i), w(W), h(H), d(D), s(S), n(N), fd(F) {}
  HRESULT GetName(const char** o) override { *o = strdup(n); return S_OK; } BMDDisplayMode GetDisplayMode() override { return id; } long GetWidth() override { return w; } long GetHeight() override { return h; }
  HRESULT GetFrameRate(BMDTimeValue* D, BMDTimeScale* S) override { *D = d; *S = s; return S_OK; } BMDFieldDominance GetFieldDominance() override { return fd; } };
static Mode* mk(int i) { switch (i) { case 0: return new Mode(bmdModeHD1080p25, 1920, 1080, 1000, 25000, "1080p25", bmdProgressiveFrame); case 1: return new Mode(bmdModeHD1080p50, 1920, 1080, 1000, 50000, "1080p50", bmdProgressiveFrame);
  case 2: return new Mode(bmdModeHD720p50, 1280, 720, 1000, 50000, "720p50", bmdProgressiveFrame); case 3: return new Mode(bmdModeHD1080i5994, 1920, 1080, 1001, 30000, "1080i59.94", bmdUpperFieldFirst); } return nullptr; }
struct ModeIt : Stub_IDeckLinkDisplayModeIterator { int i = 0; HRESULT Next(IDeckLinkDisplayMode** m) override { Mode* x = mk(i++); if (!x) return S_FALSE; *m = x; return S_OK; } };

struct Buf : Stub_IDeckLinkVideoBuffer { std::vector<uint8_t>* v; Buf(std::vector<uint8_t>* p) : v(p) {}
  HRESULT GetBytes(void** b) override { *b = v->data(); return S_OK; } HRESULT StartAccess(BMDBufferAccessFlags) override { return S_OK; } HRESULT EndAccess(BMDBufferAccessFlags) override { return S_OK; } };
struct InFrame : Stub_IDeckLinkVideoInputFrame { std::vector<uint8_t> px; long w, h;
  InFrame(long W, long H) : px(W * H * 2), w(W), h(H) { // 75% bars in UYVY (BT.709 video levels): white, yellow, cyan, green, magenta, red, blue, black
    const uint8_t bars[8][3] = {{180, 128, 128}, {168, 44, 136}, {145, 147, 44}, {133, 63, 52}, {63, 193, 204}, {51, 109, 212}, {28, 212, 120}, {16, 128, 128}};
    for (long y = 0; y < h; y++) for (long x = 0; x < w; x += 2) { const uint8_t* c = bars[x * 8 / w]; uint8_t* p = &px[(y * w + x) * 2]; p[0] = c[1]; p[1] = c[0]; p[2] = c[2]; p[3] = c[0]; } }
  HRESULT QueryInterface(REFIID iid, LPVOID* p) override { if (eq(iid, IID_IDeckLinkVideoBuffer)) { *p = new Buf(&px); return S_OK; } *p = nullptr; return E_NOINTERFACE; }
  long GetWidth() override { return w; } long GetHeight() override { return h; } long GetRowBytes() override { return w * 2; } BMDPixelFormat GetPixelFormat() override { return bmdFormat8BitYUV; } BMDFrameFlags GetFlags() override { return bmdFrameFlagDefault; } };
struct OutFrame : Stub_IDeckLinkMutableVideoFrame { std::vector<uint8_t> px; long w, h; OutFrame(long W, long H) : px(W * H * 4), w(W), h(H) {}
  HRESULT QueryInterface(REFIID iid, LPVOID* p) override { if (eq(iid, IID_IDeckLinkVideoBuffer)) { *p = new Buf(&px); return S_OK; } *p = nullptr; return E_NOINTERFACE; }
  long GetWidth() override { return w; } long GetHeight() override { return h; } long GetRowBytes() override { return w * 4; } BMDPixelFormat GetPixelFormat() override { return bmdFormat8BitBGRA; } };

struct Input : Stub_IDeckLinkInput { IDeckLinkInputCallback* cb = nullptr; std::atomic<bool> run{false}; std::thread t; long w = 1920, h = 1080;
  HRESULT GetDisplayModeIterator(IDeckLinkDisplayModeIterator** it) override { *it = new ModeIt(); return S_OK; }
  HRESULT SetCallback(IDeckLinkInputCallback* c) override { cb = c; return S_OK; }
  HRESULT EnableVideoInput(BMDDisplayMode m, BMDPixelFormat, BMDVideoInputFlags) override { if (m == bmdModeHD720p50) { w = 1280; h = 720; } return S_OK; }
  HRESULT DisableVideoInput() override { return S_OK; } HRESULT PauseStreams() override { return S_OK; } HRESULT FlushStreams() override { return S_OK; }
  HRESULT StartStreams() override { if (run) return S_OK; run = true; t = std::thread([this] { int n = 0; while (run) { if (++n == 6 && cb) { Mode* m = mk(2); cb->VideoInputFormatChanged(bmdVideoInputDisplayModeChanged, m, bmdDetectedVideoInputYCbCr422); m->Release(); }
      InFrame* f = new InFrame(w, h); if (cb) cb->VideoInputFrameArrived(f, nullptr); f->Release(); std::this_thread::sleep_for(std::chrono::milliseconds(20)); } }); return S_OK; }
  HRESULT StopStreams() override { run = false; if (t.joinable()) t.join(); return S_OK; } };
struct Output : Stub_IDeckLinkOutput { long w = 0, h = 0;
  HRESULT GetDisplayModeIterator(IDeckLinkDisplayModeIterator** it) override { *it = new ModeIt(); return S_OK; }
  HRESULT EnableVideoOutput(BMDDisplayMode m, BMDVideoOutputFlags) override { Mode* x = nullptr; for (int i = 0; i < 4; i++) { Mode* c = mk(i); if (c->id == m) { w = c->w; h = c->h; } c->Release(); } return w ? S_OK : E_FAIL; }
  HRESULT DisableVideoOutput() override { return S_OK; }
  HRESULT CreateVideoFrame(int32_t W, int32_t H, int32_t, BMDPixelFormat, BMDFrameFlags, IDeckLinkMutableVideoFrame** f) override { *f = new OutFrame(W, H); return S_OK; }
  HRESULT DisplayVideoFrameSync(IDeckLinkVideoFrame* f) override { OutFrame* o = (OutFrame*)f; FILE* fp = fopen("/tmp/dlfake/out.bin", "wb"); if (fp) { fwrite(o->px.data(), 1, o->px.size(), fp); fclose(fp); } return S_OK; }
  // scheduled playback: a "card clock" thread plays one queued frame per frame period (50 fps here), like a genlocked output
  IDeckLinkVideoOutputCallback* cb = nullptr; std::mutex qm; std::vector<std::pair<int64_t, IDeckLinkVideoFrame*>> q; std::atomic<bool> playing{false}; std::thread pt; std::atomic<int64_t> cur{0}; int64_t dur = 1000, sc = 50000;
  HRESULT SetScheduledFrameCompletionCallback(IDeckLinkVideoOutputCallback* c) override { cb = c; return S_OK; }
  HRESULT ScheduleVideoFrame(IDeckLinkVideoFrame* f, BMDTimeValue t, BMDTimeValue d, BMDTimeScale s) override { dur = d; sc = s; std::lock_guard<std::mutex> g(qm); f->AddRef(); q.push_back({ t / d, f }); return S_OK; }
  HRESULT GetBufferedVideoFrameCount(uint32_t* n) override { std::lock_guard<std::mutex> g(qm); *n = (uint32_t)q.size(); return S_OK; }
  HRESULT GetScheduledStreamTime(BMDTimeScale s, BMDTimeValue* t, double* sp) override { *t = cur * dur * s / sc; *sp = playing ? 1.0 : 0; return S_OK; }
  HRESULT StartScheduledPlayback(BMDTimeValue, BMDTimeScale, double) override { if (playing) return S_OK; playing = true; cur = 0;
    pt = std::thread([this] { auto next = std::chrono::steady_clock::now(); while (playing) { next += std::chrono::microseconds((int64_t)(1e6 * dur / sc)); std::this_thread::sleep_until(next);
      IDeckLinkVideoFrame* show = nullptr; BMDOutputFrameCompletionResult res = bmdOutputFrameCompleted; std::vector<IDeckLinkVideoFrame*> late;
      { std::lock_guard<std::mutex> g(qm); for (size_t i = 0; i < q.size();) { if (q[i].first < cur) { late.push_back(q[i].second); q.erase(q.begin() + i); } else if (q[i].first == cur) { show = q[i].second; q.erase(q.begin() + i); } else i++; } }
      for (auto* f : late) { if (cb) cb->ScheduledFrameCompleted(f, bmdOutputFrameDropped); f->Release(); }
      if (show) { OutFrame* o = (OutFrame*)show; FILE* fp = fopen("/tmp/dlfake/sched.log", "a"); if (fp) { fprintf(fp, "%lld %u\n", (long long)(int64_t)cur, (unsigned)o->px[0]); fclose(fp); } if (cb) cb->ScheduledFrameCompleted(show, res); show->Release(); }
      cur++; } }); return S_OK; }
  HRESULT StopScheduledPlayback(BMDTimeValue, BMDTimeValue*, BMDTimeScale) override { playing = false; if (pt.joinable()) pt.join(); std::lock_guard<std::mutex> g(qm); for (auto& x : q) x.second->Release(); q.clear(); return S_OK; } };
struct Status : IDeckLinkStatus { int r = 1; HRESULT QueryInterface(REFIID, LPVOID* p) override { *p = nullptr; return E_NOINTERFACE; } ULONG AddRef() override { return ++r; } ULONG Release() override { int n = --r; if (!n) delete this; return n; }
  HRESULT GetFlag(BMDDeckLinkStatusID id, bool* v) override { if (id == bmdDeckLinkStatusReferenceSignalLocked) { *v = getenv("FAKE_REF") && *getenv("FAKE_REF") == '1'; return S_OK; } return E_NOTIMPL; }
  HRESULT GetInt(BMDDeckLinkStatusID id, int64_t* v) override { if (id == bmdDeckLinkStatusReferenceSignalMode) { *v = bmdModeHD1080p50; return S_OK; } return E_NOTIMPL; }
  HRESULT GetFloat(BMDDeckLinkStatusID, double*) override { return E_NOTIMPL; } HRESULT GetString(BMDDeckLinkStatusID, const char**) override { return E_NOTIMPL; }
  HRESULT GetBytes(BMDDeckLinkStatusID, void*, uint32_t*) override { return E_NOTIMPL; } HRESULT GetInterface(BMDDeckLinkStatusID, void**) override { return E_NOTIMPL; }
  HRESULT GetFlagWithParam(BMDDeckLinkStatusID, uint64_t, bool*) override { return E_NOTIMPL; } HRESULT GetIntWithParam(BMDDeckLinkStatusID, uint64_t, int64_t*) override { return E_NOTIMPL; }
  HRESULT GetFloatWithParam(BMDDeckLinkStatusID, uint64_t, double*) override { return E_NOTIMPL; } HRESULT GetStringWithParam(BMDDeckLinkStatusID, uint64_t, const char**) override { return E_NOTIMPL; }
  HRESULT GetBytesWithParam(BMDDeckLinkStatusID, uint64_t, void*, uint32_t*) override { return E_NOTIMPL; } };
struct Attr : Stub_IDeckLinkProfileAttributes { HRESULT GetInt(BMDDeckLinkAttributeID id, int64_t* v) override { if (id == BMDDeckLinkVideoIOSupport) { *v = bmdDeviceSupportsCapture | bmdDeviceSupportsPlayback; return S_OK; } return E_NOTIMPL; } };
static Input* gIn = new Input(); static Output* gOut = new Output();
struct Dev : Stub_IDeckLink {
  HRESULT QueryInterface(REFIID iid, LPVOID* p) override { if (eq(iid, IID_IDeckLinkInput)) { gIn->AddRef(); *p = gIn; return S_OK; } if (eq(iid, IID_IDeckLinkOutput)) { gOut->AddRef(); *p = gOut; return S_OK; } if (eq(iid, IID_IDeckLinkProfileAttributes)) { *p = new Attr(); return S_OK; } if (eq(iid, IID_IDeckLinkStatus)) { *p = new Status(); return S_OK; } *p = nullptr; return E_NOINTERFACE; }
  HRESULT GetModelName(const char** n) override { *n = strdup("DeckLink Duo 2"); return S_OK; } HRESULT GetDisplayName(const char** n) override { *n = strdup("DeckLink Duo 2 (1)"); return S_OK; } };
struct It : Stub_IDeckLinkIterator { int i = 0; HRESULT Next(IDeckLink** d) override { if (i++) return S_FALSE; *d = new Dev(); return S_OK; } };
extern "C" IDeckLinkIterator* CreateDeckLinkIteratorInstance_0004() { return new It(); }
