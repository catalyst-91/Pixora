#include "DeckLinkAPI.h"
#include <cstring>
#define STUBS(C) 
struct Stub_IDeckLinkIterator : public IDeckLinkIterator {
  int r=1; HRESULT QueryInterface(REFIID, LPVOID* p) override { *p=nullptr; return E_NOINTERFACE; } ULONG AddRef() override { return ++r; } ULONG Release() override { int n=--r; if(!n) delete this; return n; }
  virtual HRESULT Next (IDeckLink** deckLinkInstance) override { return E_NOTIMPL; }
};
struct Stub_IDeckLink : public IDeckLink {
  int r=1; HRESULT QueryInterface(REFIID, LPVOID* p) override { *p=nullptr; return E_NOINTERFACE; } ULONG AddRef() override { return ++r; } ULONG Release() override { int n=--r; if(!n) delete this; return n; }
  virtual HRESULT GetModelName (const char** modelName) override { return E_NOTIMPL; }
  virtual HRESULT GetDisplayName (const char** displayName) override { return E_NOTIMPL; }
};
struct Stub_IDeckLinkInput : public IDeckLinkInput {
  int r=1; HRESULT QueryInterface(REFIID, LPVOID* p) override { *p=nullptr; return E_NOINTERFACE; } ULONG AddRef() override { return ++r; } ULONG Release() override { int n=--r; if(!n) delete this; return n; }
  virtual HRESULT DoesSupportVideoMode (BMDVideoConnection connection ,  BMDDisplayMode requestedMode,  BMDPixelFormat requestedPixelFormat,  BMDVideoInputConversionMode conversionMode,  BMDSupportedVideoModeFlags flags,  BMDDisplayMode* actualMode,  bool* supported) override { return E_NOTIMPL; }
  virtual HRESULT GetDisplayMode (BMDDisplayMode displayMode,  IDeckLinkDisplayMode** resultDisplayMode) override { return E_NOTIMPL; }
  virtual HRESULT GetDisplayModeIterator (IDeckLinkDisplayModeIterator** iterator) override { return E_NOTIMPL; }
  virtual HRESULT SetScreenPreviewCallback (IDeckLinkScreenPreviewCallback* previewCallback) override { return E_NOTIMPL; }
  virtual HRESULT EnableVideoInput (BMDDisplayMode displayMode,  BMDPixelFormat pixelFormat,  BMDVideoInputFlags flags) override { return E_NOTIMPL; }
  virtual HRESULT EnableVideoInputWithAllocatorProvider (BMDDisplayMode displayMode,  BMDPixelFormat pixelFormat,  BMDVideoInputFlags flags,  IDeckLinkVideoBufferAllocatorProvider* allocatorProvider) override { return E_NOTIMPL; }
  virtual HRESULT DisableVideoInput (void) override { return E_NOTIMPL; }
  virtual HRESULT GetAvailableVideoFrameCount (uint32_t* availableFrameCount) override { return E_NOTIMPL; }
  virtual HRESULT EnableAudioInput (BMDAudioSampleRate sampleRate,  BMDAudioSampleType sampleType,  uint32_t channelCount) override { return E_NOTIMPL; }
  virtual HRESULT DisableAudioInput (void) override { return E_NOTIMPL; }
  virtual HRESULT GetAvailableAudioSampleFrameCount (uint32_t* availableSampleFrameCount) override { return E_NOTIMPL; }
  virtual HRESULT StartStreams (void) override { return E_NOTIMPL; }
  virtual HRESULT StopStreams (void) override { return E_NOTIMPL; }
  virtual HRESULT PauseStreams (void) override { return E_NOTIMPL; }
  virtual HRESULT FlushStreams (void) override { return E_NOTIMPL; }
  virtual HRESULT SetCallback (IDeckLinkInputCallback* theCallback) override { return E_NOTIMPL; }
  virtual HRESULT GetHardwareReferenceClock (BMDTimeScale desiredTimeScale,  BMDTimeValue* hardwareTime,  BMDTimeValue* timeInFrame,  BMDTimeValue* ticksPerFrame) override { return E_NOTIMPL; }
};
struct Stub_IDeckLinkOutput : public IDeckLinkOutput {
  int r=1; HRESULT QueryInterface(REFIID, LPVOID* p) override { *p=nullptr; return E_NOINTERFACE; } ULONG AddRef() override { return ++r; } ULONG Release() override { int n=--r; if(!n) delete this; return n; }
  virtual HRESULT DoesSupportVideoMode (BMDVideoConnection connection ,  BMDDisplayMode requestedMode,  BMDPixelFormat requestedPixelFormat,  BMDVideoOutputConversionMode conversionMode,  BMDSupportedVideoModeFlags flags,  BMDDisplayMode* actualMode,  bool* supported) override { return E_NOTIMPL; }
  virtual HRESULT GetDisplayMode (BMDDisplayMode displayMode,  IDeckLinkDisplayMode** resultDisplayMode) override { return E_NOTIMPL; }
  virtual HRESULT GetDisplayModeIterator (IDeckLinkDisplayModeIterator** iterator) override { return E_NOTIMPL; }
  virtual HRESULT SetScreenPreviewCallback (IDeckLinkScreenPreviewCallback* previewCallback) override { return E_NOTIMPL; }
  virtual HRESULT EnableVideoOutput (BMDDisplayMode displayMode,  BMDVideoOutputFlags flags) override { return E_NOTIMPL; }
  virtual HRESULT DisableVideoOutput (void) override { return E_NOTIMPL; }
  virtual HRESULT CreateVideoFrame (int32_t width,  int32_t height,  int32_t rowBytes,  BMDPixelFormat pixelFormat,  BMDFrameFlags flags,  IDeckLinkMutableVideoFrame** outFrame) override { return E_NOTIMPL; }
  virtual HRESULT CreateVideoFrameWithBuffer (int32_t width,  int32_t height,  int32_t rowBytes,  BMDPixelFormat pixelFormat,  BMDFrameFlags flags,  IDeckLinkVideoBuffer* buffer,  IDeckLinkMutableVideoFrame** outFrame) override { return E_NOTIMPL; }
  virtual HRESULT RowBytesForPixelFormat (BMDPixelFormat pixelFormat,  int32_t width,  int32_t* rowBytes) override { return E_NOTIMPL; }
  virtual HRESULT CreateAncillaryData (BMDPixelFormat pixelFormat,  IDeckLinkVideoFrameAncillary** outBuffer) override { return E_NOTIMPL; }
  virtual HRESULT DisplayVideoFrameSync (IDeckLinkVideoFrame* theFrame) override { return E_NOTIMPL; }
  virtual HRESULT ScheduleVideoFrame (IDeckLinkVideoFrame* theFrame,  BMDTimeValue displayTime,  BMDTimeValue displayDuration,  BMDTimeScale timeScale) override { return E_NOTIMPL; }
  virtual HRESULT SetScheduledFrameCompletionCallback (IDeckLinkVideoOutputCallback* theCallback) override { return E_NOTIMPL; }
  virtual HRESULT GetBufferedVideoFrameCount (uint32_t* bufferedFrameCount) override { return E_NOTIMPL; }
  virtual HRESULT EnableAudioOutput (BMDAudioSampleRate sampleRate,  BMDAudioSampleType sampleType,  uint32_t channelCount,  BMDAudioOutputStreamType streamType) override { return E_NOTIMPL; }
  virtual HRESULT DisableAudioOutput (void) override { return E_NOTIMPL; }
  virtual HRESULT WriteAudioSamplesSync (void* buffer,  uint32_t sampleFrameCount,  uint32_t* sampleFramesWritten) override { return E_NOTIMPL; }
  virtual HRESULT BeginAudioPreroll (void) override { return E_NOTIMPL; }
  virtual HRESULT EndAudioPreroll (void) override { return E_NOTIMPL; }
  virtual HRESULT ScheduleAudioSamples (void* buffer,  uint32_t sampleFrameCount,  BMDTimeValue streamTime,  BMDTimeScale timeScale,  uint32_t* sampleFramesWritten) override { return E_NOTIMPL; }
  virtual HRESULT GetBufferedAudioSampleFrameCount (uint32_t* bufferedSampleFrameCount) override { return E_NOTIMPL; }
  virtual HRESULT FlushBufferedAudioSamples (void) override { return E_NOTIMPL; }
  virtual HRESULT SetAudioCallback (IDeckLinkAudioOutputCallback* theCallback) override { return E_NOTIMPL; }
  virtual HRESULT StartScheduledPlayback (BMDTimeValue playbackStartTime,  BMDTimeScale timeScale,  double playbackSpeed) override { return E_NOTIMPL; }
  virtual HRESULT StopScheduledPlayback (BMDTimeValue stopPlaybackAtTime,  BMDTimeValue* actualStopTime,  BMDTimeScale timeScale) override { return E_NOTIMPL; }
  virtual HRESULT IsScheduledPlaybackRunning (bool* active) override { return E_NOTIMPL; }
  virtual HRESULT GetScheduledStreamTime (BMDTimeScale desiredTimeScale,  BMDTimeValue* streamTime,  double* playbackSpeed) override { return E_NOTIMPL; }
  virtual HRESULT GetReferenceStatus (BMDReferenceStatus* referenceStatus) override { return E_NOTIMPL; }
  virtual HRESULT GetHardwareReferenceClock (BMDTimeScale desiredTimeScale,  BMDTimeValue* hardwareTime,  BMDTimeValue* timeInFrame,  BMDTimeValue* ticksPerFrame) override { return E_NOTIMPL; }
  virtual HRESULT GetFrameCompletionReferenceTimestamp (IDeckLinkVideoFrame* theFrame,  BMDTimeScale desiredTimeScale,  BMDTimeValue* frameCompletionTimestamp) override { return E_NOTIMPL; }
};
struct Stub_IDeckLinkProfileAttributes : public IDeckLinkProfileAttributes {
  int r=1; HRESULT QueryInterface(REFIID, LPVOID* p) override { *p=nullptr; return E_NOINTERFACE; } ULONG AddRef() override { return ++r; } ULONG Release() override { int n=--r; if(!n) delete this; return n; }
  virtual HRESULT GetFlag (BMDDeckLinkAttributeID cfgID,  bool* value) override { return E_NOTIMPL; }
  virtual HRESULT GetInt (BMDDeckLinkAttributeID cfgID,  int64_t* value) override { return E_NOTIMPL; }
  virtual HRESULT GetFloat (BMDDeckLinkAttributeID cfgID,  double* value) override { return E_NOTIMPL; }
  virtual HRESULT GetString (BMDDeckLinkAttributeID cfgID,  const char** value) override { return E_NOTIMPL; }
  virtual HRESULT GetStringWithParam (BMDDeckLinkAttributeID cfgID,  uint64_t param,  const char** value) override { return E_NOTIMPL; }
};
struct Stub_IDeckLinkDisplayModeIterator : public IDeckLinkDisplayModeIterator {
  int r=1; HRESULT QueryInterface(REFIID, LPVOID* p) override { *p=nullptr; return E_NOINTERFACE; } ULONG AddRef() override { return ++r; } ULONG Release() override { int n=--r; if(!n) delete this; return n; }
  virtual HRESULT Next (IDeckLinkDisplayMode** deckLinkDisplayMode) override { return E_NOTIMPL; }
};
struct Stub_IDeckLinkDisplayMode : public IDeckLinkDisplayMode {
  int r=1; HRESULT QueryInterface(REFIID, LPVOID* p) override { *p=nullptr; return E_NOINTERFACE; } ULONG AddRef() override { return ++r; } ULONG Release() override { int n=--r; if(!n) delete this; return n; }
  virtual HRESULT GetName (const char** name) override { return E_NOTIMPL; }
  virtual BMDDisplayMode GetDisplayMode (void) override { return 0; }
  virtual long GetWidth (void) override { return 0; }
  virtual long GetHeight (void) override { return 0; }
  virtual HRESULT GetFrameRate (BMDTimeValue* frameDuration,  BMDTimeScale* timeScale) override { return E_NOTIMPL; }
  virtual BMDFieldDominance GetFieldDominance (void) override { return 0; }
  virtual BMDDisplayModeFlags GetFlags (void) override { return 0; }
};
struct Stub_IDeckLinkVideoInputFrame : public IDeckLinkVideoInputFrame {
  int r=1; HRESULT QueryInterface(REFIID, LPVOID* p) override { *p=nullptr; return E_NOINTERFACE; } ULONG AddRef() override { return ++r; } ULONG Release() override { int n=--r; if(!n) delete this; return n; }
  virtual HRESULT GetStreamTime (BMDTimeValue* frameTime,  BMDTimeValue* frameDuration,  BMDTimeScale timeScale) override { return E_NOTIMPL; }
  virtual HRESULT GetHardwareReferenceTimestamp (BMDTimeScale timeScale,  BMDTimeValue* frameTime,  BMDTimeValue* frameDuration) override { return E_NOTIMPL; }
  virtual long GetWidth (void) override { return 0; }
  virtual long GetHeight (void) override { return 0; }
  virtual long GetRowBytes (void) override { return 0; }
  virtual BMDPixelFormat GetPixelFormat (void) override { return 0; }
  virtual BMDFrameFlags GetFlags (void) override { return 0; }
  virtual HRESULT GetTimecode (BMDTimecodeFormat format,  IDeckLinkTimecode** timecode) override { return E_NOTIMPL; }
  virtual HRESULT GetAncillaryData (IDeckLinkVideoFrameAncillary** ancillary) override { return E_NOTIMPL; }
};
struct Stub_IDeckLinkMutableVideoFrame : public IDeckLinkMutableVideoFrame {
  int r=1; HRESULT QueryInterface(REFIID, LPVOID* p) override { *p=nullptr; return E_NOINTERFACE; } ULONG AddRef() override { return ++r; } ULONG Release() override { int n=--r; if(!n) delete this; return n; }
  virtual HRESULT SetFlags (BMDFrameFlags newFlags) override { return E_NOTIMPL; }
  virtual HRESULT SetTimecode (BMDTimecodeFormat format,  IDeckLinkTimecode* timecode) override { return E_NOTIMPL; }
  virtual HRESULT SetTimecodeFromComponents (BMDTimecodeFormat format,  uint8_t hours,  uint8_t minutes,  uint8_t seconds,  uint8_t frames,  BMDTimecodeFlags flags) override { return E_NOTIMPL; }
  virtual HRESULT SetAncillaryData (IDeckLinkVideoFrameAncillary* ancillary) override { return E_NOTIMPL; }
  virtual HRESULT SetTimecodeUserBits (BMDTimecodeFormat format,  BMDTimecodeUserBits userBits) override { return E_NOTIMPL; }
  virtual HRESULT SetInterfaceProvider (REFIID iid,  IUnknown* iface) override { return E_NOTIMPL; }
  virtual long GetWidth (void) override { return 0; }
  virtual long GetHeight (void) override { return 0; }
  virtual long GetRowBytes (void) override { return 0; }
  virtual BMDPixelFormat GetPixelFormat (void) override { return 0; }
  virtual BMDFrameFlags GetFlags (void) override { return 0; }
  virtual HRESULT GetTimecode (BMDTimecodeFormat format,  IDeckLinkTimecode** timecode) override { return E_NOTIMPL; }
  virtual HRESULT GetAncillaryData (IDeckLinkVideoFrameAncillary** ancillary) override { return E_NOTIMPL; }
};
struct Stub_IDeckLinkVideoBuffer : public IDeckLinkVideoBuffer {
  int r=1; HRESULT QueryInterface(REFIID, LPVOID* p) override { *p=nullptr; return E_NOINTERFACE; } ULONG AddRef() override { return ++r; } ULONG Release() override { int n=--r; if(!n) delete this; return n; }
  virtual HRESULT GetBytes (void** buffer) override { return E_NOTIMPL; }
  virtual HRESULT GetSize (uint64_t* size) override { return E_NOTIMPL; }
  virtual HRESULT StartAccess (BMDBufferAccessFlags flags) override { return E_NOTIMPL; }
  virtual HRESULT EndAccess (BMDBufferAccessFlags flags) override { return E_NOTIMPL; }
};
struct Stub_IDeckLinkVideoFrame : public IDeckLinkVideoFrame {
  int r=1; HRESULT QueryInterface(REFIID, LPVOID* p) override { *p=nullptr; return E_NOINTERFACE; } ULONG AddRef() override { return ++r; } ULONG Release() override { int n=--r; if(!n) delete this; return n; }
  virtual long GetWidth (void) override { return 0; }
  virtual long GetHeight (void) override { return 0; }
  virtual long GetRowBytes (void) override { return 0; }
  virtual BMDPixelFormat GetPixelFormat (void) override { return 0; }
  virtual BMDFrameFlags GetFlags (void) override { return 0; }
  virtual HRESULT GetTimecode (BMDTimecodeFormat format,  IDeckLinkTimecode** timecode) override { return E_NOTIMPL; }
  virtual HRESULT GetAncillaryData (IDeckLinkVideoFrameAncillary** ancillary) override { return E_NOTIMPL; }
};