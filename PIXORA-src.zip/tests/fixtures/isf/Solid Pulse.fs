/*{
  "DESCRIPTION": "Test generator: fills with a colour, a long selects the quadrant, a point marks a dot",
  "CREDIT": "PIXORA tests",
  "ISFVSN": "2",
  "CATEGORIES": ["Generator", "Test"],
  "INPUTS": [
    { "NAME": "level", "TYPE": "float", "DEFAULT": 1.0, "MIN": 0.0, "MAX": 1.0 },
    { "NAME": "tint", "TYPE": "color", "DEFAULT": [1.0, 0.0, 0.0, 1.0] },
    { "NAME": "side", "TYPE": "long", "VALUES": [0, 1, 2], "LABELS": ["Full", "Left", "Right"], "DEFAULT": 0 },
    { "NAME": "invert", "TYPE": "bool", "DEFAULT": false },
    { "NAME": "spot", "TYPE": "point2D", "DEFAULT": [0.0, 0.0], "MIN": [0.0, 0.0], "MAX": [1.0, 1.0] },
  ]
}*/
void main() {
  vec4 c = tint * level;
  vec2 uv = isf_FragNormCoord;
  if (side == 1 && uv.x > 0.5) c = vec4(0.0, 0.0, 0.0, 1.0);
  if (side == 2 && uv.x < 0.5) c = vec4(0.0, 0.0, 0.0, 1.0);
  if (invert) c.rgb = 1.0 - c.rgb;
  if (distance(gl_FragCoord.xy / RENDERSIZE, spot) < 0.05) c = vec4(1.0);
  gl_FragColor = vec4(c.rgb, 1.0);
}
