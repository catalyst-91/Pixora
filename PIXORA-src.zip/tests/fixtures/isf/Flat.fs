/*{ "DESCRIPTION": "Flat colour (test fixture)", "ISFVSN": "2", "CATEGORIES": ["Generator"],
  "INPUTS": [ { "NAME": "col", "TYPE": "color", "DEFAULT": [1, 0, 0, 1] } ] }*/
void main() { gl_FragColor = col; }
