/*{ "DESCRIPTION": "Hard wipe (test fixture): the end image grows from the left, or from the right when flipped", "ISFVSN": "2", "CATEGORIES": ["Wipe"],
  "INPUTS": [ { "NAME": "startImage", "TYPE": "image" }, { "NAME": "endImage", "TYPE": "image" },
    { "NAME": "progress", "TYPE": "float", "MIN": 0, "MAX": 1, "DEFAULT": 0 }, { "NAME": "flip", "TYPE": "bool", "DEFAULT": false } ] }*/
void main() { vec2 uv = isf_FragNormCoord; float x = flip ? 1.0 - uv.x : uv.x;
  gl_FragColor = x < progress ? IMG_NORM_PIXEL(endImage, uv) : IMG_NORM_PIXEL(startImage, uv); }
