/*{
  "DESCRIPTION": "IMPORTED image and a custom vertex shader with a varying",
  "INPUTS": [ { "NAME": "wobble", "TYPE": "float", "DEFAULT": 0.0 } ],
  "IMPORTED": { "logo": { "PATH": "logo.png" } }
}*/
varying vec2 shifted;
void main() { gl_FragColor = IMG_NORM_PIXEL(logo, shifted); }
