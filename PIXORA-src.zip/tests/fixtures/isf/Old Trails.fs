/*{
  "DESCRIPTION": "ISF 1.0 style: PERSISTENT_BUFFERS and vv_FragNormCoord",
  "INPUTS": [ { "NAME": "inputImage", "TYPE": "image" } ],
  "PERSISTENT_BUFFERS": ["trail"],
  "PASSES": [ { "TARGET": "trail" }, {} ]
}*/
void main() {
  if (PASSINDEX == 0) gl_FragColor = max(IMG_THIS_PIXEL(inputImage), IMG_NORM_PIXEL(trail, vv_FragNormCoord) * 0.9);
  else gl_FragColor = IMG_THIS_PIXEL(trail);
}
