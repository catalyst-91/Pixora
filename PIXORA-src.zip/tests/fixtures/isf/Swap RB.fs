/*{
  "DESCRIPTION": "Test filter: swaps red and blue, uses IMG_PIXEL / IMG_SIZE",
  "CATEGORIES": ["Color Adjustment"],
  "INPUTS": [ { "NAME": "inputImage", "TYPE": "image" }, { "NAME": "amount", "TYPE": "float", "DEFAULT": 1.0 } ]
}*/
void main() {
  vec4 a = IMG_PIXEL(inputImage, isf_FragNormCoord * IMG_SIZE(inputImage));
  vec4 b = IMG_THIS_PIXEL(inputImage);
  gl_FragColor = mix(a, vec4(b.b, b.g, b.r, b.a), amount);
}
