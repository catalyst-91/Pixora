/*{
  "DESCRIPTION": "Test multi-pass: half-size pass then a persistent buffer that brightens each frame (feedback)",
  "INPUTS": [ { "NAME": "rate", "TYPE": "float", "DEFAULT": 0.02, "MIN": 0.0, "MAX": 0.5 } ],
  "PASSES": [ { "TARGET": "small", "WIDTH": "floor($WIDTH/2.0)", "HEIGHT": "$HEIGHT/2" }, { "TARGET": "acc", "PERSISTENT": true }, {} ]
}*/
void main() {
  if (PASSINDEX == 0) gl_FragColor = vec4(0.0, 1.0, 0.0, 1.0);
  else if (PASSINDEX == 1) { vec4 prev = IMG_NORM_PIXEL(acc, isf_FragNormCoord); gl_FragColor = vec4(min(1.0, prev.r + rate), 0.0, 0.0, 1.0); }
  else { vec4 s = IMG_THIS_NORM_PIXEL(small); vec4 a = IMG_THIS_PIXEL(acc); gl_FragColor = vec4(a.r, s.g * 0.5, float(IMG_SIZE(small).x) / 1000.0, 1.0); }
}
