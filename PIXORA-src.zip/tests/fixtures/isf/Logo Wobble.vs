varying vec2 shifted;
void main() { isf_vertShaderInit(); shifted = isf_FragNormCoord + vec2(wobble, 0.0); }
