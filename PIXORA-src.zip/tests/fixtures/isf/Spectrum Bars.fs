/*{
  "DESCRIPTION": "audioFFT input + TIME + an event",
  "INPUTS": [ { "NAME": "fft", "TYPE": "audioFFT", "MAX": 64 }, { "NAME": "flash", "TYPE": "event" } ]
}*/
void main() {
  float v = IMG_NORM_PIXEL(fft, vec2(isf_FragNormCoord.x, 0.5)).r;
  float bar = step(isf_FragNormCoord.y, v);
  gl_FragColor = flash ? vec4(1.0) : vec4(bar, bar * 0.5, 0.5 + 0.5 * sin(TIME), 1.0);
}
