# Builds the small glTF test models used by tests/scene3d_check.py (run by the check itself; no files are committed).
import json, struct, io
from PIL import Image
def glb(gltf, binary):
  while len(binary) % 4: binary += b'\0'
  gltf['buffers'] = [{'byteLength': len(binary)}]; j = json.dumps(gltf).encode()
  while len(j) % 4: j += b' '
  return struct.pack('<III', 0x46546C67, 2, 12 + 8 + len(j) + 8 + len(binary)) + struct.pack('<II', len(j), 0x4E4F534A) + j + struct.pack('<II', len(binary), 0x004E4942) + binary
class B:
  def __init__(s): s.bin = b''; s.views = []; s.acc = []
  def add(s, data, target=None):
    while len(s.bin) % 4: s.bin += b'\0'
    v = {'buffer': 0, 'byteOffset': len(s.bin), 'byteLength': len(data)}
    if target: v['target'] = target
    s.views.append(v); s.bin += data; return len(s.views) - 1
  def accessor(s, fmt, comp, typ, vals, n, target=None, minmax=False):
    data = struct.pack('<' + fmt * len(vals), *vals); a = {'bufferView': s.add(data, target), 'componentType': comp, 'count': len(vals) // n, 'type': typ}
    if minmax: a['min'] = [min(vals[i::n]) for i in range(n)]; a['max'] = [max(vals[i::n]) for i in range(n)]
    s.acc.append(a); return len(s.acc) - 1
def cube(b):
  P, N, I = [], [], []
  for ax in range(3):
    for sg in (1, -1):
      n = [0, 0, 0]; n[ax] = sg; u = [0, 0, 0]; u[(ax + 1) % 3] = 1; v = [0, 0, 0]; v[(ax + 2) % 3] = 1; base = len(P) // 3
      for a, c in ((-1, -1), (1, -1), (1, 1), (-1, 1)): P += [n[k] + a * u[k] + c * v[k] for k in range(3)]; N += n
      I += [base, base + 1, base + 2, base, base + 2, base + 3] if sg > 0 else [base, base + 2, base + 1, base, base + 3, base + 2]
  return {'POSITION': b.accessor('f', 5126, 'VEC3', P, 3, 34962, True), 'NORMAL': b.accessor('f', 5126, 'VEC3', N, 3, 34962)}, b.accessor('H', 5123, 'SCALAR', I, 1, 34963)
def animated_cube():
  b = B(); attrs, idx = cube(b)
  t = b.accessor('f', 5126, 'SCALAR', [0, 1, 2], 1, None, True); tr = b.accessor('f', 5126, 'VEC3', [-2, 0, 0, 2, 0, 0, -2, 0, 0], 3)
  cpos = b.accessor('f', 5126, 'VEC3', [0, 0, 9, 0, 0, 14, 0, 0, 9], 3)
  g = {'asset': {'version': '2.0'}, 'scene': 0, 'scenes': [{'nodes': [0, 2]}], 'nodes': [{'mesh': 0}, {'mesh': 0, 'translation': [0, 0, -30], 'scale': [0.01, 0.01, 0.01]}, {'camera': 0, 'translation': [0, 0, 9]}],
    'cameras': [{'type': 'perspective', 'perspective': {'yfov': 0.6, 'znear': 0.1, 'zfar': 100, 'aspectRatio': 1.78}}],
    'meshes': [{'primitives': [{'attributes': attrs, 'indices': idx, 'material': 0}]}], 'materials': [{'pbrMetallicRoughness': {'baseColorFactor': [1, 0.05, 0.05, 1], 'metallicFactor': 0, 'roughnessFactor': 0.6}}],
    'animations': [{'samplers': [{'input': t, 'output': tr, 'interpolation': 'LINEAR'}, {'input': t, 'output': cpos, 'interpolation': 'LINEAR'}], 'channels': [{'sampler': 0, 'target': {'node': 0, 'path': 'translation'}}, {'sampler': 1, 'target': {'node': 2, 'path': 'translation'}}]}],
    'accessors': b.acc, 'bufferViews': b.views}
  return glb(g, b.bin)
def textured_quad():
  b = B(); im = Image.new('RGB', (64, 64)); px = im.load()
  for y in range(64):
    for x in range(64): px[x, y] = (255, 220, 0) if x < 32 else (0, 60, 255)
  for y in range(0, 8):  # a white strip along the top edge of the picture
    for x in range(64): px[x, y] = (255, 255, 255)
  f = io.BytesIO(); im.save(f, 'PNG'); png = f.getvalue()
  P = [-1, -1, 0, 1, -1, 0, 1, 1, 0, -1, 1, 0]; UV = [0, 1, 1, 1, 1, 0, 0, 0]; N = [0, 0, 1] * 4
  attrs = {'POSITION': b.accessor('f', 5126, 'VEC3', P, 3, 34962, True), 'NORMAL': b.accessor('f', 5126, 'VEC3', N, 3, 34962), 'TEXCOORD_0': b.accessor('f', 5126, 'VEC2', UV, 2, 34962)}
  idx = b.accessor('B', 5121, 'SCALAR', [0, 1, 2, 0, 2, 3], 1, 34963); img = b.add(png)
  g = {'asset': {'version': '2.0'}, 'scenes': [{'nodes': [0]}], 'nodes': [{'mesh': 0}], 'meshes': [{'primitives': [{'attributes': attrs, 'indices': idx, 'material': 0}]}],
    'materials': [{'pbrMetallicRoughness': {'baseColorTexture': {'index': 0}, 'metallicFactor': 0}, 'extensions': {'KHR_materials_unlit': {}}, 'doubleSided': True}], 'extensionsUsed': ['KHR_materials_unlit'],
    'textures': [{'source': 0}], 'images': [{'bufferView': img, 'mimeType': 'image/png'}], 'accessors': b.acc, 'bufferViews': b.views}
  return glb(g, b.bin)
