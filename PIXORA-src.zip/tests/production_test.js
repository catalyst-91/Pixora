// PIXORA live-production test: switcher (preview / CUT / AUTO / T-bar), overlay channels, shared timers, keyboard
// shortcuts, cue actions, and remote-guest signalling (invite key, isolation from show state, relay to outputs only).
//   node tests/production_test.js
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
(async () => {
  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxprod-')), MEDIA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxprodm-'));
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8879, OSC_PORT: 8880, DATA_DIR: DATA, MEDIA_DIR: MEDIA }, stdio: ['ignore', 'pipe', 'pipe'] }); kids.push(srv);
  const B = 'http://127.0.0.1:8879';
  for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const cmd = c => fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(c) }), st = () => fetch(B + '/api/state').then(r => r.json());
  const solid = (n, c) => ({ type: 'gen', name: n, gen: { kind: 'solid', params: { c1: c } } });
  for (const [i, n] of ['Cam 1', 'Cam 2', 'Slides'].entries()) await cmd({ op: 'set', path: `layers.0.clips.${i}`, value: solid(n, '#' + ['f00', '00f', '0f0'][i]) });
  await cmd({ op: 'trigger', layer: 0, clip: 0 }); await cmd({ op: 'switcher', a: 'set', on: true, layer: 0 }); await cmd({ op: 'switcher', a: 'preview', clip: 1 });
  let s = await st(); assert.deepStrictEqual([s.layers[0].active, s.switcher.preview], [0, 1]); ok('switcher: program Cam 1, preview Cam 2');
  await cmd({ op: 'switcher', a: 'cut' }); s = await st(); assert.deepStrictEqual([s.layers[0].active, s.switcher.preview, s.layers[0].cutTrig === s.layers[0].trig], [1, 0, true]); ok('CUT swaps program and preview (marked as a cut, no transition)');
  await cmd({ op: 'switcher', a: 'preview', clip: 2 }); await cmd({ op: 'switcher', a: 'auto' }); s = await st(); assert.deepStrictEqual([s.layers[0].active, s.switcher.preview, s.layers[0].cutTrig === s.layers[0].trig], [2, 1, false]); ok('AUTO takes Slides with the layer transition');
  await cmd({ op: 'switcher', a: 'tbar', value: 0.4 }); s = await st(); assert.strictEqual(s.switcher.tbar, 0.4); await cmd({ op: 'switcher', a: 'tbar', value: 1 }); s = await st(); assert.deepStrictEqual([s.layers[0].active, s.switcher.tbar], [1, 0]); ok('T-bar: 40% holds the mix, 100% completes the take and resets');
  await cmd({ op: 'runAction', action: { type: 'switcher', mode: 'auto' } }); s = await st(); assert.strictEqual(s.layers[0].active, 2); ok('cue action "Switcher AUTO"');
  // overlays
  await cmd({ op: 'overlay', n: 2, a: 'on' }); s = await st(); assert.strictEqual(s.overlays[1].on, false); ok('an empty overlay channel cannot go on air');
  await cmd({ op: 'overlay', n: 2, a: 'set', clip: { type: 'gen', name: 'Lower third', gen: { kind: 'title', params: { tpl: 0 } } } }); await cmd({ op: 'runAction', action: { type: 'overlay', n: 2, mode: 'toggle' } });
  s = await st(); assert.strictEqual(s.overlays[1].on, true); await cmd({ op: 'overlay', a: 'allOff', n: 1 }); s = await st(); assert.strictEqual(s.overlays[1].on, false); ok('overlay 2 toggled on by a cue, all overlays off');
  // timers
  await cmd({ op: 'timer', name: 'Doors', a: 'set', mode: 'down', secs: 120 }); await cmd({ op: 'timer', name: 'Doors', a: 'start' }); await tick(600); await cmd({ op: 'timer', name: 'Doors', a: 'stop' });
  s = await st(); let t = s.timers.find(x => x.name === 'Doors'); assert.ok(t.base > 0.4 && t.base < 1.2 && !t.running, JSON.stringify(t)); await cmd({ op: 'timer', name: 'Doors', a: 'add', secs: 30 }); s = await st(); t = s.timers[0];
  assert.ok(t.base < 0, 'adding 30 s to a countdown'); await cmd({ op: 'runAction', action: { type: 'timer', name: 'doors', mode: 'reset' } }); s = await st(); assert.strictEqual(s.timers[0].base, 0); ok('timer: start / stop keeps elapsed time, +30 s, reset by a cue (names match case-insensitively)');
  // shortcuts are saved with the show
  await cmd({ op: 'shortcuts', list: [{ key: 'F5', action: { type: 'overlay', n: 1, mode: 'toggle' } }, { key: '', action: {} }] }); s = await st(); assert.deepStrictEqual(s.shortcuts.map(k => k.key), ['F5']); ok('keyboard shortcuts saved with the show (empty rows dropped)');
  // guests
  const g = await fetch(B + '/api/guests').then(r => r.json()); assert.ok(/^[0-9a-f]{12}$/.test(g.key)); ok('invite key issued to operators');
  const open = url => new Promise((res, rej) => { const w = new WebSocket(url); const msgs = []; w.onmessage = e => msgs.push(JSON.parse(e.data)); w.onopen = () => res(Object.assign(w, { msgs })); w.onerror = () => rej(new Error('refused')); });
  await assert.rejects(open('ws://127.0.0.1:8879/ws?role=guest&key=000000000000')); ok('wrong invite key refused');
  const out = await open('ws://127.0.0.1:8879/ws?role=output'), guest = await open(`ws://127.0.0.1:8879/ws?role=guest&key=${g.key}&name=Sam`); await tick(300);
  const gh = guest.msgs.find(m => m.t === 'hello'); assert.strictEqual(gh.slot, 1); assert.strictEqual(gh.name, 'Sam');
  const outGuests = out.msgs.filter(m => m.t === 'guests').pop(); assert.deepStrictEqual(outGuests.guests.map(x => [x.slot, x.name]), [[1, 'Sam']]); ok('guest joins as Guest 1 "Sam"; outputs are told');
  const outId = out.msgs.find(m => m.t === 'hello').id;
  guest.send(JSON.stringify({ t: 'rtc', to: outId, data: { sdp: { type: 'offer', sdp: 'v=0' } } })); await tick(150);
  const relayed = out.msgs.find(m => m.t === 'rtc'); assert.deepStrictEqual([relayed.from, relayed.slot, relayed.data.sdp.type], [gh.id, 1, 'offer']); ok('signalling relayed guest → output');
  guest.send(JSON.stringify({ t: 'cmd', cmd: { op: 'set', path: 'comp.master', value: 0 } })); await cmd({ op: 'trigger', layer: 0, clip: 0 }); await tick(300);
  s = await st(); assert.notStrictEqual(s.comp.master, 0); assert.ok(!guest.msgs.some(m => ['state', 'patch', 'presence', 'outputs', 'feeds'].includes(m.t)), guest.msgs.map(m => m.t).join(','));
  ok('guest cannot send commands and never receives show state (' + [...new Set(guest.msgs.map(m => m.t))].join(', ') + ')');
  const ctl = await open('ws://127.0.0.1:8879/ws?role=control'); ctl.send(JSON.stringify({ t: 'guestKick', slot: 1 })); await tick(500); assert.strictEqual(guest.readyState, 3); ok('operator ends the guest session');
  [out, ctl].forEach(w => w.close()); srv.kill(); console.log('\nAll production tests passed.'); process.exit(0);
})().catch(e => { console.error('✗', e); process.exit(1); });
