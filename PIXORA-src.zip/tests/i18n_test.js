// Interface language packs: every built-in pack has the same strings, no empty values, placeholders kept ({n}, {l}…),
// and the packs + engine are served. The on-screen behaviour (switching, patterns, restoring English) is checked in Chrome.
//   node tests/i18n_test.js
const fs = require('fs'), path = require('path'), assert = require('assert');
const DIR = path.join(__dirname, '..', 'public', 'i18n'), langs = ['es', 'fr', 'de', 'pt', 'ja', 'zh', 'it', 'ko'];
const packs = Object.fromEntries(langs.map(l => [l, JSON.parse(fs.readFileSync(path.join(DIR, l + '.json'), 'utf8'))]));
const keys = Object.keys(packs.es);
for (const l of langs) {
  assert.deepStrictEqual(Object.keys(packs[l]).sort(), keys.slice().sort(), l + ' has a different set of strings');
  for (const k of keys) { const v = packs[l][k]; assert.ok(typeof v === 'string' && v.trim(), `${l}: empty translation for "${k}"`);
    for (const ph of k.match(/\{\w+\}/g) || []) assert.ok(v.includes(ph), `${l}: "${k}" lost ${ph}`);
    for (const sym of ['…', '●', '■', '▶', '◀', '＋', '→', '←', '↑', '↓', '›']) if (k.includes(sym)) assert.ok(v.includes(sym), `${l}: "${k}" lost ${sym}`); }
}
const engine = fs.readFileSync(path.join(__dirname, '..', 'public', 'i18n.js'), 'utf8');
for (const l of langs) assert.ok(engine.includes(`${l}: '`), 'engine lists ' + l);
const index = fs.readFileSync(path.join(__dirname, '..', 'public', 'index.html'), 'utf8'); assert.ok(index.includes('/i18n.js') && index.includes('/i18n-ui.js'));
console.log(`✓ ${langs.length} language packs × ${keys.length} strings, identical keys, no blanks, placeholders and symbols kept`);
console.log('i18n test passed');
