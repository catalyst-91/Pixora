// Exercise the Windows/macOS temperature samplers with stubbed commands
const fs = require('fs'), vm = require('vm');
const src = fs.readFileSync(require('path').join(__dirname, '..', 'server.js'), 'utf8');
const code = src.slice(src.indexOf('let tempCache ='), src.indexOf("if (process.platform === 'win32' || process.platform === 'darwin') { setTimeout"));
async function run(platform, outputs) {
  const calls = [];
  const ctx = { fs, process: { platform }, execFile: (cmd, args, o, cb) => { calls.push(cmd + ' ' + args.join(' ').slice(0, 60)); const k = Object.keys(outputs).find(k => (cmd + ' ' + args.join(' ')).includes(k)); setTimeout(() => k ? cb(null, outputs[k]) : cb(new Error('nf'), ''), 1); }, Promise, parseFloat, Math, Date, setTimeout };
  vm.createContext(ctx); vm.runInContext(code + ';this.sampleTemp=sampleTemp;this.cpuTemp=cpuTemp;this.get=()=>tempCache;', ctx);
  await ctx.sampleTemp(); return { temp: ctx.cpuTemp(), cache: ctx.get(), calls };
}
(async () => {
  let r = await run('win32', { 'Counters_ThermalZoneInformation': '3231\r\n' });
  console.log('win perf counter →', r.temp, r.cache.src); if (Math.abs(r.temp - 49.95) > 0.1) throw 'win1';
  r = await run('win32', { 'MSAcpi': '3332\r\n' });
  console.log('win ACPI fallback →', r.temp, r.cache.src); if (Math.abs(r.temp - 60.05) > 0.1) throw 'win2';
  r = await run('win32', { 'MSAcpi': '2732' }); console.log('win bogus 0K-ish value discarded? →', r.temp);
  r = await run('win32', {}); console.log('win no sensors →', r.temp); if (r.temp !== null) throw 'win3';
  r = await run('darwin', { 'pmset': 'CPU_Power_notify = 0\n CPU_Scheduler_Limit \t= 100\n CPU_Available_CPUs = 8\n CPU_Speed_Limit \t= 72\n' });
  console.log('mac pmset →', r.temp, 'throttle', r.cache.throttle); if (r.cache.throttle !== 28) throw 'mac1';
  r = await run('darwin', { 'osx-cpu-temp': '61.3°C\n', pmset: 'CPU_Speed_Limit = 100' });
  console.log('mac osx-cpu-temp →', r.temp, 'throttle', r.cache.throttle); if (r.temp !== 61.3 || r.cache.throttle !== 0) throw 'mac2';
  console.log('TEMP TESTS PASS');
})().catch(e => { console.error('FAIL', e); process.exit(1); });
