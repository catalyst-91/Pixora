// Update installer test: copies PIXORA to a scratch folder, serves an update feed, applies it, checks checksum enforcement,
// path-traversal filtering, backup, file replacement and the automatic restart on the new version.
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), http = require('http'), zlib = require('zlib'), crypto = require('crypto'), assert = require('assert');
const SRC = path.join(__dirname, '..'), TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'pxupd-')), APP = path.join(TMP, 'app'), PORT = 8823, B = `http://127.0.0.1:${PORT}`;
const tick = ms => new Promise(r => setTimeout(r, ms));
for (const f of fs.readdirSync(SRC).filter(f => /^server[\w-]*\.js$/.test(f)).concat('package.json')) fs.mkdirSync(APP, { recursive: true }), fs.copyFileSync(path.join(SRC, f), path.join(APP, f));
fs.cpSync(path.join(SRC, 'public'), path.join(APP, 'public'), { recursive: true, filter: s => !s.includes(path.join('public', 'manual', 'img')) });
function zip(files) { const parts = [], central = []; let off = 0; for (const [name, d0] of Object.entries(files)) { const data = Buffer.from(d0), nb = Buffer.from(name), def = zlib.deflateRawSync(data);
  const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(8, 8); lh.writeUInt32LE(def.length, 18); lh.writeUInt32LE(data.length, 22); lh.writeUInt16LE(nb.length, 26);
  const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(8, 10); ch.writeUInt32LE(def.length, 20); ch.writeUInt32LE(data.length, 24); ch.writeUInt16LE(nb.length, 28); ch.writeUInt32LE(off, 42);
  parts.push(lh, nb, def); central.push(ch, nb); off += 30 + nb.length + def.length; }
  const cd = Buffer.concat(central), e = Buffer.alloc(22); e.writeUInt32LE(0x06054b50, 0); e.writeUInt16LE(Object.keys(files).length, 8); e.writeUInt16LE(Object.keys(files).length, 10); e.writeUInt32LE(cd.length, 12); e.writeUInt32LE(off, 16); return Buffer.concat([...parts, cd, e]); }
const pkg = JSON.parse(fs.readFileSync(path.join(SRC, 'package.json'))); const oldV = pkg.version; pkg.version = '9.9.9';
const upd = zip({ 'PIXORA/server.js': fs.readFileSync(path.join(SRC, 'server.js')), 'PIXORA/server-pro3.js': fs.readFileSync(path.join(SRC, 'server-pro3.js')), ...Object.fromEntries(fs.readdirSync(SRC).filter(x => /^server-[\w-]+\.js$/.test(x) && x !== 'server-pro3.js').map(x => ['PIXORA/' + x, fs.readFileSync(path.join(SRC, x))])), 'PIXORA/package.json': JSON.stringify(pkg), 'PIXORA/public/update-test.txt': 'hello 9.9.9', 'PIXORA/../evil.txt': 'pwned', 'PIXORA/data/state.json': '{}' });
let manifest = { version: '9.9.9', url: 'PIXORA-9.9.9.zip', sha256: '00'.repeat(32) };
const feed = http.createServer((q, r) => { if (q.url.startsWith('/feed')) { r.writeHead(200, { 'Content-Type': 'application/json' }); r.end(JSON.stringify(manifest)); } else { r.writeHead(200); r.end(upd); } });
let srv;
(async () => {
  await new Promise(r => feed.listen(0, r)); const FEED = `http://127.0.0.1:${feed.address().port}/feed.json`;
  srv = spawn(process.execPath, [path.join(APP, 'server.js')], { cwd: APP, env: { ...process.env, PORT, OSC_PORT: 7023, DATA_DIR: path.join(TMP, 'data'), MEDIA_DIR: path.join(TMP, 'media') }, stdio: 'ignore' });
  for (let i = 0; i < 40 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const post = (p, b) => fetch(B + p, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) }).then(async r => ({ status: r.status, body: await r.json() }));
  await post('/api/cmd', { op: 'set', path: 'update.feed', value: FEED });
  let r = await post('/api/update', { action: 'check' }); assert.strictEqual(r.body.latest.newer, true);
  r = await post('/api/update', { action: 'apply' }); assert.strictEqual(r.status, 400); assert.match(r.body.error, /checksum/); assert.ok(!fs.existsSync(path.join(APP, 'public', 'update-test.txt')));
  console.log('✓ bad checksum rejected, nothing written');
  manifest.sha256 = crypto.createHash('sha256').update(upd).digest('hex'); await post('/api/update', { action: 'check' });
  r = await post('/api/update', { action: 'apply' }); assert.strictEqual(r.status, 200);
  let v = null; for (let i = 0; i < 60; i++) { await tick(250); try { v = (await (await fetch(B + '/api/info')).json()).version; if (v === '9.9.9') break; } catch {} }
  assert.strictEqual(v, '9.9.9', 'restarted on new version');
  assert.strictEqual(fs.readFileSync(path.join(APP, 'public', 'update-test.txt'), 'utf8'), 'hello 9.9.9');
  assert.ok(!fs.existsSync(path.join(TMP, 'evil.txt')) && !fs.existsSync(path.join(APP, 'data', 'state.json')), 'traversal / data files filtered');
  assert.ok(fs.existsSync(path.join(APP, '.backup', oldV, 'server.js')), 'backup kept');
  console.log(`✓ update applied ${oldV} → 9.9.9, server restarted itself on the new version, backup in .backup/${oldV}, path traversal & data files ignored`);
  console.log('\nUPDATE TEST PASS');
  await fetch(B + '/api/info').catch(() => {}); try { process.kill(-srv.pid); } catch {}
  require('child_process').spawnSync('pkill', ['-f', APP + '/server.js']); feed.close(); fs.rmSync(TMP, { recursive: true, force: true }); process.exit(0);
})().catch(e => { console.error('FAIL', e); require('child_process').spawnSync('pkill', ['-f', 'server.js'], { cwd: APP }); process.exit(1); });
