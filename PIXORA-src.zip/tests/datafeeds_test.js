// Data-driven graphics: polled CSV → rows/records for tickers, push feeds edited live, Google Sheets links → CSV export.
//   node tests/datafeeds_test.js
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert'), http = require('http');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
(async () => {
  let csv = 'Team,Pts\nLions,12\nTigers,9\n';
  const web = http.createServer((q, r) => { r.writeHead(200, { 'Content-Type': 'text/csv' }); r.end(csv); }); await new Promise(r => web.listen(8858, '127.0.0.1', r));
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8856, OSC_PORT: 8857, DATA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxdf-')), MEDIA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxdfm-')) }, stdio: 'ignore' }); kids.push(srv);
  const B = 'http://127.0.0.1:8856';
  for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const cmd = c => fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(c) });
  const feeds = () => fetch(B + '/api/feeds').then(r => r.json());
  await cmd({ op: 'feedAdd', feed: { id: 'table', name: 'table', type: 'csv', url: 'http://127.0.0.1:8858/t.csv', interval: 1 } });
  let v; for (let i = 0; i < 40 && !((v = (await feeds()).values.table) && v.records); i++) await tick(200);
  assert.deepStrictEqual(v.records, [{ Team: 'Lions', Pts: '12' }, { Team: 'Tigers', Pts: '9' }]); assert.strictEqual(v.B2, '12'); ok('CSV feed → records (for tickers / row cycling) and cells (B2)');
  csv = 'Team,Pts\nLions,13\nTigers,9\nBears,7\n'; for (let i = 0; i < 30 && (await feeds()).values.table.records.length !== 3; i++) await tick(200);
  assert.strictEqual((await feeds()).values.table.records.length, 3); ok('rows added to the sheet show up on the next poll');
  await cmd({ op: 'feedAdd', feed: { id: 'score', name: 'score', type: 'push' } }); await cmd({ op: 'feedSet', id: 'score', value: { homeScore: 2, period: 'Chukka 3' } }); await tick(300);
  assert.deepStrictEqual((await feeds()).values.score, { homeScore: 2, period: 'Chukka 3' }); ok('push feed values set from PIXORA (live values editor)');
  await fetch(B + '/api/feed/score?homeScore=3'); await tick(300); assert.strictEqual(+(await feeds()).values.score.homeScore, 3); ok('another app can still push (GET /api/feed/score?homeScore=3)');
  const conv = async u => (await fetch(B + '/api/feed-url?u=' + encodeURIComponent(u)).then(r => r.json())).url;
  const ID = '1AbCdEfGhIjKlMnOpQrStUvWxYz0123456789';
  assert.strictEqual(await conv(`https://docs.google.com/spreadsheets/d/${ID}/edit#gid=12345`), `https://docs.google.com/spreadsheets/d/${ID}/export?format=csv&gid=12345`);
  assert.strictEqual(await conv(`https://docs.google.com/spreadsheets/d/${ID}/edit?usp=sharing`), `https://docs.google.com/spreadsheets/d/${ID}/export?format=csv`);
  assert.strictEqual(await conv('https://docs.google.com/spreadsheets/d/e/2PACX-1vabc/pub?output=csv'), 'https://docs.google.com/spreadsheets/d/e/2PACX-1vabc/pub?output=csv');
  assert.strictEqual(await conv('https://example.com/a.csv'), 'https://example.com/a.csv'); ok('Google Sheets share links → CSV export (published links and other URLs untouched)');
  web.close(); console.log('datafeeds_test: all passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
