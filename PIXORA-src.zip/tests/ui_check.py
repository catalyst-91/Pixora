# Controller UI checks in real Chrome: interface languages (switch, patterns, back to English, remembered), ISF controls
# appear on an ISF clip, the versions compare dialog lists changes. Needs Python Playwright + Chrome:
#   python3 tests/ui_check.py [path-to-chrome]
import json, urllib.request, subprocess, os, time, sys, tempfile
from playwright.sync_api import sync_playwright
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); CHROME = sys.argv[1] if len(sys.argv) > 1 else '/usr/bin/google-chrome'
B = 'http://127.0.0.1:8919'; tmp = tempfile.mkdtemp()
srv = subprocess.Popen(['node', 'server.js'], cwd=ROOT, env=dict(os.environ, PORT='8919', OSC_PORT='8920', DATA_DIR=tmp + '/d', MEDIA_DIR=tmp + '/m'), stdout=open(tmp + '/log', 'w'), stderr=subprocess.STDOUT)
def cmd(b): urllib.request.urlopen(urllib.request.Request(B + '/api/cmd', data=json.dumps(b).encode(), headers={'Content-Type': 'application/json'})).read()
for _ in range(60):
  try: urllib.request.urlopen(B + '/api/info'); break
  except Exception: time.sleep(0.2)
ok = lambda m: print('✓ ' + m)
try:
  cmd({'op': 'shaderSave', 'shader': {'id': 'g', 'name': 'Pulse', 'code': open(os.path.join(ROOT, 'tests/fixtures/isf/Solid Pulse.fs')).read()}})
  cmd({'op': 'assign', 'layer': 0, 'slot': 0, 'clip': {'type': 'gen', 'name': 'Pulse', 'gen': {'kind': 'shader', 'params': {'shader': 'g', 'p1': .5, 'p2': .5, 'p3': .5, 'p4': .5, 'isf': {}}}}})
  cmd({'op': 'versionSave', 'label': 'Before'}); cmd({'op': 'set', 'path': 'layers.1.opacity', 'value': 0.5})
  with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=['--use-gl=swiftshader', '--enable-unsafe-swiftshader'])
    pg = b.new_page(viewport={'width': 1600, 'height': 1000}); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(B + '/'); time.sleep(2)
    txt = lambda sel: pg.evaluate(f"() => document.querySelector({json.dumps(sel)}).textContent.trim()")
    pg.evaluate("() => PX_I18N.set('es')"); time.sleep(0.8)
    lh = pg.evaluate("() => [...document.querySelectorAll('[data-lh]')].map(e => e.textContent).join(' ')")
    assert 'Capa 1' in lh and 'Borrar todo' in pg.content(), lh[:200]; ok('Spanish: layer names via the "Layer {n}" pattern, toolbar buttons translated')
    pg.evaluate("() => PX_I18N.set('ja')"); time.sleep(0.8); assert 'レイヤー1' in pg.evaluate("() => document.body.innerText"); ok('Japanese')
    pg.evaluate("() => PX_I18N.set('en')"); time.sleep(0.8); body = pg.evaluate("() => document.body.innerText")
    assert 'Layer 1' in body and 'Clear all' in body and 'レイヤー' not in body and 'Capa' not in body; ok('back to English restores every original string')
    pg.evaluate("() => PX_I18N.set('fr')"); pg.reload(); time.sleep(2); assert pg.evaluate("() => PX_I18N.lang()") == 'fr' and 'Calque 1' in pg.evaluate("() => document.body.innerText"); ok('choice remembered per screen')
    pg.evaluate("() => PX_I18N.set('en')"); time.sleep(0.5)
    pg.evaluate("() => UI.select(0, 0)"); time.sleep(1); body = pg.evaluate("() => document.querySelector('#right, .right, aside') ? document.body.innerText : document.body.innerText")
    assert all(x in body for x in ['level', 'tint', 'side', 'invert', 'spot X']), 'ISF inputs not shown'; ok('ISF generator inputs shown as controls on the clip')
    pg.evaluate("() => UI.setBtab('shows')"); time.sleep(1.2); pg.locator('[data-vercmp]').first.click(); time.sleep(1)
    assert 'Layer 2 settings' in pg.evaluate("() => document.querySelector('.modal').innerText"); ok('versions: compare dialog lists the change')
    cmd({'op': 'audioOutAdd', 'name': 'Record feed', 'ch': 3}); time.sleep(0.6); pg.evaluate("() => UI.setRtab('mixer')"); time.sleep(1)
    t = pg.evaluate("() => document.body.innerText"); assert 'Record feed' in t and 'Add output' in t and pg.locator('select.mxroute').count() >= 2; pg.screenshot(path=os.environ.get('PX_SHOT_DIR', tmp) + '/mixer.png')
    ok('audio mixer: outputs list with device / channels, and a route menu on every layer strip')
    pg.keyboard.press('Escape'); time.sleep(0.3)
    cmd({'op': 'shaderSave', 'shader': {'id': 'hw', 'name': 'Hard Wipe', 'code': open(os.path.join(ROOT, 'tests', 'fixtures', 'isf', 'Hard Wipe.fs')).read()}}); cmd({'op': 'set', 'path': 'layers.0.transition', 'value': 'isf:hw'}); time.sleep(0.6)
    pg.evaluate("() => { UI.select(0, null); UI.setRtab('layer') }"); time.sleep(1); t = pg.evaluate("() => document.body.innerText")
    assert 'ISF · Hard Wipe' in pg.content() and 'flip' in t and 'startImage' not in t, 'ISF transition menu / inputs'; ok('layer transition menu lists ISF transitions; their inputs show, startImage / endImage / progress don\'t')
    urllib.request.urlopen(urllib.request.Request(B + '/api/settings', data=json.dumps({'backup': {'mode': 'node', 'primary': 'http://127.0.0.1:9', 'syncScope': 'library', 'syncMbps': 50}}).encode(), headers={'Content-Type': 'application/json'})).read()
    pg.reload(); time.sleep(2); pg.evaluate("() => UI.setRtab('team')"); time.sleep(1.5)
    assert pg.locator('#bkSync').is_checked() and pg.locator('#bkScope').input_value() == 'library' and pg.locator('#bkMbps').input_value() == '50', 'media sync options'
    t = pg.evaluate("() => document.body.innerText"); assert 'Sync media now' in t, t[-800:]; pg.screenshot(path=os.environ.get('PX_SHOT_DIR', tmp) + '/backup.png')
    ok('backup / render node panel: copy media from the primary, scope, bandwidth limit, status and Sync now')
    pg.evaluate("() => UI.setRtab('kiosk')"); time.sleep(0.8); pg.locator('[data-kx=add]').click(); time.sleep(1)
    t = pg.evaluate("() => document.body.innerText").lower(); assert 'day-parts' in t and 'day-part 1' in t and 'otherwise' in t, (errs, pg.evaluate('() => [UI.rtab, document.querySelector("#rpane").innerText.slice(0, 300)]')); ok('kiosk panel: add a day-part')
    cmd({'op': 'set', 'path': 'kiosk.on', 'value': True}); cmd({'op': 'set', 'path': 'kiosk.locked', 'value': True}); time.sleep(2)
    assert pg.locator('#kioskLock').is_visible(), 'lock screen'; pg.screenshot(path=os.environ.get('PX_SHOT_DIR', tmp) + '/kiosk-lock.png')
    pg.locator('#kioskLock button').click(); time.sleep(1); assert pg.locator('#kioskLock').count() == 0, 'unlocked'
    ok('kiosk lock: control screen shows the lock; Unlock opens it (no PIN set)')
    pg.evaluate("() => UI.setRtab('vp')"); time.sleep(0.8); pg.locator('[data-vpx=volume]').click(); time.sleep(1)
    t = pg.evaluate("() => document.querySelector('#rpane').innerText").lower(); assert 'left' in t and 'back' in t and 'right' in t and 'tracking' in t, t[:400]; ok('virtual production panel: 3-wall volume')
    pg.evaluate("() => UI.setRtab('audience')"); time.sleep(1.5); t = pg.evaluate("() => document.querySelector('#rpane').innerText").lower(); assert 'join link' in t and 'poll' in t, t[:300]; ok('audience panel renders')
    assert not errs, errs; b.close()
  print('UI check passed')
finally: srv.terminate()
