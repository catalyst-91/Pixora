# Expressions in real Chrome: an expression drives a layer's opacity on the output, param() reads another parameter,
# a broken expression is ignored (the slider value stays), and the Mods panel shows the error while typing.
import json, urllib.request, subprocess, os, time, sys, tempfile, signal
from playwright.sync_api import sync_playwright
from PIL import Image
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); CHROME = sys.argv[1] if len(sys.argv) > 1 else '/usr/bin/google-chrome'
B = 'http://127.0.0.1:9041'; tmp = tempfile.mkdtemp()
srv = subprocess.Popen(['node', 'server.js'], cwd=ROOT, env=dict(os.environ, PORT='9041', OSC_PORT='9042', DATA_DIR=tmp + '/d', MEDIA_DIR=tmp + '/m'), stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
def cmd(b): return json.loads(urllib.request.urlopen(urllib.request.Request(B + '/api/cmd', data=json.dumps(b).encode(), headers={'Content-Type': 'application/json'})).read() or b'{}')
for _ in range(60):
  try: urllib.request.urlopen(B + '/api/info'); break
  except Exception: time.sleep(0.2)
ok = lambda m: print('✓ ' + m)
try:
  for k, v in [('comp.width', 320), ('comp.height', 180)]: cmd({'op': 'set', 'path': k, 'value': v})
  cmd({'op': 'assign', 'layer': 0, 'slot': 0, 'clip': {'type': 'gen', 'name': 'w', 'gen': {'kind': 'solid', 'params': {'c1': '#ffffff'}}}}); cmd({'op': 'trigger', 'layer': 0, 'clip': 0})
  with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=['--use-gl=swiftshader', '--enable-unsafe-swiftshader']); pg = b.new_page(viewport={'width': 320, 'height': 180}); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(B + '/clean?out=main&fs=0'); time.sleep(2)
    def px(): pg.screenshot(path=tmp + '/e.png'); return Image.open(tmp + '/e.png').convert('RGB').getpixel((160, 90))[0]
    assert px() > 240
    cmd({'op': 'set', 'path': 'exprs', 'value': [{'path': 'layers.0.opacity', 'expr': '0.25'}]}); time.sleep(0.8); v = px(); assert 50 < v < 80, v; ok(f'expression sets the layer opacity to 0.25 (pixel {v})')
    cmd({'op': 'set', 'path': 'exprs', 'value': [{'path': 'layers.0.opacity', 'expr': 'param("comp.master") * 0.5'}]}); time.sleep(0.8); v = px(); assert 115 < v < 140, v; ok(f'param("comp.master") * 0.5 → {v}')
    cmd({'op': 'set', 'path': 'exprs', 'value': [{'path': 'layers.0.opacity', 'expr': 'sin('}]}); time.sleep(0.8); v = px(); assert v > 240, v
    assert pg.evaluate("() => Object.values(engine.exprErrors || {})[0] || ''").startswith('unexpected'); ok('a broken expression is ignored and reported')
    cmd({'op': 'set', 'path': 'exprs', 'value': [{'path': 'layers.0.opacity', 'expr': 'tri(time)'}]}); vals = []
    for _ in range(6): vals.append(px()); time.sleep(0.2)
    assert max(vals) - min(vals) > 40, vals; ok(f'time-based expression animates {vals}')
    ctl = b.new_page(viewport={'width': 1600, 'height': 1000}); ctl.on('pageerror', lambda e: errs.append(str(e))); ctl.goto(B + '/'); time.sleep(2); ctl.evaluate("() => UI.setRtab('mods')"); time.sleep(1)
    inp = ctl.locator('[data-path="exprs.0.expr"]'); inp.fill('1 +'); time.sleep(0.3); assert 'end' in ctl.locator('[data-exprerr="0"]').inner_text(); ok('Mods panel shows the error while typing')
    ctl.locator('[data-addmacro]').click(); time.sleep(0.8); assert 'Macro 1' in ctl.content(); ok('Mods panel: add a macro')
    assert not errs, errs; b.close()
  print('Expression check passed')
finally: srv.send_signal(signal.SIGTERM)
