// Runs desktop/main.js and preload.js against mocked electron + grandi (API shapes per the grandi README):
// server fork, controller/output windows, NDI send frame fields, NDI find (Finder object) + receive, off-screen web paint,
// Spout plugin hook, and the preload's BGRA/RGBA + stride repacking.
const Module = require('module'), path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert');
const DESK = path.join(__dirname, '..', 'desktop');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'pxd-'));
const log = []; const L = (...a) => log.push(a.join(' '));
const EventEmitter = require('events');

/* ---- mock electron */
const ipcHandlers = {}, ipcOn = {};
class WebContents extends EventEmitter { constructor() { super(); this.sent = []; this.fps = 0; this.js = []; } executeJavaScript(j) { this.js.push(j); return Promise.resolve(); } isFocused() { return false; } toggleDevTools() {} reload() {} setWindowOpenHandler(f) { this.openHandler = f; } beginFrameSubscription(_o, cb) { this.frameCb = cb; L('beginFrameSubscription'); } endFrameSubscription() { this.frameCb = null; L('endFrameSubscription'); } setFrameRate(f) { this.fps = f; } send(ch, m) { this.sent.push([ch, m]); } isDestroyed() { return false; } }
const wins = [];
class BrowserWindow extends EventEmitter { constructor(o) { super(); this.opts = o; this.webContents = new WebContents(); this.destroyed = false; this.bounds = { x: o.x || 0, y: o.y || 0, width: o.width || 800, height: o.height || 600 }; wins.push(this); } loadURL(u) { this.url = u; setTimeout(() => this.emit('ready-to-show'), 5); } show() { this.shown = true; } setBounds(b) { this.bounds = b; } getBounds() { return this.bounds; } isMaximized() { return false; } maximize() {} isFullScreen() { return false; } reload() {} setMenuBarVisibility() {} focus() {} isDestroyed() { return this.destroyed; } destroy() { this.destroyed = true; } close() { this.destroyed = true; this.emit('closed'); } }
const image = (w, h, fill) => ({ getSize: () => ({ width: w, height: h }), toBitmap: () => { const b = Buffer.alloc(w * h * 4); for (let i = 0; i < b.length; i += 4) b.set(fill, i); return b; }, getBitmap() { throw new Error('getBitmap is deprecated — must not be used'); } });
let trayMenu = null;
const electron = {
  app: { getVersion: () => '1.2.0', isPackaged: false, addRecentDocument() {}, clearRecentDocuments() {}, getAppPath: () => DESK, commandLine: { appendSwitch: () => {} }, requestSingleInstanceLock: () => true, quit: () => L('quit'), getPath: k => path.join(tmp, k), whenReady: () => Promise.resolve(), on: (ev, f) => { (global.__appOn = global.__appOn || {})[ev] = f; }, setLoginItemSettings: o => L('login', JSON.stringify(o)) },
  BrowserWindow, Tray: class { constructor() {} setToolTip() {} on() {} setContextMenu(m) { trayMenu = m; } },
  Menu: { buildFromTemplate: t => t, setApplicationMenu: m => { global.__appMenu = m; } }, Notification: class { constructor(o) { this.o = o; } show() { (global.__notes = global.__notes || []).push(this.o); } static isSupported() { return true; } }, screen: { getAllDisplays: () => [{ id: 1, label: 'Main', bounds: { x: 0, y: 0, width: 1920, height: 1080 } }, { id: 2, label: 'LED', bounds: { x: 1920, y: 0, width: 1280, height: 720 } }], getPrimaryDisplay: () => ({ id: 1 }), on: () => {} },
  powerSaveBlocker: { start: () => 7, stop: () => {} }, nativeImage: { createFromPath: () => ({ resize: () => ({}) }) },
  dialog: { showMessageBox: o => { L('msgbox', o.message); return Promise.resolve({}); }, showErrorBox: (a, b) => L('errbox', a, b) }, shell: { openPath() {}, openExternal() {} },
  ipcMain: { on: (c, f) => ipcOn[c] = f, handle: (c, f) => ipcHandlers[c] = f },
  contextBridge: { exposeInMainWorld: (k, v) => { global.window = global.window || {}; global.window[k] = v; } },
  ipcRenderer: new (class extends EventEmitter { sendSync(c, m) { return 'sync:' + c; } send() {} invoke(c) { return Promise.resolve(c); } })(),
};
/* ---- mock grandi (shapes from the grandi README) */
const ndiSent = [], finders = [];
const grandi = {
  FOURCC_BGRA: 1095911234, FOURCC_RGBA: 1094862674, FOURCC_RGBX: 1481066322, FORMAT_TYPE_PROGRESSIVE: 1, BANDWIDTH_HIGHEST: 100,
  COLOR_FORMAT_BGRX_BGRA: 0, COLOR_FORMAT_RGBX_RGBA: 2, COLOR_FORMAT_FASTEST: 100,
  send: async o => { L('ndi.send', JSON.stringify(o)); return { video: async f => { await new Promise(r => setTimeout(r, 5)); ndiSent.push(f); }, destroy: () => L('sender.destroy') }; },
  find: async (o, ms) => { const f = { waited: 0, destroyed: false, wait: async t => { f.waited = t; }, sources: () => [{ name: 'CAM-PC (OBS)', urlAddress: '10.0.0.5:5961' }, { name: 'GFX (vMix)', urlAddress: '10.0.0.6:5961' }], destroy: () => { f.destroyed = true; } }; finders.push(f); return f; },
  receive: async o => { L('ndi.receive', o.source.name, 'colorFormat=' + o.colorFormat); let n = 0; const w = 4, h = 2, stride = 24; // padded lines
    return { destroy: () => L('receiver.destroy'), video: async () => { await new Promise(r => setTimeout(r, 5)); if (n++ > 3) throw new Error('timeout'); const d = Buffer.alloc(stride * h, 0); for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) d.set([10, 20, 30, 0], y * stride + x * 4); return { xres: w, yres: h, lineStrideBytes: stride, fourCC: grandi.FOURCC_RGBX, data: d }; } }; },
};
const forks = []; const realCP = require('child_process');
const realLoad = Module._load;
Module._load = function (req, parent, isMain) {
  if (req === 'electron') return electron;
  if (req === 'grandi') return grandi;
  if (req === 'child_process') return { ...realCP, fork: (s, a, o) => { forks.push({ s, env: o.env }); const e = new EventEmitter(); e.kill = () => L('server.kill'); return e; } };
  return realLoad.apply(this, arguments);
};
const http = require('http');
const srv = http.createServer((q, r) => { r.setHeader('content-type', 'application/json'); r.end(q.url.startsWith('/api/state') ? JSON.stringify({ outputs: [{ id: 'main', name: 'Main' }, { id: 'led', name: 'LED wall' }] }) : '{}'); });
const tick = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  await new Promise(r => srv.listen(0, r)); process.env.PORT = srv.address().port;
  // Spout plugin hook via userData/plugins/spout.js
  fs.mkdirSync(path.join(tmp, 'userData', 'plugins'), { recursive: true });
  fs.writeFileSync(path.join(tmp, 'userData', 'plugins', 'spout.js'), "module.exports={create:n=>({frames:0,send(b,w,h){if(b.length!==w*h*4)throw new Error('bad');this.frames++;global.__spout=(global.__spout||0)+1},close(){global.__spoutClosed=1}})}");
  Object.defineProperty(process, 'platform', { value: 'win32' });
  require(path.join(DESK, 'main.js'));
  await tick(400);
  assert.strictEqual(forks.length, 1, 'server forked'); assert.ok(forks[0].env.DATA_DIR && forks[0].env.MEDIA_DIR); console.log('✓ server forked with DATA_DIR/MEDIA_DIR');
  const ctl = wins.find(w => w.url && w.url.endsWith('/')); assert.ok(ctl, 'controller opened'); console.log('✓ controller window', ctl.url);
  assert.ok(trayMenu, 'tray built'); const status = trayMenu.find(i => /^NDI:/.test(i.label)); console.log('✓ tray status:', status.label); assert.match(status.label, /grandi/); assert.match(status.label, /plugin loaded/);
  // window.open of an output from the controller → native output window
  ctl.webContents.openHandler({ url: `http://localhost:${process.env.PORT}/output?out=led` }); await tick(50);
  const out = wins.find(w => /out=led/.test(w.url || '')); assert.ok(out); console.log('✓ output window opened', out.url);
  // turn on NDI + Spout from the tray
  const outMenu = trayMenu.find(i => i.label === 'Outputs').submenu.find(i => /LED wall/.test(i.label));
  outMenu.submenu.find(i => i.label === 'Send as NDI').click({ checked: true }); await tick(30);
  outMenu.submenu.find(i => /Spout/.test(i.label || '')).click({ checked: true }); await tick(30);
  assert.ok(out.webContents.frameCb, 'frame subscription active');
  for (let i = 0; i < 5; i++) out.webContents.frameCb(image(8, 4, [1, 2, 3, 255])); // burst: must not queue more than one NDI frame
  await tick(60); out.webContents.frameCb(image(8, 4, [1, 2, 3, 255])); await tick(30);
  const f = ndiSent[0]; assert.ok(f, 'NDI frame sent');
  assert.deepStrictEqual([f.xres, f.yres, f.lineStrideBytes, f.fourCC, f.frameFormatType, f.data.length], [8, 4, 32, grandi.FOURCC_BGRA, 1, 128]);
  assert.ok(ndiSent.length >= 2 && ndiSent.length < 6, 'back-pressure drops frames while NDI busy (sent ' + ndiSent.length + ' of 6)');
  console.log(`✓ NDI send: ${ndiSent.length}/6 frames (busy frames dropped), fields`, JSON.stringify({ xres: f.xres, yres: f.yres, stride: f.lineStrideBytes, fourCC: f.fourCC, fps: f.frameRateN + '/' + f.frameRateD }));
  assert.ok(global.__spout >= 6); console.log('✓ Spout plugin received', global.__spout, 'frames');
  outMenu.submenu.find(i => i.label === 'Send as NDI').click({ checked: false }); await tick(10);
  assert.ok(out.webContents.frameCb, 'subscription kept while Spout still on'); console.log('✓ turning NDI off keeps Spout running');
  out.close(); await tick(10); assert.ok(global.__spoutClosed); console.log('✓ closing output closes senders');
  // NDI listing uses Finder.sources() and destroys the finder
  const names = await ipcHandlers['native-list-ndi'](); assert.deepStrictEqual(names, ['CAM-PC (OBS)', 'GFX (vMix)']); assert.ok(finders.every(x => x.destroyed && x.waited)); console.log('✓ NDI list via Finder:', names.join(', '));
  // NDI receive → native-frame with stride + fmt
  const owner = new WebContents(); const ev = { sender: owner };
  ipcOn['native-open-ndi'](ev, { name: 'GFX (vMix)' }); const nid = ev.returnValue; await tick(80);
  const frames = owner.sent.filter(s => s[0] === 'native-frame'); assert.ok(frames.length >= 2);
  const nf = frames[0][1]; assert.deepStrictEqual([nf.width, nf.height, nf.stride, nf.fmt], [4, 2, 24, 'rgba']); console.log('✓ NDI receive → frames', frames.length, JSON.stringify({ w: nf.width, h: nf.height, stride: nf.stride, fmt: nf.fmt }));
  ipcOn['native-close']({}, { id: nid }); await tick(20); assert.ok(log.includes('receiver.destroy')); console.log('✓ closing NDI source destroys receiver');
  const ev2 = { sender: owner }; ipcOn['native-open-ndi'](ev2, { name: 'Missing' }); await tick(30);
  assert.ok(owner.sent.some(s => s[0] === 'native-status' && /not found/.test(s[1].error))); console.log('✓ missing NDI source reports status');
  // off-screen web page → paint → native-frame
  const ev3 = { sender: owner }; ipcOn['native-open-web'](ev3, { url: 'https://example.com', w: 640, h: 360 });
  const off = wins[wins.length - 1]; assert.ok(off.opts.webPreferences.offscreen); off.webContents.emit('paint', {}, {}, image(4, 2, [50, 100, 150, 255]));
  const wf = owner.sent.filter(s => s[0] === 'native-frame').pop()[1]; assert.deepStrictEqual([wf.fmt, wf.stride, wf.width], ['bgra', 16, 4]); console.log('✓ off-screen web paint → BGRA frame at', off.webContents.fps, 'fps');

  // ---- preload conversion
  global.ImageData = class { constructor(d, w, h) { this.data = d; this.width = w; this.height = h; } };
  require(path.join(DESK, 'preload.js'));
  const api = global.window.pixoraNative; assert.ok(api.onFrame && api.onStatus && api.listNdi);
  let got; api.onFrame(9, im => got = im);
  electron.ipcRenderer.emit('native-frame', {}, { id: 9, width: nf.width, height: nf.height, stride: nf.stride, fmt: 'rgba', data: frames[0][1].data });
  assert.strictEqual(got.data.length, 4 * 2 * 4); assert.deepStrictEqual([...got.data.slice(0, 4)], [10, 20, 30, 255]); assert.deepStrictEqual([...got.data.slice(16, 20)], [10, 20, 30, 255]);
  console.log('✓ preload: padded RGBX rows repacked, alpha forced to 255');
  electron.ipcRenderer.emit('native-frame', {}, { id: 9, width: 4, height: 2, stride: 16, fmt: 'bgra', data: image(4, 2, [50, 100, 150, 255]).toBitmap() });
  assert.deepStrictEqual([...got.data.slice(0, 4)], [150, 100, 50, 255]); console.log('✓ preload: BGRA swizzled to RGBA');
  let st; api.onStatus(9, s => st = s); electron.ipcRenderer.emit('native-status', {}, { id: 9, error: 'x' }); assert.ok(st); console.log('✓ preload: status events');
  console.log('\nDESKTOP HARNESS PASS'); srv.close(); process.exit(0);
})().catch(e => { console.error('FAIL', e); console.error(log.join('\n')); process.exit(1); });
