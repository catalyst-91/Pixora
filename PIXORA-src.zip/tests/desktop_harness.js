// Runs desktop/main.js and preload.js against mocked electron and the REAL PIXORA NDI module + NDI runtime:
// server fork, controller/output windows, NDI® send → discovery → receive round trip, NDI audio, NDI-only off-screen
// outputs, renaming, off-screen web paint, Spout plugin hook, and the preload's BGRA/RGBA + stride repacking.
// Needs the Linux NDI runtime: NDI_LIB=/path/to/libndi.so.6 node tests/desktop_harness.js
const Module = require('module'), path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert');
const DESK = path.join(__dirname, '..', 'desktop');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'pxd-'));
const log = []; const L = (...a) => log.push(a.join(' '));
const EventEmitter = require('events');

/* ---- mock electron */
const ipcHandlers = {}, ipcOn = {};
class WebContents extends EventEmitter { constructor() { super(); this.sent = []; this.fps = 0; this.js = []; } executeJavaScript(j) { this.js.push(j); return Promise.resolve(); } isFocused() { return false; } toggleDevTools() {} reload() {} setWindowOpenHandler(f) { this.openHandler = f; } beginFrameSubscription(_o, cb) { this.frameCb = cb; L('beginFrameSubscription'); } endFrameSubscription() { this.frameCb = null; L('endFrameSubscription'); } setFrameRate(f) { this.fps = f; } setAudioMuted(m) { this.muted = m; } send(ch, m) { this.sent.push([ch, m]); } isDestroyed() { return false; } }
const wins = [];
class BrowserWindow extends EventEmitter { constructor(o) { super(); this.opts = o; this.webContents = new WebContents(); this.destroyed = false; this.bounds = { x: o.x || 0, y: o.y || 0, width: o.width || 800, height: o.height || 600 }; wins.push(this); } loadURL(u) { this.url = u; setTimeout(() => this.emit('ready-to-show'), 5); } show() { this.shown = true; } setBounds(b) { this.bounds = b; } getBounds() { return this.bounds; } isMaximized() { return false; } maximize() {} isFullScreen() { return false; } reload() {} setMenuBarVisibility() {} focus() {} isDestroyed() { return this.destroyed; } destroy() { this.destroyed = true; } close() { this.destroyed = true; this.emit('closed'); } }
const image = (w, h, fill) => ({ getSize: () => ({ width: w, height: h }), toBitmap: () => { const b = Buffer.alloc(w * h * 4); for (let i = 0; i < b.length; i += 4) b.set(fill, i); return b; }, getBitmap() { throw new Error('getBitmap is deprecated — must not be used'); } });
let trayMenu = null;
const electron = {
  app: { getVersion: () => '1.2.0', isPackaged: false, addRecentDocument() {}, clearRecentDocuments() {}, getAppPath: () => DESK, commandLine: { appendSwitch: () => {} }, requestSingleInstanceLock: () => true, quit: () => L('quit'), getPath: k => path.join(tmp, k), whenReady: () => Promise.resolve(), on: (ev, f) => { (global.__appOn = global.__appOn || {})[ev] = f; }, setLoginItemSettings: o => L('login', JSON.stringify(o)) },
  BrowserWindow, Tray: class { constructor() {} setToolTip() {} on() {} setContextMenu(m) { trayMenu = m; } },
  Menu: { buildFromTemplate: t => t, setApplicationMenu: m => { global.__appMenu = m; } }, Notification: class { constructor(o) { this.o = o; } show() { (global.__notes = global.__notes || []).push(this.o); } static isSupported() { return true; } }, screen: { getAllDisplays: () => [{ id: 1, label: 'Main', bounds: { x: 0, y: 0, width: 1920, height: 1080 } }, { id: 2, label: 'LED', bounds: { x: 1920, y: 0, width: 1280, height: 720 } }], getPrimaryDisplay: () => ({ id: 1 }), on: () => {} },
  powerSaveBlocker: { start: () => 7, stop: () => {} }, nativeImage: { createFromPath: () => ({ resize: () => ({}) }) },
  dialog: { showMessageBox: o => { L('msgbox', o.message); return Promise.resolve({}); }, showErrorBox: (a, b) => L('errbox', a, b) }, shell: { openPath() {}, openExternal() {} },
  ipcMain: { on: (c, f) => ipcOn[c] = f, handle: (c, f) => ipcHandlers[c] = f },
  contextBridge: { exposeInMainWorld: (k, v) => { global.window = global.window || {}; global.window[k] = v; } },
  ipcRenderer: new (class extends EventEmitter { sendSync(c, m) { return 'sync:' + c; } send() {} invoke(c) { return Promise.resolve(c); } })(),
};
const forks = []; const realCP = require('child_process');
const realLoad = Module._load;
Module._load = function (req, parent, isMain) {
  if (req === 'electron') return electron;
  if (req === 'child_process') return { ...realCP, fork: (s, a, o) => { forks.push({ s, env: o.env }); const e = new EventEmitter(); e.kill = () => L('server.kill'); return e; } };
  return realLoad.apply(this, arguments);
};
const http = require('http');
const srv = http.createServer((q, r) => { r.setHeader('content-type', 'application/json'); r.end(q.url.startsWith('/api/state') ? JSON.stringify({ outputs: [{ id: 'main', name: 'Main' }, { id: 'led', name: 'LED wall' }] }) : '{}'); });
const tick = ms => new Promise(r => setTimeout(r, ms));
process.env.PIXORA_NDI_RUNTIME = process.env.NDI_LIB || '/tmp/ndisdk/NDI SDK for Linux/lib/x86_64-linux-gnu/libndi.so.6';
process.env.PIXORA_NDI_ADDON = process.env.PIXORA_NDI_ADDON || [path.join(DESK, 'native', 'ndi', 'build', 'Release', 'pixora_ndi.node'), path.join(DESK, 'native', 'ndi', `pixora_ndi-linux-${process.arch}.node`)].find(f => fs.existsSync(f));
(async () => {
  await new Promise(r => srv.listen(0, r)); process.env.PORT = srv.address().port;
  // Spout plugin hook via userData/plugins/spout.js
  fs.mkdirSync(path.join(tmp, 'userData', 'plugins'), { recursive: true });
  fs.writeFileSync(path.join(tmp, 'userData', 'plugins', 'spout.js'), "module.exports={create:n=>({frames:0,send(b,w,h){if(b.length!==w*h*4)throw new Error('bad');this.frames++;global.__spout=(global.__spout||0)+1},close(){global.__spoutClosed=1}})}");
  Object.defineProperty(process, 'platform', { value: 'win32' });
  require(path.join(DESK, 'main.js'));
  await tick(400);
  assert.strictEqual(forks.length, 1, 'server forked'); assert.ok(forks[0].env.DATA_DIR && forks[0].env.MEDIA_DIR); console.log('✓ server forked with DATA_DIR/MEDIA_DIR');
  const ctl = wins.find(w => w.url && w.url.endsWith('/')); assert.ok(ctl, 'controller opened'); console.log('✓ controller window', ctl.url);
  assert.ok(trayMenu, 'tray built'); const status = trayMenu.find(i => /^NDI®/.test(i.label || '')); console.log('✓ tray status:', status.label); assert.match(status.label, /NDI®: ready \(v6\./); assert.match(status.label, /plugin loaded/);
  assert.ok(trayMenu.some(i => /ndi\.video/.test(i.label || '')), 'tray links to ndi.video');
  // window.open of an output from the controller → native output window
  ctl.webContents.openHandler({ url: `http://localhost:${process.env.PORT}/output?out=led` }); await tick(50);
  const out = wins.find(w => /out=led/.test(w.url || '')); assert.ok(out); console.log('✓ output window opened', out.url);
  // discovery on this machine without mDNS: extra IP
  let st = await ipcHandlers['native-ndi-set']({}, { extraIps: '127.0.0.1', fps: 30 }); assert.strictEqual(st.extraIps, '127.0.0.1'); assert.ok(st.available && /6\.\d+/.test(st.version));
  // turn on NDI + Spout from the tray
  const outMenu = trayMenu.find(i => i.label === 'Outputs').submenu.find(i => /LED wall/.test(i.label));
  outMenu.submenu.find(i => i.label === 'Send as NDI®').click({ checked: true }); await tick(30);
  outMenu.submenu.find(i => /Spout/.test(i.label || '')).click({ checked: true }); await tick(30);
  assert.ok(out.webContents.frameCb, 'frame subscription active');
  assert.ok(out.webContents.sent.some(s => s[0] === 'native-ndi-audio' && s[1].on), 'output asked to stream clip audio');
  const red = image(64, 36, [0, 0, 255, 255]); // BGRA red
  const pump = setInterval(() => out.webContents.frameCb && out.webContents.frameCb(red), 33);
  // NDI audio: PCM from the output window
  const pcm = new Float32Array(1024 * 2).map((_, i) => Math.sin(i / 10) * 0.3); const apump = setInterval(() => ipcOn['native-ndi-pcm']({ sender: out.webContents }, { data: pcm, sampleRate: 48000, channels: 2 }), 21);
  await tick(300);
  // the NDI source is discoverable and listed for the Library
  let names = []; for (let i = 0; i < 8 && !names.some(n => /PIXORA led/.test(n)); i++) names = await ipcHandlers['native-list-ndi']();
  const mine = names.find(n => /PIXORA led/.test(n)); assert.ok(mine, 'own NDI output discoverable: ' + names.join(', ')); console.log('✓ NDI® source discoverable:', mine);
  // receive it back as a clip source → native-frame RGBA
  const owner = new WebContents(); const ev = { sender: owner };
  ipcOn['native-open-ndi'](ev, { name: mine }); const nid = ev.returnValue;
  for (let i = 0; i < 60 && !owner.sent.some(s => s[0] === 'native-frame'); i++) await tick(100);
  const nfm = owner.sent.find(s => s[0] === 'native-frame'); assert.ok(nfm, 'NDI frames received'); const nf = nfm[1];
  const px = [...nf.data.subarray(18 * nf.stride + 32 * 4, 18 * nf.stride + 32 * 4 + 4)];
  assert.deepStrictEqual([nf.width, nf.height, nf.fmt], [64, 36, 'rgba']); assert.ok(px[0] > 230 && px[1] < 30 && px[2] < 30, 'red came back red: ' + px);
  console.log('✓ NDI® round trip: output window → NDI send → discovery → receive →', nf.width + '×' + nf.height, nf.fmt, 'pixel', px.join(','));
  st = await ipcHandlers['native-ndi-state'](); const so = st.outputs.led;
  assert.ok(so.sending && so.receivers >= 1 && so.frames > 3 && so.audio, JSON.stringify(so)); console.log(`✓ live status: ${so.receivers} receiver, ${so.frames} frames sent, ${so.dropped} dropped, ${so.size}, audio ${so.audio}`);
  assert.ok(global.__spout >= 3); console.log('✓ Spout plugin received', global.__spout, 'frames alongside NDI');
  ipcOn['native-close']({}, { id: nid }); await tick(300);
  // rename the sender
  st = await ipcHandlers['native-ndi-set']({}, { outId: 'led', name: 'Main Stage LED' }); assert.strictEqual(st.outputs.led.name, 'Main Stage LED'); await tick(400);
  names = []; for (let i = 0; i < 8 && !names.some(n => /Main Stage LED/.test(n)); i++) names = await ipcHandlers['native-list-ndi']();
  assert.ok(names.some(n => /Main Stage LED/.test(n)), names.join(', ')); console.log('✓ renamed NDI® source:', names.find(n => /Main Stage LED/.test(n)));
  outMenu.submenu.find(i => i.label === 'Send as NDI®').click({ checked: false }); await tick(10);
  assert.ok(out.webContents.frameCb, 'subscription kept while Spout still on'); assert.ok(out.webContents.sent.some(s => s[0] === 'native-ndi-audio' && !s[1].on)); console.log('✓ turning NDI off stops its audio and keeps Spout running');
  clearInterval(pump); clearInterval(apump);
  out.close(); await tick(10); assert.ok(global.__spoutClosed); console.log('✓ closing output closes senders');
  // NDI-only output: off-screen, muted locally, painted frames go to NDI
  st = await ipcHandlers['native-ndi-set']({}, { outId: 'main', ndi: true, ndiOnly: true }); await tick(100);
  const off1 = wins.find(w => /out=main/.test(w.url || '') && /ndi=1/.test(w.url || '')); assert.ok(off1 && off1.opts.webPreferences.offscreen && off1.opts.show === false && off1.webContents.muted, 'off-screen NDI window');
  for (let i = 0; i < 10; i++) { off1.webContents.emit('paint', {}, {}, image(32, 18, [0, 255, 0, 255])); await tick(40); }
  st = await ipcHandlers['native-ndi-state'](); assert.ok(st.outputs.main.sending && st.outputs.main.offscreen && st.outputs.main.frames > 0, JSON.stringify(st.outputs.main));
  console.log(`✓ NDI-only output: off-screen ${off1.opts.width}×${off1.opts.height}, muted locally, ${st.outputs.main.frames} frames sent at ${off1.webContents.fps} fps`);
  st = await ipcHandlers['native-ndi-set']({}, { outId: 'main', ndi: false }); await tick(50); assert.ok(off1.destroyed && !st.outputs.main.sending); console.log('✓ turning NDI off closes the off-screen output');
  // a missing source reports a status instead of hanging
  const ev2 = { sender: owner }; ipcOn['native-open-ndi'](ev2, { name: 'Missing' }); for (let i = 0; i < 40 && !owner.sent.some(s => s[0] === 'native-status'); i++) await tick(100);
  assert.ok(owner.sent.some(s => s[0] === 'native-status' && /not found/.test(s[1].error))); console.log('✓ missing NDI source reports status');
  // off-screen web page → paint → native-frame
  const ev3 = { sender: owner }; ipcOn['native-open-web'](ev3, { url: 'https://example.com', w: 640, h: 360 });
  const off = wins[wins.length - 1]; assert.ok(off.opts.webPreferences.offscreen); off.webContents.emit('paint', {}, {}, image(4, 2, [50, 100, 150, 255]));
  const wf = owner.sent.filter(s => s[0] === 'native-frame').pop()[1]; assert.deepStrictEqual([wf.fmt, wf.stride, wf.width], ['bgra', 16, 4]); console.log('✓ off-screen web paint → BGRA frame at', off.webContents.fps, 'fps');

  // ---- preload conversion
  global.ImageData = class { constructor(d, w, h) { this.data = d; this.width = w; this.height = h; } };
  require(path.join(DESK, 'preload.js'));
  const api = global.window.pixoraNative; assert.ok(api.onFrame && api.onStatus && api.listNdi && api.ndiState && api.ndiSet && api.ndiPcm && api.onNdiAudio);
  let got; api.onFrame(9, im => got = im);
  const padded = Buffer.alloc(24 * 2); for (let y = 0; y < 2; y++) for (let x = 0; x < 4; x++) padded.set([10, 20, 30, 0], y * 24 + x * 4);
  electron.ipcRenderer.emit('native-frame', {}, { id: 9, width: 4, height: 2, stride: 24, fmt: 'rgba', data: padded });
  assert.strictEqual(got.data.length, 4 * 2 * 4); assert.deepStrictEqual([...got.data.slice(0, 4)], [10, 20, 30, 255]); assert.deepStrictEqual([...got.data.slice(16, 20)], [10, 20, 30, 255]);
  console.log('✓ preload: padded RGBX rows repacked, alpha forced to 255');
  electron.ipcRenderer.emit('native-frame', {}, { id: 9, width: 4, height: 2, stride: 16, fmt: 'bgra', data: image(4, 2, [50, 100, 150, 255]).toBitmap() });
  assert.deepStrictEqual([...got.data.slice(0, 4)], [150, 100, 50, 255]); console.log('✓ preload: BGRA swizzled to RGBA');
  let pst; api.onStatus(9, s => pst = s); electron.ipcRenderer.emit('native-status', {}, { id: 9, error: 'x' }); assert.ok(pst); console.log('✓ preload: status events');
  console.log('\nDESKTOP HARNESS PASS'); srv.close(); process.exit(0);
})().catch(e => { console.error('FAIL', e); console.error(log.join('\n')); process.exit(1); });
