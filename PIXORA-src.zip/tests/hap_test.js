// Decodes HAP test files with public/hap.js and compares frame 0 against ffmpeg's own HAP decoder.
// Needs a PIXORA server on PX_PORT (default 8811) serving media/_t/*.mov, plus ffmpeg.
require('../public/hap.js'); const H = globalThis.HapPlayer; const { execFileSync } = require('child_process'); const path = require('path'); const fs = require('fs');
const PORT = process.env.PX_PORT || 8811; const DIR = path.join(__dirname, '..', 'media', '_t');
(async () => {
  for (const f of ['hap1.mov', 'hap5.mov', 'hapq.mov', 'hapraw.mov', 'hapchunk.mov']) {
    if (!fs.existsSync(path.join(DIR, f))) continue;
    const url = `http://127.0.0.1:${PORT}/media/local/_t/${f}`; const info = await H.demux(url);
    const r = await fetch(url, { headers: { Range: `bytes=${info.offs[0]}-${info.offs[0] + info.sizes[0] - 1}` } }); const b = new Uint8Array(await r.arrayBuffer());
    const fr = H.decodeFrame(b); const out = new Uint8Array(info.w * info.h * 4);
    H.decodeDXT(fr.data, info.w, info.h, fr.fmt === 0xF ? 0xE : fr.fmt, out); if (fr.fmt === 0xF) H.ycocg(out);
    const ref = execFileSync('ffmpeg', ['-v', 'error', '-i', path.join(DIR, f), '-frames:v', '1', '-f', 'rawvideo', '-pix_fmt', 'rgba', '-'], { maxBuffer: 64 << 20 });
    let diff = 0; for (let i = 0; i < out.length; i += 4) for (let k = 0; k < 3; k++) diff += Math.abs(out[i + k] - ref[i + k]);
    const mae = diff / (info.w * info.h * 3);
    // flip round-trip: flipping twice must give the original blocks
    const f2 = H.flipDXT(H.flipDXT(fr.data, info.w, info.h, fr.fmt === 0xF ? 0xE : fr.fmt), info.w, info.h, fr.fmt === 0xF ? 0xE : fr.fmt); const same = Buffer.compare(Buffer.from(f2), Buffer.from(fr.data)) === 0;
    // single flip vs CPU-decoded image flipped vertically
    const fl = H.flipDXT(fr.data, info.w, info.h, fr.fmt === 0xF ? 0xE : fr.fmt); const o2 = new Uint8Array(out.length); H.decodeDXT(fl, info.w, info.h, fr.fmt === 0xF ? 0xE : fr.fmt, o2); if (fr.fmt === 0xF) H.ycocg(o2);
    let fd = 0; for (let y = 0; y < info.h; y++) for (let x = 0; x < info.w * 4; x++) fd += Math.abs(o2[y * info.w * 4 + x] - out[(info.h - 1 - y) * info.w * 4 + x]);
    console.log(`${f.padEnd(12)} ${info.fourcc} ${info.w}×${info.h} ${info.count} frames @ ${info.fps.toFixed(2)} fps · section 0x${b[3].toString(16)} fmt 0x${fr.fmt.toString(16)} · mean error vs ffmpeg ${mae.toFixed(2)}/255 · flip ok ${same && fd === 0}`);
    if (mae > 3 || !same || fd !== 0) { console.error('FAIL'); process.exit(1); }
  }
  console.log('HAP DECODER TESTS PASS');
})().catch(e => { console.error('FAIL', e); process.exit(1); });
