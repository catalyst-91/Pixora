# Stream input in real Chrome: an SRT sender calls PIXORA, the output window plays it through Media Source at the live edge
# (picture and sound), and keeps playing after the sender drops and returns. Needs Playwright, Chrome and ffmpeg with SRT.
#   python3 tests/stream_check.py [path-to-chrome]
import json, urllib.request, subprocess, os, time, sys, tempfile, signal
from playwright.sync_api import sync_playwright
from PIL import Image
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); CHROME = sys.argv[1] if len(sys.argv) > 1 else '/usr/bin/google-chrome'
B = 'http://127.0.0.1:8929'; tmp = tempfile.mkdtemp()
srv = subprocess.Popen(['node', 'server.js'], cwd=ROOT, env=dict(os.environ, PORT='8929', OSC_PORT='8930', DATA_DIR=tmp + '/d', MEDIA_DIR=tmp + '/m'), stdout=open(tmp + '/log', 'w'), stderr=subprocess.STDOUT)
def cmd(b): return json.loads(urllib.request.urlopen(urllib.request.Request(B + '/api/cmd', data=json.dumps(b).encode(), headers={'Content-Type': 'application/json'})).read() or b'{}')
for _ in range(60):
  try: urllib.request.urlopen(B + '/api/info'); break
  except Exception: time.sleep(0.2)
ok = lambda m: print('✓ ' + m)
def sender(color):
  return subprocess.Popen(['ffmpeg', '-v', 'error', '-re', '-f', 'lavfi', '-i', f'color=c={color}:s=640x360:r=30', '-f', 'lavfi', '-i', 'sine=f=440', '-c:v', 'libx264', '-preset', 'ultrafast', '-tune', 'zerolatency', '-pix_fmt', 'yuv420p', '-g', '15', '-c:a', 'aac', '-f', 'mpegts', 'srt://127.0.0.1:9201?mode=caller&latency=80000'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
tx = None
try:
  url = 'srt://0.0.0.0:9201?mode=listener&latency=80000'
  cmd({'op': 'assign', 'layer': 0, 'slot': 0, 'clip': {'type': 'stream', 'name': 'SRT in', 'url': url, 'mode': 'auto', 'latency': 0.6, 'fit': 'stretch'}}); cmd({'op': 'trigger', 'layer': 0, 'clip': 0})
  with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=['--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--autoplay-policy=no-user-gesture-required'])
    pg = b.new_page(viewport={'width': 320, 'height': 180}); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(B + '/clean?out=main&fs=0'); time.sleep(1); pg.mouse.click(160, 90); time.sleep(1.5)
    tx = sender('red')
    def px():
      pg.screenshot(path=tmp + '/s.png'); return Image.open(tmp + '/s.png').convert('RGB').getpixel((160, 90))
    for _ in range(40):
      c = px()
      if c[0] > 200 and c[1] < 60: break
      time.sleep(0.5)
    assert c[0] > 200 and c[1] < 60, (c, pg.evaluate("() => { const s = engine.layers[0].cur; return s && [s.errMsg, s.streamInfo && s.streamInfo.mime, s.el.readyState, s.streamBytes, s.el.error && s.el.error.message, s.el.buffered.length, s.el.src] }"))
    lag = pg.evaluate("() => { const v = engine.layers[0].cur.el; const b = v.buffered; return b.length ? b.end(b.length - 1) - v.currentTime : 99 }")
    ok(f'SRT sender → picture on the output (pixel {c}), playing {lag:.2f} s behind the newest frame received')
    assert lag < 1.5, lag
    time.sleep(1); lv = pg.evaluate("() => peakDb(abus.bus.get('main').an)"); assert lv > -25, lv; ok(f'stream audio on the Main output ({lv} dB)')
    tx.send_signal(signal.SIGKILL); tx.wait(); time.sleep(6); tx = sender('lime')  # SRT notices a silent peer after its 5 s idle timeout; encoders like OBS keep retrying, ffmpeg tries once
    for _ in range(50):
      c = px()
      if c[1] > 200 and c[0] < 60: break
      time.sleep(0.5)
    assert c[1] > 200 and c[0] < 60, (c, pg.evaluate("() => { const s = engine.layers[0].cur; return s && [s.errMsg, s.streamInfo, s.el.readyState, s.streamBytes, s.el.error && s.el.error.message, s.el.buffered.length && [s.el.buffered.start(0), s.el.buffered.end(0)], s.el.currentTime, s.el.paused] }")); ok('sender drops and calls back with a new picture: the output follows on its own')
    assert not errs, errs; b.close()
  print('Stream check passed')
finally:
  if tx: tx.kill()
  srv.send_signal(signal.SIGTERM)
