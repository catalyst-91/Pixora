// Render nodes: an extra PIXORA follows the primary's show, forwards operator commands, reports its outputs (fps, drift)
// to the primary, and never takes control when the primary goes away.
//   node tests/rendernode_test.js
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill('SIGKILL'); } catch {} }));
const P = 'http://127.0.0.1:8901', N = 'http://127.0.0.1:8903', MEDIA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxrnM-'));
const start = (port, osc) => { const k = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: port, OSC_PORT: osc, DATA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxrn-')), MEDIA_DIR: MEDIA }, stdio: 'ignore' }); kids.push(k); return k; };
const up = async B => { for (let i = 0; i < 80 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150); };
const json = (u, b) => fetch(u, b ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) } : undefined).then(r => r.json());
const until = async (f, ms = 8000, what = '') => { const t0 = Date.now(); while (Date.now() - t0 < ms) { if (await f()) return; await tick(150); } throw new Error('timed out: ' + what); };
(async () => {
  const prim = start(8901, 8902); start(8903, 8904); await up(P); await up(N);
  await json(N + '/api/settings', { backup: { mode: 'node', primary: P, nodeName: 'Render 2', selfUrl: N } });
  await until(async () => (await json(N + '/api/backup')).connected, 8000, 'node connect');
  let ps = await json(P + '/api/backup'); assert.strictEqual(ps.nodes.length, 1); assert.strictEqual(ps.nodes[0].name, 'Render 2'); assert.strictEqual(ps.mirrors.length, 0, 'a node is not a backup');
  ok('node connects and is listed as a render node (not a backup — controllers will not fail over to it)');
  await json(P + '/api/cmd', { op: 'set', path: 'comp.master', value: 0.4 }); await until(async () => (await json(N + '/api/state')).comp.master === 0.4, 4000, 'mirror'); ok('node follows the show');
  // an operator on the node: command goes to the primary
  const ws = new WebSocket(N.replace('http', 'ws') + '/ws?role=control'); await new Promise(r => ws.onopen = r);
  ws.send(JSON.stringify({ t: 'cmd', cmd: { op: 'set', path: 'comp.speed', value: 1.5 } })); await until(async () => (await json(P + '/api/state')).comp.speed === 1.5, 4000, 'forward'); ws.close(); ok('commands from a node operator are applied on the primary');
  // an output window on the node reports stats → primary sees them
  const out = new WebSocket(N.replace('http', 'ws') + '/ws?role=output'); await new Promise(r => out.onopen = r);
  out.send(JSON.stringify({ t: 'hello', output: 'main' })); out.send(JSON.stringify({ t: 'ostat', name: 'Wall right', fps: 59.9, target: 60, drops: 0, dropRate: 0, worst: 18, drift: [12, -7] }));
  await until(async () => { const l = (await json(P + '/api/ostats')).list; return l.some(o => o.remote && o.name === 'Render 2 · Wall right'); }, 5000, 'node stats');
  const o = (await json(P + '/api/ostats')).list.find(o => o.remote); assert.deepStrictEqual(o.drift, [12, -7]); assert.strictEqual(o.fps, 59.9);
  ps = await json(P + '/api/backup'); assert.strictEqual(((ps.nodes[0] || {}).outputs || [])[0]?.name, 'Wall right', JSON.stringify(ps)); ok("node outputs (fps, drift per layer) appear on the primary's Sync panel and Team list");
  out.close();
  let e = await json(N + '/api/backup', { action: 'takeover' }); assert.ok(/never takes control/.test(e.error)); ok('a node refuses manual takeover');
  prim.kill('SIGKILL'); await tick(4500); const ns = await json(N + '/api/backup'); assert.strictEqual(ns.active, false); assert.strictEqual(ns.connected, false); ok('primary lost → the node keeps rendering but does not take control');
  process.exit(0);
})().catch(e => { console.error('✗', e.message); process.exit(1); });
