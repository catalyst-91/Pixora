// PIXORA ATEM test: a simulated ATEM Mini Extreme speaks the UDP protocol (hello / session / ack / retransmit, as in
// atem-connection) and keeps switcher state; PIXORA drives it through the Devices API and cue actions.   node tests/atem_test.js
const { spawn } = require('child_process'); const dgram = require('dgram'), path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const until = async (fn, ms = 6000) => { const t = Date.now(); while (Date.now() - t < ms) { const v = await fn(); if (v) return v; await tick(50); } throw new Error('timed out waiting'); };
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));

/* ---- simulated ATEM */
const sim = { prog: 1, prev: 2, dsk: [false, false], got: [], cams: [], aux: [0], dropFirst: true, session: 0x8123, id: 0 };
const blk = (name, data) => { const b = Buffer.alloc(8 + data.length); b.writeUInt16BE(b.length, 0); b.write(name, 4, 'latin1'); data.copy(b, 8); return b; };
const u16 = (...v) => { const b = Buffer.alloc(v.length * 2); v.forEach((x, i) => b.writeUInt16BE(x, i * 2)); return b; };
const inpr = (id, name, short) => { const b = Buffer.alloc(36); b.writeUInt16BE(id, 0); b.write(name, 2, 20); b.write(short, 22, 4); return blk('InPr', b); };
const state = () => [blk('_ver', u16(2, 30)), blk('_pin', Buffer.concat([Buffer.from('ATEM Mini Extreme ISO'), Buffer.alloc(23)])), blk('_top', Buffer.from([1, 24, 2, 3, 0, 2, 1, 0, 4, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0])),
  inpr(0, 'Black', 'BLK'), inpr(1, 'Camera 1', 'CAM1'), inpr(2, 'Camera 2', 'CAM2'), inpr(3, 'PIXORA', 'PIX'), inpr(4, 'Slides', 'SLD'), inpr(3010, 'Media Player 1', 'MP1'),
  blk('PrgI', Buffer.from([0, 0, 0, sim.prog])), blk('PrvI', Buffer.from([0, 0, 0, sim.prev])), blk('DskS', Buffer.from([0, 0, 0, 0, 0, 0, 0, 0])),
  blk('MPrp', Buffer.concat([u16(0), Buffer.from([1, 0]), u16(9, 0), Buffer.from('Walk In  '), Buffer.alloc(3)])), blk('MPrp', Buffer.concat([u16(1), Buffer.from([0, 0]), u16(0, 0)])), blk('InCm', Buffer.alloc(4))];
const sock = dgram.createSocket('udp4'); let client = null;
function out(blocks) { const payload = Buffer.concat(blocks); const b = Buffer.alloc(12 + payload.length); sim.id = (sim.id + 1) % 32768; b.writeUInt16BE((0x01 << 11) | b.length, 0); b.writeUInt16BE(sim.session, 2); b.writeUInt16BE(sim.id, 10); payload.copy(b, 12); sock.send(b, client.port, client.address); }
sock.on('message', (m, r) => {
  client = r; const flags = m[0] >> 3;
  if (flags & 0x02) { sim.session = 0x8123; const h = Buffer.alloc(20); h.writeUInt16BE((0x02 << 11) | 20, 0); h.writeUInt16BE(0x53ab, 2); h[12] = 0x02; sock.send(h, r.port, r.address); setTimeout(() => out(state()), 50); return; }
  if (flags & 0x01) {
    const id = m.readUInt16BE(10);
    if (sim.dropFirst && m.length > 12) { sim.dropFirst = false; return; } // lose the first command: PIXORA must retransmit
    const a = Buffer.alloc(12); a.writeUInt16BE((0x10 << 11) | 12, 0); a.writeUInt16BE(sim.session, 2); a.writeUInt16BE(id, 4); sock.send(a, r.port, r.address);
    let o = 12; const ups = [];
    while (o + 8 <= m.length) { const len = m.readUInt16BE(o), name = m.toString('latin1', o + 4, o + 8), d = m.subarray(o + 8, o + len); o += len; sim.got.push([name, d.toString('hex')]);
      if (name === 'CPgI') { sim.prog = d.readUInt16BE(2); ups.push(blk('PrgI', Buffer.from([0, 0, 0, sim.prog]))); }
      if (name === 'CPvI') { sim.prev = d.readUInt16BE(2); ups.push(blk('PrvI', Buffer.from([0, 0, 0, sim.prev]))); }
      if (name === 'DCut' || name === 'DAut') { [sim.prog, sim.prev] = [sim.prev, sim.prog]; ups.push(blk('PrgI', Buffer.from([0, 0, 0, sim.prog])), blk('PrvI', Buffer.from([0, 0, 0, sim.prev]))); }
      if (name === 'CDsL') { sim.dsk[d[0]] = !!d[1]; ups.push(blk('DskS', Buffer.from([d[0], d[1], 0, 0, 0, 0, 0, 0]))); }
      if (name === 'CAuS') { sim.aux[d[1]] = d.readUInt16BE(2); ups.push(blk('AuxS', Buffer.from([d[1], 0, 0, d[3]]))); }
      if (name === 'CCmd') sim.cams.push(d.toString('hex'));
    }
    if (ups.length) setTimeout(() => out(ups), 10);
  }
});

(async () => {
  await new Promise(r => sock.bind(19910, '127.0.0.1', r));
  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxatem-')), MEDIA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxatemm-'));
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8885, OSC_PORT: 8886, DATA_DIR: DATA, MEDIA_DIR: MEDIA }, stdio: ['ignore', 'pipe', 'pipe'] }); kids.push(srv);
  const B = 'http://127.0.0.1:8885';
  for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const api = async (p, method = 'GET', body) => { const r = await fetch(B + p, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined }); const j = await r.json(); if (!r.ok) throw new Error(j.error); return j; };
  const dev = async () => (await api('/api/devices')).devices.find(d => d.name === 'Switcher');

  await api('/api/devices', 'POST', { type: 'atem', name: 'Switcher', host: '127.0.0.1', port: 19910 });
  let d = await until(async () => { const x = await dev(); return x.state.online && x.state.inputs.length ? x : null; });
  assert.strictEqual(d.state.info.model, 'ATEM Mini Extreme ISO'); assert.deepStrictEqual(d.state.inputs.map(i => i.short), ['BLK', 'CAM1', 'CAM2', 'PIX', 'SLD', 'MP1']); assert.strictEqual(d.state.program, 1); assert.strictEqual(d.state.macros[0].name, 'Walk In');
  ok(`connected (no SDK): ${d.state.info.model}, ${d.state.inputs.length} inputs, program CAM1 / preview CAM2, macro "Walk In"`);

  await api('/api/devices/Switcher/preview', 'POST', { input: 'PIX' }); // by short name; first packet is dropped → retransmit
  await until(async () => (await dev()).state.preview === 3); ok('preview → PIXORA by name; the dropped first packet was retransmitted');
  await api('/api/devices/Switcher/auto', 'POST'); await until(async () => (await dev()).state.program === 3); ok('AUTO: PIXORA on program, Camera 1 on preview');
  await api('/api/devices/Switcher/dsk', 'POST', { key: 1, on: true }); await until(async () => (await dev()).state.dsk[0].onAir); ok('downstream key 1 on air');
  await api('/api/devices/Switcher/aux', 'POST', { aux: 1, input: 2 }); await until(async () => (await dev()).state.aux[0] === 2); ok('aux 1 ← Camera 2');
  await api('/api/devices/Switcher/camera', 'POST', { camera: 2, param: 'iris', value: 0.5 });
  await api('/api/devices/Switcher/camera', 'POST', { camera: 2, param: 'whiteBalance', value: 5600 });
  await until(() => sim.cams.length >= 2);
  assert.strictEqual(sim.cams[0], '020003008000000000010000000000000400000000000000'); assert.strictEqual(sim.cams[1].slice(0, 32), '0201020002000000000200000000000015e0000000000000'.slice(0, 32));
  assert.strictEqual(sim.cams[1].slice(32, 40), '15e00000'); ok('camera control to CAM2: iris 0.5 (fixed16 0x0400), white balance 5600 K — Blackmagic camera protocol over the ATEM');

  // from a cue action
  await fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ op: 'runAction', action: { type: 'device', device: 'Switcher', action: 'program', args: '{"input":4}' } }) });
  await until(async () => (await dev()).state.program === 4); ok('cue action "Device action" puts Slides on program');
  assert.ok(sim.got.some(g => g[0] === 'DAut' && g[1] === '00000000'));
  srv.kill(); sock.close(); console.log('\nAll ATEM tests passed.'); process.exit(0);
})().catch(e => { console.error('✗', e); process.exit(1); });
