# Audience in real Chrome: a phone votes on /join, the output's Audience overlay shows the bars and a QR code that OpenCV
# decodes back to the join link, the Question and Wall views draw, and the operator panel shows the QR and results.
#   python3 tests/audience_check.py [path-to-chrome]     (needs Playwright, Chrome, Pillow, OpenCV)
import json, urllib.request, subprocess, os, time, sys, tempfile, signal
from playwright.sync_api import sync_playwright
import cv2
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); CHROME = sys.argv[1] if len(sys.argv) > 1 else '/usr/bin/google-chrome'
B = 'http://127.0.0.1:8971'; tmp = tempfile.mkdtemp(); SHOT = os.environ.get('PX_SHOT_DIR', tmp)
srv = subprocess.Popen(['node', 'server.js'], cwd=ROOT, env=dict(os.environ, PORT='8971', OSC_PORT='8972', DATA_DIR=tmp + '/d', MEDIA_DIR=tmp + '/m'), stdout=open(tmp + '/log', 'w'), stderr=subprocess.STDOUT)
def api(p, body=None): return json.loads(urllib.request.urlopen(urllib.request.Request(B + p, data=json.dumps(body).encode() if body is not None else None, headers={'Content-Type': 'application/json'})).read() or b'{}')
for _ in range(60):
  try: api('/api/info'); break
  except Exception: time.sleep(0.2)
cmd = lambda c: api('/api/cmd', c); ok = lambda m: print('✓ ' + m)
try:
  cmd({'op': 'set', 'path': 'comp.width', 'value': 1280}); cmd({'op': 'set', 'path': 'comp.height', 'value': 720})
  for k, v in [('audience.on', True), ('audience.poll', {'question': 'Which encore?', 'options': ['Song A', 'Song B', 'Song C']}), ('audience.pollOpen', True), ('audience.moderate', False)]: cmd({'op': 'set', 'path': k, 'value': v})
  adm = api('/api/audience'); url = adm['url'].replace(adm['url'].split('/join')[0], B)
  gen = lambda view: {'type': 'gen', 'name': 'aud', 'gen': {'kind': 'audience', 'params': {'view': view, 'c1': '#ff2fd0', 'c2': '#ffffff', 'bg': '#0b0b12', 'size': 1}}}
  for i in range(4): cmd({'op': 'assign', 'layer': 0, 'slot': i, 'clip': gen([0, 3, 4, 2][i])})
  cmd({'op': 'trigger', 'layer': 0, 'clip': 0})
  with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=['--use-gl=swiftshader', '--enable-unsafe-swiftshader']); errs = []
    ph = b.new_page(viewport={'width': 390, 'height': 800}, device_scale_factor=2); ph.on('pageerror', lambda e: errs.append(str(e)))
    ph.goto(url); time.sleep(1.5); assert 'Which encore?' in ph.content(); ph.locator('.opt').nth(1).click(); time.sleep(1)
    assert 'Vote counted' in ph.content() and '100%' in ph.content(); ph.screenshot(path=SHOT + '/phone-vote.png')
    ph.locator('nav button', has_text='Ask').click(); ph.fill('#askName', 'Mia'); ph.fill('#askText', 'Can you play it twice?'); ph.click('#askSend'); time.sleep(1); assert 'Sent' in ph.content()
    ph.locator('nav button', has_text='Wall').click(); ph.fill('#wallText', 'Loving it!'); ph.click('#wallSend'); time.sleep(1)
    ok('phone: vote (results shown after voting), ask a question, post to the wall')
    a = api('/api/audience'); assert a['tally']['list'][1]['votes'] == 1 and a['qa'][0]['text'] == 'Can you play it twice?' and a['wall'][0]['text'] == 'Loving it!'
    api('/api/audience', {'action': 'status', 'what': 'qa', 'id': a['qa'][0]['id'], 'status': 'live'})
    out = b.new_page(viewport={'width': 1280, 'height': 720}); out.on('pageerror', lambda e: errs.append(str(e)))
    out.goto(B + '/clean?out=main&fs=0'); time.sleep(2.5); out.screenshot(path=SHOT + '/aud-poll.png')
    img = cv2.imread(SHOT + '/aud-poll.png'); val, pts, _ = cv2.QRCodeDetector().detectAndDecode(img)
    assert val == adm['url'], (val, adm['url']); ok(f'output: poll overlay drawn, its QR code decodes to the join link ({val})')
    from PIL import Image
    im = Image.open(SHOT + '/aud-poll.png').convert('RGB'); bar = im.getpixel((300, 172)); assert bar[0] > 200 and bar[2] > 150 and bar[1] < 120, bar  # Song B bar at 100 %
    ok(f'poll bars follow the votes {bar}')
    for clip, name, word in [(1, 'aud-question', 'question'), (2, 'aud-wall', 'wall')]:
      cmd({'op': 'trigger', 'layer': 0, 'clip': clip}); time.sleep(1.5); out.screenshot(path=SHOT + f'/{name}.png')
      px = Image.open(SHOT + f'/{name}.png').convert('RGB'); lit = sum(1 for x in range(0, 1280, 8) for y in range(0, 720, 8) if sum(px.getpixel((x, y))) > 200)
      assert lit > 40, (name, lit); ok(f'{word} overlay draws ({lit} lit samples)')
    ctl = b.new_page(viewport={'width': 1600, 'height': 1000}); ctl.on('pageerror', lambda e: errs.append(str(e)))
    ctl.goto(B + '/'); time.sleep(2); ctl.evaluate("() => UI.setRtab('audience')"); time.sleep(1.5)
    t = ctl.evaluate("() => document.querySelector('#rpane').innerText"); assert 'Song B' in t and 'Loving it!' in t and 'Can you play it twice?' in t, t[:500]
    ctl.locator('#audQr').screenshot(path=SHOT + '/aud-panel-qr.png'); v2, _, _ = cv2.QRCodeDetector().detectAndDecode(cv2.imread(SHOT + '/aud-panel-qr.png'))
    assert v2 == adm['url'], v2; ctl.screenshot(path=SHOT + '/aud-panel.png'); ok('operator panel: QR code (decodes), live results, questions and wall posts')
    assert not errs, errs; b.close()
  print('Audience check passed')
finally: srv.send_signal(signal.SIGTERM)
