// Stage 3D from MVR: 3DS + glTF geometry, nested group / symbol transforms, fixtures with beam directions, saved & served model.
//   node tests/mvr3d_test.js
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert'), zlib = require('zlib');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const MV = require(path.join(ROOT, 'server-mvr3d.js'));
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));

// --- fixtures: a unit cube in 3DS (mm) and in glTF (m, Y-up) ---
const CUBE_V = [[0, 0, 0], [1, 0, 0], [1, 1, 0], [0, 1, 0], [0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]];
const CUBE_F = [[0, 2, 1], [0, 3, 2], [4, 5, 6], [4, 6, 7], [0, 1, 5], [0, 5, 4], [1, 2, 6], [1, 6, 5], [2, 3, 7], [2, 7, 6], [3, 0, 4], [3, 4, 7]];
function chunk(id, body) { const h = Buffer.alloc(6); h.writeUInt16LE(id, 0); h.writeUInt32LE(6 + body.length, 2); return Buffer.concat([h, body]); }
function make3ds(size) { // size in mm
  const v = Buffer.alloc(2 + CUBE_V.length * 12); v.writeUInt16LE(CUBE_V.length, 0); CUBE_V.forEach((p, i) => p.forEach((c, a) => v.writeFloatLE(c * size[a], 2 + i * 12 + a * 4)));
  const f = Buffer.alloc(2 + CUBE_F.length * 8); f.writeUInt16LE(CUBE_F.length, 0); CUBE_F.forEach((t, i) => { t.forEach((c, a) => f.writeUInt16LE(c, 2 + i * 8 + a * 2)); });
  return chunk(0x4D4D, chunk(0x3D3D, chunk(0x4000, Buffer.concat([Buffer.from('box\0'), chunk(0x4100, Buffer.concat([chunk(0x4110, v), chunk(0x4120, f)]))]))));
}
function makeGlb() { // 1 m cube, Y-up, with a node translation of +1 m in Y (= up)
  const pos = Buffer.alloc(CUBE_V.length * 12); CUBE_V.forEach((p, i) => p.forEach((c, a) => pos.writeFloatLE(c, i * 12 + a * 4)));
  const idx = Buffer.alloc(CUBE_F.length * 6); CUBE_F.flat().forEach((c, i) => idx.writeUInt16LE(c, i * 2));
  const bin = Buffer.concat([pos, idx]);
  const j = { asset: { version: '2.0' }, scene: 0, scenes: [{ nodes: [0] }], nodes: [{ mesh: 0, translation: [0, 1, 0] }], meshes: [{ primitives: [{ attributes: { POSITION: 0 }, indices: 1 }] }],
    buffers: [{ byteLength: bin.length }], bufferViews: [{ buffer: 0, byteOffset: 0, byteLength: pos.length }, { buffer: 0, byteOffset: pos.length, byteLength: idx.length }],
    accessors: [{ bufferView: 0, componentType: 5126, count: 8, type: 'VEC3', min: [0, 0, 0], max: [1, 1, 1] }, { bufferView: 1, componentType: 5123, count: 36, type: 'SCALAR' }] };
  let js = Buffer.from(JSON.stringify(j)); while (js.length % 4) js = Buffer.concat([js, Buffer.from(' ')]);
  const H = Buffer.alloc(12); H.write('glTF', 0); H.writeUInt32LE(2, 4); H.writeUInt32LE(12 + 8 + js.length + 8 + bin.length, 8);
  const c = (b, t) => { const h = Buffer.alloc(8); h.writeUInt32LE(b.length, 0); h.writeUInt32LE(t, 4); return Buffer.concat([h, b]); };
  return Buffer.concat([H, c(js, 0x4E4F534A), c(bin, 0x004E4942)]);
}
function zip(files) { // stored + deflated entries
  const locals = [], cents = []; let off = 0;
  for (const [name, data, deflate] of files) { const comp = deflate ? zlib.deflateRawSync(data) : data; const nb = Buffer.from(name);
    const L = Buffer.alloc(30); L.writeUInt32LE(0x04034b50, 0); L.writeUInt16LE(20, 4); L.writeUInt16LE(deflate ? 8 : 0, 8); L.writeUInt32LE(comp.length, 18); L.writeUInt32LE(data.length, 22); L.writeUInt16LE(nb.length, 26);
    const C = Buffer.alloc(46); C.writeUInt32LE(0x02014b50, 0); C.writeUInt16LE(20, 4); C.writeUInt16LE(20, 6); C.writeUInt16LE(deflate ? 8 : 0, 10); C.writeUInt32LE(comp.length, 20); C.writeUInt32LE(data.length, 24); C.writeUInt16LE(nb.length, 28); C.writeUInt32LE(off, 42);
    locals.push(L, nb, comp); cents.push(C, nb); off += 30 + nb.length + comp.length; }
  const cd = Buffer.concat(cents); const E = Buffer.alloc(22); E.writeUInt32LE(0x06054b50, 0); E.writeUInt16LE(files.length, 8); E.writeUInt16LE(files.length, 10); E.writeUInt32LE(cd.length, 12); E.writeUInt32LE(off, 16);
  return Buffer.concat([...locals, cd, E]);
}
const XML = `<?xml version="1.0" encoding="UTF-8"?>
<GeneralSceneDescription verMajor="1" verMinor="6"><AUXData><Symdef uuid="SYM-1" name="Crate"><ChildList><Geometry3D fileName="crate.glb"/></ChildList></Symdef></AUXData>
<Scene><Layers><Layer name="Rig" uuid="L1"><ChildList>
  <Truss name="Front truss" uuid="T1"><Matrix>{1,0,0}{0,1,0}{0,0,1}{-5000,0,6000}</Matrix><Geometries><Geometry3D fileName="truss.3ds"/></Geometries></Truss>
  <GroupObject name="Set" uuid="G1"><Matrix>{1,0,0}{0,1,0}{0,0,1}{2000,0,0}</Matrix><ChildList>
    <SceneObject name="Riser" uuid="S1"><Matrix>{0,1,0}{-1,0,0}{0,0,1}{0,3000,0}</Matrix><Geometries><Symbol symdef="SYM-1" uuid="SY1"/></Geometries></SceneObject>
  </ChildList></GroupObject>
  <Fixture name="Spot 1" uuid="F1"><Matrix>{1,0,0}{0,1,0}{0,0,1}{1000,-2000,6000}</Matrix><GDTFSpec>Spot.gdtf</GDTFSpec><Addresses><Address break="0">1</Address></Addresses></Fixture>
  <VideoScreen name="Main LED" uuid="V1"><Matrix>{1,0,0}{0,1,0}{0,0,1}{0,0,3000}</Matrix><Geometries><Geometry3D fileName="truss.3ds"/></Geometries></VideoScreen>
</ChildList></Layer></Layers></Scene></GeneralSceneDescription>`;
(async () => {
  const files = { 'GeneralSceneDescription.xml': Buffer.from(XML), 'truss.3ds': make3ds([10000, 300, 300]), 'crate.glb': makeGlb() };
  const g3 = MV.read3ds(files['truss.3ds']); assert.strictEqual(g3.pos.length, 24); assert.strictEqual(g3.idx.length, 36); ok('3DS mesh read (8 vertices, 12 triangles)');
  const gg = MV.readGlb(files['crate.glb']); assert.strictEqual(gg.idx.length, 36); const zs = []; for (let i = 2; i < gg.pos.length; i += 3) zs.push(gg.pos[i]); assert.strictEqual(Math.min(...zs), 1000); ok('glTF mesh read, node transform applied, Y-up → Z-up, metres → mm');

  const M = MV.build(files, XML);
  assert.strictEqual(M.tris, 24, 'truss + riser; the video screen is drawn live, not as a mesh');
  assert.strictEqual(M.verts.length, 24 * 3 * 9);
  // truss: x from -5 to 5 m, height (Y) 6..6.3 m; riser: group +2 m X, object rotated 90° about Z and moved +3 m in MVR Y (= -3 m viewer Z), sitting 1 m up
  const pts = []; for (let i = 0; i < M.verts.length; i += 9) pts.push([M.verts[i], M.verts[i + 1], M.verts[i + 2], M.verts[i + 6]]);
  const truss = pts.filter(p => p[3] > 0.6), riser = pts.filter(p => p[3] < 0.4);
  const rng = (a, k) => [Math.min(...a.map(p => p[k])), Math.max(...a.map(p => p[k]))].map(v => +v.toFixed(3));
  assert.deepStrictEqual(rng(truss, 0), [-5, 5]); assert.deepStrictEqual(rng(truss, 1), [6, 6.3]); ok('truss placed by its matrix (10 m wide at 6 m trim)');
  assert.deepStrictEqual(rng(riser, 0), [2, 3]); assert.deepStrictEqual(rng(riser, 1), [1, 2]); assert.deepStrictEqual(rng(riser, 2), [-4, -3]); ok('group → object → symbol transforms compose (rotation + offsets)');
  assert.strictEqual(M.fixtures.length, 1); assert.deepStrictEqual(M.fixtures[0].p, [1, 6, 2]); assert.deepStrictEqual(M.fixtures[0].d.map(v => v + 0), [0, -1, 0]); ok('fixture position and beam direction (pointing down)');
  assert.deepStrictEqual(M.bounds.min, [-5, 1, -4]);

  // server: import, store, serve
  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxmvr-'));
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8891, OSC_PORT: 8892, DATA_DIR: DATA, MEDIA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxmvrm-')) }, stdio: 'ignore' }); kids.push(srv);
  const B = 'http://127.0.0.1:8891'; for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const mvr = zip([['GeneralSceneDescription.xml', Buffer.from(XML), true], ['truss.3ds', files['truss.3ds'], false], ['crate.glb', files['crate.glb'], true]]);
  if (process.env.MVR_OUT) fs.writeFileSync(process.env.MVR_OUT, mvr);
  const r = await fetch(B + '/api/mvr?apply=1&name=Festival', { method: 'POST', body: mvr }).then(r => r.json());
  assert.strictEqual(r.added.length, 1); assert.ok(r.model && r.model.tris === 24 && r.model.fixtures === 1, JSON.stringify(r.model)); ok('MVR import adds the screen and saves the 3D model');
  const s = await fetch(B + '/api/state').then(r => r.json()); assert.strictEqual(s.stage3d.id, r.model.id); assert.strictEqual(s.stage3d.name, 'Festival'); assert.strictEqual(s.led.layout3d, 'custom');
  const bin = await fetch(B + '/api/stage3d/model?id=' + r.model.id).then(r => r.arrayBuffer()); assert.strictEqual(bin.byteLength, 24 * 3 * 36);
  const fx = await fetch(B + '/api/stage3d/fixtures?id=' + r.model.id).then(r => r.json()); assert.strictEqual(fx[0].name, 'Spot 1');
  assert.strictEqual((await fetch(B + '/api/stage3d/model?id=../../etc')).status, 404); ok('model and fixtures served by id (path-safe); show references the model, stage switches to MVR layout');
  // the model travels with exported shows and is copied to backup servers
  const doc = await fetch(B + '/api/show/export').then(r => r.json()); assert.strictEqual(doc.stage3dModel.id, r.model.id); assert.strictEqual(Buffer.from(doc.stage3dModel.bin, 'base64').length, 24 * 3 * 36);
  const D2 = fs.mkdtempSync(path.join(os.tmpdir(), 'pxmvr2-')); const s2 = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8893, OSC_PORT: 8894, DATA_DIR: D2, MEDIA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxmvrm2-')) }, stdio: 'ignore' }); kids.push(s2);
  const B2 = 'http://127.0.0.1:8893'; for (let i = 0; i < 60 && !(await fetch(B2 + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const bad = JSON.parse(JSON.stringify(doc)); bad.stage3dModel.fixtures[0].name = 'tampered'; bad.state.stage3d = null;
  await fetch(B2 + '/api/show/import', { method: 'POST', body: JSON.stringify(bad) }); assert.strictEqual((await fetch(B2 + '/api/stage3d/model?id=' + r.model.id)).status, 404); ok('tampered model data in a show file is rejected');
  const im = await fetch(B2 + '/api/show/import', { method: 'POST', body: JSON.stringify(doc) }); assert.ok(im.ok);
  assert.strictEqual((await fetch(B2 + '/api/stage3d/model?id=' + r.model.id).then(r => r.arrayBuffer())).byteLength, 24 * 3 * 36); assert.strictEqual((await fetch(B2 + '/api/state').then(r => r.json())).stage3d.id, r.model.id); ok('exported show carries the 3D model to another machine');
  const D3 = fs.mkdtempSync(path.join(os.tmpdir(), 'pxmvr3-')); const s3 = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8897, OSC_PORT: 8898, DATA_DIR: D3, MEDIA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxmvrm3-')) }, stdio: 'ignore' }); kids.push(s3);
  const B3 = 'http://127.0.0.1:8897'; for (let i = 0; i < 60 && !(await fetch(B3 + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  await fetch(B3 + '/api/settings', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ backup: { mode: 'backup', primary: B, failoverSec: 3 } }) });
  for (let i = 0; i < 60 && (await fetch(B3 + '/api/stage3d/model?id=' + r.model.id)).status !== 200; i++) await tick(200);
  assert.strictEqual((await fetch(B3 + '/api/stage3d/model?id=' + r.model.id)).status, 200); ok('backup server copies the 3D model from the primary');
  process.exit(0);
})().catch(e => { console.error('✗', e.stack || e.message); process.exit(1); });
