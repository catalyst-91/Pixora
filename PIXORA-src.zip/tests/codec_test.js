// NotchLC / DXV: .mov files in codecs browsers can't decode are recognised from their sample description, shown as needing
// conversion in the library, and queued for conversion when placed in a slot or by "convert all"; ordinary .mov files are not.
//   node tests/codec_test.js
const { spawn, execFileSync } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
const tmp = p => fs.mkdtempSync(path.join(os.tmpdir(), p));
const api = (B, p, body) => fetch(B + p, body !== undefined ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : {}).then(r => r.json());
(async () => {
  let ff = 'ffmpeg'; try { execFileSync(ff, ['-version'], { stdio: 'ignore' }); } catch { console.log('✓ skipped: no ffmpeg'); return; }
  const D = tmp('pxc-'), M = tmp('pxcm-');
  const mk = (name, args) => execFileSync(ff, ['-v', 'error', '-f', 'lavfi', '-i', 'testsrc=size=64x36:rate=25:duration=1', ...args, '-y', path.join(M, name)]);
  // ffmpeg can decode NotchLC and DXV but not write them: make uncompressed .mov files and give them those codecs' sample-description
  // tags, which is all the sniff reads (a real file of either kind then converts through ffmpeg's own decoders)
  const retag = (name, fc) => { mk(name, ['-c:v', 'rawvideo', '-pix_fmt', 'uyvy422']); const f = path.join(M, name), b = fs.readFileSync(f), i = b.indexOf('stsd');
    assert.ok(i > 0 && b.toString('latin1', i + 16, i + 20) === '2vuy'); b.write(fc, i + 16, 'latin1'); fs.writeFileSync(f, b); };
  retag('notch.mov', 'nlc1'); retag('resolume.mov', 'DXD3');
  mk('normal.mov', ['-c:v', 'libx264', '-pix_fmt', 'yuv420p']);
  const B = 'http://127.0.0.1:8961';
  kids.push(spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8961, OSC_PORT: 8962, DATA_DIR: D, MEDIA_DIR: M }, stdio: 'ignore' }));
  for (let i = 0; i < 80 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const lib = await api(B, '/api/library?refresh=1'); const items = lib.sources.flatMap(s => s.items); const by = n => items.find(i => i.name === n);
  assert.ok(by('notch.mov') && by('resolume.mov') && by('normal.mov'), JSON.stringify(items.map(i => i.name)));
  assert.strictEqual(by('notch.mov').native, false); assert.strictEqual(by('notch.mov').playable, false);
  assert.strictEqual(by('resolume.mov').native, false); assert.strictEqual(by('normal.mov').native, true); assert.strictEqual(by('normal.mov').playable, true);
  ok('library: NotchLC and DXV .mov files need converting, an H.264 .mov plays as it is');
  await api(B, '/api/cmd', { op: 'assign', layer: 0, slot: 0, clip: { type: 'video', name: 'N', src: by('notch.mov').src } });
  await api(B, '/api/cmd', { op: 'assign', layer: 0, slot: 1, clip: { type: 'video', name: 'H', src: by('normal.mov').src } });
  await tick(400); let jobs = (await api(B, '/api/jobs')).jobs;
  assert.ok(jobs.some(j => j.src === by('notch.mov').src), JSON.stringify(jobs)); assert.ok(!jobs.some(j => j.src === by('normal.mov').src));
  ok('placing a NotchLC clip in a slot queues its conversion; the H.264 clip is left alone');
  await api(B, '/api/cmd', { op: 'assign', layer: 0, slot: 2, clip: { type: 'video', name: 'R', src: by('resolume.mov').src } });
  await api(B, '/api/convertAll', {}); await tick(300); jobs = (await api(B, '/api/jobs')).jobs;
  assert.ok(jobs.some(j => j.src === by('resolume.mov').src)); ok('the DXV clip is converted too');
  process.exit(0);
})().catch(e => { console.error('✗', e); process.exit(1); });
