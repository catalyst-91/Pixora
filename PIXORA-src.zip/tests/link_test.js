// PIXORA ⇄ Ableton Link test: PIXORA runs its Carabiner helper; a second Carabiner plays "Ableton Live".
// Checks peers, tempo both ways, and that PIXORA's bar phase lines up with the Link session.
//   PIXORA_CARABINER=/path/to/Carabiner node tests/link_test.js
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), net = require('net'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const EXE = process.env.PIXORA_CARABINER || path.join(ROOT, 'desktop', 'link-dist', process.platform === 'win32' ? 'Carabiner.exe' : 'Carabiner');
if (!fs.existsSync(EXE)) { if (process.env.PIXORA_REQUIRE_CARABINER) { console.error('Carabiner was not built: ' + EXE); process.exit(1); } console.log('Carabiner not built — skipping Link test'); process.exit(0); }
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
const until = async (fn, ms = 8000) => { const t = Date.now(); while (Date.now() - t < ms) { const v = await fn(); if (v) return v; await tick(80); } throw new Error('timed out'); };
(async () => {
  const live = spawn(EXE, ['--port', '17031', '--daemon'], { stdio: 'ignore' }); kids.push(live); await tick(500);
  const peer = net.connect(17031, '127.0.0.1'); let pl = '', plAt = 0; peer.setEncoding('utf8'); peer.on('data', d => { pl += d; plAt = Date.now(); }); await new Promise(r => peer.on('connect', r));
  const peerStatus = async () => { pl = ''; peer.write('status\n'); await tick(120); const m = /:peers (\d+) :bpm ([\d.]+) :start (\d+) :beat ([-\d.]+)/.exec(pl); return m && { peers: +m[1], bpm: +m[2], beat: +m[4], at: plAt }; };
  peer.write('bpm 122.0\n');
  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxlink-')), MEDIA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxlinkm-'));
  fs.writeFileSync(path.join(DATA, 'settings.json'), JSON.stringify({ link: { on: true, mode: 'both', port: 17030 } }));
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8877, OSC_PORT: 8878, DATA_DIR: DATA, MEDIA_DIR: MEDIA, PIXORA_CARABINER: EXE }, stdio: ['ignore', 'pipe', 'pipe'] }); kids.push(srv);
  const B = 'http://127.0.0.1:8877'; for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const st = () => fetch(B + '/api/state').then(r => r.json()), lk = () => fetch(B + '/api/link').then(r => r.json());
  const v = await until(async () => { const x = await lk(); return x.peers >= 1 ? x : null; }); ok(`PIXORA joined the Link session (${v.peers} peer, helper started by PIXORA)`);
  await until(async () => (await st()).comp.bpm === 122); ok('Live sets 122 BPM → PIXORA follows');
  peer.write('bpm 128.0\n'); await until(async () => (await st()).comp.bpm === 128); ok('Live changes to 128 BPM → PIXORA follows');
  await fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ op: 'set', path: 'comp.bpm', value: 140 }) });
  await until(async () => { const p = await peerStatus(); return p && Math.abs(p.bpm - 140) < 0.01; }); ok('PIXORA tapped to 140 BPM → the Link session (Live) goes to 140');
  await tick(1500);
  const s = await st(), p = await peerStatus(); const bar = 4 * 60000 / s.comp.bpm, pixPh = ((((p.at - s.comp.beatEpoch) % bar) + bar) % bar) / bar * 4, linkPh = ((p.beat % 4) + 4) % 4;
  const d = Math.min(Math.abs(pixPh - linkPh), 4 - Math.abs(pixPh - linkPh)); assert.ok(d < 0.06, `phase ${pixPh.toFixed(3)} vs ${linkPh.toFixed(3)}`); ok(`bar phase lines up with Link (PIXORA beat ${pixPh.toFixed(2)} vs Live ${linkPh.toFixed(2)} of 4)`);
  await fetch(B + '/api/link', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ mode: 'follow' }) }); await tick(800);
  await fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ op: 'set', path: 'comp.bpm', value: 100 }) }); await tick(1200);
  const p2 = await peerStatus(); assert.ok(Math.abs(p2.bpm - 140) < 0.01, 'follow mode must not push tempo'); ok('follow mode: PIXORA changes stay local, Live keeps 140');
  peer.destroy(); srv.kill(); console.log('\nAll Link tests passed.'); process.exit(0);
})().catch(e => { console.error('✗', e); process.exit(1); });
