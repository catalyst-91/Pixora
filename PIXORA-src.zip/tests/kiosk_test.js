// Kiosk / signage: day-part windows (weekdays, overnight, campaign dates, priority), the server keeping the right day-part on
// air (on change, on start-up after a "power cut", "otherwise" outside every window), and the control lock with its PIN.
//   node tests/kiosk_test.js
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
const K = require('../server-kiosk.js');
const at = (y, mo, d, h, mi) => new Date(y, mo - 1, d, h, mi);
(async () => {
  // ---- windows (2026-11-16 is a Monday)
  const dp = o => Object.assign({ id: 'x', name: 'x', on: true, days: [0, 1, 2, 3, 4, 5, 6], from: '09:00', to: '17:00', dateFrom: '', dateTo: '' }, o);
  assert.ok(K.inWindow(dp({}), at(2026, 11, 16, 9, 0)) && K.inWindow(dp({}), at(2026, 11, 16, 16, 59)) && !K.inWindow(dp({}), at(2026, 11, 16, 17, 0)));
  const wk = dp({ days: [1, 2, 3, 4, 5] }); assert.ok(K.inWindow(wk, at(2026, 11, 20, 12, 0)) && !K.inWindow(wk, at(2026, 11, 21, 12, 0)), 'weekdays only');
  const night = dp({ from: '22:00', to: '02:00', days: [5] }); // Friday night
  assert.ok(K.inWindow(night, at(2026, 11, 20, 23, 30)) && K.inWindow(night, at(2026, 11, 21, 1, 59)) && !K.inWindow(night, at(2026, 11, 21, 2, 0)) && !K.inWindow(night, at(2026, 11, 20, 1, 0)) && !K.inWindow(night, at(2026, 11, 21, 23, 0)));
  const camp = dp({ dateFrom: '2026-12-01', dateTo: '2026-12-24' }); assert.ok(!K.inWindow(camp, at(2026, 11, 30, 12, 0)) && K.inWindow(camp, at(2026, 12, 24, 12, 0)) && !K.inWindow(camp, at(2026, 12, 25, 12, 0)));
  const nightCamp = dp({ from: '22:00', to: '02:00', dateTo: '2026-12-24' }); assert.ok(K.inWindow(nightCamp, at(2026, 12, 25, 1, 0)), 'the overnight tail belongs to the day it started');
  assert.ok(K.inWindow(dp({ from: '00:00', to: '00:00' }), at(2026, 11, 16, 3, 0)) && !K.inWindow(dp({ on: false }), at(2026, 11, 16, 12, 0)));
  const k = { dayparts: [dp({ id: 'xmas', name: 'Xmas', dateFrom: '2026-12-01', dateTo: '2026-12-24' }), dp({ id: 'day', name: 'Day' })] };
  assert.strictEqual(K.current(k, at(2026, 12, 10, 12, 0)).id, 'xmas'); assert.strictEqual(K.current(k, at(2026, 11, 10, 12, 0)).id, 'day'); assert.strictEqual(K.current(k, at(2026, 11, 10, 20, 0)), null);
  const nx = K.nextChange(k, at(2026, 11, 10, 16, 30)); assert.strictEqual(new Date(nx.at).getHours(), 17); assert.strictEqual(nx.to, null);
  ok('windows: times, weekdays, overnight (belongs to the start day), campaign dates, all day, first match wins, next change');

  // ---- server
  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxk-')), MEDIA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxkm-')); let srv;
  const start = () => { srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8951, OSC_PORT: 8952, DATA_DIR: DATA, MEDIA_DIR: MEDIA }, stdio: 'ignore' }); kids.push(srv); };
  const B = 'http://127.0.0.1:8951', up = async () => { for (let i = 0; i < 80 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150); };
  const cmd = x => fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(x) }).then(r => r.json());
  const state = () => fetch(B + '/api/state').then(r => r.json());
  start(); await up();
  const gen = c => ({ type: 'gen', name: c, gen: { kind: 'solid', params: { c1: c } } });
  for (let i = 0; i < 3; i++) await cmd({ op: 'assign', layer: 0, slot: i, clip: gen(['#f00', '#0f0', '#00f'][i]) });
  const n = new Date(), hm = m => { const d = new Date(n.getTime() + m * 60000); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); };
  await cmd({ op: 'set', path: 'kiosk.dayparts', value: [
    { id: 'now', name: 'Lunch', on: true, days: [0, 1, 2, 3, 4, 5, 6], from: hm(-30), to: hm(30), action: { type: 'trigger', layer: 1, clip: 2 } },
    { id: 'later', name: 'Evening', on: true, days: [0, 1, 2, 3, 4, 5, 6], from: hm(60), to: hm(120), action: { type: 'trigger', layer: 1, clip: 3 } }] });
  await cmd({ op: 'set', path: 'kiosk.otherwise', value: { type: 'blackoutOn' } });
  let s = await state(); assert.strictEqual(s.layers[0].active, null, 'nothing happens while kiosk mode is off');
  await cmd({ op: 'set', path: 'kiosk.on', value: true }); await tick(400); s = await state(); assert.strictEqual(s.layers[0].active, 1, 'switching kiosk mode on puts the current day-part on air');
  let kv = await fetch(B + '/api/kiosk').then(r => r.json()); assert.strictEqual(kv.status.current.name, 'Lunch'); assert.ok(kv.status.next && kv.status.next.at > Date.now());
  ok(`kiosk on → “Lunch” on air at once (next change ${new Date(kv.status.next.at).toLocaleTimeString()})`);
  await cmd({ op: 'trigger', layer: 0, clip: 0 }); // someone plays something else; the day-part doesn't fight it…
  await tick(300); s = await state(); assert.strictEqual(s.layers[0].active, 0, 'manual trigger'); await tick(5600); s = await state(); assert.strictEqual(s.layers[0].active, 0, JSON.stringify((await fetch(B + '/api/monitor').then(r => r.json())).log.filter(l => /kiosk|schedule|cmd/.test(JSON.stringify(l))).slice(-12)));
  srv.kill('SIGKILL'); await tick(500); start(); await up(); await tick(2200); s = await state(); assert.strictEqual(s.layers[0].active, 1);
  ok('…until a power cut: on start-up the current day-part is put back on air');
  await cmd({ op: 'set', path: 'kiosk.dayparts.0.from', value: hm(200) }); await cmd({ op: 'set', path: 'kiosk.dayparts.0.to', value: hm(230) }); await tick(400);
  s = await state(); assert.strictEqual(s.comp.blackout, true); kv = await fetch(B + '/api/kiosk').then(r => r.json()); assert.strictEqual(kv.status.current, null);
  ok('when the window moves away from now, “otherwise” runs (blackout)');

  // ---- lock
  await cmd({ op: 'set', path: 'comp.blackout', value: false });
  const r1 = await fetch(B + '/api/kiosk', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ pin: '12a' }) }); assert.strictEqual(r1.status, 400);
  await fetch(B + '/api/kiosk', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ pin: '2468' }) });
  assert.ok(!JSON.stringify(await fetch(B + '/api/settings').then(r => r.json())).includes('2468') && !JSON.stringify(await state()).includes('2468'), 'the PIN is not sent to clients');
  await cmd({ op: 'set', path: 'kiosk.locked', value: true });
  const ws = new WebSocket(B.replace('http', 'ws') + '/ws?role=control'); const msgs = []; ws.onmessage = e => { if (typeof e.data === 'string') { try { msgs.push(JSON.parse(e.data)); } catch {} } };
  await new Promise(r => ws.onopen = r); await tick(400);
  const kmsg = () => msgs.filter(m => m.t === 'kiosk').pop(); assert.strictEqual(kmsg().unlocked, false); assert.strictEqual(kmsg().pinSet, true);
  ws.send(JSON.stringify({ t: 'cmd', cmd: { op: 'set', path: 'comp.master', value: 0.2 } })); await tick(400);
  assert.notStrictEqual((await state()).comp.master, 0.2); assert.ok(msgs.some(m => m.t === 'error' && /locked/.test(m.msg)));
  ws.send(JSON.stringify({ t: 'kioskUnlock', pin: '1111' })); await tick(300); assert.strictEqual(kmsg().unlocked, false); assert.strictEqual(kmsg().wrong, true);
  ws.send(JSON.stringify({ t: 'kioskUnlock', pin: '2468' })); await tick(300); assert.strictEqual(kmsg().unlocked, true);
  ws.send(JSON.stringify({ t: 'cmd', cmd: { op: 'set', path: 'comp.master', value: 0.2 } })); await tick(400); assert.strictEqual((await state()).comp.master, 0.2);
  ws.send(JSON.stringify({ t: 'kioskLock' })); await tick(300); ws.send(JSON.stringify({ t: 'cmd', cmd: { op: 'set', path: 'comp.master', value: 0.7 } })); await tick(400); assert.strictEqual((await state()).comp.master, 0.2);
  await cmd({ op: 'set', path: 'comp.master', value: 0.9 }); assert.strictEqual((await state()).comp.master, 0.9, 'the HTTP API keeps working');
  ok('lock: control clients are refused until the right PIN (wrong PIN reported), can lock again, the HTTP API keeps working, the PIN never reaches clients');
  ws.close(); console.log('Kiosk test passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
