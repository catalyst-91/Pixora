// Virtual production: FreeD D1 messages (build / parse / checksum), the UDP receiver, tracking reaching the outputs,
// the off-axis projection for a wall, and wall corners.
//   node tests/vp_test.js
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), dgram = require('dgram'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
const F = require('../server-freed.js'), S3 = require('../public/scene3d.js');
(async () => {
  const pose = { cam: 3, pan: -45.5, tilt: 12.25, roll: -1, x: 1234.5, y: -6000, z: 1650, zoom: 40000, focus: 1200 }, b = F.build(pose), q = F.parse(b);
  assert.strictEqual(b.length, 29); for (const k of Object.keys(pose)) assert.ok(Math.abs(q[k] - pose[k]) < 0.05, k + ' ' + q[k]);
  const bad = Buffer.from(b); bad[5] ^= 1; assert.strictEqual(F.parse(bad), null, 'checksum'); assert.strictEqual(F.parse(Buffer.alloc(10)), null);
  ok('FreeD D1: pan / tilt / roll, X / Y / Z, zoom / focus round-trip; a bad checksum is refused');
  // off-axis: eye straight in front of a 4 × 2 m wall → symmetric frustum; eye to the right → frustum shifts left
  const w = S3.wallCorners({ cx: 0, cy: 1, cz: 0, w: 4, h: 2, yaw: 0 }); assert.deepStrictEqual(w.pa.map(v => +v.toFixed(6)), [-2, 0, 0]); assert.deepStrictEqual(w.pc.map(v => +v.toFixed(6)), [-2, 2, 0]);
  let o = S3.offAxis(w.pa, w.pb, w.pc, [0, 1, 4], 1, 100); assert.ok(Math.abs(o.frustum.l + o.frustum.r) < 1e-9 && Math.abs(o.frustum.l + 0.5) < 1e-9 && Math.abs(o.frustum.t - 0.25) < 1e-9, JSON.stringify(o.frustum));
  o = S3.offAxis(w.pa, w.pb, w.pc, [1, 1, 4], 1, 100); assert.ok(o.frustum.l < -0.5 && o.frustum.r < 0.5, JSON.stringify(o.frustum)); assert.strictEqual(S3.offAxis(w.pa, w.pb, w.pc, [0, 1, -1], 1, 100), null, 'behind');
  const side = S3.wallCorners({ cx: -3, cy: 1, cz: 2, w: 4, h: 2, yaw: 90 }); assert.ok(Math.abs(side.pa[2] - 4) < 1e-9 && Math.abs(side.pb[2]) < 1e-9 && Math.abs(side.pa[0] + 3) < 1e-9, JSON.stringify(side));
  const floor = S3.wallCorners({ cx: 0, cy: 0, cz: 2, w: 4, h: 4, pitch: 90 }); assert.ok(Math.abs(floor.pc[1]) < 1e-9 && Math.abs(floor.pc[2]) < 1e-9 && Math.abs(floor.pa[2] - 4) < 1e-9, JSON.stringify(floor));
  ok('off-axis projection: symmetric in front of the wall, skewed when the eye moves, none from behind; side walls (yaw 90) and floors (pitch 90) placed right');
  assert.deepStrictEqual(S3.eyeFrom({ offset: { x: 0.5, y: 0, z: 0 }, invert: {} }, { x: 1000, y: -6000, z: 1600 }).map(v => +v.toFixed(3)), [1.5, 1.6, 6]); ok('FreeD floor X / Y + height Z → stage X, Y-up, Z');

  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxv-'));
  kids.push(spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8991, OSC_PORT: 8992, DATA_DIR: DATA, MEDIA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxvm-')) }, stdio: 'ignore' }));
  const B = 'http://127.0.0.1:8991'; for (let i = 0; i < 80 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const cmd = x => fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(x) }).then(r => r.json());
  await cmd({ op: 'set', path: 'vp.port', value: 40999 }); await cmd({ op: 'set', path: 'vp.on', value: true }); await tick(600);
  const ws = new WebSocket(B.replace('http', 'ws') + '/ws?role=output'); const tracks = []; ws.onmessage = e => { if (typeof e.data === 'string') { const m = JSON.parse(e.data); if (m.t === 'track') tracks.push(m); } };
  await new Promise(r => ws.onopen = r);
  const u = dgram.createSocket('udp4'); const sendP = p => new Promise(r => u.send(F.build(p), 40999, '127.0.0.1', r));
  const t0 = Date.now(); for (let i = 0; i < 60; i++) { await sendP({ ...pose, x: i * 10 }); await tick(10); }
  await new Promise(r => u.send(Buffer.concat([F.build({ ...pose, cam: 7 }), F.build({ ...pose, cam: 8 })]), 40999, '127.0.0.1', r)); // two messages in one datagram
  const junk = F.build(pose); junk[28] ^= 0xff; await new Promise(r => u.send(junk, 40999, '127.0.0.1', r)); await tick(1300);
  const st = await fetch(B + '/api/vp').then(r => r.json());
  assert.strictEqual(st.port, 40999); assert.ok(st.packets >= 62 && st.bad >= 1, JSON.stringify(st)); assert.ok(Math.abs(st.cams[3].x - 590) < 0.1 && st.cams[7] && st.cams[8]);
  assert.ok(tracks.length >= 10 && tracks.length <= 62, tracks.length); assert.ok(Math.abs(tracks[tracks.length - 1].cams[3].x - 590) < 0.1);
  ok(`receiver: ${st.packets} messages (two in one datagram too), bad ones counted; outputs got ${tracks.length} updates (capped near 60/s) with the latest pose`);
  await cmd({ op: 'set', path: 'vp.on', value: false }); await tick(400); assert.strictEqual((await fetch(B + '/api/vp').then(r => r.json())).port, 0); ok('switching tracking off closes the port');
  ws.close(); u.close(); console.log('Virtual production test passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
