// Spout / Syphon loader (desktop/texshare.js): finds the module for this platform, puts SpoutLibrary.dll's folder on the
// search path, adapts it to the sender interface the output pipeline uses, and degrades cleanly when it's missing.
// The native modules themselves are built and can only run on Windows / macOS (build/texshare-prepare.js).
//   node tests/desktop_texshare_test.js
const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert'), Module = require('module');
const ok = m => console.log('✓ ' + m);
const ROOT = path.join(__dirname, '..');
const real = Object.getOwnPropertyDescriptor(process, 'platform');
const as = p => Object.defineProperty(process, 'platform', { value: p, configurable: true });
const fresh = () => { delete require.cache[require.resolve(path.join(ROOT, 'desktop/texshare.js'))]; return require(path.join(ROOT, 'desktop/texshare.js')); };
try {
  as('linux'); let t = fresh().open({}); assert.strictEqual(t.available, false); assert.match(t.error, /Windows \/ macOS/); ok('Linux: reported as not applicable');
  as('win32'); delete process.env.PIXORA_TEXSHARE_DIR; t = fresh().open({ resourcesPath: os.tmpdir() }); assert.strictEqual(t.available, false); assert.match(t.error, /not included in this build/); assert.deepStrictEqual(t.senders(), []); ok('missing module: clean "not included" message, no crash');
  // a stand-in module: Module._extensions['.node'] loads our JS in place of a binary
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pxts-')); const file = path.join(dir, `pixora_texshare-win32-${process.arch}.node`);
  fs.writeFileSync(file, `const sent = []; let n = 0; module.exports = { kind: 'spout', available: () => true, lastError: () => '', senders: () => [{ name: 'Resolume', width: 1920, height: 1080 }],
    createSender: name => { sent.push(['create', name]); return ++n; }, send: (id, b, w, h) => { sent.push(['send', id, b.length, w, h]); return true; }, close: id => { sent.push(['close', id]); return true; },
    openReceiver: () => 9, receive: () => null, _log: sent };`);
  const orig = Module._extensions['.node']; Module._extensions['.node'] = (m, f) => Module._extensions['.js'](m, f);
  process.env.PIXORA_TEXSHARE_DIR = dir; t = fresh().open({});
  Module._extensions['.node'] = orig;
  assert.strictEqual(t.available, true); assert.strictEqual(t.kind, 'Spout'); assert.ok(process.env.PATH.split(path.delimiter).includes(dir), 'DLL folder on PATH');
  assert.deepStrictEqual(t.senders(), [{ name: 'Resolume', width: 1920, height: 1080 }]);
  const s = t.create('PIXORA Main'); assert.ok(s.send(Buffer.alloc(16 * 9 * 4), 16, 9)); s.close();
  assert.deepStrictEqual(t.mod._log, [['create', 'PIXORA Main'], ['send', 1, 576, 16, 9], ['close', 1]]); ok('Windows: module found, DLL folder on PATH, senders listed, create → send → close');
  as('darwin'); assert.strictEqual(fresh().open({}).kind, 'Syphon'); ok('macOS: Syphon');
  // the desktop app wires it in
  const main = fs.readFileSync(path.join(ROOT, 'desktop/main.js'), 'utf8'), pre = fs.readFileSync(path.join(ROOT, 'desktop/preload.js'), 'utf8'), pkg = require(path.join(ROOT, 'desktop/package.json'));
  assert.ok(main.includes("require('./texshare.js')") && main.includes("'native-open-texshare'") && pre.includes('openTexShare'));
  assert.ok(pkg.build.files.includes('texshare.js') && pkg.build.extraResources.some(r => r.from === 'texshare-dist'));
  assert.ok(fs.readFileSync(path.join(ROOT, 'desktop/build/before-pack.js'), 'utf8').includes('texshare-prepare')); ok('desktop app: sender + receiver IPC, packaged resources, build step');
} finally { Object.defineProperty(process, 'platform', real); }
