// NDI® live test: PIXORA NDI module → real NDI runtime. Sends video + audio, discovers the source, receives it back.
// Build the module (cd desktop/native/ndi && npx node-gyp rebuild) and point NDI_LIB at the NDI runtime library, e.g.
//   NDI_LIB="/path/NDI SDK for Linux/lib/x86_64-linux-gnu/libndi.so.6" node tests/ndi_live_test.js
const NDI = require(require('path').join(__dirname, '..', 'desktop', 'ndi.js'));
const assert = require('assert');
process.env.PIXORA_NDI_RUNTIME = process.env.NDI_LIB || process.env.PIXORA_NDI_RUNTIME;
process.env.PIXORA_NDI_ADDON = process.env.PIXORA_NDI_ADDON || require('path').join(__dirname, '..', 'desktop', 'native', 'ndi', 'build', 'Release', 'pixora_ndi.node');
(async () => {
  const ndi = NDI.open({});
  console.log('available:', ndi.available, ndi.version, ndi.error);
  assert.ok(ndi.available);
  const W = 640, H = 360;
  const tx = ndi.sender('PIXORA Test Output', {});
  const frame = Buffer.alloc(W * H * 4);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const i = (y * W + x) * 4; const left = x < W / 2; frame[i] = left ? 255 : 0; frame[i + 1] = 0; frame[i + 2] = left ? 0 : 255; frame[i + 3] = 255; } // BGRA: left blue, right red
  let sending = true, sent = 0, dropped = 0;
  const pump = setInterval(async () => { if (!sending) return; const ok = await tx.video(frame, W, H, { fourCC: 'BGRA', frameRateN: 30, frameRateD: 1 }); ok ? sent++ : dropped++;
    const a = new Float32Array(1600 * 2); for (let i = 0; i < 1600; i++) { const v = Math.sin(2 * Math.PI * 1000 * (sent * 1600 + i) / 48000) * 0.5; a[2 * i] = v; a[2 * i + 1] = -v; } tx.audio(a, 48000, 2); }, 33);
  let src = null;
  for (let i = 0; i < 10 && !src; i++) { const list = await ndi.find(1000, '127.0.0.1'); console.log('sources:', list.map(s => s.name + ' @ ' + s.url)); src = list.find(s => s.name.includes('PIXORA Test Output')); }
  assert.ok(src, 'source found by NDI discovery');
  const rx = ndi.receiver(src, { colorFormat: 'rgba' });
  let video = null, audio = null; const t0 = Date.now();
  while ((!video || !audio) && Date.now() - t0 < 15000) { const f = await rx.capture(500); if (f.type === 'video' && !video) video = f; if (f.type === 'audio' && !audio) audio = f; }
  assert.ok(video, 'video received'); console.log('video:', video.xres + '×' + video.yres, video.fourCC, video.frameRateN + '/' + video.frameRateD, 'stride', video.lineStrideBytes, 'bytes', video.data.length);
  const px = (x, y) => { const i = y * video.lineStrideBytes + x * 4; return [...video.data.subarray(i, i + 4)]; };
  console.log('left pixel RGBA', px(100, 180), 'right pixel RGBA', px(540, 180));
  const L = px(100, 180), R = px(540, 180);
  assert.ok(L[2] > 200 && L[0] < 40, 'left is blue'); assert.ok(R[0] > 200 && R[2] < 40, 'right is red');
  assert.ok(audio, 'audio received'); console.log('audio:', audio.sampleRate, 'Hz', audio.channels, 'ch', audio.samples, 'samples, first L/R', audio.data[100].toFixed(3), audio.data[101].toFixed(3));
  assert.ok(Math.abs(audio.data[100] + audio.data[101]) < 0.02, 'R is inverted L');
  console.log('receiver connections on sender:', tx.connections(), '| sent', sent, 'dropped', dropped);
  assert.ok(tx.connections() >= 1);
  rx.destroy(); sending = false; clearInterval(pump); await new Promise(r => setTimeout(r, 200)); tx.destroy();
  console.log('NDI LIVE TEST PASS'); process.exit(0);
})().catch(e => { console.error('FAIL', e); process.exit(1); });
