// Audience interaction: QR encoder round trip (via the matrix), the join key instead of the PIN, voting (one per phone,
// changeable, closed polls refused, new poll resets), questions with moderation / block words / upvotes / one on screen,
// the wall, rate limits, the "audience" feed for the outputs, and a new join link locking out the old one.
//   node tests/audience_test.js
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
const qr = require('../public/qr.js');
(async () => {
  const a = qr('http://192.168.1.20:8080/join?k=abc'); assert.ok(a.size === 29 && a.get(0, 0) && a.get(6, 6) && !a.get(7, 7) && a.get(8, a.size - 8), 'finder + dark module');
  for (let i = 8; i < a.size - 8; i++) assert.strictEqual(a.get(i, 6), i % 2 === 0, 'timing pattern');
  assert.strictEqual(qr('x'.repeat(400)).version, 15); assert.throws(() => qr('x'.repeat(500)), /too long/);
  ok('QR: version picked by length (v3 for a join link, v15 at 400 bytes), finder / timing / dark module in place; decoding is checked in tests/audience_check.py');

  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxa-'));
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8961, OSC_PORT: 8962, DATA_DIR: DATA, MEDIA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'pxam-')), PIN: '4321' }, stdio: 'ignore' }); kids.push(srv);
  const B = 'http://127.0.0.1:8961'; for (let i = 0; i < 80 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const op = (p, body) => fetch(B + p + (p.includes('?') ? '&' : '?') + 'pin=4321', body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : {}).then(r => r.json());
  const cmd = x => op('/api/cmd', x);
  let adm = await op('/api/audience'); const K = adm.key; assert.ok(/\/join\?k=/.test(adm.url));
  const phone = (d, ip) => ({ get: () => fetch(`${B}/api/join/info?k=${K}&d=${d}`).then(async r => ({ ...(await r.json()), http: r.status })),
    post: (p, body, key) => fetch(`${B}/api/join/${p}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ k: key || K, d, ...body }) }).then(async r => ({ ...(await r.json()), http: r.status })) });
  const p1 = phone('ph1'), p2 = phone('ph2'), p3 = phone('ph3');
  assert.strictEqual((await fetch(B + '/api/audience').then(r => r.status)), 401, 'operator view needs the PIN');
  assert.strictEqual((await fetch(`${B}/api/join/info?k=wrong&d=x`)).status, 403); assert.ok((await p1.get()).off, 'closed while audience is off');
  assert.ok((await fetch(B + '/join?k=' + K).then(r => r.text())).includes('Join in'), 'phone page served without the PIN');
  ok('phones use the join key (no PIN); a wrong key is refused; nothing to join while it is off');

  await cmd({ op: 'set', path: 'audience.on', value: true }); await cmd({ op: 'set', path: 'audience.poll', value: { question: 'Next song?', options: ['Rock', 'Pop', 'Jazz', ''] } });
  let i1 = await p1.get(); assert.strictEqual(i1.poll.options.length, 3); assert.strictEqual(i1.poll.open, false);
  assert.strictEqual((await p1.post('vote', { choice: 0 })).http, 409, 'closed poll');
  await cmd({ op: 'set', path: 'audience.pollOpen', value: true });
  await p1.post('vote', { choice: 0 }); await p2.post('vote', { choice: 0 }); i1 = await p3.post('vote', { choice: 1 }); await p1.post('vote', { choice: 1 }); // ph1 changes its mind
  assert.strictEqual((await p1.post('vote', { choice: 3 })).http, 400, 'empty answer'); assert.strictEqual((await p1.post('vote', { choice: 1, pollId: 'old' })).http, 409, 'stale poll');
  adm = await op('/api/audience'); assert.deepStrictEqual(adm.tally.list.map(o => o.votes), [1, 2, 0]); assert.strictEqual(adm.tally.total, 3); assert.deepStrictEqual(adm.tally.list.map(o => o.pct), [33, 67, 0]);
  i1 = await p1.get(); assert.strictEqual(i1.poll.mine, 1); assert.strictEqual(i1.poll.results.total, 3);
  ok('poll: closed until opened, one vote per phone (changeable), empty / stale answers refused, live tally 33 % / 67 %');
  await op('/api/audience', { action: 'pollReset' }); adm = await op('/api/audience'); assert.strictEqual(adm.tally.total, 0); assert.strictEqual((await p1.get()).poll.mine, null);
  ok('new poll clears the votes; phones can vote again');

  await cmd({ op: 'set', path: 'audience.blockWords', value: 'badword, spam' });
  let r = await p1.post('ask', { text: 'How long is the set?', name: 'Sam' }); assert.strictEqual(r.http, 200); assert.strictEqual(r.status, 'pending');
  assert.strictEqual((await p1.post('ask', { text: 'second too soon' })).http, 429, 'rate limit');
  r = await p2.post('ask', { text: 'this is BADWORD stuff' }); assert.strictEqual(r.http, 200); assert.strictEqual(r.status, 'pending', 'a held post looks pending to the phone');
  await p3.post('ask', { text: 'Encore?' }); assert.strictEqual((await p3.post('ask', { text: 'again?' })).http, 429);
  adm = await op('/api/audience'); const [qSam, qBad, qEnc] = adm.qa; assert.strictEqual(qSam.status, 'pending'); assert.strictEqual(qBad.status, 'hidden'); assert.strictEqual(qEnc.status, 'pending');
  assert.strictEqual((await p1.get()).questions.length, 0, 'nothing public before approval');
  await op('/api/audience', { action: 'status', what: 'qa', id: qSam.id, status: 'approved' }); await op('/api/audience', { action: 'status', what: 'qa', id: qEnc.id, status: 'approved' });
  await p1.post('up', { id: qEnc.id }); await p2.post('up', { id: qEnc.id }); await p2.post('up', { id: qEnc.id }); /* p2 takes it back */ await p3.post('up', { id: qEnc.id });
  const qs = (await p1.get()).questions; assert.deepStrictEqual(qs.map(q => [q.text, q.up]), [['Encore?', 2], ['How long is the set?', 0]]); assert.ok(qs[0].mine);
  await op('/api/audience', { action: 'status', what: 'qa', id: qSam.id, status: 'live' }); await op('/api/audience', { action: 'status', what: 'qa', id: qEnc.id, status: 'live' });
  adm = await op('/api/audience'); assert.deepStrictEqual(adm.qa.map(q => q.status), ['done', 'hidden', 'live'], 'one question on screen at a time');
  ok('Q&A: waits for approval, block words held back silently, rate limited, upvotes (toggle) sort the list, one question on screen');

  await cmd({ op: 'set', path: 'audience.moderate', value: false }); await tick(8100);
  r = await p1.post('post', { text: 'Best night ever!', name: 'Jo' }); assert.strictEqual(r.http, 200); assert.strictEqual(r.status, 'approved');
  adm = await op('/api/audience'); assert.strictEqual(adm.wall[0].status, 'approved', 'no moderation → straight on');
  await cmd({ op: 'set', path: 'audience.allowNames', value: false }); await p2.post('post', { text: 'hello  ‮ there\u0007', name: 'Should not show' });
  adm = await op('/api/audience'); assert.strictEqual(adm.wall[1].name, ''); assert.strictEqual(adm.wall[1].text, 'hello there');
  ok('wall: unmoderated posts go straight up, names can be switched off, control characters stripped');

  // the feed the outputs draw
  const ws = new WebSocket(B.replace('http', 'ws') + '/ws?role=output&pin=4321'); let feedMsg = null; ws.onmessage = e => { if (typeof e.data === 'string') { const m = JSON.parse(e.data); if (m.t === 'feeds' && m.values.audience) feedMsg = m.values.audience; } };
  await new Promise(r => ws.onopen = r); await cmd({ op: 'set', path: 'audience.title', value: 'Vote now' }); await tick(900);
  assert.ok(feedMsg && feedMsg.title === 'Vote now' && feedMsg.url.includes('k=' + K) && feedMsg.qa.text === 'Encore?' && feedMsg.wall.length === 2 && feedMsg.wall[0].text === 'hello there' && feedMsg.poll.question === 'Next song?', JSON.stringify(feedMsg));
  ws.close(); ok('outputs get the "audience" feed: title, join link, poll, the question on screen, the wall');

  await cmd({ op: 'set', path: 'audience.publicUrl', value: 'https://vote.example.com/' }); await tick(400); adm = await op('/api/audience'); assert.strictEqual(adm.url, 'https://vote.example.com/join?k=' + K);
  adm = await op('/api/audience', { action: 'newKey' }); assert.notStrictEqual(adm.key, K); assert.strictEqual((await p1.get()).http, 403);
  ok('a public address replaces the LAN link; a new join link locks out the old QR code');
  console.log('Audience test passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
