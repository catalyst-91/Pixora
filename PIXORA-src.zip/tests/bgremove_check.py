# AI background removal in real Chrome, with a stand-in segmenter (the MediaPipe model is bundled only in desktop builds):
# without the model the clip plays untouched and reports "unavailable"; with a mask, "remove" shows the layer below,
# "colour" replaces, "blur" softens, "invert" keeps the background instead.
#   python3 tests/bgremove_check.py [path-to-chrome]
import json, urllib.request, subprocess, os, time, sys, tempfile, signal
from playwright.sync_api import sync_playwright
from PIL import Image
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); CHROME = sys.argv[1] if len(sys.argv) > 1 else '/usr/bin/google-chrome'
B = 'http://127.0.0.1:8997'; tmp = tempfile.mkdtemp(); os.makedirs(tmp + '/m'); SHOT = os.environ.get('PX_SHOT_DIR', tmp)
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=red:s=160x180:r=30:d=6', '-f', 'lavfi', '-i', 'color=c=blue:s=160x180:r=30:d=6', '-filter_complex', 'hstack', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', tmp + '/m/person.mp4'], check=True)
srv = subprocess.Popen(['node', 'server.js'], cwd=ROOT, env=dict(os.environ, PORT='8997', OSC_PORT='8998', DATA_DIR=tmp + '/d', MEDIA_DIR=tmp + '/m'), stdout=open(tmp + '/log', 'w'), stderr=subprocess.STDOUT)
def cmd(b): return json.loads(urllib.request.urlopen(urllib.request.Request(B + '/api/cmd', data=json.dumps(b).encode(), headers={'Content-Type': 'application/json'})).read() or b'{}')
for _ in range(60):
  try: urllib.request.urlopen(B + '/api/info'); break
  except Exception: time.sleep(0.2)
ok = lambda m: print('✓ ' + m)
try:
  for k, v in [('comp.width', 320), ('comp.height', 180)]: cmd({'op': 'set', 'path': k, 'value': v})
  cmd({'op': 'assign', 'layer': 0, 'slot': 0, 'clip': {'type': 'gen', 'name': 'green', 'gen': {'kind': 'solid', 'params': {'c1': '#00ff00'}}}}); cmd({'op': 'trigger', 'layer': 0, 'clip': 0})
  cmd({'op': 'assign', 'layer': 1, 'slot': 0, 'clip': {'type': 'video', 'name': 'Person', 'src': 'local/person.mp4', 'loop': True, 'fit': 'stretch'}}); cmd({'op': 'trigger', 'layer': 1, 'clip': 0})
  def bgr(**kw): cmd({'op': 'set', 'path': 'layers.1.clips.0.bgr', 'value': dict({'on': True, 'mode': 'remove', 'threshold': 0.5, 'softness': 0.05, 'blur': 6, 'color': '#ffff00', 'invert': False}, **kw)}); time.sleep(0.8)
  with sync_playwright() as p:
    b = p.chromium.launch(executable_path=CHROME, args=['--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--autoplay-policy=no-user-gesture-required']); pg = b.new_page(viewport={'width': 320, 'height': 180}); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(B + '/clean?out=main&fs=0'); time.sleep(1); pg.mouse.click(160, 90); time.sleep(2)
    def px():
      pg.screenshot(path=SHOT + '/bgr.png'); im = Image.open(SHOT + '/bgr.png').convert('RGB'); return im.getpixel((60, 90)), im.getpixel((260, 90))
    bgr(); L, R = px(); st = pg.evaluate("() => PixoraSeg.status")
    assert st == 'unavailable' and L[0] > 200 and R[2] > 200, (st, L, R); ok(f'no model installed: status “{st}”, the clip plays untouched {L} {R}')
    pg.evaluate("""() => { PixoraSeg.provider = (el, w, h) => { const mw = 64, mh = 36, d = new Uint8Array(mw * mh); for (let y = 0; y < mh; y++) for (let x = 0; x < mw; x++) d[y * mw + x] = x < mw / 2 ? 255 : 0; return { data: d, w: mw, h: mh }; }; }""")
    time.sleep(0.8); L, R = px(); assert L[0] > 200 and L[1] < 60 and R[1] > 200 and R[0] < 60 and R[2] < 60, (L, R); ok(f'remove: the person (left) stays {L}, the background shows the layer below {R}')
    bgr(mode='color'); L, R = px(); assert L[0] > 200 and L[1] < 60 and R[0] > 200 and R[1] > 200 and R[2] < 60, (L, R); ok(f'solid colour behind the person {R}')
    bgr(mode='blur'); L, R = px(); assert L[0] > 200 and R[2] > 200 and R[0] < 60, (L, R); ok(f'blur keeps the background, softened {R}')
    bgr(invert=True); L, R = px(); assert L[1] > 200 and L[0] < 60 and R[2] > 200, (L, R); ok(f'invert keeps the background and drops the person {L} {R}')
    bgr(); pg.evaluate("() => { PixoraSeg.provider = () => { const mw = 64, mh = 36, d = new Uint8Array(mw * mh); for (let y = 0; y < mh / 2; y++) for (let x = 0; x < mw; x++) d[y * mw + x] = 255; return { data: d, w: mw, h: mh }; }; }"); time.sleep(0.8)
    pg.screenshot(path=SHOT + '/bgr.png'); im = Image.open(SHOT + '/bgr.png').convert('RGB'); top, bot = im.getpixel((60, 30)), im.getpixel((60, 150))
    assert top[0] > 200 and top[1] < 60 and bot[1] > 200 and bot[0] < 60, (top, bot); ok('mask rows line up with the picture (top of the mask = top of the frame)')
    cmd({'op': 'set', 'path': 'layers.1.clips.0.bgr.on', 'value': False}); time.sleep(0.8); L, R = px(); assert L[0] > 200 and R[2] > 200, (L, R); ok('off: back to the plain clip')
    assert not errs, errs; b.close()
  print('Background removal check passed')
finally: srv.send_signal(signal.SIGTERM)
