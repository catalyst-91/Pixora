# PIXORA integration tests

| Test | Run | What it checks |
|---|---|---|
| `desktop_harness.js` | `node tests/desktop_harness.js` | Desktop app (`main.js`, `preload.js`) against mocked Electron + grandi |
| `companion_harness.js` | start PIXORA on 8811, then `PX_PORT=8811 node tests/companion_harness.js` (add `PX_PIN_PORT=` for a PIN-protected server with PIN 4321) | Companion module actions, feedbacks, variables, presets, reconnect and PIN handling against a live server |
| `gdtf_check.py` | `curl -o p.gdtf localhost:8080/api/gdtf && python3 tests/gdtf_check.py p.gdtf` (needs `lxml`) | GDTF structure, references and DMX offsets |
| `temp_test.js` | `node tests/temp_test.js` | Windows / macOS CPU temperature parsing with stubbed system commands |
