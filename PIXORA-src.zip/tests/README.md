# PIXORA integration tests

Run them all with `node tests/run-all.js` (or `node tests/run-all.js ma3 stream` for some). Every GitHub build runs this first and stops if anything fails. Tests that need extra things skip themselves when they're missing.

| Test | Run | What it checks |
|---|---|---|
| `atem_test.js`, `devices_test.js` | `node tests/…` | ATEM protocol and the Blackmagic / BirdDog / Panasonic / VISCA / NDI PTZ drivers against simulated devices |
| `tcnet_test.js`, `prodjlink_test.js` | `node tests/…` | Pioneer DJ Link: TCNet bridge and direct Pro DJ Link (virtual CDJ, beats, metadata), deck-follow |
| `link_test.js` | `PIXORA_CARABINER=/path/Carabiner node tests/link_test.js` (skips without it) | Ableton Link peers, tempo both ways, bar phase |
| `playlist_test.js`, `production_test.js`, `stream_test.js`, `rec_test.js` | `node tests/…` | Playlists, switcher / overlays / timers / guests, streaming (needs ffmpeg), recording |
| `qforge_test.js`, `qforge_e2e_test.js` | `QFORGE_DIR=/path/to/qforge node tests/qforge_e2e_test.js` (skips without it) | QForge feedback, and QForge's OSC encoder ⇄ PIXORA over real UDP |
| `ma3_test.js` | `node tests/ma3_test.js` | grandMA3 package (GDTF, plugin, SendOSC macros, thumbnails) and the "grandMA3 command" action |
| `desktop_updater_test.js`, `desktop_crash_test.js` | `node tests/…` | GitHub-release updater (installer picking, versions, checksums), crash reports (what's removed, issue link, asking) |
| `pro3_test.js`, `update_test.js`, `hap_test.js`, `temp_test.js`, `desktop_native_test.js` | `node tests/…` | Roles, reports, preflight, sync, timecode; feed updates; HAP; temperatures; desktop menus and dialogs |
| `desktop_decklink_test.js` | see the file header (needs the DeckLink module and a fake driver) | DeckLink in / out from the desktop app |
| `desktop_harness.js` | `node tests/desktop_harness.js` | Desktop app (`main.js`, `preload.js`) against mocked Electron + grandi |
| `companion_harness.js` | start PIXORA on 8811, then `PX_PORT=8811 node tests/companion_harness.js` (add `PX_PIN_PORT=` for a PIN-protected server with PIN 4321) | Companion module actions, feedbacks, variables, presets, reconnect and PIN handling against a live server |
| `gdtf_check.py` | `curl -o p.gdtf localhost:8080/api/gdtf && python3 tests/gdtf_check.py p.gdtf` (needs `lxml`) | GDTF structure, references and DMX offsets |
| `temp_test.js` | `node tests/temp_test.js` | Windows / macOS CPU temperature parsing with stubbed system commands |
