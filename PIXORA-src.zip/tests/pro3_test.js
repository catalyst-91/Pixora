// PIXORA v1.2 server feature tests. Starts its own server on a temp data dir.
// node tests/pro3_test.js   (needs ffmpeg for the optimise test; pdftotext optional)
const { spawn, spawnSync, execFileSync } = require('child_process');
const path = require('path'), fs = require('fs'), os = require('os'), dgram = require('dgram'), net = require('net'), http = require('http'), zlib = require('zlib'), crypto = require('crypto'), assert = require('assert');
const ROOT = path.join(__dirname, '..'), PORT = 8821, B = `http://127.0.0.1:${PORT}`;
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'px12-'));
const tick = ms => new Promise(r => setTimeout(r, ms));
let cookie = '';
const api = async (p, opt = {}) => { const r = await fetch(B + p, { ...opt, headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}), ...(opt.headers || {}) }, body: opt.body && typeof opt.body !== 'string' && !Buffer.isBuffer(opt.body) ? JSON.stringify(opt.body) : opt.body }); const ct = r.headers.get('content-type') || ''; return { status: r.status, headers: r.headers, body: ct.includes('json') ? await r.json() : Buffer.from(await r.arrayBuffer()) }; };
const cmd = c => api('/api/cmd', { method: 'POST', body: c });
function zip(files) { // tiny stored zip writer
  const parts = [], central = []; let off = 0;
  for (const [name, data0] of Object.entries(files)) { const data = Buffer.from(data0); const nb = Buffer.from(name); const crc = zlib.crc32 ? zlib.crc32(data) : 0; const def = zlib.deflateRawSync(data);
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(8, 8); lh.writeUInt32LE(crc >>> 0, 14); lh.writeUInt32LE(def.length, 18); lh.writeUInt32LE(data.length, 22); lh.writeUInt16LE(nb.length, 26);
    const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(8, 10); ch.writeUInt32LE(crc >>> 0, 16); ch.writeUInt32LE(def.length, 20); ch.writeUInt32LE(data.length, 24); ch.writeUInt16LE(nb.length, 28); ch.writeUInt32LE(off, 42);
    parts.push(lh, nb, def); central.push(ch, nb); off += 30 + nb.length + def.length; }
  const cd = Buffer.concat(central); const end = Buffer.alloc(22); end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(Object.keys(files).length, 8); end.writeUInt16LE(Object.keys(files).length, 10); end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(off, 16);
  return Buffer.concat([...parts, cd, end]);
}
function glb(min, max) { const j = JSON.stringify({ asset: { version: '2.0' }, meshes: [{ primitives: [{ attributes: { POSITION: 0 } }] }], accessors: [{ min, max, count: 3, type: 'VEC3', componentType: 5126 }] }); const jb = Buffer.from(j + ' '.repeat((4 - j.length % 4) % 4)); const h = Buffer.alloc(20); h.write('glTF', 0); h.writeUInt32LE(2, 4); h.writeUInt32LE(20 + jb.length, 8); h.writeUInt32LE(jb.length, 12); h.write('JSON', 16); return Buffer.concat([h, jb]); }
// CITP helpers (client side)
const ucs2 = s => Buffer.from(s + '\0', 'utf16le');
function citpPkt(type, ver, body) { const layer = Buffer.concat([Buffer.from([ver[0], ver[1]]), Buffer.from(type, 'latin1'), body]); const h = Buffer.alloc(20); h.write('CITP', 0, 'latin1'); h[4] = 1; h.writeUInt32LE(20 + layer.length, 8); h.writeUInt16LE(1, 12); h.write('MSEX', 16, 'latin1'); return Buffer.concat([h, layer]); }
function readUcs2(b, o) { let e = o; while (e + 1 < b.length && (b[e] || b[e + 1])) e += 2; return [b.toString('utf16le', o, e), e + 2]; }

let srv;
(async () => {
  srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT, OSC_PORT: 7021, DATA_DIR: DATA }, stdio: ['ignore', 'pipe', 'pipe'] });
  let log = ''; srv.stdout.on('data', d => log += d); srv.stderr.on('data', d => log += d);
  for (let i = 0; i < 40 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const ok = m => console.log('✓ ' + m);

  /* ---- library + HAP + preflight */
  await api('/api/library?refresh=1');
  const hap = (await api('/api/hap')).body; const lib = (await api('/api/library')).body.sources.flatMap(s => s.items);
  if (Object.keys(hap).length) { assert.strictEqual(hap['local/_t/hapq.mov'], 'HapY'); ok('HAP detection: ' + Object.entries(hap).map(([k, v]) => path.basename(k) + '=' + v).join(', ')); }
  const vid = lib.find(i => /lowres25|Automata/.test(i.name)) || lib.find(i => i.kind === 'video');
  await cmd([{ op: 'assign', layer: 0, slot: 0, clip: { type: 'video', src: vid.src, name: 'Opener' } }, { op: 'assign', layer: 0, slot: 1, clip: { type: 'video', src: vid.src, name: 'Second' } }, { op: 'set', path: 'comp.fps', value: 60 }]);
  const pf = (await api('/api/preflight')).body; assert.ok(pf.items.length > 0 && pf.summary); ok(`preflight: ${pf.summary.total} items, ${pf.summary.flagged} flagged, target ${pf.target.w}×${pf.target.h}`);

  /* ---- optimise (ffmpeg) with relink */
  const lr = lib.find(i => /lowres25/.test(i.name));
  if (lr && spawnSync('ffmpeg', ['-version']).status === 0) {
    await cmd({ op: 'assign', layer: 1, slot: 0, clip: { type: 'video', src: lr.src, name: 'Low res' } });
    await api('/api/optimise', { method: 'POST', body: { keys: [lr.src], w: 320, h: 180, fps: 30 } });
    let j; for (let i = 0; i < 100; i++) { j = (await api('/api/optjobs')).body.jobs.find(x => x.src === lr.src); if (j && (j.status === 'done' || j.status === 'error')) break; await tick(200); }
    assert.strictEqual(j.status, 'done', j.err); const s = (await api('/api/state')).body; assert.strictEqual(s.layers[1].clips[0].src, j.newSrc);
    const out = path.join(ROOT, 'media', 'Optimised', path.basename(j.newSrc)); const pr = execFileSync('ffprobe', ['-v', 'error', '-show_entries', 'stream=width,height,r_frame_rate', '-of', 'csv=p=0', out]).toString().trim().split('\n')[0];
    ok(`optimise → ${j.newSrc} (${pr}), clip relinked`); fs.rmSync(path.join(ROOT, 'media', 'Optimised'), { recursive: true, force: true });
  }

  /* ---- show lock */
  await cmd({ op: 'lockShow', pin: '2468' });
  let r = await cmd({ op: 'set', path: 'comp.width', value: 1000 }); assert.ok(r.status >= 400 || (r.body && r.body.error), 'edit blocked');
  r = await cmd({ op: 'trigger', layer: 0, clip: 1 }); let s = (await api('/api/state')).body; assert.strictEqual(s.layers[0].active, 1); assert.notStrictEqual(s.comp.width, 1000);
  r = await cmd({ op: 'unlockShow', pin: 'nope' }); s = (await api('/api/state')).body; assert.strictEqual(s.show.lock, true);
  await cmd({ op: 'unlockShow', pin: '2468' }); s = (await api('/api/state')).body; assert.strictEqual(s.show.lock, false); ok('show lock: edits refused, playback allowed, wrong PIN refused, unlock works');

  /* ---- Art-Net timecode in (OpTimeCode) */
  await cmd([{ op: 'set', path: 'comp.timecode.source', value: 'artnet' }, { op: 'set', path: 'comp.timecode.fps', value: 25 }, { op: 'cueAdd' }].filter(Boolean));
  const u = dgram.createSocket('udp4'); const tcp = (h, m, s2, f) => { const b = Buffer.alloc(19); b.write('Art-Net\0', 0, 'latin1'); b.writeUInt16LE(0x9700, 8); b[11] = 14; b[14] = f; b[15] = s2; b[16] = m; b[17] = h; b[18] = 1; return b; };
  const ws = new WebSocket(`ws://127.0.0.1:${PORT}/ws?role=control`); const got = []; ws.onmessage = e => { try { const m = JSON.parse(e.data); if (m.t === 'tc') got.push(m); } catch {} };
  await new Promise(r => ws.onopen = r);
  for (let f = 0; f < 10; f++) { u.send(tcp(1, 2, 3, f), 6454, '127.0.0.1'); await tick(40); }
  await tick(200); const last = got[got.length - 1]; assert.ok(last && last.source === 'artnet', 'tc broadcast'); assert.strictEqual(last.frames, ((1 * 60 + 2) * 60 + 3) * 25 + 9); ok(`Art-Net timecode in → 01:02:03:09 (${last.frames} frames)`);

  /* ---- Art-Net timecode out */
  const rx = dgram.createSocket({ type: 'udp4', reuseAddr: true }); const outs = []; rx.on('message', b => { if (b.readUInt16LE(8) === 0x9700) outs.push(b); });
  await new Promise(r => rx.bind(16454, r));
  // point the generator at our test port by sending to localhost: patch artnetDest + use internal clock
  await cmd([{ op: 'set', path: 'comp.timecode.source', value: 'internal' }, { op: 'tcReset', frames: 25 * 3600 }, { op: 'tcStart' }]);
  const ctl = dgram.createSocket({ type: 'udp4', reuseAddr: true }); // the server sends to port 6454; listen there too
  const outs2 = []; ctl.on('message', b => { if (b.length === 19 && b.readUInt16LE(8) === 0x9700) outs2.push(b); }); ctl.on('error', () => {});
  await new Promise(r => ctl.bind(6454, r)); try { ctl.setBroadcast(true); } catch {}
  await cmd({ op: 'set', path: 'comp.timecode.artnetOut', value: true }); await tick(600);
  if (outs2.length) { const b = outs2[outs2.length - 1]; assert.strictEqual(b[17], 1); ok(`Art-Net timecode out: ${outs2.length} packets in 0.6 s, last ${[b[17], b[16], b[15], b[14]].map(x => String(x).padStart(2, '0')).join(':')} (type ${b[18]})`); }
  else console.log('  (Art-Net TC out sent to broadcast — not receivable in this sandbox)');
  await cmd([{ op: 'set', path: 'comp.timecode.artnetOut', value: false }, { op: 'tcStop' }]); ctl.close(); rx.close();

  /* ---- CITP / MSEX */
  await cmd({ op: 'set', path: 'citp.on', value: true }); await tick(500);
  const ci = (await api('/api/citp')).body; assert.ok(ci.on && ci.port > 0);
  for (const ver of [[1, 2], [1, 1], [1, 0]]) {
    const sock = net.connect(ci.port, '127.0.0.1'); await new Promise(r => sock.on('connect', r));
    const msgs = []; let buf = Buffer.alloc(0);
    sock.on('data', d => { global.__cb = (global.__cb || 0) + d.length; buf = Buffer.concat([buf, d]); while (buf.length >= 20) { const n = buf.readUInt32LE(8); if (buf.length < n) break; msgs.push(buf.subarray(0, n)); buf = buf.subarray(n); } });
    const of = t => msgs.filter(m => m.toString('latin1', 22, 26) === t);
    sock.write(citpPkt('CInf', [1, 2], Buffer.from([1, ver[0], ver[1]]))); await tick(150);
    const sinf = of('SInf')[0]; if (!sinf) console.log('bytes', global.__cb, 'msgs', msgs.map(m => m.toString('latin1', 16, 26)), (await api('/api/citp')).body.log); assert.ok(sinf, 'SInf'); assert.deepStrictEqual([sinf[20], sinf[21]], ver);
    const sb = sinf.subarray(26); let name;
    if (ver[1] >= 2) { const uuid = sb.toString('latin1', 0, 36); assert.match(uuid, /^[0-9a-f-]{36}$/); [name] = readUcs2(sb, 37); } else [name] = readUcs2(sb, 0);
    assert.strictEqual(name, 'PIXORA');
    const libReq = ver[1] >= 2 ? Buffer.concat([Buffer.from([1, 0, 0, 0, 0]), Buffer.from([0, 0])]) : ver[1] === 1 ? Buffer.from([1, 0, 0, 0, 0, 0]) : Buffer.from([1, 0]);
    sock.write(citpPkt('GELI', ver, libReq)); await tick(150);
    const elin = of('ELIn')[0]; assert.ok(elin, 'ELIn'); const eb = elin.subarray(26); const libCount = ver[1] >= 2 ? eb.readUInt16LE(1) : eb[1]; assert.ok(libCount >= 2);
    let o = ver[1] >= 2 ? 3 : 2; const firstLib = ver[1] >= 1 ? eb[o + 1] : eb[o]; o += ver[1] >= 1 ? 4 : 1; if (ver[1] >= 2) o += 4; o += 2; const [lname] = readUcs2(eb, o);
    const ein = ver[1] >= 2 ? Buffer.concat([Buffer.from([1, 1, 1, 0, 0]), Buffer.from([2, 0, 0, 1])]) : ver[1] === 1 ? Buffer.from([1, 1, 1, 0, 0, 2, 0, 1]) : Buffer.from([1, 1, 2, 0, 1]);
    sock.write(citpPkt('GEIn', ver, ein)); await tick(150);
    const mein = of('MEIn')[0]; assert.ok(mein, 'MEIn'); const mb = mein.subarray(26); let mo = ver[1] >= 1 ? 4 : 1; const ecount = ver[1] >= 2 ? mb.readUInt16LE(mo) : mb[mo]; mo += ver[1] >= 2 ? 2 : 1;
    assert.strictEqual(ecount, 2); mo += 1 + (ver[1] >= 2 ? 4 : 0) + 2; const [ename] = readUcs2(mb, mo); assert.strictEqual(ename, 'Opener');
    const libpart = ver[1] >= 1 ? Buffer.from([1, 1, 0, 0]) : Buffer.from([1]);
    const geth = Buffer.concat([Buffer.from('JPEG', 'latin1'), Buffer.from([128, 0, 96, 0, 1, 1]), libpart, ver[1] >= 2 ? Buffer.from([1, 0]) : Buffer.from([1]), Buffer.from([0])]);
    sock.write(citpPkt('GETh', ver, geth)); await tick(250);
    const th = of('EThn')[0]; assert.ok(th, 'EThn'); const tb = th.subarray(26); const toff = 1 + (ver[1] >= 1 ? 4 : 1) + 1; assert.strictEqual(tb.toString('latin1', toff, toff + 4), 'JPEG');
    const jlen = tb.readUInt16LE(toff + 8); const jpg = tb.subarray(toff + 10, toff + 10 + jlen); assert.strictEqual(jpg[0], 0xFF); assert.strictEqual(jpg[1], 0xD8);
    await tick(300); assert.ok(of('LSta').length >= 1, 'LSta');
    ok(`CITP MSEX ${ver.join('.')}: SInf "${name}", ELIn ${libCount} libraries ("${lname}"), MEIn "${ename}", EThn JPEG ${tb.readUInt16LE(toff + 4)}×${tb.readUInt16LE(toff + 6)} (${jlen} B), LSta streaming`);
    sock.destroy();
  }
  await cmd({ op: 'set', path: 'citp.on', value: false });

  /* ---- MVR import */
  const xml = `<?xml version="1.0" encoding="UTF-8"?><GeneralSceneDescription verMajor="1" verMinor="6"><Scene><Layers><Layer name="Stage" uuid="L1"><ChildList>
    <VideoScreen name="Upstage LED" uuid="V1"><Matrix>{1,0,0}{0,1,0}{0,0,1}{0,3000,2500}</Matrix><Geometries><Geometry3D fileName="led_6x3.glb"/></Geometries></VideoScreen>
    <VideoScreen name="SL IMAG" uuid="V2"><Matrix>{0,1,0}{-1,0,0}{0,0,1}{-6000,0,3000}</Matrix><Geometries><Geometry3D fileName="imag"/></Geometries></VideoScreen>
    <Fixture name="Spot 1" uuid="F1"><Matrix>{1,0,0}{0,1,0}{0,0,1}{1000,0,6000}</Matrix><GDTFSpec>Robe@Spiider.gdtf</GDTFSpec><Addresses><Address break="0">101</Address></Addresses></Fixture>
    </ChildList></Layer></Layers></Scene></GeneralSceneDescription>`;
  const mvr = zip({ 'GeneralSceneDescription.xml': xml, 'led_6x3.glb': glb([-3, -0.05, 0], [3, 0.05, 3]), 'imag.glb': glb([-2, -0.1, 0], [2, 0.1, 2.25]) });
  r = await api('/api/mvr', { method: 'POST', body: mvr, headers: { 'Content-Type': 'application/octet-stream' } });
  assert.strictEqual(r.status, 200, JSON.stringify(r.body)); const sc = r.body;
  assert.strictEqual(sc.screens.length, 2); assert.deepStrictEqual([sc.screens[0].wm, sc.screens[0].hm, sc.screens[0].y], [6, 3, 2.5]); assert.strictEqual(sc.screens[1].ry, 90); assert.strictEqual(sc.fixtures.length, 1);
  r = await api('/api/mvr?apply=1&opt=' + encodeURIComponent(JSON.stringify({ panelMm: 500, panelPx: 128 })), { method: 'POST', body: mvr, headers: { 'Content-Type': 'application/octet-stream' } });
  s = (await api('/api/state')).body; const up = s.led.screens.find(x => x.name === 'Upstage LED');
  assert.ok(up); assert.deepStrictEqual([up.cols, up.rows, up.panelW, up.pos3d.y, up.pos3d.z], [12, 6, 128, 2.5, -3]);
  ok(`MVR: ${sc.screens.length} screens (${sc.screens.map(x => `${x.name} ${x.wm}×${x.hm} m`).join(', ')}), ${sc.fixtures.length} fixture; applied → "${up.name}" ${up.cols}×${up.rows} panels at y ${up.pos3d.y} m`);

  /* ---- report PDF */
  r = await api('/api/report?title=Test%20Event'); assert.strictEqual(r.headers.get('content-type'), 'application/pdf'); assert.strictEqual(r.body.toString('latin1', 0, 5), '%PDF-');
  const pf2 = path.join(DATA, 'r.pdf'); fs.writeFileSync(pf2, r.body);
  const txt = spawnSync('pdftotext', [pf2, '-']).stdout?.toString() || ''; if (txt) { assert.match(txt, /Test Event/); assert.match(txt, /Changes made during the show/); }
  const pages = spawnSync('pdfinfo', [pf2]).stdout?.toString().match(/Pages:\s+(\d+)/); ok(`report PDF: ${r.body.length} bytes${pages ? ', ' + pages[1] + ' page(s), text extracts OK' : ''}`);

  /* ---- web proxy (sandboxed, frame-blocking headers removed, scroll script injected) */
  const site = http.createServer((q, rs) => { rs.writeHead(200, { 'Content-Type': 'text/html', 'X-Frame-Options': 'DENY', 'Content-Security-Policy': "frame-ancestors 'none'" }); rs.end('<html><head><title>T</title><meta http-equiv="X-Frame-Options" content="deny"></head><body>Hello site</body></html>'); });
  await new Promise(r2 => site.listen(0, r2));
  r = await fetch(`${B}/webproxy?u=${encodeURIComponent('http://127.0.0.1:' + site.address().port + '/page')}&scroll=40&zoom=1.5&transparent=1`);
  const html = await r.text(); assert.ok(!r.headers.get('x-frame-options')); assert.match(r.headers.get('content-security-policy'), /^sandbox/); assert.match(html, /<base href="http:\/\/127\.0\.0\.1:\d+\/page">/); assert.match(html, /zoom:1\.5/); assert.match(html, /scrollTo/); assert.ok(!/http-equiv="X-Frame-Options"/i.test(html));
  site.close(); ok('web proxy: X-Frame-Options/CSP stripped, sandboxed, base/zoom/scroll/transparent injected');

  /* ---- users, roles, sessions */
  r = await api('/api/users', { method: 'POST', body: { user: 'jay', pass: 'secret12', role: 'operator' } }); assert.strictEqual(r.status, 400); // first must be admin
  r = await api('/api/users', { method: 'POST', body: { user: 'jay', pass: 'secret12', role: 'admin' } }); assert.strictEqual(r.status, 200);
  r = await api('/api/state'); assert.strictEqual(r.status, 401); ok('first admin created → API now requires login');
  r = await api('/api/auth/login', { method: 'POST', body: { user: 'jay', pass: 'wrong' } }); assert.strictEqual(r.status, 401);
  r = await api('/api/auth/login', { method: 'POST', body: { user: 'JAY', pass: 'secret12' } }); assert.strictEqual(r.status, 200); cookie = r.headers.get('set-cookie').split(';')[0];
  assert.strictEqual((await api('/api/state')).status, 200); assert.strictEqual((await api('/api/auth/me')).body.role, 'admin');
  await api('/api/users', { method: 'POST', body: { user: 'client1', pass: 'client12', role: 'client' } }); await api('/api/users', { method: 'POST', body: { user: 'view1', pass: 'viewer12', role: 'viewer' } });
  const adminCookie = cookie;
  cookie = (await api('/api/auth/login', { method: 'POST', body: { user: 'client1', pass: 'client12' } })).headers.get('set-cookie').split(';')[0];
  assert.strictEqual((await api('/api/trigger/1/2', { method: 'POST' })).status !== 403, true, 'client may trigger');
  r = await api('/api/cmd', { method: 'POST', body: { op: 'set', path: 'comp.width', value: 640 } }); assert.strictEqual(r.status, 403);
  const wsC = new WebSocket(`ws://127.0.0.1:${PORT}/ws?role=control`, { headers: { Cookie: cookie } }); const errs = []; wsC.onmessage = e => { const m = JSON.parse(e.data); if (m.t === 'error') errs.push(m.msg); };
  await new Promise((res2, rej) => { wsC.onopen = res2; wsC.onerror = rej; }).catch(() => {});
  if (wsC.readyState === 1) { wsC.send(JSON.stringify({ t: 'cmd', cmd: { op: 'set', path: 'comp.width', value: 640 } })); wsC.send(JSON.stringify({ t: 'cmd', cmd: { op: 'trigger', layer: 0, clip: 0 } })); await tick(300); assert.ok(errs.some(e => /only trigger/.test(e))); s = (await api('/api/state')).body; assert.strictEqual(s.layers[0].active, 0); assert.notStrictEqual(s.comp.width, 640); }
  cookie = (await api('/api/auth/login', { method: 'POST', body: { user: 'view1', pass: 'viewer12' } })).headers.get('set-cookie').split(';')[0];
  assert.strictEqual((await api('/api/trigger/1/1', { method: 'POST' })).status, 403); assert.strictEqual((await api('/api/state')).status, 200);
  cookie = adminCookie; r = await api('/api/users', { method: 'POST', body: { user: 'jay', role: 'viewer' } }); assert.strictEqual(r.status, 400, 'keeps an admin');
  r = await fetch(B + '/api/state?pin=x'); assert.strictEqual(r.status, 401);
  ok('roles: client can trigger but not edit (HTTP + WebSocket), viewer read-only, last admin protected, wrong logins refused');
  r = await api('/api/tunnel', { method: 'POST', body: { on: true } }); console.log('  tunnel resp', r.status, JSON.stringify(r.body)); ok('remote access: ' + (r.body.status === 'error' ? 'refuses cleanly — ' + r.body.err.split('.')[0] : r.body.status));
  await api('/api/tunnel', { method: 'POST', body: { on: false } });

  /* ---- updates: local feed, checksum enforced, files replaced, restart */
  const pkgDir = fs.mkdtempSync(path.join(os.tmpdir(), 'pxupd-'));
  const newPkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'))); const cur = newPkg.version; newPkg.version = '9.9.9';
  const upd = zip({ 'PIXORA/server.js': fs.readFileSync(path.join(ROOT, 'server.js')), 'PIXORA/server-pro3.js': fs.readFileSync(path.join(ROOT, 'server-pro3.js')), 'PIXORA/package.json': JSON.stringify(newPkg), 'PIXORA/public/update-test.txt': 'hello from 9.9.9', 'PIXORA/../evil.txt': 'x' });
  const sha = crypto.createHash('sha256').update(upd).digest('hex');
  let manifest = { version: '9.9.9', url: 'pixora.zip', sha256: 'deadbeef', notes: 'test' };
  const fsrv = http.createServer((q, rs) => { if (q.url.startsWith('/feed.json')) { rs.writeHead(200, { 'Content-Type': 'application/json' }); rs.end(JSON.stringify(manifest)); } else { rs.writeHead(200); rs.end(upd); } }); await new Promise(r2 => fsrv.listen(0, r2));
  // run the update against a scratch COPY of the app so the real tree isn't modified
  console.log('  (update apply is exercised in tests/update_test.js against a scratch copy)');
  await cmd({ op: 'set', path: 'update.feed', value: `http://127.0.0.1:${fsrv.address().port}/feed.json` });
  r = await api('/api/update', { method: 'POST', body: { action: 'check' } }); console.log('  upd', r.status, JSON.stringify(r.body).slice(0,300)); assert.strictEqual(r.body.latest.newer, true); ok(`update check: ${cur} → ${r.body.latest.version} available`);
  fsrv.close(); fs.rmSync(pkgDir, { recursive: true, force: true });

  console.log('\nPRO3 SERVER TESTS PASS'); srv.kill(); fs.rmSync(DATA, { recursive: true, force: true }); process.exit(0);
})().catch(e => { console.error('FAIL', e); try { srv.kill(); } catch {} process.exit(1); });
