// PIXORA ⇄ grandMA3: the USB package (GDTF, plugin, SendOSC macros, thumbnails as images) and the "grandMA3 command" action.
//   node tests/ma3_test.js
const { spawn } = require('child_process'); const path = require('path'), fs = require('fs'), os = require('os'), assert = require('assert'), dgram = require('dgram'), zlib = require('zlib');
const ROOT = path.join(__dirname, '..'); const tick = ms => new Promise(r => setTimeout(r, ms)); const ok = m => console.log('✓ ' + m);
const kids = []; process.on('exit', () => kids.forEach(k => { try { k.kill(); } catch {} }));
function unzip(buf) { // stored or deflated entries, via the central directory
  const out = {}; let e = buf.length - 22; while (e > 0 && buf.readUInt32LE(e) !== 0x06054b50) e--;
  let p = buf.readUInt32LE(e + 16); const n = buf.readUInt16LE(e + 10);
  for (let i = 0; i < n; i++) { const m = buf.readUInt16LE(p + 10), cs = buf.readUInt32LE(p + 20), nl = buf.readUInt16LE(p + 28), xl = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), lo = buf.readUInt32LE(p + 42);
    const name = buf.slice(p + 46, p + 46 + nl).toString(); const ds = lo + 30 + buf.readUInt16LE(lo + 26) + buf.readUInt16LE(lo + 28); const raw = buf.slice(ds, ds + cs);
    out[name] = m === 8 ? zlib.inflateRawSync(raw) : raw; p += 46 + nl + xl + cl; }
  return out;
}
(async () => {
  const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxma3-')), MEDIA = fs.mkdtempSync(path.join(os.tmpdir(), 'pxma3m-'));
  fs.writeFileSync(path.join(MEDIA, 'intro.mp4'), Buffer.alloc(1000));
  const srv = spawn(process.execPath, ['server.js'], { cwd: ROOT, env: { ...process.env, PORT: 8865, OSC_PORT: 8866, DATA_DIR: DATA, MEDIA_DIR: MEDIA }, stdio: 'ignore' }); kids.push(srv);
  const B = 'http://127.0.0.1:8865';
  for (let i = 0; i < 60 && !(await fetch(B + '/api/info').then(r => r.ok).catch(() => false)); i++) await tick(150);
  const cmd = c => fetch(B + '/api/cmd', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(c) });
  const lib = await fetch(B + '/api/library').then(r => r.json()).catch(() => ({}));
  const src = JSON.stringify(lib).match(/"src":"([^"]*intro\.mp4)"/); assert.ok(src, 'media scanned'); const key = src[1];
  await cmd({ op: 'set', path: 'layers.0.clips.0', value: { type: 'video', src: key, name: 'Intro "wide"' } });
  await cmd({ op: 'set', path: 'layers.0.clips.2', value: { type: 'gen', name: 'Logo', gen: { kind: 'solid', params: { c1: '#f00' } } } });
  await cmd({ op: 'set', path: 'layers.1.clips.0', value: { type: 'gen', name: 'Bars', gen: { kind: 'solid', params: { c1: '#00f' } } } });
  const jpg = Buffer.from('/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/wAALCAABAAEBAREA/8QAFAABAAAAAAAAAAAAAAAAAAAACf/EABQQAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQEAAD8AKp//2Q==', 'base64');
  assert.ok((await fetch(B + '/api/thumb?src=' + encodeURIComponent(key), { method: 'POST', body: jpg })).ok, 'thumbnail stored');
  // settings
  let s = await fetch(B + '/api/ma3', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ oscLine: 3, macroStart: 2001, imageStart: 51 }) }).then(r => r.json());
  assert.deepStrictEqual([s.oscLine, s.macroStart, s.imageStart, s.oscIn], [3, 2001, 51, 8866]); ok('MA3 settings saved (OSC line, first macro, first image)');
  // package
  const r = await fetch(B + '/api/ma3/package?oscLine=3&macroStart=2001&imageStart=51'); assert.ok(r.ok);
  const z = unzip(Buffer.from(await r.arrayBuffer())), names = Object.keys(z);
  for (const f of ['gma3_library/fixturetypes/Booth_Productions@PIXORA.gdtf', 'gma3_library/datapools/plugins/PIXORA/PIXORA.xml', 'gma3_library/datapools/plugins/PIXORA/pixora.lua', 'PIXORA-for-grandMA3.txt']) assert.ok(names.includes(f), f);
  assert.ok(unzip(z['gma3_library/fixturetypes/Booth_Productions@PIXORA.gdtf'])['description.xml'], 'GDTF is a valid zip with description.xml'); ok('package has the GDTF, the plugin and a readme');
  const macros = names.filter(n => n.startsWith('gma3_library/datapools/macros/')).sort();
  const mx = n => z[`gma3_library/datapools/macros/PIXORA_${n}.xml`].toString();
  assert.match(mx(2001), /<Macro Name="PIXORA GO">\s*<MacroLine Command="SendOSC 3 &quot;\/pixora\/cue\/go,i,1&quot;"\/>/);
  const all = macros.map(n => z[n].toString()).join('\n');
  assert.match(all, /Name="PX 1\.1 Intro 'wide'"[\s\S]*?SendOSC 3 &quot;\/pixora\/trigger\/1\/1,i,1&quot;/, 'clip macro, quotes made safe');
  assert.match(all, /Name="PX 2\.1 Bars"[\s\S]*?\/pixora\/trigger\/2\/1,i,1/); assert.match(all, /Name="PX Column 3"[\s\S]*?\/pixora\/column\/3,i,1/);
  assert.match(all, /Name="PIXORA Blackout off"[\s\S]*?\/pixora\/blackout,i,0/); assert.match(all, /Name="PX Clear layer 2"[\s\S]*?\/pixora\/clear\/2,i,1/);
  assert.ok(!/Column 2"/.test(all), 'empty columns are skipped');
  for (const n of macros) assert.match(z[n].toString(), /^<\?xml version="1\.0" encoding="UTF-8"\?>\n<GMA3 DataVersion="[\d.]+">\n\t<Macro Name="[^"<>]*">\n\t\t<MacroLine Command="[^"<>]*"\/>\n\t<\/Macro>\n<\/GMA3>\n$/);
  ok(`${macros.length} macros (GO, Back, blackout, clear, columns, every clip, clear per layer) as SendOSC on line 3`);
  const imgs = names.filter(n => n.startsWith('gma3_library/media/images/')); assert.deepStrictEqual(imgs.length, 1); assert.ok(z[imgs[0]].equals(jpg)); ok('clip thumbnail packed as an image');
  const lua = z['gma3_library/datapools/plugins/PIXORA/pixora.lua'].toString();
  assert.match(lua, /img = "PIXORA_\d+\.jpg", imgName = "PIXORA_\d+", imgNum = 51/); assert.match(lua, /Import Image Library "%s" At Image %d \/CreateReferenceObject/); assert.match(lua, /Assign Appearance "%s" At Macro %d/);
  assert.match(lua, /^return main\n$/m); assert.ok(!/[^\\]"[^",}\s]*"[^,\s)}\]]/.test(lua.split('\n').filter(l => l.trim().startsWith('{ num')).join('\n')), 'Lua table strings are closed');
  for (const l of lua.split('\n').filter(l => l.trim().startsWith('{ num'))) assert.strictEqual((l.replace(/\\"/g, '').match(/"/g) || []).length % 2, 0, l);
  const code = lua.split('\n').filter(l => !l.trim().startsWith('--')).join('\n').replace(/"(\\.|[^"\\])*"|'(\\.|[^'\\])*'/g, '""'); const opens = (code.match(/\b(function|if|for)\b/g) || []).length, ends = (code.match(/\bend\b/g) || []).length; assert.strictEqual(opens, ends, 'Lua blocks balanced');
  ok('Lua plugin: imports macros, images with appearances, assigns them; strings and blocks balanced');
  // PIXORA → MA3
  const got = []; const ma = dgram.createSocket('udp4'); ma.on('message', b => got.push(b)); await new Promise(res => ma.bind(8867, '127.0.0.1', res));
  await fetch(B + '/api/ma3', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ host: '127.0.0.1', port: 8867, prefix: '/gma3' }) });
  await cmd({ op: 'runAction', action: { type: 'ma3', cmd: 'Go+ Sequence 1' } }); await tick(200);
  assert.ok(got.length && got[0].toString('latin1').includes('/gma3/cmd') && got[0].toString('latin1').includes(',s') && got[0].toString('latin1').includes('Go+ Sequence 1')); ok('“grandMA3 command” action sends /gma3/cmd "Go+ Sequence 1"');
  await fetch(B + '/api/ma3', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ cmd: 'Off Sequence 1' }) }); await tick(200);
  assert.ok(got[1] && got[1].toString('latin1').includes('Off Sequence 1')); ok('test command from Setup');
  ma.close(); console.log('ma3_test: all passed'); process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
