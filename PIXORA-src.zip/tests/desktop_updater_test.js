// PIXORA desktop updater: picks the right GitHub release file for each computer, compares versions, verifies checksums.
//   node tests/desktop_updater_test.js
const assert = require('assert'), Module = require('module'), path = require('path'), fs = require('fs'), os = require('os'), crypto = require('crypto');
const realLoad = Module._load; Module._load = function (req, ...a) { return req === 'electron' ? { app: { getPath: () => os.tmpdir(), getVersion: () => '1.5.0' }, net: {}, dialog: {}, shell: {}, BrowserWindow: { getAllWindows: () => [] } } : realLoad.call(this, req, ...a); };
const { pickAsset, newer, plainNotes, Updater } = require('../desktop/updater.js');
// the file names of a real PIXORA release (v1.4.2)
const assets = ['PIXORA-1.4.2-linux-x86_64.AppImage', 'PIXORA-1.4.2-mac-arm64.dmg', 'PIXORA-1.4.2-mac-x64.dmg', 'PIXORA-1.4.2-portable.exe', 'PIXORA-Setup-1.4.2.exe', 'carabiner-source.tar.gz'].map(name => ({ name }));
const pick = env => (pickAsset(assets, env) || {}).name;
assert.strictEqual(pick({ platform: 'win32', arch: 'x64', portable: false }), 'PIXORA-Setup-1.4.2.exe');
assert.strictEqual(pick({ platform: 'win32', arch: 'x64', portable: true }), 'PIXORA-1.4.2-portable.exe');
assert.strictEqual(pick({ platform: 'darwin', arch: 'arm64' }), 'PIXORA-1.4.2-mac-arm64.dmg');
assert.strictEqual(pick({ platform: 'darwin', arch: 'x64' }), 'PIXORA-1.4.2-mac-x64.dmg');
assert.strictEqual(pick({ platform: 'darwin', arch: 'x64', rosetta: true }), 'PIXORA-1.4.2-mac-arm64.dmg', 'Intel build on Apple silicon moves to the native build');
assert.strictEqual(pick({ platform: 'linux', arch: 'x64' }), 'PIXORA-1.4.2-linux-x86_64.AppImage');
assert.strictEqual(pick({ platform: 'linux', arch: 'arm64' }), undefined, 'no arm64 AppImage → no update offered');
console.log('✓ picks the right installer for Windows (installed / portable), Mac (Apple silicon / Intel / Rosetta) and Linux');
assert(newer('1.5.1', '1.5.0') && newer('v2.0.0', '1.9.9') && newer('1.10.0', '1.9.0') && !newer('1.5.0', '1.5.0') && !newer('1.4.9', '1.5.0'));
console.log('✓ version comparison');
assert.strictEqual(plainNotes('## Hi\n- **bold** `code` [link](http://x)'), 'Hi\n• bold code link'); console.log('✓ release notes as plain text');
(async () => {
  const u = new Updater({}); const f = path.join(os.tmpdir(), 'pxupd-test.bin'); fs.writeFileSync(f, 'hello');
  const good = 'sha256:' + crypto.createHash('sha256').update('hello').digest('hex');
  assert.strictEqual(await u.verify(f, { digest: good }), true); assert.strictEqual(await u.verify(f, { digest: 'sha256:' + '0'.repeat(64) }), false); assert.strictEqual(await u.verify(f, {}), true);
  console.log('✓ SHA-256 check against GitHub\'s digest'); console.log('desktop_updater_test: all passed');
})().catch(e => { console.error(e); process.exit(1); });
