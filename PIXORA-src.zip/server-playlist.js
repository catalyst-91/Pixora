// PIXORA playlists as one input — Booth Productions.
// A clip of type "playlist" plays a list of media one after another (or shuffled) on its layer, like a single input.
// The list is either kept in the clip, or comes from outside and is re-read when it changes:
//   • a folder in one of PIXORA's media sources (new files appear on the next pass)
//   • an .m3u / .m3u8 / .pls / .txt playlist file (local path inside a media source, or an http(s) URL)
// The server owns the playhead (clip.index), so every output shows the same item; videos advance when the primary
// output reports the end, stills after clip.imageSecs.
'use strict';
const path = require('path'), fs = require('fs'), fsp = fs.promises;
const IMG = /\.(png|jpe?g|gif|webp|bmp|avif|svg)$/i, MEDIA = /\.(mp4|m4v|mov|webm|mkv|avi|mxf|wmv|mpg|mpeg|ts|m2ts|flv|ogv|hap|png|jpe?g|gif|webp|bmp|avif|svg)$/i;

module.exports = function playlists(ctx) { // ctx: { sources: () => [], scanSource, resolveMedia }
  const kindOf = src => IMG.test(src.split('?')[0]) ? 'image' : 'video';
  // absolute path → "sourceId/rel/path" when it sits inside one of the media sources
  function toSrc(abs) {
    const a = path.resolve(abs);
    for (const s of ctx.sources()) { const root = path.resolve(s.path); if (a === root || a.startsWith(root + path.sep)) return s.id + '/' + path.relative(root, a).split(path.sep).join('/'); }
    return null;
  }
  function parseList(text, base) { // M3U / M3U8 / PLS / plain list → [{src, name, dur}]
    const out = []; let title = null, dur = null; const isUrl = /^https?:/i.test(base || '');
    for (let line of String(text).replace(/^﻿/, '').split(/\r?\n/)) {
      line = line.trim(); if (!line) continue;
      const inf = /^#EXTINF:\s*(-?[\d.]+)\s*,?(.*)$/i.exec(line); if (inf) { dur = +inf[1] > 0 ? +inf[1] : null; title = inf[2].trim() || null; continue; }
      const pls = /^File\d+=(.*)$/i.exec(line); if (pls) line = pls[1].trim(); else if (line.startsWith('#') || /^\[playlist\]|^(Title|Length)\d+=|^NumberOfEntries=|^Version=/i.test(line)) continue;
      let src = null, name = title || decodeURIComponent(line.split(/[\\/]/).pop().split('?')[0]);
      if (/^https?:/i.test(line)) src = line;
      else if (/^file:/i.test(line)) src = toSrc(decodeURIComponent(new URL(line).pathname).replace(/^\/([A-Za-z]:)/, '$1'));
      else if (isUrl) src = new URL(line, base).href;
      else { const abs = path.isAbsolute(line) ? line : path.join(base || '.', line.replace(/\\/g, path.sep)); src = fs.existsSync(abs) ? toSrc(abs) : null; } // skip files that aren't there
      if (src && (MEDIA.test(src.split('?')[0]) || /^https?:/i.test(src))) out.push({ src, name, dur, kind: kindOf(src) });
      title = dur = null;
    }
    return out;
  }
  async function resolve(ext) { // → { items, error }
    if (!ext || !ext.path) return { items: [], error: 'no playlist source' };
    try {
      if (ext.kind === 'folder') { // "sourceId/sub/folder"
        const i = ext.path.indexOf('/'), sid = i < 0 ? ext.path : ext.path.slice(0, i), sub = i < 0 ? '' : ext.path.slice(i + 1).replace(/\/+$/, '');
        const src = ctx.sources().find(s => s.id === sid); if (!src) return { items: [], error: 'media source not found: ' + sid };
        const r = await ctx.scanSource(src, true);
        const items = r.items.filter(it => (it.folder || '') === sub || (ext.recursive && (it.folder || '').startsWith(sub ? sub + '/' : ''))).map(it => ({ src: it.src, name: it.name, kind: it.kind }));
        return { items, error: items.length ? '' : 'no media in that folder' };
      }
      let text, base;
      if (/^https?:/i.test(ext.path)) { const r = await fetch(ext.path, { headers: { 'User-Agent': 'PIXORA' }, signal: AbortSignal.timeout(8000) }); if (!r.ok) throw new Error('HTTP ' + r.status); text = await r.text(); base = ext.path; }
      else { const abs = ctx.resolveMedia(ext.path); if (!abs) throw new Error('playlist file must be inside a media source (add its folder as a source)'); text = await fsp.readFile(abs, 'utf8'); base = path.dirname(abs); }
      const items = parseList(text, base); return { items, error: items.length ? '' : 'the playlist has no playable entries' };
    } catch (e) { return { items: [], error: e.message }; }
  }
  // move the playhead; bumping layer.trig makes outputs load the next item and dedupes "ended" from several outputs
  function advance(state, li, dir = 1, now = Date.now()) {
    const L = state.layers[li], c = L && L.active != null && L.clips[L.active]; if (!c || c.type !== 'playlist') return false;
    const n = (c.items || []).length; if (!n) return false;
    let i = c.index || 0;
    if (dir === 'goto') i = 0; else if (c.order === 'shuffle' && n > 1 && dir > 0) { let j; do { j = Math.floor(Math.random() * n); } while (j === i); i = j; }
    else { i += dir; if (i >= n) { if (c.loop === false) { L.paused = false; return false; } i = 0; } if (i < 0) i = n - 1; }
    c.index = i; L.trig = (L.trig || 0) + 1; L.trigAt = now; return true;
  }
  function tick(state, now) { // stills: advance after imageSecs (or the #EXTINF duration)
    let dirty = false;
    state.layers.forEach((L, li) => { const c = L.active != null && L.clips[L.active]; if (!c || c.type !== 'playlist' || L.paused || !(c.items || []).length) return;
      const it = c.items[(c.index || 0) % c.items.length]; if (it.kind !== 'image') return;
      if (now - (L.trigAt || now) >= ((it.dur || c.imageSecs || 8) * 1000)) dirty = advance(state, li, 1, now) || dirty; });
    return dirty;
  }
  return { resolve, parseList, advance, tick, kindOf };
};
