#!/usr/bin/env bash
# PIXORA — Booth Productions  ·  macOS / Linux launcher
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Install Node.js 18+ first (https://nodejs.org)"; exit 1; }
command -v ffmpeg >/dev/null || echo "Tip: install ffmpeg to play AVI/WMV/MPEG-2/ProRes (brew install ffmpeg / sudo apt install ffmpeg)"
export PORT="${PORT:-8080}"
( sleep 1.5; (xdg-open "http://localhost:$PORT/" || open "http://localhost:$PORT/") >/dev/null 2>&1 ) &
exec node server.js
