// PIXORA action outputs — Booth Productions.
//   Send OSC:  any OSC message to any host (a lighting console, QLab, Companion, another PIXORA…)
//   Set DMX:   channels on an Art-Net or sACN universe, optionally faded — hazers, relays, house lights, a console's
//              DMX remote. Values are held and re-sent once a second (nodes drop universes that go quiet).
'use strict';
const dgram = require('dgram'), crypto = require('crypto');
module.exports = function actionsOut(ctx) { // ctx: { oscMsg, sock(), monitor }
  // "1 0.5 hello "two words" true" → typed OSC args
  function parseArgs(str) {
    const out = [], re = /"((?:[^"\\]|\\.)*)"|(\S+)/g; let m;
    while ((m = re.exec(String(str || '')))) {
      if (m[1] != null) { out.push(m[1].replace(/\\"/g, '"')); continue; }
      const t = m[2];
      if (/^-?\d+$/.test(t)) out.push(parseInt(t, 10)); else if (/^-?\d*\.\d+$|^-?\d+\.\d*$/.test(t)) out.push({ type: 'f', value: parseFloat(t) });
      else if (t === 'true' || t === 'false') out.push(t === 'true' ? 1 : 0); else out.push(t);
    }
    return out;
  }
  function osc(a) {
    const host = String(a.host || '127.0.0.1').trim(), port = +a.port || 8000, addr = String(a.address || '').trim();
    if (!/^\//.test(addr)) throw new Error('OSC address must start with /');
    const args = parseArgs(a.args);
    ctx.sock().send(ctx.oscMsg(addr, args), port, host);
    ctx.monitor('osc-out', `→ ${host}:${port} ${addr} ${a.args || ''}`);
  }
  // ---- DMX
  const sock = dgram.createSocket('udp4'); sock.on('error', () => {}); sock.bind(() => { try { sock.setBroadcast(true); sock.setMulticastTTL(4); } catch {} });
  const CID = crypto.randomBytes(16), seq = {}, unis = new Map(); // key "artnet|host|uni" → { proto, host, uni, data, from, to, t0, dur }
  const artDmx = (uni, d) => { const b = Buffer.alloc(530); b.write('Art-Net\0', 0, 'latin1'); b.writeUInt16LE(0x5000, 8); b.writeUInt16BE(14, 10); seq[uni] = ((seq[uni] || 0) % 255) + 1; b[12] = seq[uni]; b[14] = uni & 255; b[15] = (uni >> 8) & 127; b.writeUInt16BE(512, 16); d.copy(b, 18); return b; };
  const sacn = (uni, d) => { const b = Buffer.alloc(638); b.writeUInt16BE(0x0010, 0); b.write('ASC-E1.17', 4, 'latin1'); b.writeUInt16BE(0x7000 | 622, 16); b.writeUInt32BE(4, 18); CID.copy(b, 22);
    b.writeUInt16BE(0x7000 | 600, 38); b.writeUInt32BE(2, 40); b.write('PIXORA actions', 44, 'latin1'); b[108] = 100; seq['s' + uni] = ((seq['s' + uni] || 0) + 1) & 255; b[111] = seq['s' + uni]; b.writeUInt16BE(uni, 113);
    b.writeUInt16BE(0x7000 | 523, 115); b[117] = 2; b[118] = 0xa1; b.writeUInt16BE(1, 121); b.writeUInt16BE(513, 123); d.copy(b, 126); return b; };
  function send(u) {
    if (u.proto === 'sacn') { const su = Math.max(1, u.uni); sock.send(sacn(su, u.data), 5568, u.host && u.host !== '255.255.255.255' ? u.host : `239.255.${(su >> 8) & 255}.${su & 255}`); }
    else sock.send(artDmx(u.uni, u.data), 6454, u.host || '255.255.255.255');
  }
  function dmx(a) {
    const proto = a.protocol === 'sacn' ? 'sacn' : 'artnet', host = String(a.host || '').trim() || (proto === 'sacn' ? '' : '255.255.255.255'), uni = Math.max(0, Math.min(32767, a.universe | 0));
    const ch = Math.max(1, Math.min(512, a.channel | 0 || 1)), vals = String(a.values ?? a.value ?? '').split(/[\s,]+/).filter(Boolean).map(v => Math.max(0, Math.min(255, /%$/.test(v) ? Math.round(parseFloat(v) * 255 / 100) : +v || 0)));
    if (!vals.length) throw new Error('DMX: enter one or more values (0–255, or a %)');
    const key = `${proto}|${host}|${uni}`; let u = unis.get(key);
    if (!u) unis.set(key, u = { proto, host, uni, data: Buffer.alloc(512), fades: [] });
    const dur = Math.max(0, +a.fade || 0) * 1000, now = Date.now();
    vals.forEach((v, i) => { const c = ch - 1 + i; if (c >= 512) return; u.fades = u.fades.filter(f => f.c !== c); if (dur) u.fades.push({ c, from: u.data[c], to: v, t0: now, dur }); else u.data[c] = v; });
    send(u); ctx.monitor('dmx-out', `${proto} ${host || 'multicast'} U${uni} ch ${ch}${vals.length > 1 ? '–' + (ch + vals.length - 1) : ''} → ${vals.join(' ')}${dur ? ` over ${dur / 1000}s` : ''}`);
  }
  setInterval(() => { const now = Date.now(); for (const u of unis.values()) if (u.fades.length) { u.fades = u.fades.filter(f => { const k = Math.min(1, (now - f.t0) / f.dur); u.data[f.c] = Math.round(f.from + (f.to - f.from) * k); return k < 1; }); send(u); } }, 33);
  setInterval(() => { for (const u of unis.values()) if (!u.fades.length) send(u); }, 1000); // keep-alive
  return { osc, dmx, parseArgs, universes: unis };
};
