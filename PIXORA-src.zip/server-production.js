// PIXORA live-production tools — Booth Productions.
//   Switcher: one layer becomes a program bus with a preview, CUT / AUTO and a T-bar (wipes, dip, stinger from layer.transition)
//   Overlays: 4 overlay channels drawn above every layer (titles, logos, lower thirds) toggled on and off with their own fade
//   Timers:   named count-down / count-up / count-to-time clocks shared by every output ({{timer.Name}} in any text)
'use strict';
const OVERLAYS = 4;
function normalize(st) {
  const sw = st.switcher = Object.assign({ on: false, layer: 0, preview: null, tbar: 0 }, st.switcher || {});
  sw.layer = Math.max(0, Math.min((st.layers || []).length - 1, +sw.layer || 0)); sw.tbar = Math.max(0, Math.min(1, +sw.tbar || 0));
  st.overlays = Array.from({ length: OVERLAYS }, (_, i) => Object.assign({ clip: null, on: false, trig: 0, transition: 'fade', dur: 0.5, volume: 1 }, (st.overlays || [])[i] || {}));
  st.timers = (Array.isArray(st.timers) ? st.timers : []).filter(t => t && t.name).map(t => Object.assign({ mode: 'down', secs: 300, until: '', running: false, startedAt: 0, base: 0 }, t));
  st.shortcuts = Array.isArray(st.shortcuts) ? st.shortcuts.filter(s => s && s.key && s.action) : [];
}
// elapsed seconds of a timer at server time `now`
const elapsed = (t, now) => t.base + (t.running ? (now - t.startedAt) / 1000 : 0);

function apply(state, cmd, now, ctx) { // → true if handled & changed
  normalize(state);
  if (cmd.op === 'switcher') {
    const sw = state.switcher, L = state.layers[sw.layer]; if (!L) return false;
    const take = cut => { if (sw.preview == null || !L.clips[sw.preview]) return false; const was = L.active; ctx.trigger(sw.layer, sw.preview); if (cut) L.cutTrig = L.trig; sw.preview = was != null ? was : null; sw.tbar = 0; return true; };
    switch (cmd.a) {
      case 'set': for (const k of ['on', 'layer']) if (k in cmd) sw[k] = k === 'on' ? !!cmd.on : +cmd.layer; if ('layer' in cmd) sw.preview = null; normalize(state); return true;
      case 'preview': sw.preview = cmd.clip == null ? null : +cmd.clip; sw.tbar = 0; return true;
      case 'cut': return take(true);
      case 'auto': return take(false);
      case 'tbar': { const v = Math.max(0, Math.min(1, +cmd.value || 0)); if (v >= 0.999) return take(true); sw.tbar = v; return true; }
      case 'program': { const c = +cmd.clip; if (!L.clips[c]) return false; sw.preview = c; return take(!!cmd.cut); } // straight to air
    }
    return false;
  }
  if (cmd.op === 'overlay') {
    const o = state.overlays[(+cmd.n || 1) - 1]; if (!o) return false;
    switch (cmd.a) {
      case 'set': if ('clip' in cmd) { o.clip = cmd.clip || null; o.trig++; } for (const k of ['transition', 'dur', 'volume']) if (k in cmd) o[k] = cmd[k]; return true;
      case 'on': if (!o.clip) return false; o.on = true; o.trig++; return true;
      case 'off': o.on = false; return true;
      case 'toggle': if (!o.clip) return false; o.on = !o.on; if (o.on) o.trig++; return true;
      case 'allOff': state.overlays.forEach(x => x.on = false); return true;
    }
    return false;
  }
  if (cmd.op === 'timer') {
    const name = String(cmd.name || '').trim(); if (!name) return false;
    let t = state.timers.find(x => x.name.toLowerCase() === name.toLowerCase());
    if (!t) { if (cmd.a === 'delete') return false; t = { name: name.slice(0, 40), mode: 'down', secs: 300, until: '', running: false, startedAt: 0, base: 0 }; state.timers.push(t); }
    switch (cmd.a) {
      case 'set': for (const k of ['mode', 'secs', 'until']) if (k in cmd) t[k] = k === 'secs' ? Math.max(0, +cmd.secs || 0) : String(cmd[k]); if ('name2' in cmd && cmd.name2) t.name = String(cmd.name2).slice(0, 40); return true;
      case 'start': if (!t.running) { t.running = true; t.startedAt = now; } return true;
      case 'stop': if (t.running) { t.base = elapsed(t, now); t.running = false; } return true;
      case 'toggle': if (t.running) { t.base = elapsed(t, now); t.running = false; } else { t.running = true; t.startedAt = now; } return true;
      case 'reset': t.base = 0; t.startedAt = now; if (cmd.start) t.running = true; return true;
      case 'add': t.base -= (+cmd.secs || 0) * (t.mode === 'up' ? -1 : 1); return true; // +30 s on a countdown
      case 'delete': state.timers = state.timers.filter(x => x !== t); return true;
    }
    return false;
  }
  if (cmd.op === 'shortcuts') { state.shortcuts = (cmd.list || []).filter(s => s && s.key && s.action).slice(0, 200); return true; }
  return false;
}
module.exports = { normalize, apply, elapsed, OVERLAYS };
