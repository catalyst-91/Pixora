// PIXORA LED processor setup pack — Booth Productions.
// Processor configuration files (Novastar .scr / .rcfgx / .ncp, Brompton Tessera projects, HELIOS configurations) are
// proprietary, so PIXORA exports what you need to set the processor up quickly and correctly in its own software:
//   README.txt            how to enter the layout in NovaLCT / VMP, Tessera, HELIOS, Colorlight
//   setup-sheet.html      printable: every screen, its cabinets, cabling order and port per cabinet, port loads
//   screens.csv           one row per screen: output raster position and size, cabinet size and count, chain
//   cabinets.csv          one row per cabinet: screen, column/row, output-raster x/y, port, position on the port
//   ports.csv             one row per processor port: screen, cabinet count, pixels, load
//   layout.json           all of the above, for scripts
//   <screen>-cabling.svg  per-screen cabling diagram (port colours, arrows, numbers)
//   overview.svg          the whole output raster with every screen
// Port planning: cabinets follow the screen's data chain (snake / rows / columns, start corner) and a new port starts
// when the next cabinet would pass the port's pixel capacity (from the selected processor) or the cabinet limit.
'use strict';
module.exports = function ledSetup(ctx) { // ctx: { state (getter), S (schema), makeZip }
  const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const csv = rows => rows.map(r => r.map(v => { const s = String(v == null ? '' : v); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }).join(',')).join('\r\n') + '\r\n';
  const PORT_COLORS = ['#ff2fd0', '#2fe0d0', '#ffd23f', '#6b8bff', '#ff7a3d', '#7dff6b', '#c48bff', '#ff4d6d', '#3dd5ff', '#ffb3e6'];
  function chainOrder(sc) { // same order as the renderer's "Data chain" test pattern
    const C = Math.max(1, sc.cols | 0), R = Math.max(1, sc.rows | 0), out = [];
    const byCols = /cols/.test(sc.chain || ''), snake = /snake/.test(sc.chain || 'snake'), st = sc.start || 'bl', fromRight = st[1] === 'r', fromBottom = st[0] === 'b';
    const outer = byCols ? C : R, inner = byCols ? R : C;
    for (let a = 0; a < outer; a++) for (let b0 = 0; b0 < inner; b0++) { const b = snake && a % 2 ? inner - 1 - b0 : b0; let c = byCols ? a : b, r = byCols ? b : a; if (fromRight) c = C - 1 - c; if (fromBottom) r = R - 1 - r; out.push([c, r]); }
    return out;
  }
  function plan(opts = {}) {
    const st = ctx.state, proc = ctx.S.LED_PROCESSORS.find(p => p.id === (opts.processor || st.led.processor)) || null;
    const perPort = Math.max(1, +opts.perPort || (proc && proc.perPort) || 650000), maxCab = Math.max(0, +opts.maxCabinets || 0);
    const screens = [], cabinets = [], ports = []; let port = 0;
    for (const sc of st.led.screens || []) {
      const pw = sc.panelW | 0, ph = sc.panelH | 0, ox = (sc.outX ?? sc.x) | 0, oy = (sc.outY ?? sc.y) | 0, order = chainOrder(sc);
      let cur = null; const first = port + 1;
      order.forEach(([c, r], i) => {
        const px = pw * ph;
        if (!cur || cur.pixels + px > perPort || (maxCab && cur.cabinets >= maxCab)) { cur = { port: ++port, screen: sc.name, screenId: sc.id, cabinets: 0, pixels: 0 }; ports.push(cur); }
        cur.cabinets++; cur.pixels += px;
        cabinets.push({ screen: sc.name, screenId: sc.id, col: c + 1, row: r + 1, x: ox + c * pw, y: oy + r * ph, w: pw, h: ph, mmX: c * (sc.panelMmW || 0), mmY: r * (sc.panelMmH || 0), port: cur.port, onPort: cur.cabinets, chainIndex: i + 1 });
      });
      screens.push({ id: sc.id, name: sc.name, x: ox, y: oy, w: pw * (sc.cols | 0), h: ph * (sc.rows | 0), cabinetW: pw, cabinetH: ph, cols: sc.cols | 0, rows: sc.rows | 0, cabinetMmW: sc.panelMmW || 0, cabinetMmH: sc.panelMmH || 0, chain: sc.chain || 'snake-rows', start: sc.start || 'bl', rotation: sc.rotation || 0, ports: [first, port] });
    }
    for (const p of ports) p.load = Math.round(p.pixels / perPort * 1000) / 10;
    const raster = { w: Math.max(0, ...screens.map(s => s.x + s.w)), h: Math.max(0, ...screens.map(s => s.y + s.h)) };
    const warnings = [];
    if (proc && ports.length > proc.ports) warnings.push(`${ports.length} ports needed — the ${proc.name} has ${proc.ports}.`);
    if (proc && (raster.w > proc.maxW || raster.h > proc.maxH)) warnings.push(`The output raster (${raster.w}×${raster.h}) is bigger than the ${proc.name}'s input (${proc.maxW}×${proc.maxH}).`);
    if (proc && ports.reduce((n, p) => n + p.pixels, 0) > proc.total) warnings.push(`More pixels than the ${proc.name} drives (${proc.total.toLocaleString('en')}).`);
    for (const s of screens) if (s.rotation) warnings.push(`${s.name} is rotated ${s.rotation}° in PIXORA — rotate it the same way in the processor.`);
    return { generated: new Date().toISOString(), processor: proc ? { id: proc.id, name: proc.name, ports: proc.ports, perPort: proc.perPort, maxW: proc.maxW, maxH: proc.maxH, note: proc.note || '' } : null, perPort, maxCabinets: maxCab, raster, screens, ports, cabinets, warnings };
  }
  function screenSvg(P, s) {
    const cabs = P.cabinets.filter(c => c.screenId === s.id).sort((a, b) => a.chainIndex - b.chainIndex), k = Math.min(1, 1400 / Math.max(1, s.w)), W = Math.round(s.w * k), H = Math.round(s.h * k), pad = 40;
    const cw = s.cabinetW * k, ch = s.cabinetH * k, cx = c => (c.col - 1) * cw + cw / 2 + pad, cy = c => (c.row - 1) * ch + ch / 2 + pad + 30, fs = Math.max(8, Math.min(cw, ch) * 0.2);
    let g = `<svg xmlns="http://www.w3.org/2000/svg" width="${W + pad * 2}" height="${H + pad * 2 + 30}" viewBox="0 0 ${W + pad * 2} ${H + pad * 2 + 30}" font-family="Inter,Arial,sans-serif"><rect width="100%" height="100%" fill="#0b0b12"/>`;
    g += `<text x="${pad}" y="28" fill="#fff" font-size="18" font-weight="700">${esc(s.name)} — ${s.cols}×${s.rows} cabinets of ${s.cabinetW}×${s.cabinetH}px · ${s.w}×${s.h}px at ${s.x},${s.y} · ports ${s.ports[0]}–${s.ports[1]}</text>`;
    for (const c of cabs) { const col = PORT_COLORS[(c.port - 1) % PORT_COLORS.length], x = (c.col - 1) * cw + pad, y = (c.row - 1) * ch + pad + 30;
      g += `<rect x="${x + 1}" y="${y + 1}" width="${cw - 2}" height="${ch - 2}" fill="${col}22" stroke="${col}" stroke-width="2"/><text x="${x + cw / 2}" y="${y + ch / 2 - fs * 0.3}" fill="#fff" font-size="${fs * 1.25}" font-weight="800" text-anchor="middle">P${c.port}·${c.onPort}</text><text x="${x + cw / 2}" y="${y + ch / 2 + fs * 1.1}" fill="#aab" font-size="${fs * 0.8}" text-anchor="middle">${c.col},${c.row}</text>`; }
    for (let i = 1; i < cabs.length; i++) { const a = cabs[i - 1], b = cabs[i]; if (a.port !== b.port) continue; const col = PORT_COLORS[(a.port - 1) % PORT_COLORS.length];
      g += `<line x1="${cx(a)}" y1="${cy(a)}" x2="${cx(b)}" y2="${cy(b)}" stroke="${col}" stroke-width="3" marker-end="url(#ar${(a.port - 1) % PORT_COLORS.length})" opacity=".9"/>`; }
    for (const p of P.ports.filter(p => p.screenId === s.id)) { const c0 = cabs.find(c => c.port === p.port && c.onPort === 1); if (!c0) continue; const col = PORT_COLORS[(p.port - 1) % PORT_COLORS.length];
      g += `<circle cx="${cx(c0)}" cy="${cy(c0)}" r="${Math.max(6, fs * 0.6)}" fill="${col}"/><text x="${cx(c0)}" y="${cy(c0) + 4}" fill="#000" font-size="${Math.max(8, fs * 0.7)}" font-weight="800" text-anchor="middle">IN</text>`; }
    g += `<defs>${PORT_COLORS.map((c, i) => `<marker id="ar${i}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="${c}"/></marker>`).join('')}</defs></svg>`;
    return g;
  }
  function overviewSvg(P) {
    const k = Math.min(1, 1600 / Math.max(1, P.raster.w)), W = Math.max(200, Math.round(P.raster.w * k)), H = Math.max(100, Math.round(P.raster.h * k));
    let g = `<svg xmlns="http://www.w3.org/2000/svg" width="${W + 20}" height="${H + 20}" viewBox="-10 -10 ${W + 20} ${H + 20}" font-family="Inter,Arial,sans-serif"><rect x="-10" y="-10" width="100%" height="100%" fill="#0b0b12"/><rect width="${W}" height="${H}" fill="none" stroke="#333" stroke-dasharray="6 4"/>`;
    for (const c of P.cabinets) { const col = PORT_COLORS[(c.port - 1) % PORT_COLORS.length]; g += `<rect x="${c.x * k + 0.5}" y="${c.y * k + 0.5}" width="${c.w * k - 1}" height="${c.h * k - 1}" fill="${col}30" stroke="${col}"/>`; }
    for (const s of P.screens) g += `<text x="${s.x * k + 6}" y="${s.y * k + 18}" fill="#fff" font-size="14" font-weight="700">${esc(s.name)} (${s.w}×${s.h})</text>`;
    return g + '</svg>';
  }
  function readme(P) {
    const pr = P.processor;
    return `PIXORA — LED processor setup pack
==================================
Made ${P.generated.slice(0, 16).replace('T', ' ')} · ${P.screens.length} screen(s) · ${P.cabinets.length} cabinets · ${P.ports.length} port(s) · output raster ${P.raster.w}×${P.raster.h}
Processor: ${pr ? pr.name + ` (${pr.ports} ports, ≈${pr.perPort.toLocaleString('en')} px per port)` : `none selected — ports planned at ${P.perPort.toLocaleString('en')} px each`}${P.maxCabinets ? ` · max ${P.maxCabinets} cabinets per port` : ''}
${P.warnings.length ? '\nCHECK:\n' + P.warnings.map(w => '  • ' + w).join('\n') + '\n' : ''}
Processor configuration files are proprietary, so this pack gives you the layout to enter (or check) in the processor's
own software. Open setup-sheet.html for the printable version.

Every cabinet is labelled P<port>·<n>: port number, then its position on that port's cable, counted from the IN arrow.
Cabinet x/y are positions in PIXORA's output raster — the picture the processor receives on its input.

Novastar NovaLCT / SmartLCT (MCTRL, VX, NovaPro)
  Screen Configuration ▸ Screen Connection: set each screen's start position (x, y) from screens.csv, the cabinet
  size, rows and columns, then draw each port's cabling in the order shown (P1·1, P1·2 …).
Novastar VMP (COEX: MX / CX)
  Screen ▸ Layout: add the cabinets, place them at the x/y in cabinets.csv and connect each Ethernet port in order.
Brompton Tessera
  Canvas: place the fixtures at the x/y in cabinets.csv (the Snap to Fixtures grid helps), then check the data chains
  in Topology view against the cabling diagrams.
Megapixel HELIOS
  Mapping: position the tiles at the x/y from cabinets.csv; check the order against the diagrams.
Colorlight (LEDVISION / LEDUpgrade)
  Screen connection: set rows, columns, cabinet size and the start x/y; draw each port's chain in this order.

Port loads (≈${P.perPort.toLocaleString('en')} px per port):
${P.ports.map(p => `  Port ${String(p.port).padStart(2)}  ${p.screen.padEnd(20).slice(0, 20)}  ${String(p.cabinets).padStart(3)} cabinets  ${p.pixels.toLocaleString('en').padStart(9)} px  ${p.load}%`).join('\n')}

Capacities are typical figures (8-bit, 60 Hz). Higher bit depth or frame rate lowers them — always confirm against the
processor's manual. PIXORA has not checked this layout on a real processor.
`;
  }
  function sheet(P) {
    return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>LED setup sheet — PIXORA</title><style>
body{font-family:Inter,Arial,sans-serif;background:#fff;color:#111;margin:24px}h1{margin:0 0 4px}h2{margin:28px 0 8px;page-break-before:auto}.muted{color:#666}
table{border-collapse:collapse;font-size:12px;margin:8px 0}td,th{border:1px solid #ccc;padding:3px 8px;text-align:left}th{background:#f2f2f6}.warn{background:#fff4d6;border:1px solid #f0c040;padding:8px 12px;border-radius:6px}
.svg{background:#0b0b12;padding:6px;border-radius:8px;max-width:100%;overflow:auto}.svg svg{max-width:100%;height:auto}@media print{.svg{break-inside:avoid}}
</style></head><body><h1>LED processor setup sheet</h1><div class="muted">PIXORA · ${esc(P.generated.slice(0, 16).replace('T', ' '))} · ${P.processor ? esc(P.processor.name) : 'no processor selected'} · output raster ${P.raster.w}×${P.raster.h} · ${P.cabinets.length} cabinets on ${P.ports.length} port(s)</div>
${P.warnings.length ? `<p class="warn">${P.warnings.map(esc).join('<br>')}</p>` : ''}
<h2>Overview</h2><div class="svg">${overviewSvg(P)}</div>
<h2>Screens</h2><table><tr><th>Screen</th><th>Raster x,y</th><th>Size px</th><th>Cabinets</th><th>Cabinet px</th><th>Cabinet mm</th><th>Chain</th><th>Ports</th></tr>${P.screens.map(s => `<tr><td>${esc(s.name)}</td><td>${s.x}, ${s.y}</td><td>${s.w}×${s.h}</td><td>${s.cols}×${s.rows}</td><td>${s.cabinetW}×${s.cabinetH}</td><td>${s.cabinetMmW}×${s.cabinetMmH}</td><td>${esc(s.chain)} from ${esc(s.start)}</td><td>${s.ports[0]}–${s.ports[1]}</td></tr>`).join('')}</table>
<h2>Ports</h2><table><tr><th>Port</th><th>Screen</th><th>Cabinets</th><th>Pixels</th><th>Load</th></tr>${P.ports.map(p => `<tr><td>${p.port}</td><td>${esc(p.screen)}</td><td>${p.cabinets}</td><td>${p.pixels.toLocaleString('en')}</td><td style="${p.load > 100 ? 'color:#c00;font-weight:700' : ''}">${p.load}%</td></tr>`).join('')}</table>
${P.screens.map(s => `<h2>${esc(s.name)} — cabling</h2><div class="svg">${screenSvg(P, s)}</div>`).join('')}
<p class="muted">Each cabinet shows P&lt;port&gt;·&lt;position on that port&gt; and its column,row. Capacities are typical (8-bit, 60 Hz); confirm with the processor manual.</p></body></html>`;
  }
  function pack(opts) {
    const P = plan(opts), files = [];
    const safe = s => String(s).replace(/[^\w.-]+/g, '_').slice(0, 40) || 'screen';
    files.push({ name: 'README.txt', data: Buffer.from(readme(P)) });
    files.push({ name: 'setup-sheet.html', data: Buffer.from(sheet(P)) });
    files.push({ name: 'screens.csv', data: Buffer.from(csv([['screen', 'raster_x', 'raster_y', 'width_px', 'height_px', 'cabinet_w_px', 'cabinet_h_px', 'cols', 'rows', 'cabinet_w_mm', 'cabinet_h_mm', 'chain', 'start', 'rotation', 'first_port', 'last_port'], ...P.screens.map(s => [s.name, s.x, s.y, s.w, s.h, s.cabinetW, s.cabinetH, s.cols, s.rows, s.cabinetMmW, s.cabinetMmH, s.chain, s.start, s.rotation, s.ports[0], s.ports[1]])])) });
    files.push({ name: 'cabinets.csv', data: Buffer.from(csv([['screen', 'col', 'row', 'raster_x', 'raster_y', 'width_px', 'height_px', 'x_mm', 'y_mm', 'port', 'position_on_port', 'chain_index'], ...P.cabinets.map(c => [c.screen, c.col, c.row, c.x, c.y, c.w, c.h, c.mmX, c.mmY, c.port, c.onPort, c.chainIndex])])) });
    files.push({ name: 'ports.csv', data: Buffer.from(csv([['port', 'screen', 'cabinets', 'pixels', 'load_percent'], ...P.ports.map(p => [p.port, p.screen, p.cabinets, p.pixels, p.load])])) });
    files.push({ name: 'layout.json', data: Buffer.from(JSON.stringify(P, null, 1)) });
    files.push({ name: 'overview.svg', data: Buffer.from(overviewSvg(P)) });
    for (const s of P.screens) files.push({ name: `${safe(s.name)}-cabling.svg`, data: Buffer.from(screenSvg(P, s)) });
    return { zip: ctx.makeZip(files), plan: P };
  }
  async function http(p, req, res, url, send) {
    if (p !== '/api/led/setup-pack' && p !== '/api/led/setup-plan') return false;
    const o = { processor: url.searchParams.get('processor') || undefined, perPort: +url.searchParams.get('perPort') || undefined, maxCabinets: +url.searchParams.get('maxCabinets') || undefined };
    if (p === '/api/led/setup-plan') { send(res, 200, plan(o)); return true; }
    const r = pack(o); res.writeHead(200, { 'Content-Type': 'application/zip', 'Content-Disposition': 'attachment; filename="PIXORA-LED-setup.zip"' }); res.end(r.zip); return true;
  }
  return { plan, pack, http, chainOrder };
};
