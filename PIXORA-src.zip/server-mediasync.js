'use strict';
// Media sync: backup servers and render nodes copy the primary's media so they can play the show on their own.
//  - the primary lists what the show uses (every media path anywhere in the show: clips, stingers, ISF images, playlists…),
//    or its whole library, plus converted copies and colour LUTs: GET /api/sync/manifest
//  - files come over plain HTTP with Range, so an interrupted copy resumes: GET /api/sync/file
//  - the backup keeps them in DATA/synced-media/<primary path>; its /media route prefers that copy, so the mirrored show's
//    paths work unchanged. Files it already has (same path and size, e.g. the same drive) are not copied.
const fs = require('fs'), fsp = fs.promises, path = require('path'), crypto = require('crypto');

module.exports = function (o) {
  const { DATA, resolveMedia, mediaKind, transFile, LUT_DIR, MODEL_DIR, monitor } = o;
  const SYNC_DIR = path.join(DATA, 'synced-media');
  const MEDIA_RE = /^[\w.\- ]+\/.+\.[A-Za-z0-9]{2,5}$/;

  /* ---------------- primary side */
  function showPaths(st) { // every string in the show that names an existing media file
    const out = new Set(); const seen = new Set();
    const walk = (v, d) => { if (d > 12 || v == null) return;
      if (typeof v === 'string') { if (v.length < 400 && MEDIA_RE.test(v) && !v.includes('..') && mediaKind(v)) out.add(v); return; }
      if (typeof v !== 'object' || seen.has(v)) return; seen.add(v);
      if (Array.isArray(v)) { for (const x of v) walk(x, d + 1); return; }
      for (const k in v) if (k !== 'history' && k !== 'undo') walk(v[k], d + 1); };
    walk(st.layers, 0); walk(st.shaders, 0); walk(st.cues, 0); walk(st.timeline, 0); walk(st.comps, 0); walk(st.playlists, 0);
    return [...out];
  }
  async function manifest(st, scope, libraryItems) {
    const srcs = new Set(showPaths(st)); if (scope === 'library') for (const it of await libraryItems()) srcs.add(it.src);
    const files = [];
    for (const src of srcs) { const abs = resolveMedia(src); if (!abs) continue; let s; try { s = await fsp.stat(abs); } catch { continue; } if (!s.isFile()) continue;
      const e = { src, size: s.size, mtime: Math.floor(s.mtimeMs) }; try { const c = await fsp.stat(transFile(src)); e.conv = c.size; } catch {} files.push(e); }
    const luts = []; for (const l of st.luts || []) { try { const s = await fsp.stat(path.join(LUT_DIR, l.id + '.' + (l.ext || 'cube'))); luts.push({ id: l.id, ext: l.ext || 'cube', size: s.size }); } catch {} }
    const models = []; if (MODEL_DIR) for (const m of st.models || []) { try { const s = await fsp.stat(path.join(MODEL_DIR, m.id + '.' + m.ext)); models.push({ id: m.id, ext: m.ext, size: s.size }); } catch {} }
    files.sort((a, b) => a.src.localeCompare(b.src));
    const sig = crypto.createHash('sha1').update(JSON.stringify([files, luts, models])).digest('hex').slice(0, 16);
    return { files, luts, models, sig, total: files.reduce((a, f) => a + f.size + (f.conv || 0), 0) + luts.reduce((a, l) => a + l.size, 0) + models.reduce((a, l) => a + l.size, 0) };
  }
  function fileFor(src, conv) { const abs = resolveMedia(src); if (!abs) return null; return conv ? transFile(src) : abs; }

  /* ---------------- backup side */
  const syncedPath = src => { if (typeof src !== 'string' || !MEDIA_RE.test(src) || src.split('/').some(p => p === '..' || p === '.' || !p)) return null;
    const abs = path.resolve(SYNC_DIR, ...src.split('/')); return abs.startsWith(SYNC_DIR + path.sep) ? abs : null; };
  const localPath = src => { const p = syncedPath(src); return p && fs.existsSync(p) ? p : null; };
  const status = { state: 'idle', files: 0, done: 0, have: 0, copied: 0, bytes: 0, total: 0, current: '', errors: [], at: 0, sig: '' };
  let runT0 = 0, running = null, again = false, timer = null, cfg = null, onStatus = () => {}, lastPush = 0;
  const push = force => { const n = Date.now(); if (force || n - lastPush > 400) { lastPush = n; onStatus(view()); } };
  const view = () => ({ ...status, errors: status.errors.slice(0, 5) });

  async function download(url, dest, size, mtime, mbps) {
    const part = dest + '.part'; await fsp.mkdir(path.dirname(dest), { recursive: true });
    let have = 0; try { have = (await fsp.stat(part)).size; } catch {} if (have > size) { await fsp.unlink(part).catch(() => {}); have = 0; }
    if (have < size) {
      const r = await fetch(url, { headers: have ? { Range: `bytes=${have}-` } : {} });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      if (have && r.status !== 206) have = 0; // server ignored the range: start over
      const w = fs.createWriteStream(part, { flags: have ? 'a' : 'w' }); const rd = r.body.getReader(); let got = 0;
      try { for (;;) { const { done, value } = await rd.read(); if (done) break;
          if (!w.write(value)) await new Promise(ok => w.once('drain', ok)); got += value.length; status.bytes += value.length; push();
          if (mbps > 0) { const ahead = status.bytes * 8 / (mbps * 1e6) * 1000 - (Date.now() - runT0); if (ahead > 20) await new Promise(ok => setTimeout(ok, ahead)); } // one bandwidth cap for the whole sync, for busy show networks
          if (cfg && cfg.cancelled) throw new Error('cancelled'); } }
      finally { await new Promise(ok => w.end(ok)); }
    }
    const fin = (await fsp.stat(part)).size; if (fin !== size) throw new Error(`size mismatch (${fin} of ${size} bytes)`);
    await fsp.rename(part, dest); if (mtime) await fsp.utimes(dest, new Date(), new Date(mtime)).catch(() => {});
  }
  const same = async (p, size, mtime) => { try { const s = await fsp.stat(p); return s.size === size && (!mtime || Math.abs(s.mtimeMs - mtime) < 2000); } catch { return false; } };

  async function runOnce() {
    const c = cfg; if (!c || !c.base) return;
    const q = (c.pin ? `pin=${encodeURIComponent(c.pin)}&` : '');
    status.state = 'checking'; status.errors = []; status.current = ''; push(true);
    const r = await fetch(`${c.base}/api/sync/manifest?${q}scope=${c.scope === 'library' ? 'library' : 'show'}`); if (!r.ok) throw new Error(`manifest: HTTP ${r.status}`);
    const m = await r.json(); Object.assign(status, { files: m.files.length + m.luts.length + (m.models || []).length, done: 0, have: 0, copied: 0, bytes: 0, total: 0, sig: m.sig });
    const jobs = [];
    for (const f of m.files) {
      const own = resolveMedia(f.src); const mine = own && await same(own, f.size); const dest = syncedPath(f.src);
      if (!dest) { status.done++; continue; }
      if (mine || await same(dest, f.size, f.mtime)) status.have++; else jobs.push({ label: f.src, url: `${c.base}/api/sync/file?${q}src=${encodeURIComponent(f.src)}`, dest, size: f.size, mtime: f.mtime });
      if (f.conv) { const t = transFile(f.src); if (await same(t, f.conv)) status.have++; else jobs.push({ label: f.src + ' (converted)', url: `${c.base}/api/sync/file?${q}conv=1&src=${encodeURIComponent(f.src)}`, dest: t, size: f.conv }); status.files++; }
    }
    for (const l of m.luts) { const dest = path.join(LUT_DIR, l.id + '.' + l.ext); if (await same(dest, l.size)) status.have++; else jobs.push({ label: 'LUT ' + l.id, url: `${c.base}/api/luts/${l.id}?${q}`, dest, size: l.size }); }
    for (const md of m.models || []) { const dest = path.join(MODEL_DIR, md.id + '.' + md.ext); if (await same(dest, md.size)) status.have++; else jobs.push({ label: '3D model ' + md.id, url: `${c.base}/api/models/${md.id}?${q}`, dest, size: md.size }); }
    status.done = status.have; status.total = jobs.reduce((a, j) => a + j.size, 0); runT0 = Date.now(); status.state = jobs.length ? 'copying' : 'done'; push(true);
    const queue = jobs.slice(); const worker = async () => { for (let j; (j = queue.shift());) {
      status.current = j.label; push();
      try { await download(j.url, j.dest, j.size, j.mtime, +c.mbps || 0); status.copied++; } catch (e) { if (e.message === 'cancelled') throw e; status.errors.push(`${j.label}: ${e.message}`); }
      status.done++; push(); } };
    await Promise.all([worker(), worker()]);
    status.state = status.errors.length ? 'error' : 'done'; status.current = ''; status.at = Date.now();
    if (status.copied) monitor('backup', `media sync: copied ${status.copied} file${status.copied === 1 ? '' : 's'} from the primary`);
    if (status.errors.length) monitor('backup', `media sync: ${status.errors.length} file(s) failed — ${status.errors[0]}`);
    push(true); return status.copied;
  }
  async function run() {
    if (running) { again = true; return running; }
    running = (async () => { let copied = 0; try { do { again = false; copied += (await runOnce()) || 0; } while (again && cfg); } catch (e) { status.state = 'error'; status.errors.unshift(e.message); status.current = ''; push(true); } finally { running = null; } return copied; })();
    return running;
  }
  return {
    SYNC_DIR, showPaths, manifest, fileFor, localPath, syncedPath, status: view, run,
    configure(c, statusCb) { // c: { base, pin, scope, mbps, on } — null stops syncing
      if (statusCb) onStatus = statusCb; if (cfg) cfg.cancelled = !c || c.base !== cfg.base;
      cfg = c && c.on !== false && c.base ? Object.assign({}, c) : null; if (!cfg) { clearTimeout(timer); if (status.state !== 'idle') { status.state = 'off'; push(true); } } },
    soon(ms = 4000) { if (!cfg) return; const due = Date.now() + ms; if (timer && timer.due <= due) return; clearTimeout(timer); timer = setTimeout(() => { timer = null; run(); }, ms); timer.due = due; }, // the show changed: look again shortly (an earlier pending look is kept)
    // primary routes
    async route(req, res, p, url, send, ctx) {
      if (p === '/api/sync/manifest') return send(res, 200, await manifest(ctx.state(), url.searchParams.get('scope'), ctx.libraryItems)), true;
      if (p === '/api/sync/file') { const src = url.searchParams.get('src') || ''; const st = ctx.state();
        const allowed = showPaths(st).includes(src) || (await ctx.libraryItems()).some(i => i.src === src); // only media this server would play anyway
        const f = allowed && fileFor(src, url.searchParams.get('conv') === '1'); if (!f) return send(res, 404, { error: 'not shared' }), true;
        await ctx.serveFile(req, res, f, 'no-cache', 'application/octet-stream'); return true; }
      return false;
    },
  };
};
