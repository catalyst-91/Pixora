// PIXORA — Blackmagic ATEM switcher control over the network (UDP 9910). Booth Productions.
// Independent Node implementation of the ATEM protocol, following the open-source atem-connection library
// (Sofie / NRK, MIT, https://github.com/Sofie-Automation/sofie-atem-connection) for packet framing and command
// layouts, and Blackmagic's Camera Control Protocol document for camera parameters. Works on Windows, macOS,
// Linux and in Docker, with no SDK or ATEM Software Control install needed.
'use strict';
const dgram = require('dgram'), { EventEmitter } = require('events');
const F = { ACK_REQ: 0x01, NEW_SESSION: 0x02, RETRANSMIT: 0x04, RETRANSMIT_REQ: 0x08, ACK: 0x10 };
const HELLO = Buffer.from([0x10, 0x14, 0x53, 0xab, 0, 0, 0, 0, 0, 0x3a, 0, 0, 0x01, 0, 0, 0, 0, 0, 0, 0]);
const V8_0_1 = 0x0002001d;
const str = (b, o, n) => b.toString('utf8', o, Math.min(b.length, o + n)).replace(/\0[\s\S]*$/, '').trim();

// Blackmagic camera control: [category, parameter, type] (types: 0 void/bool, 1 int8, 2 int16, 3 int32, 0x80 fixed16)
const CAM = {
  focus: [0, 0, 0x80], autoFocus: [0, 1, 0], irisF: [0, 2, 0x80], iris: [0, 3, 0x80], autoIris: [0, 5, 0], ois: [0, 6, 0],
  zoomPos: [0, 8, 0x80], zoom: [0, 9, 0x80], gainOld: [1, 1, 1], whiteBalance: [1, 2, 2], autoWhiteBalance: [1, 3, 0], exposure: [1, 5, 3],
  shutterAngle: [1, 11, 3], shutter: [1, 12, 3], gain: [1, 13, 1], iso: [1, 14, 3], nd: [1, 16, 0x80], panTilt: [11, 0, 0x80], preset: [11, 1, 1],
};

class AtemClient extends EventEmitter {
  constructor(host, port = 9910) {
    super(); this.host = host; this.port = port; this.session = 0x53ab; this.nextId = 1; this.inFlight = new Map(); this.lastRx = 0; this.connected = false; this.version = 0;
    this.state = { model: '', mes: 1, dsks: 0, auxes: 0, inputs: {}, program: {}, preview: {}, transition: {}, ftb: {}, dsk: {}, usk: {}, aux: {}, macros: {}, tally: {}, recording: '', streaming: '', ready: false };
  }
  connect() {
    this.close(); this.sock = dgram.createSocket('udp4'); this.sock.on('message', (m, r) => this.rx(m, r)); this.sock.on('error', e => this.emit('error', e));
    this.sock.bind(0, () => this.hello());
    this.timer = setInterval(() => this.watch(), 200);
  }
  hello() { this.session = 0x53ab; this.connected = false; this.state.ready = false; this.inFlight.clear(); this.send(HELLO); this.helloAt = Date.now(); }
  watch() {
    const now = Date.now();
    if (!this.connected && now - this.helloAt > 1000) this.hello();
    if (this.connected && now - this.lastRx > 5000) { this.connected = false; this.emit('disconnected'); this.hello(); }
    for (const [id, p] of this.inFlight) { if (now - p.at > 150) { if (++p.tries > 8) { this.inFlight.delete(id); p.bad(new Error('ATEM did not acknowledge')); continue; } p.at = now; p.buf[0] |= F.RETRANSMIT << 3; this.send(p.buf); } }
  }
  close() { clearInterval(this.timer); try { this.sock && this.sock.close(); } catch {} this.sock = null; this.connected = false; for (const p of this.inFlight.values()) p.bad(new Error('disconnected')); this.inFlight.clear(); }
  send(buf) { if (this.sock) this.sock.send(buf, this.port, this.host, () => {}); }
  ack(id) { const b = Buffer.alloc(12); b.writeUInt16BE((F.ACK << 11) | 12, 0); b.writeUInt16BE(this.session, 2); b.writeUInt16BE(id, 4); this.send(b); }
  rx(m, r) {
    if (m.length < 12 || (m.readUInt16BE(0) & 0x07ff) !== m.length) return;
    this.lastRx = Date.now(); const flags = m[0] >> 3; this.session = m.readUInt16BE(2); const rid = m.readUInt16BE(10);
    if (flags & F.NEW_SESSION) { this.connected = true; this.ack(rid); return; }
    if (flags & F.ACK) { const a = m.readUInt16BE(4); for (const [id, p] of this.inFlight) if (id <= a || a - id > 16384) { this.inFlight.delete(id); p.ok(); } }
    if (flags & F.RETRANSMIT_REQ) { const from = m.readUInt16BE(6); for (const [id, p] of this.inFlight) if (id >= from) this.send(p.buf); }
    if (flags & F.ACK_REQ) { this.ack(rid); if (rid !== this.lastRid || !(flags & F.RETRANSMIT)) { this.lastRid = rid; if (m.length > 12) this.commands(m.subarray(12)); } }
  }
  commands(b) {
    let o = 0, changed = false;
    while (o + 8 <= b.length) { const len = b.readUInt16BE(o); if (len < 8 || o + len > b.length) break; const name = b.toString('latin1', o + 4, o + 8), d = b.subarray(o + 8, o + len); o += len;
      try { if (this.parse(name, d)) changed = true; } catch {} }
    if (changed) this.emit('state', this.state);
  }
  parse(n, d) {
    const S = this.state;
    switch (n) {
      case '_ver': this.version = d.readUInt32BE(0); return false;
      case '_pin': S.model = str(d, 0, 40); return true;
      case '_top': S.mes = d[0]; S.sources = d[1]; S.dsks = d[2]; S.auxes = d[3]; S.mediaPlayers = d[5]; return true;
      case 'InPr': { const id = d.readUInt16BE(0); S.inputs[id] = { id, name: str(d, 2, 20), short: str(d, 22, 4), port: d.readUInt16BE(30), internal: d[32] }; return true; }
      case 'PrgI': S.program[d[0]] = d.readUInt16BE(2); return true;
      case 'PrvI': S.preview[d[0]] = d.readUInt16BE(2); return true;
      case 'TrSS': S.transition[d[0]] = Object.assign(S.transition[d[0]] || {}, { style: d[1], next: d[3] }); return true;
      case 'TMxP': S.transition[d[0]] = Object.assign(S.transition[d[0]] || {}, { mixRate: d[1] }); return true;
      case 'FtbS': S.ftb[d[0]] = { black: d[1] === 1, moving: d[2] === 1 }; return true;
      case 'DskS': S.dsk[d[0]] = { onAir: d[1] === 1, moving: d[2] === 1 }; return true;
      case 'KeOn': S.usk[`${d[0]}:${d[1]}`] = d[2] === 1; return true;
      case 'AuxS': S.aux[d[0]] = d.readUInt16BE(2); return true;
      case 'MPrp': { const i = d.readUInt16BE(0), used = d[2] !== 0, nl = d.readUInt16BE(4); if (used) S.macros[i] = { id: i, name: str(d, 8, nl) || 'Macro ' + (i + 1) }; else delete S.macros[i]; return true; }
      case 'TlSr': { const c = d.readUInt16BE(0); S.tally = {}; for (let i = 0; i < c; i++) { const src = d.readUInt16BE(2 + i * 3), v = d[4 + i * 3]; if (v) S.tally[src] = { program: !!(v & 1), preview: !!(v & 2) }; } return true; }
      case 'RTMS': S.recording = ['idle', 'recording', 'stopping'][d.readUInt16BE(0) & 3] || String(d.readUInt16BE(0)); return true;
      case 'StRS': S.streaming = { 1: 'idle', 2: 'connecting', 4: 'streaming', 36: 'stopping' }[d.readUInt16BE(0)] || String(d.readUInt16BE(0)); return true;
      case 'InCm': S.ready = true; this.emit('ready'); return true;
    }
    return false;
  }
  cmd(name, payload) {
    return new Promise((ok, bad) => {
      if (!this.connected) return bad(new Error('ATEM not connected'));
      const id = this.nextId; this.nextId = (this.nextId + 1) % 32768 || 1;
      const blk = Buffer.alloc(8 + payload.length); blk.writeUInt16BE(blk.length, 0); blk.write(name, 4, 'latin1'); payload.copy(blk, 8);
      const buf = Buffer.alloc(12 + blk.length); buf.writeUInt16BE((F.ACK_REQ << 11) | buf.length, 0); buf.writeUInt16BE(this.session, 2); buf.writeUInt16BE(id, 10); blk.copy(buf, 12);
      this.inFlight.set(id, { buf, ok, bad, at: Date.now(), tries: 0 }); this.send(buf);
    });
  }
  /* ---- actions */
  program(input, me = 0) { const b = Buffer.alloc(4); b[0] = me; b.writeUInt16BE(input, 2); return this.cmd('CPgI', b); }
  preview(input, me = 0) { const b = Buffer.alloc(4); b[0] = me; b.writeUInt16BE(input, 2); return this.cmd('CPvI', b); }
  cut(me = 0) { return this.cmd('DCut', Buffer.from([me, 0, 0, 0])); }
  auto(me = 0) { return this.cmd('DAut', Buffer.from([me, 0, 0, 0])); }
  ftb(me = 0) { return this.cmd('FtbA', Buffer.from([me, 0, 0, 0])); }
  transitionStyle(style, me = 0) { return this.cmd('CTTp', Buffer.from([0x01, me, style & 255, 0])); } // 0 mix, 1 dip, 2 wipe, 3 DVE, 4 stinger
  mixRate(frames, me = 0) { return this.cmd('CTMx', Buffer.from([me, Math.max(1, Math.min(250, frames | 0)), 0, 0])); }
  dskOnAir(k, on) { return this.cmd('CDsL', Buffer.from([k, on ? 1 : 0, 0, 0])); }
  dskAuto(k) { return this.cmd('DDsA', this.version >= V8_0_1 ? Buffer.from([0, k, 0, 0]) : Buffer.from([k, 0, 0, 0])); }
  uskOnAir(k, on, me = 0) { return this.cmd('CKOn', Buffer.from([me, k, on ? 1 : 0, 0])); }
  aux(bus, input) { const b = Buffer.alloc(4); b[0] = 1; b[1] = bus; b.writeUInt16BE(input, 2); return this.cmd('CAuS', b); }
  macro(i, action = 0) { const b = Buffer.alloc(4); b.writeUInt16BE(action === 0 ? i : 0xffff, 0); b[2] = action; return this.cmd('MAct', b); } // 0 run, 1 stop, 4 continue
  record(on) { return this.cmd('RcTM', Buffer.from([on ? 1 : 0, 0, 0, 0])); }
  stream(on) { return this.cmd('StrR', Buffer.from([on ? 1 : 0, 0, 0, 0])); }
  camera(source, param, values, relative = false) {
    const [cat, par, type] = CAM[param] || []; if (cat == null) return Promise.reject(new Error('unknown camera parameter ' + param));
    const vals = [].concat(values == null ? [] : values), size = type === 0 || type === 1 ? 1 : type === 3 ? 4 : 2;
    const len = 16 + Math.ceil((vals.length * size) / 8) * 8, b = Buffer.alloc(len);
    b[0] = source; b[1] = cat; b[2] = par; b[3] = relative ? 1 : 0; b[4] = type;
    b.writeUInt16BE(vals.length, type === 0 || type === 1 ? 6 : type === 3 ? 10 : 8);
    vals.forEach((v, i) => { const o = 16 + i * size; if (type === 0) b.writeInt8(v ? 1 : 0, o); else if (type === 1) b.writeInt8(v | 0, o); else if (type === 2) b.writeInt16BE(v | 0, o); else if (type === 3) b.writeInt32BE(v | 0, o); else b.writeInt16BE(Math.round(Math.max(-16, Math.min(15.99, v)) * 2048), o); });
    return this.cmd('CCmd', b);
  }
}
module.exports = { AtemClient, CAM };
