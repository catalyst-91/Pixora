// PIXORA replay export — Booth Productions.
// Turns replay events into video files for social media teams. The main output already holds the replay as encoded video
// (H.264 Annex-B, or VP8), so nothing is re-encoded: the output sends the event's chunks — from the keyframe at or
// before the in point (keyframes every half second) to the out point — and ffmpeg wraps them into an MP4 (WebM for VP8).
// Slow motion costs nothing either: 50 fps frames written at 25 fps play at half speed.
//   Files go to media/Replays/<event> [unit] [speed].mp4 and appear in the library.
'use strict';
const fs = require('fs'), path = require('path'), os = require('os'), crypto = require('crypto');
const { spawn } = require('child_process');

module.exports = function replayExport(ctx) { // ctx: { FFMPEG, ffmpegOk(), LOCAL_MEDIA, state (getter), sendToOutput(o), broadcast(o), monitor, onSaved() }
  const jobs = new Map(); // id → { name, unit, speed, fps, codec, parts[], bytes, timer }
  const dir = () => path.join(ctx.LOCAL_MEDIA, 'Replays');
  const safe = s => String(s || 'Replay').replace(/[\\/:*?"<>|\x00-\x1f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80) || 'Replay';
  const status = (o) => ctx.broadcast(Object.assign({ t: 'replayExportStatus' }, o)); // controllers only listen; 'replayExport' is the request to the output

  // controller asks: { event?, from?, to?, units: ['A'] | 'all', speed: 1 | 0.5 | 0.25 }
  function request(cmd) {
    const R = ctx.state.replay; if (!R) throw new Error('replay is not set up');
    if (!ctx.ffmpegOk()) throw new Error('exporting replays needs ffmpeg');
    const ev = cmd.event && R.events.find(e => e.id === cmd.event);
    const from = ev ? ev.in : +cmd.from, to = ev ? ev.out : +cmd.to; if (!(to > from)) throw new Error('nothing to export — mark an in and out point or pick an event');
    const live = R.units.filter(u => u.source != null && u.source !== '' && u.source !== 'off').map(u => u.id); // source 0 = layer 1
    const units = cmd.units === 'all' ? live : [].concat(cmd.units || (ev && ev.unit) || R.selected).filter(u => live.includes(u));
    if (!units.length) throw new Error('that replay unit isn’t recording');
    const speed = [1, 0.5, 0.25].includes(+cmd.speed) ? +cmd.speed : 1;
    const out = [];
    for (const unit of units) {
      const id = crypto.randomBytes(5).toString('hex'), name = safe(ev ? ev.name : cmd.name || 'Replay');
      jobs.set(id, { id, name, unit, speed, event: ev ? ev.id : null, parts: [], bytes: 0, multi: units.length > 1, timer: setTimeout(() => fail(id, 'the main output didn’t answer'), 30000) });
      ctx.sendToOutput({ t: 'replayExport', id, unit, from, to });
      out.push(id); status({ id, state: 'collecting', name, unit });
    }
    return out;
  }
  function fail(id, msg) { const j = jobs.get(id); if (!j) return; clearTimeout(j.timer); jobs.delete(id); status({ id, state: 'error', name: j.name, unit: j.unit, error: msg }); ctx.monitor('replay', `export failed: ${msg}`); }

  // binary from the primary output: [4][u32 header length][header JSON][data]
  //   header: { id, codec, fps, w, h, part, last, error? }
  function data(buf) {
    if (buf.length < 5) return; const hl = buf.readUInt32BE(0); let h; try { h = JSON.parse(buf.subarray(4, 4 + hl).toString()); } catch { return; }
    const j = jobs.get(h.id); if (!j) return;
    if (h.error) return fail(h.id, h.error);
    clearTimeout(j.timer); j.timer = setTimeout(() => fail(h.id, 'the transfer stopped'), 30000);
    Object.assign(j, { codec: h.codec || j.codec, fps: h.fps || j.fps, w: h.w || j.w, h: h.h || j.h, frames: (j.frames || 0) + (h.frames || 0) });
    const d = buf.subarray(4 + hl); j.parts.push(Buffer.from(d)); j.bytes += d.length;
    if (j.bytes > 1024 * 1024 * 1024) return fail(h.id, 'too long to export');
    if (h.last) finish(j);
  }
  function finish(j) {
    clearTimeout(j.timer); jobs.delete(j.id);
    const vp8 = /^vp8/i.test(j.codec || ''), ext = vp8 ? 'webm' : 'mp4';
    const tmp = path.join(os.tmpdir(), `pixora-replay-${j.id}.${vp8 ? 'ivf' : 'h264'}`);
    let raw = Buffer.concat(j.parts); j.parts = [];
    let fps = Math.max(1, +j.fps || 50); const std = [23.976, 24, 25, 29.97, 30, 48, 50, 59.94, 60].find(r => Math.abs(fps - r) / r < 0.03); if (std) fps = std; // measured rate → nearest standard one
    const outFps = Math.round(fps * j.speed * 1000) / 1000;
    if (vp8) raw = ivf(raw, j, outFps); // IVF: frame timestamps at the output frame rate
    fs.writeFileSync(tmp, raw);
    fs.mkdirSync(dir(), { recursive: true });
    const base = `${j.name}${j.multi ? ' ' + j.unit : ''}${j.speed !== 1 ? ' ' + Math.round(j.speed * 100) + '%' : ''}`;
    let file = path.join(dir(), `${base}.${ext}`); for (let n = 2; fs.existsSync(file); n++) file = path.join(dir(), `${base} (${n}).${ext}`);
    const args = vp8 ? ['-v', 'error', '-y', '-i', tmp, '-c', 'copy', file]
      : ['-v', 'error', '-y', '-f', 'h264', '-r', String(outFps), '-i', tmp, '-c', 'copy', '-movflags', '+faststart', file];
    status({ id: j.id, state: 'saving', name: j.name, unit: j.unit });
    const p = spawn(ctx.FFMPEG, args, { windowsHide: true }); let err = '';
    p.stderr.on('data', d => { err += d; }); p.on('error', e => { err += e.message; });
    p.on('close', code => {
      try { fs.rmSync(tmp, { force: true }); } catch {}
      if (code !== 0 || !fs.existsSync(file)) return status({ id: j.id, state: 'error', name: j.name, unit: j.unit, error: (err.trim().split('\n').pop() || 'ffmpeg failed').slice(0, 200) });
      const rel = path.relative(ctx.LOCAL_MEDIA, file).split(path.sep).join('/'), secs = Math.round((j.frames || 0) / outFps * 10) / 10;
      const R = ctx.state.replay, ev = R && j.event && R.events.find(e => e.id === j.event);
      if (ev) { ev.files = (ev.files || []).filter(f => !(f.unit === j.unit && f.speed === j.speed)).concat({ unit: j.unit, speed: j.speed, file: rel }).slice(-12); ctx.changed(); }
      ctx.monitor('replay', `exported ${rel} (${secs}s, ${Math.round(fs.statSync(file).size / 1048576 * 10) / 10} MB)`);
      status({ id: j.id, state: 'done', name: j.name, unit: j.unit, file: rel, url: '/media/local/' + rel.split('/').map(encodeURIComponent).join('/'), secs });
      ctx.onSaved();
    });
  }
  // VP8 frames → IVF container ([u32 len][u64 pts][frame] per frame); the output sends VP8 frames as [u32 len][frame]…
  function ivf(buf, j, fps) {
    const frames = []; for (let o = 0; o + 4 <= buf.length;) { const n = buf.readUInt32BE(o); frames.push(buf.subarray(o + 4, o + 4 + n)); o += 4 + n; }
    const den = Math.round(fps * 1000), num = 1000, hdr = Buffer.alloc(32);
    hdr.write('DKIF', 0); hdr.writeUInt16LE(0, 4); hdr.writeUInt16LE(32, 6); hdr.write('VP80', 8); hdr.writeUInt16LE(j.w | 0, 12); hdr.writeUInt16LE(j.h | 0, 14);
    hdr.writeUInt32LE(den, 16); hdr.writeUInt32LE(num, 20); hdr.writeUInt32LE(frames.length, 24);
    const parts = [hdr]; frames.forEach((f, i) => { const fh = Buffer.alloc(12); fh.writeUInt32LE(f.length, 0); fh.writeBigUInt64LE(BigInt(i), 4); parts.push(fh, f); });
    return Buffer.concat(parts);
  }
  return { request, data, jobs };
};
