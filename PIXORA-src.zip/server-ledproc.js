// PIXORA LED processor control — Booth Productions. Drivers for the Devices hub (server-devices.js):
//   Novastar COEX (MX / CX series, VMP)      HTTP :8001 /api/v1/device/…   (as the MIT "novastar-coex" library uses it)
//   Novastar controllers (MCTRL, VX, NovaPro, J6, VX Pro)  TCP :5200 (VX Pro :15200), 55 AA frames — tables from
//                                            Bitfocus Companion's MIT "novastar-controller" module (server-ledproc-novastar.js)
//   Novastar H series splicers               UDP :6000, JSON commands (as Companion's MIT "novastar-splicer" module)
//   Megapixel HELIOS                         HTTP public API: PATCH /api/v1/public, POST /api/v1/presets/{id}/apply
//   Any processor with DMX / eDMX control    Art-Net or sACN — brightness, preset, blackout, freeze, test channels you set
//                                            from the processor's manual (e.g. Brompton Tessera DMX control profiles)
// None of these have been tried on real hardware here; they follow the published APIs and the open-source drivers above.
'use strict';
module.exports = function ledproc({ Device, httpReq, clamp, net, dgram, crypto }) {
  const NOVA = require('./server-ledproc-novastar.js');
  const TYPES = {
    'nova-coex': { label: 'LED processor — Novastar COEX (MX / CX, VMP)', port: 8001, led: true },
    'nova-ctrl': { label: 'LED processor — Novastar MCTRL / VX / NovaPro', port: 5200, led: true },
    'nova-h': { label: 'LED processor — Novastar H series', port: 6000, led: true },
    helios: { label: 'LED processor — Megapixel HELIOS', port: 80, led: true },
    'led-dmx': { label: 'LED processor — DMX / eDMX control (Brompton, ROE, others)', port: 0, led: true },
  };
  const pct = v => { v = +v; if (!isFinite(v)) return 1; return clamp(v > 1 ? v / 100 : v, 0, 1); }; // 0–1 or 0–100 → 0–1
  // every LED processor offers the same core actions, so cues, keys and the panel work the same whatever the brand
  const CORE = [['brightness', 'Brightness (0–100 %)', ['value']], ['blackout', 'Blackout on/off', ['on']], ['freeze', 'Freeze on/off', ['on']], ['preset', 'Recall preset', ['preset']], ['test', 'Test pattern', ['pattern']], ['normal', 'Normal (no blackout / freeze / test)']];

  /* ---------------------------------------------------------- health monitoring (shared shape for the Health page)
     state.health = { at, temp: hottest °C, board: controller °C, cards, cardsBad, ports, portsBad, alerts: [{ lvl, msg }] } */
  const tempWarn = d => +((d.cfg.opts || {}).tempWarn) || 70;
  function coexHealth(d, data) { // GET /api/v1/device/monitor/info (COEX). Status codes aren't documented: 0 is treated as normal.
    const H = { at: Date.now(), temp: null, board: null, cards: 0, cardsBad: 0, ports: 0, portsBad: 0, fansBad: 0, bitErrors: 0, alerts: [] }; if (!data) return H;
    const tv = t => (t && typeof t === 'object' ? +t.value : +t); const hot = v => { if (isFinite(v) && v > -40 && v < 150) H.temp = H.temp == null ? v : Math.max(H.temp, v); };
    if (data.mainBoardTemperature) { H.board = tv(data.mainBoardTemperature); hot(H.board); if (data.mainBoardTemperature.status) H.alerts.push({ lvl: 'warn', msg: `controller temperature warning (${H.board}°C)` }); }
    (data.fanInfos || []).forEach((f, i) => { if (f && f.status) { H.fansBad++; H.alerts.push({ lvl: 'warn', msg: `fan ${i + 1} fault` }); } });
    for (const p of data.controllerPortMonitorInfos || []) { H.ports++; if (p && p.status) { H.portsBad++; H.alerts.push({ lvl: 'err', msg: `output port ${(p.controllerPortID ?? 0) + 1} fault` }); } }
    for (const cab of data.cabinets || []) for (const rv of cab.rvCards || []) {
      H.cards++; const t = tv(rv.temperature); hot(t); const where = `port ${(rv.netPortIndex ?? cab.outPutID ?? 0) + 1} card ${(rv.cabinetIndex ?? cab.index ?? 0) + 1}`; let bad = false;
      if (isFinite(t) && t >= tempWarn(d)) { bad = true; H.alerts.push({ lvl: t >= tempWarn(d) + 10 ? 'err' : 'warn', msg: `${where} at ${t}°C` }); }
      else if (rv.temperature && rv.temperature.status) { bad = true; H.alerts.push({ lvl: 'warn', msg: `${where} temperature warning` }); }
      if (rv.voltage && rv.voltage.status) { bad = true; H.alerts.push({ lvl: 'warn', msg: `${where} voltage warning (${tv(rv.voltage)} V)` }); }
      const be = (rv.errorBit || []).reduce((n, e) => n + (+(e && e.value) || 0), 0); if (be) { H.bitErrors += be; bad = true; }
      if (rv.nextCabinetLinkStatus && rv.nextCabinetLinkStatus.linkStatus === false) { bad = true; H.alerts.push({ lvl: 'err', msg: `data link broken after ${where}` }); }
      if (bad) H.cardsBad++;
    }
    for (const c of data.cardMonitorInfo || []) if (c && c.status) H.alerts.push({ lvl: 'warn', msg: `controller card ${(c.cardID ?? 0) + 1} reports a problem` });
    if (H.bitErrors) H.alerts.push({ lvl: 'warn', msg: `${H.bitErrors} data bit errors on the receiving cards (check cables)` });
    return H;
  }
  function genericHealth(d, obj) { // HELIOS: no published monitoring schema, so read any temperature / signal / fault fields the API returns
    const H = { at: Date.now(), temp: null, board: null, cards: 0, cardsBad: 0, ports: 0, portsBad: 0, alerts: [], generic: true }; let n = 0;
    const nm = k => k.replace(/^\./, '');
    const walk = (o, key, depth) => { if (depth > 8 || n++ > 20000 || o == null) return;
      if (typeof o === 'number') { if (/temp/i.test(key) && o > -40 && o < 150) { H.temp = H.temp == null ? o : Math.max(H.temp, o); if (o >= tempWarn(d)) H.alerts.push({ lvl: 'warn', msg: `${nm(key)} ${o}°C` }); }
        else if (/(error|fault|alarm|offline)s?(count)?$/i.test(key) && o > 0) H.alerts.push({ lvl: 'warn', msg: `${nm(key)}: ${o}` }); return; }
      if (typeof o === 'boolean') { if (/(signal|locked|present|detected)$/i.test(key) && /ingest|input|source/i.test(key) && o === false) H.alerts.push({ lvl: 'err', msg: `no input signal (${nm(key)})` }); return; }
      if (Array.isArray(o)) { o.forEach((x, i) => walk(x, key + '[' + i + ']', depth + 1)); return; }
      if (typeof o === 'object') for (const [k, v] of Object.entries(o)) walk(v, key + '.' + k, depth + 1); };
    walk(obj, '', 0); H.alerts = H.alerts.slice(0, 20); return H;
  }
  function healthChanged(d, H) { // log new alerts once
    const prev = new Set(((d.state.health || {}).alerts || []).map(a => a.msg)); d.state.health = H;
    for (const a of H.alerts) if (!prev.has(a.msg)) d.hub.monitor('device', `${d.cfg.name}: ${a.msg}`);
    d.changed();
  }

  /* ---------------------------------------------------------- Novastar COEX (HTTP) */
  class NovaCoex extends Device {
    api(method, path, body) { return httpReq(this.host, this.port, method, '/api/v1/device/' + path, body, { timeout: 4000 }).then(r => { if (r && r.code) throw new Error(r.message === 'device locked' ? 'the processor is locked by VMP on another computer — close VMP there' : r.message || 'error ' + r.code); return r; }); }
    start() { Object.assign(this.state, { presets: [], inputs: [] }); this.every(10000, async () => {
      try { const p = await this.api('GET', 'preset'); this.state.presets = ((p && p.data && p.data.data) || []).map(x => ({ id: x.sequenceNumber, name: x.name }));
        const s = await this.api('GET', 'input/sources').catch(() => null); this.state.inputs = ((s && s.data && s.data.data) || []).map(x => ({ id: x.groupId, name: x.name }));
        if (!this.state.online) this._online(true); else this.changed();
      } catch (e) { if (this.state.online) this._online(false); this._error(e); } })
      this.every(10000, async () => { const m = await this.api('GET', 'monitor/info').catch(() => null); if (m && m.data) healthChanged(this, coexHealth(this, m.data.data || m.data)); }); }
    stop() { this.stopped = true; super.stop(); } retry() {}
    actions() { return CORE.concat([['input', 'Input source', ['input']], ['gamma', 'Gamma', ['value']], ['colorTemp', 'Colour temperature (K)', ['value']]]); }
    async act(name, a = {}) {
      const mode = v => this.api('PUT', 'screen/displaymode', { value: v }); // 0 normal · 1 blackout · 2 freeze
      switch (name) {
        case 'brightness': return this.api('PUT', 'cabinet/brightness', { ratio: pct(a.value), idList: [16777215] }); // 16777215 = every cabinet
        case 'blackout': return mode(a.on === false || a.on === 'false' || a.on === 0 ? 0 : 1);
        case 'freeze': return mode(a.on === false || a.on === 'false' || a.on === 0 ? 0 : 2);
        case 'normal': await mode(0); return this.api('PUT', 'screen/controller/pattern/test', { mode: 0, parameters: { state: 0 } }).catch(() => {});
        case 'preset': { const p = (this.state.presets || []).find(x => String(x.id) === String(a.preset) || String(x.name).toLowerCase() === String(a.preset).toLowerCase()); return this.api('PUT', 'currentpreset', { sequenceNumber: p ? p.id : +a.preset }); }
        case 'input': { const s = (this.state.inputs || []).find(x => String(x.id) === String(a.input) || String(x.name).toLowerCase() === String(a.input).toLowerCase()); if (!s) throw new Error('unknown input ' + a.input); return this.api('PUT', 'screen/input', { groupId: s.id }); }
        case 'test': { const m = { off: 0, red: 16, green: 17, blue: 18, white: 19, grid: 32, gradient: 48 }[String(a.pattern || 'grid').toLowerCase()]; const mode = m == null ? +a.pattern || 0 : m;
          return this.api('PUT', 'screen/controller/pattern/test', { mode, parameters: { red: 4095, green: 4095, blue: 4095, gray: 255, gridWidth: 64, moveSpeed: 0, gradientStretch: 1, state: mode ? 1 : 0 } }); }
        case 'gamma': return this.api('PUT', 'cabinet/gamma', { value: +a.value || 2.8, type: 3, idList: [16777215] }).catch(() => this.api('PUT', 'screen/gamma', { gamma: +a.value || 2.8 }));
        case 'colorTemp': return this.api('PUT', 'cabinet/colortemperature', { value: clamp(+a.value || 6500, 1700, 15000), idList: [16777215], isAllCabinet: true });
      }
      return super.act(name);
    }
  }

  /* ---------------------------------------------------------- Novastar controllers (TCP, 55 AA frames) */
  function novaFrame(bytes) { const b = Buffer.from(bytes); let s = 0; for (let i = 2; i < b.length; i++) s += b[i]; s += 0x5555; const c = Buffer.alloc(2); c.writeUInt16LE(s & 0xffff); return Buffer.concat([b, c]); }
  const BRIGHT = v => novaFrame([0x55, 0xaa, 0x00, 0x00, 0xfe, 0xff, 0x01, 0xff, 0xff, 0xff, 0x01, 0x00, 0x01, 0x00, 0x00, 0x02, 0x01, 0x00, clamp(Math.round(v * 255), 0, 255)]);
  class NovaCtrl extends Device {
    get model() { return NOVA.CONFIG_MODEL[(this.cfg.opts || {}).model] || NOVA.CONFIG_MODEL.vx4s; }
    get port() { return +this.cfg.port || ((this.cfg.opts || {}).model === 'vxPro' ? 15200 : 5200); }
    start() { this.connect(); }
    connect() { if (this.stopped) return; const s = this.sock = net.connect({ host: this.host, port: this.port });
      s.setTimeout(15000); s.on('connect', () => { this._online(true); this.state.info = { model: this.model.label }; });
      s.on('data', () => {}); s.on('timeout', () => { s.write(Buffer.alloc(0)); });
      s.on('error', e => this._error(e)); s.on('close', () => { if (this.sock === s) { this.sock = null; this._online(false); } }); }
    stop() { this.stopped = true; super.stop(); try { this.sock && this.sock.destroy(); } catch {} }
    send(buf) { if (!this.sock || this.sock.destroyed || !this.state.online) throw new Error(`${this.cfg.name}: not connected`); this.sock.write(buf); return { ok: true }; }
    pick(list, key, what) { const L = list || []; const k = String(key ?? '').toLowerCase(); const c = L.find(x => x.id === String(key)) || L.find(x => String(x.label).toLowerCase() === k) || L.find(x => String(x.label).toLowerCase().includes(k)); if (!c) throw new Error(`${this.model.label}: no ${what} "${key}" (${L.map(x => x.label).join(', ') || 'none on this model'})`); return c.cmd; }
    actions() { return CORE.concat([['input', 'Input source', ['input']]]); }
    async act(name, a = {}) {
      const M = this.model, dm = l => this.send(this.pick(M.displayModes, l, 'display mode'));
      switch (name) {
        case 'brightness': return this.send(BRIGHT(pct(a.value)));
        case 'blackout': return dm(a.on === false || a.on === 'false' || a.on === 0 ? 'Normal' : 'Black');
        case 'freeze': return dm(a.on === false || a.on === 'false' || a.on === 0 ? 'Normal' : 'Freeze');
        case 'normal': dm('Normal'); try { this.send(this.pick(NOVA.CHOICES_TESTPATTERNS, 'Pattern Off', 'pattern')); } catch {} return { ok: true };
        case 'preset': { const n = +a.preset; return this.send(this.pick(M.presets, isFinite(n) && n >= 1 ? String(n - 1) : a.preset, 'preset')); } // presets 1…n
        case 'input': return this.send(this.pick(M.inputs, a.input, 'input'));
        case 'test': { const t = String(a.pattern || 'white').toLowerCase(), map = { off: 'Pattern Off', grid: 'Horizontal', gradient: 'Gray-Scale' }; return this.send(this.pick(NOVA.CHOICES_TESTPATTERNS, map[t] || t, 'test pattern')); }
      }
      return super.act(name);
    }
    view() { return Object.assign(super.view(), { models: Object.values(NOVA.CONFIG_MODEL).map(m => ({ id: m.id, label: m.label })) }); }
  }

  /* ---------------------------------------------------------- Novastar H series (UDP JSON) */
  class NovaH extends Device {
    start() { this.sock = dgram.createSocket('udp4'); this.sock.on('error', e => this._error(e)); this.sock.on('message', m => { this.lastRx = Date.now(); try { const r = JSON.parse(m.toString()); if (Array.isArray(r)) for (const x of r) if (x.cmd === 'R0400' && x.data) { this.state.screens = (x.data.screens || x.data || []).map(s => ({ id: s.screenId, name: s.name || s.general && s.general.name })).filter(s => s.id != null); this.changed(); } } catch {} if (!this.state.online) this._online(true); });
      this.sock.bind(() => { this.every(5000, async () => { this.cmd('R0400', {}); if (this.state.online && Date.now() - (this.lastRx || 0) > 16000) { this.state.online = false; this.changed(); } }); }); }
    stop() { this.stopped = true; super.stop(); try { this.sock.close(); } catch {} } retry() {}
    cmd(cmd, params) { const b = Buffer.from(JSON.stringify([Object.assign({}, params, { cmd, deviceId: 0 })])); this.sock.send(b, this.port, this.host); return { ok: true }; }
    get screen() { return +((this.cfg.opts || {}).screenId) || 0; }
    actions() { return CORE.filter(x => x[0] !== 'test').concat([['test', 'Test pattern on/off', ['on']]]); }
    async act(name, a = {}) {
      const off = a.on === false || a.on === 'false' || a.on === 0, screenId = a.screen != null ? +a.screen : this.screen;
      switch (name) {
        case 'brightness': return this.cmd('W0410', { screenId, brightness: Math.round(pct(a.value) * 100) });
        case 'blackout': return this.cmd('W0409', { screenId, type: off ? 1 : 0 });
        case 'freeze': return this.cmd('W040A', { screenId, enable: off ? 0 : 1 });
        case 'normal': this.cmd('W0409', { screenId, type: 1 }); return this.cmd('W040A', { screenId, enable: 0 });
        case 'preset': return this.cmd('W0605', { screenId, presetId: +a.preset || 0 });
        case 'test': return this.cmd('W0303', { screenId, enable: off ? 0 : 1 });
      }
      return super.act(name);
    }
  }

  /* ---------------------------------------------------------- Megapixel HELIOS (public REST API) */
  class Helios extends Device {
    api(method, path, body) { const c = this.cfg; return httpReq(this.host, this.port, method, path, body, { timeout: 4000, auth: c.user ? `${c.user}:${c.password || ''}` : undefined }); }
    pub(obj) { return this.api('PATCH', '/api/v1/public', obj); }
    start() { Object.assign(this.state, { presets: [] }); this.every(8000, async () => {
      try { const d = await this.api('GET', '/api/v1/public?dev.display&sys.description'); const disp = d && d.dev && d.dev.display || {};
        this.state.info = { name: d && d.sys && d.sys.description, brightness: disp.brightness, blackout: disp.blackout, freeze: disp.freeze };
        const p = await this.api('GET', '/api/v1/presets/list').catch(() => null); const arr = Array.isArray(p) ? p : p && (p.presets || p.data) || [];
        this.state.presets = arr.map(x => ({ id: x.id ?? x.presetId, name: x.name || x.label || String(x.id) })).filter(x => x.id != null);
        if (!this.state.online) this._online(true); else this.changed();
      } catch (e) { if (this.state.online) this._online(false); this._error(e); } })
      this.every(30000, async () => { const d = await this.api('GET', '/api/v1/public').catch(() => null); if (d && typeof d === 'object') healthChanged(this, genericHealth(this, d)); }); }
    stop() { this.stopped = true; super.stop(); } retry() {}
    actions() { return CORE.concat([['input', 'Input (name)', ['input']], ['gamma', 'Gamma', ['value']]]); }
    async act(name, a = {}) {
      const off = a.on === false || a.on === 'false' || a.on === 0;
      switch (name) {
        case 'brightness': return this.pub({ dev: { display: { brightness: Math.round(pct(a.value) * 100) } } });
        case 'blackout': return this.pub({ dev: { display: { blackout: !off } } });
        case 'freeze': return this.pub({ dev: { display: { freeze: !off } } });
        case 'normal': await this.pub({ dev: { display: { blackout: false, freeze: false } } }); return this.pub({ dev: { ingest: { testPattern: { enabled: false } } } });
        case 'test': return this.pub({ dev: { ingest: { testPattern: { enabled: String(a.pattern || 'on').toLowerCase() !== 'off' } } } });
        case 'preset': { const p = (this.state.presets || []).find(x => String(x.id) === String(a.preset) || String(x.name).toLowerCase() === String(a.preset).toLowerCase()); return this.api('POST', `/api/v1/presets/${encodeURIComponent(p ? p.id : a.preset)}/apply`); }
        case 'input': return this.pub({ dev: { ingest: { input: String(a.input || '') } } });
        case 'gamma': return this.pub({ dev: { display: { gamma: +a.value || 2.8 } } });
      }
      return super.act(name);
    }
  }

  /* ---------------------------------------------------------- generic DMX / eDMX controlled processor */
  // opts: protocol artnet|sacn, universe, chBright, chPreset, presetStep (DMX value per preset, default 1), chBlackout, chFreeze, chTest
  class LedDmx extends Device {
    start() { this.state.online = true; this.state.info = { note: 'DMX output — no feedback' }; this.changed(); }
    retry() {}
    set(ch, v) { const o = this.cfg.opts || {}; ch = +ch; if (!ch) throw new Error(`${this.cfg.name}: that function has no DMX channel set (Devices ▸ edit)`);
      this.hub.dmx({ protocol: o.protocol === 'sacn' ? 'sacn' : 'artnet', host: this.cfg.host, universe: +o.universe || 0, channel: ch, values: String(clamp(Math.round(v), 0, 255)) }); return { ok: true }; }
    actions() { return CORE; }
    async act(name, a = {}) {
      const o = this.cfg.opts || {}, off = a.on === false || a.on === 'false' || a.on === 0;
      switch (name) {
        case 'brightness': return this.set(o.chBright, pct(a.value) * 255);
        case 'blackout': return this.set(o.chBlackout, off ? 0 : 255);
        case 'freeze': return this.set(o.chFreeze, off ? 0 : 255);
        case 'preset': return this.set(o.chPreset, (+a.preset || 0) * (+o.presetStep || 1));
        case 'test': return this.set(o.chTest, String(a.pattern || '').toLowerCase() === 'off' ? 0 : +a.pattern > 0 ? +a.pattern : 255);
        case 'normal': for (const c of [o.chBlackout, o.chFreeze, o.chTest]) if (+c) this.set(c, 0); return { ok: true };
      }
      return super.act(name);
    }
  }
  return { TYPES, CLASSES: { 'nova-coex': NovaCoex, 'nova-ctrl': NovaCtrl, 'nova-h': NovaH, helios: Helios, 'led-dmx': LedDmx }, novaFrame, BRIGHT, MODELS: NOVA.CONFIG_MODEL };
};
