//go:build windows

// PIXORA.exe — Windows launcher for PIXORA (Booth Productions).
// Starts the PIXORA engine (Node.js + server.js) hidden in the background, opens the controller, and sits in the
// system tray with a menu. Quitting from the tray stops the engine; a Job Object guarantees the engine never
// outlives the launcher, even if the launcher is killed.
package main

import (
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"
	"unsafe"
)

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")
	advapi32 = syscall.NewLazyDLL("advapi32.dll")

	pMessageBoxW         = user32.NewProc("MessageBoxW")
	pRegisterClassExW    = user32.NewProc("RegisterClassExW")
	pCreateWindowExW     = user32.NewProc("CreateWindowExW")
	pDefWindowProcW      = user32.NewProc("DefWindowProcW")
	pGetMessageW         = user32.NewProc("GetMessageW")
	pTranslateMessage    = user32.NewProc("TranslateMessage")
	pDispatchMessageW    = user32.NewProc("DispatchMessageW")
	pPostQuitMessage     = user32.NewProc("PostQuitMessage")
	pPostMessageW        = user32.NewProc("PostMessageW")
	pCreatePopupMenu     = user32.NewProc("CreatePopupMenu")
	pAppendMenuW         = user32.NewProc("AppendMenuW")
	pTrackPopupMenu      = user32.NewProc("TrackPopupMenu")
	pDestroyMenu         = user32.NewProc("DestroyMenu")
	pSetForegroundWindow = user32.NewProc("SetForegroundWindow")
	pGetCursorPos        = user32.NewProc("GetCursorPos")
	pLoadImageW          = user32.NewProc("LoadImageW")
	pRegisterWindowMsgW  = user32.NewProc("RegisterWindowMessageW")
	pSetMenuDefaultItem  = user32.NewProc("SetMenuDefaultItem")

	pGetModuleHandleW         = kernel32.NewProc("GetModuleHandleW")
	pCreateMutexW             = kernel32.NewProc("CreateMutexW")
	pCreateJobObjectW         = kernel32.NewProc("CreateJobObjectW")
	pSetInformationJobObject  = kernel32.NewProc("SetInformationJobObject")
	pAssignProcessToJobObject = kernel32.NewProc("AssignProcessToJobObject")
	pOpenProcess              = kernel32.NewProc("OpenProcess")

	pShellNotifyIconW = shell32.NewProc("Shell_NotifyIconW")
	pShellExecuteW    = shell32.NewProc("ShellExecuteW")

	pRegOpenKeyExW    = advapi32.NewProc("RegOpenKeyExW")
	pRegSetValueExW   = advapi32.NewProc("RegSetValueExW")
	pRegDeleteValueW  = advapi32.NewProc("RegDeleteValueW")
	pRegQueryValueExW = advapi32.NewProc("RegQueryValueExW")
	pRegCloseKey      = advapi32.NewProc("RegCloseKey")
)

const (
	MB_OK = 0x0; MB_OKCANCEL = 0x1; MB_YESNO = 0x4; MB_ICONERROR = 0x10; MB_ICONWARNING = 0x30; MB_ICONINFO = 0x40; MB_SETFOREGROUND = 0x10000
	IDOK = 1; IDYES = 6

	WM_DESTROY = 0x0002; WM_COMMAND = 0x0111; WM_APP = 0x8000; WM_CLOSE = 0x0010
	WM_LBUTTONDBLCLK = 0x0203; WM_RBUTTONUP = 0x0205; WM_LBUTTONUP = 0x0202
	WM_TRAY = WM_APP + 1; WM_ENGINE_DIED = WM_APP + 2

	NIM_ADD = 0; NIM_MODIFY = 1; NIM_DELETE = 2
	NIF_MESSAGE = 1; NIF_ICON = 2; NIF_TIP = 4; NIF_INFO = 0x10
	NIIF_INFO = 1; NIIF_WARNING = 2

	MF_STRING = 0; MF_SEPARATOR = 0x800; MF_CHECKED = 0x8; MF_GRAYED = 0x1
	TPM_RIGHTBUTTON = 0x2; TPM_RETURNCMD = 0x100; TPM_BOTTOMALIGN = 0x20

	IMAGE_ICON = 1; LR_LOADFROMFILE = 0x10; LR_DEFAULTSIZE = 0x40

	HKEY_CURRENT_USER = 0x80000001; KEY_ALL_ACCESS = 0xF003F; REG_SZ = 1
	CREATE_NO_WINDOW = 0x08000000
	JobObjectExtendedLimitInformation = 9; JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x2000
	PROCESS_SET_QUOTA = 0x0100; PROCESS_TERMINATE = 0x0001
	ERROR_ALREADY_EXISTS = 183
)

const (
	cmdController = 1 + iota
	cmdOutput
	cmdManual
	cmdMedia
	cmdLog
	cmdFolder
	cmdAutostart
	cmdRestart
	cmdShortcuts
	cmdQuit
)

type POINT struct{ X, Y int32 }
type MSG struct {
	Hwnd    uintptr
	Message uint32
	WParam  uintptr
	LParam  uintptr
	Time    uint32
	Pt      POINT
	Private uint32
}
type WNDCLASSEXW struct {
	CbSize        uint32
	Style         uint32
	LpfnWndProc   uintptr
	CbClsExtra    int32
	CbWndExtra    int32
	HInstance     uintptr
	HIcon         uintptr
	HCursor       uintptr
	HbrBackground uintptr
	LpszMenuName  *uint16
	LpszClassName *uint16
	HIconSm       uintptr
}
type GUID struct {
	Data1 uint32
	Data2 uint16
	Data3 uint16
	Data4 [8]byte
}
type NOTIFYICONDATAW struct {
	CbSize           uint32
	HWnd             uintptr
	UID              uint32
	UFlags           uint32
	UCallbackMessage uint32
	HIcon            uintptr
	SzTip            [128]uint16
	DwState          uint32
	DwStateMask      uint32
	SzInfo           [256]uint16
	UVersion         uint32
	SzInfoTitle      [64]uint16
	DwInfoFlags      uint32
	GuidItem         GUID
	HBalloonIcon     uintptr
}
type IO_COUNTERS struct{ R, W, O, RB, WB, OB uint64 }
type JOBOBJECT_BASIC_LIMIT_INFORMATION struct {
	PerProcessUserTimeLimit int64
	PerJobUserTimeLimit     int64
	LimitFlags              uint32
	MinimumWorkingSetSize   uintptr
	MaximumWorkingSetSize   uintptr
	ActiveProcessLimit      uint32
	Affinity                uintptr
	PriorityClass           uint32
	SchedulingClass         uint32
}
type JOBOBJECT_EXTENDED_LIMIT_INFORMATION struct {
	Basic                 JOBOBJECT_BASIC_LIMIT_INFORMATION
	Io                    IO_COUNTERS
	ProcessMemoryLimit    uintptr
	JobMemoryLimit        uintptr
	PeakProcessMemoryUsed uintptr
	PeakJobMemoryUsed     uintptr
}

func u16(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }
func copyU16(dst []uint16, s string) {
	r, _ := syscall.UTF16FromString(s)
	if len(r) > len(dst) { r = r[:len(dst)-1]; r = append(r, 0) }
	copy(dst, r)
}

func msgBox(text string, flags uintptr) int {
	r, _, _ := pMessageBoxW.Call(0, uintptr(unsafe.Pointer(u16(text))), uintptr(unsafe.Pointer(u16("PIXORA"))), flags|MB_SETFOREGROUND)
	return int(r)
}

func shellOpen(target string, args string) {
	var a uintptr
	if args != "" { a = uintptr(unsafe.Pointer(u16(args))) }
	pShellExecuteW.Call(0, uintptr(unsafe.Pointer(u16("open"))), uintptr(unsafe.Pointer(u16(target))), a, 0, 1)
}

/* ---------- paths & settings ---------- */
var (
	exeDir, appDir, dataDir, mediaDir, logDir, logPath string
	port                                              = 8080
	pin, mediaDirs                                    string
	baseURL                                           string
)

func setupPaths() {
	exe, _ := os.Executable()
	exeDir = filepath.Dir(exe)
	appDir = filepath.Join(exeDir, "app")
	appdata := os.Getenv("APPDATA")
	local := os.Getenv("LOCALAPPDATA")
	if local == "" { local = appdata }
	home, _ := os.UserHomeDir()
	dataDir = filepath.Join(appdata, "PIXORA", "data")
	logDir = filepath.Join(local, "PIXORA")
	logPath = filepath.Join(logDir, "pixora.log")
	mediaDir = filepath.Join(home, "Videos", "PIXORA")
	// optional settings file: %APPDATA%\PIXORA\launcher.conf  (PORT=, PIN=, MEDIA_DIRS=, MEDIA_DIR=)
	if b, err := os.ReadFile(filepath.Join(appdata, "PIXORA", "launcher.conf")); err == nil {
		for _, line := range strings.Split(string(b), "\n") {
			kv := strings.SplitN(strings.TrimSpace(line), "=", 2)
			if len(kv) != 2 || strings.HasPrefix(kv[0], "#") { continue }
			v := strings.Trim(strings.TrimSpace(kv[1]), `"'`)
			switch strings.ToUpper(strings.TrimSpace(kv[0])) {
			case "PORT": if p, err := strconv.Atoi(v); err == nil && p > 0 && p < 65536 { port = p }
			case "PIN": pin = v
			case "MEDIA_DIRS": mediaDirs = v
			case "MEDIA_DIR": if v != "" { mediaDir = v }
			}
		}
	}
	for _, d := range []string{dataDir, logDir, mediaDir} { os.MkdirAll(d, 0755) }
	baseURL = fmt.Sprintf("http://localhost:%d", port)
}

/* ---------- Node.js discovery ---------- */
func findNode() string {
	cands := []string{
		filepath.Join(exeDir, "node", "node.exe"), // optional bundled runtime next to PIXORA.exe
		filepath.Join(exeDir, "runtime", "node.exe"),
	}
	if p, err := exec.LookPath("node.exe"); err == nil { cands = append(cands, p) }
	for _, env := range []string{"ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA"} {
		if v := os.Getenv(env); v != "" {
			cands = append(cands, filepath.Join(v, "nodejs", "node.exe"), filepath.Join(v, "Programs", "nodejs", "node.exe"))
		}
	}
	if v := os.Getenv("NVM_SYMLINK"); v != "" { cands = append(cands, filepath.Join(v, "node.exe")) }
	if v := os.Getenv("VOLTA_HOME"); v != "" { cands = append(cands, filepath.Join(v, "bin", "node.exe")) }
	for _, c := range cands {
		if st, err := os.Stat(c); err == nil && !st.IsDir() { return c }
	}
	return ""
}

func nodeMajor(node string) int {
	cmd := exec.Command(node, "-p", "process.versions.node.split('.')[0]")
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: CREATE_NO_WINDOW}
	out, err := cmd.Output()
	if err != nil { return 0 }
	n, _ := strconv.Atoi(strings.TrimSpace(string(out)))
	return n
}

/* ---------- engine ---------- */
var (
	engineMu   sync.Mutex
	engine     *exec.Cmd
	job        uintptr
	quitting   bool
	nodePath   string
	mainHwnd   uintptr
)

func pixoraRunning() bool {
	c := http.Client{Timeout: 800 * time.Millisecond}
	r, err := c.Get(baseURL + "/api/info")
	if err != nil { return false }
	defer r.Body.Close()
	b, _ := io.ReadAll(io.LimitReader(r.Body, 4096))
	return strings.Contains(string(b), `"pinRequired"`)
}
func portBusy() bool {
	c := http.Client{Timeout: 800 * time.Millisecond}
	r, err := c.Get(baseURL + "/")
	if err != nil { return false }
	r.Body.Close()
	return true
}

func makeJob() {
	j, _, _ := pCreateJobObjectW.Call(0, 0)
	if j == 0 { return }
	var info JOBOBJECT_EXTENDED_LIMIT_INFORMATION
	info.Basic.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
	pSetInformationJobObject.Call(j, JobObjectExtendedLimitInformation, uintptr(unsafe.Pointer(&info)), unsafe.Sizeof(info))
	job = j
}

func startEngine() error {
	engineMu.Lock()
	defer engineMu.Unlock()
	if engine != nil { return nil }
	lf, err := os.OpenFile(logPath, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
	if err != nil { return err }
	fmt.Fprintf(lf, "---- PIXORA start %s · %s · port %d\r\n", time.Now().Format(time.RFC3339), nodePath, port)
	cmd := exec.Command(nodePath, filepath.Join(appDir, "server.js"))
	cmd.Dir = appDir
	cmd.Stdout, cmd.Stderr = lf, lf
	env := append(os.Environ(), "PORT="+strconv.Itoa(port), "DATA_DIR="+dataDir, "MEDIA_DIR="+mediaDir, "PIXORA_NO_BROWSER=1", "PIXORA_LAUNCHER=1")
	if pin != "" { env = append(env, "PIN="+pin) }
	if mediaDirs != "" { env = append(env, "MEDIA_DIRS="+mediaDirs) }
	// make winget/choco/scoop ffmpeg installs visible even if PATH wasn't refreshed for this session
	extra := []string{}
	for _, d := range []string{filepath.Join(exeDir, "ffmpeg", "bin"), filepath.Join(os.Getenv("ProgramFiles"), "ffmpeg", "bin"), `C:\ffmpeg\bin`, filepath.Join(os.Getenv("LOCALAPPDATA"), "Microsoft", "WinGet", "Links"), filepath.Join(os.Getenv("USERPROFILE"), "scoop", "shims"), `C:\ProgramData\chocolatey\bin`} {
		if st, err := os.Stat(d); err == nil && st.IsDir() { extra = append(extra, d) }
	}
	if len(extra) > 0 { env = append(env, "PATH="+strings.Join(extra, ";")+";"+os.Getenv("PATH")) }
	cmd.Env = env
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: CREATE_NO_WINDOW}
	if err := cmd.Start(); err != nil { lf.Close(); return err }
	if job != 0 {
		if h, _, _ := pOpenProcess.Call(PROCESS_SET_QUOTA|PROCESS_TERMINATE, 0, uintptr(cmd.Process.Pid)); h != 0 {
			pAssignProcessToJobObject.Call(job, h)
			syscall.CloseHandle(syscall.Handle(h))
		}
	}
	engine = cmd
	go func(c *exec.Cmd, f *os.File) {
		c.Wait()
		f.Close()
		engineMu.Lock()
		if engine == c { engine = nil }
		q := quitting
		engineMu.Unlock()
		if !q && c.ProcessState != nil && c.ProcessState.ExitCode() == 75 { // engine installed an update: restart it quietly
			time.Sleep(300 * time.Millisecond)
			if startEngine() == nil { go func() { if waitReady(20 * time.Second) { balloon("PIXORA updated", "The new version is running.", false) } }(); return }
		}
		if !q && mainHwnd != 0 { pPostMessageW.Call(mainHwnd, WM_ENGINE_DIED, 0, 0) }
	}(cmd, lf)
	return nil
}

func stopEngine() {
	engineMu.Lock()
	c := engine
	engine = nil
	engineMu.Unlock()
	if c != nil && c.Process != nil {
		c.Process.Kill()
		done := make(chan struct{})
		go func() { c.Wait(); close(done) }()
		select { case <-done: case <-time.After(3 * time.Second): }
	}
}

func waitReady(d time.Duration) bool {
	end := time.Now().Add(d)
	for time.Now().Before(end) {
		if pixoraRunning() { return true }
		time.Sleep(250 * time.Millisecond)
	}
	return false
}

/* ---------- browser ---------- */
func openAppWindow(url string) {
	pf, pf86, la := os.Getenv("ProgramFiles"), os.Getenv("ProgramFiles(x86)"), os.Getenv("LOCALAPPDATA")
	for _, b := range []string{
		filepath.Join(pf, `Google\Chrome\Application\chrome.exe`), filepath.Join(pf86, `Google\Chrome\Application\chrome.exe`), filepath.Join(la, `Google\Chrome\Application\chrome.exe`),
		filepath.Join(pf86, `Microsoft\Edge\Application\msedge.exe`), filepath.Join(pf, `Microsoft\Edge\Application\msedge.exe`),
	} {
		if _, err := os.Stat(b); err == nil {
			c := exec.Command(b, "--app="+url, "--autoplay-policy=no-user-gesture-required")
			if c.Start() == nil { go c.Wait(); return }
		}
	}
	shellOpen(url, "")
}

/* ---------- start with Windows ---------- */
const runKey = `Software\Microsoft\Windows\CurrentVersion\Run`

func regRun() (uintptr, bool) {
	var h uintptr
	r, _, _ := pRegOpenKeyExW.Call(HKEY_CURRENT_USER, uintptr(unsafe.Pointer(u16(runKey))), 0, KEY_ALL_ACCESS, uintptr(unsafe.Pointer(&h)))
	return h, r == 0
}
func autostartOn() bool {
	h, ok := regRun()
	if !ok { return false }
	defer pRegCloseKey.Call(h)
	var typ, size uint32
	r, _, _ := pRegQueryValueExW.Call(h, uintptr(unsafe.Pointer(u16("PIXORA"))), 0, uintptr(unsafe.Pointer(&typ)), 0, uintptr(unsafe.Pointer(&size)))
	return r == 0
}
func setAutostart(on bool) {
	h, ok := regRun()
	if !ok { return }
	defer pRegCloseKey.Call(h)
	if on {
		exe, _ := os.Executable()
		v, _ := syscall.UTF16FromString(`"` + exe + `" --background`)
		pRegSetValueExW.Call(h, uintptr(unsafe.Pointer(u16("PIXORA"))), 0, REG_SZ, uintptr(unsafe.Pointer(&v[0])), uintptr(len(v)*2))
	} else {
		pRegDeleteValueW.Call(h, uintptr(unsafe.Pointer(u16("PIXORA"))))
	}
}

/* ---------- shortcuts (desktop + Start menu) via the WScript.Shell COM object ---------- */
func makeShortcuts() bool {
	exe, _ := os.Executable()
	q := func(v string) string { return "'" + strings.ReplaceAll(v, "'", "''") + "'" }
	ps := "$w=New-Object -ComObject WScript.Shell;" +
		"foreach($d in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))){" +
		"$s=$w.CreateShortcut((Join-Path $d 'PIXORA.lnk'));$s.TargetPath=" + q(exe) + ";$s.WorkingDirectory=" + q(exeDir) +
		";$s.IconLocation=" + q(exe+",0") + ";$s.Description='PIXORA media server';$s.Save()}"
	c := exec.Command("powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", ps)
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: CREATE_NO_WINDOW}
	return c.Run() == nil
}

/* ---------- tray ---------- */
var (
	nid             NOTIFYICONDATAW
	taskbarCreated  uintptr
	hIcon           uintptr
)

func loadIcon() uintptr {
	hInst, _, _ := pGetModuleHandleW.Call(0)
	// resource ID 1 (embedded via the .syso), then PIXORA.ico next to the exe
	if h, _, _ := pLoadImageW.Call(hInst, 1, IMAGE_ICON, 32, 32, 0); h != 0 { return h }
	if h, _, _ := pLoadImageW.Call(0, uintptr(unsafe.Pointer(u16(filepath.Join(exeDir, "PIXORA.ico")))), IMAGE_ICON, 32, 32, LR_LOADFROMFILE); h != 0 { return h }
	return 0
}

func trayAdd() {
	nid = NOTIFYICONDATAW{}
	nid.CbSize = uint32(unsafe.Sizeof(nid))
	nid.HWnd = mainHwnd
	nid.UID = 1
	nid.UFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP
	nid.UCallbackMessage = WM_TRAY
	nid.HIcon = hIcon
	copyU16(nid.SzTip[:], fmt.Sprintf("PIXORA — port %d", port))
	pShellNotifyIconW.Call(NIM_ADD, uintptr(unsafe.Pointer(&nid)))
}
func balloon(title, text string, warn bool) {
	n := nid
	n.UFlags = NIF_INFO
	copyU16(n.SzInfoTitle[:], title)
	copyU16(n.SzInfo[:], text)
	n.DwInfoFlags = NIIF_INFO
	if warn { n.DwInfoFlags = NIIF_WARNING }
	pShellNotifyIconW.Call(NIM_MODIFY, uintptr(unsafe.Pointer(&n)))
}

func showMenu(hwnd uintptr) {
	m, _, _ := pCreatePopupMenu.Call()
	add := func(id int, text string, flags uintptr) { pAppendMenuW.Call(m, flags, uintptr(id), uintptr(unsafe.Pointer(u16(text)))) }
	running := pixoraRunning()
	st := "PIXORA — engine running on port " + strconv.Itoa(port)
	if !running { st = "PIXORA — engine stopped" }
	add(0, st, MF_GRAYED)
	pAppendMenuW.Call(m, MF_SEPARATOR, 0, 0)
	add(cmdController, "Open controller", MF_STRING)
	add(cmdOutput, "Open output window", MF_STRING)
	add(cmdManual, "Open manual", MF_STRING)
	pAppendMenuW.Call(m, MF_SEPARATOR, 0, 0)
	add(cmdMedia, "Show media folder", MF_STRING)
	add(cmdFolder, "Show data folder", MF_STRING)
	add(cmdLog, "Show log", MF_STRING)
	pAppendMenuW.Call(m, MF_SEPARATOR, 0, 0)
	var f uintptr = MF_STRING
	if autostartOn() { f |= MF_CHECKED }
	add(cmdAutostart, "Start with Windows", f)
	add(cmdShortcuts, "Add desktop && Start menu shortcuts", MF_STRING)
	add(cmdRestart, "Restart engine", MF_STRING)
	add(cmdQuit, "Stop PIXORA and quit", MF_STRING)
	pSetMenuDefaultItem.Call(m, cmdController, 0)
	var pt POINT
	pGetCursorPos.Call(uintptr(unsafe.Pointer(&pt)))
	pSetForegroundWindow.Call(hwnd)
	id, _, _ := pTrackPopupMenu.Call(m, TPM_RIGHTBUTTON|TPM_RETURNCMD|TPM_BOTTOMALIGN, uintptr(pt.X), uintptr(pt.Y), 0, hwnd, 0)
	pDestroyMenu.Call(m)
	pPostMessageW.Call(hwnd, 0, 0, 0) // WM_NULL: lets the menu close properly (documented TrackPopupMenu quirk)
	if id != 0 { doCommand(int(id)) }
}

func doCommand(id int) {
	switch id {
	case cmdController: openAppWindow(baseURL + "/")
	case cmdOutput: openAppWindow(baseURL + "/output")
	case cmdManual: shellOpen(baseURL+"/manual/", "")
	case cmdMedia: shellOpen(mediaDir, "")
	case cmdFolder: shellOpen(filepath.Dir(dataDir), "")
	case cmdLog: shellOpen("notepad.exe", `"`+logPath+`"`)
	case cmdAutostart: setAutostart(!autostartOn())
	case cmdRestart:
		go func() {
			stopEngine()
			if err := startEngine(); err == nil && waitReady(15*time.Second) { balloon("PIXORA", "Engine restarted", false) } else { balloon("PIXORA", "Engine failed to restart — see the log", true) }
		}()
	case cmdShortcuts: go func() { if makeShortcuts() { balloon("PIXORA", "Shortcuts added to the desktop and Start menu", false) } }()
	case cmdQuit: pPostMessageW.Call(mainHwnd, WM_CLOSE, 0, 0)
	}
}

func wndProc(hwnd, msg, wparam, lparam uintptr) uintptr {
	switch {
	case msg == WM_TRAY:
		switch lparam & 0xFFFF {
		case WM_RBUTTONUP: showMenu(hwnd)
		case WM_LBUTTONDBLCLK: openAppWindow(baseURL + "/")
		}
		return 0
	case msg == WM_ENGINE_DIED:
		balloon("PIXORA engine stopped", "The engine exited unexpectedly. Right-click the tray icon ▸ Restart engine, or Show log.", true)
		return 0
	case msg == WM_CLOSE:
		engineMu.Lock(); quitting = true; engineMu.Unlock()
		stopEngine()
		pShellNotifyIconW.Call(NIM_DELETE, uintptr(unsafe.Pointer(&nid)))
		pPostQuitMessage.Call(0)
		return 0
	case msg == WM_DESTROY:
		pPostQuitMessage.Call(0)
		return 0
	case taskbarCreated != 0 && msg == taskbarCreated: // Explorer restarted → re-add the icon
		trayAdd()
		return 0
	}
	r, _, _ := pDefWindowProcW.Call(hwnd, msg, wparam, lparam)
	return r
}

func main() {
	runtime.LockOSThread()
	setupPaths()
	background := len(os.Args) > 1 && os.Args[1] == "--background"

	// one launcher per user session; a second double-click just opens the controller
	if _, _, e := pCreateMutexW.Call(0, 0, uintptr(unsafe.Pointer(u16("Local\\PIXORA-Launcher")))); e == syscall.Errno(ERROR_ALREADY_EXISTS) {
		openAppWindow(baseURL + "/")
		return
	}
	if pixoraRunning() { // started some other way (start.ps1, Docker…) — just open it
		openAppWindow(baseURL + "/")
		return
	}
	if portBusy() {
		msgBox(fmt.Sprintf("Port %d is already used by another program, so PIXORA can't start.\n\nTo use another port, create the file\n%%APPDATA%%\\PIXORA\\launcher.conf\ncontaining the line:  PORT=8090", port), MB_ICONERROR)
		return
	}
	if _, err := os.Stat(filepath.Join(appDir, "server.js")); err != nil {
		msgBox("PIXORA can't find its app folder.\n\nIf you opened PIXORA.exe straight from the zip, right-click the zip ▸ Extract All… first, then run PIXORA.exe from the extracted folder.\n\nPIXORA.exe must stay next to the \"app\" folder.", MB_ICONERROR)
		return
	}
	nodePath = findNode()
	if nodePath == "" || nodeMajor(nodePath) < 18 {
		if msgBox("PIXORA needs Node.js (free) to run its video engine.\n\nClick OK to open the download page, install the Windows LTS version, then start PIXORA again.", MB_OKCANCEL|MB_ICONINFO) == IDOK {
			shellOpen("https://nodejs.org/en/download", "")
		}
		return
	}
	if _, err := exec.LookPath("ffmpeg.exe"); err != nil {
		tip := filepath.Join(filepath.Dir(dataDir), ".ffmpeg-tip")
		if _, e := os.Stat(tip); e != nil {
			os.WriteFile(tip, []byte("shown"), 0644)
			msgBox("Tip: MP4, MOV (H.264) and WebM play straight away.\n\nTo also play AVI, WMV, MPEG-2, ProRes and MXF files, install ffmpeg (free). In a terminal:\n    winget install Gyan.FFmpeg\nthen restart PIXORA.", MB_ICONINFO)
		}
	}

	// first run: offer shortcuts so PIXORA can be started like any installed program
	if mark := filepath.Join(filepath.Dir(dataDir), ".shortcut-asked"); !background {
		if _, e := os.Stat(mark); e != nil {
			os.WriteFile(mark, []byte("asked"), 0644)
			if msgBox("Add PIXORA to your desktop and Start menu?\n\n(Keep this PIXORA folder where it is — for example move it to Documents or C:\\PIXORA first — because the shortcuts point here.)", MB_YESNO|MB_ICONINFO) == IDYES {
				makeShortcuts()
			}
		}
	}

	makeJob()
	if err := startEngine(); err != nil {
		msgBox("PIXORA couldn't start the engine:\n"+err.Error(), MB_ICONERROR)
		return
	}

	// hidden window + tray icon
	hInst, _, _ := pGetModuleHandleW.Call(0)
	hIcon = loadIcon()
	cls := u16("PIXORATrayWindow")
	wc := WNDCLASSEXW{LpfnWndProc: syscall.NewCallback(wndProc), HInstance: hInst, LpszClassName: cls, HIcon: hIcon, HIconSm: hIcon}
	wc.CbSize = uint32(unsafe.Sizeof(wc))
	pRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc)))
	mainHwnd, _, _ = pCreateWindowExW.Call(0, uintptr(unsafe.Pointer(cls)), uintptr(unsafe.Pointer(u16("PIXORA"))), 0, 0, 0, 0, 0, 0, 0, hInst, 0)
	taskbarCreated, _, _ = pRegisterWindowMsgW.Call(uintptr(unsafe.Pointer(u16("TaskbarCreated"))))
	trayAdd()

	go func() {
		if waitReady(20 * time.Second) {
			balloon("PIXORA is running", fmt.Sprintf("Port %d · right-click this icon for the output window, manual and more.", port), false)
			if !background { openAppWindow(baseURL + "/") }
		} else {
			balloon("PIXORA couldn't start", "Right-click the tray icon ▸ Show log for details.", true)
		}
	}()

	var m MSG
	for {
		r, _, _ := pGetMessageW.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 { break }
		pTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		pDispatchMessageW.Call(uintptr(unsafe.Pointer(&m)))
	}
	engineMu.Lock(); quitting = true; engineMu.Unlock()
	stopEngine()
}
