# PIXORA.exe (Windows launcher)

A small native tray launcher written in Go. It starts `app/server.js` hidden under Node.js and opens the controller. Its tray menu offers controller, output, manual, folders, log, start-with-Windows, shortcuts, restart and quit. A Job Object makes sure the engine never outlives the launcher.

Build it (from any OS; Go cross-compiles):

    python3 mkres.py icon_win.png rsrc_windows_amd64.syso 1.1.0   # icon + manifest + version info
    GOOS=windows GOARCH=amd64 go build -trimpath -ldflags "-H=windowsgui -s -w" -o PIXORA.exe .

Package it as:

    PIXORA/PIXORA.exe
    PIXORA/app/            # server.js, public/, package.json
    PIXORA/node/node.exe   # optional, for a no-install build

For NDI, use the Electron app in `desktop/` instead (`npm run dist:win`).
