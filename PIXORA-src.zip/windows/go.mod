module pixora-launcher

go 1.22
