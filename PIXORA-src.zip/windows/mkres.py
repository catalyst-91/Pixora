"""Build a Go-linkable COFF resource object (rsrc_windows_amd64.syso) holding the app icon, a manifest and
version info, so PIXORA.exe shows the PIXORA icon in Explorer and proper details in File ▸ Properties."""
import struct, io, sys
from PIL import Image

ICON_PNG, OUT, VER = sys.argv[1], sys.argv[2], sys.argv[3]  # e.g. 1.1.0

# ---- icon images: classic DIB for small sizes (max compatibility), PNG for 256
def dib(img):
    w, h = img.size
    px = img.convert('RGBA').transpose(Image.FLIP_TOP_BOTTOM).tobytes('raw', 'BGRA')
    mask_row = ((w + 31) // 32) * 4
    hdr = struct.pack('<IiiHHIIiiII', 40, w, h * 2, 1, 32, 0, len(px) + mask_row * h, 0, 0, 0, 0)
    return hdr + px + b'\0' * (mask_row * h)
src = Image.open(ICON_PNG).convert('RGBA')
images = []
for s in (16, 20, 24, 32, 40, 48, 64, 96, 128):
    images.append((s, dib(src.resize((s, s), Image.LANCZOS))))
b = io.BytesIO(); src.resize((256, 256), Image.LANCZOS).save(b, 'PNG'); images.append((256, b.getvalue()))

def grp_icon():
    out = struct.pack('<HHH', 0, 1, len(images))
    for i, (s, data) in enumerate(images):
        out += struct.pack('<BBBBHHIH', s if s < 256 else 0, s if s < 256 else 0, 0, 0, 1, 32, len(data), i + 1)
    return out

manifest = f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<assembly xmlns="urn:schemas-microsoft-com:asm.v1" manifestVersion="1.0">
  <assemblyIdentity type="win32" name="BoothProductions.PIXORA" version="{VER}.0" processorArchitecture="amd64"/>
  <description>PIXORA</description>
  <dependency><dependentAssembly><assemblyIdentity type="win32" name="Microsoft.Windows.Common-Controls" version="6.0.0.0" processorArchitecture="*" publicKeyToken="6595b64144ccf1df" language="*"/></dependentAssembly></dependency>
  <trustInfo xmlns="urn:schemas-microsoft-com:asm.v3"><security><requestedPrivileges><requestedExecutionLevel level="asInvoker" uiAccess="false"/></requestedPrivileges></security></trustInfo>
  <compatibility xmlns="urn:schemas-microsoft-com:compatibility.v1"><application><supportedOS Id="{{8e0f7a12-bfb3-4fe8-b9a5-48fd50a15a9a}}"/></application></compatibility>
  <application xmlns="urn:schemas-microsoft-com:asm.v3"><windowsSettings>
    <dpiAware xmlns="http://schemas.microsoft.com/SMI/2005/WindowsSettings">true/pm</dpiAware>
    <dpiAwareness xmlns="http://schemas.microsoft.com/SMI/2016/WindowsSettings">PerMonitorV2</dpiAwareness>
  </windowsSettings></application>
</assembly>'''.encode('utf-8')

# ---- VS_VERSIONINFO
def pad4(b): return b + b'\0' * ((4 - len(b) % 4) % 4)
def wstr(s): return (s + '\0').encode('utf-16-le')
def node(key, value=b'', children=(), vtype=1):
    vlen = len(value) // 2 if vtype == 1 else len(value)
    blob = pad4(struct.pack('<HHH', 0, vlen, vtype) + wstr(key)) + value
    if children: blob = pad4(blob) + b''.join(pad4(c) for c in children[:-1]) + children[-1]
    return struct.pack('<H', len(blob)) + blob[2:]
vparts = [int(x) for x in (VER.split('.') + ['0', '0', '0'])[:4]]
ms, ls = (vparts[0] << 16) | vparts[1], (vparts[2] << 16) | vparts[3]
ffi = struct.pack('<13I', 0xFEEF04BD, 0x00010000, ms, ls, ms, ls, 0x3F, 0, 0x40004, 1, 0, 0, 0)
strings = {'CompanyName': 'Booth Productions', 'FileDescription': 'PIXORA', 'FileVersion': VER, 'InternalName': 'PIXORA',
           'LegalCopyright': '© Booth Productions', 'OriginalFilename': 'PIXORA.exe', 'ProductName': 'PIXORA', 'ProductVersion': VER}
st = [node(k, wstr(v)) for k, v in strings.items()]
sfi = node('StringFileInfo', children=[node('040904B0', children=st)])
vfi = node('VarFileInfo', children=[node('Translation', struct.pack('<HH', 0x0409, 0x04B0), vtype=0)])
version = node('VS_VERSION_INFO', ffi, [sfi, vfi], vtype=0)

# ---- resource tree: type -> id -> lang(0x409)
res = {3: {i + 1: d for i, (_, d) in enumerate(images)}, 14: {1: grp_icon()}, 16: {1: version}, 24: {1: manifest}}
LANG = 0x0409
dirs, leaves = [], []
# layout: all directory tables first, then data entries, then data
def dir_table(n): return 16 + 8 * n
types = sorted(res)
off = dir_table(len(types))
type_dir_off = {}
for t in types: type_dir_off[t] = off; off += dir_table(len(res[t]))
name_dir_off = {}
for t in types:
    for i in sorted(res[t]): name_dir_off[(t, i)] = off; off += dir_table(1)
entry_off = {}
for t in types:
    for i in sorted(res[t]): entry_off[(t, i)] = off; off += 16
data_off = {}
for t in types:
    for i in sorted(res[t]):
        off = (off + 7) & ~7; data_off[(t, i)] = off; off += len(res[t][i])
buf = bytearray(off); relocs = []
def put_dir(at, entries):
    struct.pack_into('<IIHHHH', buf, at, 0, 0, 0, 0, 0, len(entries))
    for k, (ident, target, is_dir) in enumerate(entries):
        struct.pack_into('<II', buf, at + 16 + 8 * k, ident, target | (0x80000000 if is_dir else 0))
put_dir(0, [(t, type_dir_off[t], True) for t in types])
for t in types:
    put_dir(type_dir_off[t], [(i, name_dir_off[(t, i)], True) for i in sorted(res[t])])
    for i in sorted(res[t]):
        put_dir(name_dir_off[(t, i)], [(LANG, entry_off[(t, i)], False)])
        struct.pack_into('<IIII', buf, entry_off[(t, i)], data_off[(t, i)], len(res[t][i]), 0, 0)
        relocs.append(entry_off[(t, i)])  # OffsetToData is an RVA → ADDR32NB relocation against .rsrc
        buf[data_off[(t, i)]:data_off[(t, i)] + len(res[t][i])] = res[t][i]
raw = bytes(buf)

# ---- COFF object
nsec = 1
hdr_size = 20 + 40 * nsec
raw_ptr = hdr_size
rel_ptr = raw_ptr + len(raw)
sym_ptr = rel_ptr + 10 * len(relocs)
coff = struct.pack('<HHIIIHH', 0x8664, nsec, 0, sym_ptr, 1, 0, 0)
coff += struct.pack('<8sIIIIIIHHI', b'.rsrc\0\0\0', 0, 0, len(raw), raw_ptr, rel_ptr, 0, len(relocs), 0, 0x40000040)
coff += raw
for r in relocs: coff += struct.pack('<IIH', r, 0, 0x0003)  # IMAGE_REL_AMD64_ADDR32NB
coff += struct.pack('<8sIhHBB', b'.rsrc\0\0\0', 0, 1, 0, 3, 0)  # section symbol
coff += struct.pack('<I', 4)  # empty string table
open(OUT, 'wb').write(coff)
print(f'{OUT}: {len(coff)} bytes, {len(images)} icon images, {len(relocs)} resources')
