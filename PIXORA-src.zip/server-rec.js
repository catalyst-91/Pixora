// PIXORA local recording — captures the primary output (video + audio) or audio only, on this computer,
// then finishes the file in the chosen format with the local ffmpeg. Booth Productions.
'use strict';
const fs = require('fs'), fsp = fs.promises, path = require('path'), crypto = require('crypto');
const { spawn, spawnSync } = require('child_process');

/* Each format: what it is, the file it writes, what it needs, and how ffmpeg finishes it from the capture. */
const FORMATS = [
  { id: 'mp4', label: 'MP4 · H.264 + AAC', group: 'video', ext: '.mp4', use: 'Plays everywhere — client previews, socials, phones', enc: ['libx264', 'aac'], native: 'mp4' },
  { id: 'mov-prores', label: 'MOV · ProRes 422 HQ + PCM 24-bit', group: 'video', ext: '.mov', use: 'Editing in Premiere, Final Cut, DaVinci Resolve', enc: ['prores_ks', 'pcm_s24le'] },
  { id: 'mov-hap', label: 'MOV · HAP + PCM', group: 'video', ext: '.mov', use: 'Media-server playback (PIXORA, Resolume)', enc: ['hap', 'pcm_s16le'] },
  { id: 'mkv', label: 'MKV · H.264 + FLAC (lossless audio)', group: 'video', ext: '.mkv', use: 'Archive with lossless sound', enc: ['libx264', 'flac'] },
  { id: 'webm', label: 'WebM · VP9 + Opus', group: 'video', ext: '.webm', use: 'Web pages, small files — no ffmpeg needed', enc: ['libvpx-vp9', 'libopus'], native: 'webm' },
  { id: 'wav', label: 'WAV · 24-bit 48 kHz', group: 'audio', ext: '.wav', use: 'Audio only — lossless, for mixing and archive', enc: ['pcm_s24le'], native: 'wav' },
  { id: 'mp3', label: 'MP3 · 320 kb/s', group: 'audio', ext: '.mp3', use: 'Audio only — small, plays everywhere', enc: ['libmp3lame'] },
  { id: 'flac', label: 'FLAC · lossless', group: 'audio', ext: '.flac', use: 'Audio only — lossless and about half the size of WAV', enc: ['flac'] },
];
const AUDIO_MODES = ['clips', 'clips+input', 'input', 'none'];
const DEFAULTS = { format: 'mp4', audio: 'clips', fps: 30, mbps: 16, folder: '', prefix: 'PIXORA', stopAfter: 0, keepMaster: false, sampleRate: 48000 };

module.exports = function rec(ctx) {
  // ctx: { DATA, LOCAL_MEDIA, FFMPEG, ffmpegOk(), settings, saveSettings(), broadcast(), monitor(), output(), addJob(job) }
  const DEFAULT_DIR = path.join(ctx.LOCAL_MEDIA, 'Recordings');
  const TMP = path.join(ctx.DATA, 'rec-tmp');
  fs.mkdirSync(DEFAULT_DIR, { recursive: true }); fs.mkdirSync(TMP, { recursive: true });
  // leftovers from a crash: keep them (they may be the only copy), just make them visible
  for (const f of fs.readdirSync(TMP)) if (/\.(webm|mp4|f32)(\.part)?$/.test(f)) { try { const to = path.join(DEFAULT_DIR, 'Recovered ' + f.replace(/\.part$/, '').replace(/\.f32$/, '.f32.raw')); fs.renameSync(path.join(TMP, f), to); } catch {} }

  let encoders = null;
  function encoderSet() {
    if (encoders) return encoders; encoders = new Set();
    if (!ctx.ffmpegOk()) return encoders;
    try { const r = spawnSync(ctx.FFMPEG, ['-hide_banner', '-encoders'], { timeout: 8000, encoding: 'utf8', windowsHide: true });
      for (const line of String(r.stdout || '').split('\n')) { const m = /^\s*[VAS][.\w]{5}\s+(\S+)/.exec(line); if (m) encoders.add(m[1]); } } catch {}
    return encoders;
  }
  function available(f) {
    if (!ctx.ffmpegOk()) return f.native ? { ok: true } : { ok: false, why: 'needs ffmpeg' };
    const enc = encoderSet(); const miss = f.enc.filter(e => !enc.has(e));
    if (miss.length && !f.native) return { ok: false, why: 'this ffmpeg has no ' + miss.join(' / ') };
    return { ok: true };
  }
  const formats = () => FORMATS.map(f => Object.assign({ id: f.id, label: f.label, group: f.group, ext: f.ext, use: f.use }, available(f)));
  const prefs = () => Object.assign({}, DEFAULTS, ctx.settings.rec || {});
  function setPrefs(b) {
    const p = prefs();
    if (b.format && FORMATS.some(f => f.id === b.format)) p.format = b.format;
    if (AUDIO_MODES.includes(b.audio)) p.audio = b.audio;
    if (b.fps) p.fps = Math.max(10, Math.min(60, +b.fps | 0));
    if (b.mbps) p.mbps = Math.max(2, Math.min(200, +b.mbps));
    if ('folder' in b) p.folder = String(b.folder || '').trim().slice(0, 500);
    if ('prefix' in b) p.prefix = safeName(b.prefix) || 'PIXORA';
    if ('stopAfter' in b) p.stopAfter = Math.max(0, Math.min(24 * 60, +b.stopAfter || 0));
    if ('keepMaster' in b) p.keepMaster = !!b.keepMaster;
    ctx.settings.rec = p; ctx.saveSettings(); ctx.broadcast({ t: 'recprefs', prefs: p }); return p;
  }
  const safeName = s => String(s || '').replace(/[\\/:*?"<>|\x00-\x1f]/g, '').trim().slice(0, 60);
  const folderOf = p => p.folder ? path.resolve(p.folder.replace(/^~(?=$|[\\/])/, require('os').homedir())) : DEFAULT_DIR;

  const st = { on: false, id: null, format: null, kind: null, audio: null, since: 0, bytes: 0, capture: null, ext: null, sampleRate: 48000, channels: 2, fps: 30, folder: null, base: null, timer: null, finishing: 0, last: null, error: null };
  const view = () => ({ on: st.on && !st.stopping, stopping: st.on && !!st.stopping, id: st.id, format: st.format, kind: st.kind, audio: st.audio, since: st.since, bytes: st.bytes, file: st.base ? path.basename(st.base) + (FORMATS.find(f => f.id === st.format) || {}).ext : null, folder: st.folder, finishing: st.finishing, last: st.last, error: st.error });
  const push = () => ctx.broadcast({ t: 'recstate', rec: view() });

  function stamp() { const d = new Date(), z = n => String(n).padStart(2, '0'); return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())} ${z(d.getHours())}.${z(d.getMinutes())}.${z(d.getSeconds())}`; }
  function uniqueBase(dir, name, ext) { let b = path.join(dir, name), i = 2; while (fs.existsSync(b + ext)) b = path.join(dir, `${name} (${i++})`); return b; }

  function start(cmd = {}) {
    if (st.on && st.stopping) throw new Error('the previous recording is still being saved — try again in a moment');
    if (st.on) return view();
    const p = prefs();
    const fmt = FORMATS.find(f => f.id === (cmd.format || p.format)); if (!fmt) throw new Error('Unknown recording format');
    const av = available(fmt); if (!av.ok) throw new Error(`${fmt.label} ${av.why} — install ffmpeg or pick MP4/WebM/WAV`);
    let audio = AUDIO_MODES.includes(cmd.audio) ? cmd.audio : cmd.audio === true ? 'clips' : p.audio;
    if (fmt.group === 'audio' && audio === 'none') audio = 'clips+input';
    const folder = cmd.folder ? path.resolve(String(cmd.folder)) : folderOf(p);
    try { fs.mkdirSync(folder, { recursive: true }); fs.accessSync(folder, fs.constants.W_OK); } catch (e) { throw new Error('Cannot write to the recording folder ' + folder + ' (' + e.code + ')'); }
    const out = ctx.output(); if (!out) throw new Error('No output window is open to record from');
    const id = crypto.randomBytes(4).toString('hex');
    Object.assign(st, { on: true, stopping: false, id, format: fmt.id, kind: fmt.group, audio, since: Date.now(), bytes: 0, capture: null, ext: null, fps: +cmd.fps || p.fps, folder, error: null,
      base: uniqueBase(folder, `${safeName(cmd.prefix) || p.prefix} ${stamp()}`, fmt.ext), keepMaster: cmd.keepMaster != null ? !!cmd.keepMaster : p.keepMaster });
    // Formats that get re-encoded are captured at a high bitrate so the finished file keeps the detail
    const mbps = fmt.native === 'mp4' || fmt.native === 'webm' ? (+cmd.mbps || p.mbps) : Math.max(+cmd.mbps || p.mbps, 40);
    out.send({ t: 'rec', on: true, id, kind: fmt.group, fps: st.fps, mbps, audio, prefer: fmt.native || (fmt.id === 'mkv' ? 'mp4' : 'webm') });
    clearTimeout(st.timer); const mins = cmd.stopAfter != null ? +cmd.stopAfter : p.stopAfter;
    if (mins > 0) st.timer = setTimeout(() => stop('timer'), mins * 60000);
    ctx.monitor('rec', `recording ${fmt.label} → ${st.base}${fmt.ext}`); push(); return view();
  }
  function stop(why) { clearTimeout(st.timer); st.timer = null; if (!st.on) return view(); st.stopping = true; push(); const out = ctx.output(); if (out) out.send({ t: 'rec', on: false, id: st.id }); else fail('Output window closed during recording'); if (why === 'timer') ctx.monitor('rec', 'auto-stop timer reached'); return view(); }
  function fail(msg) { st.on = false; st.stopping = false; st.error = msg; clearTimeout(st.timer); ctx.broadcast({ t: 'error', msg: 'Recording: ' + msg }); push(); }

  async function chunk(id, ext, buf, q) {
    if (!st.on || id !== st.id) { const e = new Error('not recording'); e.status = 409; throw e; }
    if (!st.capture) { st.ext = ['mp4', 'webm', 'f32'].includes(ext) ? ext : 'webm'; st.capture = path.join(TMP, `${st.id}.${st.ext}`); if (q.sr) st.sampleRate = +q.sr | 0 || 48000; if (q.ch) st.channels = +q.ch | 0 || 2; }
    await fsp.appendFile(st.capture + '.part', buf); st.bytes += buf.length; push();
  }

  async function done(id) {
    if (id !== st.id) return view();
    const job = { fmt: FORMATS.find(f => f.id === st.format), capture: st.capture, ext: st.ext, base: st.base, fps: st.fps, sr: st.sampleRate, ch: st.channels, keepMaster: st.keepMaster };
    st.on = false; st.stopping = false; clearTimeout(st.timer);
    if (!job.capture || !fs.existsSync(job.capture + '.part')) { fail('nothing was captured — click the output window once so the browser allows audio/capture, then try again'); return view(); }
    await fsp.rename(job.capture + '.part', job.capture);
    st.finishing++; push();
    finish(job).then(file => { st.last = { file: path.basename(file), path: file, folder: path.dirname(file), at: Date.now(), bytes: fs.statSync(file).size, format: job.fmt.label }; ctx.monitor('rec', 'saved ' + file); ctx.saved(file); })
      .catch(e => { st.error = String(e.message || e); ctx.broadcast({ t: 'error', msg: 'Recording: ' + st.error }); })
      .finally(() => { st.finishing--; push(); });
    return view();
  }

  /* ---------- finishing: write the WAV header / remux / transcode into the destination folder */
  async function finish(j) {
    const target = j.base + j.fmt.ext;
    if (j.ext === 'f32') return finishAudio(j, target);
    // straight copy: the capture already is the wanted container (and nothing to fix without ffmpeg)
    if (j.fmt.native === j.ext && (j.ext === 'webm' || !ctx.ffmpegOk())) { await move(j.capture, target); return target; }
    if (!ctx.ffmpegOk()) { const t2 = j.base + '.' + j.ext; await move(j.capture, t2); throw new Error('ffmpeg not found — kept the capture as ' + path.basename(t2)); }
    const args = ['-hide_banner', '-y', '-i', j.capture, ...videoArgs(j), target + '.part' + j.fmt.ext];
    await ctx.addJob({ type: 'rec', name: path.basename(target), run: jb => ffmpeg(args, jb) });
    await fsp.rename(target + '.part' + j.fmt.ext, target);
    if (j.keepMaster) await move(j.capture, j.base + ' (master).' + j.ext); else await fsp.unlink(j.capture).catch(() => {});
    return target;
  }
  function videoArgs(j) {
    const r = ['-r', String(j.fps)], even = ['-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2'], ar = ['-ar', '48000'];
    switch (j.fmt.id) {
      case 'mp4': return j.ext === 'mp4' ? ['-c', 'copy', '-movflags', '+faststart', '-f', 'mp4']
        : [...even, ...r, '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '17', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '320k', ...ar, '-movflags', '+faststart', '-f', 'mp4'];
      case 'webm': return [...r, '-c:v', 'libvpx-vp9', '-b:v', '0', '-crf', '24', '-row-mt', '1', '-deadline', 'good', '-cpu-used', '5', '-c:a', 'libopus', '-b:a', '256k', ...ar, '-f', 'webm'];
      case 'mov-prores': return [...even, ...r, '-c:v', 'prores_ks', '-profile:v', '3', '-vendor', 'apl0', '-pix_fmt', 'yuv422p10le', '-c:a', 'pcm_s24le', ...ar, '-f', 'mov'];
      case 'mov-hap': return ['-vf', 'scale=trunc(iw/4)*4:trunc(ih/4)*4', ...r, '-c:v', 'hap', '-format', 'hap', '-c:a', 'pcm_s16le', ...ar, '-f', 'mov'];
      case 'mkv': if (j.ext === 'mp4') return ['-c:v', 'copy', '-c:a', 'flac', ...ar, '-f', 'matroska'];
        return [...even, ...r, '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '16', '-pix_fmt', 'yuv420p', '-c:a', 'flac', ...ar, '-f', 'matroska'];
    }
    throw new Error('not a video format');
  }
  async function finishAudio(j, target) {
    const raw = ['-f', 'f32le', '-ar', String(j.sr), '-ac', String(j.ch), '-i', j.capture];
    if (!ctx.ffmpegOk()) { // WAV without ffmpeg: wrap the float samples in a 32-bit float WAV header
      if (j.fmt.id !== 'wav') throw new Error('ffmpeg needed for ' + j.fmt.label);
      await writeFloatWav(j.capture, target, j.sr, j.ch); await fsp.unlink(j.capture).catch(() => {}); return target;
    }
    const enc = { wav: ['-c:a', 'pcm_s24le', '-f', 'wav'], mp3: ['-c:a', 'libmp3lame', '-b:a', '320k', '-f', 'mp3'], flac: ['-c:a', 'flac', '-compression_level', '5', '-f', 'flac'] }[j.fmt.id];
    const resample = j.sr !== 48000 && j.fmt.id !== 'mp3' ? ['-ar', '48000'] : [];
    await ctx.addJob({ type: 'rec', name: path.basename(target), run: jb => ffmpeg(['-hide_banner', '-y', ...raw, ...resample, ...enc, target + '.part'], jb, fs.statSync(j.capture).size / (4 * j.ch * j.sr)) });
    await fsp.rename(target + '.part', target);
    if (j.keepMaster) await writeFloatWav(j.capture, j.base + ' (master).wav', j.sr, j.ch);
    await fsp.unlink(j.capture).catch(() => {});
    return target;
  }
  async function writeFloatWav(src, dst, sr, ch) {
    const size = fs.statSync(src).size, h = Buffer.alloc(44);
    h.write('RIFF', 0); h.writeUInt32LE(Math.min(0xffffffff, 36 + size), 4); h.write('WAVE', 8); h.write('fmt ', 12); h.writeUInt32LE(16, 16);
    h.writeUInt16LE(3, 20); h.writeUInt16LE(ch, 22); h.writeUInt32LE(sr, 24); h.writeUInt32LE(sr * ch * 4, 28); h.writeUInt16LE(ch * 4, 32); h.writeUInt16LE(32, 34);
    h.write('data', 36); h.writeUInt32LE(Math.min(0xffffffff, size), 40);
    await fsp.writeFile(dst + '.part', h); await new Promise((ok, bad) => fs.createReadStream(src).on('error', bad).pipe(fs.createWriteStream(dst + '.part', { flags: 'a' })).on('error', bad).on('finish', ok));
    await fsp.rename(dst + '.part', dst);
  }
  function ffmpeg(args, jb, knownDur) {
    return new Promise((ok, bad) => {
      const ff = spawn(ctx.FFMPEG, args, { windowsHide: true }); let dur = knownDur || 0, tail = '';
      ff.stderr.on('data', d => { const s = d.toString(); tail = (tail + s).slice(-800);
        const dm = /Duration: (\d+):(\d+):([\d.]+)/.exec(s); if (dm && !dur) dur = +dm[1] * 3600 + +dm[2] * 60 + +dm[3];
        const tm = /time=(\d+):(\d+):([\d.]+)/.exec(s); if (tm && dur && jb) jb.progress(Math.min(0.99, (+tm[1] * 3600 + +tm[2] * 60 + +tm[3]) / dur)); });
      ff.on('error', bad);
      ff.on('close', code => code === 0 ? ok() : bad(new Error('ffmpeg failed: ' + tail.split('\n').filter(Boolean).slice(-2).join(' '))));
    });
  }
  async function move(a, b) { try { await fsp.rename(a, b); } catch (e) { if (e.code !== 'EXDEV') throw e; await fsp.copyFile(a, b); await fsp.unlink(a); } }

  /* ---------- HTTP API + OSC */
  async function http(p, req, res, url, send, readBody) {
    if (!p.startsWith('/api/rec')) return false;
    const q = Object.fromEntries(url.searchParams);
    try {
      if (p === '/api/rec/chunk' && req.method === 'POST') { await chunk(q.id, q.ext, await readBody(req, 64 * 1024 * 1024), q); send(res, 200, { ok: true }); return true; }
      if (p === '/api/rec/done' && req.method === 'POST') { send(res, 200, await done(q.id)); return true; }
      if (p === '/api/rec/formats') { send(res, 200, { formats: formats(), prefs: prefs(), defaultFolder: DEFAULT_DIR, ffmpeg: ctx.ffmpegOk() }); return true; }
      if (p === '/api/rec/prefs' && req.method === 'POST') { send(res, 200, setPrefs(JSON.parse((await readBody(req)).toString() || '{}'))); return true; }
      if (p === '/api/rec/start') { let b = {}; if (req.method === 'POST') { try { b = JSON.parse((await readBody(req)).toString() || '{}'); } catch {} } send(res, 200, start(Object.assign({}, q, b))); return true; }
      if (p === '/api/rec/stop') { send(res, 200, stop()); return true; }
      if (p === '/api/rec/toggle') { send(res, 200, st.on ? (st.stopping ? view() : stop()) : start(q)); return true; }
      if (p === '/api/rec' || p === '/api/rec/status') { send(res, 200, view()); return true; }
    } catch (e) { send(res, e.status || 400, { error: e.message }); return true; }
    return false;
  }
  function osc(addr, args) { // /pixora/rec [1|0] · /pixora/rec/start [format] · /pixora/rec/stop
    const m = /^\/(?:pixora|bvj)\/rec(?:\/(start|stop|toggle))?$/.exec(addr); if (!m) return false;
    const a = args[0];
    try { if (m[1] === 'start') start(typeof a === 'string' ? { format: a } : {}); else if (m[1] === 'stop') stop();
      else if (m[1] === 'toggle' || a === undefined) (st.on ? stop() : start()); else +a > 0 ? start() : stop(); } catch (e) { ctx.broadcast({ t: 'error', msg: 'Recording: ' + e.message }); }
    return true;
  }
  function outputGone(c) { if (st.on && c === ctx.output()) fail('the output window closed while recording — the capture so far is in ' + TMP); }
  function captureError(msg) { if (st.on && /unavailable/.test(msg)) { ctx.broadcast({ t: 'error', msg: 'Recording: ' + msg }); return; } fail(msg); }

  return { FORMATS, formats, prefs, setPrefs, start, stop, done, chunk, view, push, http, osc, outputGone, captureError, get on() { return st.on && !st.stopping; }, DEFAULT_DIR };
};
