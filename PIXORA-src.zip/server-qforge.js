// PIXORA ⇄ QForge — Booth Productions.
// QForge (Booth Productions' show-playback app) fires PIXORA with its PIXORA cue type over OSC (PIXORA OSC in, port 7000).
// This module sends feedback the other way, to QForge's OSC port (53000), so a running PIXORA cue shows the clip's
// progress and can wait for the clip to end before QForge auto-continues:
//   /pixora/fb/layer/<n>   [progress 0–1 (f), remaining s (f), elapsed s (f), clip name (s), playing (i)]   ~5 per second
//   /pixora/fb/ended/<n>   [clip name (s)]                                                            when a clip ends
//   /pixora/fb/cue         [cue number (i), cue name (s)]                                             when the cue changes
//   /pixora/fb/hello       [PIXORA version (s), OSC in port (i)]                                      every few seconds
'use strict';
module.exports = function qforge(ctx) { // ctx: { settings, saveSettings, state (getter), oscMsg, sock(), monitor }
  const cfg = () => (ctx.settings.qforge = Object.assign({ on: false, host: '127.0.0.1', port: 53000 }, ctx.settings.qforge || {}));
  const send = (addr, args) => { const c = cfg(); if (!c.on || !c.host || !c.port) return; try { ctx.sock().send(ctx.oscMsg(addr, args), +c.port, c.host); } catch {} };
  let lastCue = -2, last = [];
  function positions(list) {
    if (!cfg().on) return; const S = ctx.state;
    (list || []).forEach((p, i) => { const L = S.layers[i]; if (!L) return; const c = L.active != null ? (L.activeClip || L.clips[L.active]) : null;
      const item = c && c.type === 'playlist' ? (c.items || [])[c.index || 0] : null, name = item ? item.name : c ? (c.name || c.src || c.type) : '';
      const v = p && p.dur ? [Math.max(0, Math.min(1, p.pos || 0)), Math.max(0, p.dur - (p.t || 0)), Math.max(0, p.t || 0), String(name), L.paused ? 0 : 1] : [0, 0, 0, String(name), c ? 1 : 0];
      const sig = v.map(x => typeof x === 'number' ? Math.round(x * 20) : x).join('|'); if (sig === last[i]) return; last[i] = sig;
      send(`/pixora/fb/layer/${i + 1}`, [+v[0].toFixed(4) + 0.0000001, +v[1].toFixed(2) + 0.0000001, +v[2].toFixed(2) + 0.0000001, v[3], v[4]]); }); // (tiny offset keeps them floats)
    if (S.cueIndex !== lastCue) { lastCue = S.cueIndex; send('/pixora/fb/cue', [S.cueIndex + 1, String((S.cues[S.cueIndex] || {}).name || '')]); }
  }
  function ended(li) { const L = ctx.state.layers[li]; const c = L && L.active != null ? L.clips[L.active] : null; send(`/pixora/fb/ended/${li + 1}`, [String(c ? c.name || c.src || '' : '')]); last[li] = null; }
  setInterval(() => send('/pixora/fb/hello', [String(require('./package.json').version), +process.env.OSC_PORT || 7000]), 5000);
  async function http(p, req, res, url, sendRes, readBody) {
    if (p !== '/api/qforge') return false;
    if (req.method === 'POST') { let b = {}; try { b = JSON.parse((await readBody(req)).toString() || '{}'); } catch {} const c = cfg(); if ('on' in b) c.on = !!b.on; if (b.host) c.host = String(b.host).slice(0, 200); if (b.port) c.port = +b.port; ctx.saveSettings(); last = []; lastCue = -2; ctx.monitor('qforge', c.on ? `feedback to QForge at ${c.host}:${c.port}` : 'QForge feedback off'); }
    sendRes(res, 200, Object.assign({ oscIn: +process.env.OSC_PORT || 7000 }, cfg())); return true;
  }
  return { positions, ended, http, cfg };
};
