// PIXORA — direct Pro DJ Link (no Bridge app needed). Booth Productions.
// Joins the DJ network as a virtual CDJ and listens to the players themselves, following the protocol research
// published by Deep Symmetry (beat-link, https://github.com/Deep-Symmetry/beat-link, EPL-2.0; packet analysis at
// https://djl-analysis.deepsymmetry.org). Independent Node implementation — no beat-link code is included.
//   UDP 50000  device keep-alives (who is on the network; we announce ourselves as a virtual player)
//   UDP 50001  beat packets (tempo, pitch, beat within bar) and CDJ-3000 precise position packets
//   UDP 50002  CDJ status packets (track, play state, master / on-air / sync flags, beat number)
//   TCP 12523 → dbserver: track title / artist / album / key / duration from the player's media (rekordbox)
'use strict';
const dgram = require('dgram'), net = require('net'), os = require('os');
const MAGIC = Buffer.from([0x51, 0x73, 0x70, 0x74, 0x31, 0x57, 0x6d, 0x4a, 0x4f, 0x4c]);
const NEUTRAL = 0x100000;
const num = (b, o, n) => { let v = 0; for (let i = 0; i < n; i++) v = v * 256 + b[o + i]; return v; };
// Pro DJ Link play state → TCNet-style state used by PIXORA's deck model
const PLAY = { 0: 0, 2: 0, 3: 3, 4: 4, 5: 5, 6: 7, 7: 3, 8: 8, 9: 9, 0x11: 6, 0x12: 4 };

/* ---------------- dbserver (track metadata) */
const F = { n1: v => Buffer.from([0x0f, v & 255]), n2: v => { const b = Buffer.alloc(3); b[0] = 0x10; b.writeUInt16BE(v, 1); return b; }, n4: v => { const b = Buffer.alloc(5); b[0] = 0x11; b.writeUInt32BE(v >>> 0, 1); return b; },
  bin: buf => { const b = Buffer.alloc(5); b[0] = 0x14; b.writeUInt32BE(buf.length, 1); return Buffer.concat([b, buf]); } };
function message(txn, type, args) { // args: [['n4', v], ...]
  const tags = Buffer.alloc(12); args.forEach((a, i) => tags[i] = a[0] === 'bin' ? 0x03 : a[0] === 'str' ? 0x02 : 0x06);
  return Buffer.concat([F.n4(0x872349ae), F.n4(txn), F.n2(type), F.n1(args.length), F.bin(tags), ...args.map(([t, v]) => F[t](v))]);
}
function readField(buf, o) { // → [value, next] or null if incomplete
  if (o >= buf.length) return null; const t = buf[o];
  if (t === 0x0f) return o + 2 <= buf.length ? [buf[o + 1], o + 2] : null;
  if (t === 0x10) return o + 3 <= buf.length ? [buf.readUInt16BE(o + 1), o + 3] : null;
  if (t === 0x11) return o + 5 <= buf.length ? [buf.readUInt32BE(o + 1), o + 5] : null;
  if (t === 0x14 || t === 0x26) { if (o + 5 > buf.length) return null; const n = buf.readUInt32BE(o + 1), len = t === 0x26 ? n * 2 : n; if (o + 5 + len > buf.length) return null;
    const raw = buf.subarray(o + 5, o + 5 + len); return [t === 0x26 ? swap16(raw).toString('utf16le').replace(/\0+$/, '') : raw, o + 5 + len]; }
  throw new Error('dbserver: unknown field 0x' + t.toString(16));
}
const swap16 = b => { const c = Buffer.from(b); for (let i = 0; i + 1 < c.length; i += 2) { const x = c[i]; c[i] = c[i + 1]; c[i + 1] = x; } return c; };
function readMessage(buf, o) {
  const f = []; let p = o; for (let i = 0; i < 5; i++) { const r = readField(buf, p); if (!r) return null; f.push(r[0]); p = r[1]; }
  if (f[0] !== 0x872349ae) throw new Error('dbserver: bad message start');
  const args = []; for (let i = 0; i < f[3]; i++) { const r = readField(buf, p); if (!r) return null; args.push(r[0]); p = r[1]; }
  return [{ txn: f[1], type: f[2], args }, p];
}
function dbConnect(ip, timeout = 4000) {
  return new Promise((ok, bad) => { // 1) ask the player which port its dbserver is on
    const q = net.connect({ host: ip, port: 12523 }); q.setTimeout(timeout, () => q.destroy(new Error('dbserver port query timed out')));
    q.on('connect', () => q.write(Buffer.from([0, 0, 0, 0x0f, ...Buffer.from('RemoteDBServer'), 0])));
    q.once('data', d => { q.destroy(); const port = d.length >= 2 ? d.readUInt16BE(d.length - 2) : 0; if (!port || port === 65535) return bad(new Error('dbserver not ready')); ok(port); });
    q.on('error', bad);
  });
}
async function fetchMetadata(ip, posingAs, slot, trackType, rbId) {
  const port = await dbConnect(ip);
  return new Promise((ok, bad) => {
    const s = net.connect({ host: ip, port }); let buf = Buffer.alloc(0), stage = 0, count = 0; const items = [];
    const done = (e, v) => { clearTimeout(t); s.destroy(); e ? bad(e) : ok(v); }; const t = setTimeout(() => done(new Error('dbserver timed out')), 5000);
    const rmst = ((posingAs & 255) << 24 | 1 << 16 | (slot & 255) << 8 | (trackType & 255)) >>> 0;
    s.on('connect', () => s.write(F.n4(1)));
    s.on('error', e => done(e));
    s.on('data', d => {
      buf = Buffer.concat([buf, d]);
      try {
        if (stage === 0) { if (buf.length < 5) return; buf = buf.subarray(5); stage = 1; s.write(message(0xfffffffe, 0x0000, [['n4', posingAs]])); }
        for (;;) {
          const r = readMessage(buf, 0); if (!r) return; const [m, next] = r; buf = buf.subarray(next);
          if (stage === 1) { stage = 2; s.write(message(1, 0x2002, [['n4', rmst], ['n4', rbId]])); }
          else if (stage === 2) { if (m.type !== 0x4000) return done(new Error('track not found on the player')); count = m.args[1] || 0; if (!count) return done(null, {}); stage = 3;
            s.write(message(2, 0x3000, [['n4', rmst], ['n4', 0], ['n4', count], ['n4', 0], ['n4', count], ['n4', 0]])); }
          else if (stage === 3) {
            if (m.type === 0x4101) items.push({ id: m.args[1], label: m.args[3], label2: m.args[5], type: (m.args[6] || 0) & 0xffff });
            if (m.type === 0x4201) { const md = {}; for (const it of items) {
              if (it.type === 0x04) md.title = it.label; else if (it.type === 0x07) md.artist = it.label; else if (it.type === 0x02) md.album = it.label;
              else if (it.type === 0x06) md.genre = it.label; else if (it.type === 0x0f) md.key = it.label; else if (it.type === 0x0e) md.label = it.label;
              else if (it.type === 0x0b) md.duration = it.id; else if (it.type === 0x0d) md.tempo = it.id / 100; else if (it.type === 0x23) md.comment = it.label; }
              s.write(message(0xfffffffe, 0x0100, [])); return done(null, md); }
          }
        }
      } catch (e) { done(e); }
    });
  });
}

/* ---------------- the virtual CDJ */
module.exports = function proDjLink(hooks) {
  // hooks: { deck(i) → deck object, changed(i, kind), monitor(msg), device: () => preferred number }
  const devices = new Map(); // number → {name, ip, number, seen}
  let s0, s1, s2, ka, me = 0, ifaces = [], status = 'off';
  const meta = new Map(), loading = new Set();

  function interfaces() { const out = []; for (const list of Object.values(os.networkInterfaces())) for (const a of list || []) if (a.family === 'IPv4' && !a.internal && a.netmask) {
    const ip = a.address.split('.').map(Number), m = a.netmask.split('.').map(Number); out.push({ ip: a.address, mac: a.mac, bcast: ip.map((x, i) => (x & m[i]) | (~m[i] & 255)).join('.'), net: ip.map((x, i) => x & m[i]).join('.'), mask: m }); }
    return out; }
  function keepAlive(ifc) {
    const b = Buffer.from([0x51, 0x73, 0x70, 0x74, 0x31, 0x57, 0x6d, 0x4a, 0x4f, 0x4c, 0x06, 0x00, ...Buffer.alloc(20), 0x01, 0x02, 0x00, 0x36, 0x00, 0x01, ...Buffer.alloc(16), 0x02, 0x00, 0x00, 0x00, 0x01, 0x64]);
    b.write('PIXORA', 0x0c, 20, 'latin1'); b[0x24] = me;
    String(ifc.mac || '00:00:00:00:00:00').split(':').forEach((h, i) => b[0x26 + i] = parseInt(h, 16) || 0);
    ifc.ip.split('.').forEach((x, i) => b[0x2c + i] = +x); return b;
  }
  function pickNumber() { const want = +hooks.device() || 7; if (!devices.has(want)) return want; for (let n = 7; n <= 15; n++) if (!devices.has(n)) return n; return want; }

  function onAnnounce(b, r) {
    if (b.length < 0x30 || !MAGIC.equals(b.subarray(0, 10)) || b[0x0a] !== 0x06) return;
    const n = b[0x24], name = b.toString('latin1', 0x0c, 0x20).replace(/\0[\s\S]*$/, '').trim(), ip = [...b.subarray(0x2c, 0x30)].join('.');
    if (name === 'PIXORA' && n === me) return;
    if (!devices.has(n)) hooks.monitor(`found ${name} (#${n}) at ${ip}`);
    devices.set(n, { number: n, name, ip, seen: Date.now() });
    if (n === me) { me = pickNumber(); hooks.monitor('another device uses our player number; now #' + me); }
  }
  function onBeat(b) {
    if (b.length < 0x3c || !MAGIC.equals(b.subarray(0, 10))) return;
    const type = b[0x0a], n = b[0x21];
    if (n < 1 || n > 6) return; const d = hooks.deck(n - 1);
    if (type === 0x28 && b.length >= 0x60) { const pitch = num(b, 0x55, 3) / NEUTRAL, bpm = num(b, 0x5a, 2); if (bpm !== 0xffff) d.bpm = bpm / 100 * pitch; d.speed = pitch; d.beat = b[0x5c]; d.beatAt = Date.now(); hooks.changed(n - 1, 'beat'); }
    else if (type === 0x0b) { d.total = num(b, 0x24, 4) * 1000; d.ms = num(b, 0x28, 4); d.rxAt = Date.now(); let p = num(b, 0x2c, 4); if (p > 0x80000000) p -= 0x100000000; d.speed = 1 + p / 10000; d.bpm = num(b, 0x38, 4) / 10; d.precise = true; hooks.changed(n - 1, 'position'); }
  }
  function onStatus(b) {
    if (b.length < 0xd0 || !MAGIC.equals(b.subarray(0, 10)) || b[0x0a] !== 0x0a) return;
    const n = b[0x21]; if (n < 1 || n > 6) return; const d = hooks.deck(n - 1), flags = b[0x89];
    const src = { player: b[0x28], slot: b[0x29], type: b[0x2a], id: num(b, 0x2c, 4) };
    const ps = b[0x7b]; d.state = flags & 0x40 && !(ps === 3 || ps === 4) ? 3 : PLAY[ps] != null ? PLAY[ps] : ps;
    d.syncMaster = !!(flags & 0x20); d.onAir = flags & 0x08 ? 255 : 0; d.synced = !!(flags & 0x10);
    const pitch = num(b, 0x8d, 3) / NEUTRAL, tbpm = num(b, 0x92, 2), beats = Date.now() - (d.beatAt || 0) < 2500; // beat packets win while they're arriving
    if (!beats) { d.speed = pitch || d.speed; if (tbpm !== 0xffff && !d.precise) d.bpm = tbpm / 100 * pitch; } d.trackBpm = tbpm !== 0xffff ? tbpm / 100 : 0;
    const bn = num(b, 0xa0, 4); d.beatNo = bn === 0xffffffff ? 0 : bn; if (!beats) d.beat = b[0xa6] || d.beat;
    if (!d.precise && d.beatNo && d.trackBpm) { d.ms = Math.round((d.beatNo - 1) * 60000 / d.trackBpm); d.rxAt = Date.now(); } // estimate without a beat grid
    const key = `${src.player}:${src.slot}:${src.type}:${src.id}`;
    if (src.id !== d.trackId) { d.trackId = src.id; d.title = d.artist = ''; d.total = d.total && d.precise ? d.total : 0; }
    if (src.id && meta.has(key)) apply(d, meta.get(key));
    else if (src.id && !loading.has(key) && (src.type === 1 || src.type === 2)) {
      const host = devices.get(src.player); if (host) { loading.add(key);
        fetchMetadata(host.ip, src.player, src.slot, src.type, src.id).then(md => { meta.set(key, md); if (d.trackId === src.id) { apply(d, md); hooks.changed(n - 1, 'track'); } hooks.monitor(`deck ${n}: ${md.artist || ''} – ${md.title || ''}`); })
          .catch(e => hooks.monitor(`deck ${n}: no track info (${e.message})`)).finally(() => setTimeout(() => loading.delete(key), 10000)); } }
    hooks.changed(n - 1, beats ? 'track' : 'status');
  }
  const apply = (d, md) => { d.title = md.title || ''; d.artist = md.artist || ''; d.album = md.album || ''; d.keyName = md.key || ''; if (md.duration && !d.precise) d.total = md.duration * 1000; };

  function bind(port, fn, shared = true) { return new Promise(ok => { const s = dgram.createSocket({ type: 'udp4', reuseAddr: shared }); s.on('error', e => { hooks.monitor(`port ${port}: ${e.message}`); status = 'error: port ' + port + ' busy (close rekordbox or other DJ Link software on this computer)'; ok(null); }); s.on('message', fn); s.bind(port, () => { try { s.setBroadcast(true); } catch {} ok(s); }); }); }
  async function start() {
    stop(); [s0, s1, s2] = await Promise.all([bind(50000, onAnnounce), bind(50001, onBeat), bind(50002, onStatus)]);
    if (!s0 || !s1) return; status = 'listening'; me = pickNumber(); ifaces = interfaces();
    const tick = () => { ifaces = interfaces(); for (const i of ifaces) s0.send(keepAlive(i), 50000, i.bcast, () => {});
      for (const [k, v] of devices) if (Date.now() - v.seen > 6000) { devices.delete(k); hooks.monitor(`${v.name} (#${k}) left`); } };
    tick(); ka = setInterval(tick, 1500); hooks.monitor(`virtual CDJ #${me} "PIXORA" on the DJ Link network`);
  }
  function stop() { clearInterval(ka); for (const s of [s0, s1, s2]) try { s && s.close(); } catch {} s0 = s1 = s2 = null; status = 'off'; devices.clear(); }
  return { start, stop, view: () => ({ status, number: me, devices: [...devices.values()].map(d => ({ name: d.name, ip: d.ip, app: d.name, vendor: d.number > 32 ? 'mixer' : 'player #' + d.number, version: '' })) }), _t: { onAnnounce, onBeat, onStatus, fetchMetadata } };
};
