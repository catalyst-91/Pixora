/* PIXORA — saved show versions: named or automatic snapshots of the show per show name, a readable compare between any two
 * versions (or a version and the live show), full restore, and bringing back single items (a clip, a cue, an output…). */
'use strict';
const fs = require('fs'), fsp = fs.promises, path = require('path'), zlib = require('zlib'), crypto = require('crypto');

// state that changes while performing, not editing — never part of a version compare
const VOLATILE = new Set(['active', 'trig', 'trigAt', 'activeClip', 'beatEpoch', 'cueIndex', 'play', 'paused', 'size']);
const LABEL = { comp: 'Composition', layers: 'Layers', outputs: 'Outputs', cues: 'Cues', led: 'LED', decks: 'Decks', feeds: 'Data feeds', rules: 'Rules', schedule: 'Schedule',
  timeline: 'Timeline', shaders: 'Shaders', luts: 'LUTs', presets: 'Looks', mods: 'Modulators', rotation: 'Sponsor rotation', oscOut: 'OSC out', checklist: 'Checklist', react: 'Audio-reactive', genPresets: 'Generator presets' };
const clipName = c => c ? (c.name || c.src || (c.gen && c.gen.kind) || c.type || 'clip') : '';
const short = v => { if (v === undefined) return '—'; if (v === null) return 'none'; if (typeof v === 'object') { const s = JSON.stringify(v); return s.length > 60 ? s.slice(0, 57) + '…' : s; } const s = String(v); return s.length > 60 ? s.slice(0, 57) + '…' : s; };

// field-level differences between two plain values, as [{ path, from, to }]
function fields(a, b, base, out, depth = 0) {
  if (a === b) return out;
  const oa = a && typeof a === 'object', ob = b && typeof b === 'object';
  if (!oa || !ob || Array.isArray(a) !== Array.isArray(b) || depth > 6) { if (JSON.stringify(a) !== JSON.stringify(b)) out.push({ path: base, from: a, to: b }); return out; }
  if (Array.isArray(a) && (a.length !== b.length || a.some(x => x && typeof x === 'object'))) { if (JSON.stringify(a) !== JSON.stringify(b)) out.push({ path: base, from: a, to: b }); return out; }
  for (const k of new Set([...Object.keys(a), ...Object.keys(b)])) { if (VOLATILE.has(k)) continue; fields(a[k], b[k], base ? base + '.' + k : k, out, depth + 1); }
  return out;
}
// list of things keyed by id: added / removed / renamed / changed
function byId(area, A = [], B = [], nameOf, out, pickBase) {
  const ma = new Map(A.filter(Boolean).map(x => [x.id, x])), mb = new Map(B.filter(Boolean).map(x => [x.id, x]));
  for (const [id, x] of ma) if (!mb.has(id)) out.push({ area, kind: 'removed', label: nameOf(x), pick: pickBase + '/' + id });
  for (const [id, y] of mb) if (!ma.has(id)) out.push({ area, kind: 'added', label: nameOf(y), pick: pickBase + '/' + id });
  for (const [id, x] of ma) { const y = mb.get(id); if (!y) continue; const f = fields(x, y, '', []); if (f.length) out.push({ area, kind: 'changed', label: nameOf(y), pick: pickBase + '/' + id, fields: f.slice(0, 40).map(d => ({ path: d.path, from: short(d.from), to: short(d.to) })), more: Math.max(0, f.length - 40) }); }
}
/* compare a → b (older → newer). Each entry: { area, kind: added|removed|changed|moved, label, fields?, pick? } where pick names an item that can be brought back from a */
function diff(a, b) {
  const out = [];
  // composition settings (fx are reported per effect)
  { const ca = Object.assign({}, a.comp, { fx: undefined }), cb = Object.assign({}, b.comp, { fx: undefined }); const f = fields(ca, cb, '', []); if (f.length) out.push({ area: 'comp', kind: 'changed', label: 'Composition settings', fields: f.map(d => ({ path: d.path, from: short(d.from), to: short(d.to) })) }); }
  fxDiff('comp', 'Composition', (a.comp || {}).fx, (b.comp || {}).fx, out, 'comp/fx');
  // layers: by id, then their clip slots and effects
  const la = new Map((a.layers || []).map((l, i) => [l.id, [l, i]])), lb = new Map((b.layers || []).map((l, i) => [l.id, [l, i]]));
  for (const [id, [l]] of la) if (!lb.has(id)) out.push({ area: 'layers', kind: 'removed', label: `Layer “${l.name}” (${(l.clips || []).filter(Boolean).length} clips)`, pick: 'layers/' + id });
  for (const [id, [l, i]] of lb) if (!la.has(id)) out.push({ area: 'layers', kind: 'added', label: `Layer ${i + 1} “${l.name}”` });
  for (const [id, [l0, i0]] of la) { const e = lb.get(id); if (!e) continue; const [l1, i1] = e; const nm = l1.name === `Layer ${i1 + 1}` ? l1.name : `Layer ${i1 + 1} “${l1.name}”`;
    if (i0 !== i1) out.push({ area: 'layers', kind: 'moved', label: `${nm}: position ${i0 + 1} → ${i1 + 1}` });
    const s0 = Object.assign({}, l0, { clips: undefined, fx: undefined }), s1 = Object.assign({}, l1, { clips: undefined, fx: undefined }); const f = fields(s0, s1, '', []);
    if (f.length) out.push({ area: 'layers', kind: 'changed', label: nm + ' settings', pick: 'layers/' + id + '/settings', fields: f.map(d => ({ path: d.path, from: short(d.from), to: short(d.to) })) });
    const n = Math.max((l0.clips || []).length, (l1.clips || []).length);
    for (let k = 0; k < n; k++) { const c0 = (l0.clips || [])[k], c1 = (l1.clips || [])[k], where = `${nm} · slot ${k + 1}`, pick = `layers/${id}/clips/${k}`;
      if (!c0 && !c1) continue;
      if (!c0) out.push({ area: 'layers', kind: 'added', label: `${where}: ${clipName(c1)}`, pick });
      else if (!c1) out.push({ area: 'layers', kind: 'removed', label: `${where}: ${clipName(c0)}`, pick });
      else { const f2 = fields(c0, c1, '', []); if (f2.length) out.push({ area: 'layers', kind: (c0.src || '') !== (c1.src || '') || c0.type !== c1.type ? 'replaced' : 'changed', label: `${where}: ${clipName(c0) === clipName(c1) ? clipName(c1) : clipName(c0) + ' → ' + clipName(c1)}`, pick, fields: f2.slice(0, 30).map(d => ({ path: d.path, from: short(d.from), to: short(d.to) })) }); } }
    fxDiff('layers', nm, l0.fx, l1.fx, out, `layers/${id}/fx`); }
  byId('outputs', a.outputs, b.outputs, o => `Output “${o.name}”`, out, 'outputs');
  byId('cues', a.cues, b.cues, c => `Cue ${c.num != null ? c.num + ' ' : ''}“${c.name || c.label || c.id}”`, out, 'cues');
  byId('shaders', (a.shaders || []).filter(x => !x.builtin), (b.shaders || []).filter(x => !x.builtin), s => `Shader “${s.name}”`, out, 'shaders');
  byId('luts', a.luts, b.luts, l => `LUT “${l.name}”`, out, 'luts');
  byId('presets', a.presets, b.presets, p => `Look “${p.name}”`, out, 'presets');
  byId('feeds', a.feeds, b.feeds, f => `Feed “${f.name || f.id}”`, out, 'feeds');
  byId('led', (a.led || {}).screens, (b.led || {}).screens, s => `LED screen “${s.name}”`, out, 'led/screens');
  { const ta = a.timeline || {}, tb = b.timeline || {}; const f = fields(Object.assign({}, ta, { play: undefined }), Object.assign({}, tb, { play: undefined }), '', []);
    if (f.length) out.push({ area: 'timeline', kind: 'changed', label: `Timeline (${(tb.tracks || []).reduce((n, t) => n + t.items.length, 0)} clips, ${(tb.lanes || []).length} automation lanes, ${(tb.events || []).length} events)`, pick: 'timeline', fields: f.slice(0, 20).map(d => ({ path: d.path, from: short(d.from), to: short(d.to) })), more: Math.max(0, f.length - 20) }); }
  for (const k of ['decks', 'rules', 'schedule', 'rotation', 'oscOut', 'checklist', 'react', 'mods', 'genPresets']) {
    const f = fields(a[k], b[k], '', []); if (f.length) out.push({ area: k, kind: 'changed', label: LABEL[k] || k, pick: k, fields: f.slice(0, 15).map(d => ({ path: d.path, from: short(d.from), to: short(d.to) })), more: Math.max(0, f.length - 15) }); }
  { const f = fields(Object.assign({}, a.led, { screens: undefined }), Object.assign({}, b.led, { screens: undefined }), '', []); if (f.length) out.push({ area: 'led', kind: 'changed', label: 'LED settings', fields: f.slice(0, 15).map(d => ({ path: d.path, from: short(d.from), to: short(d.to) })) }); }
  return out;
}
function fxDiff(area, owner, fa = {}, fb = {}, out, pickBase) {
  for (const k of new Set([...Object.keys(fa || {}), ...Object.keys(fb || {})])) {
    const x = (fa || {})[k] || {}, y = (fb || {})[k] || {};
    if (!!x.on !== !!y.on) { out.push({ area, kind: y.on ? 'added' : 'removed', label: `${owner} · effect ${k}`, pick: pickBase + '/' + k }); continue; }
    if (!y.on) continue; const f = fields(x, y, '', []); if (f.length) out.push({ area, kind: 'changed', label: `${owner} · effect ${k}`, pick: pickBase + '/' + k, fields: f.map(d => ({ path: d.path, from: short(d.from), to: short(d.to) })) });
  }
}
// copy one item (named by a diff entry's pick) from `src` into `dst`; returns a description
function pick(dst, src, p) {
  const parts = String(p || '').split('/'), clone = v => v === undefined ? undefined : JSON.parse(JSON.stringify(v));
  const putById = (A, B, id) => { const x = (B || []).find(o => o && o.id === id); const i = A.findIndex(o => o && o.id === id); if (!x) { if (i >= 0) A.splice(i, 1); return 'removed'; } if (i >= 0) A[i] = clone(x); else A.push(clone(x)); return 'restored'; };
  if (parts[0] === 'layers') {
    const id = parts[1], ls = src.layers.find(l => l.id === id), ld = dst.layers.find(l => l.id === id);
    if (parts.length === 2) { if (!ls) throw new Error('that layer is not in the version'); if (ld) Object.assign(ld, clone(ls), { active: ld.active, trig: ld.trig }); else dst.layers.push(Object.assign(clone(ls), { active: null })); return 'layer restored'; }
    if (!ld) throw new Error('the layer no longer exists — bring back the whole layer first');
    if (parts[2] === 'settings') { const keep = { clips: ld.clips, fx: ld.fx, active: ld.active, trig: ld.trig, trigAt: ld.trigAt, id: ld.id }; Object.assign(ld, clone(Object.assign({}, ls, { clips: undefined, fx: undefined })), keep); return 'layer settings restored'; }
    if (parts[2] === 'clips') { const k = +parts[3]; while (ld.clips.length <= k) ld.clips.push(null); ld.clips[k] = ls ? clone(ls.clips[k] || null) : null; return 'clip slot restored'; }
    if (parts[2] === 'fx') { ld.fx[parts[3]] = clone(((ls || {}).fx || {})[parts[3]] || { on: false }); return 'effect restored'; }
  }
  if (parts[0] === 'comp' && parts[1] === 'fx') { dst.comp.fx[parts[2]] = clone((src.comp.fx || {})[parts[2]] || { on: false }); return 'effect restored'; }
  if (['outputs', 'cues', 'shaders', 'luts', 'presets', 'feeds'].includes(parts[0]) && parts[1]) { dst[parts[0]] = dst[parts[0]] || []; return putById(dst[parts[0]], src[parts[0]], parts[1]); }
  if (parts[0] === 'led' && parts[1] === 'screens' && parts[2]) return putById(dst.led.screens, (src.led || {}).screens, parts[2]);
  if (parts[0] === 'timeline') { const play = dst.timeline.play; dst.timeline = clone(src.timeline); dst.timeline.play = play; return 'timeline restored'; }
  if (['decks', 'rules', 'schedule', 'rotation', 'oscOut', 'checklist', 'react', 'mods', 'genPresets'].includes(parts[0])) { dst[parts[0]] = clone(src[parts[0]]); return (LABEL[parts[0]] || parts[0]) + ' restored'; }
  throw new Error('nothing to bring back for ' + p);
}

module.exports = function (ctx) {
  // ctx: { DATA, state(), safeName(), autoMinutes() }
  const ROOT = path.join(ctx.DATA, 'versions'); let lastAutoHash = '';
  const dirOf = name => path.join(ROOT, ctx.safeName(name || 'Untitled') || 'Untitled');
  const hash = st => crypto.createHash('sha1').update(JSON.stringify(strip(st))).digest('hex');
  const strip = st => { const c = JSON.parse(JSON.stringify(st)); for (const l of c.layers || []) for (const k of VOLATILE) delete l[k]; delete c.cueIndex; if (c.comp) delete c.comp.beatEpoch; if (c.timeline) delete c.timeline.play; return c; };
  function list(name) {
    const dir = dirOf(name); let files = []; try { files = fs.readdirSync(dir).filter(f => f.endsWith('.json.gz')); } catch {}
    return files.map(f => { try { return JSON.parse(fs.readFileSync(path.join(dir, f.replace(/\.json\.gz$/, '.meta')), 'utf8')); } catch { return null; } }).filter(Boolean).sort((x, y) => y.at - x.at);
  }
  function read(name, id) { if (!/^[\w-]+$/.test(String(id))) throw new Error('bad version id'); const f = path.join(dirOf(name), id + '.json.gz'); if (!fs.existsSync(f)) throw new Error('no such version'); return JSON.parse(zlib.gunzipSync(fs.readFileSync(f)).toString()); }
  function save(opts = {}) {
    const st = ctx.state(), name = st.comp.name, dir = dirOf(name), h = hash(st);
    if (opts.auto && h === lastAutoHash) return null; // nothing changed since the last automatic version
    const prev = list(name)[0]; if (opts.auto && prev && prev.hash === h) { lastAutoHash = h; return null; }
    fs.mkdirSync(dir, { recursive: true });
    const at = Date.now(), id = new Date(at).toISOString().replace(/[-:]/g, '').replace(/\..*/, '') + '-' + crypto.randomBytes(2).toString('hex');
    const body = zlib.gzipSync(JSON.stringify(strip(st)));
    const meta = { id, at, show: name, label: String(opts.label || '').slice(0, 80) || (opts.auto ? 'Automatic' : 'Version'), note: String(opts.note || '').slice(0, 400), auto: !!opts.auto, reason: opts.reason || (opts.auto ? 'timer' : 'manual'),
      by: String(opts.by || '').slice(0, 60), hash: h, bytes: body.length, layers: st.layers.length, clips: st.layers.reduce((n, l) => n + l.clips.filter(Boolean).length, 0), cues: (st.cues || []).length, outputs: st.outputs.length };
    fs.writeFileSync(path.join(dir, id + '.json.gz'), body); fs.writeFileSync(path.join(dir, id + '.meta'), JSON.stringify(meta)); lastAutoHash = h;
    prune(name); return meta;
  }
  function prune(name) { // keep every named version; the newest 40 automatic ones
    const autos = list(name).filter(v => v.auto); for (const v of autos.slice(40)) remove(name, v.id);
  }
  function remove(name, id) { if (!/^[\w-]+$/.test(String(id))) return; for (const e of ['.json.gz', '.meta']) try { fs.unlinkSync(path.join(dirOf(name), id + e)); } catch {} }
  function rename(name, id, label, note) { const f = path.join(dirOf(name), id + '.meta'); const m = JSON.parse(fs.readFileSync(f, 'utf8')); if (label != null) m.label = String(label).slice(0, 80); if (note != null) m.note = String(note).slice(0, 400); m.auto = false; fs.writeFileSync(f, JSON.stringify(m)); return m; }
  const resolve = (name, ref) => ref === 'current' || !ref ? strip(ctx.state()) : read(name, ref);
  function compare(name, a, b) { const A = resolve(name, a), B = resolve(name, b); const d = diff(A, B); return { a, b, changes: d, counts: d.reduce((o, x) => (o[x.kind] = (o[x.kind] || 0) + 1, o), {}) }; }
  let timer = null;
  function schedule() { clearInterval(timer); const m = ctx.autoMinutes(); if (m > 0) timer = setInterval(() => { try { save({ auto: true }); } catch (e) { console.warn('auto version:', e.message); } }, m * 60000); }
  return { list, read, save, remove, rename, compare, pick: (st, name, id, p) => pick(st, read(name, id), p), schedule, diff, strip };
};
module.exports.diff = diff; module.exports.pick = pick;
