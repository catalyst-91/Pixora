# PIXORA — Booth Productions

A browser-based media server / VJ engine in the spirit of Resolume: custom-resolution compositing,
video library playback from local **and external drives**, layers, effects, generators, shaders,
LED panel mapping with a built-in test-pattern generator, projection mapping, cues, timecode,
DMX/Art-Net/sACN, pixel mapping, MIDI (APC Mini mk2 / Launchpads), OSC, HTTP API and a phone remote.

All video decoding, compositing and effects run **on your own computer's GPU** (WebGL in the Output
window). The small Node.js server runs on your machine too — no cloud, no internet required.

## Desktop app
PIXORA installs as a native desktop app (Windows `.exe`, Mac `.dmg` for Apple Silicon and Intel, Linux AppImage), with its own windows and menus and the engine built in. To get the installers, see **BUILD-DESKTOP-APP.md** (GitHub builds them) or run `npm run dist` in `desktop/`.

## Quick start (run from source / server mode)
| Platform | Steps |
|---|---|
| **Windows** | `winget install OpenJS.NodeJS.LTS` and `winget install Gyan.FFmpeg`, then right-click `start.ps1` ▸ Run with PowerShell |
| **macOS / Linux** | Install Node 18+ and ffmpeg, then `./start.sh` |
| **Docker** | `docker compose up -d --build` (see comments in `docker-compose.yml` for drives & networking) |

Then open:
- Controller — `http://localhost:8080/`
- Output — `http://localhost:8080/output` (click once, press **F** for full screen)
- Phone remote — `http://<this-computer-ip>:8080/remote`
- Manual — `http://localhost:8080/manual/` (also `PIXORA-User-Manual.pdf`)

Put media in `media/`, upload it in the app, or add any folder / external drive under
**Sources & Drives**. There are no npm dependencies; ffmpeg is optional (needed only to convert formats
browsers can't play, such as AVI, WMV, MPEG-2, ProRes and MXF).

## v1.1 pro features
Data feeds (any app can push JSON/CSV/text or OSC into PIXORA) with `{{feed.key}}` templates · rules · OSC output · per-screen routing ·
title designer & logo animator · timeline with automation & timecode chase · clip automation recording · sponsor rotation with proof-of-play reports ·
scheduler · LED processor capacity check · per-screen calibration · day/night brightness · LED content templates (PNG/SVG/PSD/spec) · Stage 3D ·
audio-reactive scenes with auto BPM · RAM frame cache for smooth reverse · output recording · multi-operator presence, follow & layer locks ·
backup/failover server · health dashboard · diagnostics monitor (`/diag`) · show-day checklist & LED test sequence · GDTF export (`/api/gdtf`).

Extra folders:
- `desktop/` — Electron desktop app: outputs on displays, start at login, NDI out (Spout via the NDI→Spout bridge or a plugin), NDI in, web pages through effects (build on your machine)
- `companion-module/` — Bitfocus Companion module with actions, feedbacks, variables and presets

## v1.2 — show-ready & console link
- **Show lock & safe loop**: lock the setup while playback stays live. A fallback clip cuts in automatically if a clip fails, playback stalls or the GPU resets. Outputs preload the next cue. Every output gets a live health card (fps, drops, errors).
- **Content preflight**: checks the library against your screens (resolution, aspect, fps, heavy codecs, bitrate, missing files). One-click optimise to H.264 at the right size, with automatic relink.
- **CITP / MSEX**: consoles that support CITP see each layer's clips as thumbnails with names, plus live layer status.
- **Art-Net timecode** in (chase) and out (generate).
- **MVR import**: video screens from a grandMA3 / Vectorworks / Capture rig become LED screens placed in the 3D view.
- **HAP playback**: HAP, HAP Alpha and HAP Q `.mov`, including chunked encodes. Uses GPU texture upload where possible.
- **Multi-machine frame sync**: followers lock video playheads to the master clock.
- **Users & roles** (admin / operator / client / viewer) with a sign-in page, plus **remote access** over a Cloudflare tunnel.
- **Show reports** as PDF: proof of play, incidents, changes.
- **Websites**: proxy for sites that block embedding, zoom, auto-scroll, transparency, auto-refresh, URL rotation, custom CSS.
- **Scoreboard** title template; MIDI pads coloured by clip type.
- **In-app updates** (SHA-256 verified, with backup) and **installer build scripts** that bundle Node.js: `installers/build-windows.ps1` (Inno Setup) and `installers/build-mac.sh` (DMG, optional signing and notarisation).

## Environment variables
`PORT` (8080) · `OSC_PORT` (7000) · `PIN` · `VIEW_PIN` · `MEDIA_DIR` · `MEDIA_DIRS` (extra roots, `;`-separated) · `DATA_DIR` · `FFMPEG_PATH`

## Network ports
TCP 8080 (web), UDP 7000 (OSC in), UDP 6454 (Art-Net DMX & timecode in/out), UDP 5568 (sACN in/out), UDP 4809 + one TCP port (CITP, when enabled)

## Folder layout
```
server.js        zero-dependency server (HTTP, WebSocket, OSC, Art-Net/sACN, ffmpeg jobs)
public/          controller, output renderer, phone remote, manual
desktop/         Electron desktop app (NDI, displays, autostart)
companion-module/ Bitfocus Companion module
tests/           integration harnesses (desktop, Companion, GDTF, temperature, v1.2 server features, HAP decoder, updates)
installers/      Windows/Mac installer build scripts, update packager
windows/         PIXORA.exe tray launcher source (Go)
server-pro3.js   v1.2 server modules
media/           Local Library
data/            autosave, saved compositions, thumbnails, converted files, settings (created on first run)
```

© Booth Productions
