# Building the PIXORA desktop app (Windows, Mac, Linux)

GitHub builds the installers for you on its own Windows, Mac and Linux computers, so you don't need to install any developer tools.

## One-time setup (about 5 minutes)
1. Create a free account at github.com if you don't have one.
2. Click **New repository**, name it `pixora` and choose **Private**, then click **Create repository**.
3. Click **uploading an existing file**. Drag in everything inside this PIXORA folder, including the hidden `.github` folder. On a Mac, press Cmd+Shift+. in Finder to show hidden files.
   With git it's simply:
   ```
   git init && git add . && git commit -m "PIXORA" && git branch -M main
   git remote add origin https://github.com/YOUR-NAME/pixora.git && git push -u origin main
   ```

## Build
1. Open the repository's **Actions** tab, click **Build PIXORA desktop app** and then **Run workflow**.
2. After about 15 minutes, open the finished run and download the files under **Artifacts**:

| Artifact | Contents |
|---|---|
| **PIXORA-Windows** | `PIXORA-Setup-1.2.0.exe` (installer) and `PIXORA-1.2.0-portable.exe` (no install) |
| **PIXORA-macOS** | `PIXORA-1.2.0-mac-arm64.dmg` (Apple Silicon, M1–M4) and `PIXORA-1.2.0-mac-x64.dmg` (Intel) |
| **PIXORA-Linux** | `PIXORA-1.2.0-linux-x86_64.AppImage` |

## Releases and automatic update notices
Push a version tag (`git tag v1.2.0 && git push --tags`). The workflow then also creates a GitHub **Release** containing every installer plus `latest.json`.

To get update notices, set this as the update feed in **PIXORA ▸ More ▸ Updates**:

`https://github.com/YOUR-NAME/pixora/releases/latest/download/latest.json`

The installed app then offers to download the new installer when you publish one.

## Removing the security warnings (optional)
Unsigned apps work, but show a warning the first time they open:
- **Mac:** right-click the app ▸ **Open**, or go to System Settings ▸ Privacy & Security ▸ **Open Anyway**.
- **Windows:** **More info ▸ Run anyway**.

To remove these warnings, add your certificates in the repository's **Settings ▸ Secrets and variables ▸ Actions**. The next build is then signed (and notarised on Mac) automatically.

| Secret | What it is |
|---|---|
| `MAC_CSC_LINK`, `MAC_CSC_KEY_PASSWORD` | Your Apple **Developer ID Application** certificate (.p12, base64) and its password ($99/year Apple Developer account) |
| `APPLE_ID`, `APPLE_APP_SPECIFIC_PASSWORD`, `APPLE_TEAM_ID` | Used for notarisation |
| `WIN_CSC_LINK`, `WIN_CSC_KEY_PASSWORD` | A Windows code-signing certificate (.pfx, base64) |

## Building on your own computer instead
Install Node.js 22, then run this in the `desktop` folder:
```
npm install
npm run dist
```
You get the installer for the computer you're on.

## NDI®

The build adds NDI automatically. For each platform and architecture, `desktop/build/ndi-prepare.js` (run from the electron-builder `beforePack` hook):

1. compiles PIXORA's NDI module (`desktop/native/ndi`, C/Node-API) with node-gyp, and
2. downloads the official NDI 6 SDK from NDI's servers and copies its runtime library into the app (`resources/ndi`).

The SDK is never committed to the repository; its licence doesn't allow republishing it. To build with an SDK you already have, set `NDI_SDK_DIR` to its folder (or `NDI_SDK_URL` to a download you control). If a step fails, the build still finishes and the app uses an NDI Runtime installed on the computer instead.

Shipping NDI comes with conditions (see the NDI SDK licence and documentation):
- The EULA (`desktop/build/EULA.txt`, shown by the installer) must carry NDI's terms.
- The About box and every place NDI is offered must say "NDI® is a registered trademark of Vizrt NDI AB" and link to https://ndi.video/. PIXORA already does this.

NDI® is a registered trademark of Vizrt NDI AB.
