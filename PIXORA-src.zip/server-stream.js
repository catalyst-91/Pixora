// PIXORA live streaming — Booth Productions.
// The primary output window encodes the programme (picture + mix) and sends it here in small chunks; one ffmpeg sends
// it to every enabled destination at once: RTMP / RTMPS (YouTube, Facebook, Twitch, Vimeo, LinkedIn, custom) and SRT.
// A failing destination does not stop the others. Stream keys stay on this computer and are never sent to controllers.
// Blackmagic "Streaming XML" files (ATEM / Web Presenter platform lists) can be imported as destination presets.
'use strict';
const { spawn, spawnSync } = require('child_process'), crypto = require('crypto');

const BUILTIN = [
  { service: 'YouTube', servers: [{ name: 'Primary', url: 'rtmp://a.rtmp.youtube.com/live2' }, { name: 'Backup', url: 'rtmp://b.rtmp.youtube.com/live2?backup=1' }, { name: 'RTMPS', url: 'rtmps://a.rtmps.youtube.com:443/live2' }] },
  { service: 'Facebook Live', servers: [{ name: 'RTMPS', url: 'rtmps://live-api-s.facebook.com:443/rtmp' }] },
  { service: 'Twitch', servers: [{ name: 'Auto', url: 'rtmp://live.twitch.tv/app' }] },
  { service: 'Vimeo', servers: [{ name: 'RTMPS', url: 'rtmps://rtmp-global.cloud.vimeo.com:443/live' }] },
  { service: 'Kick', servers: [{ name: 'RTMPS', url: 'rtmps://fa723fc1b171.global-contribute.live-video.net:443/app' }] },
  { service: 'Custom RTMP', servers: [{ name: 'Custom', url: '' }] },
  { service: 'SRT', servers: [{ name: 'Caller', url: 'srt://host:9000?mode=caller&latency=200000' }] },
];
const DEF = { video: { mode: 'auto', kbps: 6000, fps: 30, height: 1080, preset: 'veryfast' }, audio: { kbps: 160 }, destinations: [] };

module.exports = function stream(ctx) { // ctx: { FFMPEG, ffmpegOk(), settings, saveSettings, broadcast, monitor, output(), sendToOutput(obj) }
  const cfg = () => { const s = ctx.settings.stream = Object.assign({}, DEF, ctx.settings.stream || {}); s.video = Object.assign({}, DEF.video, s.video); s.audio = Object.assign({}, DEF.audio, s.audio); s.destinations = s.destinations || []; return s; };
  let ff = null, st = { state: 'idle', since: 0, kbps: 0, fps: 0, speed: 0, error: '', dests: {}, passthrough: false, bytes: 0 }, stopT = null, wantOn = false, restarts = 0, lastData = 0, watch = null, rateT = null;
  let protocols = null;
  const protos = () => { if (protocols) return protocols; protocols = new Set(); try { const r = spawnSync(ctx.FFMPEG, ['-hide_banner', '-protocols'], { encoding: 'utf8', timeout: 8000, windowsHide: true }); String(r.stdout).split('\n').forEach(l => protocols.add(l.trim())); } catch {} return protocols; };
  const urlFor = d => { if (d.kind === 'srt') return d.url; const base = String(d.url || '').trim(); const key = String(d.key || '').trim(); if (!key) return base; const q = base.indexOf('?'); return q < 0 ? base.replace(/\/+$/, '') + '/' + key : base.slice(0, q).replace(/\/+$/, '') + '/' + key + base.slice(q); };
  const mask = k => !k ? '' : k.length <= 6 ? '••••' : '••••' + k.slice(-4);
  const enabled = () => cfg().destinations.filter(d => d.on && d.url);
  function view() {
    const c = cfg();
    return { state: st.state, on: st.state === 'live' || st.state === 'starting', since: st.since, kbps: st.kbps, fps: st.fps, speed: st.speed, error: st.error, passthrough: st.passthrough, label: st.state === 'live' ? 'LIVE · ' + enabled().length : st.state.toUpperCase(),
      video: c.video, audio: c.audio, presets: (ctx.settings.streamPresets || []).concat(BUILTIN), srt: protos().has('srt'), rtmps: protos().has('rtmps'), ffmpeg: ctx.ffmpegOk(),
      destinations: c.destinations.map(d => ({ id: d.id, name: d.name, kind: d.kind, url: d.url, key: mask(d.key), hasKey: !!d.key, on: !!d.on, state: (st.dests[d.id] || {}).state || (d.on && st.state === 'live' ? 'live' : 'off'), error: (st.dests[d.id] || {}).error || '' })) };
  }
  const push = () => ctx.broadcast({ t: 'streamstate', stream: view() });
  function setCfg(b) {
    const c = cfg();
    if (b.video) Object.assign(c.video, { mode: ['auto', 'reencode'].includes(b.video.mode) ? b.video.mode : c.video.mode, kbps: Math.max(500, Math.min(50000, +b.video.kbps || c.video.kbps)), fps: [24, 25, 30, 50, 60].includes(+b.video.fps) ? +b.video.fps : c.video.fps,
      height: [480, 720, 1080, 1440, 2160].includes(+b.video.height) ? +b.video.height : c.video.height, preset: ['ultrafast', 'superfast', 'veryfast', 'faster', 'fast', 'medium'].includes(b.video.preset) ? b.video.preset : c.video.preset });
    if (b.audio) c.audio.kbps = Math.max(64, Math.min(320, +b.audio.kbps || c.audio.kbps));
    if (b.destination) { const x = b.destination; let d = c.destinations.find(y => y.id === x.id);
      if (x.remove) { c.destinations = c.destinations.filter(y => y.id !== x.id); }
      else { if (!d) { d = { id: crypto.randomBytes(4).toString('hex'), on: true }; c.destinations.push(d); }
        for (const k of ['name', 'url', 'kind']) if (x[k] != null) d[k] = String(x[k]).slice(0, 500).trim(); if (x.on != null) d.on = !!x.on;
        if (x.key != null && !/^•+/.test(x.key)) d.key = String(x.key).trim(); // masked value from the UI = keep the saved key
        if (!d.kind) d.kind = /^srt:/i.test(d.url) ? 'srt' : 'rtmp'; if (!d.name) d.name = d.kind === 'srt' ? 'SRT' : 'Stream'; } }
    ctx.saveSettings(); push(); return view();
  }
  // Blackmagic Streaming XML → presets  (<streaming><service><name/><servers><server><name/><url/>…)
  function importXml(text) {
    const tag = (s, t) => [...s.matchAll(new RegExp(`<${t}\\b[^>]*>([\\s\\S]*?)</${t}>`, 'gi'))].map(m => m[1]);
    const val = (s, t) => { const m = new RegExp(`<${t}\\b[^>]*>([\\s\\S]*?)</${t}>`, 'i').exec(s); return m ? m[1].replace(/<!\[CDATA\[|\]\]>/g, '').trim() : ''; };
    const out = tag(text, 'service').map(sv => ({ service: val(sv, 'name'), servers: tag(sv, 'server').map(x => ({ name: val(x, 'name'), url: val(x, 'url') })).filter(x => /^(rtmps?|srt):\/\//i.test(x.url)) })).filter(s => s.service && s.servers.length);
    if (!out.length) throw new Error('no streaming services found in that XML');
    const keep = (ctx.settings.streamPresets || []).filter(p => !out.some(o => o.service === p.service)); ctx.settings.streamPresets = keep.concat(out.map(o => Object.assign(o, { imported: true }))); ctx.saveSettings(); push(); return out.length;
  }
  function args(pass) {
    const c = cfg(), v = c.video, dests = enabled();
    const a = ['-hide_banner', '-loglevel', 'info', '-stats', '-fflags', '+genpts', '-probesize', '1000000', '-analyzeduration', '1000000', '-thread_queue_size', '512', '-i', 'pipe:0', '-map', '0:v:0', '-map', '0:a:0?'];
    if (pass) a.push('-c:v', 'copy');
    else a.push('-vf', `scale=-2:${v.height}`, '-r', String(v.fps), '-c:v', 'libx264', '-preset', v.preset, '-tune', 'zerolatency', '-b:v', v.kbps + 'k', '-maxrate', v.kbps + 'k', '-bufsize', v.kbps * 2 + 'k',
      '-g', String(v.fps * 2), '-keyint_min', String(v.fps * 2), '-sc_threshold', '0', '-pix_fmt', 'yuv420p', '-profile:v', 'high');
    a.push('-c:a', 'aac', '-b:a', c.audio.kbps + 'k', '-ar', '48000', '-ac', '2');
    const slave = d => `[f=${d.kind === 'srt' ? 'mpegts' : 'flv'}:onfail=ignore${d.kind === 'srt' ? '' : ':flvflags=no_duration_filesize'}]${urlFor(d).replace(/([|\[\]])/g, '\\$1')}`;
    a.push('-f', 'tee', dests.map(slave).join('|'));
    return a;
  }
  function start() {
    if (ff) return view();
    if (!ctx.ffmpegOk()) throw new Error('Live streaming needs ffmpeg');
    const dests = enabled(); if (!dests.length) throw new Error('Add and switch on at least one destination');
    const bad = dests.find(d => (d.kind === 'srt' && !protos().has('srt')) || (/^rtmps:/i.test(d.url) && !protos().has('rtmps'))); if (bad) throw new Error(`this ffmpeg cannot send ${bad.kind === 'srt' ? 'SRT' : 'RTMPS'} (${bad.name})`);
    if (dests.some(d => d.kind !== 'srt' && !d.key && !/\/live2?\/|\/app\/.+/.test(d.url))) ctx.monitor('stream', 'warning: a destination has no stream key');
    if (!ctx.output()) throw new Error('No output window is open to stream from');
    wantOn = true; st = { state: 'starting', since: Date.now(), kbps: 0, fps: 0, speed: 0, error: '', dests: {}, passthrough: false, bytes: 0 };
    const c = cfg(); ctx.sendToOutput({ t: 'streamCtl', on: true, fps: c.video.fps, kbps: c.video.kbps, height: c.video.height, passthrough: c.video.mode === 'auto' });
    push(); return view();
  }
  // first chunk tells us whether the output managed H.264 pass-through (header byte), then ffmpeg starts
  function data(buf) {
    if (!wantOn) return; lastData = Date.now();
    if (!ff) { if (buf[0] !== 0x50 && buf[0] !== 0x52) return; st.passthrough = buf[0] === 0x50; spawnFf(st.passthrough); buf = buf.subarray(1); }
    st.bytes += buf.length; if (ff && ff.stdin.writable) ff.stdin.write(buf);
  }
  function spawnFf(pass) {
    const a = args(pass); ctx.monitor('stream', `starting → ${enabled().map(d => d.name).join(', ')}${pass ? ' (H.264 pass-through)' : ' (x264 ' + cfg().video.preset + ')'}`);
    ff = spawn(ctx.FFMPEG, a, { windowsHide: true }); let tail = '';
    ff.stdin.on('error', () => {});
    ff.stderr.setEncoding('utf8'); ff.stderr.on('data', d => { tail = (tail + d).slice(-4000);
      const m = /time=\s*(\d+):(\d+):([\d.]+)/.exec(d); // the tee muxer reports no frame count or bitrate: go live on output time, measure bitrate from the input
      if (m && (+m[1] * 3600 + +m[2] * 60 + +m[3]) > 0) { st.fps = cfg().video.fps; const sp = /speed=\s*([\d.]+)x/.exec(d); if (sp) st.speed = +sp[1]; if (st.state === 'starting') { st.state = 'live'; st.since = Date.now(); restarts = 0; ctx.monitor('stream', 'live'); } }
      for (const line of d.split(/\r?\n/)) { const f = /Slave '\[[^\]]*\]([^']+)' failed|Error opening output ([^:]+)|(rtmps?:\/\/\S+|srt:\/\/\S+): (.*(?:refused|denied|error|timed out|not found).*)/i.exec(line);
        if (f) { const url = f[1] || f[2] || f[3] || '', d0 = enabled().find(x => url && (urlFor(x).startsWith(url.trim()) || url.includes(x.url))); if (d0) { st.dests[d0.id] = { state: 'error', error: (f[4] || line).slice(0, 160) }; ctx.monitor('stream', `${d0.name}: ${st.dests[d0.id].error}`); } } }
      push(); });
    const me = ff; ff.on('exit', code => { if (ff !== me) return; /* an older ffmpeg finishing after a restart */ const was = ff; ff = null;
      if (wantOn) { st.error = (tail.split('\n').filter(l => /error|failed|refused|invalid|denied/i.test(l)).pop() || `ffmpeg stopped (${code})`).trim().slice(0, 200); ctx.monitor('stream', 'stopped: ' + st.error);
        if (restarts++ < 5) { st.state = 'starting'; push(); ctx.sendToOutput({ t: 'streamCtl', on: false }); setTimeout(() => { if (wantOn) { const c = cfg(); ctx.sendToOutput({ t: 'streamCtl', on: true, fps: c.video.fps, kbps: c.video.kbps, height: c.video.height, passthrough: c.video.mode === 'auto' }); } }, 3000); }
        else { wantOn = false; st.state = 'error'; ctx.sendToOutput({ t: 'streamCtl', on: false }); push(); } }
      else { st.state = 'idle'; st.kbps = st.fps = 0; push(); ctx.monitor('stream', 'stopped'); }
    });
    let lastBytes = st.bytes, lastAt = Date.now(); clearInterval(rateT); rateT = setInterval(() => { const now = Date.now(); st.kbps = Math.round((st.bytes - lastBytes) * 8 / (now - lastAt)); lastBytes = st.bytes; lastAt = now; }, 2000);
    clearInterval(watch); watch = setInterval(() => { if (wantOn && ff && Date.now() - lastData > 5000) { st.error = 'the output window stopped sending video'; ctx.monitor('stream', st.error); try { ff.stdin.end(); } catch {} } }, 2000);
    push();
  }
  function stop() { wantOn = false; clearInterval(watch); clearInterval(rateT); ctx.sendToOutput({ t: 'streamCtl', on: false }); if (ff) { st.state = 'stopping'; try { ff.stdin.end(); } catch {} const f = ff; clearTimeout(stopT); stopT = setTimeout(() => { try { f.kill('SIGKILL'); } catch {} }, 6000); } else { st.state = 'idle'; } push(); return view(); }
  function outputGone(c) { if (wantOn && c === ctx.output()) { st.error = 'the streaming output window closed'; stop(); st.state = 'error'; push(); } }
  async function http(p, req, res, url, send, readBody) {
    if (!p.startsWith('/api/stream')) return false;
    try {
      const body = async () => { try { return JSON.parse((await readBody(req)).toString() || '{}'); } catch { return {}; } };
      if (p === '/api/stream' && req.method === 'GET') send(res, 200, view());
      else if (p === '/api/stream' && req.method === 'POST') send(res, 200, setCfg(await body()));
      else if (p === '/api/stream/start' && req.method === 'POST') send(res, 200, start());
      else if (p === '/api/stream/stop' && req.method === 'POST') send(res, 200, stop());
      else if (p === '/api/stream/xml' && req.method === 'POST') send(res, 200, { imported: importXml((await readBody(req)).toString()) });
      else return false;
    } catch (e) { send(res, 400, { error: e.message }); }
    return true;
  }
  function osc(addr, a) { if (!/^\/(pixora|bvj)\/stream(\/(start|stop))?$/.test(addr)) return false; const on = /start$/.test(addr) ? true : /stop$/.test(addr) ? false : !!(a[0] ?? 1); try { on ? start() : stop(); } catch (e) { ctx.monitor('stream', e.message); } return true; }
  return { view, start, stop, data, http, osc, outputGone, setCfg, importXml, _args: args };
};
