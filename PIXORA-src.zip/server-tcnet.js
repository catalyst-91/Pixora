// PIXORA ⇄ PRO DJ LINK Bridge (and any TCNet node: ShowKontrol, etc.) — Booth Productions.
// Implements a TCNet Link (V3.5) slave node from the open TCNet specification by Event Imagineering Group:
//   Opt-IN keep-alive (type 2) on UDP 60000, Status (5), Time packets (254) on UDP 60001, Request (20) and
//   Data packets (200: Metrics 2, Metadata 4, Mixer 150) on our unicast listener port (65023+).
// What PIXORA does with it: follow the DJ's tempo and bar phase, run timecode cues from the playing deck,
// lock clips to a deck's playhead, put track/artist into titles ({{djlink.master.title}}) and fire rules on track changes.
'use strict';
const dgram = require('dgram'), os = require('os'), crypto = require('crypto');

const LAYERS = ['1', '2', '3', '4', 'A', 'B', 'M', 'C'];
const STATE = { 0: 'idle', 3: 'playing', 4: 'looping', 5: 'paused', 6: 'stopped', 7: 'cue', 8: 'platter', 9: 'ffwd', 10: 'frev', 11: 'hold' };
const playing = s => s === 3 || s === 4;
const ascii = (b, o, n) => b.toString('latin1', o, Math.min(b.length, o + n)).replace(/\0[\s\S]*$/, '').trim();

module.exports = function tcnet(ctx) {
  // ctx: { settings, saveSettings, state, setFeed, updateTc, broadcast, monitor, markDirty }
  const cfg = () => (ctx.settings.tcnet = Object.assign({ on: false, source: 'direct', device: 7, bpm: true, beat: true, master: 'auto', latency: 0 }, ctx.settings.tcnet || {}));
  const me = { id: crypto.randomBytes(2).readUInt16LE(0), seq: 0, port: 0, started: Date.now() };
  const nodes = new Map(); // key ip:nodeId → node
  const decks = LAYERS.map((n, i) => ({ layer: i + 1, name: n, state: 0, ms: 0, total: 0, beat: 0, onAir: 0, trackId: 0, bpm: 0, speed: 1, syncMaster: false, beatNo: 0, title: '', artist: '', key: 0, rxAt: 0, tc: null }));
  const mixer = { crossfader: 0, master: 0, channels: [] };
  // direct mode: PIXORA joins the Pro DJ Link network itself (server-prodjlink.js); bridge mode: TCNet from PRO DJ LINK Bridge
  const pdl = require('./server-prodjlink.js')({ deck: i => decks[i], device: () => cfg().device, monitor: m => ctx.monitor('djlink', m),
    changed: (i, kind) => { timeAt = Date.now(); if (kind === 'track') publish(); else onTime(); } });
  let sock0, sock1, sockL, timer, lastFeed = '', lastBeat = 0, masterIdx = -1, timeAt = 0, srcNode = null, status = 'off', djTimer;

  /* ---------- packets */
  function header(type, size) {
    const b = Buffer.alloc(size); b.writeUInt16LE(me.id, 0); b[2] = 3; b[3] = 5; b.write('TCN', 4, 'latin1'); b[7] = type;
    b.write('PIXORA', 8, 8, 'latin1'); b[16] = me.seq = (me.seq + 1) & 255; b[17] = 4; /* slave */ b.writeUInt16LE(0, 18);
    b.writeUInt32LE(Math.floor(process.hrtime()[1] / 1000) % 1000000, 20); return b;
  }
  function optIn() {
    const b = header(2, 68); b.writeUInt16LE(nodes.size, 24); b.writeUInt16LE(me.port, 26); b.writeUInt16LE(Math.floor((Date.now() - me.started) / 1000) % 43200, 28);
    b.write('Booth Production', 32, 16, 'latin1'); b.write('PIXORA', 48, 16, 'latin1'); const v = String(require('./package.json').version).split('.').map(Number); b[64] = v[0] | 0; b[65] = v[1] | 0; b[66] = v[2] | 0; return b;
  }
  function request(node, dataType, layer) { if (!node || !sockL) return; const b = header(20, 26); b[24] = dataType; b[25] = layer; sockL.send(b, node.port, node.ip, () => {}); }

  function broadcastAddrs() {
    const out = new Set(['255.255.255.255']);
    for (const list of Object.values(os.networkInterfaces())) for (const a of list || []) if (a.family === 'IPv4' && !a.internal && a.netmask) {
      const ip = a.address.split('.').map(Number), m = a.netmask.split('.').map(Number); out.add(ip.map((x, i) => (x & m[i]) | (~m[i] & 255)).join('.')); }
    return [...out];
  }
  const myIps = () => new Set(Object.values(os.networkInterfaces()).flat().filter(a => a && a.family === 'IPv4').map(a => a.address));

  /* ---------- receive */
  function onPacket(b, rinfo) {
    if (b.length < 24 || b.toString('latin1', 4, 7) !== 'TCN') return;
    const nodeId = b.readUInt16LE(0); if (nodeId === me.id && myIps().has(rinfo.address)) return;
    const type = b[7], key = rinfo.address + ':' + nodeId, verMinor = b[3], verMajor = b[2];
    let n = nodes.get(key);
    if (!n) { n = { key, ip: rinfo.address, nodeId, port: 65023, seen: 0, name: ascii(b, 8, 8), type: b[17] }; nodes.set(key, n); ctx.monitor('tcnet', `found ${n.name} at ${n.ip}`); }
    n.seen = Date.now(); n.type = b[17]; n.name = ascii(b, 8, 8) || n.name; n.utf16 = verMajor > 3 || (verMajor === 3 && verMinor >= 5);
    if (type === 2 && b.length >= 68) { n.port = b.readUInt16LE(26) || n.port; n.vendor = ascii(b, 32, 16); n.app = ascii(b, 48, 16); n.version = `${b[64]}.${b[65]}.${b[66]}`; }
    else if (type === 3) { nodes.delete(key); }
    else if (type === 5 && b.length >= 100) { n.port = b.readUInt16LE(26) || n.port; srcNode = n;
      for (let i = 0; i < 8; i++) { const d = decks[i], st = b[42 + i], tid = b.readUInt32LE(50 + i * 4); d.state = st;
        if (b.length >= 188 + i * 16) d.layerName = ascii(b, 172 + i * 16, 16);
        if (tid !== d.trackId) { d.trackId = tid; d.title = d.artist = ''; d.bpm = 0; if (tid && i < 6) { request(n, 4, i + 1); request(n, 2, i + 1); } } }
      if (b[83]) n.smpte = b[83];
    }
    else if (type === 254 && b.length >= 104) { srcNode = srcNode || n; timeAt = Date.now();
      for (let i = 0; i < 8; i++) { const d = decks[i]; d.ms = b.readUInt32LE(24 + i * 4); d.total = b.readUInt32LE(56 + i * 4); d.beat = b[88 + i]; d.state = b[96 + i]; d.rxAt = timeAt;
        if (b.length >= 162) d.onAir = b[154 + i];
        if (i < 6 && b.length >= 112 + i * 6) { const o = 106 + i * 6; d.tc = b[o + 1] ? { fps: b[o], h: b[o + 2], m: b[o + 3], s: b[o + 4], f: b[o + 5] } : null; } }
      onTime();
    }
    else if (type === 200) {
      const dt = b[24], li = b[25] - 1, d = decks[li];
      if (dt === 2 && d && b.length >= 122) { d.state = b[27]; d.syncMaster = b[29] === 1; d.beat = b[31]; d.total = b.readUInt32LE(32); d.ms = b.readUInt32LE(36); d.rxAt = Date.now();
        d.speed = b.readUInt32LE(40) / 32768 || d.speed; d.beatNo = b.readUInt32LE(57); d.bpm = b.readUInt32LE(112) / 100; const tid = b.readUInt32LE(118); if (tid && tid !== d.trackId) { d.trackId = tid; request(n, 4, li + 1); } }
      else if (dt === 4 && d && b.length >= 541) { const enc = n.utf16 ? 'utf16le' : 'utf8'; const txt = o => b.toString(enc, o, o + 256).replace(/\0[\s\S]*$/, '').trim();
        d.artist = txt(29); d.title = txt(285); if (b.length >= 547) { d.key = b.readUInt16LE(541); } ctx.monitor('tcnet', `deck ${d.name}: ${d.artist} – ${d.title}`); }
      else if (dt === 150 && b.length >= 250) { mixer.master = b[62]; mixer.crossfader = b[99]; mixer.name = ascii(b, 29, 16);
        mixer.channels = Array.from({ length: 6 }, (_, c) => ({ fader: b[127 + c * 24], level: b[126 + c * 24] })); }
      publish();
    }
  }

  /* ---------- which deck leads */
  function pickMaster() {
    const c = cfg(); if (c.master !== 'auto') { const i = LAYERS.indexOf(String(c.master)); return i >= 0 ? i : 0; }
    const live = decks.slice(0, 6);
    let i = live.findIndex(d => d.syncMaster && playing(d.state)); if (i >= 0) return i;
    let best = -1, bv = 0; live.forEach((d, k) => { if (playing(d.state) && d.onAir > bv) { bv = d.onAir; best = k; } }); if (best >= 0) return best;
    i = live.findIndex(d => playing(d.state)); return i >= 0 ? i : masterIdx;
  }
  const posNow = d => d.ms + (playing(d.state) && d.rxAt ? (Date.now() - d.rxAt) * (d.speed || 1) : 0);

  function onTime() {
    masterIdx = pickMaster(); const c = cfg(), m = decks[masterIdx]; if (!m) return;
    const S = ctx.state.comp;
    if (c.bpm && m.bpm > 20 && playing(m.state) && Math.abs(S.bpm - m.bpm) >= 0.05) { S.bpm = Math.round(m.bpm * 100) / 100; ctx.markDirty(); }
    // bar phase: beat marker 1 = downbeat. Nudge the beat clock only when it has drifted, so the state isn't rewritten every bar.
    if (c.beat && playing(m.state) && m.beat === 1 && lastBeat !== 1 && S.bpm > 0) {
      const now = Date.now() - (+c.latency || 0), bar = 4 * 60000 / S.bpm, ph = (((now - (S.beatEpoch || 0)) % bar) + bar) % bar;
      if (Math.min(ph, bar - ph) > 15) { S.beatEpoch = now; ctx.markDirty(); }
    }
    lastBeat = m.beat;
    if (S.timecode && S.timecode.source === 'tcnet' && playing(m.state)) { const fps = S.timecode.fps || 25; ctx.updateTc(Math.floor(m.ms / 1000 * fps), fps); }
    publish();
  }

  /* ---------- share */
  const deckView = d => ({ deck: d.name, title: d.title, artist: d.artist, bpm: Math.round(d.bpm * 10) / 10, state: STATE[d.state] || String(d.state), playing: playing(d.state), onAir: d.onAir > 0, trackId: d.trackId, length: Math.round(d.total / 1000) });
  function publish() {
    const live = decks.slice(0, 4).map(deckView), master = masterIdx >= 0 ? deckView(decks[masterIdx]) : {};
    const v = { master, deck1: live[0], deck2: live[1], deck3: live[2], deck4: live[3], mixer: { crossfader: mixer.crossfader, master: mixer.master }, bridge: srcNode ? srcNode.name : '' };
    const sig = JSON.stringify(v); if (sig === lastFeed) return; lastFeed = sig; ctx.setFeed('djlink', v, 'tcnet');
  }
  // deck playheads for outputs (clip "Follow deck"), ~25 Hz while anything plays
  function djTick() {
    if (!decks.some(d => playing(d.state)) && Date.now() - timeAt > 1000) return;
    ctx.broadcast({ t: 'djtime', master: masterIdx, layers: decks.slice(0, 6).map(d => ({ ms: Math.round(posNow(d)), state: d.state, speed: d.speed, total: d.total })) }, 'output');
  }

  /* ---------- lifecycle */
  function bindShared(port) { return new Promise(ok => { const s = dgram.createSocket({ type: 'udp4', reuseAddr: true }); s.on('error', e => { ctx.monitor('tcnet', `port ${port}: ${e.message}`); status = 'error: ' + e.message; ok(null); }); s.on('message', onPacket); s.bind(port, () => { try { s.setBroadcast(true); } catch {} ok(s); }); }); }
  function bindListener(port = 65023) { return new Promise(ok => { const s = dgram.createSocket('udp4'); s.once('error', () => { s.close(); if (port < 65100) bindListener(port + 1).then(ok); else ok(null); }); s.on('message', onPacket); s.bind(port, () => { me.port = port; s.removeAllListeners('error'); s.on('error', () => {}); try { s.setBroadcast(true); } catch {} ok(s); }); }); }
  async function start() {
    stop(); if (!cfg().on) return;
    if (cfg().source === 'direct') { await pdl.start(); djTimer = setInterval(djTick, 40); return; }
    [sock0, sock1, sockL] = await Promise.all([bindShared(60000), bindShared(60001), bindListener()]);
    if (!sock0 || !sockL) { status = status.startsWith('error') ? status : 'error: could not open TCNet ports'; return; }
    status = 'listening'; ctx.monitor('tcnet', `TCNet node PIXORA listening (unicast port ${me.port})`);
    const hello = () => { const b = optIn(); for (const a of broadcastAddrs()) sock0.send(b, 60000, a, () => {}); sockL.send(b, 60000, '127.0.0.1', () => {});
      for (const n of nodes.values()) { if (Date.now() - n.seen > 5000) { nodes.delete(n.key); continue; } sockL.send(b, n.port, n.ip, () => {}); }
      // keep metrics fresh for playing decks (BPM, sync master, beat number)
      const src = [...nodes.values()].find(n => n.type === 2 || n.type === 8) || srcNode; if (src) decks.slice(0, 6).forEach((d, i) => { if (d.trackId) request(src, 2, i + 1); if (d.trackId && !d.title) request(src, 4, i + 1); });
      if (src) request(src, 150, 1); };
    hello(); timer = setInterval(hello, 1000); djTimer = setInterval(djTick, 40);
  }
  function stop() { pdl.stop(); clearInterval(timer); clearInterval(djTimer); for (const s of [sock0, sock1, sockL]) try { s && s.close(); } catch {} sock0 = sock1 = sockL = null; status = 'off'; nodes.clear(); }
  function view() { const P = cfg().source === 'direct' ? pdl.view() : null; return { cfg: cfg(), status: P ? P.status : status, port: P ? 0 : me.port, number: P ? P.number : 0, master: masterIdx >= 0 ? LAYERS[masterIdx] : null, nodes: P ? P.devices : [...nodes.values()].map(n => ({ name: n.name, ip: n.ip, app: n.app, vendor: n.vendor, version: n.version, type: n.type })), decks: decks.slice(0, 6).map(d => Object.assign(deckView(d), { ms: Math.round(posNow(d)), beat: d.beat, onAirLevel: d.onAir, layerName: d.layerName })), mixer }; }
  function set(c) { Object.assign(cfg(), c); ctx.saveSettings(); start(); return view(); }
  async function http(p, req, res, url, send, readBody) {
    if (p === '/api/tcnet' && req.method === 'GET') { send(res, 200, view()); return true; }
    if (p === '/api/tcnet' && req.method === 'POST') { try { send(res, 200, set(JSON.parse((await readBody(req)).toString() || '{}'))); } catch (e) { send(res, 400, { error: e.message }); } return true; }
    return false;
  }
  start();
  return { start, stop, view, set, http, _test: { onPacket, decks, nodes, me, pdl } };
};
