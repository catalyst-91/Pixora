// PIXORA remote guests — Booth Productions.
// A guest opens /guest?key=… on a phone or laptop and sends camera + microphone to PIXORA over WebRTC (peer to peer).
// The server only relays signalling between the guest and each output window; the media never passes through it.
// Guests get one of 4 slots ("Guest 1–4"); a Guest clip shows whoever is in that slot. The invite key is separate from
// the show PIN, so a guest can join without being able to control anything.
'use strict';
const crypto = require('crypto');
module.exports = function guests(ctx) { // ctx: { settings, saveSettings, clients: () => Set, broadcast, monitor }
  if (!ctx.settings.guestKey) { ctx.settings.guestKey = crypto.randomBytes(6).toString('hex'); ctx.saveSettings(); }
  const slots = [null, null, null, null]; // client per slot
  const list = () => slots.map((c, i) => c ? { slot: i + 1, id: c.id, name: c.guestName || 'Guest ' + (i + 1), addr: c.addr } : null).filter(Boolean);
  const push = () => { const m = JSON.stringify({ t: 'guests', guests: list() }); for (const x of ctx.clients()) if (x.role !== 'guest' && x.role !== 'mirror') x.send(m); };
  function keyOk(url) { const k = url.searchParams.get('key') || ''; const a = Buffer.from(k), b = Buffer.from(ctx.settings.guestKey); return a.length === b.length && crypto.timingSafeEqual(a, b); }
  function join(c, url) {
    const free = slots.indexOf(null); if (free < 0) { c.send({ t: 'guestFull' }); setTimeout(() => c.socket.destroy(), 200); return; }
    slots[free] = c; c.guestSlot = free + 1; c.guestName = String(url.searchParams.get('name') || '').slice(0, 40) || 'Guest ' + (free + 1);
    c.send({ t: 'hello', id: c.id, role: 'guest', slot: c.guestSlot, name: c.guestName, ice: iceServers() });
    ctx.monitor('guest', `${c.guestName} joined as Guest ${c.guestSlot} from ${c.addr}`); push();
    for (const o of ctx.clients()) if (o.role === 'output') o.send({ t: 'guestJoined', slot: c.guestSlot, id: c.id });
  }
  function leave(c) { const i = slots.indexOf(c); if (i >= 0) { slots[i] = null; ctx.monitor('guest', `${c.guestName} left`); push(); } }
  // returns true when the message was for us
  function message(c, m) {
    if (m.t === 'rtc') { // relay: guest ⇄ output only
      const to = c.role === 'guest' ? [...ctx.clients()].find(x => x.id === m.to && x.role === 'output') : c.role === 'output' ? slots.find(x => x && x.id === m.to) : null; if (!to) return true;
      to.send({ t: 'rtc', from: c.id, slot: c.role === 'guest' ? c.guestSlot : to.guestSlot, data: m.data }); return true;
    }
    if (c.role === 'guest') { if (m.t === 'guestName') { c.guestName = String(m.name || '').slice(0, 40) || c.guestName; push(); } return true; } // guests can do nothing else
    if (m.t === 'guestKick' && c.role === 'control' && !c.viewer) { const g = slots[(+m.slot || 0) - 1]; if (g) { g.send({ t: 'guestKicked' }); setTimeout(() => g.socket.destroy(), 200); } return true; }
    if (m.t === 'guestNewKey' && c.role === 'control' && !c.viewer) { ctx.settings.guestKey = crypto.randomBytes(6).toString('hex'); ctx.saveSettings(); for (const g of slots) if (g) g.socket.destroy(); push(); ctx.broadcast({ t: 'guestKey', key: ctx.settings.guestKey }, 'control'); return true; }
    return false;
  }
  const iceServers = () => (ctx.settings.iceServers && ctx.settings.iceServers.length ? ctx.settings.iceServers : [{ urls: 'stun:stun.l.google.com:19302' }]);
  return { keyOk, join, leave, message, list, key: () => ctx.settings.guestKey, iceServers };
};
