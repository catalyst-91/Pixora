/* PIXORA timeline editor: clip tracks per layer + automation lanes, synced to the server playhead (optionally chasing timecode) */
(function () {
  const UI = window.UI, $ = UI.$, esc = UI.esc, I = UI.icon;
  const LW = 170, RH = 26, TH = 40, LH = 64, EH = 30; // EH: the events row (OSC, DMX, cues… fired as the playhead passes)
  let bound = false, zoom = +(localStorage.pxTlZoom || 0), scroll = 0, sel = null, drag = null, raf = 0, cv = null, local = null;
  const tlPos = s => { const p = s.timeline.play; return p.playing ? p.pos + (BVJ.now() - p.startAt) / 1000 : p.pos; };
  const fmt = t => { t = Math.max(0, t); const m = Math.floor(t / 60), sec = t % 60; return `${String(m).padStart(2, '0')}:${sec.toFixed(1).padStart(4, '0')}`; };
  function pathTargets(s) { const t = [['comp.master', 'Comp › Master'], ['comp.speed', 'Comp › Speed'], ['comp.crossfader', 'Comp › Crossfader']];
    s.layers.forEach((l, i) => { t.push([`layers.${i}.opacity`, `L${i + 1} ${l.name} › Opacity`], [`layers.${i}.transform.scale`, `L${i + 1} › Scale`], [`layers.${i}.transform.x`, `L${i + 1} › Position X`], [`layers.${i}.transform.y`, `L${i + 1} › Position Y`], [`layers.${i}.transform.rotation`, `L${i + 1} › Rotation`]);
      for (const f of SCHEMA.FX) for (const p of f.params) if (!p.type) t.push([`layers.${i}.fx.${f.id}.${p.k}`, `L${i + 1} › ${f.name} › ${p.label}`]); }); return t; }
  const rangeFor = path => { if (/opacity|master|crossfader/.test(path)) return [0, 1]; if (/speed/.test(path)) return [0, 2]; if (/rotation/.test(path)) return [-180, 180]; if (/scale/.test(path)) return [0, 3]; if (/\.(x|y)$/.test(path)) return [-1, 1];
    const m = /fx\.(\w+)\.(\w+)$/.exec(path); if (m) { const f = SCHEMA.FX.find(x => x.id === m[1]); const p = f && f.params.find(x => x.k === m[2]); if (p) return [p.min, p.max]; } return [0, 1]; };

  UI.bpanels.timeline = {
    sig: s => JSON.stringify([(s.timeline.events || []).length, s.timeline.tracks.map(t => [t.id, t.layerId, t.items.length]), s.timeline.lanes.map(l => [l.id, l.path, l.points.length]), s.layers.map(l => l.id + l.name), s.timeline.duration, s.timeline.play.playing]),
    tools: s => `<button class="btn sm ${s.timeline.play.playing ? 'live' : 'primary'}" id="tlPlay">${s.timeline.play.playing ? '■ Stop' : '▶ Play'}</button><button class="btn sm icon" id="tlZero" title="Back to start">${I('restart')}</button>
      <span class="mono" id="tlTime" style="min-width:110px">00:00.0</span>
      <span class="tlabel">Length</span><input type="number" data-path="timeline.duration" min="1" style="width:64px"><span class="muted small">s</span>
      <button class="sw" data-path="timeline.loop" data-toggle title="Loop"></button><span class="muted small">Loop</span>
      <button class="sw" data-path="timeline.followTc" data-toggle title="Chase timecode"></button><span class="muted small">Chase TC</span>
      <button class="btn sm" id="tlAddEv" title="Add an event (OSC, DMX, cue, any action) at the playhead">${I('plus')}Event</button>
      <select id="tlAddTrack"><option value="">＋ Track…</option>${s.layers.map((l, i) => `<option value="${i}">${i + 1} · ${esc(l.name)}</option>`).join('')}</select>
      <select id="tlAddLane" style="width:140px"><option value="">＋ Automation…</option>${pathTargets(s).map(([v, l]) => `<option value="${esc(v)}">${esc(l)}</option>`).join('')}</select>
      <input type="range" id="tlZoom" min="2" max="200" value="${zoom || 20}" style="width:80px" title="Zoom">`,
    render: () => `<div class="libmain" style="padding:0;overflow:hidden;position:relative"><canvas id="tlCanvas" style="display:block;width:100%;height:100%"></canvas>
      <div class="tlhelp">Double-click a track to place the selected clip · drag to move · drag the right edge to trim · double-click a clip for fades · Delete removes · double-click the Events row to add an OSC / DMX / cue event · double-click a lane to add a point (right-click deletes) · click the ruler to seek</div></div>`,
    after(pane, s) {
      cv = $('#tlCanvas', pane); const host = cv.parentElement;
      const fit = () => { const r = host.getBoundingClientRect(); cv.width = Math.max(100, r.width) * devicePixelRatio; cv.height = Math.max(60, r.height) * devicePixelRatio; if (!zoom) zoom = Math.max(2, (r.width - LW - 20) / Math.max(10, s.timeline.duration)); };
      fit(); new ResizeObserver(fit).observe(host);
      $('#tlPlay').onclick = () => UI.cmd({ op: UI.st().timeline.play.playing ? 'tlStop' : 'tlPlay' });
      $('#tlZero').onclick = () => UI.cmd({ op: 'tlSeek', pos: 0 });
      $('#tlAddEv').onclick = () => addEvent(tlPos(UI.st()));
      $('#tlZoom').oninput = e => { zoom = +e.target.value; localStorage.pxTlZoom = zoom; };
      $('#tlAddTrack').onchange = e => { if (e.target.value !== '') UI.cmd({ op: 'tlAddTrack', layer: +e.target.value }); e.target.value = ''; };
      $('#tlAddLane').onchange = e => { if (e.target.value) { const [mn, mx] = rangeFor(e.target.value); UI.cmd({ op: 'tlAddLane', path: e.target.value, min: mn, max: mx }); } e.target.value = ''; };
      cv.onmousedown = down; cv.ondblclick = dbl; cv.oncontextmenu = ctx; cv.onwheel = e => { e.preventDefault(); if (e.ctrlKey || e.metaKey) { zoom = Math.max(2, Math.min(200, zoom * (e.deltaY < 0 ? 1.15 : 0.87))); } else scroll = Math.max(0, scroll + e.deltaY / zoom); };
      if (!bound) { addEventListener('mousemove', move); addEventListener('mouseup', up); bound = true; }
      if (!raf) loop();
    },
  };
  function rows(s) { const r = [{ kind: 'events', y: RH, h: EH }]; let y = RH + EH; for (const t of s.timeline.tracks) { r.push({ kind: 'track', t, y, h: TH }); y += TH; } for (const l of s.timeline.lanes) { r.push({ kind: 'lane', l, y, h: LH }); y += LH; } return r; }
  const tx = t => LW + (t - scroll) * zoom, xt = x => (x - LW) / zoom + scroll;
  function hit(e) {
    const s = UI.st(); const r = cv.getBoundingClientRect(); const x = e.clientX - r.left, y = e.clientY - r.top; const t = xt(x);
    if (y < RH) return { area: 'ruler', x, y, t };
    for (const row of rows(s)) if (y >= row.y && y < row.y + row.h) {
      if (row.kind === 'events') { if (x < LW) return { area: 'none', x, y, t }; const ev = (s.timeline.events || []).find(e => Math.abs(tx(e.at) - x) < 7); return ev ? { area: 'event', row, ev, x, y, t } : { area: 'events', row, x, y, t }; }
      if (x < LW) return { area: 'label', row, x, y, t };
      if (row.kind === 'track') { for (const it of row.t.items) { const x0 = tx(it.start), x1 = tx(it.start + it.dur); if (x >= x0 && x <= x1) return { area: 'item', row, it, edge: x > x1 - 7, x, y, t }; } return { area: 'track', row, x, y, t }; }
      const l = row.l; for (let i = 0; i < l.points.length; i++) { const [pt, pv] = l.points[i]; const px = tx(pt), py = row.y + row.h - 6 - ((pv - l.min) / ((l.max - l.min) || 1)) * (row.h - 12); if (Math.abs(px - x) < 7 && Math.abs(py - y) < 7) return { area: 'point', row, i, x, y, t }; }
      return { area: 'lane', row, x, y, t };
    }
    return { area: 'none', x, y, t };
  }
  function laneVal(row, y) { const l = row.l; const v = l.min + (1 - (y - row.y - 6) / (row.h - 12)) * (l.max - l.min); return Math.max(l.min, Math.min(l.max, +v.toFixed(4))); }
  function down(e) {
    if (e.button !== 0) return; const h = hit(e); const s = UI.st();
    if (h.area === 'ruler') { drag = { kind: 'seek' }; UI.cmd({ op: 'tlSeek', pos: Math.max(0, h.t) }); return; }
    if (h.area === 'label') { const lx = h.x; if (lx > LW - 26) { if (h.row.kind === 'track') UI.cmd({ op: 'tlRemoveTrack', id: h.row.t.id }); else UI.cmd({ op: 'tlRemoveLane', id: h.row.l.id }); }
      else if (lx > LW - 50 && h.row.kind === 'track') { const ti = s.timeline.tracks.indexOf(h.row.t); BVJ.cmd({ op: 'set', path: `timeline.tracks.${ti}.mute`, value: !h.row.t.mute }); }
      else if (lx > LW - 50 && h.row.kind === 'lane') { const li = s.timeline.lanes.indexOf(h.row.l); BVJ.cmd({ op: 'set', path: `timeline.lanes.${li}.on`, value: !h.row.l.on }); } return; }
    if (h.area === 'item') { sel = h.it.id; const ti = s.timeline.tracks.indexOf(h.row.t), ii = h.row.t.items.indexOf(h.it); local = JSON.parse(JSON.stringify(h.it)); drag = { kind: h.edge ? 'trim' : 'move', ti, ii, t0: h.t, start0: h.it.start, dur0: h.it.dur }; return; }
    if (h.area === 'point') { const li = s.timeline.lanes.indexOf(h.row.l); local = h.row.l.points.map(p => p.slice()); drag = { kind: 'point', li, i: h.i, row: h.row }; return; }
    if (h.area === 'event') { sel = h.ev.id; local = { at: h.ev.at }; drag = { kind: 'event', id: h.ev.id, t0: h.t, at0: h.ev.at, moved: false }; return; }
    sel = null;
  }
  function move(e) {
    if (!drag || !cv) return; const s = UI.st(); const r = cv.getBoundingClientRect(); const t = xt(e.clientX - r.left); const snap = v => e.shiftKey ? v : Math.round(v * 4) / 4;
    if (drag.kind === 'seek') { clearTimeout(drag.tm); drag.tm = setTimeout(() => UI.cmd({ op: 'tlSeek', pos: Math.max(0, t) }), 30); return; }
    if (drag.kind === 'move') local.start = Math.max(0, snap(drag.start0 + (t - drag.t0)));
    if (drag.kind === 'trim') local.dur = Math.max(0.25, snap(drag.dur0 + (t - drag.t0)));
    if (drag.kind === 'event') { local.at = Math.max(0, snap(drag.at0 + (t - drag.t0))); drag.moved = drag.moved || local.at !== drag.at0; return; }
    if (drag.kind === 'point') { const y = e.clientY - r.top; local[drag.i] = [Math.max(0, +snap(t).toFixed(3)), laneVal(drag.row, y)]; }
  }
  function up() {
    if (!drag) return; const s = UI.st();
    if (drag.kind === 'move' || drag.kind === 'trim') BVJ.cmd({ op: 'set', path: `timeline.tracks.${drag.ti}.items.${drag.ii}`, value: local });
    if (drag.kind === 'point') BVJ.cmd({ op: 'set', path: `timeline.lanes.${drag.li}.points`, value: local.sort((a, b) => a[0] - b[0]) });
    if (drag.kind === 'event' && drag.moved) UI.cmd({ op: 'tlMoveEvent', id: drag.id, at: local.at });
    drag = null; local = null;
  }
  function dbl(e) {
    const h = hit(e); const s = UI.st();
    if (h.area === 'events') return addEvent(Math.round(h.t * 4) / 4);
    if (h.area === 'event') return editEvent(h.ev.id);
    if (h.area === 'item') return editItem(h.it.id);
    if (h.area === 'track') { const li = s.layers.findIndex(l => l.id === h.row.t.layerId); const l = s.layers[li]; if (!l) return;
      let slot = UI.sel.layer === li && UI.sel.slot != null && l.clips[UI.sel.slot] ? UI.sel.slot : l.clips.findIndex(c => c); if (slot < 0) return UI.toast('That layer has no clips yet', 'err');
      UI.cmd({ op: 'tlAddItem', track: h.row.t.id, start: Math.max(0, Math.round(h.t * 4) / 4), dur: 8, slot }); }
    if (h.area === 'lane') { const li = s.timeline.lanes.indexOf(h.row.l); const pts = [...h.row.l.points.map(p => p.slice()), [Math.max(0, +h.t.toFixed(3)), laneVal(h.row, h.y)]].sort((a, b) => a[0] - b[0]); BVJ.cmd({ op: 'set', path: `timeline.lanes.${li}.points`, value: pts }); }
  }
  function ctx(e) { const h = hit(e); if (h.area === 'point') { e.preventDefault(); const s = UI.st(); const li = s.timeline.lanes.indexOf(h.row.l); BVJ.cmd({ op: 'set', path: `timeline.lanes.${li}.points`, value: h.row.l.points.filter((_, i) => i !== h.i) }); }
    else if (h.area === 'item') { e.preventDefault(); UI.cmd({ op: 'tlRemoveItem', id: h.it.id }); }
    else if (h.area === 'event') { e.preventDefault(); UI.cmd({ op: 'tlRemoveEvent', id: h.ev.id }); } }
  addEventListener('keydown', e => { if (UI.btab !== 'timeline' || !sel || (e.key !== 'Delete' && e.key !== 'Backspace') || /input|textarea|select/i.test(e.target.tagName)) return; e.stopImmediatePropagation(); const s = UI.st(); UI.cmd({ op: (s.timeline.events || []).some(x => x.id === sel) ? 'tlRemoveEvent' : 'tlRemoveItem', id: sel }); sel = null; }, true);

  // ---- events (fired as the playhead passes) and clip item settings
  function addEvent(at) {
    const before = new Set((UI.st().timeline.events || []).map(e => e.id)); UI.cmd({ op: 'tlAddEvent', at: Math.max(0, at) });
    let n = 0; const wait = () => { const e = (UI.st().timeline.events || []).find(x => !before.has(x.id)); if (e) editEvent(e.id); else if (n++ < 30) setTimeout(wait, 50); }; wait();
  }
  function editEvent(id) {
    const idx = () => (UI.st().timeline.events || []).findIndex(e => e.id === id), ev = () => UI.st().timeline.events[idx()];
    if (idx() < 0) return; sel = id;
    const body = UI.el('<div></div>'); let lastType = null;
    const draw = () => { const e = ev(); if (!e) return; lastType = (e.action || {}).type; const b = `timeline.events.${idx()}`;
      body.innerHTML = `<div class="row wide"><label>Name</label><div class="ctl"><input type="text" data-tlev="name" value="${esc(e.name)}"></div></div>
        <div class="row wide"><label>At (seconds)</label><div class="ctl"><input type="number" step="0.05" min="0" data-tlev="at" value="${e.at}" style="width:110px"><span class="muted small">${fmt(e.at)}</span></div></div>
        <div class="row wide"><label>On</label><div class="ctl"><input type="checkbox" data-tlev="on" ${e.on !== false ? 'checked' : ''}></div></div>
        <div class="hint">What happens when the playhead reaches this point — e.g. <b>Send OSC</b> to a console or QLab, <b>Set DMX</b> for a hazer or house lights, a cue, an overlay, a device action or a grandMA3 command.</div>
        ${UI.actionEditor(b + '.action', e.action)}`; };
    draw();
    body.addEventListener('change', e => { const k = e.target.dataset.tlev; if (!k) { if (e.target.dataset.actf === 'type' || e.target.dataset.actf === 'device') setTimeout(() => { if ((ev().action || {}).type !== lastType || e.target.dataset.actf === 'device') draw(); }, 200); return; }
      if (k === 'at') UI.cmd({ op: 'tlMoveEvent', id, at: +e.target.value || 0 }); else BVJ.cmd({ op: 'set', path: `timeline.events.${idx()}.${k}`, value: k === 'on' ? e.target.checked : e.target.value }); });
    UI.modal('Timeline event', body, [{ label: 'Delete', cls: 'danger', click: () => UI.cmd({ op: 'tlRemoveEvent', id }) }, { label: 'Test now', click: () => { const a = ev() && ev().action; if (a) UI.cmd({ op: 'runAction', action: a }); return false; } }, { label: 'Done', cls: 'primary' }], { width: '620px' });
  }
  function editItem(id) {
    const s = UI.st(); let ti = -1, ii = -1; s.timeline.tracks.forEach((t, a) => t.items.forEach((x, b) => { if (x.id === id) { ti = a; ii = b; } })); if (ti < 0) return; sel = id;
    const it = s.timeline.tracks[ti].items[ii], p = `timeline.tracks.${ti}.items.${ii}`;
    const body = UI.el(`<div><div class="row wide"><label>Start (s)</label><div class="ctl"><input type="number" step="0.05" min="0" data-k="start" value="${it.start}" style="width:110px"></div></div>
      <div class="row wide"><label>Length (s)</label><div class="ctl"><input type="number" step="0.05" min="0.1" data-k="dur" value="${it.dur}" style="width:110px"></div></div>
      <div class="row wide"><label>Fade in (s)</label><div class="ctl"><input type="number" step="0.1" min="0" data-k="fadeIn" value="${it.fadeIn || 0}" style="width:110px"></div></div>
      <div class="row wide"><label>Fade out (s)</label><div class="ctl"><input type="number" step="0.1" min="0" data-k="fadeOut" value="${it.fadeOut || 0}" style="width:110px"></div></div>
      <div class="hint">Fades scale the layer's opacity at the start and end of this clip, exactly in time on every output.</div></div>`);
    UI.modal('Timeline clip', body, [{ label: 'Cancel' }, { label: 'Save', cls: 'primary', click: () => { const v = Object.assign({}, it); body.querySelectorAll('[data-k]').forEach(i => { v[i.dataset.k] = Math.max(0, +i.value || 0); }); v.dur = Math.max(0.1, v.dur); v.fadeIn = Math.min(v.fadeIn, v.dur); v.fadeOut = Math.min(v.fadeOut, v.dur); BVJ.cmd({ op: 'set', path: p, value: v }); } }], { width: '420px' });
  }
  function loop() {
    raf = requestAnimationFrame(loop); const s = UI.st(); if (!s || UI.btab !== 'timeline' || !cv || !cv.isConnected) return;
    const g = cv.getContext('2d'); const dpr = devicePixelRatio; const W = cv.width / dpr, H = cv.height / dpr; g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.fillStyle = '#0c0c11'; g.fillRect(0, 0, W, H); const tl = s.timeline; const pos = tlPos(s); const tEl = $('#tlTime'); if (tEl) tEl.textContent = fmt(pos) + ' / ' + fmt(tl.duration);
    // ruler
    g.fillStyle = '#15151c'; g.fillRect(0, 0, W, RH); const step = zoom > 60 ? 1 : zoom > 20 ? 5 : zoom > 6 ? 10 : 30;
    g.font = '10px ui-monospace,monospace'; g.textBaseline = 'middle';
    for (let t = Math.floor(scroll / step) * step; tx(t) < W; t += step) { const x = tx(t); if (x < LW) continue; g.fillStyle = '#2a2a36'; g.fillRect(x, RH - 8, 1, 8); g.fillStyle = '#8b8b99'; g.fillText(fmt(t).replace(/\.0$/, ''), x + 3, RH / 2 - 2); g.fillStyle = '#16161d'; g.fillRect(x, RH, 1, H); }
    const endX = tx(tl.duration); g.fillStyle = 'rgba(255,47,208,.08)'; if (endX < W) g.fillRect(endX, RH, W - endX, H);
    for (const row of rows(s)) {
      if (row.kind === 'events') {
        g.fillStyle = '#101017'; g.fillRect(LW, row.y, W, row.h); g.fillStyle = '#16161e'; g.fillRect(0, row.y, LW, row.h - 1); g.fillStyle = '#1d1d26'; g.fillRect(0, row.y + row.h - 1, W, 1);
        g.fillStyle = '#ffd23f'; g.font = '600 12px Inter,sans-serif'; g.fillText('Events', 10, row.y + row.h / 2); g.fillStyle = '#5c5f6a'; g.font = '10px Inter,sans-serif'; g.fillText('OSC · DMX · cues', 62, row.y + row.h / 2);
        const evs = s.timeline.events || []; if (!evs.length) { g.fillStyle = '#3a3a48'; g.font = '11px Inter,sans-serif'; g.fillText('double-click to add an event', LW + 10, row.y + row.h / 2); }
        for (const e0 of evs) { const at = drag && drag.kind === 'event' && drag.id === e0.id ? local.at : e0.at, x = tx(at); if (x < LW - 6 || x > W + 6) continue;
          g.fillStyle = e0.on === false ? '#5c5f6a' : sel === e0.id ? '#ff2fd0' : '#ffd23f'; g.beginPath(); g.moveTo(x, row.y + 6); g.lineTo(x + 6, row.y + row.h / 2); g.lineTo(x, row.y + row.h - 6); g.lineTo(x - 6, row.y + row.h / 2); g.closePath(); g.fill();
          g.fillStyle = e0.on === false ? '#5c5f6a' : '#e7e8ec'; g.font = '11px Inter,sans-serif'; g.fillText(e0.name, x + 9, row.y + row.h / 2); g.fillStyle = 'rgba(255,210,63,.12)'; g.fillRect(x, row.y + row.h, 1, H); }
        continue;
      }
      g.fillStyle = row.kind === 'track' ? '#121219' : '#0f0f15'; g.fillRect(LW, row.y, W, row.h); g.fillStyle = '#1d1d26'; g.fillRect(0, row.y + row.h - 1, W, 1);
      g.fillStyle = '#16161e'; g.fillRect(0, row.y, LW, row.h - 1);
      if (row.kind === 'track') {
        const li = s.layers.findIndex(l => l.id === row.t.layerId); const l = s.layers[li];
        g.fillStyle = row.t.mute ? '#5c5f6a' : '#e7e8ec'; g.font = '600 12px Inter,sans-serif'; g.fillText(l ? `${li + 1} · ${l.name}` : '(deleted layer)', 10, row.y + row.h / 2);
        g.fillStyle = row.t.mute ? '#ffd23f' : '#5c5f6a'; g.font = '700 10px ui-monospace,monospace'; g.fillText('M', LW - 42, row.y + row.h / 2); g.fillStyle = '#ff4d5e'; g.fillText('✕', LW - 20, row.y + row.h / 2);
        for (const it0 of row.t.items) { const it = local && sel === it0.id && drag && drag.kind !== 'point' ? local : it0; const x0 = tx(it.start), x1 = tx(it.start + it.dur); if (x1 < LW || x0 > W) continue;
          const c = l && l.clips[it.slot]; const gr = g.createLinearGradient(x0, 0, x1, 0); gr.addColorStop(0, sel === it0.id ? '#ff2fd0' : '#6b3bff'); gr.addColorStop(1, sel === it0.id ? '#9b3bff' : '#2f6bff');
          g.fillStyle = gr; g.globalAlpha = row.t.mute ? 0.4 : 0.9; roundR(g, Math.max(LW, x0), row.y + 5, Math.max(4, x1 - Math.max(LW, x0)), row.h - 10, 5); g.fill(); g.globalAlpha = 1;
          g.save(); g.beginPath(); g.rect(Math.max(LW, x0), row.y, x1 - Math.max(LW, x0), row.h); g.clip(); g.fillStyle = '#fff'; g.font = '600 11px Inter,sans-serif'; g.fillText(c ? BVJ.clipLabel(c) : `slot ${it.slot + 1} (empty)`, Math.max(LW, x0) + 7, row.y + row.h / 2); g.restore();
          g.fillStyle = 'rgba(255,255,255,.5)'; g.fillRect(x1 - 3, row.y + 12, 2, row.h - 24);
          const fi = (+it.fadeIn || 0) * zoom, fo = (+it.fadeOut || 0) * zoom; g.fillStyle = 'rgba(0,0,0,.45)'; // fade ramps
          if (fi > 1) { g.beginPath(); g.moveTo(x0, row.y + 5); g.lineTo(x0 + fi, row.y + 5); g.lineTo(x0, row.y + row.h - 5); g.closePath(); g.fill(); }
          if (fo > 1) { g.beginPath(); g.moveTo(x1, row.y + 5); g.lineTo(x1 - fo, row.y + 5); g.lineTo(x1, row.y + row.h - 5); g.closePath(); g.fill(); } }
      } else {
        const ln = row.l; const pts = local && drag && drag.kind === 'point' && drag.li === s.timeline.lanes.indexOf(ln) ? local : ln.points;
        g.fillStyle = ln.on ? '#2fe0d0' : '#5c5f6a'; g.font = '600 11px Inter,sans-serif'; const nm = ln.path.replace(/^layers\.(\d+)\./, (m, i) => 'L' + (+i + 1) + ' '); g.fillText(nm.length > 20 ? '…' + nm.slice(-19) : nm, 10, row.y + 18);
        g.fillStyle = '#5c5f6a'; g.font = '10px ui-monospace,monospace'; g.fillText(`${ln.min}…${ln.max}`, 10, row.y + 36); g.fillStyle = ln.on ? '#2fe0d0' : '#5c5f6a'; g.fillText(ln.on ? 'ON' : 'OFF', LW - 46, row.y + row.h / 2); g.fillStyle = '#ff4d5e'; g.fillText('✕', LW - 20, row.y + row.h / 2);
        const yOf = v => row.y + row.h - 6 - ((v - ln.min) / ((ln.max - ln.min) || 1)) * (row.h - 12);
        if (pts.length) { g.strokeStyle = ln.on ? '#2fe0d0' : '#5c5f6a'; g.lineWidth = 2; g.beginPath(); g.moveTo(LW, yOf(pts[0][1])); for (const [t, v] of pts) g.lineTo(tx(t), yOf(v)); g.lineTo(W, yOf(pts[pts.length - 1][1])); g.stroke();
          for (const [t, v] of pts) { g.fillStyle = '#fff'; g.beginPath(); g.arc(tx(t), yOf(v), 4.5, 0, 7); g.fill(); } }
        else { g.fillStyle = '#3a3a48'; g.font = '11px Inter,sans-serif'; g.fillText('double-click to add automation points', LW + 10, row.y + row.h / 2); }
      }
    }
    if (!s.timeline.tracks.length && !s.timeline.lanes.length) { g.fillStyle = '#5c5f6a'; g.font = '13px Inter,sans-serif'; g.fillText('Add a track (one per layer) or an automation lane from the toolbar to start building a timed show.', LW + 10, RH + EH + 30); }
    g.fillStyle = '#1d1d26'; g.fillRect(LW - 1, 0, 1, H);
    const px = tx(pos); if (px >= LW) { g.fillStyle = '#ff2fd0'; g.fillRect(px - 1, 0, 2, H); g.beginPath(); g.moveTo(px - 6, 0); g.lineTo(px + 6, 0); g.lineTo(px, 8); g.fill(); }
    if (s.timeline.play.playing && px > W - 40) scroll += (px - (W - 40)) / zoom;
  }
  function roundR(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
})();
