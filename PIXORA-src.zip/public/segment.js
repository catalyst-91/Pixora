/* PIXORA — AI background removal (person segmentation) without a green screen. Runs locally on the output computer's GPU
   with Google MediaPipe's selfie segmenter (Apache 2.0); the desktop app bundles the runtime and model in /vendor/mediapipe
   (fetched when the app is built). Nothing leaves the machine. PixoraSeg.mask(el) → { data: Uint8Array (0–255 = person),
   w, h } for a video / canvas element, or null while the model loads (or when it isn't installed: see PixoraSeg.status). */
(function (root) {
  'use strict';
  const BASE = '/vendor/mediapipe/';
  const S = root.PixoraSeg = { status: 'idle', error: '', backend: '', provider: null, last: new WeakMap(), ms: 0 };
  let seg = null, loading = null;
  async function load() {
    S.status = 'loading';
    try {
      const head = await fetch(BASE + 'selfie_segmenter.tflite', { method: 'HEAD' }); if (!head.ok) throw new Error('not installed');
      const vision = await import(BASE + 'vision_bundle.mjs');
      const files = await vision.FilesetResolver.forVisionTasks(BASE + 'wasm');
      const make = delegate => vision.ImageSegmenter.createFromOptions(files, { baseOptions: { modelAssetPath: BASE + 'selfie_segmenter.tflite', delegate }, runningMode: 'VIDEO', outputConfidenceMasks: true, outputCategoryMask: false });
      try { seg = await make('GPU'); S.backend = 'GPU'; } catch { seg = await make('CPU'); S.backend = 'CPU'; }
      S.status = 'ready';
    } catch (e) { S.status = 'unavailable'; S.error = String(e.message || e); }
  }
  S.ensure = () => { if (S.provider) { S.status = 'ready'; S.backend = 'test'; return true; } if (!loading) loading = load(); return S.status === 'ready'; };
  // one mask per element per new picture (a paused video or a still canvas keeps its mask)
  S.mask = (el, key) => {
    if (!el || !S.ensure()) return null;
    const vw = el.videoWidth || el.width, vh = el.videoHeight || el.height; if (!vw || !vh) return null;
    const stamp = el.currentTime != null ? el.currentTime + (el.paused ? ':p' : '') : performance.now() >> 5; // a new video / camera frame, or ~30 checks a second for canvases
    const prev = S.last.get(el); if (prev && prev.stamp === stamp) return prev.m;
    let m = null; const t0 = performance.now();
    try {
      if (S.provider) m = S.provider(el, vw, vh); // tests / other models plug in here
      else { const r = seg.segmentForVideo(el, performance.now()); const cm = r.confidenceMasks && r.confidenceMasks[0];
        if (cm) { const f = cm.getAsFloat32Array(), d = new Uint8Array(f.length); for (let i = 0; i < f.length; i++) d[i] = f[i] * 255; m = { data: d, w: cm.width, h: cm.height }; }
        r.close && r.close(); }
    } catch (e) { S.error = String(e.message || e); }
    S.ms = S.ms * 0.9 + (performance.now() - t0) * 0.1; S.last.set(el, { stamp, m }); return m;
  };
})(typeof window !== 'undefined' ? window : this);
