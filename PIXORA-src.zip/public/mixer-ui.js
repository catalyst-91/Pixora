/* PIXORA — Audio mixer: a strip per layer (fader, mute, audio-follows-video, peak meter) and the master. */
(function () {
  const UI = window.UI, $ = UI.$, $$ = UI.$$, esc = UI.esc;
  UI.MORETABS.push(['mixer', 'Audio Mixer', 'midi', 'Audio']);
  let lv = { layers: [], master: -60, buses: {}, at: 0 }; const hold = {};
  (BVJ.extraHandlers = BVJ.extraHandlers || {}).meters = m => { lv = { layers: m.layers || [], master: m.master, buses: m.buses || {}, at: Date.now() }; };
  UI.audioDev = { devices: [], buses: [] }; BVJ.extraHandlers.audiodev = m => { const was = JSON.stringify(UI.audioDev); UI.audioDev = m; if (UI.rtab === 'mixer' && was !== JSON.stringify(m)) UI.renderRight(true); };
  setTimeout(() => UI.api('/api/audio/devices').then(m => { UI.audioDev = m; }).catch(() => {}), 1500);
  const db = v => v <= 0.0001 ? '−∞' : (20 * Math.log10(v)).toFixed(1);
  const pct = d => Math.max(0, Math.min(100, (d + 60) / 60 * 100)); // −60…0 dBFS → 0…100 %
  function paintMeters() {
    if (UI.rtab !== 'mixer') return; const stale = Date.now() - lv.at > 1500;
    $$('[data-meter]').forEach(el => { const k = el.dataset.meter, d = stale ? -60 : k === 'm' ? lv.master : (lv.layers[+k] ?? -60);
      const h = hold[k] = Math.max(d, (hold[k] ?? -60) - 0.6); el.firstElementChild.style.height = pct(d) + '%'; el.lastElementChild.style.bottom = pct(h) + '%'; el.classList.toggle('clip', d > -0.5); });
    requestAnimationFrame(paintMeters);
  }
  UI.panels.mixer = {
    sig: s => JSON.stringify([s.layers.map(l => [l.name, l.mute, l.afv, l.audioOut]), s.comp.mute, (s.comp.audioOuts || []).map(a => [a.id, a.name, a.device, a.ch, a.mono, a.mute])]),
    render(s) {
      const strip = (k, name, path, mute, extra) => `<div class="mxs"><div class="mxname" title="${esc(name)}">${esc(name)}</div>
        <div class="mxbody"><div class="mxmeter" data-meter="${k}"><i></i><b></b></div><input type="range" min="0" max="1" step="0.01" data-path="${path}" orient="vertical" class="mxfader"></div>
        <div class="mxdb mono small" data-mxdb="${path}"></div>
        <button class="btn sm ${mute ? 'danger' : ''}" data-mxmute="${path.replace(/volume$/, 'mute')}">M</button>${extra || ''}</div>`;
      const outs = s.comp.audioOuts || [{ id: 'main', name: 'Main' }], multi = outs.length > 1;
      const route = i => multi ? `<select data-path="layers.${i}.audioOut" class="mxroute" title="Audio output for this layer">${outs.map(o => `<option value="${esc(o.id)}">${esc(o.name)}</option>`).join('')}</select>` : '';
      const strips = s.layers.map((l, i) => strip(String(i), `${i + 1} ${l.name || ''}`, `layers.${i}.volume`, l.mute, `<button class="btn sm ${l.afv ? 'primary' : ''}" data-mxafv="${i}" title="Audio follows video: silent while the layer is faded out">AFV</button>${route(i)}`)).join('');
      const D = UI.audioDev || { devices: [], buses: [] }, stat = id => (D.buses || []).find(b => b.id === id);
      const devOpts = o => { const list = (D.devices || []).filter(d => d.id !== 'default'); const known = list.some(d => d.id === o.device || d.label === o.deviceLabel);
        return `<option value="">Default output</option>${list.map(d => `<option value="${esc(d.id)}" ${d.id === o.device || (!known ? false : d.label === o.deviceLabel && !o.device) ? 'selected' : ''}>${esc(d.label)}${d.channels ? ` (${d.channels} ch)` : ''}</option>`).join('')}${(o.device || o.deviceLabel) && !known ? `<option value="${esc(o.device)}" selected>${esc(o.deviceLabel || 'Missing device')} — not connected</option>` : ''}`; };
      const chOpts = o => { const st = stat(o.id), n = Math.max(2, (st && st.channels) || 2, o.ch + 1), opts = [];
        for (let c = 1; c <= Math.min(64, n); c += o.mono ? 1 : 2) opts.push(`<option value="${c}" ${c === o.ch ? 'selected' : ''}>${o.mono ? 'Ch ' + c : c + '–' + (c + 1)}</option>`);
        if (!opts.some(x => x.includes(`value="${o.ch}"`))) opts.push(`<option value="${o.ch}" selected>${o.mono ? 'Ch ' + o.ch : o.ch + '–' + (o.ch + 1)}</option>`); return opts.join(''); };
      const busRows = outs.map((o, k) => { const st = stat(o.id), b = `comp.audioOuts.${k}`;
        return `<div class="mxbus"><div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
          <div class="mxmeter mxmeter-h" data-meter="b:${esc(o.id)}" title="Level on this output"><i></i><b></b></div>
          <input type="text" value="${esc(o.name)}" data-busname="${k}" style="width:110px" ${o.id === 'main' ? 'title="The Main output"' : ''}>
          <select data-busdev="${k}" style="max-width:220px">${devOpts(o)}</select>
          <select data-busch="${k}" title="Output channels">${chOpts(o)}</select>
          <label class="small"><input type="checkbox" data-path="${b}.mono"> mono</label>
          <button class="btn sm ${o.mute ? 'danger' : ''}" data-busmute="${k}">M</button>
          ${o.id === 'main' ? '' : `<button class="btn sm" data-busdel="${esc(o.id)}" title="Remove this output">✕</button>`}</div>
          <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:4px 0 0 30px"><span class="small muted">Gain</span><input type="range" min="0" max="2" step="0.01" data-path="${b}.gain" style="width:120px"><span class="small mono" data-mxdb="${b}.gain"></span>
          <span class="small muted">Delay</span><input type="number" min="0" max="2000" step="1" data-path="${b}.delay" style="width:70px"><span class="small muted">ms</span>
          <span class="small ${st && !st.ok ? '' : 'muted'}" style="${st && st.error ? 'color:var(--amber, #ffb43f)' : ''}">${st ? (st.error ? esc(st.error) : `● ${esc(st.device)}`) : 'waiting for the output window…'}</span></div></div>`; }).join('');
      return `<div class="sec"><h4>Audio mixer</h4><div class="mxwrap">${strips}<div class="mxsep"></div>${strip('m', 'MASTER', 'comp.volume', s.comp.mute)}</div>
        <div class="hint">Meters show what the main output is playing (peak, dBFS). M mutes a layer; AFV keeps a layer silent while it is faded out, so a camera or video is only heard when it is seen. Audio is mixed in the output window and recorded with Local recording / NDI audio.</div></div>
        <div class="sec"><h4>Outputs</h4>${busRows}<button class="btn sm" data-busadd style="margin-top:6px">+ Add output</button>
        <div class="hint">Send each layer — or a single clip (Clip ▸ Audio output) — to its own output: walk-in music to FOH on channels 1–2, video playback to a record feed on 3–4, a presenter's video to monitors. Pick any device the main output computer has: Dante Virtual Soundcard, a multi-channel interface, HDMI / SDI embedders. Delay lines the audio up with a delayed picture (LED processor, projector). The program mix for recording, NDI and streaming always contains every layer.</div></div>`;
    },
    after(pane) {
      const showDb = () => $$('[data-mxdb]', pane).forEach(el => { el.textContent = db(+BVJ.get(el.dataset.mxdb) ?? 1) + ' dB'; });
      pane.addEventListener('input', showDb); showDb();
      pane.onchange = e => { const t = e.target, d = t.dataset;
        if (d.busname != null) UI.cmd({ op: 'set', path: `comp.audioOuts.${d.busname}.name`, value: t.value || 'Output' });
        if (d.busdev != null) { const dev = ((UI.audioDev || {}).devices || []).find(x => x.id === t.value); UI.cmd({ op: 'set', path: `comp.audioOuts.${d.busdev}.device`, value: t.value }); UI.cmd({ op: 'set', path: `comp.audioOuts.${d.busdev}.deviceLabel`, value: dev ? dev.label : '' }); }
        if (d.busch != null) UI.cmd({ op: 'set', path: `comp.audioOuts.${d.busch}.ch`, value: +t.value }); };
      pane.onclick = e => { const t = e.target.closest('button'); if (!t) return;
        if (t.dataset.busmute != null) { BVJ.set(`comp.audioOuts.${t.dataset.busmute}.mute`, !BVJ.get(`comp.audioOuts.${t.dataset.busmute}.mute`)); return; }
        if (t.dataset.busadd != null) { UI.cmd({ op: 'audioOutAdd', ch: ((BVJ.state.comp.audioOuts || []).length * 2 + 1) }); return; }
        if (t.dataset.busdel) { if (confirm('Remove this output? Layers and clips sent to it go back to Main.')) UI.cmd({ op: 'audioOutDel', id: t.dataset.busdel }); return; }
        if (t.dataset.mxmute) BVJ.set(t.dataset.mxmute, !BVJ.get(t.dataset.mxmute));
        if (t.dataset.mxafv != null) BVJ.set(`layers.${t.dataset.mxafv}.afv`, !BVJ.get(`layers.${t.dataset.mxafv}.afv`)); };
      requestAnimationFrame(paintMeters);
    },
  };
})();
