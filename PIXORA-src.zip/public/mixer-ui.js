/* PIXORA — Audio mixer: a strip per layer (fader, mute, audio-follows-video, peak meter) and the master. */
(function () {
  const UI = window.UI, $ = UI.$, $$ = UI.$$, esc = UI.esc;
  UI.MORETABS.push(['mixer', 'Audio Mixer', 'midi', 'Audio']);
  let lv = { layers: [], master: -60, at: 0 }; const hold = {};
  (BVJ.extraHandlers = BVJ.extraHandlers || {}).meters = m => { lv = { layers: m.layers || [], master: m.master, at: Date.now() }; };
  const db = v => v <= 0.0001 ? '−∞' : (20 * Math.log10(v)).toFixed(1);
  const pct = d => Math.max(0, Math.min(100, (d + 60) / 60 * 100)); // −60…0 dBFS → 0…100 %
  function paintMeters() {
    if (UI.rtab !== 'mixer') return; const stale = Date.now() - lv.at > 1500;
    $$('[data-meter]').forEach(el => { const k = el.dataset.meter, d = stale ? -60 : k === 'm' ? lv.master : (lv.layers[+k] ?? -60);
      const h = hold[k] = Math.max(d, (hold[k] ?? -60) - 0.6); el.firstElementChild.style.height = pct(d) + '%'; el.lastElementChild.style.bottom = pct(h) + '%'; el.classList.toggle('clip', d > -0.5); });
    requestAnimationFrame(paintMeters);
  }
  UI.panels.mixer = {
    sig: s => JSON.stringify([s.layers.map(l => [l.name, l.mute, l.afv]), s.comp.mute]),
    render(s) {
      const strip = (k, name, path, mute, extra) => `<div class="mxs"><div class="mxname" title="${esc(name)}">${esc(name)}</div>
        <div class="mxbody"><div class="mxmeter" data-meter="${k}"><i></i><b></b></div><input type="range" min="0" max="1" step="0.01" data-path="${path}" orient="vertical" class="mxfader"></div>
        <div class="mxdb mono small" data-mxdb="${path}"></div>
        <button class="btn sm ${mute ? 'danger' : ''}" data-mxmute="${path.replace(/volume$/, 'mute')}">M</button>${extra || ''}</div>`;
      const strips = s.layers.map((l, i) => strip(String(i), `${i + 1} ${l.name || ''}`, `layers.${i}.volume`, l.mute, `<button class="btn sm ${l.afv ? 'primary' : ''}" data-mxafv="${i}" title="Audio follows video: silent while the layer is faded out">AFV</button>`)).join('');
      return `<div class="sec"><h4>Audio mixer</h4><div class="mxwrap">${strips}<div class="mxsep"></div>${strip('m', 'MASTER', 'comp.volume', s.comp.mute)}</div>
        <div class="hint">Meters show what the main output is playing (peak, dBFS). M mutes a layer; AFV keeps a layer silent while it is faded out, so a camera or video is only heard when it is seen. Audio is mixed in the output window and recorded with Local recording / NDI audio.</div></div>`;
    },
    after(pane) {
      const showDb = () => $$('[data-mxdb]', pane).forEach(el => { el.textContent = db(+BVJ.get(el.dataset.mxdb) ?? 1) + ' dB'; });
      pane.addEventListener('input', showDb); showDb();
      pane.onclick = e => { const t = e.target.closest('button'); if (!t) return;
        if (t.dataset.mxmute) BVJ.set(t.dataset.mxmute, !BVJ.get(t.dataset.mxmute));
        if (t.dataset.mxafv != null) BVJ.set(`layers.${t.dataset.mxafv}.afv`, !BVJ.get(`layers.${t.dataset.mxafv}.afv`)); };
      requestAnimationFrame(paintMeters);
    },
  };
})();
