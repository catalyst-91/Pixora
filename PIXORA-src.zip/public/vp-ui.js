/* PIXORA — Virtual production: FreeD camera tracking, LED volume walls, a camera simulator for setting up without a tracker. */
(function () {
  const UI = window.UI, $ = UI.$, esc = UI.esc, I = UI.icon;
  const i = UI.MORETABS.findIndex(t => t[0] === 'audience'); UI.MORETABS.splice(i + 1, 0, ['vp', 'Virtual production', 'cam', 'VP']);
  const sec = (t, b) => `<div class="sec"><h4>${t}</h4>${b}</div>`; let ST = {}, PS = {};
  const num = (label, path, step, unit, w) => `<div class="row wide"><label>${esc(label)}</label><div class="ctl"><input type="number" data-path="${path}" step="${step || 0.01}" style="width:${w || 90}px"><span class="muted small">${unit || ''}</span></div></div>`;
  const trio = (label, base, keys, step, unit) => `<div class="row wide"><label>${esc(label)}</label><div class="ctl">${keys.map(k => `<span class="muted small">${k.toUpperCase()}</span><input type="number" data-path="${base}.${k}" step="${step}" style="width:72px">`).join(' ')}<span class="muted small">${unit}</span></div></div>`;
  UI.panels.vp = {
    sig: s => JSON.stringify([s.vp.on, s.vp.sim, (s.vp.lens || []).length, s.vp.inner && s.vp.inner.mode, s.vp.walls.map(w => w.id), (s.models || []).length, s.psn && s.psn.on, s.layers.length]),
    render(s) {
      const v = s.vp, cams = Object.values(ST.cams || {});
      let h = sec('Virtual production', `${UI.rToggle('Camera tracking (FreeD)', 'vp.on')}${num('UDP port', 'vp.port', 1, '', 90)}${num('Camera id', 'vp.cam', 1, 'the tracked camera to follow', 70)}
        <div class="kv"><span>Tracking</span><b id="vpStat">—</b></div>
        <div class="hint">A 3D Scene clip set to <b>Camera: Tracked camera</b> renders each LED wall below from the tracked camera's position (off-axis projection), so the wall shows correct parallax through the lens. Put the clip on a layer that fills the comp; the walls' comp regions are where each wall's picture goes — map them to the LED processors with the LED screens / Advanced output as usual.</div>`);
      h += sec('Camera position', `${trio('Offset', 'vp.offset', ['x', 'y', 'z'], 0.01, 'm — where the tracking origin is on the stage')}
        <div class="row wide"><label>Flip axes</label><div class="ctl">${['x', 'y', 'z'].map(k => `<label class="small"><input type="checkbox" data-vpinv="${k}" ${v.invert[k] ? 'checked' : ''}> ${k.toUpperCase()}</label>`).join(' ')}</div></div>
        <div class="hint">Stage coordinates are metres with Y up and the walls facing +Z. FreeD X / Y are the floor and Z the height; flip an axis if the camera moves the wrong way.</div>
        ${UI.rToggle('Simulate the camera (no tracker)', 'vp.sim')}${v.sim ? trio('Sim position', 'vp.simPose', ['x', 'y', 'z'], 10, 'mm (FreeD units)') + `<div class="hint">Drag the numbers to walk the virtual camera around; the walls update live.</div>` : ''}`);
      const L = v.lens || [], inn = v.inner || {};
      h += sec('Camera & lens', `${num('Video delay', 'vp.delayMs', 1, 'ms — hold tracking back to match the camera\'s picture', 80)}${num('Field of view', 'vp.fov', 0.1, '° horizontal, when there is no lens table', 80)}${num('Sensor aspect', 'vp.sensorAspect', 0.01, 'width ÷ height (1.78 = 16:9)', 80)}
        ${num('Pan offset', 'vp.panOffset', 0.1, '°', 80)}${num('Tilt offset', 'vp.tiltOffset', 0.1, '°', 80)}<div class="row wide"><label>Flip pan</label><div class="ctl"><label class="small"><input type="checkbox" data-vpinv="pan" ${v.invert && v.invert.pan ? 'checked' : ''}> pan turns the other way</label></div></div>
        <div class="row wide"><label>Lens table</label><div class="ctl small muted">zoom encoder → horizontal field of view</div></div>
        ${L.map((r, j) => `<div class="row wide"><label>Point ${j + 1}</label><div class="ctl"><span class="muted small">zoom</span><input type="number" data-path="vp.lens.${j}.zoom" style="width:90px"><span class="muted small">→</span><input type="number" step="0.1" data-path="vp.lens.${j}.fov" style="width:70px"><span class="muted small">°</span><button class="btn xs" data-vpx="lensDel" data-i="${j}">✕</button></div></div>`).join('')}
        <button class="btn sm" data-vpx="lensAdd">${I('plus')}Point at the current zoom</button>
        ${v.sim ? trio('Sim pan / tilt / zoom', 'vp.simPose', ['pan', 'tilt', 'zoom'], 1, '° / ° / encoder') : ''}
        <div class="hint">Zoom the lens to a few positions; at each, add a point and type the field of view you measured (or read from the lens data). In between, PIXORA interpolates.</div>`);
      h += sec('Inner frustum', `${UI.rSelect('Outside the camera\'s view', 'vp.inner.mode', [['off', 'Same as inside (no frustum)'], ['dim', 'Dim'], ['black', 'Black'], ['color', 'Colour']])}
        ${inn.mode && inn.mode !== 'off' ? `${UI.rRange('Margin', 'vp.inner.margin', 0, 1, 0.01, 0.1)}${UI.rRange('Edge softness', 'vp.inner.softness', 0, 1, 0.01, 0.1)}${inn.mode === 'dim' ? UI.rRange('Outside level', 'vp.inner.dim', 0, 1, 0.01, 0.3) : ''}${inn.mode === 'color' ? UI.rColor('Colour', 'vp.inner.color') : ''}` : ''}
        <div class="hint">The part of each wall the tracked camera can see (its frustum, from position, pan / tilt / roll and the lens) keeps the full scene; the rest — what only lights the set and the talent — can be dimmed, blacked out or set to a colour, with a margin for fast moves.</div>`);
      h += sec('Scene placement', `${trio('Scene origin', 'vp.scene', ['x', 'y', 'z'], 0.01, 'm')}<div class="hint">In tracked mode the model isn't centred or auto-scaled: 1 model unit = 1 m, placed at this origin (the clip's Model scale and Model turn still apply).</div>`);
      h += sec('LED walls', (v.walls.length ? '' : '<div class="hint">Add one wall per flat LED surface — e.g. a back wall and two side walls of a volume, or a floor.</div>') + v.walls.map((w, j) => { const b = `vp.walls.${j}`;
        return `<div class="card"><header><b>${esc(w.name)}</b><span class="mono small">${(+w.w).toFixed(2)} × ${(+w.h).toFixed(2)} m</span><button class="btn xs danger" data-vpx="del" data-i="${j}">${I('trash')}</button></header><div class="body">
          <div class="row wide"><label>Name</label><div class="ctl"><input type="text" data-path="${b}.name"></div></div>
          ${trio('Centre', b, ['cx', 'cy', 'cz'], 0.01, 'm')}${trio('Size', b, ['w', 'h'], 0.01, 'm')}${trio('Facing', b, ['yaw', 'pitch'], 1, '° (yaw 90 = left side wall, pitch 90 = floor)')}
          ${trio('Comp region', b, ['rx', 'ry', 'rw', 'rh'], 1, 'px')}</div></div>`; }).join('') + `<button class="btn sm primary" data-vpx="add">${I('plus')}Add wall</button> <button class="btn sm" data-vpx="volume">Make a 3-wall volume</button>`);
      const ps = s.psn || {}, tr = (PS.trackers || []);
      h += sec('PosiStageNet tracking', `${UI.rToggle('Receive PosiStageNet', 'psn.on')}${num('UDP port', 'psn.port', 1, '', 90)}<div class="row wide"><label>Multicast group</label><div class="ctl"><input type="text" data-path="psn.group" style="width:140px"></div></div>
        <div class="kv"><span>Trackers</span><b id="psnStat">${ps.on ? '—' : 'off'}</b></div><div id="psnList" class="small mono"></div>
        <div class="hint">Positions of performers, moving set pieces and flown screens from BlackTrax, Stage Precision, Zactrack, Kinesys bridges or a lighting desk. Any parameter can follow a tracker with an expression — <span class="mono">track(1, "x")</span> gives tracker 1's X in metres (Mods ▸ Expressions). Quick set-up:</div>
        <div class="row wide"><label>Layer follows</label><div class="ctl"><select id="psnLayer">${s.layers.map((l, i) => `<option value="${i}">${esc(l.name || 'Layer ' + (i + 1))}</option>`).join('')}</select><select id="psnTr">${tr.length ? tr.map(t => `<option value="${t.id}">${t.id} ${esc(t.name || '')}</option>`).join('') : '<option value="1">tracker 1</option>'}</select></div></div>
        <div class="row wide"><label>Stage left → right</label><div class="ctl"><input type="number" id="psnX0" value="-5" step="0.1" style="width:70px"> → <input type="number" id="psnX1" value="5" step="0.1" style="width:70px"><span class="muted small">m on X = comp left → right</span></div></div>
        <div class="row wide"><label>Bottom → top</label><div class="ctl"><select id="psnVA"><option value="z">Z</option><option value="y">Y</option></select><input type="number" id="psnY0" value="0" step="0.1" style="width:70px"> → <input type="number" id="psnY1" value="8" step="0.1" style="width:70px"><span class="muted small">m = comp bottom → top</span></div></div>
        <button class="btn sm" data-vpx="psnFollow">Make the layer follow</button>`);
      return h;
    },
    live() { const el = $('#vpStat'); if (!el) return; const v = UI.st().vp, c = (ST.cams || {})[v.cam | 0];
      el.innerHTML = !v.on ? 'off' : ST.error ? `<span style="color:var(--red)">${esc(ST.error)}</span>` : c ? `${ST.rate} msg/s from ${esc(ST.from)} · camera ${c.cam}: X ${(c.x / 1000).toFixed(2)} Y ${(c.y / 1000).toFixed(2)} Z ${(c.z / 1000).toFixed(2)} m · pan ${c.pan.toFixed(1)}° tilt ${c.tilt.toFixed(1)}°`
        : `listening on UDP ${ST.port || v.port} — no tracking data yet${Object.keys(ST.cams || {}).length ? ' for camera ' + v.cam + ' (seeing ' + Object.keys(ST.cams).join(', ') + ')' : ''}`; },
    after(pane) {
      pane.onclick = e => { const t = e.target.closest('[data-vpx]'); if (!t) return; const s = UI.st(), walls = JSON.parse(JSON.stringify(s.vp.walls)), W = s.comp.width, H = s.comp.height;
        const mk = (o) => Object.assign({ id: 'w' + Math.random().toString(36).slice(2, 7), name: 'Wall ' + (walls.length + 1), cx: 0, cy: 2.5, cz: 0, w: 8, h: 4.5, yaw: 0, pitch: 0, rx: 0, ry: 0, rw: W, rh: H }, o);
        if (t.dataset.vpx === 'psnFollow') { const li = +$('#psnLayer').value, id = $('#psnTr').value, x0 = +$('#psnX0').value, x1 = +$('#psnX1').value, ax = $('#psnVA').value, y0 = +$('#psnY0').value, y1 = +$('#psnY1').value;
          const ex = (s.exprs || []).filter(x => x.path !== `layers.${li}.transform.x` && x.path !== `layers.${li}.transform.y`);
          ex.push({ on: true, path: `layers.${li}.transform.x`, expr: `(track(${id}, "x") - (${x0})) / (${x1 - x0 || 1}) * 2 - 1`, min: -2, max: 2 }, { on: true, path: `layers.${li}.transform.y`, expr: `(track(${id}, "${ax}") - (${y0})) / (${y1 - y0 || 1}) * 2 - 1`, min: -2, max: 2 });
          UI.cmd({ op: 'set', path: 'exprs', value: ex }); UI.toast('The layer follows the tracker — see Mods ▸ Expressions', 'ok'); return; }
        if (t.dataset.vpx === 'lensAdd' || t.dataset.vpx === 'lensDel') { const lens = JSON.parse(JSON.stringify(s.vp.lens || [])); if (t.dataset.vpx === 'lensDel') lens.splice(+t.dataset.i, 1);
          else { const c = s.vp.sim ? s.vp.simPose : (ST.cams || {})[s.vp.cam | 0]; lens.push({ zoom: c ? Math.round(+c.zoom || 0) : 0, fov: +s.vp.fov || 50 }); } UI.cmd({ op: 'set', path: 'vp.lens', value: lens }); return; }
        if (t.dataset.vpx === 'add') walls.push(mk({}));
        if (t.dataset.vpx === 'del') walls.splice(+t.dataset.i, 1);
        if (t.dataset.vpx === 'volume') { if (walls.length && !confirm('Replace the walls with a 3-wall volume (left, back, right) side by side across the comp?')) return; walls.length = 0; const third = Math.floor(W / 3);
          walls.push(mk({ name: 'Left', cx: -4, cy: 2.25, cz: 3, w: 6, h: 4.5, yaw: 90, rx: 0, rw: third })); walls.push(mk({ name: 'Back', cx: 0, cy: 2.25, cz: 0, w: 8, h: 4.5, yaw: 0, rx: third, rw: third }));
          walls.push(mk({ name: 'Right', cx: 4, cy: 2.25, cz: 3, w: 6, h: 4.5, yaw: -90, rx: third * 2, rw: W - third * 2 })); }
        UI.cmd({ op: 'set', path: 'vp.walls', value: walls }); };
      pane.onchange = e => { const k = e.target.dataset.vpinv; if (k) UI.cmd({ op: 'set', path: 'vp.invert', value: Object.assign({}, UI.st().vp.invert, { [k]: e.target.checked }) }); };
      const poll = () => { UI.api('/api/vp').then(r => { ST = r; this.live(); }).catch(() => {}); UI.api('/api/psn').then(r => { const had = (PS.trackers || []).length; PS = r; const st = $('#psnStat'), li = $('#psnList'); if (!st) return;
          st.textContent = r.on ? (r.error ? r.error : `${r.trackers.length} · ${r.rate} packets/s${r.from ? ' from ' + r.from : ''}`) : 'off';
          li.innerHTML = r.trackers.slice(0, 20).map(t => `${t.id} ${esc(t.name || '')}: ${t.pos.map(v => v.toFixed(2)).join(', ')}`).join('<br>'); if (!had && r.trackers.length) UI.renderRight(true); }).catch(() => {}); }; poll(); clearInterval(this._t); this._t = setInterval(() => { if (UI.rtab === 'vp') poll(); else clearInterval(this._t); }, 500);
    },
  };
})();
