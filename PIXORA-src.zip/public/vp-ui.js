/* PIXORA — Virtual production: FreeD camera tracking, LED volume walls, a camera simulator for setting up without a tracker. */
(function () {
  const UI = window.UI, $ = UI.$, esc = UI.esc, I = UI.icon;
  const i = UI.MORETABS.findIndex(t => t[0] === 'audience'); UI.MORETABS.splice(i + 1, 0, ['vp', 'Virtual production', 'cam', 'VP']);
  const sec = (t, b) => `<div class="sec"><h4>${t}</h4>${b}</div>`; let ST = {};
  const num = (label, path, step, unit, w) => `<div class="row wide"><label>${esc(label)}</label><div class="ctl"><input type="number" data-path="${path}" step="${step || 0.01}" style="width:${w || 90}px"><span class="muted small">${unit || ''}</span></div></div>`;
  const trio = (label, base, keys, step, unit) => `<div class="row wide"><label>${esc(label)}</label><div class="ctl">${keys.map(k => `<span class="muted small">${k.toUpperCase()}</span><input type="number" data-path="${base}.${k}" step="${step}" style="width:72px">`).join(' ')}<span class="muted small">${unit}</span></div></div>`;
  UI.panels.vp = {
    sig: s => JSON.stringify([s.vp.on, s.vp.sim, s.vp.walls.map(w => w.id), (s.models || []).length]),
    render(s) {
      const v = s.vp, cams = Object.values(ST.cams || {});
      let h = sec('Virtual production', `${UI.rToggle('Camera tracking (FreeD)', 'vp.on')}${num('UDP port', 'vp.port', 1, '', 90)}${num('Camera id', 'vp.cam', 1, 'the tracked camera to follow', 70)}
        <div class="kv"><span>Tracking</span><b id="vpStat">—</b></div>
        <div class="hint">A 3D Scene clip set to <b>Camera: Tracked camera</b> renders each LED wall below from the tracked camera's position (off-axis projection), so the wall shows correct parallax through the lens. Put the clip on a layer that fills the comp; the walls' comp regions are where each wall's picture goes — map them to the LED processors with the LED screens / Advanced output as usual.</div>`);
      h += sec('Camera position', `${trio('Offset', 'vp.offset', ['x', 'y', 'z'], 0.01, 'm — where the tracking origin is on the stage')}
        <div class="row wide"><label>Flip axes</label><div class="ctl">${['x', 'y', 'z'].map(k => `<label class="small"><input type="checkbox" data-vpinv="${k}" ${v.invert[k] ? 'checked' : ''}> ${k.toUpperCase()}</label>`).join(' ')}</div></div>
        <div class="hint">Stage coordinates are metres with Y up and the walls facing +Z. FreeD X / Y are the floor and Z the height; flip an axis if the camera moves the wrong way.</div>
        ${UI.rToggle('Simulate the camera (no tracker)', 'vp.sim')}${v.sim ? trio('Sim position', 'vp.simPose', ['x', 'y', 'z'], 10, 'mm (FreeD units)') + `<div class="hint">Drag the numbers to walk the virtual camera around; the walls update live.</div>` : ''}`);
      h += sec('Scene placement', `${trio('Scene origin', 'vp.scene', ['x', 'y', 'z'], 0.01, 'm')}<div class="hint">In tracked mode the model isn't centred or auto-scaled: 1 model unit = 1 m, placed at this origin (the clip's Model scale and Model turn still apply).</div>`);
      h += sec('LED walls', (v.walls.length ? '' : '<div class="hint">Add one wall per flat LED surface — e.g. a back wall and two side walls of a volume, or a floor.</div>') + v.walls.map((w, j) => { const b = `vp.walls.${j}`;
        return `<div class="card"><header><b>${esc(w.name)}</b><span class="mono small">${(+w.w).toFixed(2)} × ${(+w.h).toFixed(2)} m</span><button class="btn xs danger" data-vpx="del" data-i="${j}">${I('trash')}</button></header><div class="body">
          <div class="row wide"><label>Name</label><div class="ctl"><input type="text" data-path="${b}.name"></div></div>
          ${trio('Centre', b, ['cx', 'cy', 'cz'], 0.01, 'm')}${trio('Size', b, ['w', 'h'], 0.01, 'm')}${trio('Facing', b, ['yaw', 'pitch'], 1, '° (yaw 90 = left side wall, pitch 90 = floor)')}
          ${trio('Comp region', b, ['rx', 'ry', 'rw', 'rh'], 1, 'px')}</div></div>`; }).join('') + `<button class="btn sm primary" data-vpx="add">${I('plus')}Add wall</button> <button class="btn sm" data-vpx="volume">Make a 3-wall volume</button>`);
      return h;
    },
    live() { const el = $('#vpStat'); if (!el) return; const v = UI.st().vp, c = (ST.cams || {})[v.cam | 0];
      el.innerHTML = !v.on ? 'off' : ST.error ? `<span style="color:var(--red)">${esc(ST.error)}</span>` : c ? `${ST.rate} msg/s from ${esc(ST.from)} · camera ${c.cam}: X ${(c.x / 1000).toFixed(2)} Y ${(c.y / 1000).toFixed(2)} Z ${(c.z / 1000).toFixed(2)} m · pan ${c.pan.toFixed(1)}° tilt ${c.tilt.toFixed(1)}°`
        : `listening on UDP ${ST.port || v.port} — no tracking data yet${Object.keys(ST.cams || {}).length ? ' for camera ' + v.cam + ' (seeing ' + Object.keys(ST.cams).join(', ') + ')' : ''}`; },
    after(pane) {
      pane.onclick = e => { const t = e.target.closest('[data-vpx]'); if (!t) return; const s = UI.st(), walls = JSON.parse(JSON.stringify(s.vp.walls)), W = s.comp.width, H = s.comp.height;
        const mk = (o) => Object.assign({ id: 'w' + Math.random().toString(36).slice(2, 7), name: 'Wall ' + (walls.length + 1), cx: 0, cy: 2.5, cz: 0, w: 8, h: 4.5, yaw: 0, pitch: 0, rx: 0, ry: 0, rw: W, rh: H }, o);
        if (t.dataset.vpx === 'add') walls.push(mk({}));
        if (t.dataset.vpx === 'del') walls.splice(+t.dataset.i, 1);
        if (t.dataset.vpx === 'volume') { if (walls.length && !confirm('Replace the walls with a 3-wall volume (left, back, right) side by side across the comp?')) return; walls.length = 0; const third = Math.floor(W / 3);
          walls.push(mk({ name: 'Left', cx: -4, cy: 2.25, cz: 3, w: 6, h: 4.5, yaw: 90, rx: 0, rw: third })); walls.push(mk({ name: 'Back', cx: 0, cy: 2.25, cz: 0, w: 8, h: 4.5, yaw: 0, rx: third, rw: third }));
          walls.push(mk({ name: 'Right', cx: 4, cy: 2.25, cz: 3, w: 6, h: 4.5, yaw: -90, rx: third * 2, rw: W - third * 2 })); }
        UI.cmd({ op: 'set', path: 'vp.walls', value: walls }); };
      pane.onchange = e => { const k = e.target.dataset.vpinv; if (k) UI.cmd({ op: 'set', path: 'vp.invert.' + k, value: e.target.checked }); };
      const poll = () => UI.api('/api/vp').then(r => { ST = r; this.live(); }).catch(() => {}); poll(); clearInterval(this._t); this._t = setInterval(() => { if (UI.rtab === 'vp') poll(); else clearInterval(this._t); }, 500);
    },
  };
})();
