/* PIXORA — 3D scenes: a small glTF 2.0 loader (.glb, or .gltf with embedded data) and WebGL renderer used by the
   "3D Scene" generator. Meshes (indexed or not), node hierarchy, PBR base colour / texture / emissive, alpha modes,
   node animations (translation / rotation / scale; linear, step, cubic-spline), the model's own cameras (animated too),
   an orbit camera with beat bounce, one key light + ambient. Skins and morph targets are drawn in their rest pose. */
(function (root) {
  'use strict';
  /* ---------- math (column-major 4x4) */
  const M = {
    id: () => { const m = new Float32Array(16); m[0] = m[5] = m[10] = m[15] = 1; return m; },
    mul(a, b) { const o = new Float32Array(16); for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) { let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k]; o[c * 4 + r] = s; } return o; },
    trs(t, q, s) { const [x, y, z, w] = q, [sx, sy, sz] = s, o = new Float32Array(16);
      o[0] = (1 - 2 * (y * y + z * z)) * sx; o[1] = 2 * (x * y + z * w) * sx; o[2] = 2 * (x * z - y * w) * sx;
      o[4] = 2 * (x * y - z * w) * sy; o[5] = (1 - 2 * (x * x + z * z)) * sy; o[6] = 2 * (y * z + x * w) * sy;
      o[8] = 2 * (x * z + y * w) * sz; o[9] = 2 * (y * z - x * w) * sz; o[10] = (1 - 2 * (x * x + y * y)) * sz;
      o[12] = t[0]; o[13] = t[1]; o[14] = t[2]; o[15] = 1; return o; },
    persp(fovy, asp, n, f) { const t = 1 / Math.tan(fovy / 2), o = new Float32Array(16); o[0] = t / asp; o[5] = t; o[10] = (f + n) / (n - f); o[11] = -1; o[14] = 2 * f * n / (n - f); return o; },
    look(e, c, up) { const z = norm([e[0] - c[0], e[1] - c[1], e[2] - c[2]]), x = norm(cross(up, z)), y = cross(z, x), o = M.id();
      o[0] = x[0]; o[4] = x[1]; o[8] = x[2]; o[1] = y[0]; o[5] = y[1]; o[9] = y[2]; o[2] = z[0]; o[6] = z[1]; o[10] = z[2];
      o[12] = -dot(x, e); o[13] = -dot(y, e); o[14] = -dot(z, e); return o; },
    inv(m) { const a = m, o = new Float32Array(16);
      const b00 = a[0] * a[5] - a[1] * a[4], b01 = a[0] * a[6] - a[2] * a[4], b02 = a[0] * a[7] - a[3] * a[4], b03 = a[1] * a[6] - a[2] * a[5], b04 = a[1] * a[7] - a[3] * a[5], b05 = a[2] * a[7] - a[3] * a[6];
      const b06 = a[8] * a[13] - a[9] * a[12], b07 = a[8] * a[14] - a[10] * a[12], b08 = a[8] * a[15] - a[11] * a[12], b09 = a[9] * a[14] - a[10] * a[13], b10 = a[9] * a[15] - a[11] * a[13], b11 = a[10] * a[15] - a[11] * a[14];
      let d = b00 * b11 - b01 * b10 + b02 * b09 + b03 * b08 - b04 * b07 + b05 * b06; if (!d) return M.id(); d = 1 / d;
      o[0] = (a[5] * b11 - a[6] * b10 + a[7] * b09) * d; o[1] = (a[2] * b10 - a[1] * b11 - a[3] * b09) * d; o[2] = (a[13] * b05 - a[14] * b04 + a[15] * b03) * d; o[3] = (a[10] * b04 - a[9] * b05 - a[11] * b03) * d;
      o[4] = (a[6] * b08 - a[4] * b11 - a[7] * b07) * d; o[5] = (a[0] * b11 - a[2] * b08 + a[3] * b07) * d; o[6] = (a[14] * b02 - a[12] * b05 - a[15] * b01) * d; o[7] = (a[8] * b05 - a[10] * b02 + a[11] * b01) * d;
      o[8] = (a[4] * b10 - a[5] * b08 + a[7] * b06) * d; o[9] = (a[1] * b08 - a[0] * b10 - a[3] * b06) * d; o[10] = (a[12] * b04 - a[13] * b02 + a[15] * b00) * d; o[11] = (a[9] * b02 - a[8] * b04 - a[11] * b00) * d;
      o[12] = (a[5] * b07 - a[4] * b09 - a[6] * b06) * d; o[13] = (a[0] * b09 - a[1] * b07 + a[2] * b06) * d; o[14] = (a[13] * b01 - a[12] * b03 - a[14] * b00) * d; o[15] = (a[8] * b03 - a[9] * b01 + a[10] * b00) * d; return o; },
    nrm(m) { const i = M.inv(m); return new Float32Array([i[0], i[4], i[8], i[1], i[5], i[9], i[2], i[6], i[10]]); }, // inverse-transpose 3x3
    xf: (m, p) => [m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12], m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13], m[2] * p[0] + m[6] * p[1] + m[10] * p[2] + m[14]],
  };
  function norm(v) { const l = Math.hypot(v[0], v[1], v[2]) || 1; return [v[0] / l, v[1] / l, v[2] / l]; }
  function cross(a, b) { return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]; }
  function dot(a, b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
  function slerp(a, b, t) { let d = a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3]; const s = d < 0 ? -1 : 1; d *= s;
    if (d > 0.9995) { const o = a.map((x, i) => x + (b[i] * s - x) * t); const l = Math.hypot(...o) || 1; return o.map(x => x / l); }
    const th = Math.acos(d), sa = Math.sin((1 - t) * th) / Math.sin(th), sb = Math.sin(t * th) / Math.sin(th) * s; return a.map((x, i) => x * sa + b[i] * sb); }

  /* ---------- glTF parsing */
  const COMP = { 5120: Int8Array, 5121: Uint8Array, 5122: Int16Array, 5123: Uint16Array, 5125: Uint32Array, 5126: Float32Array }, NUM = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4, MAT4: 16 };
  function parse(buf) {
    const u8 = new Uint8Array(buf); let json, bin = null;
    if (u8[0] === 0x67 && u8[1] === 0x6c && u8[2] === 0x54 && u8[3] === 0x46) { // binary .glb
      const dv = new DataView(buf); let off = 12;
      while (off + 8 <= buf.byteLength) { const len = dv.getUint32(off, true), type = dv.getUint32(off + 4, true), data = new Uint8Array(buf, off + 8, len);
        if (type === 0x4E4F534A) json = JSON.parse(new TextDecoder().decode(data)); else if (type === 0x004E4942) bin = data; off += 8 + len; }
    } else json = JSON.parse(new TextDecoder().decode(u8));
    if (!json || !json.asset) throw new Error('not a glTF file');
    const buffers = (json.buffers || []).map((b, i) => { if (b.uri == null) return bin; const m = /^data:[^;]*;base64,(.*)$/.exec(b.uri); if (!m) throw new Error('external .bin files aren’t supported — export as .glb (binary glTF)');
      const s = atob(m[1]), a = new Uint8Array(s.length); for (let k = 0; k < s.length; k++) a[k] = s.charCodeAt(k); return a; });
    const view = i => { const v = json.bufferViews[i], b = buffers[v.buffer]; return { bytes: new Uint8Array(b.buffer, b.byteOffset + (v.byteOffset || 0), v.byteLength), stride: v.byteStride || 0 }; };
    const acc = i => { const a = json.accessors[i], T = COMP[a.componentType], n = NUM[a.type], out = new T(a.count * n); if (a.bufferView == null) return { data: out, n, a };
      const v = view(a.bufferView), es = T.BYTES_PER_ELEMENT, stride = v.stride || es * n, base = v.bytes.byteOffset + (a.byteOffset || 0);
      if (stride === es * n && base % es === 0) out.set(new T(v.bytes.buffer, base, a.count * n));
      else { const dv = new DataView(v.bytes.buffer); const get = { 5120: 'getInt8', 5121: 'getUint8', 5122: 'getInt16', 5123: 'getUint16', 5125: 'getUint32', 5126: 'getFloat32' }[a.componentType];
        for (let e = 0; e < a.count; e++) for (let c = 0; c < n; c++) out[e * n + c] = dv[get](base + e * stride + c * es, true); }
      if (a.normalized && T !== Float32Array) { const f = new Float32Array(out.length), mx = { 5120: 127, 5121: 255, 5122: 32767, 5123: 65535 }[a.componentType]; for (let k = 0; k < out.length; k++) f[k] = Math.max(-1, out[k] / mx); return { data: f, n, a }; }
      return { data: out, n, a }; };
    const meshes = (json.meshes || []).map(m => m.primitives.filter(p => (p.mode ?? 4) === 4 && p.attributes.POSITION != null).map(p => {
      const pos = acc(p.attributes.POSITION).data; let nrm = p.attributes.NORMAL != null ? acc(p.attributes.NORMAL).data : null;
      const uv = p.attributes.TEXCOORD_0 != null ? Float32Array.from(acc(p.attributes.TEXCOORD_0).data) : null, idx = p.indices != null ? acc(p.indices).data : null;
      if (!nrm) { nrm = new Float32Array(pos.length); const cnt = idx ? idx.length : pos.length / 3; // smooth normals from the triangles
        for (let t = 0; t + 2 < cnt; t += 3) { const [a, b, c] = idx ? [idx[t], idx[t + 1], idx[t + 2]] : [t, t + 1, t + 2]; const P = k => [pos[k * 3], pos[k * 3 + 1], pos[k * 3 + 2]];
          const pa = P(a), pb = P(b), pc = P(c), f = cross([pb[0] - pa[0], pb[1] - pa[1], pb[2] - pa[2]], [pc[0] - pa[0], pc[1] - pa[1], pc[2] - pa[2]]);
          for (const k of [a, b, c]) { nrm[k * 3] += f[0]; nrm[k * 3 + 1] += f[1]; nrm[k * 3 + 2] += f[2]; } }
        for (let k = 0; k < nrm.length; k += 3) { const v = norm([nrm[k], nrm[k + 1], nrm[k + 2]]); nrm[k] = v[0]; nrm[k + 1] = v[1]; nrm[k + 2] = v[2]; } }
      return { pos: Float32Array.from(pos), nrm: Float32Array.from(nrm), uv, idx, mat: p.material, count: idx ? idx.length : pos.length / 3 }; }));
    const images = (json.images || []).map(im => { if (im.bufferView != null) return new Blob([view(im.bufferView).bytes.slice()], { type: im.mimeType || 'image/png' });
      const m = /^data:([^;]*);base64,(.*)$/.exec(im.uri || ''); if (!m) return null; const s = atob(m[2]), a = new Uint8Array(s.length); for (let k = 0; k < s.length; k++) a[k] = s.charCodeAt(k); return new Blob([a], { type: m[1] }); });
    const materials = (json.materials || []).map(m => { const pb = m.pbrMetallicRoughness || {}, tex = pb.baseColorTexture && json.textures && json.textures[pb.baseColorTexture.index];
      return { base: pb.baseColorFactor || [1, 1, 1, 1], metal: pb.metallicFactor ?? 1, rough: pb.roughnessFactor ?? 1, emis: m.emissiveFactor || [0, 0, 0], image: tex ? tex.source : null,
        alpha: m.alphaMode || 'OPAQUE', cutoff: m.alphaCutoff ?? 0.5, double: !!m.doubleSided, unlit: !!(m.extensions && m.extensions.KHR_materials_unlit) }; });
    const nodes = (json.nodes || []).map(n => ({ mesh: n.mesh, camera: n.camera, children: n.children || [], matrix: n.matrix ? Float32Array.from(n.matrix) : null,
      t: n.translation || [0, 0, 0], r: n.rotation || [0, 0, 0, 1], s: n.scale || [1, 1, 1] }));
    const animations = (json.animations || []).map(an => ({ name: an.name || '', channels: an.channels.filter(c => c.target && c.target.node != null && ['translation', 'rotation', 'scale'].includes(c.target.path)).map(c => {
      const s = an.samplers[c.sampler]; return { node: c.target.node, path: c.target.path, input: Float32Array.from(acc(s.input).data), output: Float32Array.from(acc(s.output).data), interp: s.interpolation || 'LINEAR' }; }) }));
    let duration = 0; for (const a of animations) for (const c of a.channels) duration = Math.max(duration, c.input[c.input.length - 1] || 0);
    const scene = json.scenes && json.scenes[json.scene || 0], roots = scene ? scene.nodes : nodes.map((_, i) => i).filter(i => !nodes.some(n => n.children.includes(i)));
    return { meshes, materials, images, nodes, roots, animations, duration, cameras: json.cameras || [] };
  }
  function sample(c, t) { const inp = c.input, n = c.path === 'rotation' ? 4 : 3, cub = c.interp === 'CUBICSPLINE', at = k => { const o = cub ? (k * 3 + 1) * n : k * n; return Array.from(c.output.subarray(o, o + n)); };
    if (t <= inp[0]) return at(0); const last = inp.length - 1; if (t >= inp[last]) return at(last);
    let k = 0; while (k < last && inp[k + 1] < t) k++; const f = (t - inp[k]) / (inp[k + 1] - inp[k] || 1); if (c.interp === 'STEP') return at(k);
    const a = at(k), b = at(k + 1); return n === 4 ? slerp(a, b, f) : a.map((x, i) => x + (b[i] - x) * f); }
  function pose(S, t) { // node world matrices at time t
    const local = S.nodes.map(n => ({ t: n.t.slice(), r: n.r.slice(), s: n.s.slice(), m: n.matrix }));
    if (S.animations.length && S.duration > 0) { const tt = t % S.duration; for (const c of S.animations[0].channels) { const v = sample(c, tt), L = local[c.node]; if (!L) continue; L.m = null; if (c.path === 'translation') L.t = v; else if (c.path === 'rotation') L.r = v; else L.s = v; } }
    const world = new Array(S.nodes.length); const walk = (i, parent) => { const L = local[i]; const m = M.mul(parent, L.m || M.trs(L.t, L.r, L.s)); world[i] = m; for (const ch of S.nodes[i].children) walk(ch, m); };
    for (const r of S.roots) walk(r, M.id()); return world;
  }
  function bounds(S) { const w = pose(S, 0); let lo = [Infinity, Infinity, Infinity], hi = [-Infinity, -Infinity, -Infinity];
    S.nodes.forEach((n, i) => { if (n.mesh == null || !w[i]) return; for (const p of S.meshes[n.mesh]) for (let k = 0; k < p.pos.length; k += 3) { const v = M.xf(w[i], [p.pos[k], p.pos[k + 1], p.pos[k + 2]]); for (let a = 0; a < 3; a++) { lo[a] = Math.min(lo[a], v[a]); hi[a] = Math.max(hi[a], v[a]); } } });
    if (!isFinite(lo[0])) { lo = [-1, -1, -1]; hi = [1, 1, 1]; } return { c: lo.map((x, a) => (x + hi[a]) / 2), r: Math.max(1e-3, Math.hypot(hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2]) / 2) }; }

  /* ---------- WebGL */
  const VS = `attribute vec3 a_p; attribute vec3 a_n; attribute vec2 a_t; uniform mat4 u_mvp; uniform mat4 u_model; uniform mat3 u_nm;
    varying vec3 v_n; varying vec3 v_w; varying vec2 v_t; void main(){ v_n = u_nm * a_n; v_w = (u_model * vec4(a_p, 1.0)).xyz; v_t = a_t; gl_Position = u_mvp * vec4(a_p, 1.0); }`;
  const FS = `precision highp float; varying vec3 v_n; varying vec3 v_w; varying vec2 v_t; uniform vec4 u_base; uniform sampler2D u_tex; uniform float u_hasTex;
    uniform vec3 u_emis; uniform float u_metal; uniform float u_rough; uniform vec3 u_ldir; uniform vec3 u_lcol; uniform vec3 u_amb; uniform vec3 u_eye; uniform float u_cut; uniform float u_unlit;
    void main(){ vec4 c = u_base; if (u_hasTex > 0.5) { vec4 t = texture2D(u_tex, v_t); c *= vec4(pow(t.rgb, vec3(2.2)), t.a); }
      if (c.a < u_cut) discard; vec3 n = normalize(v_n); if (!gl_FrontFacing) n = -n; vec3 col;
      if (u_unlit > 0.5) col = c.rgb; else { vec3 l = normalize(-u_ldir), v = normalize(u_eye - v_w), h = normalize(l + v); float d = max(dot(n, l), 0.0);
        float sh = mix(8.0, 128.0, 1.0 - u_rough); float sp = pow(max(dot(n, h), 0.0), sh) * (1.0 - u_rough * 0.85);
        vec3 diff = c.rgb * (1.0 - u_metal * 0.8), spec = mix(vec3(0.04), c.rgb, u_metal);
        col = diff * (u_amb + u_lcol * d) + spec * u_lcol * sp + c.rgb * u_metal * u_amb * 0.5; }
      col += u_emis; gl_FragColor = vec4(pow(clamp(col, 0.0, 1.0), vec3(1.0 / 2.2)) * c.a, c.a); }`; // premultiplied out
  const hex = (h, d) => { const m = /^#?([0-9a-f]{6})$/i.exec(h || ''); if (!m) return d; const n = parseInt(m[1], 16); return [(n >> 16 & 255) / 255, (n >> 8 & 255) / 255, (n & 255) / 255]; };

  function Scene3D(gl, isGL2) { this.gl = gl; this.isGL2 = isGL2; this.models = new Map(); this.fbos = new Map(); this.prog = null; this.u32 = isGL2 || !!gl.getExtension('OES_element_index_uint'); }
  Scene3D.prototype.program = function () { if (this.prog) return this.prog; const gl = this.gl, p = gl.createProgram();
    for (const [t, s] of [[gl.VERTEX_SHADER, VS], [gl.FRAGMENT_SHADER, FS]]) { const sh = gl.createShader(t); gl.shaderSource(sh, s); gl.compileShader(sh); if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(sh)); gl.attachShader(p, sh); }
    gl.bindAttribLocation(p, 0, 'a_p'); gl.bindAttribLocation(p, 1, 'a_n'); gl.bindAttribLocation(p, 2, 'a_t'); gl.linkProgram(p); if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
    p.u = {}; for (const n of ['u_mvp', 'u_model', 'u_nm', 'u_base', 'u_tex', 'u_hasTex', 'u_emis', 'u_metal', 'u_rough', 'u_ldir', 'u_lcol', 'u_amb', 'u_eye', 'u_cut', 'u_unlit']) p.u[n] = gl.getUniformLocation(p, n); return (this.prog = p); };
  Scene3D.prototype.model = function (url) { // → { state: 'loading' | 'ready' | 'error', ... }
    let e = this.models.get(url); if (e) return e; e = { state: 'loading' }; this.models.set(url, e); const gl = this.gl;
    fetch(url).then(r => { if (!r.ok) throw new Error('model ' + r.status); return r.arrayBuffer(); }).then(async buf => {
      const S = parse(buf); const B = bounds(S);
      const textures = await Promise.all(S.images.map(async b => { if (!b) return null; try { const bmp = await createImageBitmap(b); const t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t);
        gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, bmp); gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
        const pot = (bmp.width & (bmp.width - 1)) === 0 && (bmp.height & (bmp.height - 1)) === 0;
        if (pot || this.isGL2) { gl.generateMipmap(gl.TEXTURE_2D); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT); }
        else { gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE); }
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR); return t; } catch { return null; } }));
      const bufs = S.meshes.map(prims => prims.map(p => { const mk = (data, target) => { const b = gl.createBuffer(); gl.bindBuffer(target || gl.ARRAY_BUFFER, b); gl.bufferData(target || gl.ARRAY_BUFFER, data, gl.STATIC_DRAW); return b; };
        let idx = p.idx, type = 0; if (idx) { if (idx instanceof Uint32Array && !this.u32) { idx = null; } else { type = idx instanceof Uint8Array ? gl.UNSIGNED_BYTE : idx instanceof Uint16Array ? gl.UNSIGNED_SHORT : gl.UNSIGNED_INT; } }
        return { pos: mk(p.pos), nrm: mk(p.nrm), uv: p.uv ? mk(p.uv) : null, idx: idx ? mk(idx, gl.ELEMENT_ARRAY_BUFFER) : null, type, count: idx ? idx.length : p.pos.length / 3, mat: p.mat }; }));
      Object.assign(e, { state: 'ready', S, B, textures, bufs, tris: S.meshes.reduce((a, m) => a + m.reduce((b, p) => b + p.count / 3, 0), 0) });
    }).catch(err => { e.state = 'error'; e.error = String(err.message || err); });
    return e; };
  Scene3D.prototype.target = function (key, W, H) { const gl = this.gl; let f = this.fbos.get(key); if (f && f.w === W && f.h === H) return f;
    if (f) { gl.deleteFramebuffer(f.f); gl.deleteTexture(f.t); gl.deleteRenderbuffer(f.d); }
    const t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, W, H, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    for (const [k, v] of [[gl.TEXTURE_MIN_FILTER, gl.LINEAR], [gl.TEXTURE_MAG_FILTER, gl.LINEAR], [gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE], [gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE]]) gl.texParameteri(gl.TEXTURE_2D, k, v);
    const d = gl.createRenderbuffer(); gl.bindRenderbuffer(gl.RENDERBUFFER, d); gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, W, H);
    const fb = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, fb); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t, 0); gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, d);
    f = { f: fb, t, d, w: W, h: H }; this.fbos.set(key, f); return f; };
  // p: generator params; returns { t, w, h } or null while loading
  Scene3D.prototype.render = function (key, url, p, W, H, time, beat, vx) { // vx: { vp, pose, compW, compH } for the tracked camera
    const e = this.model(url); if (e.state !== 'ready') return { state: e.state, error: e.error };
    const gl = this.gl, S = e.S, B = e.B, f = this.target(key, W, H), prg = this.program(), u = prg.u;
    const prevFb = gl.getParameter(gl.FRAMEBUFFER_BINDING), prevVp = gl.getParameter(gl.VIEWPORT), sc = gl.isEnabled(gl.SCISSOR_TEST), bl = gl.isEnabled(gl.BLEND), prevProg = gl.getParameter(gl.CURRENT_PROGRAM), prevAB = gl.getParameter(gl.ARRAY_BUFFER_BINDING);
    gl.bindFramebuffer(gl.FRAMEBUFFER, f.f); gl.viewport(0, 0, W, H); gl.disable(gl.SCISSOR_TEST);
    const bg = p.bgOn ? hex(p.bg, [0, 0, 0]) : null; gl.clearColor(bg ? bg[0] : 0, bg ? bg[1] : 0, bg ? bg[2] : 0, bg ? 1 : 0); gl.clearDepth(1); gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL); gl.depthMask(true);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    const at = time * (p.animSpeed ?? 1), world = pose(S, at);
    const bounce = 1 + (+p.bounce || 0) * Math.pow(Math.max(0, 1 - ((beat || 0) % 1) * 3), 2) * 0.15; // a kick on each beat
    const fit = M.trs([0, 0, 0], quatY((+p.rotate || 0) * Math.PI / 180), [1, 1, 1]), center = M.trs([-B.c[0], -B.c[1], -B.c[2]], [0, 0, 0, 1], [1, 1, 1]);
    const sMul = (+p.scale || 1) * bounce, scl = M.trs([0, 0, 0], [0, 0, 0, 1], [sMul, sMul, sMul]), modelBase = M.mul(fit, M.mul(scl, center));
    let view, proj, eye; const cams = S.nodes.map((n, i) => n.camera != null ? i : -1).filter(i => i >= 0), views = [];
    const tracked = (p.camMode | 0) === 2;
    if (tracked) { // virtual production: the scene sits in stage space (metres); each LED wall gets its own off-axis view from the tracked camera
      const vp = (vx && vx.vp) || {}, pe = eyeFrom(vp, vx && vx.pose) || [0, 1.6, 6]; eye = pe; const sx = W / ((vx && vx.compW) || W), sy = H / ((vx && vx.compH) || H);
      const so = vp.scene || {}; const placed = M.mul(M.trs([+so.x || 0, +so.y || 0, +so.z || 0], quatY((+p.rotate || 0) * Math.PI / 180), [1, 1, 1]), M.trs([0, 0, 0], [0, 0, 0, 1], [sMul, sMul, sMul]));
      modelBase.set(placed);
      for (const w of vp.walls || []) { const c = wallCorners(w), o2 = offAxis(c.pa, c.pb, c.pc, pe, 0.05, 500); if (!o2) continue;
        const rx = Math.round((+w.rx || 0) * sx), ry = Math.round((+w.ry || 0) * sy), rw = Math.round((+w.rw || 0) * sx), rh = Math.round((+w.rh || 0) * sy); if (rw < 1 || rh < 1) continue;
        views.push({ view: o2.view, proj: o2.proj, eye: pe, vpRect: [rx, H - ry - rh, rw, rh] }); } // comp y runs down, GL y up
    } else if ((p.camMode | 0) === 1 && cams.length) { // the model's own (possibly animated) camera
      const ci = cams[Math.min(cams.length - 1, Math.max(0, (p.camIndex | 0)))], cw = M.mul(modelBase, world[ci]); view = M.inv(cw); eye = [cw[12], cw[13], cw[14]];
      const cam = S.cameras[S.nodes[ci].camera] || {}, pc = cam.perspective || {}; proj = M.persp(pc.yfov || 0.8, W / H, Math.max(1e-3, (pc.znear || 0.05)), pc.zfar || B.r * 200);
    } else { const ang = ((+p.orbit || 0) + time * (+p.spin || 0)) * Math.PI / 180, el = (+p.elev || 0) * Math.PI / 180, d = B.r * (+p.dist || 2.4) / Math.tan(((+p.fov || 40) * Math.PI / 180) / 2) * 0.45;
      eye = [Math.sin(ang) * Math.cos(el) * d, Math.sin(el) * d, Math.cos(ang) * Math.cos(el) * d]; view = M.look(eye, [0, 0, 0], [0, 1, 0]); proj = M.persp((+p.fov || 40) * Math.PI / 180, W / H, Math.max(1e-3, d / 100), d * 20 + B.r * 4); }
    if (!tracked) views.push({ view, proj, eye, vpRect: [0, 0, W, H] });
    gl.useProgram(prg);
    const lAz = (p.lightAz == null ? -45 : +p.lightAz) * Math.PI / 180, lEl = (p.lightEl == null ? 50 : +p.lightEl) * Math.PI / 180, li = +p.light >= 0 ? +p.light : 1, lc = hex(p.lightColor, [1, 1, 1]), am = (+p.ambient >= 0 ? +p.ambient : 0.25);
    gl.uniform3f(u.u_ldir, -Math.sin(lAz) * Math.cos(lEl), -Math.sin(lEl), -Math.cos(lAz) * Math.cos(lEl)); gl.uniform3f(u.u_lcol, lc[0] * li, lc[1] * li, lc[2] * li); gl.uniform3f(u.u_amb, am, am, am);
    gl.activeTexture(gl.TEXTURE0); gl.uniform1i(u.u_tex, 0);
    const tint = hex(p.tint, null), draws = [];
    S.nodes.forEach((n, i) => { if (n.mesh == null || !world[i]) return; const m = M.mul(modelBase, world[i]); e.bufs[n.mesh].forEach(b => draws.push({ b, m, mat: S.materials[b.mat] || { base: [0.8, 0.8, 0.8, 1], metal: 0, rough: 0.6, emis: [0, 0, 0], image: null, alpha: 'OPAQUE', double: true } })); });
    draws.sort((a, b) => (a.mat.alpha === 'BLEND') - (b.mat.alpha === 'BLEND')); // opaque first
    gl.enable(gl.SCISSOR_TEST);
    for (const V of views) { const vp = M.mul(V.proj, V.view); gl.viewport(V.vpRect[0], V.vpRect[1], V.vpRect[2], V.vpRect[3]); gl.scissor(V.vpRect[0], V.vpRect[1], V.vpRect[2], V.vpRect[3]); gl.uniform3f(u.u_eye, V.eye[0], V.eye[1], V.eye[2]);
    for (const { b, m, mat } of draws) {
      gl.uniformMatrix4fv(u.u_mvp, false, M.mul(vp, m)); gl.uniformMatrix4fv(u.u_model, false, m); gl.uniformMatrix3fv(u.u_nm, false, M.nrm(m));
      const base = tint ? [mat.base[0] * tint[0], mat.base[1] * tint[1], mat.base[2] * tint[2], mat.base[3]] : mat.base; gl.uniform4f(u.u_base, base[0], base[1], base[2], base[3]);
      gl.uniform3f(u.u_emis, mat.emis[0], mat.emis[1], mat.emis[2]); gl.uniform1f(u.u_metal, mat.metal); gl.uniform1f(u.u_rough, mat.rough); gl.uniform1f(u.u_unlit, mat.unlit ? 1 : 0);
      gl.uniform1f(u.u_cut, mat.alpha === 'MASK' ? mat.cutoff : -1); const tx = mat.image != null ? e.textures[mat.image] : null; gl.bindTexture(gl.TEXTURE_2D, tx); gl.uniform1f(u.u_hasTex, tx ? 1 : 0);
      if (mat.double) gl.disable(gl.CULL_FACE); else { gl.enable(gl.CULL_FACE); gl.cullFace(gl.BACK); }
      if (mat.alpha === 'BLEND') { gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false); } else { gl.disable(gl.BLEND); gl.depthMask(true); }
      gl.bindBuffer(gl.ARRAY_BUFFER, b.pos); gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 0, 0);
      gl.bindBuffer(gl.ARRAY_BUFFER, b.nrm); gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 3, gl.FLOAT, false, 0, 0);
      if (b.uv) { gl.bindBuffer(gl.ARRAY_BUFFER, b.uv); gl.enableVertexAttribArray(2); gl.vertexAttribPointer(2, 2, gl.FLOAT, false, 0, 0); } else { gl.disableVertexAttribArray(2); gl.vertexAttrib2f(2, 0, 0); }
      if (b.idx) { gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, b.idx); gl.drawElements(gl.TRIANGLES, b.count, b.type, 0); } else gl.drawArrays(gl.TRIANGLES, 0, b.count);
    } }
    gl.disable(gl.SCISSOR_TEST);
    gl.disableVertexAttribArray(1); gl.disableVertexAttribArray(2); gl.disable(gl.DEPTH_TEST); gl.disable(gl.CULL_FACE); gl.depthMask(true);
    if (bl) gl.enable(gl.BLEND); else gl.disable(gl.BLEND); if (sc) gl.enable(gl.SCISSOR_TEST);
    gl.bindFramebuffer(gl.FRAMEBUFFER, prevFb); gl.viewport(prevVp[0], prevVp[1], prevVp[2], prevVp[3]); gl.useProgram(prevProg); gl.bindBuffer(gl.ARRAY_BUFFER, prevAB);
    return { t: f.t, w: W, h: H, state: 'ready', tris: e.tris, cams: cams.length, anim: S.duration, eye, walls: views.length };
  };
  // virtual production: a wall's corners (metres, Y up). yaw 0 = the wall faces +Z (the camera stands at +Z looking at it)
  function wallCorners(w) { const y = (+w.yaw || 0) * Math.PI / 180, pt = (+w.pitch || 0) * Math.PI / 180, r = [Math.cos(y), 0, -Math.sin(y)], n0 = [Math.sin(y), 0, Math.cos(y)];
    const u = [-n0[0] * Math.sin(pt), Math.cos(pt), -n0[2] * Math.sin(pt)], c = [+w.cx || 0, +w.cy || 0, +w.cz || 0], hw = (+w.w || 1) / 2, hh = (+w.h || 1) / 2;
    const at = (a, b) => [c[0] + r[0] * a + u[0] * b, c[1] + r[1] * a + u[1] * b, c[2] + r[2] * a + u[2] * b]; return { pa: at(-hw, -hh), pb: at(hw, -hh), pc: at(-hw, hh) }; }
  // generalised perspective projection (Kooima): the wall is the image plane, seen from the tracked eye
  function offAxis(pa, pb, pc, pe, n, f) { const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
    const vr = norm(sub(pb, pa)), vu = norm(sub(pc, pa)), vn = norm(cross(vr, vu)), va = sub(pa, pe), vb = sub(pb, pe), vc = sub(pc, pe), d = -dot(va, vn);
    if (d <= 1e-4) return null; // eye behind the wall
    const l = dot(vr, va) * n / d, r = dot(vr, vb) * n / d, b = dot(vu, va) * n / d, t = dot(vu, vc) * n / d;
    const P = new Float32Array(16); P[0] = 2 * n / (r - l); P[5] = 2 * n / (t - b); P[8] = (r + l) / (r - l); P[9] = (t + b) / (t - b); P[10] = -(f + n) / (f - n); P[11] = -1; P[14] = -2 * f * n / (f - n);
    const R = M.id(); R[0] = vr[0]; R[4] = vr[1]; R[8] = vr[2]; R[1] = vu[0]; R[5] = vu[1]; R[9] = vu[2]; R[2] = vn[0]; R[6] = vn[1]; R[10] = vn[2];
    const T = M.id(); T[12] = -pe[0]; T[13] = -pe[1]; T[14] = -pe[2]; return { proj: P, view: M.mul(R, T), frustum: { l, r, b, t } }; }
  // FreeD pose → eye position in metres (stage coordinates, Y up): FreeD X / Y are the floor, Z is height
  function eyeFrom(vp, pose) { if (!pose) return null; const s = 1 / 1000, inv = vp.invert || {}, o = vp.offset || {};
    return [(inv.x ? -1 : 1) * pose.x * s + (+o.x || 0), (inv.z ? -1 : 1) * pose.z * s + (+o.y || 0), (inv.y ? 1 : -1) * pose.y * s + (+o.z || 0)]; }
  function quatY(a) { return [0, Math.sin(a / 2), 0, Math.cos(a / 2)]; }
  Scene3D.parse = parse; Scene3D.offAxis = offAxis; Scene3D.wallCorners = wallCorners; Scene3D.eyeFrom = eyeFrom; Scene3D.pose = pose; Scene3D.M = M;
  if (typeof module !== 'undefined' && module.exports) module.exports = Scene3D; else root.PixoraScene3D = Scene3D;
})(typeof window !== 'undefined' ? window : this);
