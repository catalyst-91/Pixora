/* Interface language picker (status bar ▸ globe): choose the language for this screen, import a pack for another language,
 * or export the strings still in English so a translator can fill them in. */
(function () {
  const UI = window.UI, I18N = window.PX_I18N; if (!UI || !I18N) return; const $ = UI.$, esc = UI.esc;
  const bar = document.getElementById('status'); if (!bar) return;
  const btn = UI.el(`<button class="btn xs" id="stLang" title="Interface language" data-noi18n style="margin-left:6px">🌐 <span></span></button>`);
  const label = () => { btn.querySelector('span').textContent = (I18N.lang() || 'en').toUpperCase(); };
  bar.appendChild(btn); label(); window.addEventListener('px-lang', label); if (I18N.ready) I18N.ready.then(label);
  btn.onclick = () => {
    const L = I18N.languages(), cur = I18N.lang();
    const m = UI.modal('Interface language', `<div class="row wide"><label>Interface language</label><div class="ctl"><select id="lgSel" data-noi18n>${Object.entries(L).map(([k, n]) => `<option value="${k}" ${k === cur ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select></div></div>
      <div class="hint">Changes this screen only — every operator can pick their own. Clip, layer and cue names you type are never translated.</div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px"><button class="btn sm" id="lgExp">Export untranslated strings</button><button class="btn sm" id="lgImp">Import language pack</button>${Object.keys(L).some(k => !['en', 'es', 'fr', 'de', 'pt', 'ja'].includes(k)) ? '<button class="btn sm danger" id="lgDel">Remove custom pack</button>' : ''}</div>
      <div class="hint">To translate into another language (or improve one): choose it, use PIXORA for a while so the screens you use are seen, then export the untranslated strings — a JSON file of English text with empty values. Fill it in and import it with the language code (e.g. <span class="mono">it</span>, <span class="mono">zh</span>, <span class="mono">pt-BR</span>).</div>`,
      [{ label: 'Close' }]);
    $('#lgSel', m).onchange = async e => { await I18N.set(e.target.value); UI.toast && UI.toast(I18N.t('Interface language') + ': ' + I18N.languages()[e.target.value], 'ok'); };
    $('#lgExp', m).onclick = () => { const blob = new Blob([I18N.exportMissing()], { type: 'application/json' }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `pixora-${I18N.lang()}-untranslated.json`; a.click(); };
    $('#lgImp', m).onclick = () => { const i = document.createElement('input'); i.type = 'file'; i.accept = '.json'; i.onchange = async () => {
      try { const obj = JSON.parse(await i.files[0].text()); const code = prompt('Language code (e.g. it, zh, pt-BR):', (i.files[0].name.match(/pixora-([a-z]{2}(?:-[A-Za-z]{2,4})?)/) || [])[1] || I18N.lang()); if (!code) return;
        const name = I18N.languages()[code] || prompt('Language name as it should appear in the list:', code) || code; const n = I18N.importPack(code, name, obj); await I18N.set(code); m.close(); UI.toast(`${n} strings imported for ${name}`, 'ok'); }
      catch (e) { UI.toast('Language pack: ' + e.message, 'err'); } }; i.click(); };
    const del = $('#lgDel', m); if (del) del.onclick = async () => { const code = I18N.lang(); if (['en', 'es', 'fr', 'de', 'pt', 'ja'].includes(code)) return UI.toast('Choose the custom language first', 'err'); I18N.removePack(code); await I18N.set('en'); m.close(); };
  };
})();
