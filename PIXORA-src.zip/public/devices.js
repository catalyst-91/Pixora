/* PIXORA — Devices & Cameras panel: Blackmagic Videohub / HyperDeck / Streaming Encoder / cameras / ATEM, BirdDog,
 * Panasonic AW + Auto Tracking, VISCA over IP and NDI® PTZ. Live state arrives as {t:'devices'} messages. */
(function () {
  const UI = window.UI, $ = UI.$, $$ = UI.$$, esc = UI.esc, I = UI.icon;
  const sec = (title, body, extra) => `<div class="sec"><h4>${title}${extra || ''}</h4>${body}</div>`;
  UI.devices = []; UI.devTypes = null;
  UI.MORETABS.push(['devices', 'Devices & Cameras', 'cam', 'Devices']);
  (BVJ.extraHandlers = BVJ.extraHandlers || {}).devices = m => { UI.devices = m.devices || []; if (UI.rtab === 'devices') UI.renderRight(); if (UI.onDevices) UI.onDevices(); };
  const act = (id, action, args) => UI.api(`/api/devices/${encodeURIComponent(id)}/${action}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(args || {}) }).catch(e => UI.toast(e.message, 'err'));
  UI.deviceAct = act;
  const PTZ = ['birddog', 'panasonic', 'visca', 'ndiptz'];
  const FIELDS = { // extra settings per device type
    visca: [['camId', 'Camera address (1–7)', 'number'], ['tcp', 'Raw VISCA over TCP (not Sony UDP)', 'checkbox']],
    pantrack: [['camId', 'Camera ID in Auto Tracking', 'number']],
    panasonic: [['user', 'Camera login (if enabled)', 'text'], ['password', 'Password', 'password']],
    ndiptz: [['source', 'NDI source name', 'text']],
    'nova-ctrl': [['opts.model', 'Model', 'select', [['vx4s', 'VX4S'], ['vx6s', 'VX6s'], ['vx600', 'VX600'], ['vx1000', 'VX1000'], ['vx16s', 'VX16S'], ['vxPro', 'VX Pro (port 15200)'], ['mctrl4k', 'MCTRL4K'], ['mctrl', 'MCTRL300 / 500 / 600 / 660'], ['novaProHD', 'NovaPro HD'], ['novaProUHDJr', 'NovaPro UHD Jr'], ['j6', 'J6']]]],
    'nova-h': [['opts.screenId', 'Screen ID (0 = first screen)', 'number']],
    pjlink: [['password', 'PJLink password (if set)', 'password'], ['opts.lampWarn', 'Warn at lamp hours (0 = off)', 'number']],
    'nova-coex': [['opts.tempWarn', 'Warn above (°C, receiving cards)', 'number']],
    helios: [['user', 'Login (if set in HELIOS)', 'text'], ['password', 'Password', 'password'], ['opts.tempWarn', 'Warn above (°C)', 'number']],
    'led-dmx': [['opts.protocol', 'Protocol', 'select', [['artnet', 'Art-Net'], ['sacn', 'sACN']]], ['opts.universe', 'Universe', 'number'], ['opts.chBright', 'Brightness channel', 'number'], ['opts.chPreset', 'Preset channel', 'number'], ['opts.presetStep', 'DMX value per preset step (default 1)', 'number'], ['opts.chBlackout', 'Blackout channel', 'number'], ['opts.chFreeze', 'Freeze channel', 'number'], ['opts.chTest', 'Test pattern channel', 'number']],
  };
  const fval = (c, k) => k.startsWith('opts.') ? (c.opts || {})[k.slice(5)] : c[k];
  const dot = d => `<span class="dvdot ${d.state.online ? (d.state.error ? 'warn' : 'on') : 'off'}" title="${esc(d.state.error || (d.state.online ? 'online' : 'offline'))}"></span>`;

  function editDevice(d) {
    const T = UI.devTypes || {}; const c = d || { type: 'videohub' };
    const body = `<div class="row wide"><label>Type</label><select id="dvType" ${d ? 'disabled' : ''}>${Object.entries(T).map(([k, t]) => `<option value="${k}" ${k === c.type ? 'selected' : ''}>${esc(t.label)}</option>`).join('')}</select></div>
      <div class="row wide"><label>Name</label><input type="text" id="dvName" value="${esc(c.name || '')}" placeholder="e.g. Router, Deck A, Cam 2"></div>
      <div class="row wide" id="dvHostRow"><label>IP / host</label><input type="text" id="dvHost" value="${esc(c.host || '')}" placeholder="192.168.1.50"></div>
      <div class="row wide"><label>Port</label><input id="dvPort" type="number" value="${c.port || ''}" placeholder="default"></div><div id="dvExtra"></div>
      <p class="muted small" id="dvHint"></p>`;
    const m = UI.modal(d ? 'Edit device' : 'Add device', body, [{ label: 'Cancel' }, { label: d ? 'Save' : 'Add', cls: 'primary', click: async bg => {
      const o = { id: d && d.id, type: $('#dvType', bg).value, name: $('#dvName', bg).value, host: $('#dvHost', bg).value, port: $('#dvPort', bg).value || undefined };
      $$('[data-f]', bg).forEach(i => { const v = i.type === 'checkbox' ? i.checked : i.type === 'number' ? (i.value === '' ? undefined : +i.value) : i.value; if (i.dataset.f.startsWith('opts.')) { (o.opts = o.opts || {})[i.dataset.f.slice(5)] = v; if (v === undefined) delete o.opts[i.dataset.f.slice(5)]; } else o[i.dataset.f] = v; });
      try { await UI.api('/api/devices', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(o) }); UI.toast('Saved ' + (o.name || 'device'), 'ok'); } catch (e) { UI.toast(e.message, 'err'); return false; } } }], { width: '440px' });
    const extra = () => { const t = $('#dvType', m).value; $('#dvPort', m).placeholder = 'default ' + ((UI.devTypes[t] || {}).port || ''); $('#dvHostRow', m).style.display = t === 'ndiptz' ? 'none' : '';
      $('#dvExtra', m).innerHTML = (FIELDS[t] || []).map(([k, l, ty, opts]) => `<div class="row wide"><label>${l}</label>${ty === 'select' ? `<select data-f="${k}">${opts.map(([v, lb]) => `<option value="${esc(v)}" ${String(fval(c, k) ?? '') === v ? 'selected' : ''}>${esc(lb)}</option>`).join('')}</select>` : ty === 'checkbox' ? `<input type="checkbox" data-f="${k}" ${fval(c, k) ? 'checked' : ''}>` : `<input type="${ty}" data-f="${k}" value="${esc(fval(c, k) == null ? '' : fval(c, k))}" ${ty === 'password' && c.hasPassword ? 'placeholder="saved — leave blank to keep"' : ''}>`}</div>`).join('');
      $('#dvHint', m).textContent = { pjlink: 'Any projector with PJLink (most Epson, Panasonic, NEC/Sharp, Sony, Christie, BenQ, Canon, Hitachi/Maxell, Optoma): port 4352. Turn PJLink on in the projector\'s network menu; its password is usually there too.', 'nova-coex': 'Novastar COEX processors (MX40 Pro, MX20, MX30, CX…) on their control network, port 8001. Close VMP on other computers — the processor accepts one controller at a time.', 'nova-ctrl': 'Older Novastar controllers over TCP (port 5200; VX Pro uses 15200). Pick the model so presets, inputs and display modes match.', 'nova-h': 'Novastar H series splicers, UDP port 6000. Screen IDs start at 0.', helios: 'Megapixel HELIOS processor (public REST API). Fill in the login only if one is set in HELIOS.', 'led-dmx': 'For processors controlled by DMX / Art-Net / sACN (e.g. Brompton Tessera DMX control, ROE, Colorlight). Enter the channels from the processor manual for the control profile you set on it. Leave the IP blank to broadcast (Art-Net) or use multicast (sACN).', atem: 'Any ATEM switcher on the network (port 9910). Camera control reaches Blackmagic cameras through the ATEM. Close other control software that holds many connections if the ATEM refuses.', ndiptz: 'NDI PTZ runs through the PIXORA desktop app; use the source name exactly as NDI lists it.',
        streamer: 'Blackmagic Streaming Encoder, Web Presenter or ATEM Mini with streaming (Ethernet protocol on port 9977).', bmcamera: 'Turn on "Web media manager / REST API" in Blackmagic Camera Setup.', pantrack: 'Needs Panasonic Auto Tracking software (AW-SF100/SF200) or a camera with built-in tracking.' }[t] || ''; };
    $('#dvType', m).onchange = extra; extra();
    const findPj = document.createElement('button'); findPj.className = 'btn xs'; findPj.textContent = 'Find projectors'; findPj.style.marginLeft = '6px';
    findPj.onclick = async () => { findPj.textContent = 'Searching…'; try { const r = await UI.api('/api/devices/pjlink-search?ms=2500'); findPj.textContent = 'Find projectors';
      if (!r.found.length) return UI.toast('No PJLink class 2 projectors answered — enter the IP address instead', 'warn');
      UI.menu(findPj.getBoundingClientRect().left, findPj.getBoundingClientRect().bottom + 4, r.found.map(p => ({ label: `${p.host} (${p.mac})`, click: () => { $('#dvHost', m).value = p.host; } }))); } catch (e) { findPj.textContent = 'Find projectors'; UI.toast(e.message, 'err'); } };
    $('#dvHostRow', m).appendChild(findPj); const showFind = () => { findPj.style.display = $('#dvType', m).value === 'pjlink' ? '' : 'none'; }; $('#dvType', m).addEventListener('change', showFind); showFind();
  }

  /* ---------- per-type controls */
  const ptzPad = d => `<div class="ptz" data-dev="${d.id}">
      <div class="pad">${[['-1', '1', '↖'], ['0', '1', '↑'], ['1', '1', '↗'], ['-1', '0', '←'], ['', '', '■'], ['1', '0', '→'], ['-1', '-1', '↙'], ['0', '-1', '↓'], ['1', '-1', '↘']].map(([p, t, l]) => p === '' ? `<button class="btn sm" data-ptzstop>■</button>` : `<button class="btn sm" data-pan="${p}" data-tilt="${t}">${l}</button>`).join('')}</div>
      <div class="ptzside"><label class="small muted">Speed</label><input type="range" min="0.1" max="1" step="0.05" value="0.5" data-ptzspeed>
        <div class="grid2"><button class="btn sm" data-zoom="1">Zoom +</button><button class="btn sm" data-zoom="-1">Zoom −</button></div>
        ${d.type !== 'birddog' ? `<button class="btn sm" data-dact="${d.type === 'ndiptz' ? 'autoFocus' : d.type === 'visca' ? 'onePushAF' : 'autoFocus'}"${d.type === 'panasonic' ? ` data-args='{"on":true}'` : ''}>Auto focus</button>` : ''}</div></div>
    <div class="presets" data-dev="${d.id}">${Array.from({ length: d.type === 'birddog' ? 9 : 12 }, (_, i) => `<button class="btn sm" data-preset="${d.type === 'visca' || d.type === 'ndiptz' ? i : i + 1}" title="Click: recall · Shift-click: store">${i + 1}</button>`).join('')}</div>
    <p class="muted small">Click a preset to recall it, Shift-click to store the current position.</p>`;

  function controls(d) {
    const s = d.state, B = (a, l, args, cls) => `<button class="btn sm ${cls || ''}" data-dact="${a}"${args ? ` data-args='${esc(JSON.stringify(args))}'` : ''}>${l}</button>`;
    switch (d.type) {
      case 'videohub': { const outs = s.outputs || [], ins = s.inputs || []; if (!outs.length) return '<p class="muted small">Waiting for routing…</p>';
        return `<table class="dvtable"><tr><th>Output</th><th>Source</th></tr>${outs.map((o, i) => `<tr><td>${i + 1} · ${esc(o)}${s.locks && s.locks[i] && s.locks[i] !== 'U' ? ' 🔒' : ''}</td><td><select data-route="${i + 1}">${ins.map((n, j) => `<option value="${j + 1}" ${s.routing[i] === j ? 'selected' : ''}>${j + 1} · ${esc(n)}</option>`).join('')}</select></td></tr>`).join('')}</table>`; }
      case 'hyperdeck': { const t = s.transport || {}; const clips = s.clips || [];
        return `<div class="kv"><span>${esc(t.status || '—')}${t['clip id'] ? ' · clip ' + t['clip id'] : ''}</span><b class="mono">${esc(t['display timecode'] || t.timecode || '')}</b></div>
          <div class="grid4" style="grid-template-columns:repeat(5,1fr)">${B('prev', '⏮')}${B('play', '▶', null, t.status === 'play' ? 'primary' : '')}${B('stop', '■')}${B('record', '● REC', null, t.status === 'record' ? 'danger' : '')}${B('next', '⏭')}</div>
          <div class="dvclips">${clips.map(c => `<div class="dvclip ${+t['clip id'] === c.id ? 'on' : ''}" data-dact="playClip" data-args='{"clip":${c.id}}'><b>${c.id}</b> ${esc(c.name)} <span class="muted mono">${esc(c.duration || '')}</span></div>`).join('') || '<p class="muted small">No clips on the selected disk.</p>'}</div>`; }
      case 'streamer': { const st = s.stream || {}, live = /stream/i.test(st.Status || '');
        return `<div class="kv"><span>${esc(s.settings['Current Platform'] || '')} ${esc(s.settings['Current Server'] || '')}</span><b class="${live ? 'ok' : ''}">${esc(st.Status || '—')}${st.Bitrate ? ' · ' + Math.round(st.Bitrate / 1e5) / 10 + ' Mb/s' : ''}</b></div>
          <div class="grid2">${B('start', 'Start stream', null, live ? 'primary' : '')}${B('stop', 'Stop stream')}</div>`; }
      case 'bmcamera': return `<div class="grid4">${B('record', s.recording ? '■ Stop rec' : '● Record', { on: !s.recording }, s.recording ? 'danger' : '')}${B('autoFocus', 'Auto focus')}${B('autoIris', 'Auto iris')}${B('autoWhiteBalance', 'Auto WB')}</div>
          <div class="row"><label>Iris</label><input type="range" min="0" max="1" step="0.01" value="0.5" data-slide="iris"><span></span></div>
          <div class="row"><label>Focus</label><input type="range" min="0" max="1" step="0.01" value="0.5" data-slide="focus"><span></span></div>
          <div class="row"><label>Zoom</label><input type="range" min="0" max="1" step="0.01" value="0" data-slide="zoom"><span></span></div>`;
      case 'pantrack': return `<div class="grid2">${B('tracking', 'Tracking ON', { on: true })}${B('tracking', 'Tracking OFF', { on: false })}</div><div class="grid4">${['upper', 'body', 'full', 'off'].map(m => B('angle', m[0].toUpperCase() + m.slice(1), { mode: m })).join('')}</div>
          <div class="presets">${Array.from({ length: 8 }, (_, i) => `<button class="btn sm" data-dact="preset" data-args='{"mode":"recall","preset":${i + 1}}'>${i + 1}</button>`).join('')}</div>`;
      case 'atem': { const ins = s.inputs || []; if (!s.online) return '<p class="muted small">Connecting…</p>';
        return `<div class="atembus"><label class="small muted">Program</label>${ins.map(i => `<button class="btn sm ${s.program === i.id ? 'danger' : ''}" data-dact="program" data-args='{"input":${i.id}}'>${esc(i.short || i.id)}</button>`).join('')}</div>
          <div class="atembus"><label class="small muted">Preview</label>${ins.map(i => `<button class="btn sm ${s.preview === i.id ? 'ok' : ''}" data-dact="preview" data-args='{"input":${i.id}}'>${esc(i.short || i.id)}</button>`).join('')}</div>
          <div class="grid4">${B('cut', 'CUT')}${B('auto', 'AUTO', null, 'primary')}${B('ftb', 'FTB', null, s.ftb ? 'danger' : '')}${B('dskAuto', 'DSK 1', { key: 1 }, s.dsk && s.dsk[0] && s.dsk[0].onAir ? 'danger' : '')}</div>
          <div class="grid4">${B('record', s.recording === 'recording' ? '■ Rec' : '● Rec', null, s.recording === 'recording' ? 'danger' : '')}${B('stream', s.streaming === 'streaming' ? '■ Stream' : 'Stream', null, s.streaming === 'streaming' ? 'danger' : '')}${B('dskAuto', 'DSK 2', { key: 2 }, s.dsk && s.dsk[1] && s.dsk[1].onAir ? 'danger' : '')}${B('macroStop', 'Stop macro')}</div>
          ${(s.macros || []).length ? `<div class="presets">${s.macros.map(mc => `<button class="btn sm" data-dact="macro" data-args='{"macro":${mc.id}}'>${esc(mc.name)}</button>`).join('')}</div>` : ''}`; }
      case 'birddog': return (s.mode === 'decode' && s.sources.length ? `<div class="row wide"><label>Decode</label><select data-dsel="source">${['None'].concat(s.sources).map(x => `<option>${esc(x)}</option>`).join('')}</select></div>` : '') + ptzPad(d);
    }
    if (d.projector) { const info = s.info || {}, H = s.health || {};
      if (!s.online) return `<p class="muted small">${s.error ? esc(s.error) : 'Connecting…'}</p>`;
      return `<div class="small" style="margin:2px 0 6px"><b style="color:${info.on ? 'var(--green)' : info.power === 'standby' ? '' : 'var(--yellow)'}">● ${esc(info.power || '?')}</b> · ${esc([info.make, info.model].filter(Boolean).join(' '))}${H.lampHours != null ? ` · lamp ${H.lampHours} h` : ''}${info.filterHours != null ? ` · filter ${info.filterHours} h` : ''}</div>
        <div class="grid4">${B('power', 'On', { on: true }, info.on ? 'primary' : '')}${B('power', 'Standby', { on: false }, info.power === 'standby' ? 'danger' : '')}${B('videoMute', info.videoMute ? 'Unmute picture' : 'Picture mute', { on: !info.videoMute }, info.videoMute ? 'danger' : '')}${B('freeze', 'Freeze', { on: true })}</div>
        ${(s.inputs || []).length ? `<div class="presets">${s.inputs.map(i => `<button class="btn sm ${info.input === i.id ? 'primary' : ''}" data-dact="input" data-args='${esc(JSON.stringify({ input: i.id }))}'>${esc(i.name)}</button>`).join('')}</div>` : ''}
        ${(H.alerts || []).map(a => `<div class="small" style="color:${a.lvl === 'err' ? 'var(--red)' : 'var(--yellow)'}">⚠ ${esc(a.msg)}</div>`).join('')}
        <p class="muted small">Use “Device action” in cues, keys, rules and the timeline to switch projectors on, mute or change input.</p>`; }
    if (d.led) { const pr = (s.presets || []).length ? s.presets : Array.from({ length: 10 }, (_, i) => ({ id: i + 1, name: String(i + 1) })), info = s.info || {};
      return `<div class="row"><label>Brightness</label><input type="range" min="0" max="100" step="1" value="${info.brightness != null ? info.brightness : 100}" data-slide="brightness"><span></span></div>
        <div class="grid4">${B('blackout', 'Blackout', { on: true }, info.blackout ? 'danger' : '')}${B('freeze', 'Freeze', { on: true }, info.freeze ? 'primary' : '')}${B('normal', 'Normal')}<select data-dsela="test"><option value="">Test pattern…</option>${['white', 'red', 'green', 'blue', 'grid', 'gradient', 'off'].map(p => `<option value="${p}">${p[0].toUpperCase() + p.slice(1)}</option>`).join('')}</select></div>
        <div class="presets">${pr.slice(0, 24).map(p => `<button class="btn sm" data-dact="preset" data-args='${esc(JSON.stringify({ preset: p.id }))}' title="Recall preset">${esc(p.name)}</button>`).join('')}</div>
        ${(s.inputs || []).length ? `<div class="presets">${s.inputs.map(i => `<button class="btn sm" data-dact="input" data-args='${esc(JSON.stringify({ input: i.id }))}'>${esc(i.name)}</button>`).join('')}</div>` : ''}
        ${s.health ? `<div class="small" style="margin:4px 0">${[s.health.temp != null ? `Hottest ${Math.round(s.health.temp)}°C` : '', s.health.cards ? `${s.health.cards - s.health.cardsBad}/${s.health.cards} receiving cards OK` : '', s.health.ports ? `${s.health.ports - s.health.portsBad}/${s.health.ports} ports OK` : ''].filter(Boolean).join(' · ') || 'Monitoring'}
          ${(s.health.alerts || []).slice(0, 5).map(a => `<div style="color:${a.lvl === 'err' ? 'var(--red)' : 'var(--yellow)'}">⚠ ${esc(a.msg)}</div>`).join('') || '<span style="color:var(--green)"> · no warnings</span>'}</div>` : ''}
        <p class="muted small">${d.type === 'led-dmx' ? 'Sends DMX — no feedback from the processor.' : 'Presets and inputs are read from the processor where it reports them.'} Use “Device action” in cues, keys and rules for the same controls.</p>`; }
    return PTZ.includes(d.type) ? ptzPad(d) : '';
  }

  UI.panels.devices = {
    sig: () => JSON.stringify(UI.devices.map(d => [d.id, d.name, d.state.online, !!d.state.error, d.state.inputs, d.state.outputs, d.state.routing, d.state.clips, d.state.transport && d.state.transport.status, d.state.transport && d.state.transport['clip id'], d.state.stream, d.state.recording, d.state.program, d.state.preview, d.state.sources, d.state.ftb, d.state.dsk, d.state.recording, d.state.streaming, d.state.macros])),
    render() {
      if (!UI.devTypes) UI.api('/api/devices').then(r => { UI.devTypes = r.types; UI.devices = r.devices; UI.renderRight(true); }).catch(() => {});
      const head = `<div class="toolbar"><button class="btn sm primary" data-dvadd>${I('plus')}Add device</button></div><p class="muted small" style="margin:2px 0 8px">Every button here is also a cue action (“Device action” in Cues, Rules and the Scheduler) and OSC <span class="mono">/pixora/device/&lt;name&gt;/&lt;action&gt;</span>.</p>`;
      if (!UI.devices.length) return head + sec('No devices yet', '<p class="muted">Add Blackmagic Videohub routers, HyperDecks, Streaming Encoders / Web Presenters, cameras and ATEM switchers, BirdDog, Panasonic, VISCA and NDI PTZ cameras. They are saved on this machine and reconnect on their own.</p>');
      return head + UI.devices.map(d => `<div class="card dvcard" data-devcard="${d.id}"><header>${dot(d)}<b>${esc(d.name)}</b><span class="muted small">${esc((UI.devTypes && UI.devTypes[d.type] || {}).label || d.type)}${d.state.info && d.state.info.model ? ' · ' + esc(d.state.info.model) : ''}</span><span class="spacer"></span>
        <button class="btn sm icon" data-dvedit="${d.id}" title="Edit">${I('wand')}</button><button class="btn sm icon" data-dvdel="${d.id}" title="Remove">${I('trash')}</button></header>
        <div class="dvbody" data-dev="${d.id}">${d.state.error && !d.state.online ? `<p class="small err">${esc(d.state.error)}</p>` : ''}${controls(d)}</div></div>`).join('');
    },
    after(pane) {
      const devOf = el => { const c = el.closest('[data-dev]'); return c && c.dataset.dev; };
      pane.onclick = e => {
        const t = e.target;
        if (t.closest('[data-dvadd]')) return editDevice();
        const ed = t.closest('[data-dvedit]'); if (ed) return editDevice(Object.assign({}, UI.devices.find(d => d.id === ed.dataset.dvedit), { type: UI.devices.find(d => d.id === ed.dataset.dvedit).type }));
        const del = t.closest('[data-dvdel]'); if (del) { const d = UI.devices.find(x => x.id === del.dataset.dvdel); return UI.modal('Remove device', `Remove <b>${esc(d.name)}</b>? Cues that use it will stop working.`, [{ label: 'Cancel' }, { label: 'Remove', cls: 'danger', click: () => UI.api('/api/devices/' + d.id, { method: 'DELETE' }) }]); }
        const a = t.closest('[data-dact]'); if (a) return act(devOf(a), a.dataset.dact, a.dataset.args ? JSON.parse(a.dataset.args) : {});
        const pr = t.closest('[data-preset]'); if (pr) { act(devOf(pr), e.shiftKey ? 'save' : 'recall', { preset: +pr.dataset.preset }); if (e.shiftKey) UI.toast('Stored preset ' + pr.textContent, 'ok'); return; }
        if (t.closest('[data-ptzstop]')) return act(devOf(t), 'stop');
      };
      // hold-to-move PTZ and zoom
      const speed = el => +($('[data-ptzspeed]', el.closest('.ptz')) || { value: 0.5 }).value;
      pane.onpointerdown = e => {
        const mv = e.target.closest('[data-pan]'), zm = e.target.closest('[data-zoom]'); if (!mv && !zm) return;
        const id = devOf(e.target), d = UI.devices.find(x => x.id === id), sp = speed(e.target);
        if (mv) act(id, 'move', { pan: +mv.dataset.pan * sp, tilt: +mv.dataset.tilt * sp });
        else act(id, d.type === 'ndiptz' ? 'zoomSpeed' : 'zoom', { speed: +zm.dataset.zoom * sp });
        const up = () => { removeEventListener('pointerup', up); act(id, 'stop'); }; addEventListener('pointerup', up);
      };
      pane.onchange = e => {
        const r = e.target.closest('[data-route]'); if (r) return act(devOf(r), 'route', { output: +r.dataset.route, input: +r.value });
        const sl = e.target.closest('[data-slide]'); if (sl) return act(devOf(sl), sl.dataset.slide, { value: +sl.value });
        const ds = e.target.closest('[data-dsel]'); if (ds) return act(devOf(ds), ds.dataset.dsel, { source: ds.value });
        const da = e.target.closest('[data-dsela]'); if (da && da.value) { act(devOf(da), da.dataset.dsela, { pattern: da.value }); da.value = ''; }
      };
    },
  };
})();
