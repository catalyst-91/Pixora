/* PIXORA right-hand property panels */
(function () {
  const S = window.SCHEMA, UI = window.UI, $ = UI.$, $$ = UI.$$, esc = UI.esc, I = UI.icon;
  const fxOn = fx => fx ? Object.keys(fx).filter(k => fx[k] && fx[k].on).join(',') : '-';
  const sec = (title, body, extra) => `<div class="sec"><h4>${title}${extra || ''}</h4>${body}</div>`;
  const primaryInfo = () => { const p = UI.outputs.find(o => o.primary) || UI.outputs[0]; return p ? p.info || {} : {}; };

  /* ================= CLIP ================= */
  UI.panels.clip = {
    sig: s => { const l = s.layers[UI.sel.layer]; const c = l && UI.sel.slot != null ? l.clips[UI.sel.slot] : null;
      return JSON.stringify(c ? [c.type, c.gen && c.gen.kind, fxOn(c.fx), !!c.fx, c.beatSync, c.src, s.shaders.length, (primaryInfo().devices || {}).video, l.active === UI.sel.slot] : [l && l.id]); },
    render(s) {
      const li = UI.sel.layer, ci = UI.sel.slot, l = s.layers[li]; const c = l && ci != null ? l.clips[ci] : null;
      if (!c) return `<div class="empty-note">${ci == null ? 'Select a clip slot to edit it.' : `Empty slot — Layer ${li + 1}, column ${ci + 1}.`}<br><br>
        ${ci != null ? `<div style="display:flex;flex-wrap:wrap;gap:6px;justify-content:center">
          <button class="btn sm" data-quick="solid">${I('wand')}Solid colour</button><button class="btn sm" data-quick="text">${I('wand')}Text</button>
          <button class="btn sm" data-quick="plasma">${I('wand')}Plasma</button><button class="btn sm" data-quick="web">${I('globe')}Web page</button>
          <button class="btn sm" data-quick="screen">${I('screen')}Screen capture</button></div><p class="hint">…or drag media from the library below.</p>` : ''}</div>`;
      const b = `layers.${li}.clips.${ci}`; const isVid = c.type === 'video';
      let h = `<div class="sec"><div style="display:flex;gap:8px;align-items:center;margin-bottom:8px">
        <input type="text" data-path="${b}.name" style="flex:1;font-weight:600">
        <button class="btn sm ${l.active === ci ? 'live' : ''}" data-clipact="trigger" title="Trigger">${I('play')}</button>
        ${isVid ? `<button class="btn sm icon" data-clipact="restart" title="Restart">${I('restart')}</button><button class="btn sm icon" data-clipact="pause" title="Pause / resume">${I('pause')}</button>` : ''}</div>
        <div class="small muted mono" style="word-break:break-all">${esc(c.type === 'gen' ? 'Generator · ' + c.gen.kind : c.type === 'web' ? c.url : c.type === 'capture' ? 'Live input' : c.type === 'screen' ? 'Screen / tab capture' : c.type === 'playlist' ? 'Playlist · ' + (c.items || []).length + ' items' + (c.ext ? ' · linked to ' + c.ext.path : '') : c.type === 'replay' ? 'Instant replay' : c.type === 'guest' ? 'Remote guest ' + (c.slot || 1) : c.type === 'decklink' ? 'DeckLink input' : c.src)}</div></div>`;
      if (isVid) {
        h += sec('Playback', `<div class="scrub" data-scrub="${li}"><div class="io"></div><div class="ph"></div><div class="tt"></div></div><div style="height:8px"></div>
          ${UI.rRange('Speed', b + '.speed', -2, 4, 0.01, 1)}
          <div class="row wide"><label>Loop mode</label><div class="ctl">${UI.seg(b + '.loop', [['loop', 'Loop'], ['bounce', 'Bounce'], ['once', 'Play once']])}</div></div>
          ${UI.rRange('In point', b + '.inPt', 0, 1, 0.001, 0)}${UI.rRange('Out point', b + '.outPt', 0, 1, 0.001, 1)}
          ${UI.rToggle('Beat sync', b + '.beatSync')}${c.beatSync ? UI.rRange('Length (beats)', b + '.beats', 1, 128, 1, 16) : ''}
          <div class="row wide" title="Lock this clip's playhead to a CDJ / rekordbox deck through PRO DJ LINK Bridge (TCNet). Make the clip the same length as the track."><label>Follow DJ deck</label><div class="ctl"><select data-path="${b}.djSync" data-rerender>${[['off', 'Off'], ['master', 'Master deck'], ['1', 'Deck 1'], ['2', 'Deck 2'], ['3', 'Deck 3'], ['4', 'Deck 4']].map(([v, l]) => `<option value="${v}" ${(c.djSync || 'off') === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div></div>
          ${c.djSync && c.djSync !== 'off' ? UI.rRange('Deck offset (s)', b + '.djOffset', -10, 10, 0.01, 0) : ''}
          <div class="hint">Reverse/bounce is smoothest with all-intra files — use “Scrub-friendly” conversion in Comp ▸ Media.</div>`);
      }
      if (c.type === 'gen') {
        const g = S.GENERATORS.find(x => x.id === c.gen.kind) || S.GENERATORS[0];
        h += sec('Generator', `<div class="row wide"><label>Type</label><div class="ctl"><select data-genkind="${b}">${S.GENERATORS.map(x => `<option value="${x.id}" ${x.id === c.gen.kind ? 'selected' : ''}>${x.name}</option>`).join('')}</select></div></div>
          ${g.params.map(p => UI.param(b + '.gen.params', p)).join('')}
          ${c.gen.kind === 'shader' ? `<button class="btn sm" data-goshaders>${I('code')}Edit shaders</button>${UI.shaderErrors[c.gen.params.shader] ? `<pre class="small" style="color:var(--red);white-space:pre-wrap">${esc(UI.shaderErrors[c.gen.params.shader])}</pre>` : ''}` : ''}
          ${c.gen.kind === 'text' ? `<div class="hint">Live feed: paste a URL to a .txt file, a CSV, or a Google Sheet published as CSV (File ▸ Share ▸ Publish to web ▸ CSV). The server fetches it every “Refresh” seconds.</div>` : ''}`);
      }
      if (c.type === 'playlist' && UI.playlistSection) h += UI.playlistSection(c, li, ci, b, l);
      if (c.type === 'web') h += sec('Web page', `${UI.rText('URL', b + '.url', 'https://…')}${UI.rToggle('Interactive', b + '.interactive')}
        ${UI.rRange('Page zoom', b + '.web.zoom', 0.25, 3, 0.05, 1)}
        ${UI.rToggle('Embed via PIXORA proxy', b + '.web.proxy')}
        ${UI.rNum('Auto-scroll (px/s)', b + '.web.scroll', 5, 0, 2000)}${UI.rToggle('Loop scrolling', b + '.web.loopScroll')}
        ${UI.rToggle('Transparent background', b + '.web.transparent')}
        ${UI.rNum('Auto-refresh (s, 0 = off)', b + '.web.refresh', 5, 0, 86400)}
        <div class="row wide"><label>Rotate through</label><div class="ctl"><textarea data-path="${b}.web.playlist" rows="3" placeholder="More URLs, one per line — the page rotates through them"></textarea></div></div>
        ${UI.rNum('Seconds per page', b + '.web.dwell', 1, 3, 3600)}
        <div class="row wide"><label>Custom CSS</label><div class="ctl"><textarea data-path="${b}.web.css" rows="2" placeholder="e.g. header, .cookie-banner { display:none }"></textarea></div></div>
        <div class="hint">Web pages render as a live overlay above the video layers in each output window. Opacity, blend (CSS), position, scale and rotation apply; GPU effects need the desktop app. <b>Proxy</b> loads the page through PIXORA so sites that refuse to be embedded still show; auto-scroll, transparent background and custom CSS turn the proxy on automatically. Proxied pages run sandboxed and can't reach PIXORA's controls. Sites that need a login or heavy app logic may still not work through the proxy; for those use Screen / tab capture.</div>`);
      if (c.type === 'capture') { const vids = (primaryInfo().devices || {}).video || [];
        h += sec('Live input', `<div class="row wide"><label>Device</label><div class="ctl"><select data-path="${b}.device"><option value="">Default camera</option>${vids.map(v => `<option value="${esc(v.id)}">${esc(v.label)}</option>`).join('')}</select><button class="btn sm" data-scan>${I('refresh')}Scan</button></div></div>
          <div class="hint">Devices are those attached to the computer running the primary Output window. Webcams, HDMI/SDI capture cards and virtual cameras all appear here.</div>`); }
      if (c.type === 'screen') h += sec('Screen capture', `<div class="hint">The Output window will ask (once) which screen, window or browser tab to capture. Captured pixels go through the full effects pipeline — use this for web pages that can't be embedded.</div>`);
      h += sec('Transform', `${UI.rSelect('Fit', b + '.fit', [['fill', 'Fill (crop)'], ['fit', 'Fit (letterbox)'], ['stretch', 'Stretch'], ['native', 'Native pixels 1:1']])}
        ${UI.rRange('Position X', b + '.x', -2, 2, 0.001, 0)}${UI.rRange('Position Y', b + '.y', -2, 2, 0.001, 0)}${UI.rRange('Scale', b + '.scale', 0, 4, 0.001, 1)}
        ${UI.rRange('Rotation', b + '.rotation', -180, 180, 0.1, 0)}${UI.rRange('Opacity', b + '.opacity', 0, 1, 0.001, 1)}
        <div class="row wide"><label>Flip</label><div class="ctl"><button class="sw" data-path="${b}.flipX" data-toggle></button><span class="muted small">H</span><button class="sw" data-path="${b}.flipY" data-toggle></button><span class="muted small">V</span></div></div>`);
      h += sec('Transition', `${UI.rSelect('Into this clip', b + '.transition', [['layer', 'Use layer setting']].concat([['fade', 'Crossfade'], ['cut', 'Cut'], ['dip', 'Dip'], ['wipe-left', 'Wipe →'], ['wipe-right', 'Wipe ←'], ['wipe-up', 'Wipe ↑'], ['wipe-down', 'Wipe ↓'], ['split', 'Split'], ['stinger', 'Stinger']].slice(0, 8)))}${UI.rRange('Duration (s)', b + '.transitionDur', 0, 10, 0.01, 0.5)}`);
      h += sec('Clip effects', c.fx ? UI.fxStack(b + '.fx', c.fx) : `<div class="hint">Clip effects travel with this clip (layer effects apply to whatever plays on the layer).</div><button class="btn sm" data-clipfx>${I('plus')}Enable clip effects</button>`,
        c.fx ? `<button class="btn xs" data-clipfxoff style="margin-left:6px">Remove</button>` : '');
      return h;
    },
    after(pane, s) {
      const li = UI.sel.layer, ci = UI.sel.slot;
      pane.onclick = async e => {
        const q = e.target.closest('[data-quick]'); if (q) { const k = q.dataset.quick; if (k === 'web') UI.assignWeb(li, ci); else if (k === 'screen') UI.cmd({ op: 'assign', layer: li, slot: ci, clip: { type: 'screen', name: 'Screen capture', fit: 'fit' } }); else UI.assignGen(li, ci, k); return; }
        const a = e.target.closest('[data-clipact]'); if (a) { const k = a.dataset.clipact; UI.cmd(k === 'trigger' ? { op: 'trigger', layer: li, clip: ci } : k === 'restart' ? { op: 'restart', layer: li } : { op: 'pause', layer: li }); }
        if (e.target.closest('[data-clipfx]')) UI.cmd({ op: 'clipFx', layer: li, slot: ci, on: true });
        if (e.target.closest('[data-clipfxoff]')) UI.cmd({ op: 'clipFx', layer: li, slot: ci, on: false });
        if (e.target.closest('[data-scan]')) { UI.cmd({ op: 'scanInputs' }); UI.toast('Scanning inputs on the output computer… (allow camera access there)'); }
        if (e.target.closest('[data-goshaders]')) UI.setBtab('shaders');
        const sc = e.target.closest('[data-scrub]'); if (sc) { const r = sc.getBoundingClientRect(); UI.cmd({ op: 'seek', layer: li, pos: (e.clientX - r.left) / r.width }); }
      };
      pane.onchange = e => { const g = e.target.dataset.genkind; if (g) { const k = e.target.value; BVJ.cmd({ op: 'set', path: g + '.gen', value: { kind: k, params: S.genDefaults(k) } }); BVJ.cmd({ op: 'set', path: g + '.name', value: S.GENERATORS.find(x => x.id === k).name }); } };
      this.live(pane, s);
    },
    live(pane, s) {
      const sc = $('[data-scrub]', pane); if (!sc) return; const li = +sc.dataset.scrub; const l = s.layers[li]; const c = l.clips[UI.sel.slot]; if (!c) return;
      $('.io', sc).style.left = c.inPt * 100 + '%'; $('.io', sc).style.width = Math.max(0, (c.outPt - c.inPt) * 100) + '%';
      const p = l.active === UI.sel.slot ? UI.positions[li] : null;
      $('.ph', sc).style.display = p ? '' : 'none'; if (p) $('.ph', sc).style.left = ((c.inPt + p.pos * (c.outPt - c.inPt)) * 100) + '%';
      $('.tt', sc).textContent = p ? `${BVJ.fmtTime(p.t)} / ${BVJ.fmtTime(p.dur)}` : (UI.libIndex.get(c.src) && UI.libIndex.get(c.src).meta ? BVJ.fmtTime(UI.libIndex.get(c.src).meta.duration) : '');
    },
  };

  /* ================= LAYER ================= */
  UI.panels.layer = {
    sig: s => { const l = s.layers[UI.sel.layer]; return JSON.stringify(l ? [l.id, l.transition, fxOn(l.fx), l.mask.type, l.autopilot, l.autoWhen, s.presets.map(p => p.id), s.layers.length] : 0); },
    render(s) {
      const li = UI.sel.layer, l = s.layers[li]; if (!l) return '';
      const b = `layers.${li}`;
      let h = `<div class="sec"><div style="display:flex;gap:6px;align-items:center"><input type="text" data-path="${b}.name" style="flex:1;font-weight:600">
        <button class="btn sm icon" data-lact="up" title="Move up">${I('up')}</button><button class="btn sm icon" data-lact="down" title="Move down">${I('down')}</button>
        <button class="btn sm icon" data-lact="dup" title="Duplicate">${I('copy')}</button><button class="btn sm icon danger" data-lact="del" title="Delete">${I('trash')}</button></div></div>`;
      h += sec('Mix', `${UI.rRange('Opacity', b + '.opacity', 0, 1, 0.001, 1, 'live')}${UI.rSelect('Blend mode', b + '.blend', S.BLENDS)}${UI.rRange('Audio volume', b + '.volume', 0, 1, 0.01, 1)}
        <div class="row wide"><label>Crossfader</label><div class="ctl">${UI.seg(b + '.xfade', [['none', 'Off'], ['A', 'Side A'], ['B', 'Side B']])}</div></div>`);
      h += sec('Transition', `${UI.rSelect('Type', b + '.transition', [['fade', 'Crossfade'], ['cut', 'Cut'], ['dip', 'Dip'], ['wipe-left', 'Wipe →'], ['wipe-right', 'Wipe ←'], ['wipe-up', 'Wipe ↑'], ['wipe-down', 'Wipe ↓'], ['split', 'Split'], ['stinger', 'Stinger']])}${l.transition === 'stinger' ? `${UI.rText('Stinger video (library path)', b + '.stinger.src', 'local/stingers/wipe.webm')}${UI.rRange('Cut point', b + '.stinger.cut', 0, 1, 0.01, 0.5)}${UI.rRange('Length (s)', b + '.stinger.dur', 0.2, 10, 0.05, 1.5)}<div class="hint">A video played over the change (WebM with alpha works); the layer swaps at the cut point. Drop a library file on the path box, or type its library path.</div>` : ''}${UI.rRange('Duration (s)', b + '.transitionDur', 0, 10, 0.01, 0.5)}`);
      h += sec('Autopilot / playlist', `${UI.rSelect('Mode', b + '.autopilot', [['off', 'Off'], ['next', 'Next clip'], ['random', 'Random clip']])}
        <div class="row wide"><label>Advance</label><div class="ctl">${UI.seg(b + '.autoWhen', [['end', 'When clip ends'], ['beats', 'Every N beats']])}</div></div>
        ${UI.rRange('Beats', b + '.autoBeats', 1, 128, 1, 16)}<div class="hint">Tip: select several files in the library and use “Send to layer” to build a playlist row, then turn on Autopilot.</div>`);
      h += sec('Layer transform', `${UI.rRange('Position X', b + '.transform.x', -2, 2, 0.001, 0)}${UI.rRange('Position Y', b + '.transform.y', -2, 2, 0.001, 0)}
        ${UI.rRange('Scale', b + '.transform.scale', 0, 4, 0.001, 1)}${UI.rRange('Rotation', b + '.transform.rotation', -180, 180, 0.1, 0)}`);
      h += sec('Mask / matte', `<div class="row wide"><label>Type</label><div class="ctl"><select data-path="${b}.mask.type" data-rerender>${['none', 'rect', 'ellipse', 'luma matte', 'alpha matte'].map(m => `<option value="${m}">${m === 'none' ? 'None' : m[0].toUpperCase() + m.slice(1)}</option>`).join('')}</select></div></div>
        ${l.mask.type === 'rect' || l.mask.type === 'ellipse' ? UI.rRange('Left', b + '.mask.x', 0, 1, 0.001, 0) + UI.rRange('Top', b + '.mask.y', 0, 1, 0.001, 0) + UI.rRange('Width', b + '.mask.w', 0, 1, 0.001, 1) + UI.rRange('Height', b + '.mask.h', 0, 1, 0.001, 1) + UI.rRange('Feather', b + '.mask.feather', 0, 0.5, 0.001, 0) : ''}
        ${/matte/.test(l.mask.type) ? `<div class="hint">Track matte: this layer is only visible where the layer directly <b>below</b> it is bright (luma) or opaque (alpha). The layer below still renders unless you bypass it or set it to 0% opacity.</div>` : ''}
        ${l.mask.type !== 'none' ? UI.rToggle('Invert', b + '.mask.invert') : ''}`);
      h += sec('Layer effects', UI.fxStack(b + '.fx', l.fx));
      h += sec('Looks (effect presets)', `<div class="row wide"><label>Apply look</label><div class="ctl"><select data-applylook><option value="">Choose…</option>${s.presets.map(p => `<option value="${p.id}">${p.fav ? '★ ' : ''}${esc(p.name)}</option>`).join('')}</select><button class="btn sm" data-savelook>${I('save')}Save current</button></div></div>`);
      return h;
    },
    after(pane) {
      const li = UI.sel.layer;
      pane.onclick = async e => {
        const a = e.target.closest('[data-lact]'); if (a) { const k = a.dataset.lact;
          if (k === 'up') { UI.cmd({ op: 'moveLayer', layer: li, dir: 1 }); UI.sel.layer = Math.min(UI.st().layers.length - 1, li + 1); }
          if (k === 'down') { UI.cmd({ op: 'moveLayer', layer: li, dir: -1 }); UI.sel.layer = Math.max(0, li - 1); }
          if (k === 'dup') UI.cmd({ op: 'duplicateLayer', layer: li });
          if (k === 'del' && confirm('Delete this layer?')) { UI.cmd({ op: 'removeLayer', layer: li }); UI.sel.layer = 0; } }
        if (e.target.closest('[data-savelook]')) { const n = await UI.prompt('Save look', UI.st().layers[li].name + ' look'); if (n) UI.cmd({ op: 'presetSave', layer: li, name: n }); }
      };
      pane.onchange = e => { if (e.target.dataset.applylook != null && e.target.value) { UI.cmd({ op: 'presetApply', id: e.target.value, layer: li }); setTimeout(() => UI.renderRight(true), 80); } };
    },
  };

  /* ================= COMPOSITION ================= */
  UI.panels.comp = {
    sig: s => JSON.stringify([fxOn(s.comp.fx), s.comp.outputMode, (primaryInfo().devices || {}).audio, UI.library.settings, UI.ffmpeg]),
    render(s) {
      const c = s.comp; const preset = S.RES_PRESETS.find(([r]) => r === c.width + 'x' + c.height);
      const aud = (primaryInfo().devices || {}).audio || []; const set = UI.library.settings || {};
      return sec('Composition', `${UI.rText('Name', 'comp.name')}
          <div class="row wide"><label>Resolution</label><div class="ctl"><select data-res><option value="">Custom…</option>${S.RES_PRESETS.map(([r, l]) => `<option value="${r}" ${preset && preset[0] === r ? 'selected' : ''}>${l}</option>`).join('')}</select></div></div>
          <div class="row wide"><label>Custom size</label><div class="ctl"><input type="number" data-path="comp.width" min="1" max="8192" style="width:80px"><span class="muted">×</span><input type="number" data-path="comp.height" min="1" max="8192" style="width:80px"><span class="muted small">px</span></div></div>
          ${UI.rColor('Background', 'comp.bg')}
          <div class="row wide"><label>Columns</label><div class="ctl"><input type="number" data-cols value="${c.columns}" min="1" max="64" style="width:80px"></div></div>
          <div class="hint">Any resolution up to 8192 px per side — ideal for LED walls and strips (e.g. 2048×256). Everything renders at exactly this size on the output computer's GPU.</div>`) +
        sec('Output window', `<div class="row wide"><label>Scaling</label><div class="ctl">${UI.seg('comp.outputMode', [['fit', 'Fit to window'], ['native', 'Native 1:1 pixels']])}</div></div>
          ${c.outputMode === 'native' ? `<div class="row wide"><label>Offset X / Y</label><div class="ctl"><input type="number" data-path="comp.outputX" style="width:80px"><input type="number" data-path="comp.outputY" style="width:80px"></div></div><div class="hint">Native mode places the composition pixel-for-pixel at this offset on the output display — what an LED processor expects.</div>` : ''}
          ${UI.rToggle('Stats overlay', 'comp.showStats')}`) +
        sec('Master', `${UI.rRange('Master', 'comp.master', 0, 1, 0.001, 1)}${UI.rRange('Speed', 'comp.speed', 0, 2, 0.01, 1)}${UI.rRange('Audio volume', 'comp.volume', 0, 1, 0.01, 1)}`) +
        sec('Audio input (for audio-reactive mods & shaders)', `<div class="row wide"><label>Input device</label><div class="ctl"><select data-path="comp.audio.device"><option value="">Default input</option>${aud.map(a => `<option value="${esc(a.id)}">${esc(a.label)}</option>`).join('')}</select><button class="btn sm" data-scan>${I('refresh')}</button></div></div>
          ${UI.rRange('Gain', 'comp.audio.gain', 0, 8, 0.01, 1)}${UI.rRange('Smoothing', 'comp.audio.smoothing', 0, 0.98, 0.01, 0.75)}${UI.rToggle('Always listen', 'comp.audio.always')}
          <div class="meter" style="margin-top:6px"><i data-alevel></i></div><div class="hint">Audio is captured on the computer running the primary Output window (mic, line-in or audio interface). It's analysed into Level / Bass / Mid / High bands.</div>`) +
        sec('Media conversion (local ffmpeg)', `<div class="kv"><span>ffmpeg</span><b style="color:${UI.ffmpeg ? 'var(--green)' : 'var(--yellow)'}">${UI.ffmpeg ? 'Installed' : 'Not found'}</b></div>
          <div class="row wide"><label>Auto-convert</label><div class="ctl"><button class="sw ${set.autoConvert ? 'on' : ''}" data-setting="autoConvert"></button><span class="muted small">convert unplayable files automatically</span></div></div>
          <div class="row wide"><label>Quality</label><div class="ctl"><select data-setting-sel="convertMode">${[['balanced', 'Balanced (H.264, GOP 15)'], ['scrub', 'Scrub-friendly (all-intra, large)'], ['small', 'Small files (GOP 60)']].map(([v, l]) => `<option value="${v}" ${set.convertMode === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div></div>
          <div class="hint">AVI, WMV, MPEG-2, ProRes, DNxHD, MXF, FLV, HEVC etc. are converted on this computer into a cached browser-playable copy. Originals (including on external drives) are never modified.</div>
          <button class="btn sm" data-convall>${I('refresh')}Convert all unplayable media in this show</button>`) +
        sec('Composition effects', UI.fxStack('comp.fx', c.fx));
    },
    after(pane) {
      pane.onchange = async e => {
        const t = e.target;
        if (t.dataset.res != null && t.value) { const [w, h] = t.value.split('x').map(Number); BVJ.cmd({ op: 'setMany', values: { 'comp.width': w, 'comp.height': h } }); }
        if (t.dataset.cols != null) UI.cmd({ op: 'setColumns', n: +t.value });
        if (t.dataset.settingSel) { await UI.api('/api/settings', { method: 'POST', body: JSON.stringify({ [t.dataset.settingSel]: t.value }) }); UI.loadLibrary(); }
      };
      pane.onclick = async e => {
        const st = e.target.closest('[data-setting]'); if (st) { const v = !st.classList.contains('on'); st.classList.toggle('on', v); await UI.api('/api/settings', { method: 'POST', body: JSON.stringify({ [st.dataset.setting]: v }) }); UI.loadLibrary(); }
        if (e.target.closest('[data-scan]')) { UI.cmd({ op: 'scanInputs' }); UI.toast('Scanning inputs on the output computer…'); }
        if (e.target.closest('[data-convall]')) { try { const r = await UI.api('/api/convertAll', { method: 'POST' }); UI.toast(r.queued + ' file(s) queued', 'ok'); } catch (er) { UI.toast(er.message, 'err'); } }
      };
    },
    live(pane) { const m = $('[data-alevel]', pane); if (m) m.style.width = ((UI.audio && UI.audio.level) || 0) * 100 + '%'; },
  };

  /* ================= OUTPUT / MAPPING ================= */
  UI.panels.output = {
    sig: s => JSON.stringify([s.outputs.map(o => [o.id, o.slices.map(x => x.id)]), UI.outputs.map(o => [o.id, o.primary, o.info && o.info.output])]),
    render(s) {
      let h = sec('Connected output windows', UI.outputs.length ? UI.outputs.map(o => `<div class="kv"><span>${o.primary ? '★ ' : ''}${esc((o.info && o.info.output) || 'Output')} ${o.info && o.info.clean ? '(clean)' : ''}</span><b class="small">${esc((o.info && o.info.gpu || '').slice(0, 36))} · ${(o.info && o.info.fps) || '–'} fps</b></div>`).join('') + `<div class="hint">★ = primary output (drives preview, audio analysis and pixel output). Press P in an output window to make it primary.</div>` : `<div class="hint">No output windows open. Use the Output button (top right) or open <span class="mono">/output</span> on the computer connected to your screen/LED processor.</div>`);
      s.outputs.forEach((o, oi) => {
        const ob = `outputs.${oi}`; const OW = o.width || s.comp.width, OH = o.height || s.comp.height;
        h += `<div class="card"><header><b>${esc(o.name)}</b><span class="muted small">${OW}×${OH}</span>
          <button class="btn xs" data-open="${o.id}">${I('screen')}Open</button><button class="btn xs" data-clean="${o.id}">Clean</button>${o.id !== 'main' ? `<button class="btn xs danger" data-delout="${o.id}">${I('trash')}</button>` : ''}</header><div class="body">
          ${UI.rText('Name', ob + '.name')}
          <div class="row wide"><label>Output size</label><div class="ctl"><input type="number" data-path="${ob}.width" style="width:80px"><span class="muted">×</span><input type="number" data-path="${ob}.height" style="width:80px"><span class="muted small">0 = comp size</span></div></div>
          <div class="row wide"><label>Slice template</label><div class="ctl" style="flex-wrap:wrap"><button class="btn xs" data-tpl="${o.id}:1:h">Full</button><button class="btn xs" data-tpl="${o.id}:2:h">2 across</button><button class="btn xs" data-tpl="${o.id}:3:h">3 across</button><button class="btn xs" data-tpl="${o.id}:4:h">4 across</button><button class="btn xs" data-tpl="${o.id}:2:v">2 stacked</button><button class="btn xs" data-tpl="${o.id}:0:h">None</button></div></div>
          ${o.slices.length ? `<div class="mapbox"><svg data-map="${oi}" viewBox="-${OW * 0.05} -${OH * 0.05} ${OW * 1.1} ${OH * 1.1}" preserveAspectRatio="xMidYMid meet"></svg></div><div class="hint">Drag the corner handles to corner-pin / keystone each slice on this output.</div>` : `<div class="hint">No slices: the whole composition is shown on this output. Add slices to cut the composition up, re-arrange it, keystone it or edge-blend projectors.</div>`}
          ${o.slices.map((sl, si) => { const sb = `${ob}.slices.${si}`; return `<div class="card closed" data-card="${sb}"><header><button class="sw" data-path="${sb}.on" data-toggle></button><b>${esc(sl.name)}</b><button class="btn xs danger" data-delslice="${o.id}:${sl.id}">${I('trash')}</button><svg class="ico chev"><use href="#i-down"/></svg></header><div class="body">
            ${UI.rText('Name', sb + '.name')}<div class="small muted" style="margin:4px 0">Input (area of the composition, 0–1)</div>
            ${UI.rRange('Src X', sb + '.src.x', 0, 1, 0.001, 0)}${UI.rRange('Src Y', sb + '.src.y', 0, 1, 0.001, 0)}${UI.rRange('Src W', sb + '.src.w', 0, 1, 0.001, 1)}${UI.rRange('Src H', sb + '.src.h', 0, 1, 0.001, 1)}
            <div class="small muted" style="margin:4px 0">Output corners (0–1 of output)</div>
            <div class="grid4 small">${['TL', 'TR', 'BR', 'BL'].map((n, k) => `<span class="muted">${n}</span><input type="number" step="0.001" data-corner="${sb}.dst.${k}:0" value="${sl.dst[k][0]}"><input type="number" step="0.001" data-corner="${sb}.dst.${k}:1" value="${sl.dst[k][1]}"><span></span>`).join('')}</div>
            <div class="small muted" style="margin:6px 0 4px">Soft edge / edge blend</div>
            ${UI.rRange('Left', sb + '.soft.l', 0, 0.5, 0.001, 0)}${UI.rRange('Right', sb + '.soft.r', 0, 0.5, 0.001, 0)}${UI.rRange('Top', sb + '.soft.t', 0, 0.5, 0.001, 0)}${UI.rRange('Bottom', sb + '.soft.b', 0, 0.5, 0.001, 0)}${UI.rRange('Gamma', sb + '.gamma', 1, 3, 0.01, 2.2)}
          </div></div>`; }).join('')}
          <button class="btn sm" data-addslice="${o.id}">${I('plus')}Add slice</button></div></div>`;
      });
      h += `<button class="btn sm" data-addout>${I('plus')}Add output</button><div class="hint" style="margin-top:10px">Each output has its own URL (<span class="mono">/output?out=ID</span>) — open it on any computer/screen. “Clean” opens a frameless feed for OBS capture (→ NDI via the DistroAV plugin, or Spout/Syphon via their OBS plugins).</div>`;
      return h;
    },
    after(pane, s) {
      pane.onclick = e => {
        const t = e.target.closest('button'); if (!t) return; const d = t.dataset;
        if (d.open) window.open('/output?out=' + d.open, 'bvj-out-' + d.open, 'width=960,height=600');
        if (d.clean) window.open('/clean?out=' + d.clean, 'bvj-clean-' + d.clean, 'width=960,height=540');
        if (d.delout && confirm('Remove this output?')) UI.cmd({ op: 'removeOutput', id: d.delout });
        if (d.addout != null) UI.cmd({ op: 'addOutput' });
        if (d.addslice) UI.cmd({ op: 'addSlice', output: d.addslice });
        if (d.delslice) { const [o, sl] = d.delslice.split(':'); UI.cmd({ op: 'removeSlice', output: o, slice: sl }); }
        if (d.tpl) { const [o, n, dir] = d.tpl.split(':'); if (+n === 0) { const oi = UI.st().outputs.findIndex(x => x.id === o); BVJ.cmd({ op: 'set', path: `outputs.${oi}.slices`, value: [] }); } else UI.cmd({ op: 'sliceTemplate', output: o, n: +n, dir }); }
      };
      pane.onchange = e => { const c = e.target.dataset.corner; if (c) { const [p, k] = c.split(':'); const cur = BVJ.get(p).slice(); cur[+k] = +e.target.value; BVJ.set(p, cur); } };
      for (const svg of $$('svg[data-map]', pane)) this.bindMap(svg, s);
      this.live(pane, s);
    },
    bindMap(svg) {
      let drag = null;
      svg.addEventListener('pointerdown', e => { const h = e.target.closest('[data-h]'); if (!h) return; drag = h.dataset.h; svg.setPointerCapture(e.pointerId); });
      svg.addEventListener('pointermove', e => {
        if (!drag) return; const s = UI.st(); const oi = +svg.dataset.map; const o = s.outputs[oi]; const OW = o.width || s.comp.width, OH = o.height || s.comp.height;
        const pt = svg.createSVGPoint(); pt.x = e.clientX; pt.y = e.clientY; const p = pt.matrixTransform(svg.getScreenCTM().inverse());
        const [si, k] = drag.split(':').map(Number); const v = [Math.round(p.x / OW * 1000) / 1000, Math.round(p.y / OH * 1000) / 1000];
        BVJ.set(`outputs.${oi}.slices.${si}.dst.${k}`, v); UI.panels.output.live(svg.closest('.pane'), s);
      });
      svg.addEventListener('pointerup', () => { drag = null; });
    },
    live(pane, s) {
      for (const svg of $$('svg[data-map]', pane)) {
        const oi = +svg.dataset.map; const o = s.outputs[oi]; if (!o) continue; const OW = o.width || s.comp.width, OH = o.height || s.comp.height;
        const colors = ['#ff8a1f', '#2fd3c4', '#a678ff', '#ffd23f', '#4f8cff', '#ff4d5e'];
        let h = `<rect x="0" y="0" width="${OW}" height="${OH}" fill="#0b0c0f" stroke="#444" stroke-width="${OW / 300}"/>`;
        o.slices.forEach((sl, si) => { const c = colors[si % colors.length]; const pts = sl.dst.map(([x, y]) => `${x * OW},${y * OH}`).join(' ');
          h += `<polygon points="${pts}" fill="${c}22" stroke="${c}" stroke-width="${OW / 250}" ${sl.on ? '' : 'stroke-dasharray="8 6" opacity=".4"'}/>`;
          const cx = sl.dst.reduce((a, p) => a + p[0], 0) / 4 * OW, cy = sl.dst.reduce((a, p) => a + p[1], 0) / 4 * OH;
          h += `<text x="${cx}" y="${cy}" fill="${c}" font-size="${OH / 12}" text-anchor="middle" dominant-baseline="middle" font-family="Inter,sans-serif">${esc(sl.name)}</text>`;
          sl.dst.forEach(([x, y], k) => { h += `<circle class="h" data-h="${si}:${k}" cx="${x * OW}" cy="${y * OH}" r="${Math.max(OW, OH) / 60}" fill="#fff" stroke="${c}" stroke-width="${OW / 300}"/>`; }); });
        svg.innerHTML = h;
      }
      for (const inp of $$('[data-corner]', pane)) { if (inp === document.activeElement) continue; const [p, k] = inp.dataset.corner.split(':'); const v = BVJ.get(p); if (v) inp.value = v[+k]; }
    },
  };

  /* ================= LED WALLS ================= */
  let ledView = localStorage.bvjLedView || 'content';
  const scrSize = sc => [sc.panelW * sc.cols, sc.panelH * sc.rows];
  const scrOut = sc => { const [w, h] = scrSize(sc); return sc.rotation === 90 || sc.rotation === 270 ? [h, w] : [w, h]; };
  UI.panels.led = {
    sig: s => JSON.stringify([s.led.screens.map(x => [x.id, x.chain]), s.led.test.on, s.led.test.mode, ledView, s.outputs.map(o => o.id)]),
    render(s) {
      const L = s.led, t = L.test; const scr = L.screens;
      const panels = scr.reduce((n, x) => n + x.cols * x.rows, 0);
      let bw = 0, bh = 0; for (const x of scr) { const [w, h] = scrSize(x); bw = Math.max(bw, x.x + w); bh = Math.max(bh, x.y + h); }
      let ow = 0, oh = 0; for (const x of scr) { const [w, h] = scrOut(x); ow = Math.max(ow, x.outX + w); oh = Math.max(oh, x.outY + h); }
      const mismatch = scr.length && (bw > s.comp.width || bh > s.comp.height || bw !== s.comp.width || bh !== s.comp.height);
      let h = `<div class="sec"><button class="btn testbtn ${t.on ? 'on' : ''}" data-ledtest>${t.on ? '● TEST PATTERN ON AIR' : 'Test pattern'}</button>
        <div class="modegrid">${S.LED_TEST_MODES.map(([v, l]) => `<button class="${t.mode === v ? 'on' : ''}" data-tmode="${v}">${l}</button>`).join('')}</div>
        ${t.mode === 'solid' ? `<div class="row wide"><label>Colour</label><div class="ctl">${UI.seg('led.test.color', [['cycle', 'Cycle'], ['red', 'R'], ['green', 'G'], ['blue', 'B'], ['white', 'W'], ['black', 'Off']])}</div></div>` : ''}
        ${t.mode === 'scan' || (t.mode === 'solid' && t.color === 'cycle') ? UI.rRange('Speed', 'led.test.speed', 0.1, 4, 0.01, 1) : ''}
        ${UI.rToggle('Labels', 'led.test.names')}
        <div class="hint">The test pattern replaces the show output (after effects, before output mapping) so every output and slice shows exactly what the LED processor will receive. Turn it off to return to the live show instantly.</div></div>`;
      h += sec('LED wall', `<div class="ledsum"><div><b>${scr.length}</b><span>screens</span></div><div><b>${panels}</b><span>panels</span></div><div><b>${bw}×${bh}</b><span>content px</span></div><div><b>${ow}×${oh}</b><span>output px</span></div></div>
        ${mismatch ? `<div class="warnbox">Composition is ${s.comp.width}×${s.comp.height} but the screens cover ${bw}×${bh}. <button class="btn xs primary" data-led="fit">Fit composition to screens</button></div>` : ''}
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin:8px 0"><button class="btn sm primary" data-led="add">${I('plus')}Add screen</button><button class="btn sm" data-led="fit">Fit comp to screens</button><button class="btn sm" data-led="build">${I('screen')}Build output mapping</button></div>
        <div class="row wide"><label>View</label><div class="ctl"><div class="seg"><button data-ledview="content" class="${ledView === 'content' ? 'on' : ''}">Content (composition)</button><button data-ledview="output" class="${ledView === 'output' ? 'on' : ''}">Output (processor)</button></div></div></div>
        <div class="mapbox"><svg data-ledsvg></svg></div>
        <div class="hint">${ledView === 'content' ? 'Content view: where each screen takes its picture from in the composition. Drag screens to arrange them — they snap to each other’s edges.' : 'Output view: where each screen sits in the video signal sent to the LED processor (e.g. a 1920×1080 raster). Drag, or auto-pack below.'}</div>
        ${ledView === 'output' ? `<div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap"><span class="muted small">Pack into raster width</span><input type="number" id="packW" value="1920" style="width:80px"><button class="btn sm" data-led="pack">Pack</button><button class="btn sm" data-led="same">Same as content</button></div>` : ''}`);
      scr.forEach((x, i) => { const b = `led.screens.${i}`; const [w, hh] = scrSize(x); const pitch = x.panelMmW && x.panelW ? (x.panelMmW / x.panelW).toFixed(2) : '–';
        const preset = S.LED_PRESETS.findIndex(p => p[1] === x.panelW && p[2] === x.panelH && p[3] === x.panelMmW && p[4] === x.panelMmH);
        h += `<div class="card ${scr.length > 2 ? 'closed' : ''}" data-card="${b}"><header><span class="swatch" style="background:${esc(x.color)}"></span><b>${esc(x.name)}</b><span class="muted small">${x.cols}×${x.rows} · ${w}×${hh}px</span>
          <button class="btn xs" data-led="dup" data-id="${x.id}" title="Duplicate">${I('copy')}</button><button class="btn xs danger" data-led="del" data-id="${x.id}">${I('trash')}</button><svg class="ico chev"><use href="#i-down"/></svg></header><div class="body">
          <div class="row wide"><label>Name</label><div class="ctl"><input type="text" data-path="${b}.name"><input type="color" data-path="${b}.color"></div></div>
          <div class="row wide"><label>Panel type</label><div class="ctl"><select data-ledpreset="${i}"><option value="">Custom panel…</option>${S.LED_PRESETS.map((p, k) => `<option value="${k}" ${k === preset ? 'selected' : ''}>${p[0]}</option>`).join('')}</select></div></div>
          <div class="row wide"><label>Panel pixels</label><div class="ctl"><input type="number" min="1" data-path="${b}.panelW" style="width:70px"><span class="muted">×</span><input type="number" min="1" data-path="${b}.panelH" style="width:70px"><span class="muted small">px</span></div></div>
          <div class="row wide"><label>Panel size</label><div class="ctl"><input type="number" min="0" data-path="${b}.panelMmW" style="width:70px"><span class="muted">×</span><input type="number" min="0" data-path="${b}.panelMmH" style="width:70px"><span class="muted small">mm · pitch ${pitch}</span></div></div>
          <div class="row wide"><label>Panels</label><div class="ctl"><input type="number" min="1" max="200" data-path="${b}.cols" style="width:70px"><span class="muted">wide ×</span><input type="number" min="1" max="200" data-path="${b}.rows" style="width:70px"><span class="muted">high</span></div></div>
          <div class="kv"><span>Screen</span><b>${w}×${hh} px · ${((x.panelMmW * x.cols) / 1000).toFixed(2)} × ${((x.panelMmH * x.rows) / 1000).toFixed(2)} m · ${x.cols * x.rows} panels</b></div>
          <div class="row wide"><label>Content X / Y</label><div class="ctl"><input type="number" data-path="${b}.x" style="width:80px"><input type="number" data-path="${b}.y" style="width:80px"></div></div>
          <div class="row wide"><label>Output X / Y</label><div class="ctl"><input type="number" data-path="${b}.outX" style="width:80px"><input type="number" data-path="${b}.outY" style="width:80px"></div></div>
          <div class="row wide"><label>Output rotation</label><div class="ctl">${UI.seg(b + '.rotation', [[0, '0°'], [90, '90°'], [180, '180°'], [270, '270°']], true)}</div></div>
          <div class="row wide"><label>Data chain</label><div class="ctl"><select data-path="${b}.chain" data-rerender><option value="snake-rows">Snake by rows</option><option value="rows">Rows (same direction)</option><option value="snake-cols">Snake by columns</option><option value="cols">Columns (same direction)</option></select>
            <select data-path="${b}.start"><option value="bl">from bottom-left</option><option value="br">from bottom-right</option><option value="tl">from top-left</option><option value="tr">from top-right</option></select></div></div>
          </div></div>`; });
      if (!scr.length) h += `<div class="empty-note">No screens yet. Click <b>Add screen</b>, choose the panel type and how many panels wide × high. Add one screen per LED surface (e.g. the 4 sides of a square truss, a centre wall and IMAG wings).</div>`;
      h += `<div class="hint">Workflow: 1) add screens & panel counts · 2) arrange them in Content view · 3) Fit comp to screens · 4) switch to Output view and arrange/pack them as your processor expects · 5) Build output mapping — creates the “${esc((s.outputs.find(o => o.id === L.output) || { name: 'LED Processor' }).name)}” output with pixel-exact slices · 6) open that output on the processor’s HDMI/DP display with Native 1:1 scaling · 7) use the test pattern to verify panel order and cabling.</div>`;
      return h;
    },
    after(pane, s) {
      pane.onclick = e => { const t = e.target.closest('button'); if (!t) return; const d = t.dataset;
        if (d.ledtest != null) BVJ.cmd({ op: 'set', path: 'led.test.on', value: !UI.st().led.test.on });
        if (d.tmode) BVJ.cmd({ op: 'setMany', values: { 'led.test.mode': d.tmode, 'led.test.on': true } });
        if (d.ledview) { ledView = d.ledview; localStorage.bvjLedView = ledView; UI.renderRight(true); }
        if (d.led === 'add') UI.cmd({ op: 'ledAddScreen' }); if (d.led === 'fit') UI.cmd({ op: 'ledFitComp' });
        if (d.led === 'build') { UI.cmd({ op: 'ledBuildOutput' }); UI.toast('Output mapping built — open it from Output ▸ LED Processor', 'ok'); }
        if (d.led === 'pack') UI.cmd({ op: 'ledPack', maxWidth: +$('#packW').value || 1920 }); if (d.led === 'same') UI.cmd({ op: 'ledSameAsContent' });
        if (d.led === 'dup') UI.cmd({ op: 'ledDuplicate', id: d.id }); if (d.led === 'del' && confirm('Remove this screen?')) UI.cmd({ op: 'ledRemoveScreen', id: d.id });
        if (t.closest('.seg') && t.dataset.path && /rotation|color/.test(t.dataset.path)) setTimeout(() => this.live(pane, UI.st()), 40); };
      pane.onchange = e => { const p = e.target.dataset.ledpreset; if (p != null && e.target.value !== '') { const [, pw, ph, mw, mh] = S.LED_PRESETS[+e.target.value];
        BVJ.cmd({ op: 'setMany', values: { [`led.screens.${p}.panelW`]: pw, [`led.screens.${p}.panelH`]: ph, [`led.screens.${p}.panelMmW`]: mw, [`led.screens.${p}.panelMmH`]: mh } }); }
        setTimeout(() => UI.renderRight(true), 60); };
      const svg = $('[data-ledsvg]', pane); if (svg) this.bindDrag(svg);
      this.live(pane, s);
    },
    bindDrag(svg) {
      let drag = null;
      const pt = e => { const p = svg.createSVGPoint(); p.x = e.clientX; p.y = e.clientY; return p.matrixTransform(svg.getScreenCTM().inverse()); };
      svg.addEventListener('pointerdown', e => { const g = e.target.closest('[data-si]'); if (!g) return; const s = UI.st(); const i = +g.dataset.si; const sc = s.led.screens[i]; const p = pt(e);
        const kx = ledView === 'content' ? 'x' : 'outX', ky = ledView === 'content' ? 'y' : 'outY'; drag = { i, kx, ky, dx: p.x - sc[kx], dy: p.y - sc[ky] }; svg.setPointerCapture(e.pointerId); });
      svg.addEventListener('pointermove', e => {
        if (!drag) return; const s = UI.st(); const sc = s.led.screens[drag.i]; const p = pt(e); const sz = ledView === 'content' ? scrSize : scrOut; const [w, h] = sz(sc);
        let x = Math.max(0, Math.round(p.x - drag.dx)), y = Math.max(0, Math.round(p.y - drag.dy)); const th = Math.max(8, (svg.viewBox.baseVal.width || 1000) / 60);
        if (!e.shiftKey) for (const [j, o] of s.led.screens.entries()) { if (j === drag.i) continue; const [ow, oh] = sz(o); const ox = o[drag.kx], oy = o[drag.ky];
          for (const [a, b] of [[x, ox + ow], [x, ox], [x + w, ox], [x + w, ox + ow]]) if (Math.abs(a - b) < th) { x += b - a; break; }
          for (const [a, b] of [[y, oy + oh], [y, oy], [y + h, oy], [y + h, oy + oh]]) if (Math.abs(a - b) < th) { y += b - a; break; } }
        if (Math.abs(x) < th) x = 0; if (Math.abs(y) < th) y = 0;
        BVJ.set(`led.screens.${drag.i}.${drag.kx}`, Math.max(0, x)); BVJ.set(`led.screens.${drag.i}.${drag.ky}`, Math.max(0, y)); this.live(svg.closest('.pane'), s);
      });
      svg.addEventListener('pointerup', () => { drag = null; UI.renderRight(true); });
    },
    live(pane, s) {
      const svg = $('[data-ledsvg]', pane); if (!svg || !s) return; const scr = s.led.screens; const content = ledView === 'content';
      const sz = content ? scrSize : scrOut; let W = content ? s.comp.width : 0, H = content ? s.comp.height : 0;
      for (const x of scr) { const [w, h] = sz(x); W = Math.max(W, (content ? x.x : x.outX) + w); H = Math.max(H, (content ? x.y : x.outY) + h); }
      if (!content) { W = Math.max(W, 1920); H = Math.max(H, 1080); }
      const pad = Math.max(W, H) * 0.03; svg.setAttribute('viewBox', `${-pad} ${-pad} ${W + pad * 2} ${H + pad * 2}`);
      const sw = Math.max(W, H) / 500;
      let h = `<rect x="0" y="0" width="${content ? s.comp.width : W}" height="${content ? s.comp.height : H}" fill="#0b0b10" stroke="#3a3a48" stroke-width="${sw}" stroke-dasharray="${sw * 4} ${sw * 3}"/>
        <text x="${(content ? s.comp.width : W) - sw * 4}" y="${-pad * 0.3}" fill="#6b6b7a" font-size="${pad * 0.7}" text-anchor="end">${content ? 'Composition ' + s.comp.width + '×' + s.comp.height : 'Output raster'}</text>`;
      scr.forEach((x, i) => {
        const [w, hh] = sz(x); const X = content ? x.x : x.outX, Y = content ? x.y : x.outY; const rotated = !content && (x.rotation === 90 || x.rotation === 270);
        const C = rotated ? x.rows : x.cols, R = rotated ? x.cols : x.rows; const pw = w / C, ph = hh / R;
        h += `<g data-si="${i}" style="cursor:move"><rect x="${X}" y="${Y}" width="${w}" height="${hh}" fill="${x.color}30" stroke="${x.color}" stroke-width="${sw * 2}"/>`;
        for (let c = 1; c < C; c++) h += `<line x1="${X + c * pw}" y1="${Y}" x2="${X + c * pw}" y2="${Y + hh}" stroke="${x.color}" stroke-opacity=".55" stroke-width="${sw * 0.7}"/>`;
        for (let r = 1; r < R; r++) h += `<line x1="${X}" y1="${Y + r * ph}" x2="${X + w}" y2="${Y + r * ph}" stroke="${x.color}" stroke-opacity=".55" stroke-width="${sw * 0.7}"/>`;
        const fs = Math.min(hh * 0.22, w / Math.max(6, x.name.length * 0.7));
        h += `<text x="${X + w / 2}" y="${Y + hh / 2}" fill="#fff" font-size="${fs}" font-weight="700" text-anchor="middle" dominant-baseline="middle" font-family="Inter,sans-serif" style="pointer-events:none">${esc(x.name)}${!content && x.rotation ? ' ↻' + x.rotation + '°' : ''}</text>
          <text x="${X + w / 2}" y="${Y + hh / 2 + fs * 0.9}" fill="#ffffffaa" font-size="${fs * 0.5}" text-anchor="middle" dominant-baseline="middle" style="pointer-events:none">${w}×${hh} @ ${X},${Y}</text></g>`;
      });
      svg.innerHTML = h;
    },
  };

  /* ================= CUES ================= */
  UI.panels.cues = {
    sig: s => JSON.stringify(s.cues.map(q => [q.id, q.type])),
    render(s) {
      let h = `<div class="sec" style="display:flex;gap:8px;align-items:center"><button class="btn go" data-cue="go">GO</button><div style="display:flex;flex-direction:column;gap:4px"><button class="btn sm" data-cue="back">◀ Back</button><button class="btn sm" data-cue="stop">■ Stop</button></div>
        <div style="flex:1;text-align:right"><div class="tlabel">Current</div><div id="cueCur" style="font-weight:600;font-size:13px"></div></div></div>`;
      h += sec('Record', `<div style="display:flex;gap:6px;align-items:center"><button class="btn sm primary" data-cue="rec">${I('rec', 'fill')}Record cue</button><span class="muted small">fade</span><input type="number" id="recFade" value="1" step="0.1" min="0" style="width:60px"><span class="muted small">s</span>
        <button class="btn sm" data-cue="addcol">+ Column cue</button></div><div class="hint">Record captures what's playing on every layer (clip + opacity), the deck and master. GO recalls it with the fade time. Use Follow = Auto + Wait for timed sequences, or set a timecode (HH:MM:SS:FF) to fire from MTC/LTC/internal clock.</div>`);
      if (!s.cues.length) return h + `<div class="empty-note">No cues yet.</div>`;
      h += `<div class="cuelist">`;
      s.cues.forEach((q, i) => { const b = `cues.${i}`;
        h += `<div class="cuerow ${i === s.cueIndex ? 'cur' : ''}" data-qi="${i}">
          <div class="cl1"><span class="cnum">${i + 1}</span><input type="text" data-path="${b}.name" class="cname"><button class="btn sm ${i === s.cueIndex ? 'live' : ''}" data-qgo="${i}">GO</button>
            <button class="btn sm icon" data-qrr="${i}" title="Re-record from what's playing now">${I('rec')}</button><button class="btn sm icon" data-qup="${i}" title="Move up">${I('up')}</button><button class="btn sm icon danger" data-qdel="${i}" title="Delete">${I('trash')}</button></div>
          <div class="cl2"><label>Type<select data-cuetype="${i}">${S.CUE_TYPES.map(t => `<option ${t === q.type ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
            ${q.type === 'column' ? `<label>Col<input type="number" min="1" data-cuecol="${i}" value="${((q.data && q.data.col) | 0) + 1}"></label>` : ''}
            <label>Fade<input type="number" step="0.1" min="0" data-path="${b}.fade"></label>
            <label>Follow<select data-path="${b}.follow"><option value="none">—</option><option value="auto">Auto</option></select></label>
            <label>Wait<input type="number" step="0.1" min="0" data-path="${b}.wait"></label>
            <label>TC<input type="text" data-path="${b}.tc" placeholder="hh:mm:ss:ff" class="mono"></label></div>
          ${q.type === 'commands' ? `<textarea data-cuecmds="${i}" rows="2" placeholder='[{"op":"trigger","layer":0,"clip":2}]'>${esc(JSON.stringify((q.data && q.data.cmds) || []))}</textarea>` : ''}</div>`;
      });
      return h + '</div>';
    },
    after(pane) {
      pane.onclick = e => { const t = e.target.closest('button'); if (!t) return; const d = t.dataset;
        if (d.cue === 'go') UI.cmd({ op: 'cueGo' }); if (d.cue === 'back') UI.cmd({ op: 'cueBack' }); if (d.cue === 'stop') UI.cmd({ op: 'cueStop' });
        if (d.cue === 'rec') UI.cmd({ op: 'cueRecord', fade: +$('#recFade').value || 0 }); if (d.cue === 'addcol') UI.cmd({ op: 'cueAdd', cue: { type: 'column', data: { col: 0 } } });
        if (d.qgo) UI.cmd({ op: 'cueGo', index: +d.qgo }); if (d.qrr) UI.cmd({ op: 'cueRerecord', index: +d.qrr });
        if (d.qup) UI.cmd({ op: 'cueMove', index: +d.qup, dir: -1 }); if (d.qdel && confirm('Delete cue?')) UI.cmd({ op: 'cueDelete', index: +d.qdel }); };
      pane.onchange = e => { const t = e.target;
        if (t.dataset.cuetype) { const i = +t.dataset.cuetype; const ty = t.value; BVJ.cmd({ op: 'setMany', values: { [`cues.${i}.type`]: ty, [`cues.${i}.data`]: ty === 'column' ? { col: 0 } : ty === 'commands' ? { cmds: [] } : (UI.st().cues[i].data && UI.st().cues[i].data.layers ? UI.st().cues[i].data : { layers: [] }) } }); if (ty === 'snapshot') UI.cmd({ op: 'cueRerecord', index: i }); }
        if (t.dataset.cuecol) BVJ.cmd({ op: 'set', path: `cues.${t.dataset.cuecol}.data`, value: { col: Math.max(0, +t.value - 1) } });
        if (t.dataset.cuecmds) { try { BVJ.cmd({ op: 'set', path: `cues.${t.dataset.cuecmds}.data`, value: { cmds: JSON.parse(t.value) } }); UI.toast('Commands saved', 'ok'); } catch { UI.toast('Invalid JSON', 'err'); } } };
      this.live(pane, UI.st());
    },
    live(pane, s) { $$('[data-qi]', pane).forEach(tr => tr.classList.toggle('cur', +tr.dataset.qi === s.cueIndex)); const c = $('#cueCur', pane); if (c) { const q = s.cues[s.cueIndex]; c.textContent = q ? `${s.cueIndex + 1}. ${q.name}` : '— (next: ' + (s.cues[0] ? s.cues[0].name : 'none') + ')'; } },
  };

  /* ================= MODULATORS ================= */
  function modTargets(s) {
    const t = [['comp.master', 'Comp › Master'], ['comp.speed', 'Comp › Speed'], ['comp.crossfader', 'Comp › Crossfader'], ['comp.volume', 'Comp › Volume']];
    const fxT = (base, label) => { for (const f of S.FX) for (const p of f.params) if (!p.type) t.push([`${base}.fx.${f.id}.${p.k}`, `${label} › ${f.name} › ${p.label}`]); };
    fxT('comp', 'Comp');
    s.layers.forEach((l, i) => { const L = `L${i + 1} ${l.name}`;
      t.push([`layers.${i}.opacity`, `${L} › Opacity`], [`layers.${i}.volume`, `${L} › Volume`], [`layers.${i}.transform.x`, `${L} › Position X`], [`layers.${i}.transform.y`, `${L} › Position Y`],
        [`layers.${i}.transform.scale`, `${L} › Scale`], [`layers.${i}.transform.rotation`, `${L} › Rotation`]); fxT(`layers.${i}`, L); });
    return t;
  }
  function modValue(m, s) {
    let v; if (m.src === 'audio') v = Math.min(1, ((UI.audio && UI.audio[m.band]) || 0));
    else { const ph = BVJ.beat(s.comp) / Math.max(0.0625, m.rate || 4); const f = ph - Math.floor(ph); v = m.shape === 'triangle' ? 1 - Math.abs(f * 2 - 1) : m.shape === 'saw' ? f : m.shape === 'square' ? (f < 0.5 ? 1 : 0) : m.shape === 'random' ? 0.5 : 0.5 + 0.5 * Math.sin(f * Math.PI * 2); }
    return v;
  }
  UI.panels.mods = {
    sig: s => JSON.stringify([s.mods.map(m => [m.id, m.src]), s.layers.map(l => l.name)]),
    render(s) {
      const targets = modTargets(s);
      let h = sec('Modulators', `<div class="hint">LFOs and audio bands drive any numeric parameter in real time (beat-synced to the BPM). The modulated value replaces the slider value while the modulator is on. For effect parameters, switch the effect on as well.</div><button class="btn sm primary" data-addmod>${I('plus')}Add modulator</button>`);
      s.mods.forEach((m, i) => { const b = `mods.${i}`;
        h += `<div class="card"><header><button class="sw" data-path="${b}.on" data-toggle></button><b>${esc((targets.find(t => t[0] === m.path) || [0, m.path])[1])}</b><button class="btn xs danger" data-delmod="${m.id}">${I('trash')}</button></header><div class="body">
          <div class="row wide"><label>Target</label><div class="ctl"><select data-path="${b}.path">${targets.map(([v, l]) => `<option value="${esc(v)}">${esc(l)}</option>`).join('')}</select></div></div>
          <div class="row wide"><label>Source</label><div class="ctl">${UI.seg(b + '.src', [['lfo', 'LFO (BPM)'], ['audio', 'Audio']])}</div></div>
          ${m.src === 'audio' ? UI.rSelect('Band', b + '.band', S.AUDIO_BANDS) : UI.rSelect('Shape', b + '.shape', S.MOD_SHAPES) + UI.rSelect('Cycle length', b + '.rate', [[0.25, '1/4 beat'], [0.5, '1/2 beat'], [1, '1 beat'], [2, '2 beats'], [4, '1 bar'], [8, '2 bars'], [16, '4 bars'], [32, '8 bars']], true)}
          <div class="row wide"><label>Range</label><div class="ctl"><input type="number" step="0.01" data-path="${b}.min" style="width:70px"><span class="muted">→</span><input type="number" step="0.01" data-path="${b}.max" style="width:70px"></div></div>
          <div class="meter"><i data-modm="${i}"></i></div></div></div>`; });
      return h;
    },
    after(pane) {
      pane.onclick = e => { if (e.target.closest('[data-addmod]')) UI.cmd({ op: 'addMod', mod: { path: `layers.${UI.sel.layer}.opacity` } }); const d = e.target.closest('[data-delmod]'); if (d) UI.cmd({ op: 'removeMod', id: d.dataset.delmod });
        if (e.target.closest('.seg')) setTimeout(() => UI.renderRight(true), 60); };
      pane.onchange = e => { if (e.target.dataset.path && /\.path$/.test(e.target.dataset.path)) setTimeout(() => UI.renderRight(true), 60); };
      if (!this._t) this._t = setInterval(() => { if (UI.rtab === 'mods') this.live($('#rpane'), UI.st()); }, 50);
    },
    live(pane, s) { $$('[data-modm]', pane).forEach(e => { const m = s.mods[+e.dataset.modm]; if (m) e.style.width = (m.on ? modValue(m, s) : 0) * 100 + '%'; }); },
  };

  /* ================= DMX / PIXELS ================= */
  UI.panels.dmx = {
    sig: s => JSON.stringify([s.comp.dmx.enabled, s.comp.dmx.protocol, s.comp.pixelMap.enabled, s.comp.pixelMap.fixtures.map(f => f.id), s.layers.length]),
    render(s) {
      const d = s.comp.dmx, pm = s.comp.pixelMap; const a0 = Math.max(1, d.address | 0);
      let table = `<table class="tbl"><thead><tr><th>Ch</th><th>Function</th></tr></thead><tbody>${S.DMX_MASTER.map((n, i) => `<tr><td class="mono">${a0 + i}</td><td>${n}</td></tr>`).join('')}`;
      s.layers.forEach((l, li) => S.DMX_LAYER.forEach((n, k) => { table += `<tr><td class="mono">${a0 + 4 + li * 6 + k}</td><td><span class="muted">L${li + 1}</span> ${n}</td></tr>`; }));
      table += '</tbody></table>';
      let h = sec('DMX input (control from a lighting desk)', `${UI.rToggle('Enabled', 'comp.dmx.enabled')}
        <div class="row wide"><label>Protocol</label><div class="ctl">${UI.seg('comp.dmx.protocol', [['artnet', 'Art-Net'], ['sacn', 'sACN (E1.31)']])}</div></div>
        ${UI.rNum('Universe', 'comp.dmx.universe', 1, 0, 32767)}${UI.rNum('Start address', 'comp.dmx.address', 1, 1, 512)}
        <div class="hint">Patch PIXORA as a generic fixture of ${4 + s.layers.length * 6} channels (4 master + 6 per layer). Art-Net universe is the 15-bit port address (0 = 0:0:0); sACN universes start at 1. A channel only takes control when its value changes, so the UI and desk can share control.</div>
        <details><summary class="muted small" style="cursor:pointer">Show personality / channel map</summary>${table}</details>`);
      const totalPx = pm.fixtures.reduce((n, f) => n + f.cols * f.rows, 0);
      h += sec('Pixel-map output (LED pixels over Art-Net / sACN)', `${UI.rToggle('Enabled', 'comp.pixelMap.enabled')}
        <div class="row wide"><label>Protocol</label><div class="ctl">${UI.seg('comp.pixelMap.protocol', [['artnet', 'Art-Net'], ['sacn', 'sACN']])}</div></div>
        ${UI.rText('Destination IP', 'comp.pixelMap.host', '255.255.255.255 = broadcast')}${UI.rRange('Refresh (fps)', 'comp.pixelMap.fps', 1, 60, 1, 40)}
        <div class="kv"><span>Total pixels</span><b>${totalPx}</b></div>
        <div class="mapbox"><svg data-pxmap viewBox="0 0 ${s.comp.width} ${s.comp.height}"></svg></div>
        <div class="hint">Each fixture samples a rectangle of the composition into a cols × rows pixel grid and sends it in wiring order. Data is sampled on the primary output computer's GPU and sent by the server. Pixels continue into the next universe automatically (170 RGB px per universe).</div>`);
      pm.fixtures.forEach((f, i) => { const b = `comp.pixelMap.fixtures.${i}`;
        h += `<div class="card closed" data-card="${b}"><header><b>${esc(f.name)}</b><span class="muted small">${f.cols}×${f.rows} · U${f.universe}/${f.channel}</span><button class="btn xs danger" data-delfix="${f.id}">${I('trash')}</button><svg class="ico chev"><use href="#i-down"/></svg></header><div class="body">
          ${UI.rText('Name', b + '.name')}${UI.rRange('Area X', b + '.x', 0, 1, 0.001, 0)}${UI.rRange('Area Y', b + '.y', 0, 1, 0.001, 0)}${UI.rRange('Area W', b + '.w', 0, 1, 0.001, 1)}${UI.rRange('Area H', b + '.h', 0, 1, 0.001, 1)}
          <div class="row wide"><label>Pixels</label><div class="ctl"><input type="number" data-path="${b}.cols" min="1" max="1024" style="width:70px"><span class="muted">cols ×</span><input type="number" data-path="${b}.rows" min="1" max="1024" style="width:70px"><span class="muted">rows</span></div></div>
          ${UI.rSelect('Wiring order', b + '.order', [['rows', 'Row by row'], ['cols', 'Column by column']])}${UI.rToggle('Snake / zig-zag', b + '.snake')}
          ${UI.rSelect('First pixel', b + '.start', [['tl', 'Top-left'], ['tr', 'Top-right'], ['bl', 'Bottom-left'], ['br', 'Bottom-right']])}
          ${UI.rSelect('Colour order', b + '.rgb', ['RGB', 'GRB', 'BRG', 'RBG', 'GBR', 'BGR', 'RGBW', 'GRBW'])}
          <div class="row wide"><label>Universe / ch</label><div class="ctl"><input type="number" data-path="${b}.universe" min="0" style="width:80px"><input type="number" data-path="${b}.channel" min="1" max="512" style="width:80px"></div></div></div></div>`; });
      return h + `<button class="btn sm" data-addfix>${I('plus')}Add pixel fixture</button>`;
    },
    after(pane) {
      pane.onclick = e => { if (e.target.closest('[data-addfix]')) UI.cmd({ op: 'addFixture' }); const d = e.target.closest('[data-delfix]'); if (d) UI.cmd({ op: 'removeFixture', id: d.dataset.delfix }); };
      this.live(pane, UI.st());
    },
    live(pane, s) {
      const svg = $('[data-pxmap]', pane); if (!svg) return; const W = s.comp.width, H = s.comp.height; const cols = ['#ff8a1f', '#2fd3c4', '#a678ff', '#ffd23f', '#4f8cff'];
      svg.innerHTML = `<rect width="${W}" height="${H}" fill="#0b0c0f"/>` + s.comp.pixelMap.fixtures.map((f, i) => { const c = cols[i % cols.length];
        return `<rect x="${f.x * W}" y="${f.y * H}" width="${f.w * W}" height="${f.h * H}" fill="${c}26" stroke="${c}" stroke-width="${W / 300}"/><text x="${(f.x + f.w / 2) * W}" y="${(f.y + f.h / 2) * H}" fill="${c}" font-size="${Math.min(H / 6, W / 20)}" text-anchor="middle" dominant-baseline="middle">${esc(f.name)}</text>`; }).join('');
    },
  };

  /* ================= MIDI ================= */
  UI.panels.midi = {
    sig: () => JSON.stringify([BVJMidi.ok, BVJMidi.inputs().map(i => i.id), BVJMidi.outputs().map(o => o.id), BVJMidi.bindings.length, BVJMidi.profile, BVJMidi.error]),
    render() {
      const M = BVJMidi;
      if (!M.ok) return sec('MIDI', `<p class="muted">${esc(M.error || 'Connect MIDI controllers (APC Mini, Launchpads, any MIDI device) directly to this browser.')}</p><button class="btn primary" data-midiinit>${I('midi')}Enable MIDI</button>
        <div class="hint">Web MIDI works in Chrome/Edge on <span class="mono">http://localhost</span> or HTTPS. On a remote machine use the browser on the computer the controller is plugged into.</div>`);
      const desc = a => a.type === 'trigger' ? `Trigger L${a.layer + 1} C${a.clip + 1}` : a.type === 'column' ? `Column ${a.col + 1}` : a.type === 'set' ? `Set ${a.path}` : a.type === 'tap' ? 'Tap tempo' : a.type === 'cmd' ? 'Command ' + a.cmd.op : a.type;
      return sec('Devices', `<div class="row wide"><label>Input</label><div class="ctl"><select data-midi="in"><option value="">All inputs</option>${M.inputs().map(i => `<option value="${esc(i.id)}" ${i.id === M.inId ? 'selected' : ''}>${esc(i.name)}</option>`).join('')}</select></div></div>
          <div class="row wide"><label>Output (LEDs)</label><div class="ctl"><select data-midi="out"><option value="">None</option>${M.outputs().map(o => `<option value="${esc(o.id)}" ${o.id === M.outId ? 'selected' : ''}>${esc(o.name)}</option>`).join('')}</select></div></div>
          <div class="row wide"><label>Controller profile</label><div class="ctl"><select data-midi="profile">${S.MIDI_PROFILES.map((p, i) => `<option value="${i}" ${i === M.profile ? 'selected' : ''}>${p}</option>`).join('')}</select></div></div>
          <div class="row wide"><label>LED feedback</label><div class="ctl"><button class="sw ${M.feedback ? 'on' : ''}" data-midifb></button></div></div>
          <div class="row wide"><label>Auto-enable</label><div class="ctl"><button class="sw ${localStorage.bvjMidiAuto === '1' ? 'on' : ''}" data-midiauto></button><span class="muted small">enable MIDI when this page opens</span></div></div>
          <div class="kv"><span>Last message</span><b class="mono" id="midiLast">${esc(M.lastMsg || '—')}</b></div>
          <div class="hint">Profiles auto-map the 8×8 pad grid to layers (bottom row = layer 1) × columns with colour LED feedback (pad colour = clip type: video green, image yellow, generator cyan, web blue, live input red, NDI purple; the playing clip is bright/pulsing): APC Mini mk2 faders 1–8 = layer opacity, fader 9 = master, track buttons = columns, scene buttons = clear layer. Launchpads: top row = columns, right column = clear layer. Learned mappings override the profile.</div>`) +
        sec('MIDI learn', `<button class="btn sm ${document.body.classList.contains('learn') ? 'on' : ''}" data-learn-toggle>${I('midi')}${document.body.classList.contains('learn') ? 'Exit learn mode' : 'Enter learn mode'}</button>
          <div class="hint">In learn mode, mappable controls get a purple outline: click one (a clip, column, fader, button, effect slider…) then press/move the MIDI control.</div>
          ${M.bindings.length ? `<table class="tbl"><thead><tr><th>MIDI</th><th>Action</th><th></th></tr></thead><tbody>${M.bindings.map((b, i) => `<tr><td class="mono">${esc(b.key)}</td><td>${esc(desc(b.action))}</td><td><button class="btn xs danger" data-unbind="${i}">${I('trash')}</button></td></tr>`).join('')}</tbody></table>
            <div style="display:flex;gap:6px;margin-top:6px"><button class="btn sm" data-midiexp>Export</button><button class="btn sm" data-midiimp>Import</button><button class="btn sm danger" data-midiclr>Clear all</button></div>` : '<div class="empty-note">No learned mappings.</div>'}`);
    },
    after(pane) {
      const M = BVJMidi;
      pane.onclick = async e => { const t = e.target.closest('button'); if (!t) return; const d = t.dataset;
        if (d.midiinit != null) { await M.init(); UI.renderRight(true); }
        if (d.midifb != null) { M.feedback = !M.feedback; M.save(); M.refreshLeds(); t.classList.toggle('on', M.feedback); }
        if (d.midiauto != null) { localStorage.bvjMidiAuto = localStorage.bvjMidiAuto === '1' ? '0' : '1'; t.classList.toggle('on', localStorage.bvjMidiAuto === '1'); }
        if (d.learnToggle != null) { $('#learnBtn').click(); UI.renderRight(true); }
        if (d.unbind) { M.bindings.splice(+d.unbind, 1); M.save(); UI.renderRight(true); UI.markLearned(); }
        if (d.midiclr != null && confirm('Clear all MIDI mappings?')) { M.bindings = []; M.save(); UI.renderRight(true); }
        if (d.midiexp != null) { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(M.bindings, null, 1)], { type: 'application/json' })); a.download = 'pixora-midi-map.json'; a.click(); }
        if (d.midiimp != null) { const i = document.createElement('input'); i.type = 'file'; i.accept = '.json'; i.onchange = async () => { try { M.bindings = JSON.parse(await i.files[0].text()); M.save(); UI.renderRight(true); } catch { UI.toast('Invalid file', 'err'); } }; i.click(); } };
      pane.onchange = e => { const k = e.target.dataset.midi; if (!k) return; if (k === 'in') { M.inId = e.target.value; M.save(); } if (k === 'out') M.setOut(e.target.value); if (k === 'profile') M.setProfile(e.target.value); };
    },
    live(pane) { const l = $('#midiLast', pane); if (l) l.textContent = BVJMidi.lastMsg || '—'; },
  };

  /* ================= TIMECODE ================= */
  let ltcDevs = null;
  UI.panels.tc = {
    sig: s => JSON.stringify([s.comp.timecode.source, BVJMidi.ok, BVJMidi.tc.ltcOn, ltcDevs && ltcDevs.length]),
    render(s) {
      const src = s.comp.timecode.source; const M = BVJMidi;
      let h = `<div class="sec"><div class="tcbig" id="tcBig">--:--:--:--</div><div class="muted small" style="text-align:center;margin-top:4px" id="tcSrc"></div></div>`;
      h += sec('Source', `<div class="row wide"><label>Timecode</label><div class="ctl"><select data-path="comp.timecode.source" data-rerender><option value="off">Off</option><option value="mtc">MTC (MIDI)</option><option value="ltc">LTC (audio input)</option><option value="artnet">Art-Net timecode (from a console)</option><option value="internal">Internal clock</option><option value="tcnet">DJ deck (PRO DJ LINK Bridge / TCNet)</option></select></div></div>
        ${UI.rSelect('Frame rate', 'comp.timecode.fps', [[24, '24'], [25, '25'], [30, '30']], true)}${UI.rNum('Offset (s)', 'comp.timecode.offset', 0.01)}`);
      h += sec('Art-Net timecode out', `${UI.rToggle('Send Art-Net timecode', 'comp.timecode.artnetOut')}<div class="row wide"><label>Send to</label><div class="ctl"><input type="text" data-path="comp.timecode.artnetDest" placeholder="255.255.255.255 (broadcast)"></div></div><div class="hint">Broadcasts PIXORA's clock (internal clock, or the timecode it's chasing) as Art-Net OpTimeCode at the frame rate above. Lighting desks set to Art-Net timecode in can follow PIXORA.</div>`);
      if (src === 'artnet') h += sec('Art-Net timecode in', `<div class="hint" style="margin-top:0">Listening on UDP 6454 for OpTimeCode (e.g. grandMA3 or ChamSys MagicQ timecode out set to Art-Net, or a timecode converter). Cues with a timecode fire as the clock passes them; the Timeline can chase it.</div>`);
      if (src === 'mtc') h += sec('MTC', M.ok ? `<div class="row wide"><label>MIDI input</label><div class="ctl"><select data-mtcin><option value="">Any input</option>${M.inputs().map(i => `<option value="${esc(i.id)}" ${i.id === M.tc.mtcIn ? 'selected' : ''}>${esc(i.name)}</option>`).join('')}</select></div></div><div class="hint">Send MTC from your DAW, grandMA3, or show-control system to a MIDI port this browser can see. Keep this controller page open.</div>` : `<button class="btn primary" data-midiinit>Enable MIDI</button>`);
      if (src === 'ltc') h += sec('LTC', `<div class="row wide"><label>Audio input</label><div class="ctl"><select data-ltcdev><option value="">Default input</option>${(ltcDevs || []).map(d => `<option value="${esc(d.deviceId)}" ${d.deviceId === M.tc.ltcDev ? 'selected' : ''}>${esc(d.label || 'Input')}</option>`).join('')}</select><button class="btn sm" data-ltcscan>${I('refresh')}</button></div></div>
        <button class="btn sm ${M.tc.ltcOn ? 'live' : 'primary'}" data-ltc>${M.tc.ltcOn ? 'Stop LTC reader' : 'Start LTC reader'}</button><div class="hint">Feed SMPTE LTC audio into an input on the computer running this controller page. The decoder runs locally in the browser.</div>`);
      if (src === 'internal') h += sec('Internal clock', `<div style="display:flex;gap:6px"><button class="btn sm primary" data-tci="start">▶ Run</button><button class="btn sm" data-tci="stop">■ Stop</button><button class="btn sm" data-tci="reset">⟲ Zero</button>
        <input type="text" id="tcSet" placeholder="00:00:00:00" class="mono" style="width:100px"><button class="btn sm" data-tci="set">Set</button></div>`);
      h += `<div class="hint">Cues with a timecode in the Cues tab fire when the clock passes that time (forward playback, jumps under 2 s).</div>`;
      return h;
    },
    after(pane, s) {
      const M = BVJMidi;
      pane.onclick = async e => { const t = e.target.closest('button'); if (!t) return; const d = t.dataset;
        if (d.midiinit != null) { await M.init(); UI.renderRight(true); }
        if (d.ltcscan != null) { try { (await navigator.mediaDevices.getUserMedia({ audio: true })).getTracks().forEach(x => x.stop()); } catch {} ltcDevs = (await navigator.mediaDevices.enumerateDevices()).filter(x => x.kind === 'audioinput'); UI.renderRight(true); }
        if (d.ltc != null) { if (M.tc.ltcOn) M.ltcStop(); else { try { await M.ltcStart(M.tc.ltcDev); } catch (er) { UI.toast(er.message, 'err'); } } UI.renderRight(true); }
        if (d.tci === 'start') UI.cmd({ op: 'tcStart' }); if (d.tci === 'stop') UI.cmd({ op: 'tcStop' }); if (d.tci === 'reset') UI.cmd({ op: 'tcReset', frames: 0 });
        if (d.tci === 'set') { const m = /^(\d+):(\d+):(\d+)[:;.](\d+)$/.exec($('#tcSet').value.trim()); if (m) { const fps = s.comp.timecode.fps; UI.cmd({ op: 'tcReset', frames: ((+m[1] * 60 + +m[2]) * 60 + +m[3]) * fps + +m[4] }); } } };
      pane.onchange = e => { if (e.target.dataset.mtcin != null) { M.tc.mtcIn = e.target.value; M.save(); } if (e.target.dataset.ltcdev != null) { M.tc.ltcDev = e.target.value; M.save(); } };
      this.live(pane, s);
    },
    live(pane, s) { const b = $('#tcBig', pane); if (!b || !s) return; const tc = UI.tc; b.textContent = tc && tc.frames != null ? UI.fmtTc(tc.frames, tc.fps || s.comp.timecode.fps) : '--:--:--:--';
      const sl = $('#tcSrc', pane); if (sl) sl.textContent = s.comp.timecode.source === 'off' ? 'Timecode off' : (tc && tc.running ? 'running · ' : '') + s.comp.timecode.source.toUpperCase() + ' @ ' + s.comp.timecode.fps + ' fps'; },
  };

  /* ================= LOG ================= */
  let logData = null, logAt = 0;
  UI.panels.log = {
    sig: () => '',
    render() { return `<div class="sec" style="display:flex;gap:6px"><button class="btn sm" data-undo>${I('undo')}Undo</button><button class="btn sm" data-redo>${I('redo')}Redo</button><span class="muted small" id="logCounts" style="margin-left:auto;align-self:center"></span></div><div id="logList"></div>`; },
    after(pane) { pane.onclick = e => { if (e.target.closest('[data-undo]')) UI.cmd({ op: 'undo' }); if (e.target.closest('[data-redo]')) UI.cmd({ op: 'redo' }); }; logAt = 0; this.live(pane); },
    async live(pane) {
      if (Date.now() - logAt < 1500) return; logAt = Date.now();
      try { logData = await UI.api('/api/log'); } catch { return; }
      const l = $('#logList', pane); if (!l) return; $('#logCounts', pane).textContent = `${logData.undo} undo · ${logData.redo} redo steps`;
      l.innerHTML = `<table class="tbl"><tbody>${logData.log.map(x => `<tr><td class="mono muted" style="white-space:nowrap">${new Date(x.at).toLocaleTimeString()}</td><td class="muted">${esc(x.who)}</td><td>${esc(x.summary)}</td></tr>`).join('')}</tbody></table>`;
    },
  };
})();
