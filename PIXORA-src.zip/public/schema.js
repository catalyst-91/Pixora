/* PIXORA shared schema — used by the server (Node) and every browser page. */
(function (root) {
  const RES_PRESETS = [
    ['1920x1080', 'HD 1080p'], ['1280x720', 'HD 720p'], ['3840x2160', '4K UHD'],
    ['2560x1440', 'QHD 1440p'], ['1080x1920', 'Portrait 1080x1920'], ['1024x768', 'XGA 4:3'],
    ['2048x256', 'LED strip 2048x256'], ['512x256', 'LED side 512x256'], ['1024x1024', 'Square 1024'],
    ['512x512', 'Square 512'], ['3840x1080', 'Dual-wide 3840x1080'],
  ];

  const BLENDS = ['normal', 'add', 'screen', 'multiply', 'overlay', 'lighten', 'darken', 'difference', 'subtract', 'luma key'];

  // Effects run in this fixed order inside one shader pass.
  const FX = [
    { id: 'chroma', name: 'Chroma Key', params: [
      { k: 'color', label: 'Key colour', type: 'color', def: '#00ff40' },
      { k: 'tolerance', label: 'Tolerance', min: 0, max: 0.6, step: 0.005, def: 0.16 },
      { k: 'softness', label: 'Edge softness', min: 0, max: 0.4, step: 0.005, def: 0.08 },
      { k: 'spill', label: 'Spill removal', min: 0, max: 1, step: 0.01, def: 0.6 },
      { k: 'choke', label: 'Choke', min: 0, max: 1, step: 0.01, def: 0 },
      { k: 'view', label: 'View', type: 'select', options: ['Result', 'Matte', 'Source'], def: 0 } ] },
    { id: 'lumakey', name: 'Luma Key', params: [
      { k: 'threshold', label: 'Threshold', min: 0, max: 1, step: 0.005, def: 0.15 },
      { k: 'softness', label: 'Softness', min: 0, max: 1, step: 0.005, def: 0.1 },
      { k: 'invert', label: 'Key out', type: 'select', options: ['Dark areas', 'Bright areas'], def: 0 } ] },
    { id: 'color', name: 'Color Adjust', params: [
      { k: 'brightness', label: 'Brightness', min: -1, max: 1, step: 0.01, def: 0 },
      { k: 'contrast', label: 'Contrast', min: 0, max: 3, step: 0.01, def: 1 },
      { k: 'saturation', label: 'Saturation', min: 0, max: 3, step: 0.01, def: 1 },
      { k: 'hue', label: 'Hue Rotate', min: 0, max: 1, step: 0.001, def: 0 } ] },
    { id: 'tint', name: 'Colorize', params: [
      { k: 'color', label: 'Color', type: 'color', def: '#ff2a6d' },
      { k: 'amount', label: 'Amount', min: 0, max: 1, step: 0.01, def: 0.6 } ] },
    { id: 'invert', name: 'Invert', params: [
      { k: 'amount', label: 'Amount', min: 0, max: 1, step: 0.01, def: 1 } ] },
    { id: 'posterize', name: 'Posterize', params: [
      { k: 'levels', label: 'Levels', min: 2, max: 16, step: 1, def: 5 } ] },
    { id: 'pixelate', name: 'Pixelate', params: [
      { k: 'size', label: 'Block px', min: 1, max: 128, step: 1, def: 16 } ] },
    { id: 'mirror', name: 'Mirror', params: [
      { k: 'mode', label: 'Mode', type: 'select', options: ['Horizontal', 'Vertical', 'Quad'], def: 0 } ] },
    { id: 'kaleido', name: 'Kaleidoscope', params: [
      { k: 'segments', label: 'Segments', min: 2, max: 24, step: 1, def: 6 },
      { k: 'spin', label: 'Spin speed', min: -2, max: 2, step: 0.01, def: 0.1 } ] },
    { id: 'wave', name: 'Wave Warp', params: [
      { k: 'amount', label: 'Amount', min: 0, max: 0.2, step: 0.001, def: 0.02 },
      { k: 'freq', label: 'Frequency', min: 1, max: 60, step: 0.5, def: 10 },
      { k: 'speed', label: 'Speed', min: 0, max: 10, step: 0.1, def: 2 } ] },
    { id: 'rgbshift', name: 'RGB Split', params: [
      { k: 'amount', label: 'Amount', min: 0, max: 0.1, step: 0.001, def: 0.01 },
      { k: 'beat', label: 'Pulse on beat', type: 'select', options: ['Off', 'On'], def: 0 } ] },
    { id: 'blur', name: 'Blur', params: [
      { k: 'radius', label: 'Radius px', min: 0, max: 30, step: 0.5, def: 4 } ] },
    { id: 'edge', name: 'Edge Detect', params: [
      { k: 'amount', label: 'Mix', min: 0, max: 1, step: 0.01, def: 1 } ] },
    { id: 'vignette', name: 'Vignette', params: [
      { k: 'amount', label: 'Amount', min: 0, max: 2, step: 0.01, def: 0.8 } ] },
    { id: 'strobe', name: 'Strobe (BPM)', params: [
      { k: 'rate', label: 'Rate', type: 'select', options: ['1/4 beat', '1/2 beat', '1 beat', '2 beats', '4 beats'], def: 2 },
      { k: 'duty', label: 'On time', min: 0.05, max: 0.95, step: 0.01, def: 0.5 } ] },
    // post passes, run after the chain above in this order: ISF effects (imported .fs filters), then LUTs (.cube / .3dl)
    { id: 'isf', name: 'ISF Effect', post: true, params: [
      { k: 'shader', label: 'ISF shader', type: 'isf', def: '' }, { k: 'mix', label: 'Mix', min: 0, max: 1, step: 0.01, def: 1 } ] },
    { id: 'isf2', name: 'ISF Effect 2', post: true, params: [
      { k: 'shader', label: 'ISF shader', type: 'isf', def: '' }, { k: 'mix', label: 'Mix', min: 0, max: 1, step: 0.01, def: 1 } ] },
    { id: 'lut', name: 'LUT', post: true, params: [
      { k: 'lut', label: 'LUT', type: 'lut', def: '' }, { k: 'mix', label: 'Intensity', min: 0, max: 1, step: 0.01, def: 1 },
      { k: 'exposure', label: 'Exposure (stops)', min: -3, max: 3, step: 0.01, def: 0 }, { k: 'contrast', label: 'Contrast', min: 0, max: 2, step: 0.01, def: 1 },
      { k: 'saturation', label: 'Saturation', min: 0, max: 2, step: 0.01, def: 1 }, { k: 'temp', label: 'Temperature', min: -1, max: 1, step: 0.01, def: 0 },
      { k: 'tint', label: 'Tint', min: -1, max: 1, step: 0.01, def: 0 }, { k: 'gain', label: 'Output gain', min: 0, max: 2, step: 0.01, def: 1 } ] },
    { id: 'lut2', name: 'LUT 2', post: true, params: [
      { k: 'lut', label: 'LUT', type: 'lut', def: '' }, { k: 'mix', label: 'Intensity', min: 0, max: 1, step: 0.01, def: 1 },
      { k: 'exposure', label: 'Exposure (stops)', min: -3, max: 3, step: 0.01, def: 0 }, { k: 'contrast', label: 'Contrast', min: 0, max: 2, step: 0.01, def: 1 },
      { k: 'saturation', label: 'Saturation', min: 0, max: 2, step: 0.01, def: 1 }, { k: 'temp', label: 'Temperature', min: -1, max: 1, step: 0.01, def: 0 },
      { k: 'tint', label: 'Tint', min: -1, max: 1, step: 0.01, def: 0 }, { k: 'gain', label: 'Output gain', min: 0, max: 2, step: 0.01, def: 1 } ] },
  ];
  const STROBE_RATES = [0.25, 0.5, 1, 2, 4];

  const GENERATORS = [
    { id: 'solid', name: 'Solid Color', params: [{ k: 'c1', label: 'Color', type: 'color', def: '#ffffff' }] },
    { id: 'gradient', name: 'Gradient', params: [
      { k: 'c1', label: 'Color A', type: 'color', def: '#ff2a6d' }, { k: 'c2', label: 'Color B', type: 'color', def: '#05d9e8' },
      { k: 'angle', label: 'Angle', min: 0, max: 1, step: 0.001, def: 0 }, { k: 'speed', label: 'Spin', min: -2, max: 2, step: 0.01, def: 0.1 } ] },
    { id: 'plasma', name: 'Plasma', params: [
      { k: 'c1', label: 'Color A', type: 'color', def: '#7b2cff' }, { k: 'c2', label: 'Color B', type: 'color', def: '#00ffd0' },
      { k: 'scale', label: 'Scale', min: 0.5, max: 20, step: 0.1, def: 4 }, { k: 'speed', label: 'Speed', min: 0, max: 5, step: 0.01, def: 1 } ] },
    { id: 'bars', name: 'Moving Bars', params: [
      { k: 'c1', label: 'Color', type: 'color', def: '#ffffff' }, { k: 'count', label: 'Count', min: 1, max: 64, step: 1, def: 8 },
      { k: 'speed', label: 'Speed', min: -5, max: 5, step: 0.01, def: 1 }, { k: 'angle', label: 'Angle', min: 0, max: 1, step: 0.001, def: 0 },
      { k: 'width', label: 'Bar width', min: 0.02, max: 0.98, step: 0.01, def: 0.3 } ] },
    { id: 'checker', name: 'Checkerboard', params: [
      { k: 'c1', label: 'Color A', type: 'color', def: '#ffffff' }, { k: 'c2', label: 'Color B', type: 'color', def: '#000000' },
      { k: 'size', label: 'Cell px', min: 4, max: 512, step: 1, def: 64 }, { k: 'speed', label: 'Scroll', min: -5, max: 5, step: 0.01, def: 0 } ] },
    { id: 'rings', name: 'Rings', params: [
      { k: 'c1', label: 'Color', type: 'color', def: '#ff9a00' }, { k: 'count', label: 'Count', min: 1, max: 40, step: 1, def: 10 },
      { k: 'speed', label: 'Speed', min: -5, max: 5, step: 0.01, def: 1 } ] },
    { id: 'noise', name: 'Noise / Static', params: [
      { k: 'c1', label: 'Color', type: 'color', def: '#ffffff' }, { k: 'scale', label: 'Grain px', min: 1, max: 64, step: 1, def: 2 } ] },
    { id: 'beatflash', name: 'Beat Flash', params: [
      { k: 'c1', label: 'Color', type: 'color', def: '#ffffff' }, { k: 'decay', label: 'Decay', min: 1, max: 20, step: 0.1, def: 6 } ] },
    { id: 'testgrid', name: 'Test Pattern', params: [
      { k: 'size', label: 'Grid px', min: 8, max: 512, step: 1, def: 64 } ] },
    { id: 'text', name: 'Text', params: [
      { k: 'text', label: 'Text', type: 'text', def: 'BOOTH PRODUCTIONS' }, { k: 'c1', label: 'Color', type: 'color', def: '#ffffff' },
      { k: 'size', label: 'Size %', min: 2, max: 100, step: 1, def: 20 }, { k: 'font', label: 'Font', type: 'select', options: ['Sans', 'Serif', 'Mono', 'Impact'], def: 0 },
      { k: 'scroll', label: 'Scroll speed', min: -2, max: 2, step: 0.01, def: 0 },
      { k: 'feed', label: 'Live feed URL (txt / CSV / Google Sheet CSV)', type: 'text', def: '' },
      { k: 'cell', label: 'CSV cell (e.g. B2, blank = all)', type: 'text', def: '' },
      { k: 'refresh', label: 'Refresh secs', min: 5, max: 600, step: 1, def: 30 } ] },
    { id: 'scene3d', name: '3D Scene (glTF / GLB)', params: [
      { k: 'model', label: 'Model', type: 'model', def: '' },
      { k: 'camMode', label: 'Camera', type: 'select', options: ['Orbit around the model', 'Camera in the model file', 'Tracked camera (virtual production)'], def: 0 },
      { k: 'spin', label: 'Orbit speed (°/s)', min: -180, max: 180, step: 1, def: 20 }, { k: 'orbit', label: 'Orbit angle', min: -180, max: 180, step: 1, def: 0 },
      { k: 'elev', label: 'Camera height (°)', min: -89, max: 89, step: 1, def: 18 }, { k: 'dist', label: 'Distance', min: 0.5, max: 10, step: 0.01, def: 2.4 },
      { k: 'fov', label: 'Field of view', min: 10, max: 120, step: 1, def: 40 }, { k: 'scale', label: 'Model scale', min: 0.05, max: 10, step: 0.01, def: 1 },
      { k: 'rotate', label: 'Model turn (°)', min: -180, max: 180, step: 1, def: 0 }, { k: 'animSpeed', label: 'Animation speed', min: 0, max: 4, step: 0.01, def: 1 },
      { k: 'bounce', label: 'Beat bounce', min: 0, max: 2, step: 0.01, def: 0 }, { k: 'camIndex', label: 'Model camera #', min: 0, max: 8, step: 1, def: 0 },
      { k: 'light', label: 'Key light', min: 0, max: 4, step: 0.01, def: 1 }, { k: 'lightColor', label: 'Light colour', type: 'color', def: '#ffffff' },
      { k: 'lightAz', label: 'Light direction', min: -180, max: 180, step: 1, def: -45 }, { k: 'lightEl', label: 'Light height', min: -89, max: 89, step: 1, def: 50 },
      { k: 'ambient', label: 'Ambient', min: 0, max: 2, step: 0.01, def: 0.25 }, { k: 'tint', label: 'Tint (white = none)', type: 'color', def: '#ffffff' },
      { k: 'bgOn', label: 'Background', type: 'select', options: ['Transparent', 'Colour'], def: 0 }, { k: 'bg', label: 'Background colour', type: 'color', def: '#000000' } ] },
    { id: 'audience', name: 'Audience (poll · QR · Q&A · wall)', params: [
      { k: 'view', label: 'Show', type: 'select', options: ['Poll results + QR code', 'Poll results', 'QR code + join link', 'Question on screen', 'Social wall'], def: 0 },
      { k: 'c1', label: 'Accent', type: 'color', def: '#ff2fd0' }, { k: 'c2', label: 'Text', type: 'color', def: '#ffffff' }, { k: 'bg', label: 'Panel', type: 'color', def: '#0b0b12' },
      { k: 'size', label: 'Size', min: 0.4, max: 2, step: 0.01, def: 1 } ] },
    { id: 'title', name: 'Title Designer', params: [
      { k: 'tpl', label: 'Template', type: 'select', options: ['Lower third', 'Full-screen title', 'Countdown', 'Clock', 'Ticker bar', 'Corner bug', 'Scoreboard', 'Captions'], def: 0 },
      { k: 'line1', label: 'Line 1  ({{feed.key}} allowed)', type: 'text', def: 'BOOTH PRODUCTIONS' }, { k: 'line2', label: 'Line 2', type: 'text', def: 'Live event production' },
      { k: 'c1', label: 'Accent', type: 'color', def: '#ff2fd0' }, { k: 'c2', label: 'Text', type: 'color', def: '#ffffff' }, { k: 'bg', label: 'Panel', type: 'color', def: '#0b0b12' },
      { k: 'font', label: 'Font', type: 'select', options: ['Sans', 'Serif', 'Mono', 'Impact'], def: 0 }, { k: 'size', label: 'Size', min: 0.3, max: 6, step: 0.01, def: 1 },
      { k: 'pos', label: 'Position', type: 'select', options: ['Bottom left', 'Bottom centre', 'Bottom right', 'Top left', 'Top centre', 'Top right', 'Centre'], def: 0 },
      { k: 'anim', label: 'Animation', type: 'select', options: ['Slide', 'Fade', 'Wipe', 'Pop', 'None'], def: 0 },
      { k: 'inDur', label: 'In (s)', min: 0, max: 5, step: 0.05, def: 0.6 }, { k: 'hold', label: 'Hold (s, 0 = stay)', min: 0, max: 120, step: 0.5, def: 0 },
      { k: 'outDur', label: 'Out (s)', min: 0, max: 5, step: 0.05, def: 0.5 }, { k: 'minutes', label: 'Countdown minutes', min: 0, max: 240, step: 0.5, def: 10 },
      { k: 'until', label: 'Count down to (HH:MM, overrides)', type: 'text', def: '' }, { k: 'speed', label: 'Ticker speed', min: 0.1, max: 4, step: 0.01, def: 1 },
      { k: 'home', label: 'Scoreboard: home team', type: 'text', def: 'HOME' }, { k: 'homeScore', label: 'Scoreboard: home score', type: 'text', def: '0' },
      { k: 'away', label: 'Scoreboard: away team', type: 'text', def: 'AWAY' }, { k: 'awayScore', label: 'Scoreboard: away score', type: 'text', def: '0' },
      { k: 'period', label: 'Scoreboard: period (e.g. Chukka 2)', type: 'text', def: 'Period 1' },
      { k: 'rowMode', label: 'Rows from a data feed', type: 'select', options: ['Off', 'One row at a time', 'All rows joined (ticker)'], def: 0 },
      { k: 'rowsFrom', label: 'Rows: feed and list (e.g. results.records)', type: 'text', def: '' },
      { k: 'rowSecs', label: 'Rows: seconds per row', min: 1, max: 120, step: 0.5, def: 5 },
      { k: 'rowSep', label: 'Rows: separator (ticker)', type: 'text', def: '   •   ' } ] },
    { id: 'logo', name: 'Logo Animator', params: [
      { k: 'src', label: 'Logo image (library)', type: 'image', def: '' },
      { k: 'anim', label: 'Animation', type: 'select', options: ['Reveal', 'Pulse (beat)', 'Float', 'Glitch (beat)', 'Spin', 'Bounce around', 'Neon glow', 'Zoom in'], def: 1 },
      { k: 'size', label: 'Size %', min: 5, max: 150, step: 1, def: 60 }, { k: 'speed', label: 'Speed', min: 0.1, max: 4, step: 0.01, def: 1 },
      { k: 'c1', label: 'Glow colour', type: 'color', def: '#9b3bff' }, { k: 'glow', label: 'Glow', min: 0, max: 1, step: 0.01, def: 0.5 },
      { k: 'bgOn', label: 'Background', type: 'select', options: ['Transparent', 'Solid'], def: 0 }, { k: 'c2', label: 'Background colour', type: 'color', def: '#000000' } ] },
    { id: 'shader', name: 'GLSL / ISF Shader', params: [
      { k: 'shader', label: 'Shader', type: 'shader', def: 'tunnel' },
      { k: 'p1', label: 'Param 1', min: 0, max: 1, step: 0.001, def: 0.5 }, { k: 'p2', label: 'Param 2', min: 0, max: 1, step: 0.001, def: 0.5 },
      { k: 'p3', label: 'Param 3', min: 0, max: 1, step: 0.001, def: 0.5 }, { k: 'p4', label: 'Param 4', min: 0, max: 1, step: 0.001, def: 0.5 } ] },
  ];

  // Built-in Shadertoy-style shaders (users can add their own GLSL or ISF in the Shaders tab).
  const BUILTIN_SHADERS = [
    { id: 'tunnel', name: 'Neon Tunnel', code: `void mainImage(out vec4 o, in vec2 f){
  vec2 p=(f-0.5*iResolution.xy)/iResolution.y; float a=atan(p.y,p.x), r=length(p);
  float t=iTime*(0.5+iParam.x*2.0); float v=0.5+0.5*sin(10.0*(0.3/r+t)+a*floor(3.0+iParam.y*8.0));
  vec3 c=mix(vec3(0.1,0.0,0.4),vec3(0.0,1.0,0.9),v)*smoothstep(0.0,0.4,r)*(1.0+iAudio.y*2.0);
  o=vec4(c,1.0); }` },
    { id: 'starfield', name: 'Starfield', code: `float h(vec2 p){return fract(sin(dot(p,vec2(41.3,289.1)))*45758.5);}
void mainImage(out vec4 o, in vec2 f){
  vec2 uv=(f-0.5*iResolution.xy)/iResolution.y; vec3 c=vec3(0.0);
  for(float i=0.0;i<4.0;i++){ float d=fract(i*0.25+iTime*(0.05+iParam.x*0.3)); float s=mix(20.0,0.5,d);
    vec2 g=uv*s+i*7.0; vec2 id=floor(g); vec2 q=fract(g)-0.5; float n=h(id);
    c+=vec3(smoothstep(0.08*d,0.0,length(q-vec2(n-0.5,fract(n*7.0)-0.5)*0.6)))*d; }
  o=vec4(c,1.0); }` },
    { id: 'waves', name: 'Colour Waves', code: `void mainImage(out vec4 o, in vec2 f){
  vec2 uv=f/iResolution.xy; float t=iTime*(0.2+iParam.x);
  vec3 c=0.5+0.5*cos(t+uv.xyx*(2.0+iParam.y*10.0)+vec3(0,2,4)); c*=0.6+0.8*iAudio.x; o=vec4(c,1.0); }` },
    { id: 'hexgrid', name: 'Hex Pulse', code: `void mainImage(out vec4 o, in vec2 f){
  vec2 uv=f/iResolution.y*(4.0+iParam.x*20.0); vec2 r=vec2(1.0,1.732); vec2 hh=r*0.5;
  vec2 a=mod(uv,r)-hh, b=mod(uv-hh,r)-hh; vec2 g=dot(a,a)<dot(b,b)?a:b; vec2 id=uv-g;
  float pulse=0.5+0.5*sin(length(id)*0.6-iBeat*3.14159);
  float e=smoothstep(0.45,0.4,max(abs(g.x)*0.866+abs(g.y)*0.5,abs(g.y)));
  o=vec4(mix(vec3(0.02),vec3(1.0,0.2+iParam.y*0.8,0.6)*pulse,e),1.0); }` },
  ];

  // Typical LED processor capacities (8-bit, 60 Hz). Always confirm against the manufacturer's manual.
  // Capacities at 60 Hz / 8-bit from manufacturer spec sheets (checked Nov 2026). `src` names the document; `note` flags anything
  // the sheet doesn't state directly. Higher bit depth roughly halves per-port capacity on most 1G systems.
  const LED_PROCESSORS = [
    { id: '', name: 'Not set' },
    { id: 'nova-mctrl660pro', name: 'NovaStar MCTRL660 PRO', ports: 6, perPort: 650000, total: 2300000, maxW: 3840, maxH: 2560, src: 'NovaStar MCTRL660 PRO Specifications V1.3', note: '10/12-bit: 320,000 px per port' },
    { id: 'nova-mctrl4k', name: 'NovaStar MCTRL4K', ports: 16, perPort: 650000, total: 8800000, maxW: 7680, maxH: 7680, src: 'NovaStar MCTRL4K Specifications', note: 'DP/HDMI input; DVI input 8.3 M px; 10/12-bit 320,000 px per port' },
    { id: 'nova-vx4s', name: 'NovaStar VX4S-N', ports: 4, perPort: 650000, total: 2300000, maxW: 3840, maxH: 1920, src: 'NovaStar VX4S-N Specifications V1.0.1', note: 'Per-port figure is NovaStar 1G standard (sheet gives 2.3 M total only)' },
    { id: 'nova-vx1000', name: 'NovaStar VX1000', ports: 10, perPort: 650000, total: 6500000, maxW: 10240, maxH: 8192, src: 'NovaStar VX1000 Specifications', note: 'Per-port figure is NovaStar 1G standard' },
    { id: 'nova-mx40pro', name: 'NovaStar MX40 Pro', ports: 20, perPort: 659722, total: 9000000, maxW: 8192, maxH: 8192, src: 'NovaStar MX40 Pro Specifications V1.4–1.5', note: '10-bit 494,791 px (A8s/A10s Pro), 12-bit 329,861 px per port' },
    { id: 'brompton-s4', name: 'Brompton Tessera S4', ports: 4, perPort: 525000, total: 2100000, maxW: 1920, maxH: 1080, src: 'Brompton processor comparison sheet', note: 'Raster shown is the default canvas; DVI-D input' },
    { id: 'brompton-s8', name: 'Brompton Tessera S8', ports: 8, perPort: 525000, total: 4500000, maxW: 4096, maxH: 2160, src: 'Brompton Tessera S8 Data Sheet (Jan 2021)', note: 'Raster assumed from 4K HDMI 2.0 input' },
    { id: 'brompton-sx40', name: 'Brompton Tessera SX40 (via XD)', ports: 40, perPort: 525000, total: 9000000, maxW: 4096, maxH: 2160, src: 'Brompton Tessera SX40 Data Sheet', note: '4 × 10G XD trunks, each up to ten 1G fixture ports' },
    { id: 'colorlight-x4s', name: 'Colorlight X4s', ports: 4, perPort: 655360, total: 1300000, maxW: 4096, maxH: 2560, src: 'Colorlight X4s specification', note: 'Per-port figure is Colorlight 1G standard' },
    { id: 'colorlight-x8', name: 'Colorlight X8', ports: 8, perPort: 655360, total: 5000000, maxW: 8192, maxH: 4096, src: 'Colorlight X8 Specification V1.0' },
    { id: 'colorlight-x16', name: 'Colorlight X16', ports: 16, perPort: 655360, total: 8880000, maxW: 8192, maxH: 4096, src: 'Colorlight X16 Specification', note: 'HDMI 2.0 card; DVI card 10.4 M px' },
    { id: 'megapixel-helios', name: 'Megapixel HELIOS 8K', ports: 72, perPort: 655360, total: 35389440, maxW: 8192, maxH: 4320, src: 'ROE Visual processor brochure (Mar 2022)', note: '8 × 10G fibre to distributors (72 RJ45); total = 8K raster' },
    { id: 'generic-1g', name: 'Generic 1 Gb port controller', ports: 1, perPort: 650000, total: 650000, maxW: 1920, maxH: 1200, note: 'Typical 1G receiving-card budget' },
  ];
  const ACTIONS = [ // shared action builder for rules, schedule and sponsors
    ['trigger', 'Trigger clip'], ['column', 'Trigger column'], ['clearLayer', 'Clear layer'], ['clearAll', 'Clear all'], ['cueGo', 'Cue GO'], ['cueIndex', 'Go to cue #'],
    ['blackoutOn', 'Blackout on'], ['blackoutOff', 'Blackout off'], ['deck', 'Switch deck'], ['testOn', 'Test pattern on'], ['testOff', 'Test pattern off'],
    ['loadComp', 'Load composition'], ['master', 'Set master'], ['tlPlay', 'Timeline play'], ['tlStop', 'Timeline stop'], ['device', 'Device action (camera, deck, router, switcher)'], ['ma3', 'grandMA3 command'], ['osc', 'Send OSC message'], ['dmx', 'Set DMX channels'], ['overlay', 'Overlay channel on/off'], ['stream', 'Live stream start / stop'], ['timer', 'Timer start / stop / reset'], ['switcher', 'Switcher CUT / AUTO / preview'], ['custom', 'Custom JSON command'], ['macro', 'Run macro'], ['http', 'HTTP request (webhook)'], ['none', 'Do nothing']];
  function actionToCmd(a) {
    a = a || {}; const n = v => Math.max(0, (+v || 1) - 1);
    switch (a.type) {
      case 'trigger': return { op: 'trigger', layer: n(a.layer), clip: n(a.clip) }; case 'column': return { op: 'column', col: n(a.col) };
      case 'clearLayer': return { op: 'clearLayer', layer: n(a.layer) }; case 'clearAll': return { op: 'clearAll' };
      case 'cueGo': return { op: 'cueGo' }; case 'cueIndex': return { op: 'cueGo', index: n(a.index) };
      case 'blackoutOn': return { op: 'blackout', on: true }; case 'blackoutOff': return { op: 'blackout', on: false };
      case 'deck': return { op: 'deckSwitch', deck: n(a.deck) }; case 'testOn': return { op: 'set', path: 'led.test.on', value: true }; case 'testOff': return { op: 'set', path: 'led.test.on', value: false };
      case 'loadComp': return { op: 'loadComp', name: a.name || '' }; case 'master': return { op: 'set', path: 'comp.master', value: Math.max(0, Math.min(1, +a.value || 0)) };
      case 'tlPlay': return { op: 'tlPlay' }; case 'tlStop': return { op: 'tlStop' };
      case 'stream': return { op: 'stream', a: a.mode || 'toggle' };
      case 'ma3': return a.cmd ? { op: 'ma3', cmd: String(a.cmd) } : [];
      case 'macro': return a.macro ? { op: 'macroRun', name: String(a.macro) } : [];
      case 'http': return a.url ? { op: 'http', method: a.method || 'GET', url: String(a.url), body: a.body || '', ctype: a.ctype || '' } : [];
      case 'osc': return a.address ? { op: 'oscSend', host: a.host, port: a.port, address: a.address, args: a.args } : [];
      case 'dmx': return { op: 'dmxSet', protocol: a.protocol, host: a.host, universe: a.universe, channel: a.channel, values: a.values, fade: a.fade };
      case 'overlay': return { op: 'overlay', n: +a.n || 1, a: a.mode || 'toggle' };
      case 'timer': return { op: 'timer', name: a.name || 'Timer', a: a.mode || 'toggle', secs: +a.secs || 0 };
      case 'switcher': return { op: 'switcher', a: a.mode || 'auto', clip: a.clip != null && a.clip !== '' ? +a.clip : undefined };
      case 'device': { let args = {}; try { args = typeof a.args === 'string' ? JSON.parse(a.args || '{}') : (a.args || {}); } catch {} return { op: 'device', device: a.device || '', action: a.action || '', args }; }
      case 'custom': try { return JSON.parse(a.json || '[]'); } catch { return []; }
    }
    return [];
  }

  // LED panel presets: [label, panel px W, panel px H, panel mm W, panel mm H]
  const LED_PRESETS = [
    ['P1.9 500×500 (256×256 px)', 256, 256, 500, 500], ['P2.6 500×500 (192×192 px)', 192, 192, 500, 500], ['P2.6 500×1000 (192×384 px)', 192, 384, 500, 1000],
    ['P2.9 500×500 (168×168 px)', 168, 168, 500, 500], ['P2.9 500×1000 (168×336 px)', 168, 336, 500, 1000], ['P3.9 500×500 (128×128 px)', 128, 128, 500, 500],
    ['P3.9 500×1000 (128×256 px)', 128, 256, 500, 1000], ['P4.8 500×500 (104×104 px)', 104, 104, 500, 500], ['P5.9 500×500 (84×84 px)', 84, 84, 500, 500],
    ['P6.9 500×1000 (72×144 px)', 72, 144, 500, 1000], ['P10 320×160 (32×16 px)', 32, 16, 320, 160]];
  const LED_TEST_MODES = [['panels', 'Panel grid & numbers'], ['chain', 'Data chain / cabling'], ['bars', 'Colour bars'], ['solid', 'Solid colour'],
    ['gradient', 'Gradients'], ['checker', 'Pixel checker'], ['scan', 'Scan lines'], ['black', 'Black']];
  const SCREEN_COLORS = ['#ff2fd0', '#00d0ff', '#9b3bff', '#ffb020', '#2fe08a', '#ff4d5e', '#4f8cff', '#ffe14d'];
  function screenDefaults(n) {
    return { id: 'scr' + Math.random().toString(36).slice(2, 7), name: 'Screen ' + (n || 1), panelW: 128, panelH: 256, panelMmW: 500, panelMmH: 1000,
      cols: 4, rows: 1, x: 0, y: 0, outX: 0, outY: 0, rotation: 0, chain: 'snake-rows', start: 'bl', color: SCREEN_COLORS[((n || 1) - 1) % SCREEN_COLORS.length],
      cal: { brightness: 1, r: 1, g: 1, b: 1, gamma: 1 }, pos3d: { x: 0, y: 2.5, z: 0, ry: 0, rx: 0 } };
  }
  function ledDefaults() { return { screens: [], output: 'led', processor: '', layout3d: 'auto', test: { on: false, mode: 'panels', color: 'cycle', names: true, speed: 1 },
    dayNight: { on: false, points: [['06:00', 1], ['18:30', 0.8], ['21:00', 0.55], ['23:59', 0.45]] } }; }

  const CUE_TYPES = ['snapshot', 'column', 'commands'];
  const MOD_SHAPES = ['sine', 'triangle', 'saw', 'square', 'random'];
  const AUDIO_BANDS = ['level', 'bass', 'mid', 'high'];
  const LAYOUTS = [['full', 'Full screen (reset)'], ['2-side', '2 side-by-side'], ['2-stack', '2 stacked'], ['3-across', '3 across'],
    ['4-grid', '2x2 grid'], ['pip-tr', 'Picture-in-picture top-right'], ['pip-tl', 'PiP top-left'], ['pip-br', 'PiP bottom-right'], ['pip-bl', 'PiP bottom-left']];
  // DMX personality: 4 master channels then 6 per layer (starting at the configured address)
  const DMX_MASTER = ['Master dimmer', 'Crossfader', 'Column trigger (1-64)', 'Global speed (0=UI, 1-255 → 0-2x)'];
  const DMX_LAYER = ['Opacity', 'Clip select (0=clear, 1-N)', 'Speed (0=UI, 1-255 → 0-2x)', 'Hue rotate (0=off)', 'Strobe (0=off, 5 rate bands)', 'Pixelate (0=off)'];
  const MIDI_PROFILES = ['Generic (learn only)', 'Akai APC Mini mk2', 'Novation Launchpad Mini mk3', 'Novation Launchpad X', 'Novation Launchpad Pro mk3'];

  // Every common video container is listed in the library. NATIVE ones usually play straight in the browser;
  // anything else (or a native-container file with an unsupported codec) is converted locally with ffmpeg.
  const NATIVE_EXT = ['mp4', 'm4v', 'webm', 'ogv', 'mov', 'mkv'];
  const VIDEO_EXT = NATIVE_EXT.concat(['avi', 'wmv', 'asf', 'mpg', 'mpeg', 'm2v', 'mpe', 'vob', 'ts', 'mts', 'm2ts', 'flv', 'f4v',
    '3gp', '3g2', 'mxf', 'dv', 'divx', 'xvid', 'rm', 'rmvb', 'ogm', 'hevc', 'h264', 'h265', 'y4m', 'nut', 'gif-video']);
  const IMAGE_EXT = ['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp'];

  function fxDefaults() {
    const o = {};
    for (const f of FX) { o[f.id] = { on: false }; for (const p of f.params) o[f.id][p.k] = p.def; if (f.id === 'isf' || f.id === 'isf2') o[f.id].v = {}; }
    return o;
  }
  function genDefaults(kind) {
    const g = GENERATORS.find(x => x.id === kind) || GENERATORS[0];
    const p = {}; for (const q of g.params) p[q.k] = q.def; if (g.id === 'shader') p.isf = {}; return p;
  }
  function clipDefaults() {
    return { name: 'Clip', type: 'video', src: '', gen: null, speed: 1, loop: 'loop', inPt: 0, outPt: 1,
      fit: 'fill', x: 0, y: 0, scale: 1, rotation: 0, opacity: 1, beatSync: false, beats: 16, djSync: 'off', djOffset: 0, flipX: false, flipY: false,
      fx: null, transition: 'layer', transitionDur: 0.5, size: 0, url: '', interactive: false, device: '', cache: false, auto: null, ndi: '',
      web: { proxy: false, zoom: 1, scroll: 0, refresh: 0, css: '', transparent: false, playlist: '', dwell: 20, loopScroll: true } };
  }
  function audioOutDefaults(id, name) { return { id: id || 'a' + Math.random().toString(36).slice(2, 7), name: name || 'Output', device: '', deviceLabel: '', ch: 1, mono: false, gain: 1, mute: false, delay: 0 }; }
  function layerDefaults(i, cols) {
    return { id: 'L' + Math.random().toString(36).slice(2, 8), name: 'Layer ' + (i + 1), opacity: 1, blend: 'normal',
      bypass: false, solo: false, xfade: 'none', transition: 'fade', transitionDur: 0.5, volume: 1, mute: false, afv: false, audioOut: 'main', stinger: { src: '', cut: 0.5, dur: 1.5 },
      active: null, trig: 0, paused: false, autopilot: 'off', autoWhen: 'end', autoBeats: 16,
      clips: new Array(cols).fill(null), fx: fxDefaults(),
      transform: { x: 0, y: 0, scale: 1, rotation: 0 }, mask: { type: 'none', x: 0, y: 0, w: 1, h: 1, feather: 0, invert: false },
      route: { mode: 'all', screens: [] }, lockedBy: '' };
  }
  function compDefaults() {
    return { name: 'Untitled Composition', width: 1920, height: 1080, bg: '#000000', master: 1, speed: 1, volume: 1, mute: false,
      precision: '8', audioOuts: [audioOutDefaults('main', 'Main')], // audio buses: each layer / clip plays out of one (device + channel pair)
      blackout: false, bpm: 120, beatEpoch: Date.now(), crossfader: 0.5, columns: 8, outputMode: 'fit',
      outputX: 0, outputY: 0, testPattern: false, showStats: false, fx: fxDefaults(), deck: 0,
      dmx: { enabled: false, protocol: 'artnet', universe: 0, address: 1 },
      pixelMap: { enabled: false, protocol: 'artnet', host: '255.255.255.255', fps: 40, fixtures: [] },
      timecode: { source: 'off', fps: 25, offset: 0, drop: true, freewheel: 12, reader: 'browser', ltcDevice: '', mtcInput: '' }, audio: { gain: 1, smoothing: 0.75, device: '', always: false } };
  }
  function newState() {
    const comp = compDefaults();
    return { comp, layers: [0, 1, 2, 3].map(i => layerDefaults(i, comp.columns)), decks: [{ name: 'Deck 1', clips: {} }],
      outputs: [outputDefaults('main', 'Main')], led: ledDefaults(), cues: [], feeds: [], rules: [], schedule: [], genPresets: [],
      rotation: { enabled: false, layer: 0, mode: 'interval', items: [] }, oscOut: { enabled: false, targets: [] },
      timeline: timelineDefaults(), checklist: { expectedOutputs: 1, items: [] },
      react: { enabled: false, onBeat: 'off', everyBeats: 8, layer: 0, onDrop: 'off', autoBpm: false, sensitivity: 0.5 }, cueIndex: -1, mods: [], presets: [], luts: [], shaders: BUILTIN_SHADERS.map(x => Object.assign({}, x)) };
  }
  function timelineDefaults() { return { duration: 120, loop: false, followTc: false, tcStart: 0, tracks: [], lanes: [], events: [], play: { playing: false, pos: 0, startAt: 0 } }; }
  function outputDefaults(id, name) { return { id: id || 'out' + Math.random().toString(36).slice(2, 6), name: name || 'Output', width: 0, height: 0, slices: [], masks: [], test: 'off', alignFrame: 0,
    lut: { on: false, lut: '', mix: 1, exposure: 0, contrast: 1, saturation: 1, temp: 0, tint: 0, gain: 1 },
    color: { space: '709', eotf: 'sdr', paper: 203, peak: 1000, tenBit: false }, // HDR / wide gamut signal for this output
    // dome / 360: output projection (off, fisheye domemaster, equirectangular, perspective camera) from equirect or flat content
    dome: { mode: 'off', input: 'equirect', fov: 180, yaw: 0, pitch: 0, roll: 0, pfov: 90, flatAz: 0, flatEl: 30, flatFov: 90 } }; } // display LUT: calibration / look per output
  // projector mesh warp: (cols+1)×(rows+1) control points in output space, started from the slice's corner pin
  function meshFromCorners(dst, cols, rows) { const [a, b, c, d] = dst || [[0, 0], [1, 0], [1, 1], [0, 1]], pts = [];
    for (let r = 0; r <= rows; r++) for (let k = 0; k <= cols; k++) { const u = k / cols, v = r / rows; pts.push([+(a[0] * (1 - u) * (1 - v) + b[0] * u * (1 - v) + c[0] * u * v + d[0] * (1 - u) * v).toFixed(4), +(a[1] * (1 - u) * (1 - v) + b[1] * u * (1 - v) + c[1] * u * v + d[1] * (1 - u) * v).toFixed(4)]); }
    return pts; }
  function sliceDefaults(n) {
    return { id: 's' + Math.random().toString(36).slice(2, 7), name: 'Slice ' + (n || 1), on: true, src: { x: 0, y: 0, w: 1, h: 1 },
      dst: [[0, 0], [1, 0], [1, 1], [0, 1]], soft: { l: 0, r: 0, t: 0, b: 0 }, gamma: 2.2, black: 0, mesh: { on: false, cols: 3, rows: 3, pts: [] }, cal: { brightness: 1, r: 1, g: 1, b: 1, gamma: 1 } };
  }
  function modDefaults() { return { id: 'm' + Math.random().toString(36).slice(2, 7), on: true, path: 'layers.0.opacity', src: 'lfo', shape: 'sine', rate: 4, band: 'bass', min: 0, max: 1 }; }
  function fixtureDefaults(n) { return { id: 'f' + Math.random().toString(36).slice(2, 7), name: 'Fixture ' + (n || 1), x: 0, y: 0, w: 1, h: 1, cols: 32, rows: 1, order: 'rows', snake: false, start: 'tl', rgb: 'RGB', universe: 0, channel: 1 }; }

  const S = { RES_PRESETS, BLENDS, FX, STROBE_RATES, GENERATORS, VIDEO_EXT, NATIVE_EXT, IMAGE_EXT, BUILTIN_SHADERS, CUE_TYPES, MOD_SHAPES,
    AUDIO_BANDS, LAYOUTS, DMX_MASTER, DMX_LAYER, MIDI_PROFILES, LED_PROCESSORS, ACTIONS, actionToCmd, timelineDefaults, LED_PRESETS, LED_TEST_MODES, SCREEN_COLORS, screenDefaults, ledDefaults,
    fxDefaults, genDefaults, clipDefaults, layerDefaults, compDefaults, audioOutDefaults, newState, outputDefaults, sliceDefaults, modDefaults, fixtureDefaults, meshFromCorners };
  if (typeof module !== 'undefined' && module.exports) module.exports = S; else root.SCHEMA = S;
})(this);
