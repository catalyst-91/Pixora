/* PIXORA — colour LUTs: parse .cube (Resolve / Adobe, 1D or 3D) and .3dl (Autodesk / Lustre / Nuke) files into float RGB tables,
 * and pack 3D tables as a 2D atlas texture (blue slices side by side). Browser (window.PixoraLUT) and Node (server validation, tests). */
(function (root, factory) { if (typeof module === 'object' && module.exports) module.exports = factory(); else root.PixoraLUT = factory(); })(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const MAX3D = 65, MAX1D = 65536;

  function parseCube(text) {
    const lines = String(text || '').split(/\r?\n/); let title = '', size3 = 0, size1 = 0, dmin = [0, 0, 0], dmax = [1, 1, 1], vals = [], range1 = null;
    for (let raw of lines) {
      const l = raw.replace(/#.*$/, '').trim(); if (!l) continue;
      const m = /^([A-Z_0-9]+)\s+(.*)$/.exec(l);
      if (m && /^[A-Z]/.test(m[1])) { const k = m[1], v = m[2].trim();
        if (k === 'TITLE') title = v.replace(/^"|"$/g, '');
        else if (k === 'LUT_3D_SIZE') size3 = parseInt(v, 10);
        else if (k === 'LUT_1D_SIZE') size1 = parseInt(v, 10);
        else if (k === 'DOMAIN_MIN') dmin = v.split(/\s+/).map(Number);
        else if (k === 'DOMAIN_MAX') dmax = v.split(/\s+/).map(Number);
        else if (k === 'LUT_1D_INPUT_RANGE' || k === 'LUT_3D_INPUT_RANGE') { const r = v.split(/\s+/).map(Number); range1 = r; }
        continue; }
      const n = l.split(/\s+/); if (n.length < 3) throw new Error('bad data line: ' + l.slice(0, 40));
      for (let i = 0; i < 3; i++) { const x = parseFloat(n[i]); if (!Number.isFinite(x)) throw new Error('bad number: ' + n[i]); vals.push(x); }
    }
    if (range1 && range1.length === 2) { dmin = [range1[0], range1[0], range1[0]]; dmax = [range1[1], range1[1], range1[1]]; }
    if (dmin.length !== 3 || dmax.length !== 3 || dmin.some((x, i) => !(dmax[i] > x))) throw new Error('bad DOMAIN_MIN / DOMAIN_MAX');
    if (size3) { if (size3 < 2 || size3 > MAX3D) throw new Error(`LUT_3D_SIZE ${size3} out of range (2–${MAX3D})`);
      if (vals.length !== size3 ** 3 * 3) throw new Error(`expected ${size3 ** 3} entries for a ${size3}³ LUT, found ${vals.length / 3}`);
      return { kind: '3d', size: size3, title, dmin, dmax, data: Float32Array.from(vals) }; }
    if (size1) { if (size1 < 2 || size1 > MAX1D) throw new Error('LUT_1D_SIZE out of range');
      if (vals.length !== size1 * 3) throw new Error(`expected ${size1} entries for a 1D LUT, found ${vals.length / 3}`);
      return { kind: '1d', size: size1, title, dmin, dmax, data: Float32Array.from(vals) }; }
    throw new Error('no LUT_3D_SIZE or LUT_1D_SIZE line — not a .cube LUT');
  }

  // .3dl: optional first row of shaper/input values (N ascending ints = mesh size), then N³ rows of integer RGB, blue changing fastest
  function parse3dl(text) {
    const rows = []; let mesh = null;
    for (const raw of String(text || '').split(/\r?\n/)) {
      const l = raw.replace(/#.*$/, '').trim(); if (!l || /^[A-Za-z]/.test(l)) continue; // skip comments and keywords (Mesh, LUT8, gamma…)
      const n = l.split(/\s+/).map(Number); if (n.some(x => !Number.isFinite(x))) throw new Error('bad line: ' + l.slice(0, 40));
      if (n.length > 3 && !mesh && !rows.length) { mesh = n; continue; }
      if (n.length !== 3) throw new Error('expected 3 values per line: ' + l.slice(0, 40)); rows.push(n);
    }
    const size = Math.round(Math.cbrt(rows.length)); if (size < 2 || size > MAX3D || size ** 3 !== rows.length) throw new Error(`${rows.length} entries is not a cube (N³)`);
    if (mesh && mesh.length !== size) throw new Error('input mesh row does not match the table size');
    let mx = 0; for (const r of rows) for (const x of r) if (x > mx) mx = x;
    const scale = mx <= 1.0001 ? 1 : mx <= 1023 ? 1023 : mx <= 4095 ? 4095 : mx <= 16383 ? 16383 : 65535;
    const data = new Float32Array(size ** 3 * 3);
    for (let r = 0; r < size; r++) for (let g = 0; g < size; g++) for (let b = 0; b < size; b++) {
      const src = rows[(r * size + g) * size + b], dst = ((b * size + g) * size + r) * 3; // → red fastest, like .cube
      data[dst] = src[0] / scale; data[dst + 1] = src[1] / scale; data[dst + 2] = src[2] / scale; }
    return { kind: '3d', size, title: '', dmin: [0, 0, 0], dmax: [1, 1, 1], data };
  }

  function parse(text, name) {
    const ext = String(name || '').toLowerCase().split('.').pop();
    if (ext === '3dl') return parse3dl(text);
    if (ext === 'cube') return parseCube(text);
    return /LUT_(3D|1D)_SIZE/.test(text) ? parseCube(text) : parse3dl(text);
  }

  // value at (r, g, b) in 0..1 — trilinear, used by tests and for previews
  function apply(lut, rgb) {
    const c = rgb.map((x, i) => Math.max(0, Math.min(1, (x - lut.dmin[i]) / (lut.dmax[i] - lut.dmin[i])))); const n = lut.size, d = lut.data;
    if (lut.kind === '1d') return c.map((x, ch) => { const p = x * (n - 1), i = Math.floor(p), j = Math.min(n - 1, i + 1), t = p - i; return d[i * 3 + ch] * (1 - t) + d[j * 3 + ch] * t; });
    const p = c.map(x => x * (n - 1)), i0 = p.map(Math.floor), i1 = i0.map(x => Math.min(n - 1, x + 1)), t = p.map((x, k) => x - i0[k]);
    const at = (r, g, b, ch) => d[((b * n + g) * n + r) * 3 + ch], out = [0, 0, 0];
    for (let ch = 0; ch < 3; ch++) { let v = 0;
      for (let k = 0; k < 8; k++) { const R = k & 1 ? i1[0] : i0[0], G = k & 2 ? i1[1] : i0[1], B = k & 4 ? i1[2] : i0[2];
        v += at(R, G, B, ch) * (k & 1 ? t[0] : 1 - t[0]) * (k & 2 ? t[1] : 1 - t[1]) * (k & 4 ? t[2] : 1 - t[2]); }
      out[ch] = v; }
    return out;
  }

  // GPU layout: 3D → (n·n) × n atlas, slice b at x ∈ [b·n, b·n+n), row g, column r; 1D → n × 1. RGBA float values.
  function atlas(lut) {
    const n = lut.size, d = lut.data;
    if (lut.kind === '1d') { const px = new Float32Array(n * 4); for (let i = 0; i < n; i++) { px[i * 4] = d[i * 3]; px[i * 4 + 1] = d[i * 3 + 1]; px[i * 4 + 2] = d[i * 3 + 2]; px[i * 4 + 3] = 1; } return { w: n, h: 1, px }; }
    const w = n * n, h = n, px = new Float32Array(w * h * 4);
    for (let b = 0; b < n; b++) for (let g = 0; g < n; g++) for (let r = 0; r < n; r++) {
      const s = ((b * n + g) * n + r) * 3, o = (g * w + b * n + r) * 4; px[o] = d[s]; px[o + 1] = d[s + 1]; px[o + 2] = d[s + 2]; px[o + 3] = 1; }
    return { w, h, px };
  }
  function toHalf(f) { // float32 → IEEE half bits
    const b = new DataView(new ArrayBuffer(4)); b.setFloat32(0, f); const x = b.getUint32(0);
    const s = (x >>> 16) & 0x8000, e = ((x >>> 23) & 0xff) - 112, m = x & 0x7fffff;
    if (e <= 0) return s; if (e >= 31) return s | 0x7c00; return s | (e << 10) | (m >>> 13);
  }
  function identity(n) { const d = new Float32Array(n ** 3 * 3); for (let b = 0; b < n; b++) for (let g = 0; g < n; g++) for (let r = 0; r < n; r++) { const o = ((b * n + g) * n + r) * 3; d[o] = r / (n - 1); d[o + 1] = g / (n - 1); d[o + 2] = b / (n - 1); } return { kind: '3d', size: n, title: 'Identity', dmin: [0, 0, 0], dmax: [1, 1, 1], data: d }; }
  function toCube(lut) { // write a LUT back out as .cube text (exports, tests)
    const L = [`TITLE "${(lut.title || 'PIXORA').replace(/"/g, '')}"`, lut.kind === '1d' ? `LUT_1D_SIZE ${lut.size}` : `LUT_3D_SIZE ${lut.size}`, `DOMAIN_MIN ${lut.dmin.join(' ')}`, `DOMAIN_MAX ${lut.dmax.join(' ')}`];
    for (let i = 0; i < lut.data.length; i += 3) L.push(`${lut.data[i].toFixed(6)} ${lut.data[i + 1].toFixed(6)} ${lut.data[i + 2].toFixed(6)}`);
    return L.join('\n') + '\n';
  }
  return { parse, parseCube, parse3dl, apply, atlas, toHalf, identity, toCube, MAX3D };
});
