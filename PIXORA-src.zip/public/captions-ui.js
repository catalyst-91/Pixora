/* PIXORA — Live captions panel (controller). Speech recognition runs in this browser (Chrome / Edge Web Speech) and sends
   text to the server, which wraps it and publishes the "captions" data feed for titles: {{captions.text}}. */
(function () {
  const UI = window.UI, $ = UI.$, esc = UI.esc, I = UI.icon;
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const LANGS = [['en-AU', 'English (Australia)'], ['en-US', 'English (US)'], ['en-GB', 'English (UK)'], ['en-NZ', 'English (NZ)'], ['es-ES', 'Spanish'], ['fr-FR', 'French'], ['de-DE', 'German'], ['it-IT', 'Italian'],
    ['pt-BR', 'Portuguese (Brazil)'], ['nl-NL', 'Dutch'], ['ja-JP', 'Japanese'], ['ko-KR', 'Korean'], ['zh-CN', 'Chinese (Mandarin)'], ['hi-IN', 'Hindi'], ['ar-SA', 'Arabic']];
  const rec = { on: false, r: null, err: '', lastPartial: 0, restarts: 0 };
  // second-language captions: Chrome's on-device Translator API (no account or key; the language model downloads once)
  const T2 = [['', 'Off'], ['en', 'English'], ['es', 'Spanish'], ['fr', 'French'], ['de', 'German'], ['it', 'Italian'], ['pt', 'Portuguese'], ['nl', 'Dutch'], ['ja', 'Japanese'], ['ko', 'Korean'], ['zh', 'Chinese'], ['hi', 'Hindi'], ['ar', 'Arabic'], ['vi', 'Vietnamese'], ['th', 'Thai'], ['id', 'Indonesian'], ['tr', 'Turkish'], ['pl', 'Polish'], ['ru', 'Russian']];
  const tr = { key: '', t: null, state: '', pct: 0 };
  async function translator(gesture) {
    const c = UI.st().captions || {}, src = (c.lang || 'en-AU').split('-')[0], dst = c.lang2 || ''; const key = src + '>' + dst;
    if (!dst || dst === src) { tr.key = key; tr.t = null; tr.state = ''; return null; }
    if (tr.key === key && tr.t) return tr.t;
    if (!('Translator' in self)) { tr.state = 'Translation needs Chrome 138 or newer on a desktop computer'; return null; }
    try {
      const av = await Translator.availability({ sourceLanguage: src, targetLanguage: dst });
      if (av === 'unavailable') { tr.state = `Chrome can't translate ${src} → ${dst}`; return null; }
      if (av !== 'available' && !gesture) { tr.state = 'Press Start listening to download the translation model'; return null; }
      tr.state = av === 'available' ? 'ready' : 'downloading…';
      tr.t = await Translator.create({ sourceLanguage: src, targetLanguage: dst, monitor(m) { m.addEventListener('downloadprogress', e => { tr.pct = Math.round(e.loaded * 100); tr.state = `downloading ${tr.pct}%`; const el = document.getElementById('capTr'); if (el) el.textContent = tr.state; }); } });
      tr.key = key; tr.state = 'ready'; return tr.t;
    } catch (e) { tr.state = 'Translation: ' + e.message; tr.t = null; return null; }
  }
  async function sendTranslated(text, final) { const t = await translator(false); if (!t) return; try { const out = await t.translate(text); BVJ.raw({ t: 'caption', text: out, final, lane: 2, src: 'browser-translate' }); } catch (e) { tr.state = 'Translation: ' + e.message; } }

  function start() {
    if (!SR) return UI.toast('Speech recognition needs Chrome or Edge — open this controller there', 'err');
    translator(true).then(refresh);
    const r = new SR(); rec.r = r; rec.on = true; rec.err = ''; rec.restarts = 0;
    r.continuous = true; r.interimResults = true; r.maxAlternatives = 1; r.lang = (UI.st().captions || {}).lang || 'en-AU';
    r.onresult = e => {
      let interim = '';
      for (let i = e.resultIndex; i < e.results.length; i++) { const x = e.results[i], t = x[0].transcript; if (x.isFinal) { BVJ.raw({ t: 'caption', text: t, final: true, src: 'browser' }); sendTranslated(t, true); } else interim += t; }
      const now = Date.now(); if (interim && now - rec.lastPartial > 150) { rec.lastPartial = now; BVJ.raw({ t: 'caption', text: interim, final: false, src: 'browser' }); }
    };
    r.onerror = e => { if (e.error === 'no-speech' || e.error === 'aborted') return; rec.err = e.error === 'not-allowed' ? 'Microphone permission was refused' : e.error === 'network' ? 'The speech service could not be reached (needs internet)' : 'Speech error: ' + e.error;
      if (e.error === 'not-allowed' || e.error === 'service-not-allowed') stop(); UI.toast(rec.err, 'err'); refresh(); };
    r.onend = () => { if (!rec.on) return; if (++rec.restarts > 200) { stop(); return; } try { r.start(); } catch { setTimeout(() => { try { rec.on && r.start(); } catch {} }, 500); } }; // Chrome stops after silence: keep going
    try { r.start(); } catch (e) { rec.on = false; UI.toast(e.message, 'err'); }
    BVJ.raw({ t: 'captionState', on: true, src: 'browser' }); refresh();
  }
  function stop() { rec.on = false; try { rec.r && rec.r.stop(); } catch {} rec.r = null; BVJ.raw({ t: 'captionState', on: false, src: 'browser' }); refresh(); }
  const refresh = () => { if (UI.rtab === 'captions') UI.renderRight(true); };
  const api = body => UI.api('/api/captions', { method: 'POST', body: JSON.stringify(body) });

  function toOverlay(lane2) {
    const s = UI.st(); let n = s.overlays.findIndex(o => o.clip && o.clip.gen && o.clip.gen.kind === 'title' && (o.clip.gen.params.line1 || '') === (lane2 ? '{{captions.text2}}' : '{{captions.text}}'));
    if (n < 0) n = s.overlays.findIndex(o => !o.clip); if (n < 0) n = s.overlays.length - 1;
    const params = Object.assign(S.genDefaults('title'), { tpl: 7, line1: lane2 ? '{{captions.text2}}' : '{{captions.text}}', line2: '', pos: lane2 ? 4 : 0, anim: 1 });
    BVJ.cmd({ op: 'overlay', n: n + 1, a: 'set', clip: { type: 'gen', name: lane2 ? 'Translated captions' : 'Live captions', gen: { kind: 'title', params } } }); BVJ.cmd({ op: 'overlay', n: n + 1, a: 'on' });
    UI.toast(`${lane2 ? 'Translated captions' : 'Captions'} on overlay ${n + 1}`, 'ok');
  }

  UI.panels.captions = {
    sig: s => JSON.stringify([s.captions, rec.on, rec.err, tr.state]),
    render(s) {
      const c = s.captions || {}, v = (BVJ.feeds || {}).captions || {};
      const sec = (t, b) => `<div class="sec"><h4>${t}</h4>${b}</div>`;
      let h = sec('Live captions', `
        <div class="capprev" id="capPrev">${esc(v.text || '') || '<span class="muted">Captions appear here…</span>'}</div>
        <div class="row wide"><label>Microphone</label><div class="ctl">
          ${rec.on ? `<button class="btn sm danger" data-cap="stop">${I('pause')}Stop listening</button><span class="small" style="color:var(--green)">● listening</span>` : `<button class="btn sm primary" data-cap="start" ${SR ? '' : 'disabled'}>${I('play')}Start listening</button>`}</div></div>
        <div class="row wide"><label>Language</label><div class="ctl"><select data-path="captions.lang">${LANGS.map(([k, l]) => `<option value="${k}">${esc(l)}</option>`).join('')}</select></div></div>
        <div class="row wide"><label>Second language</label><div class="ctl"><select data-path="captions.lang2">${T2.map(([k, l]) => `<option value="${k}">${esc(l)}</option>`).join('')}</select><span class="small muted" id="capTr">${esc(c.lang2 ? tr.state || '' : '')}</span></div></div>
        ${c.lang2 ? `<div class="capprev" id="capPrev2" style="color:#ffd76a">${esc(v.text2 || '') || '<span class="muted">Translation appears here…</span>'}</div>` : ''}
        ${SR ? '' : `<div class="hint" style="color:var(--yellow)">This browser has no speech recognition. Open the controller in Chrome or Edge on the computer with the microphone (the desktop app's own window can't do it), or send captions from another captioner (below).</div>`}
        ${rec.err ? `<div class="hint" style="color:var(--red)">${esc(rec.err)}</div>` : ''}
        <div class="ctl" style="flex-wrap:wrap;gap:6px;margin-top:6px"><button class="btn sm" data-cap="overlay">Show on an overlay</button>${c.lang2 ? '<button class="btn sm" data-cap="overlay2">Show translation on an overlay</button><a class="btn sm" href="/api/captions/transcript?fmt=srt&lane=2" download>Translation (.srt)</a>' : ''}<button class="btn sm" data-cap="clear">Clear screen</button>
          <a class="btn sm" href="/api/captions/transcript?fmt=txt" download>Transcript (.txt)</a><a class="btn sm" href="/api/captions/transcript?fmt=srt" download>Subtitles (.srt)</a><button class="btn sm" data-cap="reset">New transcript</button></div>
        <div class="hint">Chrome and Edge send the audio to their own speech service, so this needs internet. Pick the microphone in the browser's site settings (the camera/mic icon in the address bar). Any title can use <span class="mono">{{captions.text}}</span>, <span class="mono">{{captions.line1}}</span>, <span class="mono">{{captions.line2}}</span> or <span class="mono">{{captions.partial}}</span>; the translation is <span class="mono">{{captions.text2}}</span>. Translation runs on this computer in Chrome (the language model downloads the first time).</div>`);
      h += sec('Layout', `${UI.rRange('Lines on screen', 'captions.lines', 1, 4, 1, 2)}${UI.rRange('Characters per line', 'captions.chars', 20, 80, 1, 42)}${UI.rRange('Clear after silence (s)', 'captions.clearAfter', 0, 30, 1, 6)}
        <div class="row wide"><label>Capitals</label><div class="ctl"><button class="sw" data-path="captions.upper" data-toggle></button></div></div>
        <div class="row wide"><label>Mask swear words</label><div class="ctl"><button class="sw" data-path="captions.censor" data-toggle></button></div></div>`);
      h += sec('From another captioner', `<div class="hint">Send text from a CART writer, a dedicated speech-to-text app or a script:</div>
        <div class="mono small" style="white-space:pre-wrap;margin:6px 0">POST ${esc(location.origin)}/api/captions
{"text": "Welcome everyone", "final": true}
OSC /pixora/caption "Welcome everyone"
OSC /pixora/caption/partial "Welc…"   (words in progress)
OSC /pixora/caption/clear
Translations: "lane": 2  ·  OSC /pixora/caption2 "Bienvenidos"</div>`);
      return h;
    },
    after(pane) {
      pane.querySelectorAll('[data-cap]').forEach(b => b.onclick = () => { const a = b.dataset.cap;
        if (a === 'start') start(); else if (a === 'stop') stop(); else if (a === 'overlay') toOverlay(); else if (a === 'overlay2') toOverlay(true);
        else if (a === 'clear') api({ action: 'clear' }); else if (a === 'reset' && confirm('Start a new transcript? The current one is discarded.')) api({ action: 'reset' }).then(() => UI.toast('New transcript', 'ok')); });
    },
  };
  // live preview without re-rendering the panel
  const prev = (BVJ.extraHandlers = BVJ.extraHandlers || {}).feeds;
  BVJ.extraHandlers.feeds = m => { if (prev) try { prev(m); } catch {} const el = document.getElementById('capPrev'); if (el) { const v = (m.values || {}).captions || {}; el.textContent = v.text || ''; } const e2 = document.getElementById('capPrev2'); if (e2) e2.textContent = ((m.values || {}).captions || {}).text2 || ''; };
  const S = window.SCHEMA;
})();
