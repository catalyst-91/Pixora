/* PIXORA WebGL compositor — runs entirely on the local GPU in the browser.
 * Pipeline per layer: source(s) -> layerFBO (transform/fit, crossfade) -> fx pass -> blend onto comp (ping-pong)
 * then composition fx -> final (master, blackout) -> screen.
 */
(function () {
  const S = window.SCHEMA;
  const VS_QUAD = `
attribute vec2 a_pos; uniform vec2 u_res, u_center, u_size, u_flip; uniform float u_rot; varying vec2 v_uv;
void main(){ vec2 p=a_pos*u_size; float c=cos(u_rot), s=sin(u_rot); p=vec2(p.x*c-p.y*s, p.x*s+p.y*c)+u_center;
  gl_Position=vec4(p/u_res*2.0-1.0,0.0,1.0); v_uv=a_pos+0.5; if(u_flip.x>0.5) v_uv.x=1.0-v_uv.x; if(u_flip.y>0.5) v_uv.y=1.0-v_uv.y; }`;
  const VS_FULL = `attribute vec2 a_pos; varying vec2 v_uv; void main(){ v_uv=a_pos+0.5; gl_Position=vec4(a_pos*2.0,0.0,1.0); }`;

  const FS_SRC = `precision highp float; varying vec2 v_uv;
uniform sampler2D u_tex; uniform int u_gen; uniform float u_alpha, u_time, u_beat, u_scroll;
uniform vec3 u_c1, u_c2; uniform vec4 u_p; uniform vec2 u_size;
float hash(vec2 p){ return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }
void main(){
  vec4 col; vec2 uv=v_uv; vec2 px=uv*u_size; float asp=u_size.x/max(u_size.y,1.0);
  if(u_gen<0){ col=texture2D(u_tex, vec2(uv.x+u_scroll, uv.y)); }
  else if(u_gen==0){ col=vec4(u_c1,1.0); }
  else if(u_gen==1){ float a=u_p.x*6.28318+u_time*u_p.y; vec2 d=vec2(cos(a),sin(a)); float t=clamp(dot((uv-0.5)*vec2(asp,1.0),d)/max(asp,1.0)+0.5,0.0,1.0); col=vec4(mix(u_c1,u_c2,t),1.0); }
  else if(u_gen==2){ vec2 q=(uv-0.5)*vec2(asp,1.0)*u_p.x; float t=u_time*u_p.y;
    float v=sin(q.x+t)+sin(q.y*1.3+t*1.1)+sin((q.x+q.y)*0.7+t*0.7)+sin(length(q)*1.5-t*1.3);
    col=vec4(mix(u_c1,u_c2,0.5+0.5*sin(v*1.57)),1.0); }
  else if(u_gen==3){ float a=u_p.w*6.28318; vec2 q=(uv-0.5)*vec2(asp,1.0); float co=dot(q,vec2(cos(a),sin(a)))/max(asp,1.0);
    float f=fract(co*u_p.x-u_time*u_p.y*0.25); float on=step(f,u_p.z); col=vec4(u_c1*on,on); }
  else if(u_gen==4){ vec2 c=floor((px+vec2(u_time*u_p.y*u_p.x,0.0))/u_p.x); float m=mod(c.x+c.y,2.0); col=vec4(mix(u_c1,u_c2,m),1.0); }
  else if(u_gen==5){ float d=length((uv-0.5)*vec2(asp,1.0)); float f=fract(d*u_p.x-u_time*u_p.y*0.5);
    float on=smoothstep(0.0,0.06,f)*smoothstep(0.5,0.44,f); col=vec4(u_c1*on,on); }
  else if(u_gen==6){ float n=hash(floor(px/u_p.x)+floor(u_time*30.0)*vec2(13.1,7.7)); col=vec4(u_c1*n,1.0); }
  else if(u_gen==7){ float a=exp(-fract(u_beat)*u_p.x); col=vec4(u_c1*a,a); }
  else { col=vec4(1.0,0.0,1.0,1.0); }
  float a=col.a*u_alpha; gl_FragColor=vec4(col.rgb*a, a);
}`;

  const FS_FX = `precision highp float; varying vec2 v_uv;
uniform sampler2D u_tex; uniform vec2 u_res; uniform float u_time, u_beat, u_gate;
uniform float u_colOn,u_bri,u_con,u_sat,u_hue; uniform float u_tintOn,u_tintAmt; uniform vec3 u_tintCol;
uniform float u_invOn,u_invAmt, u_posOn,u_posLv, u_pixOn,u_pixSz, u_mirOn,u_mirMode, u_kalOn,u_kalSeg,u_kalSpin;
uniform float u_wavOn,u_wavAmt,u_wavFreq,u_wavSpd, u_rgbOn,u_rgbAmt, u_blurOn,u_blurR, u_edgeOn,u_edgeAmt, u_vigOn,u_vigAmt;
uniform float u_ckOn,u_ckTol,u_ckSoft,u_ckSpill,u_ckChoke,u_ckView; uniform vec3 u_ckCol; uniform float u_lkOn,u_lkTh,u_lkSoft,u_lkInv;
vec4 tap(vec2 uv){ return texture2D(u_tex, clamp(uv,0.0,1.0)); }
vec4 samp(vec2 uv){
  if(u_blurOn<0.5||u_blurR<0.5) return tap(uv);
  vec2 o=u_blurR/u_res; vec4 s=tap(uv)*0.2;
  s+=(tap(uv+vec2(o.x,0.0))+tap(uv-vec2(o.x,0.0))+tap(uv+vec2(0.0,o.y))+tap(uv-vec2(0.0,o.y)))*0.12;
  s+=(tap(uv+o)+tap(uv-o)+tap(uv+vec2(o.x,-o.y))+tap(uv+vec2(-o.x,o.y)))*0.08; return s; }
float lum(vec3 c){ return dot(c,vec3(0.299,0.587,0.114)); }
vec2 cbcr(vec3 c){ return vec2(-0.168736*c.r-0.331264*c.g+0.5*c.b, 0.5*c.r-0.418688*c.g-0.081312*c.b); }
// chroma key matte from the CbCr distance to the key colour; the 4-tap min gives "choke" (shrinks the matte edge)
float ckMatte(vec3 c){ float d=distance(cbcr(c),cbcr(u_ckCol)); return smoothstep(u_ckTol, u_ckTol+max(u_ckSoft,0.0005), d); }
vec3 hueRot(vec3 c,float h){ float a=h*6.28318; vec3 k=vec3(0.57735); float ca=cos(a); return c*ca+cross(k,c)*sin(a)+k*dot(k,c)*(1.0-ca); }
void main(){
  vec2 uv=v_uv; float asp=u_res.x/u_res.y;
  if(u_wavOn>0.5){ uv.x+=sin(uv.y*u_wavFreq+u_time*u_wavSpd)*u_wavAmt; uv.y+=cos(uv.x*u_wavFreq*0.8+u_time*u_wavSpd*1.1)*u_wavAmt*0.5; }
  if(u_mirOn>0.5){ if(u_mirMode<0.5||u_mirMode>1.5) uv.x=uv.x>0.5?1.0-uv.x:uv.x; if(u_mirMode>0.5) uv.y=uv.y>0.5?1.0-uv.y:uv.y; }
  if(u_kalOn>0.5){ vec2 p=(uv-0.5)*vec2(asp,1.0); float r=length(p); float a=atan(p.y,p.x)+u_time*u_kalSpin; float sg=6.28318/u_kalSeg;
    a=mod(a,sg); a=abs(a-sg*0.5); p=vec2(cos(a),sin(a))*r; uv=p/vec2(asp,1.0)+0.5; }
  if(u_pixOn>0.5&&u_pixSz>1.0){ vec2 b=u_pixSz/u_res; uv=(floor(uv/b)+0.5)*b; }
  vec4 c;
  if(u_rgbOn>0.5){ float amt=u_rgbAmt; if(u_rgbOn>1.5) amt*=1.0+3.0*exp(-fract(u_beat)*6.0);
    vec4 r=samp(uv+vec2(amt,0.0)), g=samp(uv), b=samp(uv-vec2(amt,0.0)); c=vec4(r.r,g.g,b.b,max(max(r.a,g.a),b.a)); }
  else c=samp(uv);
  if(u_edgeOn>0.5){ vec2 o=1.0/u_res;
    float tl=lum(tap(uv+vec2(-o.x,o.y)).rgb), t=lum(tap(uv+vec2(0.0,o.y)).rgb), tr=lum(tap(uv+o).rgb);
    float l=lum(tap(uv-vec2(o.x,0.0)).rgb), r=lum(tap(uv+vec2(o.x,0.0)).rgb);
    float bl=lum(tap(uv-o).rgb), bt=lum(tap(uv-vec2(0.0,o.y)).rgb), br=lum(tap(uv+vec2(o.x,-o.y)).rgb);
    float gx=-tl-2.0*l-bl+tr+2.0*r+br, gy=tl+2.0*t+tr-bl-2.0*bt-br; float e=clamp(length(vec2(gx,gy)),0.0,1.0);
    c.rgb=mix(c.rgb, vec3(e)*max(c.a,0.0001), u_edgeAmt); }
  float a=c.a; vec3 col=a>0.0001?c.rgb/a:vec3(0.0);
  if(u_ckOn>0.5){
    float m=ckMatte(col);
    if(u_ckChoke>0.0){ vec2 o=(1.0+u_ckChoke*4.0)/u_res; vec4 n1=tap(uv+vec2(o.x,0.0)), n2=tap(uv-vec2(o.x,0.0)), n3=tap(uv+vec2(0.0,o.y)), n4=tap(uv-vec2(0.0,o.y));
      float mn=min(min(ckMatte(n1.rgb/max(n1.a,0.0001)),ckMatte(n2.rgb/max(n2.a,0.0001))),min(ckMatte(n3.rgb/max(n3.a,0.0001)),ckMatte(n4.rgb/max(n4.a,0.0001)))); m=mix(m,min(m,mn),u_ckChoke); }
    if(u_ckView>1.5){ /* source */ }
    else if(u_ckView>0.5){ col=vec3(m); a=1.0; }
    else { // spill: pull colours that lean towards the key colour back to grey, strongest near the edge
      float d=distance(cbcr(col),cbcr(u_ckCol)); float sp=(1.0-smoothstep(u_ckTol, u_ckTol+u_ckSoft+0.25, d))*u_ckSpill;
      col=mix(col, vec3(lum(col)), sp); a*=m; }
  }
  if(u_lkOn>0.5){ float l=lum(col); float m=smoothstep(u_lkTh-u_lkSoft*0.5, u_lkTh+u_lkSoft*0.5+0.0005, l); if(u_lkInv>0.5) m=1.0-m; a*=m; }
  if(u_colOn>0.5){ col+=u_bri; col=(col-0.5)*u_con+0.5; col=mix(vec3(lum(col)),col,u_sat); if(u_hue>0.0) col=hueRot(col,u_hue); }
  if(u_tintOn>0.5){ col=mix(col, lum(col)*u_tintCol*1.6, u_tintAmt); }
  if(u_invOn>0.5){ col=mix(col,1.0-col,u_invAmt); }
  if(u_posOn>0.5){ col=floor(clamp(col,0.0,1.0)*u_posLv)/(u_posLv-1.0); }
  if(u_vigOn>0.5){ vec2 d=(v_uv-0.5)*vec2(asp,1.0)/max(asp,1.0); col*=clamp(1.0-u_vigAmt*dot(d,d)*2.0,0.0,1.0); }
  col=clamp(col,0.0,1.0); a*=u_gate; gl_FragColor=vec4(col*a,a);
}`;

  const FS_COMP = `precision highp float; varying vec2 v_uv;
uniform sampler2D u_base, u_top, u_matte; uniform int u_mode, u_mask, u_scrN; uniform float u_op, u_feather, u_inv; uniform vec4 u_mrect; uniform vec2 u_res; uniform vec4 u_scr[8];
void main(){
  vec3 b=texture2D(u_base,v_uv).rgb; vec4 t=texture2D(u_top,v_uv); float a=t.a; vec3 s=a>0.0001?t.rgb/a:vec3(0.0); vec3 r;
  if(u_mask>0){ float m=1.0; float fe=max(u_feather,0.0001);
    if(u_mask==1){ vec2 d=min(v_uv-u_mrect.xy, u_mrect.zw-v_uv); m=clamp(min(d.x*u_res.x/u_res.y,d.y)/fe,0.0,1.0); if(u_feather<=0.0) m=step(0.0,min(d.x,d.y)); }
    else if(u_mask==2){ vec2 c=(u_mrect.xy+u_mrect.zw)*0.5, h=(u_mrect.zw-u_mrect.xy)*0.5; float e=length((v_uv-c)/max(h,vec2(0.0001))); m=clamp((1.0-e)/fe,0.0,1.0); if(u_feather<=0.0) m=step(e,1.0); }
    else if(u_mask==3){ vec4 mt=texture2D(u_matte,v_uv); m=dot(mt.rgb,vec3(0.299,0.587,0.114)); }
    else if(u_mask==4){ m=texture2D(u_matte,v_uv).a; }
    if(u_inv>0.5) m=1.0-m; a*=m; }
  if(u_scrN>0){ float inside=0.0; for(int i=0;i<8;i++){ if(i>=u_scrN) break; vec4 r=u_scr[i]; if(v_uv.x>=r.x&&v_uv.x<r.z&&v_uv.y>=r.y&&v_uv.y<r.w) inside=1.0; } a*=inside; }
  if(u_mode==1) r=b+s; else if(u_mode==2) r=1.0-(1.0-b)*(1.0-s); else if(u_mode==3) r=b*s;
  else if(u_mode==4) r=mix(2.0*b*s, 1.0-2.0*(1.0-b)*(1.0-s), step(0.5,b));
  else if(u_mode==5) r=max(b,s); else if(u_mode==6) r=min(b,s); else if(u_mode==7) r=abs(b-s); else if(u_mode==8) r=max(b-s,0.0);
  else if(u_mode==9){ a*=smoothstep(0.05,0.3,dot(s,vec3(0.299,0.587,0.114))); r=s; }
  else r=s;
  gl_FragColor=vec4(clamp(mix(b,r,a*u_op),0.0,1.0),1.0);
}`;

  // HDR / wide-gamut output: the composition (BT.1886 / Rec.709, display-referred; above 1.0 in the 16-bit pipeline) → Rec.2020 and PQ or HLG
  const FS_HDR = `precision highp float; varying vec2 v_uv; uniform sampler2D u_tex; uniform float u_wide; uniform float u_eotf; uniform float u_paper; uniform float u_peak;
    void main(){ vec4 c = texture2D(u_tex, v_uv); vec3 lin = pow(max(c.rgb, 0.0), vec3(2.4));
      if (u_wide > 0.5) lin = mat3(0.6274, 0.0691, 0.0164, 0.3293, 0.9195, 0.0880, 0.0433, 0.0114, 0.8956) * lin;
      vec3 e;
      if (u_eotf < 0.5) e = pow(clamp(lin, 0.0, 1.0), vec3(1.0 / 2.4));
      else if (u_eotf < 1.5) { vec3 Y = clamp(lin * u_paper, 0.0, u_peak) / 10000.0; vec3 p = pow(Y, vec3(0.1593017578125)); e = pow((0.8359375 + 18.8515625 * p) / (1.0 + 18.6875 * p), vec3(78.84375)); }
      else { vec3 L = clamp(lin * 0.2627 * (u_paper / 203.0), 0.0, 1.0); vec3 lo = sqrt(3.0 * L), hi = 0.17883277 * log(max(12.0 * L - 0.28466892, 1e-6)) + 0.55991073; e = mix(lo, hi, step(1.0 / 12.0, L)); }
      gl_FragColor = vec4(e, c.a); }`;
  // 10-bit SDI: pack the output picture as v210 (4:2:2 Y'CbCr, limited range) on the GPU; each RGBA8 texel is one little-endian 32-bit word
  const FS_V210 = `precision highp float; uniform sampler2D u_tex; uniform vec2 u_src; uniform float u_m2020;
    vec3 ycc(float px, float row) { vec3 c = clamp(texture2D(u_tex, vec2((min(px, u_src.x - 1.0) + 0.5) / u_src.x, 1.0 - row / u_src.y)).rgb, 0.0, 1.0);
      float kr = u_m2020 > 0.5 ? 0.2627 : 0.2126, kb = u_m2020 > 0.5 ? 0.0593 : 0.0722; float y = kr * c.r + (1.0 - kr - kb) * c.g + kb * c.b;
      return vec3(64.0 + 876.0 * y, 512.0 + 896.0 * (c.b - y) / (2.0 * (1.0 - kb)), 512.0 + 896.0 * (c.r - y) / (2.0 * (1.0 - kr))); }
    vec2 chroma(float px, float row) { return (ycc(px, row).yz + ycc(px + 1.0, row).yz) * 0.5; }
    void main(){ float wi = floor(gl_FragCoord.x), row = gl_FragCoord.y, g = floor(wi / 4.0), k = wi - g * 4.0, b0 = g * 6.0; vec3 v;
      if (k < 0.5) { vec2 c = chroma(b0, row); v = vec3(c.x, ycc(b0, row).x, c.y); }
      else if (k < 1.5) { v = vec3(ycc(b0 + 1.0, row).x, chroma(b0 + 2.0, row).x, ycc(b0 + 2.0, row).x); }
      else if (k < 2.5) { v = vec3(chroma(b0 + 2.0, row).y, ycc(b0 + 3.0, row).x, chroma(b0 + 4.0, row).x); }
      else { v = vec3(ycc(b0 + 4.0, row).x, chroma(b0 + 4.0, row).y, ycc(b0 + 5.0, row).x); }
      v = floor(clamp(v + 0.5, 4.0, 1019.0)); float a = v.x, b = v.y, c = v.z;
      float B0 = mod(a, 256.0), B1 = floor(a / 256.0) + mod(b, 64.0) * 4.0, B2 = floor(b / 64.0) + mod(c, 16.0) * 16.0, B3 = floor(c / 16.0);
      gl_FragColor = vec4(B0, B1, B2, B3) / 255.0; }`;
  // AI background removal: the person mask (from PixoraSeg) cuts the source out, blurs or replaces what's behind
  const FS_BGR = `precision highp float; varying vec2 v_uv; uniform sampler2D u_tex; uniform sampler2D u_mask; uniform float u_mode; uniform float u_thr; uniform float u_soft; uniform float u_blur; uniform vec3 u_col; uniform vec2 u_px; uniform float u_inv;
    void main(){ float raw = texture2D(u_mask, v_uv).r; if (u_inv > 0.5) raw = 1.0 - raw; float m = smoothstep(u_thr - u_soft, u_thr + u_soft + 1e-4, raw); vec4 c = texture2D(u_tex, v_uv);
      if (u_mode < 0.5) { gl_FragColor = vec4(c.rgb * m, m); return; }
      vec3 bg; if (u_mode < 1.5) { bg = vec3(0.0); float n = 0.0; for (int i = -3; i <= 3; i++) for (int j = -3; j <= 3; j++) { bg += texture2D(u_tex, v_uv + vec2(float(i), float(j)) * u_px * u_blur).rgb; n += 1.0; } bg /= n; } else bg = u_col;
      gl_FragColor = vec4(mix(bg, c.rgb, m), 1.0); }`;
  const FS_FINAL = `precision highp float; varying vec2 v_uv; uniform sampler2D u_tex; uniform float u_master;
void main(){ gl_FragColor=vec4(texture2D(u_tex,v_uv).rgb*u_master,1.0); }`;
  // copy with alpha + optional source sub-rect (used for clip fx, mattes, previews, pixel sampling)
  const FS_MIX = `precision highp float; varying vec2 v_uv; uniform sampler2D u_a, u_b; uniform float u_mix;
void main(){ vec4 a=texture2D(u_a,v_uv), b=clamp(texture2D(u_b,v_uv),0.0,1.0); gl_FragColor=mix(a,b,u_mix); }`;
  // colour LUT: pre adjustments (exposure, white balance, contrast, saturation) → 1D or 3D LUT (atlas, trilinear) → intensity → gain
  const FS_LUT = `precision highp float; varying vec2 v_uv; uniform sampler2D u_tex, u_lut; uniform float u_n, u_is1d, u_mix, u_exp, u_con, u_sat, u_temp, u_tint, u_gain; uniform vec3 u_dmin, u_dmax;
vec3 at3(float r, float g, float b){ float n=u_n; return texture2D(u_lut, vec2((b*n + r + 0.5)/(n*n), (g + 0.5)/n)).rgb; }
vec3 lut(vec3 c){ c=clamp((c-u_dmin)/(u_dmax-u_dmin),0.0,1.0); float n=u_n;
  if(u_is1d>0.5){ vec3 p=(c*(n-1.0)+0.5)/n; return vec3(texture2D(u_lut,vec2(p.r,0.5)).r, texture2D(u_lut,vec2(p.g,0.5)).g, texture2D(u_lut,vec2(p.b,0.5)).b); }
  vec3 p=c*(n-1.0); float b0=floor(p.b), b1=min(b0+1.0,n-1.0), t=p.b-b0;
  // red/green interpolate in hardware inside a slice; blue between the two neighbouring slices
  vec2 rg=p.rg; vec3 a=texture2D(u_lut, vec2((b0*n + rg.x + 0.5)/(n*n), (rg.y + 0.5)/n)).rgb, z=texture2D(u_lut, vec2((b1*n + rg.x + 0.5)/(n*n), (rg.y + 0.5)/n)).rgb;
  return mix(a,z,t); }
void main(){ vec4 s=texture2D(u_tex,v_uv); float al=s.a; vec3 c=al>0.0001? s.rgb/al : vec3(0.0);
  c*=exp2(u_exp); c*=vec3(1.0+0.25*u_temp, 1.0-0.25*u_tint, 1.0-0.25*u_temp);
  c=(c-0.5)*u_con+0.5; float y=dot(c,vec3(0.2126,0.7152,0.0722)); c=mix(vec3(y),c,u_sat); c=clamp(c,0.0,1.0);
  vec3 o=mix(c, lut(c), u_mix)*u_gain; gl_FragColor=vec4(clamp(o,0.0,1.0)*al, al); }`;
  // dome / 360 output: per output pixel → view direction (fisheye domemaster, equirect, perspective) → rotate → sample equirect or a flat window on the sphere
  const FS_DOME = `precision highp float; varying vec2 v_uv; uniform sampler2D u_tex; uniform int u_mode, u_in; uniform float u_fov, u_pfov, u_aspect, u_tanH, u_tanV; uniform mat3 u_rot, u_frot;
const float PI=3.14159265358979;
void main(){ vec3 d; vec2 uv=v_uv;
  if(u_mode==0){ vec2 p=uv*2.0-1.0; if(u_aspect>1.0) p.x*=u_aspect; else p.y/=u_aspect; float r=length(p); if(r>1.0){ gl_FragColor=vec4(0.0,0.0,0.0,1.0); return; }
    float th=r*radians(u_fov)*0.5, ph=atan(p.y,p.x); d=vec3(sin(th)*cos(ph), cos(th), sin(th)*sin(ph)); }
  else if(u_mode==1){ float lon=(uv.x-0.5)*2.0*PI, lat=(uv.y-0.5)*PI; d=vec3(cos(lat)*sin(lon), sin(lat), -cos(lat)*cos(lon)); }
  else { float t=tan(radians(u_pfov)*0.5); d=normalize(vec3((uv.x*2.0-1.0)*t*u_aspect, (uv.y*2.0-1.0)*t, -1.0)); }
  d=u_rot*d; vec2 s;
  if(u_in==0){ s=vec2(atan(d.x,-d.z)/(2.0*PI)+0.5, asin(clamp(d.y,-1.0,1.0))/PI+0.5); }
  else { vec3 l=u_frot*d; if(l.z>=-0.0001){ gl_FragColor=vec4(0.0,0.0,0.0,1.0); return; } s=vec2(l.x/(-l.z)/u_tanH*0.5+0.5, l.y/(-l.z)/u_tanV*0.5+0.5);
    if(s.x<0.0||s.x>1.0||s.y<0.0||s.y>1.0){ gl_FragColor=vec4(0.0,0.0,0.0,1.0); return; } }
  gl_FragColor=vec4(texture2D(u_tex,s).rgb,1.0); }`;
  const FS_BLIT = `precision highp float; varying vec2 v_uv; uniform sampler2D u_tex; uniform float u_alpha; uniform vec4 u_rect;
void main(){ gl_FragColor=texture2D(u_tex,u_rect.xy+v_uv*u_rect.zw)*u_alpha; }`;
  // output mapping: inverse homography (corner pin / keystone) + soft-edge blending per slice
  const MAP_HEAD = `precision highp float; uniform sampler2D u_tex; uniform vec2 u_out; uniform vec4 u_src, u_soft; uniform float u_gamma, u_bri, u_cgam, u_black; uniform vec3 u_gain;
vec4 sliceColor(vec2 uv){
  vec2 s=vec2(u_src.x+uv.x*u_src.z, u_src.y+uv.y*u_src.w); vec3 c=texture2D(u_tex, vec2(s.x,1.0-s.y)).rgb;
  float f=1.0; if(u_soft.x>0.0) f*=clamp(uv.x/u_soft.x,0.0,1.0); if(u_soft.y>0.0) f*=clamp((1.0-uv.x)/u_soft.y,0.0,1.0);
  if(u_soft.z>0.0) f*=clamp(uv.y/u_soft.z,0.0,1.0); if(u_soft.w>0.0) f*=clamp((1.0-uv.y)/u_soft.w,0.0,1.0);
  c=pow(max(c,vec3(0.0)),vec3(u_cgam))*u_gain*u_bri;
  // black-level compensation: lift black outside the blend zones so it matches the doubled projector black in the overlaps
  float lift=u_black*step(0.999,f); c=c+lift*(1.0-c);
  return vec4(clamp(c,0.0,1.0)*pow(f,1.0/max(u_gamma,0.1)),1.0); }`;
  const FS_MAP = MAP_HEAD + `uniform mat3 u_hinv;
void main(){ vec2 p=vec2(gl_FragCoord.x/u_out.x, 1.0-gl_FragCoord.y/u_out.y); vec3 q=u_hinv*vec3(p,1.0); vec2 uv=q.xy/q.z;
  if(uv.x<0.0||uv.y<0.0||uv.x>1.0||uv.y>1.0) discard; gl_FragColor=sliceColor(uv); }`;
  // mesh warp: triangles in output space (y down, 0..1) carrying the slice's own 0..1 coordinates
  const VS_MESH = `attribute vec2 a_pos; attribute vec2 a_uv; varying vec2 v_uv; void main(){ v_uv=a_uv; gl_Position=vec4(a_pos.x*2.0-1.0, 1.0-a_pos.y*2.0, 0.0, 1.0); }`;
  const FS_MESH = MAP_HEAD + `varying vec2 v_uv; void main(){ gl_FragColor=sliceColor(clamp(v_uv,0.0,1.0)); }`;
  // full-output overlay from a 2D canvas (masks multiply, test patterns replace)
  const FS_OVER = `precision mediump float; uniform sampler2D u_tex; uniform vec2 u_out; void main(){ vec2 p=vec2(gl_FragCoord.x/u_out.x, 1.0-gl_FragCoord.y/u_out.y); gl_FragColor=texture2D(u_tex, vec2(p.x,1.0-p.y)); }`;
  const VS_MAP = `attribute vec2 a_pos; void main(){ gl_Position=vec4(a_pos*2.0,0.0,1.0); }`;
  const SHADER_HEAD = `precision highp float; varying vec2 v_uv; uniform vec3 iResolution; uniform float iTime, iBeat, u_alpha; uniform vec4 iAudio, iParam, iMouse;
#define iGlobalTime iTime
`;

  const GEN_INDEX = { solid: 0, gradient: 1, plasma: 2, bars: 3, checker: 4, rings: 5, noise: 6, beatflash: 7 };
  const CANVAS_GENS = { text: 1, testgrid: 1, audience: 1 };
  // Audience overlay: poll results, the join QR code, the question on screen, the social wall — from the "audience" data feed
  function drawAudience(ctx, W, H, p, A) {
    const k = Math.min(W / 1920, H / 1080) * (+p.size || 1), acc = p.c1 || '#ff2fd0', fg = p.c2 || '#ffffff', bg = p.bg || '#0b0b12', F = 'Inter, Helvetica, Arial, sans-serif';
    const panel = (x, y, w, h) => { ctx.save(); ctx.globalAlpha = 0.88; ctx.fillStyle = bg; const r = 18 * k; ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.fill(); ctx.restore(); };
    const wrap = (text, maxW, size, weight, maxLines) => { ctx.font = `${weight || 600} ${size}px ${F}`; const words = String(text || '').split(' '), lines = []; let cur = '';
      for (const w of words) { const t = cur ? cur + ' ' + w : w; if (ctx.measureText(t).width > maxW && cur) { lines.push(cur); cur = w; } else cur = t; } if (cur) lines.push(cur);
      if (lines.length > maxLines) { lines.length = maxLines; lines[maxLines - 1] = lines[maxLines - 1].replace(/\s*\S*$/, '') + '…'; } return lines; };
    const text = (lines, x, y, size, color, lh, align) => { ctx.fillStyle = color; ctx.textAlign = align || 'left'; ctx.textBaseline = 'top'; lines.forEach((l, i) => ctx.fillText(l, x, y + i * size * (lh || 1.2))); return y + lines.length * size * (lh || 1.2); };
    const view = p.view | 0; if (!A) { ctx.fillStyle = fg; ctx.font = `600 ${28 * k}px ${F}`; ctx.textAlign = 'center'; ctx.fillText('Audience: waiting for data…', W / 2, H / 2); return; }
    const qrBox = (x, y, s) => { panel(x, y, s, s + 74 * k); if (window.PixoraQR && A.url) try { PixoraQR.draw(ctx, A.url, x + 14 * k, y + 14 * k, s - 28 * k, '#000', '#fff'); } catch {}
      ctx.font = `600 ${20 * k}px ${F}`; text(wrap(A.title || 'Join in', s - 24 * k, 22 * k, 700, 1), x + s / 2, y + s + 6 * k, 22 * k, fg, 1.2, 'center');
      text([A.url.replace(/^https?:\/\//, '').replace(/\?k=.*$/, '')], x + s / 2, y + s + 38 * k, 16 * k, fg + 'aa', 1.2, 'center'); };
    const poll = (x, y, w) => { const P = A.poll || {}; if (!P.question) return; const opts = P.options || [], qL = wrap(P.question, w - 60 * k, 40 * k, 700, 3), rowH = 64 * k;
      const h = 40 * k + qL.length * 48 * k + opts.length * (rowH + 12 * k) + 50 * k; panel(x, y, w, h); let yy = text(qL, x + 30 * k, y + 28 * k, 40 * k, fg) + 16 * k;
      const max = Math.max(1, ...opts.map(o => o.votes));
      for (const o of opts) { ctx.fillStyle = '#ffffff14'; ctx.fillRect(x + 30 * k, yy, w - 60 * k, rowH); ctx.fillStyle = acc; ctx.fillRect(x + 30 * k, yy, (w - 60 * k) * (o.votes / max) * (o.pct > 0 ? 1 : 0), rowH);
        ctx.font = `600 ${28 * k}px ${F}`; ctx.fillStyle = fg; ctx.textBaseline = 'middle'; ctx.textAlign = 'left'; ctx.fillText(o.text, x + 46 * k, yy + rowH / 2, w - 220 * k);
        ctx.textAlign = 'right'; ctx.font = `800 ${30 * k}px ${F}`; ctx.fillText(o.pct + '%', x + w - 46 * k, yy + rowH / 2); yy += rowH + 12 * k; }
      ctx.textBaseline = 'top'; text([`${P.total} vote${P.total === 1 ? '' : 's'}${P.open ? '' : ' · voting closed'}`], x + 30 * k, yy + 4 * k, 20 * k, fg + 'aa'); };
    const m = 60 * k, qs = 300 * k;
    if (view === 0) { poll(m, m, W - 3 * m - qs); qrBox(W - m - qs, m, qs); }
    else if (view === 1) poll(W * 0.15, H * 0.12, W * 0.7);
    else if (view === 2) qrBox(W - m - qs, H - m - qs - 74 * k, qs);
    else if (view === 3) { const Q = A.qa; if (Q) { const w = W * 0.8, L = wrap(Q.text, w - 100 * k, 54 * k, 700, 5), h = L.length * 66 * k + 140 * k, x = (W - w) / 2, y = H - h - m;
        panel(x, y, w, h); ctx.fillStyle = acc; ctx.fillRect(x, y + 24 * k, 8 * k, h - 48 * k); text(['QUESTION'], x + 50 * k, y + 30 * k, 22 * k, acc); const yy = text(L, x + 50 * k, y + 66 * k, 54 * k, fg);
        if (Q.name) text(['— ' + Q.name], x + 50 * k, yy + 8 * k, 26 * k, fg + 'bb'); } }
    else if (view === 4) { const posts = (A.wall || []).slice(0, 6), n = posts.length, cols = Math.max(1, Math.min(3, n)), rows = n > 3 ? 2 : 1, cw = (W - (cols + 1) * m) / cols;
      const ch = rows === 2 ? (H - 3 * m) / 2 : Math.min(H - 2 * m, cw * 0.62), top = rows === 2 ? m : (H - ch) / 2, fs = (cols === 1 ? 64 : cols === 2 ? 48 : 36) * k; // fewer posts → bigger cards
      posts.forEach((q, i) => { const x = m + (i % cols) * (cw + m), y = top + Math.floor(i / cols) * (ch + m); panel(x, y, cw, ch); if (q.live) { ctx.strokeStyle = acc; ctx.lineWidth = 5 * k; ctx.strokeRect(x + 3 * k, y + 3 * k, cw - 6 * k, ch - 6 * k); }
        const L = wrap(q.text, cw - 60 * k, fs, 600, Math.max(1, Math.floor((ch - 110 * k) / (fs * 1.2)))); text(L, x + 30 * k, y + 30 * k, fs, fg); if (q.name) text(['@' + q.name], x + 30 * k, y + ch - 30 * k - fs * 0.66, fs * 0.66, acc); });
      if (!posts.length) { ctx.fillStyle = fg + 'aa'; ctx.font = `600 ${32 * k}px ${F}`; ctx.textAlign = 'center'; ctx.fillText('Scan the code and post to the wall', W / 2, H / 2); } }
  }
  const OVERLAY_LAYER = { opacity: 1, blend: 'normal', fx: null, mask: null, bypass: false, solo: false, xfade: 'none', paused: false, speed: 1, transform: null };
  const ANIM_GENS = { title: 1, logo: 1 };
  // {{feed.path}} templates resolve against live data feeds (any app can push data into PIXORA)
  function timerText(name) { // shared timers (server-production.js): {{timer.Doors}}
    const st = window.BVJ && BVJ.state, t = st && (st.timers || []).find(x => x.name.toLowerCase() === String(name).toLowerCase()); if (!t) return '';
    const now = BVJ.now ? BVJ.now() : Date.now(), el = t.base + (t.running ? (now - t.startedAt) / 1000 : 0);
    let v; if (t.mode === 'up') v = el; else if (t.mode === 'to' && /^\d{1,2}:\d{2}$/.test(t.until)) { const [hh, mm] = t.until.split(':').map(Number), d = new Date(now), tg = new Date(d); tg.setHours(hh, mm, 0, 0); if (tg < d) tg.setDate(tg.getDate() + 1); v = (tg - d) / 1000; } else v = Math.max(0, t.secs - el);
    const s = Math.max(0, Math.ceil(t.mode === 'up' ? Math.floor(v) : v)), h = Math.floor(s / 3600), m = Math.floor(s / 60) % 60, ss = s % 60;
    return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(ss).padStart(2, '0');
  }
  let ROW = null; // the data row a title is drawing (rows from a feed: one at a time, or joined into a ticker)
  function feedRows(path) { // "results.records" → array of rows (objects, or plain values as { value })
    let v = String(path || '').split('.').filter(Boolean).reduce((a, k) => a == null ? undefined : a[k], (window.BVJ && BVJ.feeds) || {});
    if (v && !Array.isArray(v) && Array.isArray(v.records)) v = v.records; else if (v && !Array.isArray(v) && Array.isArray(v.rows)) v = v.rows;
    return Array.isArray(v) ? v.map(r => r && typeof r === 'object' && !Array.isArray(r) ? r : Array.isArray(r) ? Object.fromEntries(r.map((c, i) => [String.fromCharCode(65 + i), c])) : { value: r }) : [];
  }
  function specialToken(p) {
    if (p === 'clock') return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
    if (p === 'clock12') return new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true });
    if (p === 'time') return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
    if (p === 'date') return new Date().toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'long' });
    if (p.startsWith('timer.')) return timerText(p.slice(6));
    if (p.startsWith('row.')) { const v = ROW ? p.slice(4).split('.').reduce((a, k) => a == null ? undefined : a[k], ROW) : undefined; return v == null ? '' : String(v); } // {{row.Name}} — the current row of a data list
    return null;
  }
  function tpl(str) { if (!str || str.indexOf('{{') < 0) return str; return String(str).replace(/\{\{\s*([\w.:-]+(?: [\w.:-]+)*)\s*\}\}/g, (m, p) => { const sp = specialToken(p); if (sp != null) return sp; const v = String(p).split('.').reduce((a, k) => a == null ? undefined : a[k], (window.BVJ && BVJ.feeds) || {}); return v == null ? '' : (typeof v === 'object' ? JSON.stringify(v) : String(v)); }); }
  function dayNightLevel(dn) {
    if (!dn || !dn.on || !(dn.points || []).length) return 1;
    const d = new Date(); const now = d.getHours() * 60 + d.getMinutes() + d.getSeconds() / 60;
    const pts = dn.points.map(([t, v]) => { const [h, m] = String(t).split(':').map(Number); return [(h || 0) * 60 + (m || 0), +v]; }).sort((a, b) => a[0] - b[0]);
    let prev = pts[pts.length - 1], next = pts[0];
    for (let i = 0; i < pts.length; i++) { if (pts[i][0] > now) { next = pts[i]; prev = pts[i - 1] || pts[pts.length - 1]; break; } if (i === pts.length - 1) { prev = pts[i]; next = pts[0]; } }
    const span = ((next[0] - prev[0]) + 1440) % 1440 || 1440; const k = (((now - prev[0]) + 1440) % 1440) / span;
    return Math.max(0, Math.min(1, prev[1] + (next[1] - prev[1]) * k));
  }
  window.PIXORA_tpl = tpl;
  const BLEND_INDEX = Object.fromEntries(S.BLENDS.map((b, i) => [b, i]));

  class Engine {
    constructor(canvas, hooks) {
      this.canvas = canvas; this.hooks = hooks || {};
      const gl = this.gl = canvas.getContext('webgl2', { alpha: false, antialias: false, premultipliedAlpha: false, preserveDrawingBuffer: false, powerPreference: 'high-performance' })
        || canvas.getContext('webgl', { alpha: false, antialias: false, powerPreference: 'high-performance' });
      if (!gl) throw new Error('WebGL not available');
      this.isGL2 = typeof WebGL2RenderingContext !== 'undefined' && gl instanceof WebGL2RenderingContext;
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
      this.buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, this.buf);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-0.5, -0.5, 0.5, -0.5, -0.5, 0.5, 0.5, 0.5]), gl.STATIC_DRAW);
      this.pSrc = this.prog(VS_QUAD, FS_SRC); this.pFx = this.prog(VS_FULL, FS_FX); this.pMix = this.prog(VS_FULL, FS_MIX); this.pLut = this.prog(VS_FULL, FS_LUT); this.pDome = this.prog(VS_FULL, FS_DOME);
      this.pComp = this.prog(VS_FULL, FS_COMP); this.pFinal = this.prog(VS_FULL, FS_FINAL); this.pHdr = this.prog(VS_FULL, FS_HDR); this.pV210 = this.prog(VS_FULL, FS_V210); this.pBgr = this.prog(VS_FULL, FS_BGR);
      this.pBlit = this.prog(VS_FULL, FS_BLIT); this.pMap = this.prog(VS_MAP, FS_MAP); this.pMesh = this.prog(VS_MESH, FS_MESH); this.pOver = this.prog(VS_MAP, FS_OVER); this.meshBuf = gl.createBuffer(); this.meshCache = new Map();
      this.shaderProgs = new Map(); this.shaderErrors = {}; this.feeds = new Map(); this.audio = { level: 0, bass: 0, mid: 0, high: 0 };
      this.output = null; // {width,height,slices}
      this.W = 0; this.H = 0; this.layers = []; // runtime per layer: {cur, prev, trig, transStart, transDur, endedTrig}
      this.sources = new Map(); this.streams = new Map(); this.canvasTex = new Map();
      this.audioUnlocked = false; this.frames = 0; this.fps = 0; this._fpsT = performance.now();
      this.lastT = performance.now();
    }
    prog(vs, fs) {
      const gl = this.gl, p = gl.createProgram();
      for (const [type, src] of [[gl.VERTEX_SHADER, vs], [gl.FRAGMENT_SHADER, fs]]) {
        const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
        if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) { const log = gl.getShaderInfoLog(s); gl.deleteShader(s); gl.deleteProgram(p); throw new Error(log); }
        gl.attachShader(p, s);
      }
      gl.bindAttribLocation(p, 0, 'a_pos'); gl.bindAttribLocation(p, 1, 'a_uv'); gl.linkProgram(p);
      if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
      p.u = {}; const n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
      for (let i = 0; i < n; i++) { const info = gl.getActiveUniform(p, i); p.u[info.name] = gl.getUniformLocation(p, info.name); }
      return p;
    }
    tex(repeat) {
      const gl = this.gl, t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      const w = repeat && this.isGL2 ? gl.REPEAT : gl.CLAMP_TO_EDGE;
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, w); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([0, 0, 0, 0]));
      return t;
    }
    fbo() { // 8-bit, or half-float when the comp asks for the 16-bit pipeline (more headroom, no banding in gradients and HDR)
      const gl = this.gl, t = this.tex();
      if (this.hiPrec && this.isGL2 && (this._cbf ?? (this._cbf = !!gl.getExtension('EXT_color_buffer_float')))) gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA16F, this.W, this.H, 0, gl.RGBA, gl.HALF_FLOAT, null);
      else gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, this.W, this.H, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
      const f = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, f);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t, 0);
      return { f, t };
    }
    resize(W, H, hi) {
      hi = !!hi; if (W === this.W && H === this.H && hi === !!this.hiPrec) return; this.hiPrec = hi;
      const gl = this.gl; this.W = W; this.H = H; if (!this.customPresent) { this.canvas.width = W; this.canvas.height = H; }
      for (const k of ['fA', 'fB', 'fC', 'fD', 'fM', 'cA', 'cB', 'cF', 'fE', 'fF', 'fT1', 'fT2', 'fH']) { if (this[k]) { gl.deleteFramebuffer(this[k].f); gl.deleteTexture(this[k].t); } this[k] = this.fbo(); }
      this.canvasTex.clear();
    }

    /* ---------------- user shaders (Shadertoy-style mainImage, or ISF) */
    shaderProg(sh) {
      if (!sh) return null; const key = sh.id + ':' + sh.code.length + ':' + sh.code.slice(0, 40) + sh.code.slice(-40);
      if (this.shaderProgs.has(key)) return this.shaderProgs.get(key);
      let body = sh.code, fs;
      try {
        fs = SHADER_HEAD + body + `
void main(){ vec4 c=vec4(0.0,0.0,0.0,1.0); mainImage(c, v_uv*iResolution.xy); float a=clamp(c.a,0.0,1.0)*u_alpha; gl_FragColor=vec4(clamp(c.rgb,0.0,1.0)*a,a); }`;
        const p = this.prog(VS_QUAD, fs); this.shaderProgs.set(key, p); delete this.shaderErrors[sh.id]; return p;
      } catch (e) {
        this.shaderErrors[sh.id] = String(e.message || e).slice(0, 600); this.shaderProgs.set(key, null);
        this.hooks.shaderError && this.hooks.shaderError(sh.id, this.shaderErrors[sh.id]); return null;
      }
    }
    /* ---------------- ISF shaders (generators and effects): multi-pass, persistent / float buffers, imported images, audio textures */
    isfCompile(sh) {
      const ISF = window.PixoraISF; if (!ISF || !sh) return null;
      const src = sh.code + '\u0000' + (sh.vs || ''); let hsh = 5381; for (let i = 0; i < src.length; i++) hsh = ((hsh << 5) + hsh + src.charCodeAt(i)) | 0;
      const key = sh.id + ':' + hsh; this.isfProgs = this.isfProgs || new Map();
      if (this.isfProgs.has(key)) return this.isfProgs.get(key);
      let entry;
      try { const info = ISF.parse(sh.code, sh.vs); const b = ISF.build(info); const prog = this.prog(b.vs, b.fs); entry = { prog, info, images: b.images }; delete this.shaderErrors[sh.id]; }
      catch (e) { entry = { error: String(e.message || e).slice(0, 800) }; this.shaderErrors[sh.id] = entry.error; this.hooks.shaderError && this.hooks.shaderError(sh.id, entry.error); }
      this.isfProgs.set(key, entry); return entry;
    }
    isfTarget(w, h, float) {
      const gl = this.gl, mk = () => { const t = this.tex(); let ok = false;
        if (float && this.isGL2 && (this._cbf ?? (this._cbf = !!gl.getExtension('EXT_color_buffer_float')))) { gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA16F, w, h, 0, gl.RGBA, gl.HALF_FLOAT, null); ok = true; }
        if (!ok) gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
        const f = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, f); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t, 0);
        gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT); return { f, t }; };
      return { a: mk(), b: mk(), w, h, float: !!float, flip: false, get read() { return this.flip ? this.b : this.a; }, get write() { return this.flip ? this.a : this.b; } };
    }
    isfFree(inst) { const gl = this.gl; for (const b of Object.values(inst.bufs || {})) for (const x of [b.a, b.b]) { gl.deleteFramebuffer(x.f); gl.deleteTexture(x.t); } inst.bufs = {}; }
    isfImage(url) { // imported images / image inputs: loaded once, uploaded bottom-up like every other texture here
      this.isfImgs = this.isfImgs || new Map(); if (!url) return null; let e = this.isfImgs.get(url); if (e) return e.ready ? e : null;
      e = { ready: false, t: null, w: 1, h: 1 }; this.isfImgs.set(url, e);
      const im = new Image(); im.crossOrigin = 'anonymous';
      im.onload = () => { const gl = this.gl; e.t = this.tex(); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, im); e.w = im.naturalWidth; e.h = im.naturalHeight; e.ready = true; };
      im.onerror = () => { e.error = true; }; im.src = /^(https?:|data:|blob:|\/)/.test(url) ? url : BVJ.mediaUrl(url); return null;
    }
    isfAudio(type, samples, time) { // audio inputs as a 1-row texture: waveform (audio) or spectrum (audioFFT)
      const n = Math.max(16, Math.min(2048, samples || 256)), key = type + n; this.isfAud = this.isfAud || {};
      let e = this.isfAud[key]; if (!e) e = this.isfAud[key] = { t: this.tex(), at: -1, px: new Uint8Array(n * 4) };
      if (e.at === time) return e; e.at = time;
      const src = type === 'audioFFT' ? this.fft : this.wave, a = this.audio, px = e.px;
      for (let i = 0; i < n; i++) { let v;
        if (src && src.length) { const pos = (type === 'audioFFT' ? i / n * src.length * 0.75 : i / n * src.length) | 0; v = src[Math.min(src.length - 1, pos)]; }
        else if (type === 'audioFFT') { const f = i / n; v = 255 * (f < 0.1 ? a.bass : f < 0.45 ? a.mid : a.high) * (1 - f * 0.5); }
        else v = 128 + 120 * a.level * Math.sin(i / n * Math.PI * 16 + time * 20);
        px[i * 4] = px[i * 4 + 1] = px[i * 4 + 2] = Math.max(0, Math.min(255, v)); px[i * 4 + 3] = 255; }
      const gl = this.gl; gl.bindTexture(gl.TEXTURE_2D, e.t); gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, n, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, px); gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true); e.w = n; return e;
    }
    // render an ISF shader at W×H; returns its output texture { t, w, h } (or null when it doesn't compile)
    isfRun(sh, ikey, vals, W, H, time, beat, extra) {
      const c = this.isfCompile(sh); if (!c || !c.prog) return null;
      const gl = this.gl, ISF = window.PixoraISF, info = c.info, p = c.prog; vals = vals || {}; extra = extra || {};
      this.isfInst = this.isfInst || new Map(); let inst = this.isfInst.get(ikey);
      if (!inst || inst.prog !== p) { if (inst) this.isfFree(inst); inst = { prog: p, bufs: {}, frame: 0, lastT: time, ev: {} }; this.isfInst.set(ikey, inst); }
      inst.used = performance.now();
      const prevFb = gl.getParameter(gl.FRAMEBUFFER_BINDING), prevVp = gl.getParameter(gl.VIEWPORT), sc = gl.isEnabled(gl.SCISSOR_TEST), bl = gl.isEnabled(gl.BLEND);
      gl.disable(gl.SCISSOR_TEST); gl.disable(gl.BLEND);
      const nums = {}; for (const i of info.inputs) if (i.type === 'float' || i.type === 'long') nums[i.name] = ISF.value(i, vals);
      const sizes = info.passes.map(ps => ISF.passSize(ps, W, H, nums));
      // buffers: one double-buffered target per named pass (reads see the previous contents), plus the output
      const need = {}; info.passes.forEach((ps, k) => { const name = ps.target || '__out'; need[name] = { w: sizes[k].w, h: sizes[k].h, float: ps.float }; });
      if (!need.__out) need.__out = sizes[sizes.length - 1];
      for (const [name, n] of Object.entries(need)) { const b = inst.bufs[name]; if (!b || b.w !== n.w || b.h !== n.h || b.float !== !!n.float) { if (b) for (const x of [b.a, b.b]) { gl.deleteFramebuffer(x.f); gl.deleteTexture(x.t); } inst.bufs[name] = this.isfTarget(n.w, n.h, n.float); } }
      gl.useProgram(p); gl.bindBuffer(gl.ARRAY_BUFFER, this.buf); gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
      const u = p.u, d = new Date();
      if (u.TIME) gl.uniform1f(u.TIME, time); if (u.TIMEDELTA) gl.uniform1f(u.TIMEDELTA, Math.max(0, time - inst.lastT)); if (u.FRAMEINDEX) gl.uniform1i(u.FRAMEINDEX, inst.frame);
      if (u.DATE) gl.uniform4f(u.DATE, d.getFullYear(), d.getMonth() + 1, d.getDate(), d.getHours() * 3600 + d.getMinutes() * 60 + d.getSeconds() + d.getMilliseconds() / 1000);
      const bi = Math.floor(beat || 0);
      for (const i of info.inputs) { const loc = u[i.name]; if (!loc) continue; const v = ISF.value(i, vals);
        if (i.type === 'float') gl.uniform1f(loc, v); else if (i.type === 'long') gl.uniform1i(loc, v); else if (i.type === 'bool') gl.uniform1i(loc, v ? 1 : 0);
        else if (i.type === 'color') gl.uniform4fv(loc, v); else if (i.type === 'point2D') gl.uniform2fv(loc, v);
        else if (i.type === 'event') { const raw = vals[i.name]; let fire = false;
          if (raw === 'beat') { fire = inst.ev[i.name] !== undefined && inst.ev[i.name] !== bi; inst.ev[i.name] = bi; }
          else { fire = inst.ev[i.name] !== undefined && raw != null && raw !== inst.ev[i.name]; inst.ev[i.name] = raw; }
          gl.uniform1i(loc, fire ? 1 : 0); } }
      const black = this.blackTex || (this.blackTex = this.tex());
      const imageFor = name => { const inp = info.inputs.find(i => i.name === name);
        if (inst.bufs[name]) return { t: inst.bufs[name].read.t, w: inst.bufs[name].w, h: inst.bufs[name].h };
        if (extra.images && extra.images[name]) return extra.images[name];
        if (inp && (inp.type === 'audio' || inp.type === 'audioFFT')) { const a = this.isfAudio(inp.type, inp.samples, time); return { t: a.t, w: a.w, h: 1 }; }
        const url = inp ? vals[name] : (sh.files || {})[name]; const im = typeof url === 'string' ? this.isfImage(url) : null;
        return im || { t: black, w: 1, h: 1 }; };
      info.passes.forEach((ps, k) => {
        const tgt = inst.bufs[ps.target || '__out'], sz = sizes[k];
        c.images.forEach((name, unit) => { const im = imageFor(name); gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(gl.TEXTURE_2D, im.t);
          if (u[name]) gl.uniform1i(u[name], unit); const su = u['_' + name + '_imgSize']; if (su) gl.uniform2f(su, im.w, im.h); });
        if (u.PASSINDEX) gl.uniform1i(u.PASSINDEX, k); if (u.RENDERSIZE) gl.uniform2f(u.RENDERSIZE, sz.w, sz.h);
        gl.bindFramebuffer(gl.FRAMEBUFFER, tgt.write.f); gl.viewport(0, 0, sz.w, sz.h);
        if (!ps.persistent) { gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT); }
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4); tgt.flip = !tgt.flip; // what was just written becomes the readable copy
      });
      // persistent buffers: copy forward so next frame's "previous" equals this frame's result in both halves
      for (const [name, b] of Object.entries(inst.bufs)) { const ps = info.passes.find(x => x.target === name); if (!ps || !ps.persistent) continue;
        const pb = this.pBlit; this.bindQuad(pb); gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, b.read.t); gl.uniform1i(pb.u.u_tex, 0); gl.uniform1f(pb.u.u_alpha, 1); gl.uniform4f(pb.u.u_rect, 0, 0, 1, 1);
        gl.bindFramebuffer(gl.FRAMEBUFFER, b.write.f); gl.viewport(0, 0, b.w, b.h); gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4); }
      const last = info.passes[info.passes.length - 1], ob = inst.bufs[last.target || '__out'];
      gl.activeTexture(gl.TEXTURE0); inst.frame++; inst.lastT = time;
      gl.bindFramebuffer(gl.FRAMEBUFFER, prevFb); gl.viewport(prevVp[0], prevVp[1], prevVp[2], prevVp[3]); if (sc) gl.enable(gl.SCISSOR_TEST); if (bl) gl.enable(gl.BLEND);
      return { t: ob.read.t, w: ob.w, h: ob.h };
    }
    lutTex(id) { // fetch + parse + upload once per LUT revision (re-importing bumps rev)
      const meta = (this.stateRef.luts || []).find(l => l.id === id); if (!meta || !window.PixoraLUT) return null;
      this.luts = this.luts || new Map(); let e = this.luts.get(id);
      if (e && e.rev === meta.rev) return e.ready ? e : null;
      if (e && e.t) this.gl.deleteTexture(e.t);
      e = { rev: meta.rev, ready: false }; this.luts.set(id, e);
      fetch('/api/luts/' + encodeURIComponent(id)).then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.text(); }).then(text => {
        if (this.luts.get(id) !== e) return; const L = PixoraLUT.parse(text, '.' + (meta.ext || 'cube')), A = PixoraLUT.atlas(L), gl = this.gl;
        const t = this.tex(); gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
        if (this.isGL2) { const h = new Uint16Array(A.px.length); for (let i = 0; i < h.length; i++) h[i] = PixoraLUT.toHalf(A.px[i]); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA16F, A.w, A.h, 0, gl.RGBA, gl.HALF_FLOAT, h); }
        else { const b = new Uint8Array(A.px.length); for (let i = 0; i < b.length; i++) b[i] = Math.max(0, Math.min(255, Math.round(A.px[i] * 255))); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, A.w, A.h, 0, gl.RGBA, gl.UNSIGNED_BYTE, b); }
        gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
        Object.assign(e, { t, kind: L.kind, size: L.size, dmin: L.dmin, dmax: L.dmax, ready: true }); delete this.shaderErrors['lut:' + id];
      }).catch(err => { e.error = String(err.message || err); this.shaderErrors['lut:' + id] = e.error; this.hooks.shaderError && this.hooks.shaderError('lut:' + id, e.error); });
      return null;
    }
    lutPass(f, cur, dst) {
      const L = f && f.lut && this.lutTex(f.lut); if (!L) return false;
      const gl = this.gl, p = this.pLut, u = p.u, n = (k, d) => Number.isFinite(+f[k]) ? +f[k] : d; this.bindQuad(p);
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, cur.t); gl.uniform1i(u.u_tex, 0);
      gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, L.t); gl.uniform1i(u.u_lut, 1);
      gl.uniform1f(u.u_n, L.size); gl.uniform1f(u.u_is1d, L.kind === '1d' ? 1 : 0); gl.uniform3fv(u.u_dmin, L.dmin); gl.uniform3fv(u.u_dmax, L.dmax);
      gl.uniform1f(u.u_mix, Math.max(0, Math.min(1, n('mix', 1)))); gl.uniform1f(u.u_exp, n('exposure', 0)); gl.uniform1f(u.u_con, n('contrast', 1)); gl.uniform1f(u.u_sat, n('saturation', 1));
      gl.uniform1f(u.u_temp, n('temp', 0)); gl.uniform1f(u.u_tint, n('tint', 0)); gl.uniform1f(u.u_gain, n('gain', 1));
      gl.disable(gl.BLEND); this.drawFull(p, dst); gl.activeTexture(gl.TEXTURE0); return true;
    }
    // yaw (Y), pitch (X), roll (Z) in degrees → column-major mat3 for GLSL
    rotMat(yaw, pitch, roll) { const r = Math.PI / 180, [a, b, c] = [yaw * r, pitch * r, roll * r], cy = Math.cos(a), sy = Math.sin(a), cp = Math.cos(b), sp = Math.sin(b), cr = Math.cos(c), sr = Math.sin(c);
      const Ry = [cy, 0, -sy, 0, 1, 0, sy, 0, cy], Rx = [1, 0, 0, 0, cp, sp, 0, -sp, cp], Rz = [cr, sr, 0, -sr, cr, 0, 0, 0, 1];
      const mul = (A, B) => { const o = new Array(9); for (let col = 0; col < 3; col++) for (let row = 0; row < 3; row++) { let v = 0; for (let k = 0; k < 3; k++) v += A[k * 3 + row] * B[col * 3 + k]; o[col * 3 + row] = v; } return o; };
      return mul(mul(Ry, Rx), Rz); }
    domePass(dm, srcTex, OW, OH) { // renders the projected picture at output size, returns its texture
      const gl = this.gl, p = this.pDome, u = p.u; let f = this.domeFbo;
      if (!f || f.w !== OW || f.h !== OH) { if (f) { gl.deleteFramebuffer(f.f); gl.deleteTexture(f.t); } const t = this.tex(); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, OW, OH, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
        const fb = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, fb); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t, 0); f = this.domeFbo = { f: fb, t, w: OW, h: OH }; }
      this.bindQuad(p); gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, srcTex); gl.uniform1i(u.u_tex, 0);
      gl.uniform1i(u.u_mode, { fisheye: 0, equirect: 1, perspective: 2 }[dm.mode] ?? 0); gl.uniform1i(u.u_in, dm.input === 'flat' ? 1 : 0);
      gl.uniform1f(u.u_fov, Math.max(10, Math.min(360, +dm.fov || 180))); gl.uniform1f(u.u_pfov, Math.max(10, Math.min(170, +dm.pfov || 90))); gl.uniform1f(u.u_aspect, OW / OH);
      gl.uniformMatrix3fv(u.u_rot, false, this.rotMat(-(+dm.yaw || 0), +dm.pitch || 0, +dm.roll || 0));
      // flat content: a window centred at azimuth / elevation; inverse rotation brings directions into its frame
      const fr = this.rotMat(-(+dm.flatAz || 0), +dm.flatEl || 0, 0), inv = [fr[0], fr[3], fr[6], fr[1], fr[4], fr[7], fr[2], fr[5], fr[8]];
      gl.uniformMatrix3fv(u.u_frot, false, inv); const tH = Math.tan(Math.max(5, Math.min(170, +dm.flatFov || 90)) * Math.PI / 360);
      gl.uniform1f(u.u_tanH, tH); gl.uniform1f(u.u_tanV, tH * this.H / this.W);
      gl.disable(gl.BLEND); gl.bindFramebuffer(gl.FRAMEBUFFER, f.f); gl.viewport(0, 0, OW, OH); gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      return f.t;
    }
    isfSweep() { if (!this.isfInst) return; const now = performance.now(); for (const [k, inst] of this.isfInst) if (now - inst.used > 5000) { this.isfFree(inst); this.isfInst.delete(k); } }
    feedText(p) {
      if (!p.feed) return tpl(p.text || '');
      const key = p.feed + '|' + (p.cell || ''); let f = this.feeds.get(key);
      if (!f) { f = { text: p.text || '', at: 0 }; this.feeds.set(key, f); }
      if (!f.loading && Date.now() - f.at > Math.max(5, p.refresh || 30) * 1000) {
        f.loading = true; fetch('/api/feed?url=' + encodeURIComponent(p.feed) + '&cell=' + encodeURIComponent(p.cell || ''))
          .then(r => r.json()).then(j => { if (j.text != null) f.text = j.text; }).catch(() => {}).finally(() => { f.loading = false; f.at = Date.now(); });
      }
      return tpl(f.text);
    }

    /* ---------------- sources */
    playlistItem(pl) { // the current entry of a playlist clip, as an ordinary clip (cached so it keeps its identity)
      const items = pl.items || []; if (!items.length) return null; const it = items[(pl.index || 0) % items.length];
      const k = (pl.index || 0) + '|' + it.src; this._plCache = this._plCache || new WeakMap(); const c = this._plCache.get(pl);
      if (c && c.k === k && c.fit === pl.fit) return c.clip;
      const clip = Object.assign({}, pl, { type: it.kind === 'image' ? 'image' : 'video', src: it.src, name: it.name, loop: 'once', items: undefined, playlist: true });
      this._plCache.set(pl, { k, fit: pl.fit, clip }); return clip;
    }
    clipKey(clip) { return clip.type + '|' + (clip.src || clip.url || clip.device || '') + '|' + JSON.stringify(clip.gen || {}); }
    makeSource(clip, li) {
      const gl = this.gl, src = { clip, tex: this.tex(clip.type === 'gen'), ready: false, w: 16, h: 9, kind: clip.type, dir: 1 };
      if (clip.type === 'video' && window.HapPlayer && window.BVJ && BVJ.hapSet && BVJ.hapSet[clip.src]) { // HAP: GPU-compressed frames streamed by hap.js
        src.kind = 'hap'; src.hap = new HapPlayer(BVJ.mediaUrl(clip.src), gl); src.vt = null; return src; }
      if (clip.type === 'video') {
        const v = document.createElement('video');
        v.muted = !this.audioUnlocked; v.playsInline = true; v.preload = 'auto'; v.loop = false; v.crossOrigin = 'anonymous';
        v.src = BVJ.mediaUrl(clip.src);
        v.addEventListener('loadedmetadata', () => { src.w = v.videoWidth || 16; src.h = v.videoHeight || 9; v.currentTime = (clip.inPt || 0) * (v.duration || 0); });
        v.addEventListener('error', () => { src.error = true; this.hooks.unplayable && this.hooks.unplayable(clip.src, li); });
        v.play().catch(() => {});
        src.el = v;
      } else if (clip.type === 'image') {
        const img = new Image(); img.onload = () => { src.w = img.naturalWidth; src.h = img.naturalHeight; gl.bindTexture(gl.TEXTURE_2D, src.tex); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img); src.ready = true; };
        img.onerror = () => { src.error = true; }; img.src = BVJ.mediaUrl(clip.src); src.el = img;
      } else if (clip.type === 'capture' || clip.type === 'screen') {
        const v = document.createElement('video'); v.muted = true; v.playsInline = true; src.el = v;
        this.getStream(clip).then(stream => { v.srcObject = stream; v.onloadedmetadata = () => { src.w = v.videoWidth; src.h = v.videoHeight; v.play().catch(() => {}); }; })
          .catch(e => { src.error = true; src.errMsg = e.message; this.hooks.needGesture && this.hooks.needGesture(clip, e); });
      } else if (clip.type === 'stream') { // SRT / RTMP / HLS / RTSP pulled in by the server's ffmpeg, played as live fragmented MP4
        const v = document.createElement('video'); v.muted = !this.audioUnlocked; v.playsInline = true; v.crossOrigin = 'anonymous'; src.el = v; src.live = true;
        this.streamPlay(src, clip);
      } else if (clip.type === 'guest') { // remote guest over WebRTC (public/guests-out.js)
        const v = document.createElement('video'); v.muted = true; v.playsInline = true; v.autoplay = true; src.el = v; src.guestSlot = +clip.slot || 1;
        v.onloadedmetadata = () => { src.w = v.videoWidth; src.h = v.videoHeight; v.play().catch(() => {}); }; v.onresize = () => { src.w = v.videoWidth; src.h = v.videoHeight; };
        if (window.pixoraGuest) window.pixoraGuest.attach(src.guestSlot, v);
      } else if (clip.type === 'replay') { // instant replay unit (public/replay.js)
        src.kind = 'replay'; src.ready = true; const sz = this.replay ? this.replay.size() : { w: 1280, h: 720 }; src.w = sz.w; src.h = sz.h;
      } else if (clip.type === 'gen') {
        src.ready = true; src.w = this.W; src.h = this.H;
      } else if ((clip.type === 'web' || clip.type === 'ndi' || (clip.type === 'decklink' && window.pixoraNative && window.pixoraNative.openDecklink) || (clip.type === 'texshare' && window.pixoraNative && window.pixoraNative.openTexShare)) && window.pixoraNative) { // desktop helper: web pages & NDI as GPU textures (effects apply)
        src.kind = 'native'; src.w = this.W; src.h = this.H;
        src.nativeId = clip.type === 'web' ? window.pixoraNative.openWeb(clip.url, this.W, this.H) : clip.type === 'decklink' ? window.pixoraNative.openDecklink(clip.device || 0) : clip.type === 'texshare' ? window.pixoraNative.openTexShare(clip.sender || '') : window.pixoraNative.openNdi(clip.ndi);
        window.pixoraNative.onFrame(src.nativeId, (frame) => { src.frame = frame; src.lastFrame = frame; src.ready = true; if (frame.width) { src.w = frame.width; src.h = frame.height; } });
        if (window.pixoraNative.onStatus) window.pixoraNative.onStatus(src.nativeId, st => { if (st.error) { src.error = true; src.errMsg = st.error; } });
        if (clip.type === 'ndi' && window.pixoraNative.onAudio && this.hooks.ndiAudio) window.pixoraNative.onAudio(src.nativeId, a => this.hooks.ndiAudio(src, a));
      } else if (clip.type === 'web') { src.ready = true; src.w = this.W; src.h = this.H; }
      return src;
    }
    async getStream(clip) {
      const key = clip.type === 'screen' ? 'screen' : 'cap:' + (clip.device || 'default');
      const have = this.streams.get(key); if (have && have.active) return have;
      let s;
      if (clip.type === 'screen') {
        if (!this.gestureOK) throw new Error('needs click');
        s = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: 60 }, audio: false });
      } else {
        s = await navigator.mediaDevices.getUserMedia({ video: { deviceId: clip.device ? { exact: clip.device } : undefined, width: { ideal: 1920 }, height: { ideal: 1080 }, frameRate: { ideal: 60 } }, audio: false });
      }
      this.streams.set(key, s); return s;
    }
    streamPlay(src, clip) {
      const q = `url=${encodeURIComponent(clip.url || '')}&mode=${encodeURIComponent(clip.mode || 'auto')}&mbps=${+clip.mbps || 8}`, v = src.el;
      const lag = Math.max(0.3, Math.min(5, +clip.latency || 0.8));
      const session = src.streamSession = {}; const alive = () => src.streamSession === session && !src.disposed;
      const retry = why => { src.errMsg = why; if (alive()) setTimeout(() => alive() && this.streamPlay(src, clip), 1500); };
      fetch('/api/streamin/info?' + q + '&wait=8000').then(r => r.json()).then(info => {
        if (!alive()) return; src.streamInfo = info;
        if (info.error && !info.mime) return retry(info.error); if (!info.mime) return retry('waiting for the stream…');
        if (!window.MediaSource || !MediaSource.isTypeSupported(info.mime)) { src.error = true; src.errMsg = 'this browser cannot play ' + info.mime; return; }
        const ms = new MediaSource(); v.src = URL.createObjectURL(ms);
        ms.addEventListener('sourceopen', async () => {
          URL.revokeObjectURL(v.src); let sb; try { sb = ms.addSourceBuffer(info.mime); sb.mode = 'segments'; } catch (e) { return retry(e.message); }
          const queue = []; let ctl = new AbortController(); session.abort = () => ctl.abort();
          const pump = () => { if (sb.updating || !queue.length || ms.readyState !== 'open') return; try { sb.appendBuffer(queue.shift()); } catch (e) {
            if (e.name === 'QuotaExceededError' && v.buffered.length) { try { sb.remove(0, Math.max(0, v.currentTime - 2)); } catch {} queue.length = 0; } } };
          sb.addEventListener('updateend', () => { // stay at the live edge, drop what's behind
            const b = v.buffered; if (b.length) { const end = b.end(b.length - 1); if (end - v.currentTime > lag + 0.6 || v.currentTime < b.start(0)) v.currentTime = Math.max(b.start(b.length - 1), end - lag * 0.5);
              if (v.currentTime - b.start(0) > 20 && !sb.updating) { try { sb.remove(0, v.currentTime - 10); return; } catch {} } }
            if (v.paused && v.readyState >= 2) v.play().catch(() => {}); pump(); });
          try { const r = await fetch('/api/streamin/live?' + q, { signal: ctl.signal }); const rd = r.body.getReader();
            v.onloadedmetadata = () => { src.w = v.videoWidth; src.h = v.videoHeight; v.play().catch(() => {}); };
            for (;;) { const { done, value } = await rd.read(); if (done || !alive()) break; queue.push(value); src.streamBytes = (src.streamBytes || 0) + value.length; pump(); }
          } catch (e) { if (!alive()) return; }
          retry('stream reconnecting…'); // the feed dropped or ffmpeg restarted: a new init segment needs a new MediaSource
        }, { once: true });
      }).catch(e => retry(e.message));
    }
    disposeSource(s) {
      if (!s) return; s.disposed = true; if (s.streamSession && s.streamSession.abort) s.streamSession.abort(); if (s.guestSlot && window.pixoraGuest) window.pixoraGuest.detach(s.el);
      if (s.el && s.el.tagName === 'VIDEO') { s.el.pause(); if (!s.el.srcObject) { s.el.removeAttribute('src'); s.el.load(); } s.el.srcObject = null; }
      this.gl.deleteTexture(s.tex); if (s.atex) this.gl.deleteTexture(s.atex);
      if (s.fc) { for (const b of s.fc.frames.values()) b.close && b.close(); s.fc = null; }
      if (s.nativeId != null && window.pixoraNative) { if (s.tallySent && window.pixoraNative.setTally) window.pixoraNative.setTally(s.nativeId, false, false); if (s.ndiStop) s.ndiStop(); window.pixoraNative.close(s.nativeId); }
      if (s.hap) s.hap.close();
    }
    unlockAudio() { this.audioUnlocked = true; this.gestureOK = true; for (const r of this.layers) for (const s of [r && r.cur, r && r.prev]) if (s && s.el && s.el.tagName === 'VIDEO' && !s.el.srcObject) s.el.muted = false; }

    /* ---------------- per-frame update of one video source */
    updateVideo(src, clip, layer, comp, dt, li, rt) {
      const v = src.el; if (!v || v.readyState < 2) return;
      if (!src.ready) src.ready = true;
      const vol = (this.audioUnlocked ? 1 : 0) * (comp.mute ? 0 : comp.volume ?? 1) * (layer.mute ? 0 : layer.volume ?? 1) * (layer.bypass || comp.blackout ? 0 : 1) * (layer.afv && !(layer.opacity > 0.001) ? 0 : 1);
      v.muted = vol <= 0; if (vol > 0) v.volume = v._pxRouted ? 1 : Math.min(1, vol); // routed through the output's mixer: the fader is a gain node there
      if (src.kind !== 'video') return; // live streams: sound follows the faders, the playhead follows the sender
      const dur = v.duration || 0; if (!dur) return;
      const inT = Math.min(clip.inPt || 0, 0.999) * dur, outT = Math.max(clip.outPt == null ? 1 : clip.outPt, (clip.inPt || 0) + 0.001) * dur;
      let rate = (clip.speed == null ? 1 : clip.speed) * (comp.speed == null ? 1 : comp.speed);
      if (clip.beatSync) rate = (outT - inT) / Math.max(0.05, (clip.beats || 16) * 60 / comp.bpm) * Math.sign(rate || 1);
      if (src.dir < 0) rate = -Math.abs(rate);
      // Follow DJ deck (PRO DJ LINK Bridge / TCNet): the clip's playhead tracks the CDJ's playhead
      if (clip.djSync && clip.djSync !== 'off' && this.djTime && !layer.paused) {
        const D = this.djTime, idx = clip.djSync === 'master' ? D.master : +clip.djSync - 1, L = D.layers && D.layers[idx];
        if (L) {
          const live = L.state === 3 || L.state === 4, sp = L.speed || 1;
          const est = inT + (L.ms + (live ? (performance.now() - D.at) * sp : 0)) / 1000 + (+clip.djOffset || 0);
          const want = Math.max(inT, Math.min(outT - 0.04, est));
          if (!live) { if (!v.paused) v.pause(); if (!v.seeking && Math.abs(v.currentTime - want) > 0.04) v.currentTime = want; }
          else { const drift = v.currentTime - want;
            if (Math.abs(drift) > 0.3 || est >= outT) { if (!v.seeking) v.currentTime = want; }
            const r = Math.max(0.5, Math.min(2, sp * (1 - Math.max(-0.15, Math.min(0.15, drift * 1.5))))); if (Math.abs(v.playbackRate - r) > 0.002) v.playbackRate = r;
            if (est >= outT) { if (!v.paused) v.pause(); } else if (v.paused) v.play().catch(() => {}); }
          src.pos = (v.currentTime - inT) / Math.max(0.001, outT - inT); src.dur = outT - inT; src.t = v.currentTime - inT; return;
        }
      }
      const paused = layer.paused || rate === 0;
      if (paused) { if (!v.paused) v.pause(); return; }
      if (rate > 0) {
        const r = Math.min(16, Math.max(0.0625, rate * (src.syncMul || 1))); if (Math.abs(v.playbackRate - r) > 0.001) v.playbackRate = r;
        if (v.paused && !src.held) v.play().catch(() => {});
      } else if (clip.cache && src.fc && src.fc.frames.size > 2) { // reverse from the RAM frame cache (smooth)
        if (!v.paused) v.pause();
        src.vt = (src.vt ?? v.currentTime) + rate * dt; if (src.vt < inT) src.vt = inT;
        const fi = Math.round(src.vt * src.fc.fps); let bmp = null; for (let k = fi; k >= fi - 6 && !bmp; k--) bmp = src.fc.frames.get(k);
        src.fcShow = bmp || src.fcShow;
      } else { // reverse: step by seeking (smoothest with all-intra encoded files)
        if (!v.paused) v.pause();
        if (!v.seeking) { const nt = v.currentTime + rate * dt; v.currentTime = Math.max(inT, nt); }
      }
      if (rate > 0) { src.fcShow = null; src.vt = null; if (clip.cache) this.cacheFrame(src, v); }
      const t = rate < 0 && src.vt != null ? src.vt : v.currentTime;
      const atEnd = rate > 0 ? (t >= outT - 0.04 || v.ended) : t <= inT + 0.02;
      if (atEnd && !src.held) {
        const mode = clip.loop || 'loop';
        if (mode === 'bounce') { src.dir = -src.dir || -1; if (src.dir > 0) { v.currentTime = inT; src.vt = null; src.fcShow = null; } else src.vt = v.currentTime; }
        else if (mode === 'once') { src.held = true; v.pause(); }
        else { v.currentTime = rate > 0 ? inT : outT - 0.04; }
        if (rt.endedTrig !== layer.trig + ':' + (rt.loops = (rt.loops || 0) + 1)) { rt.endedTrig = layer.trig + ':' + rt.loops; this.hooks.ended && this.hooks.ended(li, layer.trig); }
      }
      if (rate > 0 && t < inT - 0.05) v.currentTime = inT;
      src.pos = dur ? (t - inT) / Math.max(0.001, outT - inT) : 0; src.dur = outT - inT; src.t = t - inT;
    }
    updateHap(src, clip, layer, comp, dt, li, rt) { // HAP playback clock: speed, in/out points, loop / bounce / once, frame sync
      const h = src.hap; if (h.error) { if (!src.error) { src.error = true; src.errMsg = h.error; } return; } if (!h.ready) return;
      src.w = h.w; src.h = h.h; const dur = h.dur || 0; if (!dur) return;
      const inT = Math.min(clip.inPt || 0, 0.999) * dur, outT = Math.max(clip.outPt == null ? 1 : clip.outPt, (clip.inPt || 0) + 0.001) * dur;
      let rate = (clip.speed == null ? 1 : clip.speed) * (comp.speed == null ? 1 : comp.speed) * (src.syncMul || 1);
      if (clip.beatSync) rate = (outT - inT) / Math.max(0.05, (clip.beats || 16) * 60 / comp.bpm) * Math.sign(rate || 1);
      if (src.vt == null) src.vt = rate < 0 ? outT - 0.001 : inT;
      if (!(layer.paused || src.held)) src.vt += rate * src.dir * dt;
      const mode = clip.loop || 'loop'; let ended = false;
      if (src.vt >= outT || src.vt < inT) {
        ended = true;
        if (mode === 'bounce') { src.dir = -src.dir; src.vt = Math.min(outT - 0.001, Math.max(inT, src.vt)); }
        else if (mode === 'once') { src.held = true; src.vt = Math.min(outT - 0.001, Math.max(inT, src.vt)); }
        else src.vt = src.vt >= outT ? inT + (src.vt - outT) % Math.max(0.001, outT - inT) : outT - 0.001;
      }
      if (ended && rt.endedTrig !== layer.trig + ':' + (rt.loops = (rt.loops || 0) + 1)) { rt.endedTrig = layer.trig + ':' + rt.loops; this.hooks.ended && this.hooks.ended(li, layer.trig); }
      if (h.show(src.vt, src.tex, rate * src.dir < 0 ? -1 : 1)) src.ready = true;
      src.pos = (src.vt - inT) / Math.max(0.001, outT - inT); src.dur = outT - inT; src.t = src.vt - inT;
    }
    upload(src) {
      const gl = this.gl; const v = src.el;
      if (src.kind === 'native' && src.frame) { gl.bindTexture(gl.TEXTURE_2D, src.tex); try { gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src.frame); } catch {} src.frame = null; return; }
      if (src.fcShow) { gl.bindTexture(gl.TEXTURE_2D, src.tex); try { gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src.fcShow); } catch {} return; }
      if (!v || v.tagName !== 'VIDEO' || v.readyState < 2) return;
      gl.bindTexture(gl.TEXTURE_2D, src.tex);
      try { gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, v); } catch (e) { /* tainted or not ready */ }
    }
    canvasGenTex(clip) {
      const key = clip.gen.kind + JSON.stringify(clip.gen.params) + this.W + 'x' + this.H + (clip.gen.kind === 'text' ? this.feedText(clip.gen.params || {}) : '') + (clip.gen.kind === 'audience' ? JSON.stringify((window.BVJ && BVJ.feeds && BVJ.feeds.audience) || null) : '');
      let t = this.canvasTex.get(key); if (t) return t;
      const c = document.createElement('canvas'); const ctx = c.getContext('2d'); const p = clip.gen.params || {};
      if (clip.gen.kind === 'text') {
        const fonts = ['Inter, Helvetica, Arial, sans-serif', 'Georgia, serif', 'ui-monospace, Menlo, Consolas, monospace', 'Impact, Haettenschweiler, sans-serif'];
        const size = Math.max(4, this.H * (p.size || 20) / 100);
        ctx.font = `bold ${size}px ${fonts[p.font | 0] || fonts[0]}`;
        const txt = this.feedText(p);
        const tw = Math.ceil(ctx.measureText(txt).width);
        const scrolling = Math.abs(p.scroll || 0) > 0.0001;
        c.width = scrolling ? Math.max(this.W, tw + this.W * 0.25) : this.W; c.height = this.H;
        ctx.font = `bold ${size}px ${fonts[p.font | 0] || fonts[0]}`;
        ctx.fillStyle = p.c1 || '#fff'; ctx.textBaseline = 'middle'; ctx.textAlign = scrolling ? 'left' : 'center';
        ctx.fillText(txt, scrolling ? 0 : c.width / 2, c.height / 2);
      } else if (clip.gen.kind === 'audience') { c.width = this.W; c.height = this.H; drawAudience(ctx, c.width, c.height, p, window.BVJ && BVJ.feeds && BVJ.feeds.audience);
      } else { // test grid
        c.width = this.W; c.height = this.H; const g = p.size || 64;
        ctx.fillStyle = '#111'; ctx.fillRect(0, 0, c.width, c.height);
        ctx.strokeStyle = '#666'; ctx.lineWidth = 1;
        for (let x = 0; x <= c.width; x += g) { ctx.beginPath(); ctx.moveTo(x + 0.5, 0); ctx.lineTo(x + 0.5, c.height); ctx.stroke(); }
        for (let y = 0; y <= c.height; y += g) { ctx.beginPath(); ctx.moveTo(0, y + 0.5); ctx.lineTo(c.width, y + 0.5); ctx.stroke(); }
        const bars = ['#fff', '#ff0', '#0ff', '#0f0', '#f0f', '#f00', '#00f', '#000'];
        const bw = c.width / bars.length, bh = c.height * 0.12, by = c.height * 0.68;
        bars.forEach((b, i) => { ctx.fillStyle = b; ctx.fillRect(i * bw, by, bw + 1, bh); });
        ctx.strokeStyle = '#fff'; ctx.lineWidth = Math.max(1, Math.min(c.width, c.height) / 300);
        ctx.beginPath(); ctx.arc(c.width / 2, c.height / 2, Math.min(c.width, c.height) * 0.42, 0, Math.PI * 2); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(c.width, c.height); ctx.moveTo(c.width, 0); ctx.lineTo(0, c.height); ctx.stroke();
        ctx.strokeStyle = '#f33'; ctx.lineWidth = Math.max(2, ctx.lineWidth * 2); ctx.strokeRect(1, 1, c.width - 2, c.height - 2);
        const fs = Math.max(10, Math.min(c.height * 0.12, c.width / 10));
        ctx.font = `bold ${fs}px Inter, Arial, sans-serif`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillStyle = '#000'; const label = `${this.W} × ${this.H}`; const tw = ctx.measureText(label).width;
        ctx.fillRect(c.width / 2 - tw / 2 - fs * 0.3, c.height * 0.4 - fs * 0.65, tw + fs * 0.6, fs * 1.3);
        ctx.fillStyle = '#fff'; ctx.fillText(label, c.width / 2, c.height * 0.4);
      }
      if (this.canvasTex.size > 24) { for (const [k, old] of this.canvasTex) { this.gl.deleteTexture(old.tex); this.canvasTex.delete(k); break; } }
      const tex = this.tex(true); const gl = this.gl; gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, c);
      t = { tex, w: c.width, h: c.height }; this.canvasTex.set(key, t); return t;
    }

    /* ---------------- animated canvas generators: Title Designer + Logo Animator */
    animGen(src, clip, time, beat, W, H) {
      const gl = this.gl; const p = (clip.gen && clip.gen.params) || {};
      if (!src.cv) { src.cv = document.createElement('canvas'); src.t0 = time; src.atex = this.tex(); }
      const c = src.cv; if (c.width !== W || c.height !== H) { c.width = W; c.height = H; }
      if (clip.gen.kind === 'title' && (p.rowMode | 0) === 1) { const n = feedRows(p.rowsFrom).length, ri = n ? Math.floor(((window.BVJ && BVJ.now ? BVJ.now() : Date.now()) / 1000) / Math.max(1, +p.rowSecs || 5)) % n : -1;
        if (src.rowIdx !== undefined && ri !== src.rowIdx) src.t0 = time; src.rowIdx = ri; } // each new row plays the title's in-animation
      const g = c.getContext('2d'); g.clearRect(0, 0, W, H); const t = time - src.t0;
      if (clip.gen.kind === 'title') drawTitle(g, W, H, p, t); else drawLogo(this, g, W, H, p, t, beat);
      gl.bindTexture(gl.TEXTURE_2D, src.atex); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, c);
      return { tex: src.atex, w: W, h: H };
    }
    // RAM frame cache: decoded frames kept as GPU-friendly ImageBitmaps for smooth reverse / bounce
    cacheFrame(src, v) {
      const fc = src.fc || (src.fc = { frames: new Map(), fps: 30, bytes: 0, pending: false });
      if (fc.pending || v.readyState < 2) return; const fi = Math.round(v.currentTime * fc.fps); if (fc.frames.has(fi)) return;
      const maxW = Math.min(v.videoWidth || 1280, 1920), scale = maxW / (v.videoWidth || maxW); const bw = Math.round((v.videoWidth || 1280) * scale), bh = Math.round((v.videoHeight || 720) * scale);
      const budget = (this.cacheBudgetMB || 1200) * 1048576; if (fc.bytes + bw * bh * 4 > budget) return;
      fc.pending = true; createImageBitmap(v, { resizeWidth: bw, resizeHeight: bh, imageOrientation: 'flipY' }).then(b => { fc.frames.set(fi, b); fc.bytes += bw * bh * 4; }).catch(() => {}).finally(() => { fc.pending = false; });
    }
    imageFor(srcKey) {
      this._imgs = this._imgs || new Map(); let im = this._imgs.get(srcKey);
      if (!im) { im = new Image(); im.src = BVJ.mediaUrl(srcKey); this._imgs.set(srcKey, im); }
      return im.complete && im.naturalWidth ? im : null;
    }

    /* ---------------- drawing helpers */
    bindQuad(p) { const gl = this.gl; gl.useProgram(p); gl.bindBuffer(gl.ARRAY_BUFFER, this.buf); gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0); }
    drawFull(p, target) {
      const gl = this.gl; gl.bindFramebuffer(gl.FRAMEBUFFER, target ? target.f : null); gl.viewport(0, 0, this.W, this.H);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    }
    drawSource(src, clip, alpha, time, beat, layer) {
      if (!src || !src.ready || alpha <= 0) return;
      const gl = this.gl, W = this.W, H = this.H; let p = this.pSrc;
      if (clip.type === 'gen' && clip.gen && clip.gen.kind === 'shader') {
        const sh = (this.stateRef.shaders || []).find(x => x.id === (clip.gen.params || {}).shader);
        if (sh && window.PixoraISF && PixoraISF.isISF(sh.code)) { // ISF generator → render to its own buffers, then draw like any texture source
          const RW = this._rect ? this._rect.w : W, RH = this._rect ? this._rect.h : H, cp = clip.gen.params || {};
          var isfOut = this.isfRun(sh, 'G:' + (src._isfKey || (src._isfKey = 's' + (this._isfSeq = (this._isfSeq || 0) + 1))) + ':' + sh.id, cp.isf, Math.max(1, RW | 0), Math.max(1, RH | 0), time, beat, {});
          if (!isfOut) return;
        } else { const sp = this.shaderProg(sh); if (sp) p = sp; }
      }
      if (clip.type === 'gen' && clip.gen && clip.gen.kind === 'scene3d') { // 3D scene: glTF model rendered with depth into its own buffer
        const cp = clip.gen.params || {}, m = (this.stateRef.models || []).find(x => x.id === cp.model); if (!m || !window.PixoraScene3D) { src.s3d = { state: m ? 'error' : 'none' }; return; }
        this.s3d = this.s3d || new PixoraScene3D(gl, this.isGL2); const RW = Math.max(1, (this._rect ? this._rect.w : W) | 0), RH = Math.max(1, (this._rect ? this._rect.h : H) | 0);
        const vp = this.stateRef.vp || {}, pose = vp.sim ? Object.assign({ cam: vp.cam }, vp.simPose || {}) : (this.track || {})[vp.cam | 0];
        const r = this.s3d.render('S:' + (src._isfKey || (src._isfKey = 's' + (this._isfSeq = (this._isfSeq || 0) + 1))), '/api/models/' + m.id + '?v=' + (m.rev || 0), cp, RW, RH, time, beat,
          { vp, pose, compW: this._rect ? this._rect.w : this.stateRef.comp.width, compH: this._rect ? this._rect.h : this.stateRef.comp.height });
        src.s3d = r; if (!r || !r.t) return; var isfOut = r; // eslint-disable-line no-var
      }
      const u = p.u; const lt = (layer && layer.transform) || { x: 0, y: 0, scale: 1, rotation: 0 };
      let tex = src.tex, w = src.w, h = src.h, gen = -1, scroll = 0;
      if (clip.type === 'gen') {
        const kind = clip.gen && clip.gen.kind;
        if (isfOut) { tex = isfOut.t; w = isfOut.w; h = isfOut.h; }
        else if (ANIM_GENS[kind]) { const at = this.animGen(src, clip, time, beat, this._rect ? this._rect.w : W, this._rect ? this._rect.h : H); tex = at.tex; w = at.w; h = at.h; }
        else if (CANVAS_GENS[kind]) { const ct = this.canvasGenTex(clip); tex = ct.tex; w = ct.w; h = ct.h; if (kind === 'text') scroll = (time * (clip.gen.params.scroll || 0) * 0.25) % 1; if (kind === 'text' && Math.abs(clip.gen.params.scroll || 0) > 0.0001) { w = W; } }
        else { gen = GEN_INDEX[kind] ?? 0; w = W; h = H; }
      }
      if (clip.bgr && clip.bgr.on && clip.type !== 'gen' && src.el && tex) { const r = this.bgrPass(src, clip.bgr, tex, w, h); if (r) tex = r; } // AI background removal
      const R = this._rect || { x: 0, y: 0, w: W, h: H };
      if (clip.type === 'gen' && this._rect) { w = R.w; h = R.h; }
      let sw = R.w, sh = R.h; const fit = clip.type === 'gen' ? 'stretch' : clip.fit || 'fill';
      if (fit === 'fill') { const s = Math.max(R.w / w, R.h / h); sw = w * s; sh = h * s; }
      else if (fit === 'fit') { const s = Math.min(R.w / w, R.h / h); sw = w * s; sh = h * s; }
      else if (fit === 'native') { sw = w; sh = h; }
      const sc = (clip.scale == null ? 1 : clip.scale) * (lt.scale == null ? 1 : lt.scale); sw *= sc; sh *= sc;
      const cx = (lt.x || 0) + (clip.x || 0) * (lt.scale ?? 1), cy = (lt.y || 0) + (clip.y || 0) * (lt.scale ?? 1);
      this.bindQuad(p);
      gl.uniform2f(u.u_res, W, H); gl.uniform2f(u.u_center, R.x + R.w / 2 + cx * R.w / 2, (H - R.y - R.h) + R.h / 2 + cy * R.h / 2);
      gl.uniform2f(u.u_size, sw, sh); gl.uniform1f(u.u_rot, -((clip.rotation || 0) + (lt.rotation || 0)) * Math.PI / 180);
      if (p !== this.pSrc) { // user shader
        gl.uniform2f(u.u_flip, 0, 0); gl.uniform1f(u.u_alpha, alpha * (clip.opacity == null ? 1 : clip.opacity));
        gl.uniform3f(u.iResolution, sw, sh, 1); gl.uniform1f(u.iTime, time); gl.uniform1f(u.iBeat, beat);
        const gp = clip.gen.params || {}; gl.uniform4f(u.iParam, +gp.p1 || 0, +gp.p2 || 0, +gp.p3 || 0, +gp.p4 || 0);
        const a = this.audio; gl.uniform4f(u.iAudio, a.level, a.bass, a.mid, a.high); if (u.iMouse) gl.uniform4f(u.iMouse, 0, 0, 0, 0);
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4); return;
      }
      gl.uniform2f(u.u_flip, clip.flipX ? 1 : 0, clip.flipY ? 1 : 0);
      gl.uniform1i(u.u_gen, gen); gl.uniform1f(u.u_alpha, alpha * (clip.opacity == null ? 1 : clip.opacity));
      gl.uniform1f(u.u_time, time); gl.uniform1f(u.u_beat, beat); gl.uniform1f(u.u_scroll, scroll);
      const gp = (clip.gen && clip.gen.params) || {};
      gl.uniform3fv(u.u_c1, BVJ.hex2rgb(gp.c1 || '#ffffff')); gl.uniform3fv(u.u_c2, BVJ.hex2rgb(gp.c2 || '#000000'));
      const kind = clip.gen && clip.gen.kind; let pv = [0, 0, 0, 0];
      if (kind === 'gradient') pv = [gp.angle, gp.speed, 0, 0]; else if (kind === 'plasma') pv = [gp.scale, gp.speed, 0, 0];
      else if (kind === 'bars') pv = [gp.count, gp.speed, gp.width, gp.angle]; else if (kind === 'checker') pv = [gp.size, gp.speed, 0, 0];
      else if (kind === 'rings') pv = [gp.count, gp.speed, 0, 0]; else if (kind === 'noise') pv = [gp.scale, 0, 0, 0]; else if (kind === 'beatflash') pv = [gp.decay, 0, 0, 0];
      gl.uniform4f(u.u_p, +pv[0] || 0, +pv[1] || 0, +pv[2] || 0, +pv[3] || 0); gl.uniform2f(u.u_size, sw, sh);
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, tex); gl.uniform1i(u.u_tex, 0);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    }
    // NDI tally: tell the camera / mixer whether its picture is on air (program) or loaded but hidden (preview)
    ndiTally(src, onAir) { const want = onAir ? 'p' : 'v'; if (src.tallySent === want || !window.pixoraNative || !window.pixoraNative.setTally) return; src.tallySent = want; window.pixoraNative.setTally(src.nativeId, onAir, !onAir); }
    // multiview: keep a small copy of each layer's image (after its effects, before opacity/blend)
    tapLayer(li, top) {
      const gl = this.gl, tw = this.tap.w, th = this.tap.h; const T = this.taps || (this.taps = []);
      let t = T[li]; if (!t || t.w !== tw || t.h !== th) { if (t) { gl.deleteFramebuffer(t.f); gl.deleteTexture(t.t); }
        const tx = this.tex(); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, tw, th, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
        const fb = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, fb); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tx, 0);
        t = T[li] = { f: fb, t: tx, w: tw, h: th }; }
      const p = this.pBlit; this.bindQuad(p); gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, top.t); gl.uniform1i(p.u.u_tex, 0);
      gl.uniform1f(p.u.u_alpha, 1); gl.uniform4f(p.u.u_rect, 0, 0, 1, 1); gl.disable(gl.BLEND);
      gl.bindFramebuffer(gl.FRAMEBUFFER, t.f); gl.viewport(0, 0, tw, th); gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      t.frame = this.frames + (this._fc = (this._fc || 0) + 1); t.at = performance.now();
    }
    // draw a texture into a pixel rectangle of the canvas (multiview layout); y from the top
    drawRect(tex, x, y, w, h, alpha, blend) {
      const gl = this.gl, p = this.pBlit; this.bindQuad(p); gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      gl.viewport(Math.round(x), Math.round(this.canvas.height - y - h), Math.round(w), Math.round(h));
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, tex); gl.uniform1i(p.u.u_tex, 0);
      gl.uniform1f(p.u.u_alpha, alpha == null ? 1 : alpha); gl.uniform4f(p.u.u_rect, 0, 0, 1, 1);
      if (blend) { gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA); } else gl.disable(gl.BLEND);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4); gl.disable(gl.BLEND);
    }
    blit(inp, out, alpha, rect, blend) {
      const gl = this.gl, p = this.pBlit; this.bindQuad(p);
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, inp.t); gl.uniform1i(p.u.u_tex, 0);
      gl.uniform1f(p.u.u_alpha, alpha == null ? 1 : alpha); const r = rect || [0, 0, 1, 1]; gl.uniform4f(p.u.u_rect, r[0], r[1], r[2], r[3]);
      if (blend) { gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA); } else gl.disable(gl.BLEND);
      this.drawFull(p, out); gl.disable(gl.BLEND);
    }
    fxActive(fx) { if (!fx) return false; for (const k in fx) if (fx[k] && fx[k].on) return true; return false; }
    isfTransitionOk(id) { const sh = (this.stateRef.shaders || []).find(x => x.id === id); return !!(sh && window.PixoraISF && PixoraISF.isISF(sh.code) && this.isfCompile(sh) && this.isfCompile(sh).prog); }
    // ISF transition: both sources drawn full strength into their own buffers, the shader mixes startImage → endImage by progress
    isfTransition(id, A, B, t, vals, time, beat, layer, comp, li) {
      const sh = (this.stateRef.shaders || []).find(x => x.id === id); if (!sh) return false; const gl = this.gl, W = this.W, H = this.H, fA = this.fA, ok = x => x && x.kind !== 'web';
      try { for (const [s, f] of [[A, this.fT1], [B, this.fT2]]) { this.fA = f; gl.bindFramebuffer(gl.FRAMEBUFFER, f.f); gl.viewport(0, 0, W, H); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT); if (ok(s)) this.drawLayerSource(s, 1, time, beat, layer, comp); } }
      finally { this.fA = fA; }
      const v = Object.assign({}, vals || {}, { progress: Math.max(0, Math.min(1, t)) });
      const res = this.isfRun(sh, 'T:' + li + ':' + sh.id, v, W, H, time, beat, { images: { startImage: { t: this.fT1.t, w: W, h: H }, endImage: { t: this.fT2.t, w: W, h: H }, inputImage: { t: this.fT2.t, w: W, h: H } } });
      gl.bindFramebuffer(gl.FRAMEBUFFER, fA.f); gl.viewport(0, 0, W, H); if (!res) return false;
      this.blit(res, fA, 1); gl.bindFramebuffer(gl.FRAMEBUFFER, fA.f); gl.viewport(0, 0, W, H); return true;
    }
    // draw one source into the layer FBO, running its clip-level effects first if it has any
    drawLayerSource(src, alpha, time, beat, layer, comp) {
      const rects = this.routeRects(layer, 'each');
      if (rects && rects.length) { const gl = this.gl; for (const r of rects) { gl.enable(gl.SCISSOR_TEST); gl.scissor(r.x, this.H - r.y - r.h, r.w, r.h); this._rect = r; this._drawLayerSource(src, alpha, time, beat, layer, comp); } this._rect = null; gl.disable(gl.SCISSOR_TEST); return; }
      this._drawLayerSource(src, alpha, time, beat, layer, comp);
    }
    routeRects(layer, mode) {
      const r = layer.route; if (!r || r.mode !== mode || !(r.screens || []).length) return null;
      return (this.stateRef.led.screens || []).filter(sc => r.screens.includes(sc.id)).map(sc => ({ x: sc.x | 0, y: sc.y | 0, w: (sc.panelW | 0) * (sc.cols | 0), h: (sc.panelH | 0) * (sc.rows | 0) }));
    }
    _drawLayerSource(src, alpha, time, beat, layer, comp) {
      const gl = this.gl, clip = src.clip;
      if (clip && this.fxActive(clip.fx)) {
        gl.bindFramebuffer(gl.FRAMEBUFFER, this.fC.f); gl.viewport(0, 0, this.W, this.H); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
        gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA); this.drawSource(src, clip, 1, time, beat, layer); gl.disable(gl.BLEND);
        this.runFx(this.fC, this.fD, clip.fx, time, beat, comp, 'C:' + (src._isfKey || (src._isfKey = 's' + (this._isfSeq = (this._isfSeq || 0) + 1))));
        this.blit(this.fD, this.fA, alpha, null, true);
      } else {
        gl.bindFramebuffer(gl.FRAMEBUFFER, this.fA.f); gl.viewport(0, 0, this.W, this.H);
        gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA); this.drawSource(src, clip, alpha, time, beat, layer); gl.disable(gl.BLEND);
      }
    }
    // effects: the fixed single-pass chain, then any post slots (ISF effects, LUTs) each in their own pass
    postSlots(fx) { const out = []; for (const id of ['isf', 'isf2', 'lut', 'lut2']) if (fx[id] && fx[id].on) out.push(id); return out; }
    runFx(inp, out, fx, time, beat, comp, ikey) {
      const post = this.postSlots(fx); if (!post.length) return this.runFxCore(inp, out, fx, time, beat, comp);
      this.runFxCore(inp, this.fE, fx, time, beat, comp); let cur = this.fE, alt = this.fF;
      post.forEach((id, k) => { const dst = k === post.length - 1 ? out : alt; if (!this.runPost(id, fx[id], cur, dst, time, beat, (ikey || 'fx') + ':' + id)) this.blit(cur, dst, 1, null, false); [cur, alt] = [dst, cur]; });
    }
    runPost(id, f, cur, dst, time, beat, ikey) {
      const gl = this.gl;
      if (id === 'isf' || id === 'isf2') {
        const sh = (this.stateRef.shaders || []).find(x => x.id === f.shader); if (!sh || !window.PixoraISF || !PixoraISF.isISF(sh.code)) return false;
        const res = this.isfRun(sh, ikey + ':' + sh.id, f.v, this.W, this.H, time, beat, { images: { inputImage: { t: cur.t, w: this.W, h: this.H } } }); if (!res) return false;
        return this.mixPass(cur, res.t, Math.max(0, Math.min(1, f.mix ?? 1)), dst);
      }
      if ((id === 'lut' || id === 'lut2') && this.lutPass) return this.lutPass(f, cur, dst);
      return false;
    }
    mixPass(a, bTex, mix, dst) {
      const gl = this.gl, p = this.pMix; this.bindQuad(p);
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, a.t); gl.uniform1i(p.u.u_a, 0);
      gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, bTex); gl.uniform1i(p.u.u_b, 1); gl.uniform1f(p.u.u_mix, mix);
      gl.disable(gl.BLEND); this.drawFull(p, dst); gl.activeTexture(gl.TEXTURE0); return true;
    }
    runFxCore(inp, out, fx, time, beat, comp) {
      const gl = this.gl, p = this.pFx, u = p.u; this.bindQuad(p);
      const f = (id, k) => (fx[id] ? +fx[id][k] || 0 : 0), on = id => fx[id] && fx[id].on ? 1 : 0;
      gl.uniform2f(u.u_res, this.W, this.H); gl.uniform1f(u.u_time, time); gl.uniform1f(u.u_beat, beat);
      let gate = 1;
      if (on('strobe')) { const per = S.STROBE_RATES[fx.strobe.rate | 0] || 1; gate = ((beat / per) % 1) < f('strobe', 'duty') ? 1 : 0; }
      gl.uniform1f(u.u_gate, gate);
      gl.uniform1f(u.u_colOn, on('color')); gl.uniform1f(u.u_bri, f('color', 'brightness')); gl.uniform1f(u.u_con, f('color', 'contrast')); gl.uniform1f(u.u_sat, f('color', 'saturation')); gl.uniform1f(u.u_hue, f('color', 'hue'));
      gl.uniform1f(u.u_tintOn, on('tint')); gl.uniform1f(u.u_tintAmt, f('tint', 'amount')); gl.uniform3fv(u.u_tintCol, BVJ.hex2rgb((fx.tint && fx.tint.color) || '#ff2a6d'));
      gl.uniform1f(u.u_invOn, on('invert')); gl.uniform1f(u.u_invAmt, f('invert', 'amount'));
      gl.uniform1f(u.u_posOn, on('posterize')); gl.uniform1f(u.u_posLv, Math.max(2, f('posterize', 'levels')));
      gl.uniform1f(u.u_pixOn, on('pixelate')); gl.uniform1f(u.u_pixSz, f('pixelate', 'size'));
      gl.uniform1f(u.u_mirOn, on('mirror')); gl.uniform1f(u.u_mirMode, f('mirror', 'mode'));
      gl.uniform1f(u.u_kalOn, on('kaleido')); gl.uniform1f(u.u_kalSeg, Math.max(2, f('kaleido', 'segments'))); gl.uniform1f(u.u_kalSpin, f('kaleido', 'spin'));
      gl.uniform1f(u.u_wavOn, on('wave')); gl.uniform1f(u.u_wavAmt, f('wave', 'amount')); gl.uniform1f(u.u_wavFreq, f('wave', 'freq')); gl.uniform1f(u.u_wavSpd, f('wave', 'speed'));
      gl.uniform1f(u.u_rgbOn, on('rgbshift') ? (fx.rgbshift.beat == 1 ? 2 : 1) : 0); gl.uniform1f(u.u_rgbAmt, f('rgbshift', 'amount'));
      gl.uniform1f(u.u_blurOn, on('blur')); gl.uniform1f(u.u_blurR, f('blur', 'radius'));
      gl.uniform1f(u.u_edgeOn, on('edge')); gl.uniform1f(u.u_edgeAmt, f('edge', 'amount'));
      gl.uniform1f(u.u_vigOn, on('vignette')); gl.uniform1f(u.u_vigAmt, f('vignette', 'amount'));
      gl.uniform1f(u.u_ckOn, on('chroma')); gl.uniform3fv(u.u_ckCol, BVJ.hex2rgb((fx.chroma && fx.chroma.color) || '#00ff40'));
      gl.uniform1f(u.u_ckTol, f('chroma', 'tolerance')); gl.uniform1f(u.u_ckSoft, f('chroma', 'softness')); gl.uniform1f(u.u_ckSpill, f('chroma', 'spill'));
      gl.uniform1f(u.u_ckChoke, f('chroma', 'choke')); gl.uniform1f(u.u_ckView, f('chroma', 'view'));
      gl.uniform1f(u.u_lkOn, on('lumakey')); gl.uniform1f(u.u_lkTh, f('lumakey', 'threshold')); gl.uniform1f(u.u_lkSoft, f('lumakey', 'softness')); gl.uniform1f(u.u_lkInv, f('lumakey', 'invert'));
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, inp.t); gl.uniform1i(u.u_tex, 0);
      gl.disable(gl.BLEND); this.drawFull(p, out);
    }

    /* ---------------- main frame */
    render(state) {
      const gl = this.gl, comp = state.comp, now = performance.now();
      const dt = Math.min(0.1, (now - this.lastT) / 1000); this.lastT = now;
      const W = Math.max(1, Math.min(8192, comp.width | 0)), H = Math.max(1, Math.min(8192, comp.height | 0));
      this.resize(W, H, state.comp.precision === '16f'); this.stateRef = state; if ((this._swp = (this._swp || 0) + 1) % 120 === 0) this.isfSweep();
      const restore = this.applyMods(state);
      const time = BVJ.now() / 1000 % 100000, beat = BVJ.beat(comp);
      this.st = state;
      const layers = (state.overlays || []).some(o => o.clip) ? state.layers.concat(state.overlays.map((o, i) => Object.assign({}, OVERLAY_LAYER, { id: 'overlay' + i, name: 'Overlay ' + (i + 1), clips: [o.clip], active: o.on && o.clip ? 0 : null, trig: o.trig || 0,
        transition: o.transition || 'fade', transitionDur: o.dur ?? 0.5, volume: o.volume ?? 1, overlay: true }))) : state.layers; const anySolo = layers.some(l => l.solo);
      while (this.layers.length < layers.length) this.layers.push({});
      // clear base composition to bg colour
      const bg = BVJ.hex2rgb(comp.bg);
      gl.bindFramebuffer(gl.FRAMEBUFFER, this.cA.f); gl.viewport(0, 0, W, H); gl.clearColor(bg[0], bg[1], bg[2], 1); gl.clear(gl.COLOR_BUFFER_BIT);
      let base = this.cA, other = this.cB;
      const positions = [];
      const keepIds = new Set();
      layers.forEach((layer, li) => {
        const rt = this.layers[li] || (this.layers[li] = {});
        // layer identity changed (reorder/remove) -> reset runtime
        if (rt.id !== layer.id) { this.disposeSource(rt.cur); this.disposeSource(rt.prev); this.disposeSource(rt.tb); this.disposeSource(rt.sting); rt.tb = rt.sting = null; Object.assign(rt, { id: layer.id, cur: null, prev: null, trig: -1, key: null, pending: null }); }
        let clip = layer.active != null ? (layer.activeClip || layer.clips[layer.active]) : null;
        if (clip && clip.type === 'playlist') clip = this.playlistItem(clip); // a playlist plays as its current item
        // new trigger / clip change
        if (!clip) { if (rt.cur) { rt.prev && this.disposeSource(rt.prev); rt.prev = rt.cur; rt.cur = null; rt.transStart = now; rt.transMode = layer.transition === 'stinger' ? 'fade' : layer.transition; rt.transVals = layer.transitionIsf || {}; rt.transDur = layer.transition === 'cut' ? 0 : layer.transitionDur * 1000; } rt.trig = layer.trig; rt.key = null; }
        else if (rt.trig !== layer.trig || rt.key !== this.clipKey(clip)) {
          const key = this.clipKey(clip);
          if (rt.cur && rt.key === key && rt.cur.kind === 'hap' && rt.trig !== layer.trig) { rt.cur.vt = null; rt.cur.held = false; rt.cur.dir = 1; }
          else if (rt.cur && rt.key === key && clip.type === 'video' && rt.trig !== layer.trig && rt.cur.el) { // retrigger same clip: restart
            rt.cur.el.currentTime = (clip.inPt || 0) * (rt.cur.el.duration || 0); rt.cur.held = false; rt.cur.dir = 1; if (!layer.paused) rt.cur.el.play().catch(() => {});
          } else if (rt.cur && rt.key === key && rt.trig === layer.trig) { /* same */ }
          else if (rt.tb && rt.tbKey === key) { if (rt.prev) this.disposeSource(rt.prev); rt.prev = null; this.disposeSource(rt.cur); rt.cur = rt.tb; rt.tb = null; rt.tbKey = null; rt.transDur = 0; if (rt.pending) { this.disposeSource(rt.pending); rt.pending = null; } } // T-bar finished: keep the frame on screen
          else { if (rt.pending) this.disposeSource(rt.pending); rt.pending = this.makeSource(clip, li); rt.pendingAt = now; }
          rt.trig = layer.trig; rt.key = key; rt.loops = 0;
        }
        if (rt.cur && !rt.pending) rt.cur.clip = clip || rt.cur.clip; // live edits reach the playing source; while the next clip loads, the outgoing one keeps its own settings
        // promote pending source once it has a frame (or after 1.5s timeout) -> start crossfade
        if (rt.pending) {
          const pd = rt.pending; if (pd.el && pd.el.tagName === 'VIDEO') this.updateVideo(pd, clip || pd.clip, layer, comp, dt, li, rt); else if (pd.kind === 'hap') this.updateHap(pd, clip || pd.clip, layer, comp, dt, li, rt);
          if (pd.ready || pd.error || now - rt.pendingAt > 1500) {
            if (rt.prev) this.disposeSource(rt.prev);
            rt.prev = rt.cur; rt.cur = pd; rt.pending = null; rt.transStart = now;
            const ct = pd.clip && pd.clip.transition && pd.clip.transition !== 'layer' ? pd.clip : null;
            let mode = ct ? ct.transition : layer.transition; const dur = ct ? ct.transitionDur : layer.transitionDur;
            if (layer.cutTrig != null && layer.cutTrig === layer.trig) mode = 'cut'; // switcher CUT
            rt.transMode = mode; rt.transDur = mode === 'cut' || !rt.prev ? 0 : (dur || 0) * 1000; rt.transVals = (ct ? ct.transitionIsf : layer.transitionIsf) || {};
            if (mode === 'stinger' && rt.prev && layer.stinger && layer.stinger.src) { // stinger: a video over the change, swap at the cut point
              if (rt.sting) this.disposeSource(rt.sting); rt.sting = this.makeSource(Object.assign({ type: 'video', fit: 'stretch', loop: 'once' }, layer.stinger), li); rt.stingCut = layer.stinger.cut ?? 0.5;
              rt.transDur = Math.max(200, (layer.stinger.dur || dur || 1.5) * 1000); if (rt.sting.el) { try { rt.sting.el.loop = false; rt.sting.el.currentTime = 0; rt.sting.el.play().catch(() => {}); } catch {} } }
          }
        }
        // update playback
        if (rt.cur && rt.cur.el && rt.cur.el.tagName === 'VIDEO' && clip) { this.updateVideo(rt.cur, clip, layer, comp, dt, li, rt); this.upload(rt.cur); }
        else if (rt.cur && rt.cur.kind === 'hap' && clip) this.updateHap(rt.cur, clip, layer, comp, dt, li, rt);
        if (rt.cur && rt.cur.kind === 'native') this.upload(rt.cur); if (rt.prev && rt.prev.kind === 'native') this.upload(rt.prev);
        for (const sx of [rt.cur, rt.prev]) if (sx && sx.kind === 'replay' && this.replay) { const f = this.replay.frame(sx.clip && sx.clip.unit, window.BVJ ? BVJ.now() : Date.now());
          if (f && f !== sx.shown) { sx.shown = f; gl.bindTexture(gl.TEXTURE_2D, sx.tex); try { gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, f); sx.w = f.displayWidth; sx.h = f.displayHeight; } catch {} } }
        let t = rt.transDur > 0 ? Math.min(1, (now - rt.transStart) / rt.transDur) : 1;
        const sw = state.switcher; let tbar = 0;
        if (sw && sw.on && sw.layer === li && sw.tbar > 0 && sw.preview != null && sw.preview !== layer.active && layer.clips[sw.preview]) {
          const pc = layer.clips[sw.preview], k = this.clipKey(pc);
          if (!rt.tb || rt.tbKey !== k) { if (rt.tb) this.disposeSource(rt.tb); rt.tb = this.makeSource(pc, li); rt.tbKey = k; }
          if (rt.tb.el && rt.tb.el.tagName === 'VIDEO') { if (rt.tb.el.paused) rt.tb.el.play().catch(() => {}); this.upload(rt.tb); } else if (rt.tb.kind === 'native') this.upload(rt.tb);
          tbar = sw.tbar;
        } else if (rt.tb && !(sw && sw.on && sw.layer === li && sw.preview != null)) { this.disposeSource(rt.tb); rt.tb = null; rt.tbKey = null; }
        if (rt.sting && rt.sting.el) this.upload(rt.sting);
        if (rt.sting && t >= 1) { this.disposeSource(rt.sting); rt.sting = null; }
        if (t >= 1 && rt.prev) { this.disposeSource(rt.prev); rt.prev = null; }
        if (rt.prev && rt.prev.el && rt.prev.el.tagName === 'VIDEO') this.upload(rt.prev);
        positions.push(rt.cur && rt.cur.dur ? { pos: rt.cur.pos, t: rt.cur.t, dur: rt.cur.dur } : null);

        // visibility
        let op = layer.opacity;
        if (layer.xfade === 'A') op *= Math.min(1, 2 * (1 - comp.crossfader)); else if (layer.xfade === 'B') op *= Math.min(1, 2 * comp.crossfader);
        const visible = !layer.bypass && (!anySolo || layer.solo) && op > 0.001 && (rt.cur || rt.prev || (tbar && rt.tb));
        if (!this.noTally) for (const sx of [rt.cur, rt.prev]) if (sx && sx.nativeId != null && sx.clip && sx.clip.type === 'ndi') this.ndiTally(sx, visible && !comp.blackout && comp.master > 0.001);
        for (const sx of [rt.cur, rt.prev]) if (sx && sx.ndiGain) sx.ndiGain((this.audioUnlocked ? 1 : 0) * (comp.mute ? 0 : comp.volume ?? 1) * (layer.mute ? 0 : layer.volume ?? 1) * (layer.afv && !(layer.opacity > 0.001) ? 0 : 1) * (visible && !comp.blackout ? 1 : 0) * (sx === rt.cur ? (rt.prev ? t : 1) : 1 - t));
        rt.webOpacity = visible ? op : 0; rt.webClip = rt.cur && rt.cur.kind === 'web' ? rt.cur.clip : null; rt.webT = t;
        if (!visible) return;
        if ((!rt.cur || rt.cur.kind === 'web') && (!rt.prev || rt.prev.kind === 'web') && !(tbar && rt.tb)) return;
        // pass 1: source(s) into layer FBO
        gl.bindFramebuffer(gl.FRAMEBUFFER, this.fA.f); gl.viewport(0, 0, W, H); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
        gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
        gl.disable(gl.BLEND);
        { // transition styles: fade · cut · dip · wipe-left/right/up/down · split · stinger; T-bar drives the same styles by hand
          const A = tbar ? rt.cur : rt.prev, Bs = tbar ? rt.tb : rt.cur, tt = tbar || t, mode = tbar ? (layer.transition === 'stinger' ? 'fade' : layer.transition || 'fade') : rt.transMode || 'fade';
          const ok = x => x && x.kind !== 'web', going = A && Bs && tt < 1;
          if (!going || mode === 'fade' || mode === 'cut' || (typeof mode === 'string' && mode.startsWith('isf:') && !this.isfTransitionOk(mode.slice(4)))) { if (ok(A)) this.drawLayerSource(A, 1 - (Bs ? 0 : tt), time, beat, layer, comp); if (ok(Bs)) this.drawLayerSource(Bs, A ? tt : 1, time, beat, layer, comp); }
          else if (typeof mode === 'string' && mode.startsWith('isf:') && this.isfTransition(mode.slice(4), A, Bs, tt, tbar ? layer.transitionIsf : rt.transVals, time, beat, layer, comp, li)) {}
          else if (mode === 'dip') { if (ok(A) && tt < 0.5) this.drawLayerSource(A, 1 - tt * 2, time, beat, layer, comp); if (ok(Bs) && tt >= 0.5) this.drawLayerSource(Bs, tt * 2 - 1, time, beat, layer, comp); }
          else if (mode === 'stinger') { if (tt < (rt.stingCut ?? 0.5)) { if (ok(A)) this.drawLayerSource(A, 1, time, beat, layer, comp); } else if (ok(Bs)) this.drawLayerSource(Bs, 1, time, beat, layer, comp);
            if (rt.sting && rt.sting.ready) this.drawLayerSource(rt.sting, 1, time, beat, Object.assign({}, layer, { transform: null }), comp); }
          else { // wipes: new source revealed inside a growing rectangle
            if (ok(A)) this.drawLayerSource(A, 1, time, beat, layer, comp);
            const w = Math.round(W * tt), h = Math.round(H * tt), r = { 'wipe-left': [0, 0, w, H], 'wipe-right': [W - w, 0, w, H], 'wipe-up': [0, 0, W, h], 'wipe-down': [0, H - h, W, h], split: [Math.round((W - w) / 2), 0, w, H] }[mode] || [0, 0, W, H];
            gl.enable(gl.SCISSOR_TEST); gl.scissor(r[0], r[1], r[2], r[3]); if (ok(Bs)) this.drawLayerSource(Bs, 1, time, beat, layer, comp); gl.disable(gl.SCISSOR_TEST); }
        }
        // pass 2: effects
        let top = this.fA;
        if (this.fxActive(layer.fx)) { this.runFx(this.fA, this.fB, layer.fx, time, beat, comp, 'L:' + layer.id); top = this.fB; }
        if (this.tap) this.tapLayer(li, top);
        // pass 3: blend onto composition
        const pc = this.pComp; this.bindQuad(pc);
        gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, base.t); gl.uniform1i(pc.u.u_base, 0);
        gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, top.t); gl.uniform1i(pc.u.u_top, 1);
        gl.uniform1i(pc.u.u_mode, BLEND_INDEX[layer.blend] || 0); gl.uniform1f(pc.u.u_op, op);
        const mk = layer.mask || {}; const mt = { none: 0, rect: 1, ellipse: 2, 'luma matte': 3, 'alpha matte': 4 }[mk.type] || 0;
        gl.uniform1i(pc.u.u_mask, mt); gl.uniform2f(pc.u.u_res, W, H);
        gl.uniform4f(pc.u.u_mrect, mk.x || 0, 1 - (mk.y || 0) - (mk.h ?? 1), (mk.x || 0) + (mk.w ?? 1), 1 - (mk.y || 0));
        gl.uniform1f(pc.u.u_feather, mk.feather || 0); gl.uniform1f(pc.u.u_inv, mk.invert ? 1 : 0);
        gl.activeTexture(gl.TEXTURE2); gl.bindTexture(gl.TEXTURE_2D, this.fM.t); gl.uniform1i(pc.u.u_matte, 2);
        const mr = this.routeRects(layer, 'mask') || []; gl.uniform1i(pc.u.u_scrN, Math.min(8, mr.length));
        if (mr.length) { const arr = new Float32Array(32); mr.slice(0, 8).forEach((r, i) => arr.set([r.x / W, 1 - (r.y + r.h) / H, (r.x + r.w) / W, 1 - r.y / H], i * 4)); gl.uniform4fv(pc.u['u_scr[0]'], arr); }
        this.drawFull(pc, other); gl.activeTexture(gl.TEXTURE0);
        [base, other] = [other, base];
        // keep this layer's image as the matte source for the layer above (track matte)
        const nx = layers[li + 1]; if (nx && nx.mask && /matte/.test(nx.mask.type)) this.blit(top, this.fM, 1);
      });
      // drop runtimes for removed layers
      for (let i = layers.length; i < this.layers.length; i++) { const rt = this.layers[i]; if (rt) { this.disposeSource(rt.cur); this.disposeSource(rt.prev); this.disposeSource(rt.pending); this.disposeSource(rt.tb); this.disposeSource(rt.sting); } }
      this.layers.length = layers.length;
      // composition fx
      if (this.fxActive(comp.fx)) { this.runFx(base, other, comp.fx, time, beat, comp, 'comp'); [base, other] = [other, base]; }
      // final -> cF (composition result), then map to the screen
      const pf = this.pFinal; this.bindQuad(pf);
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, base.t); gl.uniform1i(pf.u.u_tex, 0);
      gl.uniform1f(pf.u.u_master, comp.blackout ? 0 : comp.master);
      this.drawFull(pf, this.cF);
      if (state.led && state.led.test && state.led.test.on) this.drawLedTest(state, time);
      if (this.customPresent) this.customPresent(this); else this.present();
      restore();
      this.frames++; if (now - this._fpsT > 1000) { this.fps = this.frames * 1000 / (now - this._fpsT); this.frames = 0; this._fpsT = now; }
      const ft = now - (this._lastFrame || now); this._lastFrame = now; const st = this.stats || (this.stats = { ftAvg: 16.7, ftMax: 0, dropped: 0, _maxT: now });
      if (ft > 0) { st.ftAvg = st.ftAvg * 0.95 + ft * 0.05; if (ft > st.ftMax) st.ftMax = ft; if (ft > 1000 / 60 * 1.8) st.dropped++; } if (now - st._maxT > 5000) { st.ftMax = ft; st._maxT = now; }
      return positions;
    }
  }
  // square (0..1) -> quad homography, returns column-major mat3 of its inverse for GLSL
  function homography(q) {
    const [[x0, y0], [x1, y1], [x2, y2], [x3, y3]] = q;
    const dx1 = x1 - x2, dx2 = x3 - x2, dy1 = y1 - y2, dy2 = y3 - y2, sx = x0 - x1 + x2 - x3, sy = y0 - y1 + y2 - y3;
    let g = 0, h = 0; const den = dx1 * dy2 - dx2 * dy1;
    if (Math.abs(den) > 1e-12) { g = (sx * dy2 - dx2 * sy) / den; h = (dx1 * sy - sx * dy1) / den; }
    const a = x1 - x0 + g * x1, b = x3 - x0 + h * x3, c = x0, d = y1 - y0 + g * y1, e = y3 - y0 + h * y3, f = y0;
    const m = [a, b, c, d, e, f, g, h, 1]; // row-major forward
    const A = m[4] * m[8] - m[5] * m[7], B = -(m[3] * m[8] - m[5] * m[6]), C = m[3] * m[7] - m[4] * m[6];
    const det = m[0] * A + m[1] * B + m[2] * C || 1e-12;
    const inv = [A, -(m[1] * m[8] - m[2] * m[7]), m[1] * m[5] - m[2] * m[4],
      B, m[0] * m[8] - m[2] * m[6], -(m[0] * m[5] - m[2] * m[3]),
      C, -(m[0] * m[7] - m[1] * m[6]), m[0] * m[4] - m[1] * m[3]].map(v => v / det);
    return new Float32Array([inv[0], inv[3], inv[6], inv[1], inv[4], inv[7], inv[2], inv[5], inv[8]]); // to column-major
  }
  function interp(pts, t) { if (!pts.length) return null; if (t <= pts[0][0]) return pts[0][1]; for (let i = 1; i < pts.length; i++) if (t < pts[i][0]) { const [t0, v0] = pts[i - 1], [t1, v1] = pts[i]; return v0 + (v1 - v0) * ((t - t0) / ((t1 - t0) || 1)); } return pts[pts.length - 1][1]; }
  Object.assign(Engine.prototype, {
    // modulators (LFO + audio) override numeric params for this frame only
    applyMods(state) {
      const mods = (state.mods || []).filter(m => m.on && m.path); const saved = [];
      const setv = (pth, val) => { const keys = pth.split('.'); let o = state; for (let i = 0; i < keys.length - 1 && o; i++) o = o[keys[i]]; const k = keys[keys.length - 1]; if (!o || typeof o[k] !== 'number') return; saved.push([o, k, o[k]]); o[k] = val; };
      // timeline automation lanes
      const tl = state.timeline; if (tl && (tl.lanes || []).length && (tl.play.playing || tl.play.pos > 0)) { const pl = tl.play; const pos = pl.playing ? pl.pos + (BVJ.now() - pl.startAt) / 1000 : pl.pos;
        for (const ln of tl.lanes) { if (!ln.on || !(ln.points || []).length) continue; const v = interp(ln.points, pos); if (v != null) setv(ln.path, v); } }
      // timeline clip fades: each item's fade in / out scales its layer's opacity
      if (tl && (tl.tracks || []).length && (tl.play.playing || tl.play.pos > 0)) { const pl = tl.play, pos = pl.playing ? pl.pos + (BVJ.now() - pl.startAt) / 1000 : pl.pos;
        for (const tr of tl.tracks) { if (tr.mute) continue; const it = tr.items.find(x => pos >= x.start && pos < x.start + x.dur); if (!it || !(+it.fadeIn > 0 || +it.fadeOut > 0)) continue;
          const li = state.layers.findIndex(l => l.id === tr.layerId); if (li < 0) continue;
          let f = 1; if (+it.fadeIn > 0) f = Math.min(f, (pos - it.start) / it.fadeIn); if (+it.fadeOut > 0) f = Math.min(f, (it.start + it.dur - pos) / it.fadeOut);
          setv(`layers.${li}.opacity`, state.layers[li].opacity * Math.max(0, Math.min(1, f))); } }
      // clip automation (recorded live moves) — relative to the layer
      state.layers.forEach((l, li) => { const c = l.active != null ? (l.activeClip || l.clips[l.active]) : null; const a = c && c.auto; if (!a || a.on === false || !a.paths) return;
        const t = ((BVJ.now() - (l.trigAt || 0)) / 1000) % Math.max(0.1, a.len || 1); for (const [rel, pts] of Object.entries(a.paths)) { const v = interp(pts, t); if (v != null) setv(`layers.${li}.${rel}`, v); } });
      if (!mods.length) return () => { for (let i = saved.length - 1; i >= 0; i--) saved[i][0][saved[i][1]] = saved[i][2]; };
      const beat = BVJ.beat(state.comp);
      for (const m of mods) {
        let v;
        if (m.src === 'audio') v = Math.min(1, (this.audio[m.band] || 0) * (state.comp.audio.gain || 1));
        else { const ph = beat / Math.max(0.0625, m.rate || 4); const f = ph - Math.floor(ph);
          v = m.shape === 'triangle' ? 1 - Math.abs(f * 2 - 1) : m.shape === 'saw' ? f : m.shape === 'square' ? (f < 0.5 ? 1 : 0)
            : m.shape === 'random' ? (Math.sin(Math.floor(ph) * 12.9898 + (m.id || '').length * 78.233) * 43758.5453 % 1 + 1) % 1 : 0.5 + 0.5 * Math.sin(f * Math.PI * 2); }
        const val = (+m.min || 0) + ((m.max == null ? 1 : +m.max) - (+m.min || 0)) * v;
        const keys = m.path.split('.'); let o = state; for (let i = 0; i < keys.length - 1 && o; i++) o = o[keys[i]];
        const k = keys[keys.length - 1]; if (!o || typeof o[k] !== 'number') continue;
        saved.push([o, k, o[k]]); o[k] = val;
      }
      return () => { for (let i = saved.length - 1; i >= 0; i--) saved[i][0][saved[i][1]] = saved[i][2]; };
    },
    setOutput(out) { this.output = out; },
    // mesh control points -> dense, smooth (Catmull-Rom) triangle list [x,y,u,v]*
    meshVerts(mesh) {
      const key = mesh.cols + 'x' + mesh.rows + ':' + mesh.pts.map(p => p[0] + ',' + p[1]).join(';');
      const hit = this.meshCache.get(mesh); if (hit && hit.key === key) return hit.v;
      const C = mesh.cols, R = mesh.rows, P = (k, r) => mesh.pts[Math.max(0, Math.min(R, r)) * (C + 1) + Math.max(0, Math.min(C, k))];
      // extrapolate past the edges so the outer cells stay straight-ish rather than pinched
      const G = (k, r) => { const kk = Math.max(0, Math.min(C, k)), rr = Math.max(0, Math.min(R, r)); const b = P(kk, rr); if (kk === k && rr === r) return b;
        const ik = kk === k ? kk : (k < 0 ? 1 : C - 1), ir = rr === r ? rr : (r < 0 ? 1 : R - 1); const i = P(ik, ir); return [2 * b[0] - i[0], 2 * b[1] - i[1]]; };
      const cr = (a, b, c, d, t) => { const t2 = t * t, t3 = t2 * t; return 0.5 * (2 * b + (c - a) * t + (2 * a - 5 * b + 4 * c - d) * t2 + (3 * b - a - 3 * c + d) * t3); };
      const S = Math.max(2, Math.min(12, Math.round(48 / Math.max(C, R)))); const NX = C * S, NY = R * S, grid = [];
      for (let j = 0; j <= NY; j++) for (let i = 0; i <= NX; i++) {
        const k = Math.min(C - 1, Math.floor(i / S)), r = Math.min(R - 1, Math.floor(j / S)), tx = i / S - k, ty = j / S - r, out = [0, 0];
        for (const ax of [0, 1]) { const rows = [-1, 0, 1, 2].map(dr => cr(G(k - 1, r + dr)[ax], G(k, r + dr)[ax], G(k + 1, r + dr)[ax], G(k + 2, r + dr)[ax], tx)); out[ax] = cr(rows[0], rows[1], rows[2], rows[3], ty); }
        grid.push([out[0], out[1], i / NX, j / NY]); }
      const v = new Float32Array(NX * NY * 24); let o = 0; const at = (i, j) => grid[j * (NX + 1) + i];
      for (let j = 0; j < NY; j++) for (let i = 0; i < NX; i++) for (const q of [at(i, j), at(i + 1, j), at(i, j + 1), at(i + 1, j), at(i + 1, j + 1), at(i, j + 1)]) { v[o++] = q[0]; v[o++] = q[1]; v[o++] = q[2]; v[o++] = q[3]; }
      this.meshCache.set(mesh, { key, v }); return v;
    },
    overlayTex(cv, slot) {
      const gl = this.gl; this.ovTex = this.ovTex || {}; let t = this.ovTex[slot]; if (!t) t = this.ovTex[slot] = this.tex(); else gl.bindTexture(gl.TEXTURE_2D, t);
      if (t._src !== cv || cv._dirty) { gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, cv); t._src = cv; cv._dirty = false; }
      return t;
    },
    drawOverlay(cv, OW, OH, blend) {
      const gl = this.gl, p = this.pOver; const t = this.overlayTex(cv, blend ? 'mask' : 'test');
      gl.useProgram(p); gl.bindBuffer(gl.ARRAY_BUFFER, this.buf); gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, t); gl.uniform1i(p.u.u_tex, 0); gl.uniform2f(p.u.u_out, OW, OH);
      if (blend) gl.enable(gl.BLEND); else gl.disable(gl.BLEND); gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    },
    maskCanvas(masks, W, H) {
      const key = W + 'x' + H + JSON.stringify(masks.map(m => [m.pts, m.invert, m.feather]));
      if (this.mCv && this.mCv._key === key) return this.mCv;
      const cv = this.mCv || (this.mCv = document.createElement('canvas')); cv.width = W; cv.height = H; const x = cv.getContext('2d');
      x.fillStyle = '#fff'; x.fillRect(0, 0, W, H);
      for (const m of masks) {
        const tmp = document.createElement('canvas'); tmp.width = W; tmp.height = H; const t = tmp.getContext('2d'); const fe = Math.max(0, +m.feather || 0) * Math.max(W, H);
        t.fillStyle = '#fff'; t.fillRect(0, 0, W, H); t.filter = fe > 0.5 ? `blur(${fe.toFixed(1)}px)` : 'none';
        t.beginPath(); m.pts.forEach(([a, b], i) => i ? t.lineTo(a * W, b * H) : t.moveTo(a * W, b * H)); t.closePath();
        if (m.invert) { t.fillStyle = '#000'; t.fillRect(0, 0, W, H); t.globalCompositeOperation = 'source-over'; t.fillStyle = '#fff'; t.fill(); } else { t.fillStyle = '#000'; t.fill(); }
        x.globalCompositeOperation = 'multiply'; x.drawImage(tmp, 0, 0); x.globalCompositeOperation = 'source-over';
      }
      cv._key = key; cv._dirty = true; return cv;
    },
    // projector alignment patterns drawn in output pixels
    testCanvas(out, W, H, kind) {
      const key = kind + W + 'x' + H + (out.name || '') + (kind === 'align' ? ':' + (out.alignFrame | 0) : '');
      const slot = out.test === 'warped' ? 'src' : 'out'; this.tCv = this.tCv || {}; let cv = this.tCv[slot];
      if (!cv) cv = this.tCv[slot] = document.createElement('canvas');
      if (cv._key === key) return cv;
      cv.width = W; cv.height = H; const x = cv.getContext('2d');
      if (kind === 'white') { x.fillStyle = '#fff'; x.fillRect(0, 0, W, H); }
      else if (kind === 'black') { x.fillStyle = '#000'; x.fillRect(0, 0, W, H); }
      else if (kind === 'align') { if (window.PixoraAlign) window.PixoraAlign.draw(x, W, H, out.alignFrame | 0); else { x.fillStyle = '#000'; x.fillRect(0, 0, W, H); } }
      else {
        x.fillStyle = '#000'; x.fillRect(0, 0, W, H); const u = Math.max(W, H) / 32, lw = Math.max(1, Math.round(Math.min(W, H) / 540));
        x.strokeStyle = '#7a7a7a'; x.lineWidth = lw; x.beginPath();
        for (let gx = W / 2 % u; gx <= W; gx += u) { x.moveTo(Math.round(gx) + 0.5, 0); x.lineTo(Math.round(gx) + 0.5, H); }
        for (let gy = H / 2 % u; gy <= H; gy += u) { x.moveTo(0, Math.round(gy) + 0.5); x.lineTo(W, Math.round(gy) + 0.5); } x.stroke();
        x.strokeStyle = '#fff'; x.lineWidth = lw * 2; x.strokeRect(lw, lw, W - lw * 2, H - lw * 2);
        x.beginPath(); x.moveTo(W / 2, 0); x.lineTo(W / 2, H); x.moveTo(0, H / 2); x.lineTo(W, H / 2); x.moveTo(0, 0); x.lineTo(W, H); x.moveTo(W, 0); x.lineTo(0, H); x.stroke();
        x.beginPath(); x.arc(W / 2, H / 2, Math.min(W, H) * 0.45, 0, Math.PI * 2); x.stroke();
        for (const [cx, cy] of [[0.12, 0.12], [0.88, 0.12], [0.12, 0.88], [0.88, 0.88]]) { x.beginPath(); x.arc(cx * W, cy * H, Math.min(W, H) * 0.08, 0, Math.PI * 2); x.stroke(); }
        const cols = ['#ff2a2a', '#2aff2a', '#2a6bff', '#fff']; cols.forEach((c, i) => { x.fillStyle = c; x.fillRect(W / 2 - u * 2 + i * u, H / 2 + u * 1.5, u, u * 0.6); });
        x.fillStyle = '#fff'; x.font = `600 ${Math.round(u * 0.7)}px Inter, Arial, sans-serif`; x.textAlign = 'center'; x.fillText(`${out.name || 'Output'} · ${W}×${H}`, W / 2, H / 2 - u * 1.2);
      }
      cv._key = key; cv._dirty = true; return cv;
    },
    // v210 bytes of the current output picture (top row first): rowBytes = ceil(w / 48) * 128 — what a DeckLink 10-bit frame holds
    packV210(m2020) { const gl = this.gl, w = this.W, h = this.H, words = Math.ceil(w / 48) * 32; if (!this._lastFinal) return null;
      if (!this.v210F || this.v210F.w !== words || this.v210F.h !== h) { if (this.v210F) { gl.deleteFramebuffer(this.v210F.f); gl.deleteTexture(this.v210F.t); }
        const t = this.tex(); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, words, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
        const f = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, f); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t, 0); this.v210F = { f, t, w: words, h, px: new Uint8Array(words * h * 4) }; }
      const p = this.pV210; this.bindQuad(p); gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, this._lastFinal); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.uniform1i(p.u.u_tex, 0); gl.uniform2f(p.u.u_src, w, h); gl.uniform1f(p.u.u_m2020, m2020 ? 1 : 0); gl.disable(gl.BLEND);
      gl.bindFramebuffer(gl.FRAMEBUFFER, this.v210F.f); gl.viewport(0, 0, words, h); gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      gl.readPixels(0, 0, words, h, gl.RGBA, gl.UNSIGNED_BYTE, this.v210F.px);
      gl.bindTexture(gl.TEXTURE_2D, this._lastFinal); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR); gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      return { bytes: this.v210F.px, w, h, rowBytes: words * 4 }; },
    bgrPass(src, b, tex, w, h) {
      if (!window.PixoraSeg) return null; const m = PixoraSeg.mask(src.el); src.bgrStatus = PixoraSeg.status; if (!m) return null;
      const gl = this.gl; w = Math.max(1, w | 0); h = Math.max(1, h | 0);
      let e = src._bgr; if (!e) { e = src._bgr = { mask: this.tex() }; }
      gl.bindTexture(gl.TEXTURE_2D, e.mask); gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1); gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, m.w, m.h, 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, m.data); gl.pixelStorei(gl.UNPACK_ALIGNMENT, 4);
      if (!e.f || e.w !== w || e.h !== h) { if (e.f) { gl.deleteFramebuffer(e.f); gl.deleteTexture(e.t); } e.t = this.tex(); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
        e.f = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, e.f); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, e.t, 0); e.w = w; e.h = h; }
      const prevFb = gl.getParameter(gl.FRAMEBUFFER_BINDING), vp = gl.getParameter(gl.VIEWPORT), bl = gl.isEnabled(gl.BLEND);
      const p = this.pBgr; this.bindQuad(p); gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, tex); gl.uniform1i(p.u.u_tex, 0);
      gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, e.mask); gl.uniform1i(p.u.u_mask, 1);
      const col = /^#?([0-9a-f]{6})$/i.exec(b.color || '') ? parseInt(b.color.replace('#', ''), 16) : 0x00b140;
      gl.uniform1f(p.u.u_mode, b.mode === 'blur' ? 1 : b.mode === 'color' ? 2 : 0); gl.uniform1f(p.u.u_thr, b.threshold ?? 0.5); gl.uniform1f(p.u.u_soft, b.softness ?? 0.15);
      gl.uniform1f(p.u.u_blur, b.blur ?? 6); gl.uniform3f(p.u.u_col, (col >> 16 & 255) / 255, (col >> 8 & 255) / 255, (col & 255) / 255); gl.uniform2f(p.u.u_px, 1 / w, 1 / h); gl.uniform1f(p.u.u_inv, b.invert ? 1 : 0);
      gl.disable(gl.BLEND); gl.bindFramebuffer(gl.FRAMEBUFFER, e.f); gl.viewport(0, 0, w, h); gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      gl.activeTexture(gl.TEXTURE0); gl.bindFramebuffer(gl.FRAMEBUFFER, prevFb); gl.viewport(vp[0], vp[1], vp[2], vp[3]); if (bl) gl.enable(gl.BLEND);
      return e.t; },
    flatCanvas(white) { const k = white ? 'fw' : 'fb'; this.flatCv = this.flatCv || {}; if (this.flatCv[k]) return this.flatCv[k];
      const cv = document.createElement('canvas'); cv.width = 16; cv.height = 16; const x = cv.getContext('2d'); x.fillStyle = white ? '#fff' : '#000'; x.fillRect(0, 0, 16, 16); cv._dirty = true; return (this.flatCv[k] = cv); },
    present() {
      const gl = this.gl, out = this.output, W = this.W, H = this.H;
      this.dayNight = dayNightLevel(this.stateRef.led && this.stateRef.led.dayNight);
      let slices = out && out.slices && out.slices.filter(s => s.on);
      let finalTex = out && out.lut && out.lut.on && out.lut.lut && this.lutPass(out.lut, this.cF, this.fE) ? this.fE.t : this.cF.t; // per-output display LUT
      const hc = out && out.color; if (hc && (hc.space === '2020' || (hc.eotf && hc.eotf !== 'sdr'))) { // HDR / Rec.2020 signal for this output
        const p = this.pHdr; this.bindQuad(p); gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, finalTex); gl.uniform1i(p.u.u_tex, 0);
        gl.uniform1f(p.u.u_wide, hc.space === '2020' ? 1 : 0); gl.uniform1f(p.u.u_eotf, hc.eotf === 'pq' ? 1 : hc.eotf === 'hlg' ? 2 : 0); gl.uniform1f(p.u.u_paper, +hc.paper || 203); gl.uniform1f(p.u.u_peak, +hc.peak || 1000);
        gl.disable(gl.BLEND); gl.bindFramebuffer(gl.FRAMEBUFFER, this.fH.f); gl.viewport(0, 0, W, H); gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4); finalTex = this.fH.t; }
      const OW = (out && out.width) || W, OH = (out && out.height) || H; this._lastFinal = finalTex;
      if (this.canvas.width !== OW || this.canvas.height !== OH) { this.canvas.width = OW; this.canvas.height = OH; }
      if (out && out.dome && out.dome.mode && out.dome.mode !== 'off') finalTex = this.domePass(out.dome, finalTex, OW, OH); // dome / 360 projection, then slices map the projected picture
      gl.bindFramebuffer(gl.FRAMEBUFFER, null); gl.viewport(0, 0, OW, OH);
      if (out && (out.test === 'grid' || out.test === 'white' || out.test === 'black' || out.test === 'align')) { gl.clearColor(0, 0, 0, 1); gl.clear(gl.COLOR_BUFFER_BIT); this.drawOverlay(this.testCanvas(out, OW, OH, out.test), OW, OH, false); return; }
      if ((!slices || !slices.length) && out && ((out.masks || []).some(m => m.on) || ['warped', 'mapwhite', 'mapblack'].includes(out.test))) slices = [Object.assign(S.sliceDefaults ? S.sliceDefaults() : {}, { id: '_full', src: { x: 0, y: 0, w: 1, h: 1 }, dst: [[0, 0], [1, 0], [1, 1], [0, 1]], soft: {}, gamma: 2.2, black: 0 })];
      if (!slices || !slices.length) { // straight composition
        const p = this.pBlit; this.bindQuad(p); gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, finalTex);
        gl.uniform1i(p.u.u_tex, 0); gl.uniform1f(p.u.u_alpha, this.dayNight); gl.uniform4f(p.u.u_rect, 0, 0, 1, 1); gl.disable(gl.BLEND);
        if (OW === W && OH === H) gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
        else { gl.clearColor(0, 0, 0, 1); gl.clear(gl.COLOR_BUFFER_BIT); gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4); }
        return;
      }
      gl.clearColor(0, 0, 0, 1); gl.clear(gl.COLOR_BUFFER_BIT);
      const test = ['warped', 'mapwhite', 'mapblack'].includes(out.test) ? out.test : null, flat = test === 'mapwhite' || test === 'mapblack'; // flat fields through the mapping, for blend tuning
      const srcTex = test === 'warped' ? this.overlayTex(this.testCanvas(out, this.W, this.H, 'grid'), 'testsrc') : flat ? this.overlayTex(this.flatCanvas(test === 'mapwhite'), 'flat' + test) : finalTex;
      gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE);
      for (const s of slices) {
        const mesh = s.mesh && s.mesh.on && Array.isArray(s.mesh.pts) && s.mesh.pts.length === (s.mesh.cols + 1) * (s.mesh.rows + 1);
        const p = mesh ? this.pMesh : this.pMap; gl.useProgram(p);
        gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, srcTex); gl.uniform1i(p.u.u_tex, 0); gl.uniform2f(p.u.u_out, OW, OH);
        const sr = s.src || { x: 0, y: 0, w: 1, h: 1 }; gl.uniform4f(p.u.u_src, sr.x, sr.y, sr.w, sr.h);
        const sf = s.soft || {}; gl.uniform4f(p.u.u_soft, sf.l || 0, sf.r || 0, sf.t || 0, sf.b || 0); gl.uniform1f(p.u.u_gamma, s.gamma || 2.2); gl.uniform1f(p.u.u_black, test && !flat ? 0 : (s.black || 0));
        let cal = s.cal || {}; if (String(s.id).startsWith('led-')) { const sc = (this.stateRef.led.screens || []).find(x => 'led-' + x.id === s.id); if (sc && sc.cal) cal = sc.cal; }
        gl.uniform3f(p.u.u_gain, cal.r ?? 1, cal.g ?? 1, cal.b ?? 1); gl.uniform1f(p.u.u_bri, (cal.brightness ?? 1) * (test ? 1 : this.dayNight)); gl.uniform1f(p.u.u_cgam, cal.gamma ?? 1);
        if (mesh) {
          const m = this.meshVerts(s.mesh); gl.bindBuffer(gl.ARRAY_BUFFER, this.meshBuf); gl.bufferData(gl.ARRAY_BUFFER, m, gl.DYNAMIC_DRAW);
          gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 16, 0); gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 2, gl.FLOAT, false, 16, 8);
          gl.drawArrays(gl.TRIANGLES, 0, m.length / 4); gl.disableVertexAttribArray(1);
        } else {
          gl.bindBuffer(gl.ARRAY_BUFFER, this.buf); gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
          gl.uniformMatrix3fv(p.u.u_hinv, false, homography(s.dst || [[0, 0], [1, 0], [1, 1], [0, 1]])); gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
        }
      }
      const masks = (!test || flat) && (out.masks || []).filter(m => m.on && m.pts && m.pts.length >= 3);
      if (masks && masks.length) { gl.blendFunc(gl.ZERO, gl.SRC_COLOR); this.drawOverlay(this.maskCanvas(masks, OW, OH), OW, OH, true); }
      gl.disable(gl.BLEND);
    },
    // read a scaled region of the composition (top-left origin rect in 0..1) -> RGBA rows top-down
    readRegion(rect, w, h) {
      const gl = this.gl; w = Math.max(1, w | 0); h = Math.max(1, h | 0);
      if (!this.rF || this.rF.w < w || this.rF.h < h) {
        if (this.rF) { gl.deleteFramebuffer(this.rF.f); gl.deleteTexture(this.rF.t); }
        const W = Math.max(w, 64), H = Math.max(h, 64); const t = this.tex(); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, W, H, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
        const f = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, f); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t, 0);
        this.rF = { f, t, w: W, h: H };
      }
      const p = this.pBlit; this.bindQuad(p); gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, this.cF.t);
      gl.uniform1i(p.u.u_tex, 0); gl.uniform1f(p.u.u_alpha, 1);
      gl.uniform4f(p.u.u_rect, rect.x, 1 - rect.y - rect.h, rect.w, rect.h); gl.disable(gl.BLEND);
      gl.bindFramebuffer(gl.FRAMEBUFFER, this.rF.f); gl.viewport(0, 0, w, h); gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      const px = new Uint8Array(w * h * 4); gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, px);
      const outp = new Uint8ClampedArray(w * h * 4); // flip to top-down
      for (let y = 0; y < h; y++) outp.set(px.subarray((h - 1 - y) * w * 4, (h - y) * w * 4), y * w * 4);
      return outp;
    },
    // pixel-map payload: [2][count] then per fixture [u16 len][rgb...] in wiring order
    pixelPayload(fixtures) {
      const parts = [];
      for (const fx of fixtures) {
        const cols = Math.max(1, Math.min(1024, fx.cols | 0)), rows = Math.max(1, Math.min(1024, fx.rows | 0));
        const img = this.readRegion({ x: +fx.x || 0, y: +fx.y || 0, w: fx.w == null ? 1 : +fx.w, h: fx.h == null ? 1 : +fx.h }, cols, rows);
        const out = new Uint8Array(cols * rows * 3); let k = 0;
        const byCols = fx.order === 'cols'; const outer = byCols ? cols : rows, inner = byCols ? rows : cols;
        const flipX = /r$/.test(fx.start || 'tl'), flipY = /^b/.test(fx.start || 'tl');
        for (let a = 0; a < outer; a++) for (let b0 = 0; b0 < inner; b0++) {
          const b = fx.snake && a % 2 ? inner - 1 - b0 : b0;
          let x = byCols ? a : b, y = byCols ? b : a; if (flipX) x = cols - 1 - x; if (flipY) y = rows - 1 - y;
          const i = (y * cols + x) * 4; out[k++] = img[i]; out[k++] = img[i + 1]; out[k++] = img[i + 2];
        }
        parts.push(out);
      }
      const total = 2 + parts.reduce((n, p) => n + 2 + p.length, 0); const buf = new Uint8Array(total); buf[0] = 2; buf[1] = parts.length; let o = 2;
      for (const p of parts) { buf[o] = p.length >> 8; buf[o + 1] = p.length & 255; buf.set(p, o + 2); o += 2 + p.length; }
      return buf;
    },
  });
  /* ---------------- Title Designer */
  const FONTS = ['Inter, Helvetica, Arial, sans-serif', 'Georgia, serif', 'ui-monospace, Menlo, Consolas, monospace', 'Impact, Haettenschweiler, sans-serif'];
  const ease = x => x <= 0 ? 0 : x >= 1 ? 1 : 1 - Math.pow(1 - x, 3);
  function titlePhase(p, t) { const inD = Math.max(0.001, +p.inDur || 0.001), hold = +p.hold || 0, outD = Math.max(0.001, +p.outDur || 0.001);
    const a = ease(t / inD); if (!hold) return { v: a, out: false }; const o = (t - inD - hold) / outD; return o > 0 ? { v: 1 - ease(o), out: true } : { v: a, out: false }; }
  function fmtClock(sec) { sec = Math.max(0, Math.floor(sec)); const h = Math.floor(sec / 3600), m = Math.floor(sec / 60) % 60, s = sec % 60; return (h ? h + ':' + String(m).padStart(2, '0') : String(m).padStart(2, '0')) + ':' + String(s).padStart(2, '0'); }
  function drawTitle(g, W, H, p, t) { try { return drawTitleInner(g, W, H, p, t); } finally { ROW = null; } }
  function drawTitleInner(g, W, H, p, t) {
    const tplId = p.tpl | 0, sz = (+p.size || 1) * H / 1080, font = FONTS[p.font | 0] || FONTS[0], ph = titlePhase(p, t), anim = p.anim | 0;
    let l1, l2, big = ''; const rm = p.rowMode | 0, rows = rm ? feedRows(p.rowsFrom) : [];
    if (rm === 2 && rows.length) { l1 = rows.map((r, i) => { ROW = Object.assign({ index: i + 1, count: rows.length }, r); return tpl(p.line1 || '{{row.value}}'); }).join(p.rowSep == null ? '   •   ' : p.rowSep); ROW = null; l2 = tpl(p.line2 || ''); }
    else { if (rm === 1 && rows.length) { const i = Math.floor(((window.BVJ && BVJ.now ? BVJ.now() : Date.now()) / 1000) / Math.max(1, +p.rowSecs || 5)) % rows.length; ROW = Object.assign({ index: i + 1, count: rows.length }, rows[i]); }
      l1 = tpl(p.line1 || ''); l2 = tpl(p.line2 || ''); }
    if (tplId === 2 && p.timer) { big = timerText(p.timer) || '--:--'; } else if (tplId === 2) { let rem; if (p.until && /^\d{1,2}:\d{2}$/.test(p.until)) { const [hh, mm] = p.until.split(':').map(Number); const d = new Date(); const tg = new Date(d); tg.setHours(hh, mm, 0, 0); if (tg < d) tg.setDate(tg.getDate() + 1); rem = (tg - d) / 1000; } else rem = (+p.minutes || 0) * 60 - t; big = fmtClock(rem); }
    if (tplId === 3) { const d = new Date(); big = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }); }
    g.save(); g.globalAlpha = anim === 1 || anim === 4 ? (anim === 4 ? 1 : ph.v) : 1; g.textBaseline = 'middle';
    const posIdx = p.pos | 0; const right = posIdx === 2 || posIdx === 5, centre = posIdx === 1 || posIdx === 4 || posIdx === 6, top = posIdx >= 3 && posIdx <= 5;
    const margin = Math.round(Math.min(W, H) * 0.06);
    const applyAnim = (x, y, w, h) => { // slide / wipe / pop transforms for a box
      if (anim === 0) { const dx = (1 - ph.v) * (right ? 1 : -1) * (w + margin * 2); g.translate(dx, 0); }
      else if (anim === 2) { g.beginPath(); g.rect(x, y, w * ph.v, h); g.clip(); }
      else if (anim === 3) { const k = 0.6 + 0.4 * ph.v + (ph.out ? 0 : Math.sin(Math.min(1, t / (+p.inDur || 0.5)) * Math.PI) * 0.06); g.translate(x + w / 2, y + h / 2); g.scale(k, k); g.translate(-(x + w / 2), -(y + h / 2)); g.globalAlpha = ph.v; }
    };
    if (tplId === 0 || tplId === 5) { // lower third / corner bug
      const f1 = 54 * sz, f2 = 32 * sz; g.font = `800 ${f1}px ${font}`; const w1 = g.measureText(l1).width; g.font = `500 ${f2}px ${font}`; const w2 = g.measureText(l2).width;
      const bug = tplId === 5; const padX = 34 * sz, bw = Math.max(w1, bug ? 0 : w2) + padX * 2 + 14 * sz, bh = bug ? f1 * 1.6 : (f1 + f2) * 1.55 + 24 * sz;
      const x = right ? W - margin - bw : centre ? (W - bw) / 2 : margin, y = posIdx === 6 ? (H - bh) / 2 : top ? margin : H - margin - bh;
      applyAnim(x, y, bw, bh);
      g.fillStyle = p.bg || '#0b0b12'; g.globalAlpha *= 0.92; roundRect(g, x, y, bw, bh, 10 * sz); g.fill(); g.globalAlpha /= 0.92;
      const gr = g.createLinearGradient(x, y, x, y + bh); gr.addColorStop(0, p.c1 || '#ff2fd0'); gr.addColorStop(1, shade(p.c1 || '#ff2fd0', -0.35)); g.fillStyle = gr; g.fillRect(x, y, 10 * sz, bh);
      g.fillStyle = p.c2 || '#fff'; g.font = `800 ${f1}px ${font}`; g.fillText(l1, x + padX + 6 * sz, bug ? y + bh / 2 : y + bh * 0.36);
      if (!bug) { g.globalAlpha *= 0.82; g.font = `500 ${f2}px ${font}`; g.fillText(l2, x + padX + 6 * sz, y + bh * 0.72); }
    } else if (tplId === 1) { // full-screen title
      const f1 = 120 * sz, f2 = 46 * sz; g.textAlign = 'center'; applyAnim(0, H * 0.3, W, H * 0.4);
      g.fillStyle = p.c2 || '#fff'; g.font = `900 ${f1}px ${font}`; g.shadowColor = p.c1 || '#ff2fd0'; g.shadowBlur = 30 * sz; g.fillText(l1, W / 2, H * 0.46); g.shadowBlur = 0;
      const lw = Math.min(W * 0.5, g.measureText(l1).width) * (anim === 0 || anim === 2 ? ph.v : 1); g.fillStyle = p.c1 || '#ff2fd0'; g.fillRect(W / 2 - lw / 2, H * 0.46 + f1 * 0.62, lw, 6 * sz);
      g.font = `500 ${f2}px ${font}`; g.globalAlpha *= 0.85; g.fillStyle = p.c2 || '#fff'; g.fillText(l2, W / 2, H * 0.46 + f1 * 0.62 + f2 * 1.3);
    } else if (tplId === 7) { // live captions: up to N rows of {{captions.text}} in a readable box; hidden while there's nothing to show
      const rows = String(l1 || '').split('\n').map(r => r.trim()).filter(Boolean);
      if (rows.length) { const f1 = 52 * sz, lh = f1 * 1.32, padX = 30 * sz, padY = 16 * sz; g.font = `600 ${f1}px ${font}`;
        const bw = Math.min(W - margin * 2, Math.max(W * 0.5, ...rows.map(r => g.measureText(r).width + padX * 2))), bh = rows.length * lh + padY * 2;
        const x = (W - bw) / 2, y = top ? margin : posIdx === 6 ? (H - bh) / 2 : H - margin - bh; applyAnim(x, y, bw, bh);
        g.fillStyle = p.bg || '#000'; g.globalAlpha *= 0.78; roundRect(g, x, y, bw, bh, 8 * sz); g.fill(); g.globalAlpha /= 0.78;
        g.fillStyle = p.c2 || '#fff'; g.textAlign = 'center'; rows.forEach((r, i) => g.fillText(r, W / 2, y + padY + lh * (i + 0.5))); }
    } else if (tplId === 6) { // scoreboard: HOME 3 | period · clock | 5 AWAY (values accept {{feed.key}})
      const hs = tpl(String(p.homeScore ?? '0')), as = tpl(String(p.awayScore ?? '0')), hn = tpl(p.home || 'HOME'), an = tpl(p.away || 'AWAY'), per = tpl(p.period || ''), clk = l2 || l1;
      const fn = 46 * sz, fs = 74 * sz, fp = 30 * sz, fc = 50 * sz; g.font = `800 ${fn}px ${font}`; const wn = Math.max(g.measureText(hn).width, g.measureText(an).width, 120 * sz);
      g.font = `800 ${fs}px ${FONTS[2]}`; const ws = Math.max(g.measureText(hs).width, g.measureText(as).width, 70 * sz) + 36 * sz;
      g.font = `700 ${fc}px ${FONTS[2]}`; const wc = Math.max(g.measureText(clk).width, 200 * sz) + 48 * sz;
      const bh = 104 * sz, side = wn + 52 * sz, bw = side * 2 + ws * 2 + wc, x = (W - bw) / 2, y = top || posIdx === 6 ? (posIdx === 6 ? (H - bh) / 2 : margin) : H - margin - bh;
      applyAnim(x, y, bw, bh);
      g.fillStyle = p.bg || '#0b0b12'; g.globalAlpha *= 0.94; roundRect(g, x, y, bw, bh, 14 * sz); g.fill(); g.globalAlpha /= 0.94;
      const c1 = p.c1 || '#ff2fd0', c2 = p.c2 || '#fff';
      g.fillStyle = c1; g.fillRect(x + side, y, ws, bh); g.fillStyle = shade(c1, -0.25); g.fillRect(x + side + ws + wc, y, ws, bh);
      g.textAlign = 'center'; g.fillStyle = c2;
      g.font = `800 ${fn}px ${font}`; g.fillText(hn, x + side / 2, y + bh / 2); g.fillText(an, x + bw - side / 2, y + bh / 2);
      g.font = `800 ${fs}px ${FONTS[2]}`; g.fillText(hs, x + side + ws / 2, y + bh / 2 + 2 * sz); g.fillText(as, x + side + ws + wc + ws / 2, y + bh / 2 + 2 * sz);
      g.font = `700 ${fc}px ${FONTS[2]}`; g.fillText(clk, x + side + ws + wc / 2, y + bh * 0.42);
      g.globalAlpha *= 0.8; g.font = `600 ${fp}px ${font}`; g.fillStyle = c1; g.fillText(per.toUpperCase(), x + side + ws + wc / 2, y + bh * 0.8);
    } else if (tplId === 2 || tplId === 3) { // countdown / clock
      const fb = 220 * sz; g.textAlign = 'center'; applyAnim(0, 0, W, H);
      g.fillStyle = p.c1 || '#ff2fd0'; g.font = `700 ${46 * sz}px ${font}`; g.fillText(l1, W / 2, H / 2 - fb * 0.72);
      g.fillStyle = p.c2 || '#fff'; g.font = `800 ${fb}px ${FONTS[2]}`; g.shadowColor = p.c1 || '#ff2fd0'; g.shadowBlur = 24 * sz; g.fillText(big, W / 2, H / 2); g.shadowBlur = 0;
      g.globalAlpha *= 0.8; g.font = `500 ${40 * sz}px ${font}`; g.fillText(l2, W / 2, H / 2 + fb * 0.7);
    } else if (tplId === 4) { // ticker bar
      const bh = 86 * sz, y = top ? margin * 0.5 : H - bh - margin * 0.5; const lbl = l2 || 'LIVE'; g.font = `800 ${38 * sz}px ${font}`; const lw = g.measureText(lbl).width + 50 * sz;
      if (anim === 0) g.translate(0, (1 - ph.v) * (top ? -1 : 1) * (bh + margin)); else if (anim === 1) g.globalAlpha = ph.v;
      g.fillStyle = p.bg || '#0b0b12'; g.fillRect(0, y, W, bh); g.save(); g.beginPath(); g.rect(lw, y, W - lw, bh); g.clip();
      g.font = `600 ${40 * sz}px ${font}`; const tw = g.measureText(l1 + '      •      ').width || 1; const off = (t * 140 * sz * (+p.speed || 1)) % tw;
      g.fillStyle = p.c2 || '#fff'; for (let x = lw + W * 0.02 - off; x < W; x += tw) g.fillText(l1 + '      •      ', x, y + bh / 2); g.restore();
      const gr = g.createLinearGradient(0, y, lw, y + bh); gr.addColorStop(0, p.c1 || '#ff2fd0'); gr.addColorStop(1, shade(p.c1 || '#ff2fd0', -0.3)); g.fillStyle = gr; g.fillRect(0, y, lw, bh);
      g.fillStyle = '#fff'; g.font = `800 ${38 * sz}px ${font}`; g.textAlign = 'center'; g.fillText(lbl, lw / 2, y + bh / 2);
    }
    g.restore();
  }
  function roundRect(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
  function shade(hex, k) { const n = parseInt((hex || '#000').slice(1), 16); const f = c => Math.max(0, Math.min(255, Math.round(c * (1 + k)))); return `rgb(${f(n >> 16 & 255)},${f(n >> 8 & 255)},${f(n & 255)})`; }

  /* ---------------- Logo Animator */
  function drawLogo(eng, g, W, H, p, t, beat) {
    if (+p.bgOn === 1) { g.fillStyle = p.c2 || '#000'; g.fillRect(0, 0, W, H); }
    const im = p.src ? eng.imageFor(p.src) : null; const sp = +p.speed || 1; const anim = p.anim | 0;
    const base = Math.min(W, H) * (+p.size || 60) / 100; let iw = base, ih = base;
    if (im) { const a = im.naturalWidth / im.naturalHeight; if (a >= 1) { iw = Math.min(base * a, W * (+p.size || 60) / 100); ih = iw / a; } else { ih = base; iw = ih * a; } }
    let cx = W / 2, cy = H / 2, sc = 1, rot = 0, alpha = 1, sx = 1; const glow = +p.glow || 0; const env = Math.exp(-((beat % 1 + 1) % 1) * 5);
    if (anim === 1) sc = 1 + 0.09 * env;
    else if (anim === 2) { cy += Math.sin(t * 1.3 * sp) * H * 0.04; rot = Math.sin(t * 0.8 * sp) * 0.04; }
    else if (anim === 4) sx = Math.cos(t * 1.6 * sp);
    else if (anim === 5) { const vx = W * 0.12 * sp, vy = H * 0.15 * sp; const rx = Math.max(1, W - iw), ry = Math.max(1, H - ih); const bx = (t * vx) % (2 * rx), by = (t * vy) % (2 * ry); cx = iw / 2 + (bx > rx ? 2 * rx - bx : bx); cy = ih / 2 + (by > ry ? 2 * ry - by : by); }
    else if (anim === 6) alpha = 0.82 + 0.18 * (Math.random() < 0.04 ? 0.2 : 1);
    else if (anim === 7) { const k = Math.min(1, t * 1.4 * sp); sc = k < 1 ? ease(k) * (1 + 0.12 * Math.sin(k * Math.PI)) : 1; }
    const draw = (ox, oy, clipY0, clipY1) => {
      g.save(); g.translate(cx + ox, cy + oy); g.rotate(rot); g.scale(sc * sx, sc); g.globalAlpha = alpha;
      if (glow > 0) { g.shadowColor = p.c1 || '#9b3bff'; g.shadowBlur = glow * Math.min(W, H) * 0.08 * (anim === 1 ? 0.6 + env : 1); }
      if (clipY0 != null) { g.beginPath(); g.rect(-iw / 2, -ih / 2 + clipY0 * ih, iw, (clipY1 - clipY0) * ih); g.clip(); }
      if (im) g.drawImage(im, -iw / 2, -ih / 2, iw, ih); else { g.fillStyle = p.c1 || '#9b3bff'; g.font = `800 ${ih * 0.3}px ${FONTS[0]}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('LOGO', 0, 0); }
      g.restore();
    };
    if (anim === 0) { // reveal: wipe in, hold, repeat
      const per = 6 / sp, k = (t % per) / per, rv = ease(Math.min(1, k * 3)); g.save(); g.beginPath(); g.rect(cx - iw / 2 - 2, 0, (iw + 4) * rv, H); g.clip(); draw(0, 0); g.restore();
      if (rv < 1) { const lx = cx - iw / 2 + iw * rv; const gr = g.createLinearGradient(lx - 30, 0, lx + 30, 0); gr.addColorStop(0, 'transparent'); gr.addColorStop(0.5, p.c1 || '#9b3bff'); gr.addColorStop(1, 'transparent'); g.fillStyle = gr; g.fillRect(lx - 30, cy - ih * 0.7, 60, ih * 1.4); }
    } else if (anim === 3) { // glitch on beats
      const hit = env > 0.5; draw(0, 0);
      if (hit) { const n = 6; for (let i = 0; i < n; i++) { const y0 = Math.random(), y1 = Math.min(1, y0 + Math.random() * 0.12); draw((Math.random() - 0.5) * iw * 0.15 * env, 0, y0, y1); }
        g.globalCompositeOperation = 'lighter'; g.globalAlpha = 0.35 * env; draw(iw * 0.02, 0); g.globalAlpha = 1; g.globalCompositeOperation = 'source-over'; }
    } else draw(0, 0);
  }

  /* ---------------- LED test pattern generator (drawn after the composition, before output mapping) */
  function chainOrder(sc) {
    const C = Math.max(1, sc.cols | 0), R = Math.max(1, sc.rows | 0), out = [];
    const byCols = /cols/.test(sc.chain || ''), snake = /snake/.test(sc.chain || 'snake');
    const st = sc.start || 'bl'; const fromRight = st[1] === 'r', fromBottom = st[0] === 'b';
    const outer = byCols ? C : R, inner = byCols ? R : C;
    for (let a = 0; a < outer; a++) for (let b0 = 0; b0 < inner; b0++) {
      let b = snake && a % 2 ? inner - 1 - b0 : b0; let c = byCols ? a : b, r = byCols ? b : a;
      if (fromRight) c = C - 1 - c; if (fromBottom) r = R - 1 - r; out.push([c, r]);
    }
    return out;
  }
  Engine.prototype.drawLedTest = function (state, time) {
    const W = this.W, H = this.H, t = state.led.test, mode = t.mode || 'panels';
    let screens = state.led.screens || [];
    if (!screens.length) screens = [{ name: 'Composition', x: 0, y: 0, panelW: Math.max(8, Math.round(W / 8)), panelH: Math.max(8, Math.round(H / 4)), cols: 8, rows: 4, color: '#9b3bff', chain: 'snake-rows', start: 'bl' }];
    const cycle = ['#ff0000', '#00ff00', '#0000ff', '#ffffff', '#000000'];
    const solid = t.color === 'cycle' ? cycle[Math.floor(time / 2 * (t.speed || 1)) % cycle.length] : ({ red: '#ff0000', green: '#00ff00', blue: '#0000ff', white: '#ffffff', black: '#000000' })[t.color] || '#ffffff';
    const anim = mode === 'scan' ? Math.floor(time * 30) : mode === 'solid' ? solid : 0;
    const key = JSON.stringify([screens, mode, t.names, t.color, W, H, anim]);
    if (this._ledKey !== key) {
      this._ledKey = key;
      const c = this._ledCanvas || (this._ledCanvas = document.createElement('canvas')); c.width = W; c.height = H; const g = c.getContext('2d');
      g.fillStyle = '#050506'; g.fillRect(0, 0, W, H);
      if (mode !== 'black' && mode !== 'solid') { g.strokeStyle = '#1b1b22'; g.lineWidth = 1; for (let x = 0; x < W; x += 32) { g.beginPath(); g.moveTo(x + .5, 0); g.lineTo(x + .5, H); g.stroke(); } for (let y = 0; y < H; y += 32) { g.beginPath(); g.moveTo(0, y + .5); g.lineTo(W, y + .5); g.stroke(); } }
      const font = (px, w) => `${w || 700} ${Math.max(6, px)}px Inter, Arial, sans-serif`;
      screens.forEach((sc, si) => {
        const pw = Math.max(1, sc.panelW | 0), ph = Math.max(1, sc.panelH | 0), C = Math.max(1, sc.cols | 0), R = Math.max(1, sc.rows | 0);
        const X = sc.x | 0, Y = sc.y | 0, SW = pw * C, SH = ph * R; const col = sc.color || '#ff2fd0';
        g.save(); g.beginPath(); g.rect(X, Y, SW, SH); g.clip();
        if (mode === 'solid') { g.fillStyle = solid; g.fillRect(X, Y, SW, SH); }
        else if (mode === 'black') { g.fillStyle = '#000'; g.fillRect(X, Y, SW, SH); }
        else if (mode === 'bars') { const bars = ['#c0c0c0', '#c0c000', '#00c0c0', '#00c000', '#c000c0', '#c00000', '#0000c0', '#000000']; const bw = SW / bars.length;
          bars.forEach((b, i) => { g.fillStyle = b; g.fillRect(X + i * bw, Y, Math.ceil(bw), SH * 0.7); });
          const ramp = g.createLinearGradient(X, 0, X + SW, 0); ramp.addColorStop(0, '#000'); ramp.addColorStop(1, '#fff'); g.fillStyle = ramp; g.fillRect(X, Y + SH * 0.7, SW, SH * 0.15);
          ['#ff0000', '#00ff00', '#0000ff', '#ffffff'].forEach((b, i) => { g.fillStyle = b; g.fillRect(X + i * SW / 4, Y + SH * 0.85, Math.ceil(SW / 4), SH * 0.15); }); }
        else if (mode === 'gradient') { const rows = [['#000', '#fff'], ['#000', '#f00'], ['#000', '#0f0'], ['#000', '#00f']];
          rows.forEach(([a, b], i) => { const gr = g.createLinearGradient(X, 0, X + SW, 0); gr.addColorStop(0, a); gr.addColorStop(1, b); g.fillStyle = gr; g.fillRect(X, Y + i * SH / 4, SW, Math.ceil(SH / 4)); }); }
        else if (mode === 'checker') { const id = g.createImageData(SW, SH); for (let y = 0; y < SH; y++) for (let x = 0; x < SW; x++) { const v = (x + y) & 1 ? 255 : 0; const i = (y * SW + x) * 4; id.data[i] = id.data[i + 1] = id.data[i + 2] = v; id.data[i + 3] = 255; } g.putImageData(id, X, Y); }
        else { // panels / chain / scan share the panel grid
          for (let r = 0; r < R; r++) for (let cc = 0; cc < C; cc++) { g.fillStyle = (r + cc) % 2 ? col + '55' : col + '2a'; g.fillRect(X + cc * pw, Y + r * ph, pw, ph); }
          g.strokeStyle = '#ffffff'; g.lineWidth = 1;
          for (let cc = 0; cc <= C; cc++) { const x = X + cc * pw + (cc === C ? -0.5 : 0.5); g.beginPath(); g.moveTo(x, Y); g.lineTo(x, Y + SH); g.stroke(); }
          for (let r = 0; r <= R; r++) { const y = Y + r * ph + (r === R ? -0.5 : 0.5); g.beginPath(); g.moveTo(X, y); g.lineTo(X + SW, y); g.stroke(); }
          const order = chainOrder(sc); const idx = new Map(order.map(([a, b], i) => [a + ',' + b, i + 1]));
          const fs = Math.min(pw, ph) * 0.28;
          if (mode === 'panels' || mode === 'scan') {
            g.strokeStyle = col; g.lineWidth = Math.max(1, Math.min(pw, ph) / 80);
            for (let r = 0; r < R; r++) for (let cc = 0; cc < C; cc++) { const px = X + cc * pw, py = Y + r * ph;
              g.beginPath(); g.moveTo(px, py); g.lineTo(px + pw, py + ph); g.moveTo(px + pw, py); g.lineTo(px, py + ph); g.globalAlpha = 0.35; g.stroke(); g.globalAlpha = 1;
              g.fillStyle = '#fff'; g.font = font(fs); g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(String(idx.get(cc + ',' + r)), px + pw / 2, py + ph / 2);
              g.font = font(fs * 0.38, 600); g.fillStyle = 'rgba(255,255,255,.75)'; g.fillText(`C${cc + 1} R${r + 1}`, px + pw / 2, py + ph / 2 + fs * 0.7); }
            g.strokeStyle = '#fff'; g.lineWidth = Math.max(1, Math.min(SW, SH) / 400); g.beginPath(); g.arc(X + SW / 2, Y + SH / 2, Math.min(SW, SH) * 0.45, 0, Math.PI * 2); g.stroke();
          } else { // chain
            g.strokeStyle = '#fff'; g.fillStyle = '#fff'; g.lineWidth = Math.max(1.5, Math.min(pw, ph) / 40);
            for (let i = 0; i < order.length; i++) { const [cc, r] = order[i]; const cx = X + cc * pw + pw / 2, cy = Y + r * ph + ph / 2;
              if (i < order.length - 1) { const [c2, r2] = order[i + 1]; const nx = X + c2 * pw + pw / 2, ny = Y + r2 * ph + ph / 2; const ang = Math.atan2(ny - cy, nx - cx); const hl = Math.min(pw, ph) * 0.14;
                g.beginPath(); g.moveTo(cx, cy); g.lineTo(nx, ny); g.stroke(); const mx = (cx + nx) / 2, my = (cy + ny) / 2;
                g.beginPath(); g.moveTo(mx + Math.cos(ang) * hl, my + Math.sin(ang) * hl); g.lineTo(mx + Math.cos(ang + 2.5) * hl, my + Math.sin(ang + 2.5) * hl); g.lineTo(mx + Math.cos(ang - 2.5) * hl, my + Math.sin(ang - 2.5) * hl); g.fill(); }
              g.beginPath(); g.arc(cx, cy, Math.min(pw, ph) * 0.2, 0, Math.PI * 2); g.fillStyle = i === 0 ? '#2fe08a' : col; g.fill(); g.fillStyle = '#fff';
              g.font = font(fs * 0.8); g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(String(i + 1), cx, cy); }
            g.font = font(Math.max(10, fs * 0.5)); g.fillStyle = '#2fe08a'; const [c0, r0] = order[0]; g.fillText('DATA IN', X + c0 * pw + pw / 2, Y + r0 * ph + ph * 0.85);
          }
          if (mode === 'scan') { const lx = X + ((time * 0.25 * (t.speed || 1)) % 1) * SW, ly = Y + ((time * 0.17 * (t.speed || 1)) % 1) * SH;
            g.fillStyle = '#fff'; g.fillRect(Math.floor(lx), Y, Math.max(2, pw / 32), SH); g.fillRect(X, Math.floor(ly), SW, Math.max(2, ph / 32)); }
        }
        g.restore();
        if (t.names !== false && mode !== 'solid' && mode !== 'black' && mode !== 'checker') { // screen label
          const lbl = `${sc.name}  ·  ${SW}×${SH}px  ·  ${C}×${R} panels`; const fs2 = Math.max(10, Math.min(SH * 0.09, SW / 26));
          g.font = font(fs2); const tw = g.measureText(lbl).width; g.fillStyle = 'rgba(0,0,0,.75)'; g.fillRect(X + 4, Y + 4, tw + fs2, fs2 * 1.6);
          g.fillStyle = col; g.fillRect(X + 4, Y + 4, Math.max(3, fs2 * 0.2), fs2 * 1.6); g.fillStyle = '#fff'; g.textAlign = 'left'; g.textBaseline = 'middle'; g.fillText(lbl, X + 4 + fs2 * 0.5, Y + 4 + fs2 * 0.8);
        }
        g.strokeStyle = col; g.lineWidth = 2; g.strokeRect(X + 1, Y + 1, SW - 2, SH - 2);
      });
      if (t.names !== false && mode !== 'solid' && mode !== 'black') { const fs3 = Math.max(10, H / 40); g.font = font(fs3, 600); g.textAlign = 'right'; g.textBaseline = 'bottom'; g.fillStyle = 'rgba(255,255,255,.6)'; g.fillText(`PIXORA TEST · ${W}×${H}`, W - 8, H - 6); }
      const gl = this.gl; if (!this._ledTex) this._ledTex = this.tex(); gl.bindTexture(gl.TEXTURE_2D, this._ledTex); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, c);
    }
    this.blit({ t: this._ledTex }, this.cF, 1);
  };
  window.BVJEngine = Engine;
})();
