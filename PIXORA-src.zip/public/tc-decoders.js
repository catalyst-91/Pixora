/* PIXORA — timecode decoders shared by the controller, the desktop app's background reader and the tests.
   LtcDecoder: SMPTE linear timecode from audio samples. Biphase-mark decoding with an adaptive level threshold
     (hysteresis, so quiet or noisy feeds still read), any of 24 / 25 / 29.97 drop-frame / 30 fps (rate from the bit
     clock and the frame numbers seen), drop-frame flag, and timecode played backwards (reversed sync word).
   MtcDecoder: MIDI timecode quarter-frame and full-frame (SysEx) messages, incl. 29.97 drop-frame and direction.
   toFrames / fromFrames: wall-clock frame counts, with the SMPTE drop-frame rule. */
(function (root) {
  'use strict';
  const RATES = [24, 25, 29.97, 30];
  // nominal frames per second used for counting (29.97 DF counts 30 labels per second with skips)
  function toFrames(h, m, s, f, fps, drop) {
    const nom = Math.round(fps);
    let n = ((h * 60 + m) * 60 + s) * nom + f;
    if (drop && nom === 30) { const tm = h * 60 + m; n -= 2 * (tm - Math.floor(tm / 10)); } // labels ;00 and ;01 skipped each minute except every 10th
    return n;
  }
  function fromFrames(n, fps, drop) {
    const nom = Math.round(fps);
    if (drop && nom === 30) { const per10 = 17982, perMin = 1798; const d = Math.floor(n / per10), r = n % per10; n += 18 * d + (r > 1 ? 2 * Math.floor((r - 2) / perMin) : 0); }
    const f = n % nom, s = Math.floor(n / nom) % 60, m = Math.floor(n / (nom * 60)) % 60, h = Math.floor(n / (nom * 3600)) % 24;
    return { h, m, s, f };
  }
  const label = (t, drop) => [t.h, t.m, t.s].map(x => String(x).padStart(2, '0')).join(':') + (drop ? ';' : ':') + String(t.f).padStart(2, '0');

  // ---------------- LTC ----------------
  const SYNC_FWD = [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1]; // bits 64..79, as they arrive going forward
  const SYNC_REV = SYNC_FWD.slice().reverse();                       // played backwards, the sync word arrives first, reversed
  class LtcDecoder {
    constructor(sampleRate, onFrame) {
      this.sr = sampleRate; this.onFrame = onFrame || (() => {});
      this.state = 0; this.since = 0; this.peak = 0.05; this.level = 0;
      this.period = sampleRate / (25 * 80); this.half = false; this.bits = []; this.maxFrame = 0;
      this.lastFrameAt = 0; this.samples = 0; this.framePeriods = []; this.lastLabel = null;
    }
    // feed Float32 samples (any length)
    push(x) {
      for (let i = 0; i < x.length; i++) {
        const v = x[i], a = v < 0 ? -v : v; this.samples++;
        this.peak = Math.max(a, this.peak * 0.99995); this.level = this.level * 0.999 + a * 0.001;
        const th = Math.max(0.004, this.peak * 0.25); // hysteresis band: a quarter of the recent peak
        this.since++;
        const s = v > th ? 1 : v < -th ? -1 : this.state;
        if (s !== this.state) { if (this.state !== 0) this.edge(this.since); this.since = 0; this.state = s; }
        if (this.since > this.sr / 20) { this.bits.length = 0; this.half = false; } // signal stopped
      }
    }
    edge(n) {
      const lo = this.sr / (30 * 80) * 0.7, hi = this.sr / (24 * 80) * 1.3;
      if (n < this.period * 0.75) { // half a bit cell: two of these make a 1
        this.period = Math.min(hi, Math.max(lo, this.period * 0.9 + n * 2 * 0.1));
        if (this.half) { this.bit(1); this.half = false; } else this.half = true;
      } else if (n < this.period * 1.5) { this.period = Math.min(hi, Math.max(lo, this.period * 0.9 + n * 0.1)); this.bit(0); this.half = false; }
      else { this.half = false; this.period = Math.min(hi, Math.max(lo, n)); } // resync on a long gap
    }
    bit(b) {
      const B = this.bits; B.push(b); if (B.length > 80) B.shift(); if (B.length < 80) return;
      let fwd = true, rev = true;
      for (let i = 0; i < 16; i++) { if (B[64 + i] !== SYNC_FWD[i]) fwd = false; if (B[i] !== SYNC_REV[i]) rev = false; if (!fwd && !rev) return; }
      const bits = fwd ? B : B.slice(0, 80).reverse(); // reversed playback: bit order is mirrored, sync at the front
      const v = (o, n) => { let r = 0; for (let i = 0; i < n; i++) r |= bits[o + i] << i; return r; };
      const f = v(0, 4) + v(8, 2) * 10, s = v(16, 4) + v(24, 3) * 10, m = v(32, 4) + v(40, 3) * 10, h = v(48, 4) + v(56, 2) * 10;
      const drop = !!bits[10];
      if (f > 29 || s > 59 || m > 59 || h > 23) return;
      B.length = 0; // the next frame starts fresh
      // frame rate: the bit clock says roughly how many frames per second; frame labels refine 24/25/30
      const now = this.samples; if (this.lastFrameAt) { this.framePeriods.push(now - this.lastFrameAt); if (this.framePeriods.length > 12) this.framePeriods.shift(); } this.lastFrameAt = now;
      this.maxFrame = Math.max(this.maxFrame, f);
      let clock = this.sr / (80 * this.period); if (this.framePeriods.length >= 3) { const p = this.framePeriods.slice().sort((a, b) => a - b)[this.framePeriods.length >> 1]; clock = this.sr / p; }
      let fps = this.maxFrame >= 25 || drop ? (drop ? 29.97 : 30) : clock < 24.5 ? 24 : clock < 27.5 ? 25 : 30; // the bit clock decides until frame labels prove more
      if (!drop && fps === 30 && clock && clock < 29.985) fps = 29.97; // 29.97 non-drop: same labels, slower clock
      const frame = { h, m, s, f, drop, fps, reverse: !fwd, frames: toFrames(h, m, s, f, fps, drop), level: this.peak, label: label({ h, m, s, f }, drop) };
      this.lastLabel = frame.label; this.onFrame(frame);
    }
  }

  // ---------------- MTC ----------------
  class MtcDecoder {
    constructor(onFrame) { this.onFrame = onFrame || (() => {}); this.q = new Array(8).fill(0); this.seen = 0; this.lastPiece = -1; this.reverse = false; }
    quarter(byte) {
      const piece = byte >> 4, val = byte & 0x0f;
      if (this.lastPiece >= 0) { const d = (piece - this.lastPiece + 8) % 8; if (d === 1) this.reverse = false; else if (d === 7) this.reverse = true; else this.seen = 0; }
      this.lastPiece = piece; this.q[piece] = val; this.seen |= 1 << piece;
      const done = this.reverse ? piece === 0 : piece === 7;
      if (!done || this.seen !== 0xff) return;
      this.seen = 0; const q = this.q;
      const f = q[0] | (q[1] << 4), s = q[2] | (q[3] << 4), m = q[4] | (q[5] << 4), h = q[6] | ((q[7] & 1) << 4), code = (q[7] >> 1) & 3;
      this.emit(h, m, s, f, code, this.reverse ? -2 : 2); // a full set of quarter frames spans two frames
    }
    sysex(d) { // F0 7F <dev> 01 01 hh mm ss ff F7
      if (!(d[0] === 0xF0 && d[1] === 0x7F && d[3] === 0x01 && d[4] === 0x01)) return false;
      this.lastPiece = -1; this.seen = 0; this.emit(d[5] & 0x1f, d[6], d[7], d[8], (d[5] >> 5) & 3, 0); return true;
    }
    emit(h, m, s, f, code, lag) {
      const fps = RATES[code], drop = code === 2; let frames = toFrames(h, m, s, f, fps, drop) + lag;
      if (frames < 0) frames = 0; const t = fromFrames(frames, fps, drop);
      this.onFrame({ h: t.h, m: t.m, s: t.s, f: t.f, drop, fps, reverse: this.reverse && lag !== 0, frames, label: label(t, drop) });
    }
  }

  // ---------------- encoder (tests and the built-in LTC generator) ----------------
  function encodeLtcFrame(t, fps, drop) {
    const bits = new Array(80).fill(0); const put = (o, n, v) => { for (let i = 0; i < n; i++) bits[o + i] = (v >> i) & 1; };
    put(0, 4, t.f % 10); put(8, 2, Math.floor(t.f / 10)); bits[10] = drop ? 1 : 0; put(16, 4, t.s % 10); put(24, 3, Math.floor(t.s / 10));
    put(32, 4, t.m % 10); put(40, 3, Math.floor(t.m / 10)); put(48, 4, t.h % 10); put(56, 2, Math.floor(t.h / 10));
    for (let i = 0; i < 16; i++) bits[64 + i] = SYNC_FWD[i];
    let ones = 0; for (let i = 0; i < 64; i++) ones += bits[i]; for (let i = 64; i < 80; i++) ones += bits[i]; // polarity bit (27 at 25 fps, else 59): even number of zeros
    const pb = fps === 25 ? 59 : 27; if (ones % 2) bits[pb] ^= 1;
    return bits;
  }
  // render n frames of LTC audio starting at frame count `start`
  function renderLtc({ sampleRate = 48000, fps = 25, drop = false, start = 0, count = 50, amp = 0.5, reverse = false }) {
    const perFrame = sampleRate / fps, cell = perFrame / 80, out = new Float32Array(Math.ceil(perFrame * count) + 2); let level = amp, pos = 0;
    const frames = []; for (let k = 0; k < count; k++) frames.push(encodeLtcFrame(fromFrames(start + k, fps, drop), fps, drop));
    let stream = frames.flat(); if (reverse) stream = frames.slice().reverse().map(b => b.slice().reverse()).flat();
    for (const b of stream) { const a = Math.round(pos), mid = Math.round(pos + cell / 2), e = Math.round(pos + cell);
      level = -level; for (let i = a; i < mid; i++) out[i] = level; if (b) level = -level; for (let i = mid; i < e; i++) out[i] = level; pos += cell; }
    return out;
  }

  const API = { LtcDecoder, MtcDecoder, toFrames, fromFrames, label, renderLtc, encodeLtcFrame, RATES };
  if (typeof module !== 'undefined' && module.exports) module.exports = API; else root.PixoraTC = API;
})(typeof window !== 'undefined' ? window : globalThis);
