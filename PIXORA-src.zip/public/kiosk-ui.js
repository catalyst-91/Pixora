/* PIXORA — Kiosk & digital signage: day-parts that keep the right content on air, a locked control screen, start-up hints. */
(function () {
  const UI = window.UI, $ = UI.$, $$ = UI.$$, esc = UI.esc, I = UI.icon;
  const i = UI.MORETABS.findIndex(t => t[0] === 'schedule'); UI.MORETABS.splice(i + 1, 0, ['kiosk', 'Kiosk & Signage', 'screen', 'Kiosk']);
  const DAYS = ['S', 'M', 'T', 'W', 'T', 'F', 'S'], sec = (t, b) => `<div class="sec"><h4>${t}</h4>${b}</div>`;
  UI.kiosk = { status: {}, unlocked: true, pinSet: false };
  const fmtNext = n => { if (!n) return 'no change in the next 8 days'; const d = new Date(n.at), today = new Date().toDateString() === d.toDateString();
    return `${today ? '' : d.toLocaleDateString(undefined, { weekday: 'short' }) + ' '}${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} → ${n.to ? '“' + esc(n.to) + '”' : 'otherwise'}`; };

  /* ---------- lock screen */
  function lockScreen() {
    const k = UI.kiosk, show = k.status && k.status.on && k.status.locked && !k.unlocked; let el = $('#kioskLock');
    if (!show) { if (el) el.remove(); return; }
    if (!el) { el = document.createElement('div'); el.id = 'kioskLock'; document.body.appendChild(el);
      el.innerHTML = `<div class="kl-box"><img src="/pixora-logo.png" alt="PIXORA"><h2>Kiosk mode</h2><div class="kl-now"></div>
        <form><input type="password" inputmode="numeric" autocomplete="off" placeholder="Unlock PIN" maxlength="12"><button class="btn primary">Unlock</button></form><div class="kl-msg small"></div></div>`;
      el.querySelector('form').onsubmit = e => { e.preventDefault(); BVJ.raw({ t: 'kioskUnlock', pin: el.querySelector('input').value }); el.querySelector('input').value = ''; };
      setTimeout(() => { const inp = el.querySelector('input'); if (inp) inp.focus(); }, 50); }
    const c = k.status.current; el.querySelector('.kl-now').innerHTML = c ? `On air: <b>${esc(c.name)}</b>` : 'Outside every day-part';
    el.querySelector('input').style.display = k.pinSet ? '' : 'none'; const msg = el.querySelector('.kl-msg'); msg.textContent = k.wrong ? 'Wrong PIN' : k.pinSet ? '' : 'No unlock PIN is set — Unlock opens the controls.'; msg.style.color = k.wrong ? '' : 'var(--muted, #999)';
  }
  (BVJ.extraHandlers = BVJ.extraHandlers || {}).kiosk = m => {
    if ('unlocked' in m) Object.assign(UI.kiosk, { unlocked: m.unlocked, pinSet: m.pinSet, wrong: !!m.wrong }); UI.kiosk.status = m.status || UI.kiosk.status;
    if (m.unlocked === false && !m.wrong && m.status && m.status.locked) UI.kiosk.unlocked = false;
    lockScreen(); if (UI.rtab === 'kiosk') UI.renderRight(true);
  };
  // the server re-sends status on lock changes; also re-check when the state's lock flag flips
  let lastLock = null; setInterval(() => { const s = UI.st && UI.st(); if (!s || !s.kiosk) return; const sig = s.kiosk.on + ':' + s.kiosk.locked;
    if (sig !== lastLock) { lastLock = sig; UI.api('/api/kiosk').then(r => { UI.kiosk.status = r.status; UI.kiosk.pinSet = r.pinSet; if (!(r.status.on && r.status.locked)) UI.kiosk.unlocked = true; lockScreen(); }).catch(() => {}); } }, 1000);

  /* ---------- panel */
  UI.panels.kiosk = {
    sig: s => JSON.stringify([s.kiosk.on, s.kiosk.locked, s.kiosk.dayparts.map(d => [d.id, d.on, d.days.join(''), d.action && d.action.type]), s.kiosk.otherwise && s.kiosk.otherwise.type, UI.kiosk.status && UI.kiosk.status.current, UI.kiosk.pinSet]),
    render(s) {
      const k = s.kiosk, st = UI.kiosk.status || {};
      let h = sec('Kiosk & digital signage', `${UI.rToggle('Kiosk mode', 'kiosk.on')}
        <div class="kv"><span>On air now</span><b id="kNow">${k.on ? (st.current ? '“' + esc(st.current.name) + '”' : 'otherwise') : '—'}</b></div>
        <div class="kv"><span>Next change</span><b id="kNext" class="small">${k.on ? fmtNext(st.next) : '—'}</b></div>
        <div class="hint">Day-parts say what plays when. PIXORA keeps the right one on air: it switches at the start of each window, and puts the current one back on air when it starts up — after a power cut or a reboot the screen shows the right content without anyone touching it. The first matching day-part wins, so put special ones (a campaign, an event night) above the everyday ones.</div>`);
      h += sec('Day-parts', (k.dayparts.length ? '' : '<div class="hint">No day-parts yet. Add one per block of the day, e.g. Breakfast 06:00–11:00 → playlist slot 1, Lunch 11:00–15:00 → slot 2, Night 22:00–02:00 → slot 3.</div>') +
        k.dayparts.map((d, j) => { const b = `kiosk.dayparts.${j}`, live = st.current && st.current.id === d.id;
          return `<div class="card"><header><button class="sw" data-path="${b}.on" data-toggle></button><b>${esc(d.name)}</b>${live ? '<span class="cnt" style="background:var(--green);color:#000">ON AIR</span>' : ''}<span class="mono small">${esc(d.from)}–${esc(d.to)}</span>
            <button class="btn xs" data-kx="up" data-i="${j}" ${j ? '' : 'disabled'} title="Higher priority">▲</button><button class="btn xs" data-kx="down" data-i="${j}" ${j < k.dayparts.length - 1 ? '' : 'disabled'} title="Lower priority">▼</button>
            <button class="btn xs danger" data-kx="del" data-i="${j}">${I('trash')}</button></header><div class="body">
            <div class="row wide"><label>Name</label><div class="ctl"><input type="text" data-path="${b}.name"></div></div>
            <div class="row wide"><label>From – to</label><div class="ctl"><input type="time" data-path="${b}.from" style="width:auto"> – <input type="time" data-path="${b}.to" style="width:auto"><span class="muted small">${d.to <= d.from && d.to !== d.from ? 'runs past midnight' : d.to === d.from ? 'all day' : ''}</span></div></div>
            <div class="row wide"><label>Days</label><div class="ctl days">${DAYS.map((x, n) => `<button class="${d.days.includes(n) ? 'on' : ''}" data-kx="day" data-i="${j}" data-d="${n}">${x}</button>`).join('')}</div></div>
            <div class="row wide"><label>Dates</label><div class="ctl"><input type="date" data-path="${b}.dateFrom" style="width:auto"> – <input type="date" data-path="${b}.dateTo" style="width:auto"><span class="muted small">optional, for a campaign</span></div></div>
            ${UI.actionEditor(b + '.action', d.action)}</div></div>`; }).join('') +
        `<button class="btn sm primary" data-kx="add">${I('plus')}Add day-part</button>`);
      h += sec('Otherwise', `<div class="hint">What plays outside every day-part — e.g. a house loop, or black out overnight.</div>${UI.actionEditor('kiosk.otherwise', k.otherwise)}`);
      h += sec('Lock the controls', `${UI.rToggle('Lock control screens', 'kiosk.locked')}
        <div class="row wide"><label>Unlock PIN</label><div class="ctl"><input type="password" id="kPin" inputmode="numeric" maxlength="12" placeholder="${UI.kiosk.pinSet ? '•••• (set)' : '3–12 digits'}" style="width:140px"><button class="btn sm" data-kx="pin">Set</button>${UI.kiosk.pinSet ? '<button class="btn sm" data-kx="pinClear">Clear</button>' : ''}</div></div>
        <div class="row wide"><label>Lock again after</label><div class="ctl"><input type="number" data-path="kiosk.relockMin" min="1" max="240" style="width:70px"><span class="muted small">minutes without a change</span></div></div>
        <div class="hint">While locked (and kiosk mode is on), every control screen and phone remote shows a lock; the server refuses their changes until the PIN is entered. Day-parts, the scheduler, rules and the HTTP / OSC API keep working. Without a PIN of its own the server PIN is used.</div>
        ${UI.kiosk.unlocked && k.locked && k.on ? `<button class="btn sm" data-kx="relock">Lock this screen now</button>` : ''}`);
      h += sec('Start-up', `<div class="hint">For an unattended screen, in the PIXORA desktop app's tray menu turn on <b>Kiosk start-up</b>: PIXORA starts at login, opens its outputs full screen without the controller, keeps the display awake, and reopens an output if it closes or its display comes back. Set each output to <b>Open automatically at launch</b> on the right display first.</div>`);
      return h;
    },
    live(pane) { const st = UI.kiosk.status || {}, k = UI.st().kiosk; const n = $('#kNext', pane); if (n && k.on) n.innerHTML = fmtNext(st.next); },
    after(pane) {
      pane.onclick = async e => { const t = e.target.closest('[data-kx]'); if (!t) return; const s = UI.st(), list = JSON.parse(JSON.stringify(s.kiosk.dayparts)), j = +t.dataset.i;
        const save = () => UI.cmd({ op: 'set', path: 'kiosk.dayparts', value: list });
        switch (t.dataset.kx) {
          case 'add': list.push({ id: 'dp' + Math.random().toString(36).slice(2, 8), name: 'Day-part ' + (list.length + 1), on: true, days: [0, 1, 2, 3, 4, 5, 6], from: '09:00', to: '17:00', dateFrom: '', dateTo: '', action: { type: 'trigger', layer: 1, clip: 1 } }); save(); break;
          case 'del': if (confirm(`Remove “${list[j].name}”?`)) { list.splice(j, 1); save(); } break;
          case 'up': case 'down': { const k2 = t.dataset.kx === 'up' ? j - 1 : j + 1; [list[j], list[k2]] = [list[k2], list[j]]; save(); break; }
          case 'day': { const d = +t.dataset.d, ds = list[j].days; list[j].days = ds.includes(d) ? ds.filter(x => x !== d) : [...ds, d].sort(); save(); break; }
          case 'pin': case 'pinClear': { const pin = t.dataset.kx === 'pin' ? $('#kPin', pane).value.trim() : ''; if (t.dataset.kx === 'pin' && !/^\d{3,12}$/.test(pin)) return UI.toast('The unlock PIN is 3–12 digits', 'err');
            try { const r = await UI.api('/api/kiosk', { method: 'POST', body: JSON.stringify({ pin }) }); UI.kiosk.pinSet = r.pinSet; UI.toast(pin ? 'Unlock PIN set' : 'Unlock PIN cleared — the server PIN is used', 'ok'); UI.renderRight(true); } catch (er) { UI.toast(er.message, 'err'); } break; }
          case 'relock': BVJ.raw({ t: 'kioskLock' }); break;
        } };
      this.live(pane); clearInterval(this._t); this._t = setInterval(() => { if (UI.rtab === 'kiosk') UI.api('/api/kiosk').then(r => { UI.kiosk.status = r.status; this.live($('#rpane')); }).catch(() => {}); }, 15000);
    },
  };
})();
