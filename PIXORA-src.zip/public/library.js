/* PIXORA bottom panel: media library, sources/drives, generators, inputs, shaders, looks, shows & jobs */
(function () {
  const S = window.SCHEMA, UI = window.UI, $ = UI.$, $$ = UI.$$, esc = UI.esc, I = UI.icon;
  const F = UI.libFilter = { source: localStorage.bvjLibSrc || 'all', folder: '', q: '', tag: '', sort: 'name', sel: new Set(), last: null };
  const fmtSize = n => n > 1e9 ? (n / 1e9).toFixed(1) + ' GB' : n > 1e6 ? (n / 1e6).toFixed(0) + ' MB' : Math.round(n / 1e3) + ' KB';
  function allItems() { const out = []; for (const s of UI.library.sources) if (F.source === 'all' || F.source === s.id) for (const it of s.items) out.push(it); return out; }
  function filtered() {
    let a = allItems(); if (F.folder) a = a.filter(i => i.folder === F.folder || i.folder.startsWith(F.folder + '/'));
    if (F.q) { const q = F.q.toLowerCase(); a = a.filter(i => (i.folder + '/' + i.name).toLowerCase().includes(q) || ((i.meta && i.meta.tags) || []).some(t => t.includes(q))); }
    if (F.tag) a = a.filter(i => ((i.meta && i.meta.tags) || []).includes(F.tag));
    if (F.sort === 'rating') a = [...a].sort((x, y) => ((y.meta && y.meta.rating) || 0) - ((x.meta && x.meta.rating) || 0));
    else if (F.sort === 'size') a = [...a].sort((x, y) => y.size - x.size);
    else if (F.sort === 'duration') a = [...a].sort((x, y) => ((y.meta && y.meta.duration) || 0) - ((x.meta && x.meta.duration) || 0));
    return a;
  }

  /* ================= FILES ================= */
  UI.bpanels.files = {
    sig: () => JSON.stringify([UI.libVersion, F.source, F.folder, F.q, F.tag, F.sort, [...F.sel], UI.thumbV, UI.jobs.map(j => [j.src, j.status, Math.round(j.progress * 20)])]),
    tools: () => `<input type="search" id="libQ" placeholder="Search files & tags…" value="${esc(F.q)}" style="width:180px">
      <select id="libSort"><option value="name">Name</option><option value="rating">Rating</option><option value="duration">Duration</option><option value="size">Size</option></select>
      <button class="btn sm" id="libSend" ${F.sel.size ? '' : 'disabled'} title="Fill the selected layer from its selected slot">${I('play')}Send ${F.sel.size || ''} to layer</button>
      <button class="btn sm" id="libUp">${I('upload')}Upload</button><button class="btn sm icon" id="libRef" title="Rescan sources">${I('refresh')}</button>`,
    render() {
      const srcs = UI.library.sources;
      let side = `<div class="src ${F.source === 'all' ? 'on' : ''}" data-src="all">${I('folder')}All media<span class="cnt">${srcs.reduce((n, s) => n + s.items.length, 0)}</span></div>`;
      for (const s of srcs) {
        side += `<div class="src ${F.source === s.id ? 'on' : ''}" data-src="${s.id}" title="${esc(s.path)}"><span class="dot ${s.online ? '' : 'off'}"></span>${I(s.kind === 'local' ? 'folder' : 'drive')}<span style="overflow:hidden;text-overflow:ellipsis">${esc(s.name)}</span><span class="cnt">${s.online ? s.items.length : 'offline'}</span></div>`;
        if (F.source === s.id) { const folders = [...new Set(s.items.map(i => i.folder).filter(Boolean).map(f => f.split('/')[0]))].sort(); for (const f of folders) side += `<div class="src folder ${F.folder === f ? 'on' : ''}" data-folder="${esc(f)}">${esc(f)}</div>`; }
      }
      const tags = [...new Set(allItems().flatMap(i => (i.meta && i.meta.tags) || []))].sort();
      if (tags.length) side += `<div class="tlabel" style="margin:10px 4px 4px">Tags</div><div style="padding:0 4px">${tags.map(t => `<span class="tagchip ${F.tag === t ? 'on' : ''}" data-tag="${esc(t)}">${esc(t)}</span>`).join('')}</div>`;
      const running = UI.jobs.filter(j => j.status === 'running' || j.status === 'queued');
      const items = filtered();
      let main = running.length ? `<div class="jobs" style="margin-bottom:8px">${running.map(j => `<div class="job"><span>${j.type === 'convert' ? 'Converting' : 'Collecting'} ${esc(j.name)}</span><div class="meter"><i style="width:${(j.progress || 0) * 100}%"></i></div><span class="mono">${Math.round((j.progress || 0) * 100)}%</span></div>`).join('')}</div>` : '';
      if (!items.length) main += `<div class="dropzone" id="dz">${srcs.length ? 'No media here yet.' : 'Loading…'}<br>Drop video / image files here to upload to the Local Library, or add an external drive / folder in <b>Sources &amp; Drives</b>.<br><span class="small">All common formats supported: MP4, MOV, WebM, MKV, AVI, WMV, MPEG, MTS, MXF, ProRes, FLV… (non-browser formats are converted locally with ffmpeg)</span></div>`;
      else main += `<div class="cards">${items.slice(0, 1500).map(it => this.card(it)).join('')}</div>${items.length > 1500 ? `<p class="muted">Showing 1500 of ${items.length} — refine the search.</p>` : ''}`;
      return `<div class="libside">${side}</div><div class="libmain" id="libMain">${main}</div>`;
    },
    card(it) {
      const m = it.meta || {}; const r = m.rating || 0;
      const th = it.kind === 'image' ? BVJ.mediaUrl(it.src) : it.thumb ? BVJ.thumbUrl(it.src, UI.thumbV) : '';
      const job = UI.jobs.find(j => j.src === it.src && (j.status === 'running' || j.status === 'queued'));
      const bdg = job ? `<span class="bdg run">${Math.round((job.progress || 0) * 100)}%</span>` : !it.playable ? `<span class="bdg conv">convert</span>` : it.converted ? `<span class="bdg ok">converted</span>` : it.kind === 'image' ? `<span class="bdg ok">image</span>` : '';
      return `<div class="mcard ${F.sel.has(it.src) ? 'sel' : ''}" draggable="true" data-src="${esc(it.src)}" title="${esc(it.folder ? it.folder + '/' : '')}${esc(it.name)}">
        <div class="th" style="${th ? `background-image:url('${th}')` : ''}">${th ? '' : I(it.kind === 'image' ? 'eye' : 'play')}${bdg}${m.duration ? `<span class="dur">${BVJ.fmtTime(m.duration)}</span>` : ''}</div>
        <div class="meta"><div class="nm">${esc(it.name)}</div><div class="sub">${m.w ? m.w + '×' + m.h : fmtSize(it.size)}<span class="stars">${[1, 2, 3, 4, 5].map(n => `<i class="${n <= r ? 'on' : ''}" data-rate="${n}">★</i>`).join('')}</span></div>
        ${(m.tags || []).length ? `<div style="margin-top:3px">${m.tags.map(t => `<span class="tagchip">${esc(t)}</span>`).join('')}</div>` : ''}</div></div>`;
    },
    after(pane) {
      const main = $('#libMain', pane);
      $('#libQ') && ($('#libQ').oninput = e => { F.q = e.target.value; clearTimeout(this._q); this._q = setTimeout(() => { UI.renderBottom(true); const q = $('#libQ'); if (q) { q.focus(); q.setSelectionRange(q.value.length, q.value.length); } }, 200); });
      $('#libSort') && ($('#libSort').value = F.sort, $('#libSort').onchange = e => { F.sort = e.target.value; UI.renderBottom(true); });
      $('#libUp') && ($('#libUp').onclick = () => $('#fileIn').click());
      $('#libRef') && ($('#libRef').onclick = () => UI.loadLibrary(true));
      $('#libSend') && ($('#libSend').onclick = () => { const items = filtered().filter(i => F.sel.has(i.src)); UI.cmd({ op: 'fillLayer', layer: UI.sel.layer, start: UI.sel.slot == null ? (UI.st().layers[UI.sel.layer].clips.findIndex(c => !c) + 1 || 1) - 1 : UI.sel.slot, items: items.map(UI.mediaClip) }); F.sel.clear(); UI.toast(items.length + ' clip(s) sent to ' + UI.st().layers[UI.sel.layer].name, 'ok'); });
      pane.onclick = e => {
        const s = e.target.closest('[data-src].src'); if (s) { F.source = s.dataset.src; F.folder = ''; localStorage.bvjLibSrc = F.source; return UI.renderBottom(true); }
        const fo = e.target.closest('[data-folder]'); if (fo) { F.folder = F.folder === fo.dataset.folder ? '' : fo.dataset.folder; return UI.renderBottom(true); }
        const tg = e.target.closest('[data-tag]'); if (tg) { F.tag = F.tag === tg.dataset.tag ? '' : tg.dataset.tag; return UI.renderBottom(true); }
        const rt = e.target.closest('[data-rate]'); if (rt) { const src = rt.closest('.mcard').dataset.src; const cur = (UI.libIndex.get(src).meta || {}).rating || 0; const n = +rt.dataset.rate; UI.api('/api/meta?src=' + encodeURIComponent(src), { method: 'POST', body: JSON.stringify({ rating: cur === n ? 0 : n }) }); return; }
        const c = e.target.closest('.mcard'); if (!c) return; const src = c.dataset.src;
        if (e.shiftKey && F.last) { const list = filtered().map(i => i.src); const a = list.indexOf(F.last), b = list.indexOf(src); for (let i = Math.min(a, b); i <= Math.max(a, b); i++) F.sel.add(list[i]); }
        else if (e.ctrlKey || e.metaKey) { F.sel.has(src) ? F.sel.delete(src) : F.sel.add(src); }
        else { F.sel.clear(); F.sel.add(src); }
        F.last = src; UI.renderBottom(true);
      };
      pane.ondblclick = e => { const c = e.target.closest('.mcard'); if (!c) return; const it = UI.libIndex.get(c.dataset.src); const s = UI.st(); const l = s.layers[UI.sel.layer];
        let slot = UI.sel.slot != null && !l.clips[UI.sel.slot] ? UI.sel.slot : l.clips.findIndex(x => !x); if (slot < 0) slot = UI.sel.slot ?? 0;
        UI.cmd({ op: 'assign', layer: UI.sel.layer, slot, clip: UI.mediaClip(it) }); UI.cmd({ op: 'trigger', layer: UI.sel.layer, clip: slot }); UI.select(UI.sel.layer, slot); };
      pane.oncontextmenu = e => { const c = e.target.closest('.mcard'); if (!c) return; e.preventDefault(); const it = UI.libIndex.get(c.dataset.src);
        UI.menu(e.clientX, e.clientY, [
          { label: 'Edit tags…', icon: 'wand', click: async () => { const t = await UI.prompt('Tags (comma separated)', ((it.meta && it.meta.tags) || []).join(', '), 'Tags'); if (t != null) UI.api('/api/meta?src=' + encodeURIComponent(it.src), { method: 'POST', body: JSON.stringify({ tags: t.split(',') }) }); } },
          ...(it.kind === 'video' ? [{ label: it.converted ? 'Re-convert (ffmpeg)' : 'Convert for smooth playback (ffmpeg)', icon: 'refresh', click: () => UI.convert(it.src) }] : []),
          ...(it.converted ? [{ label: 'Remove converted copy', icon: 'trash', click: () => UI.api('/api/convert?src=' + encodeURIComponent(it.src), { method: 'DELETE' }) }] : []),
          ...(it.src.startsWith('local/') ? ['-', { label: 'Delete file from Local Library', icon: 'trash', click: () => { if (confirm('Delete ' + it.name + ' from disk?')) UI.api('/api/media?src=' + encodeURIComponent(it.src), { method: 'DELETE' }).catch(er => UI.toast(er.message, 'err')); } }] : [])]); };
      pane.ondragstart = e => { const c = e.target.closest('.mcard'); if (!c) return; const src = c.dataset.src; const list = F.sel.has(src) && F.sel.size > 1 ? filtered().filter(i => F.sel.has(i.src)) : [UI.libIndex.get(src)];
        e.dataTransfer.setData('bvj/media', JSON.stringify(list)); e.dataTransfer.effectAllowed = 'copy'; };
      const dz = main; dz.ondragover = e => { if (e.dataTransfer.types.includes('Files')) { e.preventDefault(); const z = $('#dz'); if (z) z.classList.add('over'); } };
      dz.ondrop = e => { if (!e.dataTransfer.files.length) return; e.preventDefault(); UI.uploadFiles([...e.dataTransfer.files], F.folder); };
    },
  };
  $('#fileIn').addEventListener('change', e => { UI.uploadFiles([...e.target.files], F.folder); e.target.value = ''; });

  /* ================= SOURCES & DRIVES ================= */
  let drives = null;
  UI.bpanels.sources = {
    sig: () => JSON.stringify([UI.libVersion, drives && drives.length]),
    tools: () => `<button class="btn sm primary" id="addSrc">${I('plus')}Add folder / drive…</button><button class="btn sm" id="srcRef">${I('refresh')}Rescan</button>`,
    render() {
      const srcs = UI.library.sources;
      let h = `<div class="libmain"><div class="grid2" style="align-items:start"><div><div class="sec"><h4>Library sources</h4>`;
      h += srcs.map(s => `<div class="card"><header style="cursor:default"><span class="dot" style="width:8px;height:8px;border-radius:50%;background:${s.online ? 'var(--green)' : 'var(--red)'}"></span>${I(s.kind === 'local' ? 'folder' : 'drive')}<b>${esc(s.name)}</b><span class="muted small">${s.online ? s.items.length + ' files' : 'OFFLINE — drive not connected'}</span>
        ${s.id !== 'local' ? `<button class="btn xs danger" data-rmsrc="${s.id}">Remove</button>` : ''}</header><div class="body small mono muted" style="word-break:break-all">${esc(s.path)}</div></div>`).join('');
      h += `<div class="hint">Sources are folders on the computer running the PIXORA server — internal disks, USB / Thunderbolt external drives, NAS shares or network mounts. They're read-only: files are streamed directly from the drive. If a drive is unplugged it shows OFFLINE and its clips come back when reconnected (even on a different drive letter — use Relink).</div></div></div>`;
      h += `<div><div class="sec"><h4>Detected drives</h4>${drives ? drives.map(d => `<div class="src" style="cursor:default">${I('drive')}<span style="flex:1;overflow:hidden;text-overflow:ellipsis" title="${esc(d.path)}">${esc(d.label)} <span class="muted mono small">${esc(d.path)}</span></span><button class="btn xs" data-adddrive="${esc(d.path)}">Add whole drive</button><button class="btn xs" data-browse="${esc(d.path)}">Browse…</button></div>`).join('') : '<div class="muted">Scanning…</div>'}
        <div class="row wide" style="margin-top:8px"><label>Path</label><div class="ctl"><input type="text" id="srcPath" placeholder="E:\\VJ Loops  or  /Volumes/SSD/Content"><button class="btn sm" id="srcAddPath">Add</button></div></div>
        <div class="hint">Running PIXORA in Docker? Drives must be mounted into the container (see manual) — or run it natively with start.ps1 / start.sh to see every drive.</div></div></div></div></div>`;
      return h;
    },
    after(pane) {
      if (!drives) UI.api('/api/drives').then(r => { drives = r.drives; UI.renderBottom(true); }).catch(() => { drives = []; });
      const add = async (p, name) => { try { await UI.api('/api/sources', { method: 'POST', body: JSON.stringify({ path: p, name }) }); UI.toast('Added ' + p, 'ok'); UI.loadLibrary(true); } catch (e) { UI.toast(e.message, 'err'); } };
      $('#addSrc').onclick = () => UI.browseFolder('Add library folder or drive', p => add(p));
      $('#srcRef').onclick = () => { drives = null; UI.loadLibrary(true); };
      pane.onclick = e => { const t = e.target.closest('button'); if (!t) return;
        if (t.dataset.rmsrc) UI.api('/api/sources?id=' + t.dataset.rmsrc, { method: 'DELETE' }).then(() => UI.loadLibrary());
        if (t.dataset.adddrive) add(t.dataset.adddrive);
        if (t.dataset.browse) UI.browseFolder('Add library folder', p => add(p));
        if (t.id === 'srcAddPath') add($('#srcPath').value.trim()); };
    },
  };

  /* ================= GENERATORS ================= */
  UI.bpanels.gens = {
    render() {
      return `<div class="libmain"><div class="hint" style="margin-top:0">Drag a generator onto any clip slot. Generators are rendered procedurally on the GPU at the composition's exact resolution.</div><div class="cards" style="--card-w:150px">${S.GENERATORS.map(g => {
        const c = { type: 'gen', gen: { kind: g.id, params: S.genDefaults(g.id) } };
        return `<div class="gtile" draggable="true" data-gen="${g.id}"><div class="gi" style="background:${UI.genBg(c)}"></div><b>${g.name}</b><span>${g.params.length} parameters</span></div>`; }).join('')}</div></div>`;
    },
    after(pane) {
      pane.ondragstart = e => { const t = e.target.closest('[data-gen]'); if (!t) return; const k = t.dataset.gen; const g = S.GENERATORS.find(x => x.id === k);
        e.dataTransfer.setData('bvj/clip', JSON.stringify({ type: 'gen', name: g.name, gen: { kind: k, params: S.genDefaults(k) } })); };
      pane.ondblclick = e => { const t = e.target.closest('[data-gen]'); if (!t) return; const l = UI.st().layers[UI.sel.layer]; const slot = UI.sel.slot ?? Math.max(0, l.clips.findIndex(c => !c)); UI.assignGen(UI.sel.layer, slot, t.dataset.gen); };
    },
  };

  /* ================= INPUTS & WEB ================= */
  /* Stream inputs: SRT / RTMP / HLS / RTSP / UDP, pulled in by the server's ffmpeg */
  const SIN_KINDS = [['srt-listen', 'SRT — listen (they call you)'], ['srt-call', 'SRT — call a sender'], ['rtmp-listen', 'RTMP — receive from OBS / encoder'], ['rtmp-pull', 'RTMP — pull a stream'], ['hls', 'HLS (.m3u8)'], ['rtsp', 'RTSP camera'], ['udp', 'UDP / MPEG-TS'], ['url', 'Other URL']];
  const sin = UI.sinForm = UI.sinForm || { kind: 'srt-listen', host: '', port: '9000', key: 'pixora', pass: '', latency: 200, url: '', mode: 'auto', mbps: 8 };
  UI.streamInUrl = f => { const lat = Math.max(20, +f.latency || 200) * 1000, pass = f.pass ? `&passphrase=${encodeURIComponent(f.pass)}` : '';
    switch (f.kind) { case 'srt-listen': return `srt://0.0.0.0:${+f.port || 9000}?mode=listener&latency=${lat}${pass}`;
      case 'srt-call': return `srt://${f.host || 'sender.local'}:${+f.port || 9000}?mode=caller&latency=${lat}${pass}`;
      case 'rtmp-listen': return `rtmp://0.0.0.0:${+f.port || 1935}/live/${encodeURIComponent(f.key || 'pixora')}?listen=1`;
      case 'udp': return `udp://0.0.0.0:${+f.port || 5000}?fifo_size=1000000&overrun_nonfatal=1`;
      default: return f.url || ''; } };
  UI.streamInSection = () => { const f = sin, k = f.kind, host = location.hostname, field = (lab, key, ph, type) => `<div class="row wide"><label>${lab}</label><div class="ctl"><input type="${type || 'text'}" data-sin="${key}" value="${esc(f[key])}" placeholder="${esc(ph || '')}"></div></div>`;
    const url = UI.streamInUrl(f), name = { 'srt-listen': 'SRT in :' + f.port, 'srt-call': 'SRT ' + (f.host || ''), 'rtmp-listen': 'OBS ' + f.key, udp: 'UDP :' + f.port }[k] || 'Stream';
    const clip = { type: 'stream', name: name.slice(0, 32), url, mode: f.mode, mbps: +f.mbps || 8, latency: 0.8, fit: 'fit' };
    const help = { 'srt-listen': `Senders call <b>srt://${esc(host)}:${esc(f.port)}</b>${f.pass ? ' with the passphrase' : ''} (OBS: Settings ▸ Stream ▸ Custom, server <span class="mono">srt://${esc(host)}:${esc(f.port)}?mode=caller</span>).`,
      'rtmp-listen': `In OBS: Settings ▸ Stream ▸ Custom — Server <span class="mono">rtmp://${esc(host)}:${esc(f.port || 1935)}/live</span>, Stream key <span class="mono">${esc(f.key)}</span>.`,
      'srt-call': 'PIXORA calls the sender (it must be listening).', hls: 'An https:// link to a .m3u8 playlist.', rtsp: 'rtsp://user:pass@camera-ip/stream — most IP and PTZ cameras.', udp: 'MPEG-TS sent to this computer’s port.', 'rtmp-pull': 'rtmp://server/app/key' }[k] || '';
    return `<div class="sec"><h4>Stream input</h4>
      <div class="row wide"><label>Type</label><div class="ctl"><select data-sin="kind">${SIN_KINDS.map(([v, l]) => `<option value="${v}" ${v === k ? 'selected' : ''}>${l}</option>`).join('')}</select></div></div>
      ${k === 'srt-call' ? field('Sender host', 'host', '192.168.1.50') : ''}${['srt-listen', 'srt-call', 'rtmp-listen', 'udp'].includes(k) ? field('Port', 'port', k.startsWith('rtmp') ? '1935' : '9000', 'number') : ''}
      ${k === 'rtmp-listen' ? field('Stream key', 'key', 'pixora') : ''}${k.startsWith('srt') ? field('Passphrase', 'pass', 'optional, 10+ characters', 'password') + field('Latency (ms)', 'latency', '200', 'number') : ''}
      ${['rtmp-pull', 'hls', 'rtsp', 'url'].includes(k) ? field('URL', 'url', { 'rtmp-pull': 'rtmp://server/app/key', hls: 'https://…/index.m3u8', rtsp: 'rtsp://camera/stream', url: 'srt:// rtmp:// https:// rtsp:// udp://' }[k]) : ''}
      <div class="row wide"><label>Video</label><div class="ctl"><select data-sin="mode"><option value="auto" ${f.mode === 'auto' ? 'selected' : ''}>Pass H.264 through (lowest CPU)</option><option value="encode" ${f.mode === 'encode' ? 'selected' : ''}>Re-encode for low latency</option></select></div></div>
      ${f.mode === 'encode' ? field('Bitrate (Mb/s)', 'mbps', '8', 'number') : ''}
      <div class="gtile" draggable="true" data-clip='${esc(JSON.stringify(clip))}' style="flex-direction:row;align-items:center;padding:8px;margin-top:6px">${I('globe')}<b>Drag the stream to a slot</b></div>
      <div class="hint">${help} Pass-through latency is about one keyframe interval of the sender (set 1 s keyframes in OBS); re-encode keeps it under a second on any sender. Streams need ffmpeg on the server — it comes with the desktop app.</div>
      <div data-sinlist class="small" style="margin-top:6px"></div></div>`; };
  const sinPoll = () => { const el = document.querySelector('[data-sinlist]'); if (!el) return; UI.api('/api/streamin/list').then(r => { el.innerHTML = r.inputs.length ? '<b>Active stream inputs</b>' + r.inputs.map(x => `<div style="display:flex;gap:6px;align-items:center"><span style="color:${x.live ? 'var(--green, #3ddc84)' : x.error ? 'var(--amber, #ffb43f)' : 'inherit'}">●</span><span>${esc(x.label)}</span><span class="muted">${x.live ? `${x.codecs} · ${x.kbps} kb/s · ${x.viewers} output${x.viewers === 1 ? '' : 's'}` : esc(x.error || x.status)}</span></div>`).join('') : (r.ffmpeg ? '' : '<span style="color:var(--amber, #ffb43f)">ffmpeg is not available on the server — stream inputs need it.</span>'); }).catch(() => {}); };
  setInterval(() => { if (UI.btab === 'inputs') sinPoll(); }, 2000);
  document.addEventListener('change', e => { const t = e.target; if (!t.dataset || t.dataset.sin == null) return; sin[t.dataset.sin] = t.value; if (['kind', 'mode'].includes(t.dataset.sin)) UI.renderBottom(true); else { const tile = t.closest('.sec').querySelector('.gtile[data-clip]'); if (tile) { const c = JSON.parse(tile.dataset.clip); c.url = UI.streamInUrl(sin); c.mode = sin.mode; c.mbps = +sin.mbps || 8; tile.dataset.clip = JSON.stringify(c); } } });
  UI.bpanels.inputs = {
    sig: () => JSON.stringify([UI.outputs.map(o => o.info && o.info.devices), UI.sinForm && [UI.sinForm.kind, UI.sinForm.mode]]),
    tools: () => `<button class="btn sm" id="scanIn">${I('refresh')}Scan inputs on output computer</button>`,
    render() {
      const p = UI.outputs.find(o => o.primary) || UI.outputs[0]; const devs = (p && p.info && p.info.devices) || { video: [] };
      const tile = (clip, icon, title, sub) => `<div class="gtile" draggable="true" data-clip='${esc(JSON.stringify(clip))}'><div class="gi" style="display:flex;align-items:center;justify-content:center;background:#0d0e12;color:var(--accent)">${I(icon)}</div><b>${esc(title)}</b><span>${esc(sub)}</span></div>`;
      return `<div class="libmain"><div class="grid2" style="align-items:start;grid-template-columns:2fr 1fr"><div><div class="sec"><h4>Live inputs</h4><div class="cards" style="--card-w:150px">
        ${tile({ type: 'screen', name: 'Screen capture', fit: 'fit' }, 'screen', 'Screen / Tab capture', 'Any screen, window or browser tab')}
        ${tile({ type: 'replay', name: 'Replay', unit: 'auto', fit: 'fit' }, 'restart', 'Replay', 'Instant replay (units A–D)')}
        ${tile({ type: 'capture', name: 'Camera', device: '', fit: 'fill' }, 'cam', 'Default camera', 'Webcam / capture card')}
        ${devs.video.map(v => tile({ type: 'capture', name: v.label.slice(0, 32), device: v.id, fit: 'fill' }, 'cam', v.label, 'Live input')).join('')}
        ${(UI.ndiSources || []).map(n => tile({ type: 'ndi', name: n.slice(0, 32), ndi: n, fit: 'fit' }, 'cam', n, 'NDI® source')).join('')}
        ${((UI.tsInputs || {}).senders || []).map(d => tile({ type: 'texshare', name: d.name.slice(0, 32), sender: d.name, fit: 'fit' }, 'screen', d.name, UI.tsInputs.kind + ' sender' + (d.width ? ` · ${d.width}×${d.height}` : ''))).join('')}
        ${(UI.dlInputs || []).map(d => tile({ type: 'decklink', name: d.name.slice(0, 32), device: d.index, fit: 'fit' }, 'cam', d.name, 'SDI / HDMI in · ' + d.model)).join('')}
        </div>${!p ? '<div class="hint">Open an Output window to list its cameras and capture cards.</div>' : ''}${window.pixoraNative && window.pixoraNative.ndiState ? `<div class="hint">NDI® sources on your network appear here in the desktop app (press Scan to refresh). NDI® is a registered trademark of Vizrt NDI AB — <a href="https://ndi.video/" target="_blank" rel="noopener" style="color:var(--accent, #c9f);text-decoration:none">ndi.video</a></div>` : ''}</div></div>
        <div>${UI.streamInSection()}${UI.guestSection ? UI.guestSection() : ''}${UI.playlistMaker ? UI.playlistMaker() : ''}<div class="sec"><h4>Web page</h4><div class="row wide"><label>URL</label><input type="text" id="webUrl" placeholder="https://example.com/scoreboard"></div>
        <div style="display:flex;gap:6px;margin-top:6px"><div class="gtile" draggable="true" id="webTile" style="flex:1;padding:8px;flex-direction:row;align-items:center">${I('globe')}<b>Drag web page to a slot</b></div></div>
        <div class="hint">Great for scoreboards, timers, social walls, HTML graphics and your own web apps. In a browser, pages render live as an overlay with transparency; in the PIXORA desktop app they become GPU textures, so effects, masks and mapping apply. For sites that block embedding, use Screen / Tab capture.</div></div></div></div></div>`;
    },
    after(pane) {
      $('#scanIn') && ($('#scanIn').onclick = () => { UI.cmd({ op: 'scanInputs' }); UI.toast('Allow camera/microphone access in the Output window to list devices');
        if (window.pixoraNative) window.pixoraNative.listNdi().then(l => { UI.ndiSources = l; UI.renderBottom(true); });
        if (window.pixoraNative && window.pixoraNative.texShareList) window.pixoraNative.texShareList().then(l => { UI.tsInputs = l; UI.renderBottom(true); }); });
      if (window.pixoraNative && window.pixoraNative.texShareList && !UI.tsInputs) { UI.tsInputs = { senders: [] }; window.pixoraNative.texShareList().then(l => { UI.tsInputs = l; UI.renderBottom(true); }); }
      if (window.pixoraNative && !UI.ndiSources) { UI.ndiSources = []; window.pixoraNative.listNdi().then(l => { UI.ndiSources = l; UI.renderBottom(true); }); }
      if (window.pixoraNative && window.pixoraNative.decklinkState && !UI.dlInputs) { UI.dlInputs = []; window.pixoraNative.decklinkState().then(s => { UI.dlInputs = (s.devices || []).filter(d => d.input); if (UI.dlInputs.length) UI.renderBottom(true); }).catch(() => {}); }
      pane.ondragstart = e => {
        if (e.target.id === 'webTile') { const url = $('#webUrl').value.trim(); if (!url) { UI.toast('Enter a URL first', 'err'); e.preventDefault(); return; } e.dataTransfer.setData('bvj/clip', JSON.stringify({ type: 'web', name: url.replace(/^https?:\/\//, '').slice(0, 40), url })); return; }
        const t = e.target.closest('[data-clip]'); if (t) e.dataTransfer.setData('bvj/clip', t.dataset.clip);
      };
    },
  };

  /* ================= SHADERS ================= */
  let curShader = null, shFilter = '', shKind = '';
  const shKindOf = x => x.isf ? x.isf.kind : 'glsl';
  const KIND_LABEL = { generator: 'ISF generator', effect: 'ISF effect', transition: 'ISF transition', glsl: 'GLSL', invalid: 'ISF (error)' };
  UI.bpanels.shaders = {
    sig: s => JSON.stringify([s.shaders.map(x => [x.id, x.name, x.isf && x.isf.kind, x.isf && x.isf.missing]), curShader, Object.keys(UI.shaderErrors), shFilter, shKind]),
    tools: () => `<button class="btn sm" id="shNew">${I('plus')}New shader</button><button class="btn sm" id="shImp">${I('upload')}Import ISF</button><button class="btn sm" id="shImpDir">${I('folder')}Folder</button>`,
    render(s) {
      const list = s.shaders.filter(x => (!shKind || shKindOf(x) === shKind) && (!shFilter || (x.name + ' ' + ((x.isf && x.isf.categories) || []).join(' ')).toLowerCase().includes(shFilter.toLowerCase())));
      if (!curShader || !s.shaders.find(x => x.id === curShader)) curShader = (list[0] || s.shaders[0] || {}).id;
      const sh = s.shaders.find(x => x.id === curShader), info = sh && UI.isfInfo(sh), kind = sh && shKindOf(sh);
      const counts = {}; for (const x of s.shaders) counts[shKindOf(x)] = (counts[shKindOf(x)] || 0) + 1;
      const badge = x => { const k = shKindOf(x); return k === 'glsl' ? '' : `<span class="cnt" title="${KIND_LABEL[k]}" style="${k === 'invalid' ? 'color:var(--red)' : ''}">${k === 'effect' ? 'FX' : k === 'generator' ? 'GEN' : k === 'transition' ? 'TR' : '!'}</span>`; };
      return `<div class="libside"><input type="search" id="shFind" placeholder="Search name or category" value="${esc(shFilter)}" style="width:100%;margin-bottom:4px">
          <select id="shKind" style="width:100%;margin-bottom:6px"><option value="">All (${s.shaders.length})</option>${['generator', 'effect', 'transition', 'glsl', 'invalid'].filter(k => counts[k]).map(k => `<option value="${k}" ${shKind === k ? 'selected' : ''}>${KIND_LABEL[k]} (${counts[k]})</option>`).join('')}</select>
          ${list.map(x => `<div class="src ${x.id === curShader ? 'on' : ''}" data-sh="${x.id}" draggable="true">${I('code')}${esc(x.name)}${UI.shaderErrors[x.id] ? '<span class="cnt" style="color:var(--red)">error</span>' : badge(x)}</div>`).join('') || '<div class="hint">No shaders match.</div>'}</div>
        <div class="libmain">${sh ? `<div style="display:flex;gap:6px;margin-bottom:6px;flex-wrap:wrap"><input type="text" id="shName" value="${esc(sh.name)}" style="flex:1;min-width:120px"><button class="btn sm primary" id="shSave">${I('save')}Save</button>
            ${kind === 'transition' ? `<button class="btn sm" id="shTr" title="Set the selected layer's transition to this shader">${I('plus')}Use as layer transition</button>` : kind === 'effect' ? `<button class="btn sm" id="shFx" title="Turn on an ISF Effect slot on the selected layer with this shader">${I('plus')}Use as layer effect</button><button class="btn sm" id="shFxComp" title="…or on the whole composition">${I('plus')}Comp effect</button>` : `<button class="btn sm" id="shUse">${I('play')}Add to selected slot</button>`}
            ${sh.builtin ? '' : `<button class="btn sm danger" id="shDel">${I('trash')}</button>`}</div>
          ${sh.isf ? `<div class="small" style="margin-bottom:4px"><b>${KIND_LABEL[kind]}</b>${info && info.ok !== false ? ` · ${info.inputs.length} input${info.inputs.length === 1 ? '' : 's'} · ${info.passes.length} pass${info.passes.length === 1 ? '' : 'es'}${info.passes.some(p => p.persistent) ? ' (feedback)' : ''}${sh.vs ? ' · custom vertex shader' : ''}` : ''}${sh.isf.credit ? ` · <span class="muted">by ${esc(sh.isf.credit)}</span>` : ''}${sh.isf.missing && sh.isf.missing.length ? ` · <span style="color:var(--amber, #fb3)">missing ${esc(sh.isf.missing.join(', '))}</span>` : ''}</div>` : ''}
          <textarea id="shCode" spellcheck="false" style="width:100%;height:calc(100% - ${sh.isf ? 92 : 70}px);min-height:120px">${esc(sh.code)}</textarea>
          ${UI.shaderErrors[sh.id] || (sh.isf && sh.isf.error) ? `<pre class="small" style="color:var(--red);white-space:pre-wrap;margin:4px 0">${esc(UI.shaderErrors[sh.id] || sh.isf.error)}</pre>` : `<div class="hint">ISF (.fs, with an optional matching .vs and any images it imports) or Shadertoy-style <span class="mono">mainImage(out vec4, in vec2)</span>. ISF generators go in clip slots; ISF filters (with an <span class="mono">inputImage</span>) are effects — use the ISF Effect slots on a clip, layer or the composition. Shadertoy uniforms: iResolution, iTime, iBeat, iAudio (level,bass,mid,high), iParam (the 4 clip sliders). Compiled on the output GPU — errors show here.</div>`}` : ''}</div>`;
    },
    after(pane) {
      pane.onclick = e => { const t = e.target.closest('[data-sh]'); if (t) { curShader = t.dataset.sh; UI.renderBottom(true); } };
      const find = $('#shFind'); if (find) find.oninput = () => { shFilter = find.value; clearTimeout(find._t); find._t = setTimeout(() => { UI.renderBottom(true); const f = $('#shFind'); if (f) { f.focus(); f.setSelectionRange(f.value.length, f.value.length); } }, 250); };
      $('#shKind') && ($('#shKind').onchange = e => { shKind = e.target.value; UI.renderBottom(true); });
      const genClip = sh => { const info = UI.isfInfo(sh), params = Object.assign(S.genDefaults('shader'), { shader: sh.id }); if (info && info.ok !== false) params.isf = UI.isfDefaults(info); return { type: 'gen', name: sh.name, gen: { kind: 'shader', params } }; };
      pane.ondragstart = e => { const t = e.target.closest('[data-sh]'); if (!t) return; const sh = UI.st().shaders.find(x => x.id === t.dataset.sh); if (shKindOf(sh) === 'effect') { e.preventDefault(); UI.toast('ISF effects go in an effect slot — select a layer and press “Use as layer effect”'); return; } e.dataTransfer.setData('bvj/clip', JSON.stringify(genClip(sh))); };
      const save = () => UI.cmd({ op: 'shaderSave', shader: { id: curShader, name: $('#shName').value, code: $('#shCode').value } });
      $('#shSave') && ($('#shSave').onclick = () => { save(); UI.toast('Shader saved — compiling on output…', 'ok'); });
      $('#shCode') && $('#shCode').addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); e.stopPropagation(); save(); UI.toast('Shader saved', 'ok'); } if (e.key === 'Tab') { e.preventDefault(); document.execCommand('insertText', false, '  '); } });
      $('#shUse') && ($('#shUse').onclick = () => { const l = UI.st().layers[UI.sel.layer]; const slot = UI.sel.slot ?? Math.max(0, l.clips.findIndex(c => !c)); const sh = UI.st().shaders.find(x => x.id === curShader);
        UI.cmd({ op: 'assign', layer: UI.sel.layer, slot, clip: genClip(sh) }); UI.select(UI.sel.layer, slot); });
      const useFx = base => { const tgt = BVJ.get(base) || {}; const slot = !(tgt.isf && tgt.isf.on) || tgt.isf.shader === curShader ? 'isf' : !(tgt.isf2 && tgt.isf2.on) ? 'isf2' : 'isf';
        const sh = UI.st().shaders.find(x => x.id === curShader), info = UI.isfInfo(sh);
        UI.cmd({ op: 'set', path: `${base}.${slot}.shader`, value: curShader }); UI.cmd({ op: 'set', path: `${base}.${slot}.on`, value: true });
        if (info && info.ok !== false) UI.cmd({ op: 'isfVals', path: `${base}.${slot}`, key: 'v', reset: true, vals: UI.isfDefaults(info) });
        UI.toast(`${sh.name} on ${base === 'comp.fx' ? 'the composition' : 'layer ' + (UI.sel.layer + 1)} (${slot === 'isf' ? 'ISF Effect' : 'ISF Effect 2'})`, 'ok'); };
      $('#shFx') && ($('#shFx').onclick = () => useFx(`layers.${UI.sel.layer}.fx`));
      $('#shFxComp') && ($('#shFxComp').onclick = () => useFx('comp.fx'));
      $('#shTr') && ($('#shTr').onclick = () => { const li = UI.sel.layer; if (!UI.st().layers[li]) return UI.toast('Select a layer first', 'err'); UI.cmd({ op: 'set', path: `layers.${li}.transition`, value: 'isf:' + curShader }); UI.toast('Layer transition set — trigger a clip to see it'); });
      $('#shDel') && ($('#shDel').onclick = () => { if (confirm('Delete shader?')) UI.cmd({ op: 'shaderDelete', id: curShader }); });
      $('#shNew') && ($('#shNew').onclick = () => { const id = 'sh' + Math.random().toString(36).slice(2, 7); UI.cmd({ op: 'shaderSave', shader: { id, name: 'New shader', code: 'void mainImage(out vec4 o, in vec2 f){\n  vec2 uv = f / iResolution.xy;\n  o = vec4(uv, 0.5 + 0.5 * sin(iTime), 1.0);\n}' } }); curShader = id; });
      const pick = dir => { const i = document.createElement('input'); i.type = 'file'; i.multiple = true; if (dir) i.webkitdirectory = true; else i.accept = '.fs,.vs,.frag,.vert,.glsl,.txt,.png,.jpg,.jpeg,.gif,.webp';
        i.onchange = () => UI.importShaders([...i.files]); i.click(); };
      $('#shImp') && ($('#shImp').onclick = () => pick(false));
      $('#shImpDir') && ($('#shImpDir').onclick = () => pick(true));
      pane.ondragover = e => { if ([...(e.dataTransfer.types || [])].includes('Files')) e.preventDefault(); };
      pane.ondrop = e => { const fs = [...(e.dataTransfer.files || [])]; if (fs.length) { e.preventDefault(); UI.importShaders(fs); } };
    },
  };
  // Import ISF / GLSL: .fs paired with a same-named .vs; images an ISF imports (IMPORTED) are uploaded to the Local Library ▸ ISF folder
  UI.importShaders = async files => {
    const base = f => f.name.replace(/\.[^.]+$/, ''), ext = f => (f.name.split('.').pop() || '').toLowerCase();
    const frags = files.filter(f => ['fs', 'frag', 'glsl', 'txt'].includes(ext(f))), verts = new Map(files.filter(f => ['vs', 'vert'].includes(ext(f))).map(f => [base(f).toLowerCase(), f]));
    const images = new Map(files.filter(f => /^(png|jpe?g|gif|webp)$/.test(ext(f))).map(f => [f.name.toLowerCase(), f]));
    if (!frags.length) return UI.toast('No .fs / .glsl files in that selection', 'err');
    const existing = UI.st().shaders, uploaded = new Map(); let ok = 0, bad = 0, gens = 0, fxs = 0, trs = 0; const errs = [];
    for (const f of frags.slice(0, 500)) {
      const code = await f.text(), vf = verts.get(base(f).toLowerCase()), vs = vf ? await vf.text() : undefined; let files2 = {};
      if (window.PixoraISF && PixoraISF.isISF(code)) { const v = PixoraISF.validate(code, vs);
        if (!v.ok) { bad++; errs.push(`${f.name}: ${v.errors[0]}`); continue; }
        for (const im of v.info.imported) { const file = images.get(String(im.path).split('/').pop().toLowerCase()); if (!file) continue;
          if (!uploaded.has(file)) { try { const r = await UI.api('/api/upload?name=' + encodeURIComponent(file.name) + '&folder=ISF', { method: 'PUT', body: file }); uploaded.set(file, r.src); } catch { uploaded.set(file, ''); } }
          if (uploaded.get(file)) files2[im.name] = uploaded.get(file); }
        if (v.info.isTransition) trs++; else if (v.info.isFilter) fxs++; else gens++; }
      const name = base(f), same = existing.find(x => x.name === name && !x.builtin); // re-importing replaces the shader with the same name
      UI.cmd({ op: 'shaderSave', shader: { id: same ? same.id : 'sh' + Math.random().toString(36).slice(2, 8), name, code, vs: vs || '', files: files2 } }); ok++;
      if (ok === 1) curShader = same ? same.id : null;
    }
    UI.toast(`Imported ${ok} shader${ok === 1 ? '' : 's'}${gens || fxs || trs ? ` (${[gens && `${gens} generator${gens === 1 ? '' : 's'}`, fxs && `${fxs} effect${fxs === 1 ? '' : 's'}`, trs && `${trs} transition${trs === 1 ? '' : 's'}`].filter(Boolean).join(', ')})` : ''}${bad ? ` — ${bad} skipped` : ''}`, bad && !ok ? 'err' : 'ok');
    if (errs.length) console.warn('ISF import:\n' + errs.join('\n'));
  };

  /* ================= SHOW VERSIONS ================= */
  UI.verSel = [];
  UI.loadVersions = () => UI.api('/api/versions').then(v => { UI.versions = v; UI.verSel = UI.verSel.filter(id => v.versions.some(x => x.id === id)); if (UI.btab === 'shows') UI.renderBottom(true); }).catch(() => {});
  const when = t => { const d = new Date(t), now = new Date(), same = d.toDateString() === now.toDateString(); return (same ? 'Today ' : d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' }) + ' ') + d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' }); };
  UI.versionsSection = () => {
    const V = UI.versions; if (!V) return `<div class="sec"><h4>Versions</h4><div class="muted small">Loading…</div></div>`;
    const rows = V.versions.slice(0, 60).map(v => `<div class="src" style="cursor:default;align-items:flex-start;gap:6px"><input type="checkbox" data-versel="${v.id}" ${UI.verSel.includes(v.id) ? 'checked' : ''} title="Tick two to compare them">
        <div style="flex:1;min-width:0"><b>${esc(v.label)}</b>${v.auto ? ' <span class="cnt">auto</span>' : ''}<div class="small muted">${when(v.at)} · ${v.layers} layers · ${v.clips} clips · ${v.cues} cues${v.by ? ' · ' + esc(v.by) : ''}</div>${v.note ? `<div class="small">${esc(v.note)}</div>` : ''}</div>
        <button class="btn xs" data-vercmp="${v.id}" title="What changed since this version">Compare</button><button class="btn xs" data-verres="${v.id}">Restore</button><button class="btn xs" data-verren="${v.id}" title="Name / note">✎</button><button class="btn xs danger" data-verdel="${v.id}">${I('trash')}</button></div>`).join('');
    return `<div class="sec"><h4>Versions of “${esc(V.show)}”</h4>
      <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:6px;align-items:center"><button class="btn sm primary" data-versave>${I('save')}Save version…</button>
        <button class="btn sm" data-vercmp2 ${UI.verSel.length === 2 ? '' : 'disabled'} title="Tick two versions">Compare ticked</button>
        <span class="small muted">Automatic every</span><select data-verevery>${[[0, 'off'], [5, '5 min'], [10, '10 min'], [15, '15 min'], [30, '30 min'], [60, 'hour']].map(([m, l]) => `<option value="${m}" ${+V.every === m ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
      ${rows || '<div class="hint">No versions yet. Save one before a big change — or let the automatic versions catch you.</div>'}
      <div class="hint">A version is a full copy of the show. Automatic versions are taken on a timer when something changed, whenever you Save, and before opening, importing or restoring — the newest 40 are kept; named versions are kept until you delete them. Compare lists every difference by layer, clip slot, effect, output and cue, and lets you bring back single items. Restoring keeps whatever is playing on air.</div></div>`;
  };
  UI.versionClick = t => {
    const d = t.dataset; const V = UI.versions; const vOf = id => V.versions.find(v => v.id === id) || {};
    if (d.versave != null) { const m = UI.modal('Save version', `<div class="row wide"><label>Name</label><div class="ctl"><input type="text" id="verLbl" placeholder="e.g. After soundcheck"></div></div><div class="row wide"><label>Note</label><div class="ctl"><textarea id="verNote" rows="3" style="width:100%" placeholder="What changed, who asked for it…"></textarea></div></div>`,
        [{ label: 'Cancel' }, { label: 'Save version', cls: 'primary', click: bg => { UI.cmd({ op: 'versionSave', label: $('#verLbl', bg).value || 'Version', note: $('#verNote', bg).value }); UI.toast('Version saved', 'ok'); } }]); return true; }
    if (d.vercmp) { UI.compareVersions(d.vercmp, 'current'); return true; }
    if (d.vercmp2 != null) { const [a, b] = UI.verSel.slice().sort((x, y) => vOf(x).at - vOf(y).at); UI.compareVersions(a, b); return true; }
    if (d.verres) { if (confirm(`Restore “${vOf(d.verres).label}” from ${when(vOf(d.verres).at)}? The current show is saved as a version first; clips playing on air keep playing.`)) UI.cmd({ op: 'versionRestore', id: d.verres }); return true; }
    if (d.verdel) { if (confirm(`Delete version “${vOf(d.verdel).label}”?`)) UI.cmd({ op: 'versionDelete', id: d.verdel }); return true; }
    if (d.verren) { const v = vOf(d.verren); UI.modal('Version name', `<div class="row wide"><label>Name</label><div class="ctl"><input type="text" id="verLbl" value="${esc(v.label)}"></div></div><div class="row wide"><label>Note</label><div class="ctl"><textarea id="verNote" rows="3" style="width:100%">${esc(v.note || '')}</textarea></div></div><div class="hint">Naming an automatic version keeps it.</div>`,
        [{ label: 'Cancel' }, { label: 'Save', cls: 'primary', click: bg => UI.cmd({ op: 'versionRename', id: v.id, label: $('#verLbl', bg).value, note: $('#verNote', bg).value }) }]); return true; }
    return false;
  };
  document.addEventListener('change', e => { const t = e.target;
    if (t.dataset && t.dataset.versel) { UI.verSel = t.checked ? [...UI.verSel.filter(x => x !== t.dataset.versel), t.dataset.versel].slice(-2) : UI.verSel.filter(x => x !== t.dataset.versel); UI.renderBottom(true); }
    if (t.dataset && t.dataset.verevery != null) UI.cmd({ op: 'versionEvery', minutes: +t.value }); });
  const AREA = { comp: 'Composition', layers: 'Layers & clips', outputs: 'Outputs', cues: 'Cues', shaders: 'Shaders', luts: 'LUTs', presets: 'Looks', feeds: 'Data feeds', led: 'LED', timeline: 'Timeline' };
  const KIND = { added: ['+', 'var(--green, #3ddc84)'], removed: ['−', 'var(--red, #ff4d5e)'], changed: ['~', 'var(--amber, #ffb43f)'], replaced: ['⇄', 'var(--amber, #ffb43f)'], moved: ['↕', 'var(--accent, #c9f)'] };
  UI.compareVersions = async (a, b) => {
    let r; try { r = await UI.api(`/api/versions/compare?a=${encodeURIComponent(a)}&b=${encodeURIComponent(b)}`); } catch (e) { return UI.toast(e.message, 'err'); }
    const V = UI.versions, nm = id => id === 'current' ? 'the show now' : `“${(V.versions.find(v => v.id === id) || {}).label}” (${when((V.versions.find(v => v.id === id) || {}).at)})`;
    const canPick = b === 'current', groups = {}; for (const c of r.changes) (groups[c.area] = groups[c.area] || []).push(c);
    const body = r.changes.length ? Object.entries(groups).map(([area, list]) => `<h4 style="margin:10px 0 4px">${esc(AREA[area] || area)} <span class="muted small">${list.length}</span></h4>` + list.map((c, i) => {
      const [sym, col] = KIND[c.kind] || ['•', ''], back = canPick && c.pick && c.kind !== 'moved' ? `<button class="btn xs" data-pick="${esc(c.pick)}" title="${c.kind === 'added' ? 'Remove it again (as in the older version)' : 'Put it back the way it was'}">${c.kind === 'added' ? 'Undo add' : 'Bring back'}</button>` : '';
      return `<div style="border-left:3px solid ${col};padding:3px 8px;margin:3px 0"><div style="display:flex;gap:6px;align-items:center"><b style="color:${col};width:14px">${sym}</b><span style="flex:1">${esc(c.label)}</span>${back}</div>
        ${c.fields ? `<div class="small mono" style="margin:2px 0 0 20px;color:var(--muted, #8b8b99)">${c.fields.slice(0, 8).map(f => `${esc(f.path)}: <s>${esc(f.from)}</s> → ${esc(f.to)}`).join('<br>')}${c.fields.length > 8 || c.more ? `<br>…and ${c.fields.length - 8 + (c.more || 0)} more` : ''}</div>` : ''}</div>`; }).join('')).join('')
      : '<div class="hint">No differences — these are the same show.</div>';
    const counts = Object.entries(r.counts).map(([k, n]) => `${n} ${k}`).join(' · ');
    const m = UI.modal(`Compare ${nm(a)} → ${nm(b)}`, `<div class="small muted" style="margin-bottom:6px">${counts || 'identical'}${canPick ? ' · “Bring back” copies that item from the older version into the live show (undo works)' : ''}</div><div style="max-height:62vh;overflow:auto">${body}</div>`,
      [{ label: 'Close' }, ...(a !== 'current' ? [{ label: 'Export older as .pixora', click: () => { location.href = '/api/versions/export?id=' + encodeURIComponent(a); return false; } }] : [])], { width: 'min(860px, 94vw)' });
    m.addEventListener('click', e => { const t = e.target.closest('[data-pick]'); if (!t) return; UI.cmd({ op: 'versionPick', id: a, pick: t.dataset.pick }); t.disabled = true; t.textContent = 'Done'; });
  };

  /* ================= LUTS ================= */
  let curLut = null; const lutCache = new Map(); // id:rev → parsed LUT, for the swatch preview
  const lutLoad = l => { const k = l.id + ':' + l.rev; if (lutCache.has(k)) return Promise.resolve(lutCache.get(k));
    return fetch('/api/luts/' + l.id).then(r => r.ok ? r.text() : Promise.reject(new Error('HTTP ' + r.status))).then(t => { const L = PixoraLUT.parse(t, '.' + (l.ext || 'cube')); lutCache.set(k, L); return L; }); };
  function lutSwatch(cv, L) { // top half: hue sweep + grey ramp as they are; bottom half: through the LUT
    const g = cv.getContext('2d'), W = cv.width, H = cv.height, im = g.createImageData(W, H);
    for (let x = 0; x < W; x++) for (let y = 0; y < H; y++) { const u = x / (W - 1), row = (y % (H / 2)) / (H / 2); let c;
      if (row < 0.5) { const h = u * 6, k = h - Math.floor(h), q = 1 - k; c = [[1, k, 0], [q, 1, 0], [0, 1, k], [0, q, 1], [k, 0, 1], [1, 0, q]][Math.min(5, Math.floor(h))].map(v => v * (0.35 + 0.65 * (1 - row * 1.2))); }
      else c = [u, u, u];
      if (y >= H / 2 && L) c = PixoraLUT.apply(L, c); const o = (y * W + x) * 4; im.data[o] = c[0] * 255; im.data[o + 1] = c[1] * 255; im.data[o + 2] = c[2] * 255; im.data[o + 3] = 255; }
    g.putImageData(im, 0, 0);
  }
  UI.bpanels.luts = {
    sig: s => JSON.stringify([(s.luts || []).map(l => [l.id, l.name, l.rev]), curLut, UI.sel.layer, s.outputs.map(o => [o.id, o.name])]),
    tools: () => `<button class="btn sm" id="lutImp">${I('upload')}Import .cube / .3dl</button>`,
    render(s) {
      const luts = s.luts || []; if (!curLut || !luts.find(l => l.id === curLut)) curLut = luts[0] && luts[0].id; const l = luts.find(x => x.id === curLut);
      return `<div class="libside">${luts.map(x => `<div class="src ${x.id === curLut ? 'on' : ''}" data-lut="${x.id}">${I('eye')}${esc(x.name)}<span class="cnt">${x.kind === '1d' ? '1D' : x.size + '³'}</span></div>`).join('') || '<div class="hint">No LUTs yet. Import .cube (Resolve, Premiere, Photoshop, most cameras) or .3dl (Lustre, Nuke, Flame) files, or drop them here.</div>'}</div>
        <div class="libmain">${l ? `<div style="display:flex;gap:6px;margin-bottom:6px;flex-wrap:wrap"><input type="text" id="lutName" value="${esc(l.name)}" style="flex:1;min-width:120px"><button class="btn sm danger" id="lutDel">${I('trash')}</button></div>
          <div class="small muted" style="margin-bottom:6px">${l.kind === '1d' ? `1D LUT, ${l.size} entries` : `3D LUT, ${l.size}×${l.size}×${l.size}`}${l.title ? ' · ' + esc(l.title) : ''} · .${esc(l.ext || 'cube')}</div>
          <canvas id="lutSw" width="512" height="96" style="width:100%;max-width:640px;height:96px;border-radius:6px;image-rendering:auto"></canvas><div class="small muted" style="margin:2px 0 8px">Top: original · bottom: through the LUT</div>
          <div style="display:flex;gap:6px;flex-wrap:wrap"><button class="btn sm primary" data-lutapply="layer">${I('plus')}Apply to layer ${UI.sel.layer + 1}</button><button class="btn sm" data-lutapply="clip" ${UI.sel.slot == null ? 'disabled' : ''}>${I('plus')}Selected clip</button><button class="btn sm" data-lutapply="comp">${I('plus')}Composition</button>
            <select id="lutOut"><option value="">Output display LUT…</option>${s.outputs.map(o => `<option value="${esc(o.id)}">${esc(o.name)}</option>`).join('')}</select></div>
          <div class="hint">Applying turns on a LUT slot (LUT, or LUT 2 if the first is taken by another LUT) in that effect stack — adjust Intensity, exposure, white balance, contrast, saturation and output gain there. Output display LUTs are in Output ▸ each output ▸ Display LUT. Re-importing a file with the same name updates it everywhere it is used.</div>` : ''}</div>`;
    },
    after(pane) {
      pane.onclick = e => { const t = e.target.closest('[data-lut]'); if (t) { curLut = t.dataset.lut; UI.renderBottom(true); return; }
        const a = e.target.closest('[data-lutapply]'); if (a) UI.applyLut(curLut, a.dataset.lutapply); };
      const l = (UI.st().luts || []).find(x => x.id === curLut), cv = $('#lutSw');
      if (cv) { lutSwatch(cv, null); if (l) lutLoad(l).then(L => { if ($('#lutSw') === cv) lutSwatch(cv, L); }).catch(err => UI.toast('LUT: ' + err.message, 'err')); }
      $('#lutName') && ($('#lutName').onchange = e => UI.cmd({ op: 'lutRename', id: curLut, name: e.target.value }));
      $('#lutDel') && ($('#lutDel').onclick = () => { if (confirm('Delete this LUT? Effect slots using it will pass the picture through.')) UI.cmd({ op: 'lutDelete', id: curLut }); });
      $('#lutOut') && ($('#lutOut').onchange = e => { if (e.target.value) UI.applyLut(curLut, 'out:' + e.target.value); e.target.value = ''; });
      $('#lutImp') && ($('#lutImp').onclick = () => { const i = document.createElement('input'); i.type = 'file'; i.multiple = true; i.accept = '.cube,.3dl'; i.onchange = () => UI.importLuts([...i.files]); i.click(); });
      pane.ondragover = e => { if ([...(e.dataTransfer.types || [])].includes('Files')) e.preventDefault(); };
      pane.ondrop = e => { const fs = [...(e.dataTransfer.files || [])].filter(f => /\.(cube|3dl)$/i.test(f.name)); if (fs.length) { e.preventDefault(); UI.importLuts(fs); } };
    },
  };
  UI.importLuts = async files => {
    let ok = 0; const errs = []; let last = null;
    for (const f of files.filter(f => /\.(cube|3dl)$/i.test(f.name)).slice(0, 200)) {
      try { const r = await fetch('/api/luts?name=' + encodeURIComponent(f.name), { method: 'POST', body: f }); const j = await r.json(); if (!r.ok) throw new Error(j.error || 'HTTP ' + r.status); ok++; last = j.lut.id; }
      catch (e) { errs.push(e.message); } }
    if (last) curLut = last;
    UI.toast(ok ? `Imported ${ok} LUT${ok === 1 ? '' : 's'}${errs.length ? ` — ${errs.length} failed: ${errs[0]}` : ''}` : (errs[0] || 'No .cube / .3dl files'), ok ? 'ok' : 'err');
  };
  UI.applyLut = (id, where) => {
    const s = UI.st(); let base, label;
    if (where === 'layer') { base = `layers.${UI.sel.layer}.fx`; label = 'layer ' + (UI.sel.layer + 1); }
    else if (where === 'comp') { base = 'comp.fx'; label = 'the composition'; }
    else if (where === 'clip') { const c = s.layers[UI.sel.layer].clips[UI.sel.slot]; if (!c) return UI.toast('Select a clip first', 'err');
      if (!c.fx) UI.cmd({ op: 'clipFx', layer: UI.sel.layer, slot: UI.sel.slot, on: true }); base = `layers.${UI.sel.layer}.clips.${UI.sel.slot}.fx`; label = 'the selected clip'; }
    else if (where.startsWith('out:')) { const oi = s.outputs.findIndex(o => o.id === where.slice(4)); if (oi < 0) return;
      UI.cmd({ op: 'set', path: `outputs.${oi}.lut.lut`, value: id }); UI.cmd({ op: 'set', path: `outputs.${oi}.lut.on`, value: true }); return UI.toast(`Display LUT on ${s.outputs[oi].name}`, 'ok'); }
    const fx = BVJ.get(base) || {}; const slot = !(fx.lut && fx.lut.on) || fx.lut.lut === id ? 'lut' : !(fx.lut2 && fx.lut2.on) ? 'lut2' : 'lut';
    setTimeout(() => { UI.cmd({ op: 'set', path: `${base}.${slot}.lut`, value: id }); UI.cmd({ op: 'set', path: `${base}.${slot}.on`, value: true }); }, where === 'clip' ? 150 : 0);
    UI.toast(`LUT on ${label} (${slot === 'lut' ? 'LUT' : 'LUT 2'})`, 'ok');
  };

  /* ================= LOOKS ================= */
  UI.bpanels.looks = {
    sig: s => JSON.stringify(s.presets.map(p => [p.id, p.name, p.fav])),
    tools: () => `<button class="btn sm" id="lookSaveL">${I('save')}Save selected layer look</button><button class="btn sm" id="lookSaveC">${I('save')}Save comp look</button>`,
    render(s) {
      if (!s.presets.length) return `<div class="libmain"><div class="empty-note">No looks saved yet. A look stores a full effect stack (and blend mode) so you can recall it on any layer or the whole composition.</div></div>`;
      const sorted = [...s.presets].sort((a, b) => (b.fav ? 1 : 0) - (a.fav ? 1 : 0));
      return `<div class="libmain"><div class="cards" style="--card-w:210px">${sorted.map(p => { const fx = S.FX.filter(f => p.fx[f.id] && p.fx[f.id].on).map(f => f.name);
        return `<div class="gtile" data-look="${p.id}"><div style="display:flex;width:100%;align-items:center;gap:6px"><b style="flex:1">${esc(p.name)}</b><span class="stars"><i class="${p.fav ? 'on' : ''}" data-fav="${p.id}">★</i></span></div>
          <span>${fx.length ? esc(fx.join(' · ')) : 'No effects'}${p.blend ? ' · ' + esc(p.blend) : ''}</span>
          <div style="display:flex;gap:4px"><button class="btn xs" data-applyl="${p.id}">Apply to layer</button><button class="btn xs" data-applyc="${p.id}">Apply to comp</button><button class="btn xs danger" data-dell="${p.id}">${I('trash')}</button></div></div>`; }).join('')}</div></div>`;
    },
    after(pane) {
      $('#lookSaveL') && ($('#lookSaveL').onclick = async () => { const n = await UI.prompt('Look name', UI.st().layers[UI.sel.layer].name + ' look'); if (n) UI.cmd({ op: 'presetSave', layer: UI.sel.layer, name: n }); });
      $('#lookSaveC') && ($('#lookSaveC').onclick = async () => { const n = await UI.prompt('Look name', 'Comp look'); if (n) UI.cmd({ op: 'presetSave', layer: null, name: n }); });
      pane.onclick = e => { const t = e.target.closest('[data-applyl],[data-applyc],[data-dell],[data-fav]'); if (!t) return; const d = t.dataset;
        if (d.applyl) UI.cmd({ op: 'presetApply', id: d.applyl, layer: UI.sel.layer }); if (d.applyc) UI.cmd({ op: 'presetApply', id: d.applyc, layer: null });
        if (d.dell) UI.cmd({ op: 'presetDelete', id: d.dell }); if (d.fav) { const i = UI.st().presets.findIndex(p => p.id === d.fav); BVJ.cmd({ op: 'set', path: `presets.${i}.fav`, value: !UI.st().presets[i].fav }); } };
    },
  };

  /* ================= SHOWS & JOBS ================= */
  UI.bpanels.shows = {
    sig: () => JSON.stringify([UI.comps, UI.jobs.map(j => [j.id, j.status, Math.round(j.progress * 50)]), UI.versions && UI.versions.versions.map(v => [v.id, v.label, v.note]), UI.versions && UI.versions.every, UI.verSel]),
    tools: () => `<button class="btn sm primary" id="shSaveAs">${I('save')}Save as…</button><button class="btn sm" id="shExp">${I('upload')}Export .pixora</button><button class="btn sm" id="shImpF">${I('folder')}Import</button><button class="btn sm" id="shCol">${I('drive')}Collect for offline</button><button class="btn sm" id="shRel">${I('link')}Relink</button>`,
    render(s) {
      return `<div class="libmain"><div class="grid2" style="align-items:start"><div class="sec"><h4>Saved compositions (on this server)</h4>
        ${UI.comps.length ? UI.comps.map(c => `<div class="src" style="cursor:default">${I('save')}<span style="flex:1">${esc(c)}</span><button class="btn xs primary" data-load="${esc(c)}">Load</button><button class="btn xs danger" data-delc="${esc(c)}">${I('trash')}</button></div>`).join('') : '<div class="muted">None yet — use Save (Ctrl+S).</div>'}
        <div class="hint">Everything also autosaves continuously, so a power cut or restart resumes exactly where you were. Show files (.pixora) are portable: they include the composition, decks, cues, outputs, mappings, looks and shaders, with references to the media.</div></div>
        ${UI.versionsSection()}
        <div class="sec"><h4>Background jobs</h4>${UI.jobs.length ? `<div class="jobs">${UI.jobs.slice().reverse().map(j => `<div class="job"><span style="width:62px" class="muted">${j.type}</span><span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(j.error || '')}">${esc(j.name)}</span><div class="meter" style="max-width:120px"><i style="width:${(j.progress || 0) * 100}%"></i></div><span class="mono" style="width:56px;text-align:right;color:${j.status === 'error' ? 'var(--red)' : j.status === 'done' ? 'var(--green)' : ''}">${j.status === 'running' ? Math.round(j.progress * 100) + '%' : j.status}</span></div>${j.error ? `<div class="small" style="color:var(--red)">${esc(j.error)}</div>` : ''}`).join('')}</div>` : '<div class="muted">No jobs.</div>'}
        <div class="hint">ffmpeg conversion and show collection run here on the server computer, one at a time.</div></div></div></div>`;
    },
    after(pane) {
      $('#shSaveAs').onclick = () => UI.saveComp(true);
      $('#shExp').onclick = () => { location.href = '/api/show/export?name=' + encodeURIComponent(UI.st().comp.name); };
      $('#shImpF').onclick = () => $('#showIn').click(); $('#shCol').onclick = () => UI.collectShow(); $('#shRel').onclick = () => UI.relink();
      if (!UI.versions || UI.versions.show !== UI.st().comp.name) UI.loadVersions();
      pane.onclick = e => { const t = e.target.closest('button'); if (!t) return; if (UI.versionClick(t)) return;
        if (t.dataset.load && confirm('Load "' + t.dataset.load + '"? Unsaved changes to the current composition will be replaced.')) UI.cmd({ op: 'loadComp', name: t.dataset.load });
        if (t.dataset.delc && confirm('Delete saved composition "' + t.dataset.delc + '"?')) UI.cmd({ op: 'deleteComp', name: t.dataset.delc }); };
    },
  };
})();
