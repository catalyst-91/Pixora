/* PIXORA bottom panel: media library, sources/drives, generators, inputs, shaders, looks, shows & jobs */
(function () {
  const S = window.SCHEMA, UI = window.UI, $ = UI.$, $$ = UI.$$, esc = UI.esc, I = UI.icon;
  const F = UI.libFilter = { source: localStorage.bvjLibSrc || 'all', folder: '', q: '', tag: '', sort: 'name', sel: new Set(), last: null };
  const fmtSize = n => n > 1e9 ? (n / 1e9).toFixed(1) + ' GB' : n > 1e6 ? (n / 1e6).toFixed(0) + ' MB' : Math.round(n / 1e3) + ' KB';
  function allItems() { const out = []; for (const s of UI.library.sources) if (F.source === 'all' || F.source === s.id) for (const it of s.items) out.push(it); return out; }
  function filtered() {
    let a = allItems(); if (F.folder) a = a.filter(i => i.folder === F.folder || i.folder.startsWith(F.folder + '/'));
    if (F.q) { const q = F.q.toLowerCase(); a = a.filter(i => (i.folder + '/' + i.name).toLowerCase().includes(q) || ((i.meta && i.meta.tags) || []).some(t => t.includes(q))); }
    if (F.tag) a = a.filter(i => ((i.meta && i.meta.tags) || []).includes(F.tag));
    if (F.sort === 'rating') a = [...a].sort((x, y) => ((y.meta && y.meta.rating) || 0) - ((x.meta && x.meta.rating) || 0));
    else if (F.sort === 'size') a = [...a].sort((x, y) => y.size - x.size);
    else if (F.sort === 'duration') a = [...a].sort((x, y) => ((y.meta && y.meta.duration) || 0) - ((x.meta && x.meta.duration) || 0));
    return a;
  }

  /* ================= FILES ================= */
  UI.bpanels.files = {
    sig: () => JSON.stringify([UI.libVersion, F.source, F.folder, F.q, F.tag, F.sort, [...F.sel], UI.thumbV, UI.jobs.map(j => [j.src, j.status, Math.round(j.progress * 20)])]),
    tools: () => `<input type="search" id="libQ" placeholder="Search files & tags…" value="${esc(F.q)}" style="width:180px">
      <select id="libSort"><option value="name">Name</option><option value="rating">Rating</option><option value="duration">Duration</option><option value="size">Size</option></select>
      <button class="btn sm" id="libSend" ${F.sel.size ? '' : 'disabled'} title="Fill the selected layer from its selected slot">${I('play')}Send ${F.sel.size || ''} to layer</button>
      <button class="btn sm" id="libUp">${I('upload')}Upload</button><button class="btn sm icon" id="libRef" title="Rescan sources">${I('refresh')}</button>`,
    render() {
      const srcs = UI.library.sources;
      let side = `<div class="src ${F.source === 'all' ? 'on' : ''}" data-src="all">${I('folder')}All media<span class="cnt">${srcs.reduce((n, s) => n + s.items.length, 0)}</span></div>`;
      for (const s of srcs) {
        side += `<div class="src ${F.source === s.id ? 'on' : ''}" data-src="${s.id}" title="${esc(s.path)}"><span class="dot ${s.online ? '' : 'off'}"></span>${I(s.kind === 'local' ? 'folder' : 'drive')}<span style="overflow:hidden;text-overflow:ellipsis">${esc(s.name)}</span><span class="cnt">${s.online ? s.items.length : 'offline'}</span></div>`;
        if (F.source === s.id) { const folders = [...new Set(s.items.map(i => i.folder).filter(Boolean).map(f => f.split('/')[0]))].sort(); for (const f of folders) side += `<div class="src folder ${F.folder === f ? 'on' : ''}" data-folder="${esc(f)}">${esc(f)}</div>`; }
      }
      const tags = [...new Set(allItems().flatMap(i => (i.meta && i.meta.tags) || []))].sort();
      if (tags.length) side += `<div class="tlabel" style="margin:10px 4px 4px">Tags</div><div style="padding:0 4px">${tags.map(t => `<span class="tagchip ${F.tag === t ? 'on' : ''}" data-tag="${esc(t)}">${esc(t)}</span>`).join('')}</div>`;
      const running = UI.jobs.filter(j => j.status === 'running' || j.status === 'queued');
      const items = filtered();
      let main = running.length ? `<div class="jobs" style="margin-bottom:8px">${running.map(j => `<div class="job"><span>${j.type === 'convert' ? 'Converting' : 'Collecting'} ${esc(j.name)}</span><div class="meter"><i style="width:${(j.progress || 0) * 100}%"></i></div><span class="mono">${Math.round((j.progress || 0) * 100)}%</span></div>`).join('')}</div>` : '';
      if (!items.length) main += `<div class="dropzone" id="dz">${srcs.length ? 'No media here yet.' : 'Loading…'}<br>Drop video / image files here to upload to the Local Library, or add an external drive / folder in <b>Sources &amp; Drives</b>.<br><span class="small">All common formats supported: MP4, MOV, WebM, MKV, AVI, WMV, MPEG, MTS, MXF, ProRes, FLV… (non-browser formats are converted locally with ffmpeg)</span></div>`;
      else main += `<div class="cards">${items.slice(0, 1500).map(it => this.card(it)).join('')}</div>${items.length > 1500 ? `<p class="muted">Showing 1500 of ${items.length} — refine the search.</p>` : ''}`;
      return `<div class="libside">${side}</div><div class="libmain" id="libMain">${main}</div>`;
    },
    card(it) {
      const m = it.meta || {}; const r = m.rating || 0;
      const th = it.kind === 'image' ? BVJ.mediaUrl(it.src) : it.thumb ? BVJ.thumbUrl(it.src, UI.thumbV) : '';
      const job = UI.jobs.find(j => j.src === it.src && (j.status === 'running' || j.status === 'queued'));
      const bdg = job ? `<span class="bdg run">${Math.round((job.progress || 0) * 100)}%</span>` : !it.playable ? `<span class="bdg conv">convert</span>` : it.converted ? `<span class="bdg ok">converted</span>` : it.kind === 'image' ? `<span class="bdg ok">image</span>` : '';
      return `<div class="mcard ${F.sel.has(it.src) ? 'sel' : ''}" draggable="true" data-src="${esc(it.src)}" title="${esc(it.folder ? it.folder + '/' : '')}${esc(it.name)}">
        <div class="th" style="${th ? `background-image:url('${th}')` : ''}">${th ? '' : I(it.kind === 'image' ? 'eye' : 'play')}${bdg}${m.duration ? `<span class="dur">${BVJ.fmtTime(m.duration)}</span>` : ''}</div>
        <div class="meta"><div class="nm">${esc(it.name)}</div><div class="sub">${m.w ? m.w + '×' + m.h : fmtSize(it.size)}<span class="stars">${[1, 2, 3, 4, 5].map(n => `<i class="${n <= r ? 'on' : ''}" data-rate="${n}">★</i>`).join('')}</span></div>
        ${(m.tags || []).length ? `<div style="margin-top:3px">${m.tags.map(t => `<span class="tagchip">${esc(t)}</span>`).join('')}</div>` : ''}</div></div>`;
    },
    after(pane) {
      const main = $('#libMain', pane);
      $('#libQ') && ($('#libQ').oninput = e => { F.q = e.target.value; clearTimeout(this._q); this._q = setTimeout(() => { UI.renderBottom(true); const q = $('#libQ'); if (q) { q.focus(); q.setSelectionRange(q.value.length, q.value.length); } }, 200); });
      $('#libSort') && ($('#libSort').value = F.sort, $('#libSort').onchange = e => { F.sort = e.target.value; UI.renderBottom(true); });
      $('#libUp') && ($('#libUp').onclick = () => $('#fileIn').click());
      $('#libRef') && ($('#libRef').onclick = () => UI.loadLibrary(true));
      $('#libSend') && ($('#libSend').onclick = () => { const items = filtered().filter(i => F.sel.has(i.src)); UI.cmd({ op: 'fillLayer', layer: UI.sel.layer, start: UI.sel.slot == null ? (UI.st().layers[UI.sel.layer].clips.findIndex(c => !c) + 1 || 1) - 1 : UI.sel.slot, items: items.map(UI.mediaClip) }); F.sel.clear(); UI.toast(items.length + ' clip(s) sent to ' + UI.st().layers[UI.sel.layer].name, 'ok'); });
      pane.onclick = e => {
        const s = e.target.closest('[data-src].src'); if (s) { F.source = s.dataset.src; F.folder = ''; localStorage.bvjLibSrc = F.source; return UI.renderBottom(true); }
        const fo = e.target.closest('[data-folder]'); if (fo) { F.folder = F.folder === fo.dataset.folder ? '' : fo.dataset.folder; return UI.renderBottom(true); }
        const tg = e.target.closest('[data-tag]'); if (tg) { F.tag = F.tag === tg.dataset.tag ? '' : tg.dataset.tag; return UI.renderBottom(true); }
        const rt = e.target.closest('[data-rate]'); if (rt) { const src = rt.closest('.mcard').dataset.src; const cur = (UI.libIndex.get(src).meta || {}).rating || 0; const n = +rt.dataset.rate; UI.api('/api/meta?src=' + encodeURIComponent(src), { method: 'POST', body: JSON.stringify({ rating: cur === n ? 0 : n }) }); return; }
        const c = e.target.closest('.mcard'); if (!c) return; const src = c.dataset.src;
        if (e.shiftKey && F.last) { const list = filtered().map(i => i.src); const a = list.indexOf(F.last), b = list.indexOf(src); for (let i = Math.min(a, b); i <= Math.max(a, b); i++) F.sel.add(list[i]); }
        else if (e.ctrlKey || e.metaKey) { F.sel.has(src) ? F.sel.delete(src) : F.sel.add(src); }
        else { F.sel.clear(); F.sel.add(src); }
        F.last = src; UI.renderBottom(true);
      };
      pane.ondblclick = e => { const c = e.target.closest('.mcard'); if (!c) return; const it = UI.libIndex.get(c.dataset.src); const s = UI.st(); const l = s.layers[UI.sel.layer];
        let slot = UI.sel.slot != null && !l.clips[UI.sel.slot] ? UI.sel.slot : l.clips.findIndex(x => !x); if (slot < 0) slot = UI.sel.slot ?? 0;
        UI.cmd({ op: 'assign', layer: UI.sel.layer, slot, clip: UI.mediaClip(it) }); UI.cmd({ op: 'trigger', layer: UI.sel.layer, clip: slot }); UI.select(UI.sel.layer, slot); };
      pane.oncontextmenu = e => { const c = e.target.closest('.mcard'); if (!c) return; e.preventDefault(); const it = UI.libIndex.get(c.dataset.src);
        UI.menu(e.clientX, e.clientY, [
          { label: 'Edit tags…', icon: 'wand', click: async () => { const t = await UI.prompt('Tags (comma separated)', ((it.meta && it.meta.tags) || []).join(', '), 'Tags'); if (t != null) UI.api('/api/meta?src=' + encodeURIComponent(it.src), { method: 'POST', body: JSON.stringify({ tags: t.split(',') }) }); } },
          ...(it.kind === 'video' ? [{ label: it.converted ? 'Re-convert (ffmpeg)' : 'Convert for smooth playback (ffmpeg)', icon: 'refresh', click: () => UI.convert(it.src) }] : []),
          ...(it.converted ? [{ label: 'Remove converted copy', icon: 'trash', click: () => UI.api('/api/convert?src=' + encodeURIComponent(it.src), { method: 'DELETE' }) }] : []),
          ...(it.src.startsWith('local/') ? ['-', { label: 'Delete file from Local Library', icon: 'trash', click: () => { if (confirm('Delete ' + it.name + ' from disk?')) UI.api('/api/media?src=' + encodeURIComponent(it.src), { method: 'DELETE' }).catch(er => UI.toast(er.message, 'err')); } }] : [])]); };
      pane.ondragstart = e => { const c = e.target.closest('.mcard'); if (!c) return; const src = c.dataset.src; const list = F.sel.has(src) && F.sel.size > 1 ? filtered().filter(i => F.sel.has(i.src)) : [UI.libIndex.get(src)];
        e.dataTransfer.setData('bvj/media', JSON.stringify(list)); e.dataTransfer.effectAllowed = 'copy'; };
      const dz = main; dz.ondragover = e => { if (e.dataTransfer.types.includes('Files')) { e.preventDefault(); const z = $('#dz'); if (z) z.classList.add('over'); } };
      dz.ondrop = e => { if (!e.dataTransfer.files.length) return; e.preventDefault(); UI.uploadFiles([...e.dataTransfer.files], F.folder); };
    },
  };
  $('#fileIn').addEventListener('change', e => { UI.uploadFiles([...e.target.files], F.folder); e.target.value = ''; });

  /* ================= SOURCES & DRIVES ================= */
  let drives = null;
  UI.bpanels.sources = {
    sig: () => JSON.stringify([UI.libVersion, drives && drives.length]),
    tools: () => `<button class="btn sm primary" id="addSrc">${I('plus')}Add folder / drive…</button><button class="btn sm" id="srcRef">${I('refresh')}Rescan</button>`,
    render() {
      const srcs = UI.library.sources;
      let h = `<div class="libmain"><div class="grid2" style="align-items:start"><div><div class="sec"><h4>Library sources</h4>`;
      h += srcs.map(s => `<div class="card"><header style="cursor:default"><span class="dot" style="width:8px;height:8px;border-radius:50%;background:${s.online ? 'var(--green)' : 'var(--red)'}"></span>${I(s.kind === 'local' ? 'folder' : 'drive')}<b>${esc(s.name)}</b><span class="muted small">${s.online ? s.items.length + ' files' : 'OFFLINE — drive not connected'}</span>
        ${s.id !== 'local' ? `<button class="btn xs danger" data-rmsrc="${s.id}">Remove</button>` : ''}</header><div class="body small mono muted" style="word-break:break-all">${esc(s.path)}</div></div>`).join('');
      h += `<div class="hint">Sources are folders on the computer running the PIXORA server — internal disks, USB / Thunderbolt external drives, NAS shares or network mounts. They're read-only: files are streamed directly from the drive. If a drive is unplugged it shows OFFLINE and its clips come back when reconnected (even on a different drive letter — use Relink).</div></div></div>`;
      h += `<div><div class="sec"><h4>Detected drives</h4>${drives ? drives.map(d => `<div class="src" style="cursor:default">${I('drive')}<span style="flex:1;overflow:hidden;text-overflow:ellipsis" title="${esc(d.path)}">${esc(d.label)} <span class="muted mono small">${esc(d.path)}</span></span><button class="btn xs" data-adddrive="${esc(d.path)}">Add whole drive</button><button class="btn xs" data-browse="${esc(d.path)}">Browse…</button></div>`).join('') : '<div class="muted">Scanning…</div>'}
        <div class="row wide" style="margin-top:8px"><label>Path</label><div class="ctl"><input type="text" id="srcPath" placeholder="E:\\VJ Loops  or  /Volumes/SSD/Content"><button class="btn sm" id="srcAddPath">Add</button></div></div>
        <div class="hint">Running PIXORA in Docker? Drives must be mounted into the container (see manual) — or run it natively with start.ps1 / start.sh to see every drive.</div></div></div></div></div>`;
      return h;
    },
    after(pane) {
      if (!drives) UI.api('/api/drives').then(r => { drives = r.drives; UI.renderBottom(true); }).catch(() => { drives = []; });
      const add = async (p, name) => { try { await UI.api('/api/sources', { method: 'POST', body: JSON.stringify({ path: p, name }) }); UI.toast('Added ' + p, 'ok'); UI.loadLibrary(true); } catch (e) { UI.toast(e.message, 'err'); } };
      $('#addSrc').onclick = () => UI.browseFolder('Add library folder or drive', p => add(p));
      $('#srcRef').onclick = () => { drives = null; UI.loadLibrary(true); };
      pane.onclick = e => { const t = e.target.closest('button'); if (!t) return;
        if (t.dataset.rmsrc) UI.api('/api/sources?id=' + t.dataset.rmsrc, { method: 'DELETE' }).then(() => UI.loadLibrary());
        if (t.dataset.adddrive) add(t.dataset.adddrive);
        if (t.dataset.browse) UI.browseFolder('Add library folder', p => add(p));
        if (t.id === 'srcAddPath') add($('#srcPath').value.trim()); };
    },
  };

  /* ================= GENERATORS ================= */
  UI.bpanels.gens = {
    render() {
      return `<div class="libmain"><div class="hint" style="margin-top:0">Drag a generator onto any clip slot. Generators are rendered procedurally on the GPU at the composition's exact resolution.</div><div class="cards" style="--card-w:150px">${S.GENERATORS.map(g => {
        const c = { type: 'gen', gen: { kind: g.id, params: S.genDefaults(g.id) } };
        return `<div class="gtile" draggable="true" data-gen="${g.id}"><div class="gi" style="background:${UI.genBg(c)}"></div><b>${g.name}</b><span>${g.params.length} parameters</span></div>`; }).join('')}</div></div>`;
    },
    after(pane) {
      pane.ondragstart = e => { const t = e.target.closest('[data-gen]'); if (!t) return; const k = t.dataset.gen; const g = S.GENERATORS.find(x => x.id === k);
        e.dataTransfer.setData('bvj/clip', JSON.stringify({ type: 'gen', name: g.name, gen: { kind: k, params: S.genDefaults(k) } })); };
      pane.ondblclick = e => { const t = e.target.closest('[data-gen]'); if (!t) return; const l = UI.st().layers[UI.sel.layer]; const slot = UI.sel.slot ?? Math.max(0, l.clips.findIndex(c => !c)); UI.assignGen(UI.sel.layer, slot, t.dataset.gen); };
    },
  };

  /* ================= INPUTS & WEB ================= */
  UI.bpanels.inputs = {
    sig: () => JSON.stringify(UI.outputs.map(o => o.info && o.info.devices)),
    tools: () => `<button class="btn sm" id="scanIn">${I('refresh')}Scan inputs on output computer</button>`,
    render() {
      const p = UI.outputs.find(o => o.primary) || UI.outputs[0]; const devs = (p && p.info && p.info.devices) || { video: [] };
      const tile = (clip, icon, title, sub) => `<div class="gtile" draggable="true" data-clip='${esc(JSON.stringify(clip))}'><div class="gi" style="display:flex;align-items:center;justify-content:center;background:#0d0e12;color:var(--accent)">${I(icon)}</div><b>${esc(title)}</b><span>${esc(sub)}</span></div>`;
      return `<div class="libmain"><div class="grid2" style="align-items:start;grid-template-columns:2fr 1fr"><div><div class="sec"><h4>Live inputs</h4><div class="cards" style="--card-w:150px">
        ${tile({ type: 'screen', name: 'Screen capture', fit: 'fit' }, 'screen', 'Screen / Tab capture', 'Any screen, window or browser tab')}
        ${tile({ type: 'replay', name: 'Replay', unit: 'auto', fit: 'fit' }, 'restart', 'Replay', 'Instant replay (units A–D)')}
        ${tile({ type: 'capture', name: 'Camera', device: '', fit: 'fill' }, 'cam', 'Default camera', 'Webcam / capture card')}
        ${devs.video.map(v => tile({ type: 'capture', name: v.label.slice(0, 32), device: v.id, fit: 'fill' }, 'cam', v.label, 'Live input')).join('')}
        ${(UI.ndiSources || []).map(n => tile({ type: 'ndi', name: n.slice(0, 32), ndi: n, fit: 'fit' }, 'cam', n, 'NDI® source')).join('')}
        ${((UI.tsInputs || {}).senders || []).map(d => tile({ type: 'texshare', name: d.name.slice(0, 32), sender: d.name, fit: 'fit' }, 'screen', d.name, UI.tsInputs.kind + ' sender' + (d.width ? ` · ${d.width}×${d.height}` : ''))).join('')}
        ${(UI.dlInputs || []).map(d => tile({ type: 'decklink', name: d.name.slice(0, 32), device: d.index, fit: 'fit' }, 'cam', d.name, 'SDI / HDMI in · ' + d.model)).join('')}
        </div>${!p ? '<div class="hint">Open an Output window to list its cameras and capture cards.</div>' : ''}${window.pixoraNative && window.pixoraNative.ndiState ? `<div class="hint">NDI® sources on your network appear here in the desktop app (press Scan to refresh). NDI® is a registered trademark of Vizrt NDI AB — <a href="https://ndi.video/" target="_blank" rel="noopener" style="color:var(--accent, #c9f);text-decoration:none">ndi.video</a></div>` : ''}</div></div>
        <div>${UI.guestSection ? UI.guestSection() : ''}${UI.playlistMaker ? UI.playlistMaker() : ''}<div class="sec"><h4>Web page</h4><div class="row wide"><label>URL</label><input type="text" id="webUrl" placeholder="https://example.com/scoreboard"></div>
        <div style="display:flex;gap:6px;margin-top:6px"><div class="gtile" draggable="true" id="webTile" style="flex:1;padding:8px;flex-direction:row;align-items:center">${I('globe')}<b>Drag web page to a slot</b></div></div>
        <div class="hint">Great for scoreboards, timers, social walls, HTML graphics and your own web apps. In a browser, pages render live as an overlay with transparency; in the PIXORA desktop app they become GPU textures, so effects, masks and mapping apply. For sites that block embedding, use Screen / Tab capture.</div></div></div></div></div>`;
    },
    after(pane) {
      $('#scanIn') && ($('#scanIn').onclick = () => { UI.cmd({ op: 'scanInputs' }); UI.toast('Allow camera/microphone access in the Output window to list devices');
        if (window.pixoraNative) window.pixoraNative.listNdi().then(l => { UI.ndiSources = l; UI.renderBottom(true); });
        if (window.pixoraNative && window.pixoraNative.texShareList) window.pixoraNative.texShareList().then(l => { UI.tsInputs = l; UI.renderBottom(true); }); });
      if (window.pixoraNative && window.pixoraNative.texShareList && !UI.tsInputs) { UI.tsInputs = { senders: [] }; window.pixoraNative.texShareList().then(l => { UI.tsInputs = l; UI.renderBottom(true); }); }
      if (window.pixoraNative && !UI.ndiSources) { UI.ndiSources = []; window.pixoraNative.listNdi().then(l => { UI.ndiSources = l; UI.renderBottom(true); }); }
      if (window.pixoraNative && window.pixoraNative.decklinkState && !UI.dlInputs) { UI.dlInputs = []; window.pixoraNative.decklinkState().then(s => { UI.dlInputs = (s.devices || []).filter(d => d.input); if (UI.dlInputs.length) UI.renderBottom(true); }).catch(() => {}); }
      pane.ondragstart = e => {
        if (e.target.id === 'webTile') { const url = $('#webUrl').value.trim(); if (!url) { UI.toast('Enter a URL first', 'err'); e.preventDefault(); return; } e.dataTransfer.setData('bvj/clip', JSON.stringify({ type: 'web', name: url.replace(/^https?:\/\//, '').slice(0, 40), url })); return; }
        const t = e.target.closest('[data-clip]'); if (t) e.dataTransfer.setData('bvj/clip', t.dataset.clip);
      };
    },
  };

  /* ================= SHADERS ================= */
  let curShader = null;
  UI.bpanels.shaders = {
    sig: s => JSON.stringify([s.shaders.map(x => [x.id, x.name]), curShader, Object.keys(UI.shaderErrors)]),
    tools: () => `<button class="btn sm" id="shNew">${I('plus')}New shader</button><button class="btn sm" id="shImp">${I('upload')}Import .fs / .glsl</button>`,
    render(s) {
      if (!curShader || !s.shaders.find(x => x.id === curShader)) curShader = s.shaders[0] && s.shaders[0].id;
      const sh = s.shaders.find(x => x.id === curShader);
      return `<div class="libside">${s.shaders.map(x => `<div class="src ${x.id === curShader ? 'on' : ''}" data-sh="${x.id}" draggable="true">${I('code')}${esc(x.name)}${UI.shaderErrors[x.id] ? '<span class="cnt" style="color:var(--red)">error</span>' : ''}</div>`).join('')}</div>
        <div class="libmain">${sh ? `<div style="display:flex;gap:6px;margin-bottom:6px"><input type="text" id="shName" value="${esc(sh.name)}" style="flex:1"><button class="btn sm primary" id="shSave">${I('save')}Save</button><button class="btn sm" id="shUse">${I('play')}Add to selected slot</button>${sh.builtin ? '' : `<button class="btn sm danger" id="shDel">${I('trash')}</button>`}</div>
          <textarea id="shCode" spellcheck="false" style="width:100%;height:calc(100% - 70px);min-height:120px">${esc(sh.code)}</textarea>
          ${UI.shaderErrors[sh.id] ? `<pre class="small" style="color:var(--red);white-space:pre-wrap;margin:4px 0">${esc(UI.shaderErrors[sh.id])}</pre>` : `<div class="hint">Shadertoy-style <span class="mono">mainImage(out vec4, in vec2)</span> or ISF (.fs). Uniforms: iResolution, iTime, iBeat, iAudio (level,bass,mid,high), iParam (the 4 clip sliders). Compiled on the output GPU — errors show here.</div>`}` : ''}</div>`;
    },
    after(pane) {
      pane.onclick = e => { const t = e.target.closest('[data-sh]'); if (t) { curShader = t.dataset.sh; UI.renderBottom(true); } };
      pane.ondragstart = e => { const t = e.target.closest('[data-sh]'); if (!t) return; const sh = UI.st().shaders.find(x => x.id === t.dataset.sh); e.dataTransfer.setData('bvj/clip', JSON.stringify({ type: 'gen', name: sh.name, gen: { kind: 'shader', params: Object.assign(S.genDefaults('shader'), { shader: sh.id }) } })); };
      const save = () => UI.cmd({ op: 'shaderSave', shader: { id: curShader, name: $('#shName').value, code: $('#shCode').value } });
      $('#shSave') && ($('#shSave').onclick = () => { save(); UI.toast('Shader saved — compiling on output…', 'ok'); });
      $('#shCode') && $('#shCode').addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); e.stopPropagation(); save(); UI.toast('Shader saved', 'ok'); } if (e.key === 'Tab') { e.preventDefault(); document.execCommand('insertText', false, '  '); } });
      $('#shUse') && ($('#shUse').onclick = () => { const l = UI.st().layers[UI.sel.layer]; const slot = UI.sel.slot ?? Math.max(0, l.clips.findIndex(c => !c)); const sh = UI.st().shaders.find(x => x.id === curShader);
        UI.cmd({ op: 'assign', layer: UI.sel.layer, slot, clip: { type: 'gen', name: sh.name, gen: { kind: 'shader', params: Object.assign(S.genDefaults('shader'), { shader: sh.id }) } } }); UI.select(UI.sel.layer, slot); });
      $('#shDel') && ($('#shDel').onclick = () => { if (confirm('Delete shader?')) UI.cmd({ op: 'shaderDelete', id: curShader }); });
      $('#shNew') && ($('#shNew').onclick = () => { const id = 'sh' + Math.random().toString(36).slice(2, 7); UI.cmd({ op: 'shaderSave', shader: { id, name: 'New shader', code: 'void mainImage(out vec4 o, in vec2 f){\n  vec2 uv = f / iResolution.xy;\n  o = vec4(uv, 0.5 + 0.5 * sin(iTime), 1.0);\n}' } }); curShader = id; });
      $('#shImp') && ($('#shImp').onclick = () => { const i = document.createElement('input'); i.type = 'file'; i.accept = '.fs,.frag,.glsl,.txt'; i.onchange = async () => { const f = i.files[0]; const id = 'sh' + Math.random().toString(36).slice(2, 7); UI.cmd({ op: 'shaderSave', shader: { id, name: f.name.replace(/\.[^.]+$/, ''), code: await f.text() } }); curShader = id; }; i.click(); });
    },
  };

  /* ================= LOOKS ================= */
  UI.bpanels.looks = {
    sig: s => JSON.stringify(s.presets.map(p => [p.id, p.name, p.fav])),
    tools: () => `<button class="btn sm" id="lookSaveL">${I('save')}Save selected layer look</button><button class="btn sm" id="lookSaveC">${I('save')}Save comp look</button>`,
    render(s) {
      if (!s.presets.length) return `<div class="libmain"><div class="empty-note">No looks saved yet. A look stores a full effect stack (and blend mode) so you can recall it on any layer or the whole composition.</div></div>`;
      const sorted = [...s.presets].sort((a, b) => (b.fav ? 1 : 0) - (a.fav ? 1 : 0));
      return `<div class="libmain"><div class="cards" style="--card-w:210px">${sorted.map(p => { const fx = S.FX.filter(f => p.fx[f.id] && p.fx[f.id].on).map(f => f.name);
        return `<div class="gtile" data-look="${p.id}"><div style="display:flex;width:100%;align-items:center;gap:6px"><b style="flex:1">${esc(p.name)}</b><span class="stars"><i class="${p.fav ? 'on' : ''}" data-fav="${p.id}">★</i></span></div>
          <span>${fx.length ? esc(fx.join(' · ')) : 'No effects'}${p.blend ? ' · ' + esc(p.blend) : ''}</span>
          <div style="display:flex;gap:4px"><button class="btn xs" data-applyl="${p.id}">Apply to layer</button><button class="btn xs" data-applyc="${p.id}">Apply to comp</button><button class="btn xs danger" data-dell="${p.id}">${I('trash')}</button></div></div>`; }).join('')}</div></div>`;
    },
    after(pane) {
      $('#lookSaveL') && ($('#lookSaveL').onclick = async () => { const n = await UI.prompt('Look name', UI.st().layers[UI.sel.layer].name + ' look'); if (n) UI.cmd({ op: 'presetSave', layer: UI.sel.layer, name: n }); });
      $('#lookSaveC') && ($('#lookSaveC').onclick = async () => { const n = await UI.prompt('Look name', 'Comp look'); if (n) UI.cmd({ op: 'presetSave', layer: null, name: n }); });
      pane.onclick = e => { const t = e.target.closest('[data-applyl],[data-applyc],[data-dell],[data-fav]'); if (!t) return; const d = t.dataset;
        if (d.applyl) UI.cmd({ op: 'presetApply', id: d.applyl, layer: UI.sel.layer }); if (d.applyc) UI.cmd({ op: 'presetApply', id: d.applyc, layer: null });
        if (d.dell) UI.cmd({ op: 'presetDelete', id: d.dell }); if (d.fav) { const i = UI.st().presets.findIndex(p => p.id === d.fav); BVJ.cmd({ op: 'set', path: `presets.${i}.fav`, value: !UI.st().presets[i].fav }); } };
    },
  };

  /* ================= SHOWS & JOBS ================= */
  UI.bpanels.shows = {
    sig: () => JSON.stringify([UI.comps, UI.jobs.map(j => [j.id, j.status, Math.round(j.progress * 50)])]),
    tools: () => `<button class="btn sm primary" id="shSaveAs">${I('save')}Save as…</button><button class="btn sm" id="shExp">${I('upload')}Export .pixora</button><button class="btn sm" id="shImpF">${I('folder')}Import</button><button class="btn sm" id="shCol">${I('drive')}Collect for offline</button><button class="btn sm" id="shRel">${I('link')}Relink</button>`,
    render(s) {
      return `<div class="libmain"><div class="grid2" style="align-items:start"><div class="sec"><h4>Saved compositions (on this server)</h4>
        ${UI.comps.length ? UI.comps.map(c => `<div class="src" style="cursor:default">${I('save')}<span style="flex:1">${esc(c)}</span><button class="btn xs primary" data-load="${esc(c)}">Load</button><button class="btn xs danger" data-delc="${esc(c)}">${I('trash')}</button></div>`).join('') : '<div class="muted">None yet — use Save (Ctrl+S).</div>'}
        <div class="hint">Everything also autosaves continuously, so a power cut or restart resumes exactly where you were. Show files (.pixora) are portable: they include the composition, decks, cues, outputs, mappings, looks and shaders, with references to the media.</div></div>
        <div class="sec"><h4>Background jobs</h4>${UI.jobs.length ? `<div class="jobs">${UI.jobs.slice().reverse().map(j => `<div class="job"><span style="width:62px" class="muted">${j.type}</span><span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(j.error || '')}">${esc(j.name)}</span><div class="meter" style="max-width:120px"><i style="width:${(j.progress || 0) * 100}%"></i></div><span class="mono" style="width:56px;text-align:right;color:${j.status === 'error' ? 'var(--red)' : j.status === 'done' ? 'var(--green)' : ''}">${j.status === 'running' ? Math.round(j.progress * 100) + '%' : j.status}</span></div>${j.error ? `<div class="small" style="color:var(--red)">${esc(j.error)}</div>` : ''}`).join('')}</div>` : '<div class="muted">No jobs.</div>'}
        <div class="hint">ffmpeg conversion and show collection run here on the server computer, one at a time.</div></div></div></div>`;
    },
    after(pane) {
      $('#shSaveAs').onclick = () => UI.saveComp(true);
      $('#shExp').onclick = () => { location.href = '/api/show/export?name=' + encodeURIComponent(UI.st().comp.name); };
      $('#shImpF').onclick = () => $('#showIn').click(); $('#shCol').onclick = () => UI.collectShow(); $('#shRel').onclick = () => UI.relink();
      pane.onclick = e => { const t = e.target.closest('button'); if (!t) return;
        if (t.dataset.load && confirm('Load "' + t.dataset.load + '"? Unsaved changes to the current composition will be replaced.')) UI.cmd({ op: 'loadComp', name: t.dataset.load });
        if (t.dataset.delc && confirm('Delete saved composition "' + t.dataset.delc + '"?')) UI.cmd({ op: 'deleteComp', name: t.dataset.delc }); };
    },
  };
})();
