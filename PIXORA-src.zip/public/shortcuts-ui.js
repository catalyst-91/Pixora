/* PIXORA — Keyboard shortcuts: bind any key combination to any cue action (saved with the show). */
(function () {
  const UI = window.UI, $ = UI.$, $$ = UI.$$, esc = UI.esc, I = UI.icon;
  UI.MORETABS.push(['shortcuts', 'Keyboard Shortcuts', 'midi', 'Keys']);
  let recording = null; // index of the row waiting for a key
  const combo = e => { const k = e.key.length === 1 ? e.key.toUpperCase() : e.key === ' ' ? 'Space' : e.key; if (['Control', 'Shift', 'Alt', 'Meta'].includes(k)) return null;
    return [e.ctrlKey && 'Ctrl', e.altKey && 'Alt', e.shiftKey && 'Shift', e.metaKey && 'Cmd'].filter(Boolean).concat(e.code && /^Digit|^Numpad/.test(e.code) ? e.code.replace('Digit', '').replace('Numpad', 'Num') : k).join('+'); };
  const list = () => (UI.st() && UI.st().shortcuts) || [];
  const save = l => UI.cmd({ op: 'shortcuts', list: l });
  UI.panels.shortcuts = {
    sig: s => JSON.stringify([s.shortcuts, recording]),
    render(s) {
      const rows = (s.shortcuts || []).map((k, i) => `<div class="kbrow"><button class="btn sm kbkey ${recording === i ? 'primary' : ''}" data-kbrec="${i}">${recording === i ? 'Press a key…' : esc(k.key)}</button>
        <div style="flex:1">${UI.actionEditor(`shortcuts.${i}.action`, k.action)}</div><button class="btn sm icon" data-kbdel="${i}">${I('trash')}</button></div>`).join('');
      return `<div class="sec"><h4>Keyboard shortcuts</h4>${rows || '<p class="muted small">No shortcuts yet.</p>'}
        <button class="btn sm" data-kbadd>${I('plus')}Add shortcut</button>
        <div class="hint">Press the key button, then the combination (e.g. F1, Ctrl+Shift+2, Space). Shortcuts work on this controller whenever you are not typing in a field, and they win over built-in keys. They are saved with the show, so every controller gets them. Panels with their own keys (Replay, Switcher) keep those while open.</div></div>`;
    },
    after(pane) {
      pane.onclick = e => { const t = e.target.closest('button'); if (!t) return; const d = t.dataset;
        if ('kbadd' in d) { save(list().concat([{ key: 'F' + (list().length + 1), action: { type: 'column', col: 1 } }])); return; }
        if (d.kbdel != null) { const l = list().slice(); l.splice(+d.kbdel, 1); save(l); return; }
        if (d.kbrec != null) { recording = +d.kbrec; UI.renderRight(true); } };
    },
  };
  addEventListener('keydown', e => {
    if (recording != null) { const c = combo(e); if (!c) return; e.preventDefault(); e.stopPropagation(); const l = list().slice(); if (c !== 'Escape' && l[recording]) { if (l.some((k, i) => i !== recording && k.key === c)) UI.toast(c + ' was already used — replaced', 'warn'); l.forEach((k, i) => { if (i !== recording && k.key === c) k.key = ''; }); l[recording].key = c; save(l.filter(k => k.key)); } recording = null; setTimeout(() => UI.renderRight(true), 50); return; }
    if (e.target.closest && e.target.closest('input,textarea,select,[contenteditable]')) return;
    const c = combo(e); if (!c) return; const hit = list().find(k => k.key === c); if (!hit) return;
    if ((UI.rtab === 'replay' || UI.rtab === 'switcher') && !/F\d+|Ctrl|Alt|Cmd/.test(c)) return; // those panels own their plain keys
    e.preventDefault(); e.stopPropagation(); UI.cmd({ op: 'runAction', action: hit.action }); UI.toast('⌨ ' + c, 'ok');
  }, true);
})();
