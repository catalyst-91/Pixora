/* PIXORA instant replay — output side. Booth Productions.
 * Each of the 4 replay units (A–D) records one source (a layer's live input, or the program output) into a rolling
 * buffer of hardware-encoded video (WebCodecs H.264, VP8 fallback) with a keyframe every half second. Playback decodes
 * the frame for the shared playhead (server clock), so every output shows the same frame, at any speed, forwards or
 * backwards. Timestamps are server time (BVJ.now) so marks made in the controller line up with the recordings. */
(function () {
  const SIZES = { '540p': [960, 540, 3e6], '720p': [1280, 720, 6e6], '1080p': [1920, 1080, 12e6] };
  const posOf = (p, now) => !p ? now : p.paused ? p.pausedAt : p.at + (now - p.startedAt) * p.speed;
  let CODEC = null; // picked once: first config the browser can encode AND decode
  async function pickCodec(w, h) {
    if (CODEC) return CODEC;
    for (const codec of ['avc1.640028', 'avc1.42E01F', 'vp8']) {
      const e = { codec, width: w, height: h, bitrate: 6e6, framerate: 50, latencyMode: 'realtime', hardwareAcceleration: 'no-preference' }; if (codec.startsWith('avc')) e.avc = { format: 'annexb' };
      try { const a = await VideoEncoder.isConfigSupported(e), b = await VideoDecoder.isConfigSupported({ codec, codedWidth: w, codedHeight: h }); if (a.supported && b.supported) return (CODEC = codec); } catch {}
    }
    return (CODEC = 'none');
  }
  class Unit {
    constructor(id) { this.id = id; this.chunks = []; this.n = 0; this.last = 0; this.cur = null; this.curIdx = -1; this.queued = -1; this.bytes = 0; this.cfgKey = ''; this.fps = 0; this.fpsN = 0; this.fpsAt = 0; }
    async configure(w, h, bitrate, fps) {
      const key = [w, h, bitrate, fps].join('x'); if (key === this.cfgKey && this.enc && this.enc.state === 'configured') return true;
      const codec = await pickCodec(w, h); if (codec === 'none') { this.error = 'This computer cannot encode video for replay'; return false; }
      this.close(); this.cfgKey = key; this.w = w; this.h = h; this.codec = codec; this.keyInt = Math.max(1, Math.round(fps / 2));
      this.canvas = new OffscreenCanvas(w, h); this.ctx = this.canvas.getContext('2d', { alpha: false });
      this.enc = new VideoEncoder({ output: c => this.store(c), error: e => { this.error = e.message; this.cfgKey = ''; } });
      const cfg = { codec, width: w, height: h, bitrate, framerate: fps, latencyMode: 'realtime', hardwareAcceleration: 'no-preference' }; if (codec.startsWith('avc')) cfg.avc = { format: 'annexb' };
      this.enc.configure(cfg); this.chunks = []; this.bytes = 0; this.resetDecoder(); return true;
    }
    store(c) { const data = new Uint8Array(c.byteLength); c.copyTo(data); this.chunks.push({ ts: c.timestamp / 1000, key: c.type === 'key', data }); this.bytes += data.byteLength; }
    trim(keepMs, now) { // drop whole GOPs older than the buffer length
      let cut = 0; for (let i = 1; i < this.chunks.length; i++) { if (this.chunks[i].key) { if (this.chunks[i].ts < now - keepMs) cut = i; else break; } }
      if (cut > 0) { for (let i = 0; i < cut; i++) this.bytes -= this.chunks[i].data.byteLength; this.chunks.splice(0, cut); this.curIdx -= cut; this.queued -= cut; if (this.queued < -1) this.resetDecoder(); }
    }
    capture(source, sw, sh, ts) {
      if (!this.enc || this.enc.state !== 'configured' || this.enc.encodeQueueSize > 3 || !sw || !sh) return;
      const k = Math.min(this.w / sw, this.h / sh), dw = sw * k, dh = sh * k; // fit, letterboxed
      this.ctx.fillStyle = '#000'; this.ctx.fillRect(0, 0, this.w, this.h);
      try { this.ctx.drawImage(source, (this.w - dw) / 2, (this.h - dh) / 2, dw, dh); } catch { return; }
      const f = new VideoFrame(this.canvas, { timestamp: Math.round(ts * 1000) });
      this.enc.encode(f, { keyFrame: this.n++ % this.keyInt === 0 }); f.close();
      this.fpsN++; if (ts - this.fpsAt >= 1000) { this.fps = this.fpsN; this.fpsN = 0; this.fpsAt = ts; }
    }
    resetDecoder() {
      try { this.dec && this.dec.state !== 'closed' && this.dec.close(); } catch {} this.dec = null; this.queued = -1;
      if (!this.codec) return;
      this.dec = new VideoDecoder({ output: f => { if (this.cur) this.cur.close(); this.cur = f; }, error: () => { this.dec = null; } });
      this.dec.configure({ codec: this.codec, codedWidth: this.w, codedHeight: this.h, optimizeForLatency: true, hardwareAcceleration: 'no-preference' });
    }
    indexAt(t) { const c = this.chunks; let lo = 0, hi = c.length - 1, r = -1; while (lo <= hi) { const m = (lo + hi) >> 1; if (c[m].ts <= t) { r = m; lo = m + 1; } else hi = m - 1; } return r; }
    frameAt(t) {
      const c = this.chunks; if (!c.length) return null;
      let i = this.indexAt(t); if (i < 0) i = 0;
      if (i !== this.curIdx) {
        if (!this.dec || this.dec.state === 'closed') this.resetDecoder();
        let key = i; while (key > 0 && !c[key].key) key--;
        const forward = this.queued >= key && i > this.queued && i - this.queued < 90;
        if (!forward) { try { this.dec.reset(); this.dec.configure({ codec: this.codec, codedWidth: this.w, codedHeight: this.h, optimizeForLatency: true, hardwareAcceleration: 'no-preference' }); } catch { this.resetDecoder(); } this.queued = key - 1; }
        if (this.dec.decodeQueueSize < 30) { for (let j = this.queued + 1; j <= i; j++) this.dec.decode(new EncodedVideoChunk({ type: c[j].key ? 'key' : 'delta', timestamp: Math.round(c[j].ts * 1000), data: c[j].data })); this.queued = i; this.curIdx = i; }
      }
      return this.cur;
    }
    close() { try { this.enc && this.enc.state !== 'closed' && this.enc.close(); } catch {} try { this.dec && this.dec.state !== 'closed' && this.dec.close(); } catch {} if (this.cur) { this.cur.close(); this.cur = null; } this.enc = this.dec = null; this.chunks = []; this.bytes = 0; this.cfgKey = ''; this.curIdx = this.queued = -1; }
    stat() { const c = this.chunks; return { id: this.id, sec: c.length ? Math.round((c[c.length - 1].ts - c[0].ts) / 100) / 10 : 0, fps: this.fps, mb: Math.round(this.bytes / 1048576), size: this.w ? this.w + '×' + this.h : '', codec: this.codec || '', error: this.error || '' }; }
  }
  class PixoraReplay {
    constructor(engine) { this.engine = engine; this.units = {}; this.R = null; this.statAt = 0; for (const id of ['A', 'B', 'C', 'D']) this.units[id] = new Unit(id); }
    supported() { return typeof VideoEncoder === 'function' && typeof VideoDecoder === 'function' && typeof OffscreenCanvas === 'function'; }
    setState(R) { this.R = R; }
    // call right after the engine has drawn a frame (the program canvas is only readable in that task)
    capture(now) {
      const R = this.R; if (!R || !this.supported()) return;
      const [w, h, br] = SIZES[R.size] || SIZES['720p'];
      for (const u of R.units) {
        const U = this.units[u.id]; if (u.source === 'off' || u.source == null) { if (U.enc) U.close(); continue; }
        if (now - U.last < 1000 / R.fps - 2) continue;
        if (!U.enc || U.cfgKey !== [w, h, br, R.fps].join('x')) { if (!U.configuring) { U.configuring = true; U.configure(w, h, br, R.fps).finally(() => U.configuring = false); } continue; }
        const src = this.sourceFor(u.source); if (!src) continue;
        U.last = now; U.capture(src.el, src.w, src.h, now); U.trim(R.seconds * 1000, now);
      }
      if (now - this.statAt > 1000 && window.BVJ && BVJ.isPrimary && BVJ.isPrimary()) { this.statAt = now; BVJ.raw({ t: 'replayStat', units: Object.values(this.units).map(U => U.stat()) }); }
    }
    sourceFor(s) {
      const E = this.engine;
      if (s === 'program') return { el: E.canvas, w: E.canvas.width, h: E.canvas.height };
      const rt = E.layers && E.layers[s], src = rt && rt.cur; if (!src || src.kind === 'replay') return null;
      if (src.el && src.el.tagName === 'VIDEO') return src.el.readyState >= 2 ? { el: src.el, w: src.el.videoWidth, h: src.el.videoHeight } : null;
      if (src.el && src.el.tagName === 'IMG') return src.el.complete ? { el: src.el, w: src.el.naturalWidth, h: src.el.naturalHeight } : null;
      if (src.lastFrame) { if (!src.lastBitmapFrom || src.lastBitmapFrom !== src.lastFrame) { src.lastBitmapFrom = src.lastFrame; this.toCanvas(src); } return src.frameCanvas ? { el: src.frameCanvas, w: src.frameCanvas.width, h: src.frameCanvas.height } : null; }
      return null;
    }
    toCanvas(src) { const f = src.lastFrame; if (!src.frameCanvas || src.frameCanvas.width !== f.width || src.frameCanvas.height !== f.height) { src.frameCanvas = new OffscreenCanvas(f.width, f.height); src.frameCtx = src.frameCanvas.getContext('2d'); } src.frameCtx.putImageData(f, 0, 0); }
    // what a Replay clip shows: the playing unit at the playhead, or the selected unit live
    frame(unitHint, now) {
      const R = this.R; if (!R) return null;
      const P = R.play, id = unitHint && unitHint !== 'auto' ? unitHint : P ? P.unit : R.selected, U = this.units[id];
      return U ? U.frameAt(P ? posOf(P, now) : now) : null;
    }
    size() { const s = SIZES[(this.R && this.R.size) || '720p']; return { w: s[0], h: s[1] }; }
  }
  window.PixoraReplay = PixoraReplay; window.PixoraReplay.posOf = posOf;
})();
