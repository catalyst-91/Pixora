/* PIXORA — Audience interaction: join link + QR, poll editor and live results, Q&A and social-wall moderation. */
(function () {
  const UI = window.UI, $ = UI.$, $$ = UI.$$, esc = UI.esc, I = UI.icon, S = window.SCHEMA;
  const i = UI.MORETABS.findIndex(t => t[0] === 'kiosk'); UI.MORETABS.splice(i + 1, 0, ['audience', 'Audience: polls, Q&A, wall', 'phone', 'Audience']);
  const sec = (t, b) => `<div class="sec"><h4>${t}</h4>${b}</div>`;
  let D = null, sig = '';
  const load = () => UI.api('/api/audience').then(d => { D = d; if (UI.rtab === 'audience') UI.renderRight(true); }).catch(() => {});
  (BVJ.extraHandlers = BVJ.extraHandlers || {}).audience = m => { D = m.data; if (UI.rtab !== 'audience') return; const s2 = JSON.stringify([D.qa.map(q => [q.id, q.status, q.up]), D.wall.map(w => [w.id, w.status]), D.key]);
    if (s2 !== sig) UI.renderRight(true); else paintTally(); };
  const act = b => UI.api('/api/audience', { method: 'POST', body: JSON.stringify(b) }).then(d => { D = d; UI.renderRight(true); }).catch(e => UI.toast(e.message, 'err'));
  function paintTally() { const box = $('#audTally'); if (!box || !D) return; const t = D.tally;
    box.innerHTML = t.list.length ? t.list.map(o => `<div class="kv"><span>${esc(o.text)}</span><b>${o.votes} · ${o.pct}%</b></div><div style="height:6px;background:#ffffff14;border-radius:3px;margin:-2px 0 6px"><div style="height:6px;border-radius:3px;width:${o.pct}%;background:var(--accent, #ff2fd0)"></div></div>`).join('') + `<div class="small muted">${t.total} vote${t.total === 1 ? '' : 's'}</div>` : '<div class="hint">Add a question and at least two answers.</div>'; }
  const STAT = { pending: 'waiting', approved: 'approved', live: 'ON SCREEN', hidden: 'hidden', done: 'done' };
  const item = (what, x) => `<div class="card"><header><b style="flex:1;white-space:normal;font-weight:500">${esc(x.text)}</b></header><div class="body" style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
      <span class="small muted" style="flex:1">${x.name ? esc(x.name) + ' · ' : ''}${new Date(x.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}${what === 'qa' ? ` · ▲ ${x.up}` : ''} · <b style="color:${x.status === 'live' ? 'var(--green)' : x.status === 'pending' ? 'var(--yellow)' : ''}">${STAT[x.status]}</b></span>
      ${x.status === 'pending' || x.status === 'hidden' ? `<button class="btn xs" data-aud="approved" data-w="${what}" data-id="${x.id}">Approve</button>` : ''}
      ${x.status !== 'live' && x.status !== 'hidden' ? `<button class="btn xs primary" data-aud="live" data-w="${what}" data-id="${x.id}">On screen</button>` : ''}
      ${x.status === 'live' ? `<button class="btn xs" data-aud="done" data-w="${what}" data-id="${x.id}">Take off</button>` : ''}
      ${x.status !== 'hidden' ? `<button class="btn xs danger" data-aud="hidden" data-w="${what}" data-id="${x.id}">Hide</button>` : ''}</div></div>`;
  UI.panels.audience = {
    sig: s => JSON.stringify([s.audience.on, s.audience.qaOn, s.audience.wallOn, s.audience.moderate, s.audience.poll.options.length, s.audience.pollOpen, !!D, D && D.key]),
    render(s) {
      const a = s.audience; if (!D) { load(); return sec('Audience', '<div class="hint">Loading…</div>'); }
      sig = JSON.stringify([D.qa.map(q => [q.id, q.status, q.up]), D.wall.map(w => [w.id, w.status]), D.key]);
      let h = sec('Audience interaction', `${UI.rToggle('Open to phones', 'audience.on')}
        <div style="display:flex;gap:12px;align-items:flex-start;margin:8px 0"><canvas id="audQr" width="148" height="148" style="border-radius:8px;background:#fff;flex:none"></canvas>
          <div style="min-width:0"><div class="small muted">Join link</div><div class="mono small" style="word-break:break-all;margin:4px 0 8px">${esc(D.url)}</div>
          <button class="btn sm" data-audx="copy">Copy link</button> <button class="btn sm" data-audx="newKey" title="Old QR codes and links stop working">New link</button></div></div>
        <div class="row wide"><label>Title on phones</label><div class="ctl"><input type="text" data-path="audience.title"></div></div>
        <div class="row wide"><label>Public address</label><div class="ctl"><input type="text" data-path="audience.publicUrl" placeholder="optional, e.g. https://vote.example.com (a tunnel to this machine)"></div></div>
        <div class="hint">Phones scan the QR code on the screen (Audience overlay generator) and join without an app or the PIN — they must reach this computer: the venue Wi-Fi, or a public address that forwards to it. Nothing is sent to any cloud service.</div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px">${[['Poll + QR', 0], ['Poll', 1], ['QR code', 2], ['Question', 3], ['Wall', 4]].map(([l, v]) => `<button class="btn sm" data-audclip="${v}">${I('plus')}${l} overlay</button>`).join('')}</div>
        <div class="hint">Puts an Audience overlay into the selected clip slot (or the first empty slot of the selected layer).</div>`);
      h += sec('Poll', `<div class="row wide"><label>Question</label><div class="ctl"><input type="text" data-path="audience.poll.question" placeholder="What should we play next?"></div></div>
        ${a.poll.options.map((o, j) => `<div class="row wide"><label>Answer ${j + 1}</label><div class="ctl"><input type="text" data-path="audience.poll.options.${j}">${a.poll.options.length > 2 ? `<button class="btn xs" data-audx="optDel" data-i="${j}">✕</button>` : ''}</div></div>`).join('')}
        ${a.poll.options.length < 8 ? `<button class="btn sm" data-audx="optAdd">${I('plus')}Answer</button>` : ''}
        <div style="display:flex;gap:6px;margin:8px 0"><button class="btn sm ${a.pollOpen ? 'danger' : 'primary'}" data-audx="toggle">${a.pollOpen ? 'Close voting' : 'Open voting'}</button><button class="btn sm" data-audx="reset">New poll (clear votes)</button></div>
        ${UI.rToggle('Show results on phones', 'audience.showResults')}<div id="audTally"></div>`);
      const qa = D.qa.slice().reverse(), wall = D.wall.slice().reverse(), pend = l => l.filter(x => x.status === 'pending').length;
      h += sec(`Q&amp;A ${pend(D.qa) ? `<span class="cnt">${pend(D.qa)} waiting</span>` : ''}`, `${UI.rToggle('Take questions', 'audience.qaOn')}${qa.length ? qa.slice(0, 60).map(x => item('qa', x)).join('') : '<div class="hint">Questions from phones appear here. “On screen” puts one on the Question overlay.</div>'}
        ${qa.length ? `<button class="btn sm danger" data-audx="clearQa">Clear questions</button>` : ''}`);
      h += sec(`Social wall ${pend(D.wall) ? `<span class="cnt">${pend(D.wall)} waiting</span>` : ''}`, `${UI.rToggle('Take wall posts', 'audience.wallOn')}${wall.length ? wall.slice(0, 60).map(x => item('wall', x)).join('') : '<div class="hint">Approved posts show on the Wall overlay, newest first; “On screen” highlights one.</div>'}
        ${wall.length ? `<button class="btn sm danger" data-audx="clearWall">Clear the wall</button>` : ''}`);
      h += sec('Moderation', `${UI.rToggle('Approve questions and posts before they show', 'audience.moderate')}${UI.rToggle('Ask for a name', 'audience.allowNames')}
        <div class="row wide"><label>Block words</label><div class="ctl"><textarea data-path="audience.blockWords" rows="2" placeholder="comma-separated — posts containing them are always held back"></textarea></div></div>
        <div class="hint">Each phone gets one vote per poll (it can change it), and can send a question or post every few seconds.</div>`);
      return h;
    },
    after(pane) {
      const c = $('#audQr', pane); if (c && D && window.PixoraQR) try { PixoraQR.draw(c.getContext('2d'), D.url, 0, 0, 148); } catch {}
      paintTally();
      pane.onclick = e => { const t = e.target.closest('button'); if (!t) return; const s = UI.st(), a = s.audience;
        if (t.dataset.aud) return act({ action: 'status', what: t.dataset.w, id: t.dataset.id, status: t.dataset.aud });
        if (t.dataset.audclip != null) { const li = UI.sel.layer ?? 0, L = s.layers[li]; if (!L) return UI.toast('Select a layer', 'err'); let ci = UI.sel.slot; if (ci == null || L.clips[ci]) { ci = L.clips.findIndex(x => !x); if (ci < 0) ci = L.clips.length; }
          const g = S.GENERATORS.find(x => x.id === 'audience'), params = {}; for (const pp of g.params) params[pp.k] = pp.def; params.view = +t.dataset.audclip;
          UI.cmd({ op: 'assign', layer: li, slot: ci, clip: { type: 'gen', name: ['Poll + QR', 'Poll', 'Join QR', 'Question', 'Wall'][params.view], gen: { kind: 'audience', params } } }); UI.toast(`Added to layer ${li + 1}, slot ${ci + 1}`, 'ok'); return; }
        switch (t.dataset.audx) {
          case 'copy': navigator.clipboard && navigator.clipboard.writeText(D.url).then(() => UI.toast('Join link copied', 'ok')); break;
          case 'newKey': if (confirm('Make a new join link? QR codes already shown or printed stop working.')) act({ action: 'newKey' }); break;
          case 'optAdd': UI.cmd({ op: 'set', path: 'audience.poll.options', value: [...a.poll.options, ''] }); break;
          case 'optDel': UI.cmd({ op: 'set', path: 'audience.poll.options', value: a.poll.options.filter((_, j) => j !== +t.dataset.i) }); break;
          case 'toggle': UI.cmd({ op: 'set', path: 'audience.pollOpen', value: !a.pollOpen }); break;
          case 'reset': if (confirm('Start a new poll? All votes are cleared and phones can vote again.')) act({ action: 'pollReset' }); break;
          case 'clearQa': if (confirm('Clear every question?')) act({ action: 'clear', what: 'qa' }); break;
          case 'clearWall': if (confirm('Clear every wall post?')) act({ action: 'clear', what: 'wall' }); break;
        } };
    },
  };
})();
