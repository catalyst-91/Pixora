/* PIXORA — camera auto-alignment wizard (Output tab ▸ Auto-align with camera). Uses public/align.js. */
(function () {
  const UI = window.UI, $ = UI.$, esc = UI.esc, A = window.PixoraAlign, S = window.SCHEMA;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  let stream = null;
  async function cams() { try { return (await navigator.mediaDevices.enumerateDevices()).filter(d => d.kind === 'videoinput'); } catch { return []; } }

  UI.alignWizard = async function () {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return UI.toast('This browser cannot open a camera', 'err');
    const st = UI.st(); let corners = [], running = false, result = null;
    const body = `<div class="alignw">
      <div class="row wide"><label>Camera</label><select id="alCam"><option value="">Default camera</option></select></div>
      <div class="alprev"><video id="alVid" autoplay muted playsinline></video><canvas id="alOv"></canvas></div>
      <div class="hint" id="alHint">Point the camera at the whole screen, lock its exposure and focus if you can, and darken the room. Then click the screen's 4 corners in the picture: top-left, top-right, bottom-right, bottom-left.</div>
      <div class="row wide"><label>Projectors</label><div class="ctl" style="flex-wrap:wrap;gap:10px">${st.outputs.map(o => `<label class="small"><input type="checkbox" data-alout="${esc(o.id)}" ${st.outputs.length === 1 || o.id !== 'main' ? 'checked' : ''}> ${esc(o.name)}</label>`).join('')}</div></div>
      <div class="row wide"><label>Wait per pattern</label><div class="ctl"><input type="number" id="alWait" value="700" min="150" step="50" style="width:80px"><span class="muted small">ms (raise it if the camera or projector lags)</span></div></div>
      <div id="alOut" class="small"></div></div>`;
    const m = UI.modal('Auto-align projectors with a camera', body, [{ label: 'Close' }, { label: 'Reset corners', click: () => { corners = []; drawOv(); return false; } },
      { label: 'Start', cls: 'primary', click: () => { start(); return false; } }, { label: 'Apply', cls: 'primary', click: () => { if (!result) { UI.toast('Run the alignment first', 'warn'); return false; } apply(); return false; } },
      { label: 'Tune blends', click: () => { tuneBlends(); return false; } }],
      { width: '760px', onClose: () => { try { stream && stream.getTracks().forEach(t => t.stop()); } catch {} stream = null; restoreTests(); } });
    const vid = $('#alVid', m), ov = $('#alOv', m), out = $('#alOut', m);
    const sel = $('#alCam', m); (await cams()).forEach(c => { const o = document.createElement('option'); o.value = c.deviceId; o.textContent = c.label || 'Camera'; sel.appendChild(o); });
    async function open() { try { stream && stream.getTracks().forEach(t => t.stop()); stream = await navigator.mediaDevices.getUserMedia({ video: { deviceId: sel.value ? { exact: sel.value } : undefined, width: { ideal: 1920 }, height: { ideal: 1080 } }, audio: false });
      vid.srcObject = stream; await vid.play().catch(() => {}); const tr = stream.getVideoTracks()[0]; try { const caps = tr.getCapabilities ? tr.getCapabilities() : {}; const adv = {}; // lock exposure / focus / white balance where the camera allows it
        if (caps.exposureMode && caps.exposureMode.includes('manual')) adv.exposureMode = 'manual'; if (caps.focusMode && caps.focusMode.includes('manual')) adv.focusMode = 'manual'; if (caps.whiteBalanceMode && caps.whiteBalanceMode.includes('manual')) adv.whiteBalanceMode = 'manual';
        if (Object.keys(adv).length) await tr.applyConstraints({ advanced: [adv] }).catch(() => {}); } catch {} } catch (e) { out.innerHTML = `<span style="color:var(--red)">Camera: ${esc(e.message)}</span>`; } }
    sel.onchange = open; await open();
    // corner picking on the preview, in camera pixels
    const capSize = () => { const w = vid.videoWidth || 1280, h = vid.videoHeight || 720, k = Math.min(1, 1280 / w); return { w: Math.round(w * k), h: Math.round(h * k), k }; };
    function drawOv() { const r = vid.getBoundingClientRect(); ov.width = r.width; ov.height = r.height; const g = ov.getContext('2d'); g.clearRect(0, 0, ov.width, ov.height); const c = capSize(), sx = r.width / c.w, sy = r.height / c.h;
      g.strokeStyle = '#ff2fd0'; g.fillStyle = '#ff2fd0'; g.lineWidth = 2; g.beginPath(); corners.forEach(([x, y], i) => { i ? g.lineTo(x * sx, y * sy) : g.moveTo(x * sx, y * sy); }); if (corners.length === 4) g.closePath(); g.stroke();
      corners.forEach(([x, y], i) => { g.beginPath(); g.arc(x * sx, y * sy, 6, 0, 7); g.fill(); g.fillText(['TL', 'TR', 'BR', 'BL'][i], x * sx + 8, y * sy - 8); }); }
    ov.onclick = e => { if (running) return; if (corners.length >= 4) corners = []; const r = ov.getBoundingClientRect(), c = capSize(); corners.push([(e.clientX - r.left) / r.width * c.w, (e.clientY - r.top) / r.height * c.h]); drawOv(); };
    vid.onloadedmetadata = drawOv; window.addEventListener('resize', drawOv, { once: true });

    const work = document.createElement('canvas'), wg = work.getContext('2d', { willReadFrequently: true });
    async function grab() { const c = capSize(); work.width = c.w; work.height = c.h; let acc = null;
      for (let k = 0; k < 2; k++) { wg.drawImage(vid, 0, 0, c.w, c.h); const L = A.luma(wg.getImageData(0, 0, c.w, c.h).data, c.w, c.h); if (!acc) acc = L; else for (let p = 0; p < acc.data.length; p++) acc.data[p] = (acc.data[p] + L.data[p]) / 2; await sleep(70); }
      return acc; }
    let saved = null;
    function setTest(oi, test, frame) { BVJ.cmd({ op: 'set', path: `outputs.${oi}.test`, value: test }); if (frame != null) BVJ.cmd({ op: 'set', path: `outputs.${oi}.alignFrame`, value: frame }); }
    function restoreTests() { if (!saved) return; saved.forEach(([oi, t]) => setTest(oi, t)); saved = null; }

    async function start() {
      if (running) return; if (corners.length !== 4) return UI.toast('Click the screen\'s 4 corners in the camera picture first', 'warn');
      const s = UI.st(), ids = [...m.querySelectorAll('[data-alout]')].filter(x => x.checked).map(x => x.dataset.alout); if (!ids.length) return UI.toast('Choose at least one projector', 'warn');
      const idx = ids.map(id => s.outputs.findIndex(o => o.id === id)).filter(i => i >= 0); const wait = Math.max(150, +$('#alWait', m).value || 700);
      running = true; result = null; saved = idx.map(i => [i, s.outputs[i].test || 'off']); const projectors = [], lines = [];
      try {
        for (const oi of idx) setTest(oi, 'black');
        for (const oi of idx) {
          const o = s.outputs[oi], W = o.width || s.comp.width, H = o.height || s.comp.height, L = A.layout(W, H), frames = [];
          for (let f = 0; f < L.frames; f++) { out.textContent = `${o.name}: pattern ${f + 1} of ${L.frames}…`; setTest(oi, 'align', f); await sleep(wait); frames.push(await grab()); }
          setTest(oi, 'black');
          const d = A.decode(frames, L); if (d.error) { lines.push(`<b>${esc(o.name)}</b>: <span style="color:var(--red)">${esc(d.error)}</span>`); continue; }
          const R = A.ransac(d.pairs, { thr: Math.max(3, Math.min(W, H) / 300) });
          if (!R) { lines.push(`<b>${esc(o.name)}</b>: <span style="color:var(--red)">only ${d.pairs.length} of ${L.pts.length} dots read — check the camera sees this projector's whole image</span>`); continue; }
          projectors.push({ id: o.id, oi, name: o.name, W, H, camToProj: R.H }); lines.push(`<b>${esc(o.name)}</b>: ${d.pairs.length}/${L.pts.length} dots, ${R.inliers} used, accuracy ${R.error.toFixed(1)} px`);
        }
        if (projectors.length) { const plan = A.plan(projectors, corners); result = plan.map((p, i) => Object.assign(p, { oi: projectors[i].oi, name: projectors[i].name }));
          for (const p of result) lines.push(p.empty ? `${esc(p.name)}: <span style="color:var(--yellow)">doesn't reach the marked screen</span>` : `${esc(p.name)} covers ${(p.slice.src.x * 100).toFixed(0)}–${((p.slice.src.x + p.slice.src.w) * 100).toFixed(0)} % across${p.slice.soft.l || p.slice.soft.r || p.slice.soft.t || p.slice.soft.b ? ', blends ' + Object.entries(p.slice.soft).filter(([, v]) => v).map(([k, v]) => ({ l: 'left', r: 'right', t: 'top', b: 'bottom' }[k] + ' ' + (v * 100).toFixed(0) + ' %')).join(', ') : ''}`);
          lines.push('Press <b>Apply</b> to set the slices (Undo reverts).'); }
      } catch (e) { lines.push(`<span style="color:var(--red)">${esc(e.message)}</span>`); }
      finally { restoreTests(); running = false; out.innerHTML = lines.join('<br>'); }
    }
    function apply() {
      for (const p of result.filter(x => !x.empty)) { const o = UI.st().outputs[p.oi]; const base = (o.slices && o.slices[0]) || S.sliceDefaults(1);
        BVJ.cmd({ op: 'set', path: `outputs.${p.oi}.slices`, value: [Object.assign({}, base, { name: base.name || 'Auto-aligned', on: true, src: p.slice.src, dst: p.slice.dst, soft: p.slice.soft, mesh: Object.assign({}, base.mesh || {}, { on: false, pts: [] }) })] }); }
      applied = true; out.innerHTML += '<br>Applied. Press <b>Tune blends</b> to match brightness and smooth the overlaps with the camera.';
      UI.toast('Projectors aligned', 'ok');
    }
    let applied = false;
    // camera-measured blend tuning: brightness match, blend curve (gamma), black level — repeated until flat
    async function tuneBlends() {
      if (running) return; if (!result || !applied) return UI.toast('Run the alignment and Apply first', 'warn');
      const live = result.filter(p => !p.empty).map(p => Object.assign({}, p, { id: p.name || p.id })); if (live.length < 2) return UI.toast('Blend tuning needs two or more overlapping projectors', 'warn');
      const regs = A.regions(live); if (!regs.some(r => r.kind === 'overlap')) return UI.toast('These projectors don\'t overlap side by side', 'warn');
      const wait = Math.max(250, +$('#alWait', m).value || 700); running = true; saved = live.map(p => [p.oi, UI.st().outputs[p.oi].test || 'off']); const log = [];
      const show = async kind => { for (const p of live) setTest(p.oi, kind); await sleep(wait + 200); return A.measure(await grab(), corners, regs); };
      try {
        for (let round = 1; round <= 5; round++) {
          out.textContent = `Blend tuning, round ${round}: white…`; const W = await show('mapwhite'); out.textContent = `Blend tuning, round ${round}: black…`; const K = await show('mapblack');
          const sl = {}; for (const p of live) { const o = UI.st().outputs[p.oi], x = o.slices[0]; sl[p.id] = { gamma: x.gamma || 2.2, black: x.black || 0, cal: Object.assign({ brightness: 1 }, x.cal || {}) }; }
          const r = A.tune(sl, W, K); log.push(`Round ${round}: ${r.done ? 'even' : r.notes.map(esc).join('; ')}`);
          if (r.done) break;
          for (const p of live) { BVJ.cmd({ op: 'set', path: `outputs.${p.oi}.slices.0.gamma`, value: sl[p.id].gamma }); BVJ.cmd({ op: 'set', path: `outputs.${p.oi}.slices.0.black`, value: sl[p.id].black }); BVJ.cmd({ op: 'set', path: `outputs.${p.oi}.slices.0.cal.brightness`, value: sl[p.id].cal.brightness }); }
          await sleep(300);
        }
      } catch (e) { log.push(`<span style="color:var(--red)">${esc(e.message)}</span>`); }
      finally { restoreTests(); running = false; out.innerHTML = log.join('<br>') + '<br>Check by eye with Test pattern ▸ White / Black through the mapping; adjust Gamma or Black level per slice if needed.'; }
    }
  };
})();
