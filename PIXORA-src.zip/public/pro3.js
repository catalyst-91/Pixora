/* PIXORA v1.2 controller panels: Show (reliability & lock), Preflight, Console (CITP & MVR), Sync, Access (users & remote),
 * Reports, Updates. */
(function () {
  const S = window.SCHEMA, UI = window.UI, $ = UI.$, $$ = UI.$$, esc = UI.esc, I = UI.icon;
  const sec = (title, body, extra) => `<div class="sec"><h4>${title}${extra || ''}</h4>${body}</div>`;
  const kv = (k, v, cls) => `<div class="kv"><span>${k}</span><b class="${cls || ''}">${v}</b></div>`;
  const api = async (p, opt = {}) => { const r = await fetch(p, { ...opt, headers: { 'Content-Type': 'application/json', ...(opt.headers || {}) }, body: opt.body && typeof opt.body === 'object' && !(opt.body instanceof Blob) && !(opt.body instanceof ArrayBuffer) ? JSON.stringify(opt.body) : opt.body }); let j = {}; try { j = await r.json(); } catch {} if (!r.ok) throw new Error(j.error || 'HTTP ' + r.status); return j; };
  const ago = t => { if (!t) return 'never'; const s = Math.round((Date.now() - t) / 1000); return s < 60 ? s + 's ago' : s < 3600 ? Math.round(s / 60) + 'm ago' : Math.round(s / 3600) + 'h ago'; };
  const fmtB = n => n > 1073741824 ? (n / 1073741824).toFixed(1) + ' GB' : (n / 1048576).toFixed(n > 1e8 ? 0 : 1) + ' MB';
  const libItems = () => { if (!libCache) library().then(() => UI.renderRight(true)); return libCache || []; };
  let libCache = null, libLoading = null; async function library() { if (libCache) return libCache; if (!libLoading) libLoading = api('/api/library').then(r => { libCache = r.sources.flatMap(s => s.items); setTimeout(() => { libCache = null; }, 15000); }).catch(() => { libCache = []; }).finally(() => { libLoading = null; }); await libLoading; return libCache; }

  UI.MORETABS.push(['show', 'Show Control & Reliability', 'save', 'Show'], ['preflight', 'Content Preflight', 'save', 'Preflight'], ['console', 'Console Link: CITP & MVR', 'link', 'Console'],
    ['sync', 'Multi-machine Sync', 'restart', 'Sync'], ['access', 'Users & Remote Access', 'eye', 'Access'], ['reports', 'Show Reports', 'book', 'Reports'], ['update', 'Updates', 'restart', 'Updates']);

  /* live data from the server */
  UI.ostats = []; UI.optjobs = [];
  const ext = BVJ.extraHandlers = BVJ.extraHandlers || {};
  ext.ostats = m => { UI.ostats = m.list || []; if (UI.rtab === 'show' || UI.rtab === 'sync') UI.panels[UI.rtab].live($('#rpane'), UI.st()); renderLockBadge(); };
  ext.optjobs = m => { UI.optjobs = m.jobs || []; if (UI.rtab === 'preflight') UI.panels.preflight.live($('#rpane')); };
  ext.tunnel = m => { tunnelInfo = m.tunnel; if (UI.rtab === 'access') UI.renderRight(true); };
  ext.update = m => { updInfo = Object.assign(updInfo || {}, m.update); if (UI.rtab === 'update') UI.renderRight(true); };

  /* lock badge in the top bar */
  function renderLockBadge() {
    const s = UI.st(); if (!s || !s.show) return; let b = $('#pxLock');
    if (!b) { b = document.createElement('button'); b.id = 'pxLock'; b.className = 'btn sm'; b.style.cssText = 'margin-left:8px;display:none;background:#5a1630;border-color:#ff4d6d;color:#fff'; b.onclick = () => UI.setRtab('show'); const host = $('#top') || $('header') || document.body; host.appendChild(b); }
    const safeOn = (UI.ostats || []).some(o => o.safe);
    b.style.display = s.show.lock || safeOn ? '' : 'none'; b.textContent = (s.show.lock ? '🔒 SHOW LOCKED' : '') + (safeOn ? (s.show.lock ? ' · ' : '') + 'SAFE LOOP ON' : '');
  }
  setInterval(renderLockBadge, 1500);

  /* ================= SHOW: lock, safe loop, preload, output health ================= */
  UI.panels.show = {
    sig: s => JSON.stringify([s.show, (UI.ostats || []).length]),
    render(s) {
      const sh = s.show; const vids = libItems().filter(i => i.kind === 'video' || i.kind === 'image');
      let h = sec('Show lock', `<div class="hint" style="margin-top:0">Locking stops anyone (including remotes and the API) from changing the setup — layers, effects, mapping, outputs, cues — while still allowing playback: triggering clips and columns, GO/back, blackout, master, BPM and the timeline.</div>
        ${sh.lock ? `<div class="row wide"><label>Unlock PIN</label><div class="ctl"><input type="password" id="pxUnlockPin" placeholder="${sh.lockPin ? 'PIN set when locked' : 'no PIN set'}"></div></div><button class="btn sm primary" data-x="unlock">${I('eye')}Unlock show</button>`
          : `<div class="row wide"><label>Unlock PIN</label><div class="ctl"><input type="password" id="pxLockPin" placeholder="optional"></div></div><button class="btn sm live" data-x="lock">🔒 Lock show</button>`}`);
      h += sec('Safe loop', `<div class="hint" style="margin-top:0">A fallback clip each output shows instantly — full-frame, on top of everything — if a clip fails to play, playback stalls, or the graphics card resets. It plays from a plain video element, so it keeps running even when WebGL doesn't.</div>
        <div class="row wide"><label>Safe clip</label><div class="ctl"><select data-x-safe><option value="">— black —</option>${vids.map(i => `<option value="${esc(i.src)}" ${i.src === sh.safeSrc ? 'selected' : ''}>${esc(i.name)}</option>`).join('')}</select></div></div>
        ${UI.rToggle('When a clip fails', 'show.safeOnError')}${UI.rToggle('When playback stalls (3 s)', 'show.safeOnStall')}
        <div style="display:flex;gap:6px;margin-top:6px"><button class="btn sm" data-x="safeOn">Engage now</button><button class="btn sm" data-x="safeOff">Release</button></div>`);
      h += sec('Instant starts', `${UI.rToggle('Preload next cue & next column', 'show.preload')}<div class="hint">Outputs quietly buffer the clips the next cue (and the next clip on each layer) will play, so they start without a black frame.</div>
        ${UI.rNum('Warn above frame drops (%)', 'show.dropWarn', 0.5, 0, 50)}`);
      h += sec('Output health', `<div id="pxOuts"></div>`);
      return h;
    },
    after(pane) {
      pane.onclick = async e => {
        const x = e.target.closest('[data-x]'); if (!x) return; const k = x.dataset.x;
        try {
          if (k === 'lock') { BVJ.cmd({ op: 'lockShow', pin: ($('#pxLockPin') || {}).value || '' }); UI.toast('Show locked'); }
          if (k === 'unlock') await api('/api/cmd', { method: 'POST', body: { op: 'unlockShow', pin: ($('#pxUnlockPin') || {}).value || '' } }).then(() => UI.toast('Show unlocked'));
          if (k === 'safeOn') BVJ.cmd({ op: 'safeLoop', on: true }); if (k === 'safeOff') BVJ.cmd({ op: 'safeLoop', on: false });
        } catch (er) { UI.toast(er.message, 'err'); }
        setTimeout(() => UI.renderRight(true), 150);
      };
      pane.onchange = e => { if (e.target.dataset.xSafe != null) { const it = libItems().find(i => i.src === e.target.value); BVJ.cmd({ op: 'setMany', values: { 'show.safeSrc': e.target.value, 'show.safeName': it ? it.name : '' } }); } };
      this.live(pane, UI.st());
    },
    live(pane) {
      const el = $('#pxOuts', pane); if (!el) return; const list = UI.ostats || [];
      el.innerHTML = list.length ? list.map(o => { const bad = o.dropRate > (UI.st().show.dropWarn || 2); const pct = Math.min(100, (o.fps / (o.target || 60)) * 100);
        return `<div class="card"><header><b>${esc(o.name)}</b><span class="muted small">${o.safe ? '<b style="color:var(--red)">SAFE LOOP</b> · ' : ''}updated ${ago(o.at)}</span></header><div class="body">
          <div class="meter"><i style="width:${pct}%;background:${pct > 92 ? 'var(--green, #3ddc84)' : pct > 75 ? 'var(--amber, #ffb020)' : 'var(--red)'}"></i></div>
          ${kv('Frame rate', `${o.fps} / ${o.target} fps`)}${kv('Dropped frames', `${o.drops} total · ${o.dropRate}% now`, bad ? 'err' : '')}${kv('Worst frame', o.worst + ' ms')}${kv('Video decoder drops', o.vdrop)}${o.mem ? kv('Memory', o.mem + ' MB') : ''}
          ${o.errors && o.errors.length ? kv('Errors', esc(o.errors.join(' · ')), 'err') : ''}${o.glLost ? kv('Graphics', 'context lost — recovering', 'err') : ''}
          ${(o.events || []).slice(-3).reverse().map(ev => `<div class="small muted">${new Date(ev.at).toLocaleTimeString()} · ${esc(ev.msg)}</div>`).join('')}</div></div>`; }).join('')
        : '<div class="hint">No output windows connected.</div>';
    },
  };

  /* ================= PREFLIGHT ================= */
  let pf = null, pfBusy = false, pfSel = new Set(), pfFilter = 'flagged';
  UI.panels.preflight = {
    sig: () => JSON.stringify([!!pf, pfBusy, pfFilter, pf && pf.at, pfSel.size]),
    render(s) {
      let h = sec('Content preflight', `<div class="hint" style="margin-top:0">Checks every file in the library against the composition and LED screens: resolution, aspect, frame rate, codecs that are heavy to decode live, files that need conversion, very high bitrates and missing media used by the show.</div>
        <button class="btn sm primary" data-x="run" ${pfBusy ? 'disabled' : ''}>${pfBusy ? 'Checking…' : (pf ? 'Re-check' : 'Run preflight')}</button>`);
      if (!pf) return h;
      const sm = pf.summary;
      h += sec('Result', `${kv('Files checked', sm.total)}${kv('Flagged', sm.flagged, sm.flagged ? 'err' : '')}${kv('Flagged and used in this show', sm.usedFlagged, sm.usedFlagged ? 'err' : '')}${kv('Missing media', sm.missing, sm.missing ? 'err' : '')}
        ${kv('Biggest target', `${esc(pf.target.name)} ${pf.target.w}×${pf.target.h} @ ${pf.fps} fps`)}${!pf.ffprobe ? '<div class="hint">ffprobe not found — install ffmpeg for full checks.</div>' : ''}
        ${pf.missing.length ? `<div class="hint" style="color:var(--red)">Missing: ${pf.missing.map(esc).join(', ')}</div>` : ''}`);
      const items = pf.items.filter(i => pfFilter === 'all' || (pfFilter === 'used' ? i.used : i.issues.some(x => x.lvl === 'warn' || x.lvl === 'err')));
      h += sec('Files', `<div class="seg" style="margin-bottom:6px">${[['flagged', 'Flagged'], ['used', 'Used in show'], ['all', 'All']].map(([k, l]) => `<button data-x="filter" data-f="${k}" class="${pfFilter === k ? 'on' : ''}">${l}</button>`).join('')}</div>
        ${items.map(i => `<div class="card pf"><header><input type="checkbox" data-pf="${esc(i.src)}" ${pfSel.has(i.src) ? 'checked' : ''}><b title="${esc(i.src)}">${esc(i.name)}</b>${i.used ? '<span class="tag">in show</span>' : ''}<span class="muted small">${i.info.codec ? esc(i.info.codec) : ''} ${i.info.w ? i.info.w + '×' + i.info.h : ''} ${i.info.fps ? i.info.fps + 'fps' : ''} · ${fmtB(i.size)}</span></header>
          <div class="body">${i.issues.map(x => `<div class="small" style="color:${x.lvl === 'err' ? 'var(--red)' : x.lvl === 'warn' ? 'var(--amber, #ffb020)' : x.lvl === 'ok' ? 'var(--green, #3ddc84)' : 'var(--muted, #999)'}">${x.lvl === 'ok' ? '✓' : x.lvl === 'info' ? 'ℹ' : '⚠'} ${esc(x.msg)}</div>`).join('') || '<div class="small" style="color:var(--green, #3ddc84)">✓ No issues</div>'}</div></div>`).join('') || '<div class="hint">Nothing to show.</div>'}`);
      h += sec('Optimise selected', `<div class="hint" style="margin-top:0">Re-encodes the selected files on this computer to H.264 at the size and frame rate the show needs (letterboxed, never stretched), saves them to <b>Local Library ▸ Optimised</b>, and points the show's clips at the new files. Originals are kept.</div>
        <div class="row wide"><label>Size</label><div class="ctl" style="display:flex;gap:4px"><input type="number" id="pfW" value="${pf.target.w}" style="width:80px">×<input type="number" id="pfH" value="${pf.target.h}" style="width:80px"></div></div>
        <div class="row wide"><label>Frame rate</label><div class="ctl"><input type="number" id="pfF" value="${pf.fps}" style="width:80px"></div></div>
        <div class="row wide"><label>Relink clips</label><div class="ctl"><input type="checkbox" id="pfR" checked></div></div>
        <div style="display:flex;gap:6px"><button class="btn sm" data-x="selFlag">Select flagged in show</button><button class="btn sm primary" data-x="opt" ${pfSel.size ? '' : 'disabled'}>Optimise ${pfSel.size} file${pfSel.size === 1 ? '' : 's'}</button></div><div id="pfJobs"></div>`);
      return h;
    },
    after(pane) {
      pane.onclick = async e => {
        const x = e.target.closest('[data-x]'); if (!x) return; const k = x.dataset.x;
        if (k === 'run') { pfBusy = true; UI.renderRight(true); try { pf = await api('/api/preflight'); } catch (er) { UI.toast(er.message, 'err'); } pfBusy = false; UI.renderRight(true); }
        if (k === 'filter') { pfFilter = x.dataset.f; UI.renderRight(true); }
        if (k === 'selFlag' && pf) { pf.items.filter(i => i.used && i.issues.some(q => q.lvl === 'warn' || q.lvl === 'err')).forEach(i => pfSel.add(i.src)); UI.renderRight(true); }
        if (k === 'opt') { try { const r = await api('/api/optimise', { method: 'POST', body: { keys: [...pfSel], w: +$('#pfW').value, h: +$('#pfH').value, fps: +$('#pfF').value, relink: $('#pfR').checked } }); UI.optjobs = r.jobs; pfSel.clear(); UI.renderRight(true); UI.toast('Optimising — progress below'); } catch (er) { UI.toast(er.message, 'err'); } }
      };
      pane.onchange = e => { const k = e.target.dataset.pf; if (k == null) return; if (e.target.checked) pfSel.add(k); else pfSel.delete(k); const b = $('[data-x="opt"]', pane); if (b) { b.disabled = !pfSel.size; b.textContent = `Optimise ${pfSel.size} file${pfSel.size === 1 ? '' : 's'}`; } };
      if (!UI.optjobs.length) api('/api/optjobs').then(r => { UI.optjobs = r.jobs; this.live(pane); }).catch(() => {});
      this.live(pane);
    },
    live(pane) { const el = $('#pfJobs', pane); if (!el) return; el.innerHTML = (UI.optjobs || []).slice(-8).reverse().map(j => `<div class="small" style="margin-top:4px">${esc(j.name)} → ${j.w}×${j.h}@${j.fps} · <b style="color:${j.status === 'error' ? 'var(--red)' : j.status === 'done' ? 'var(--green, #3ddc84)' : ''}">${j.status === 'running' ? j.pct + '%' : j.status}</b>${j.relinked ? ` · ${j.relinked} clip(s) relinked` : ''}${j.err ? ' · ' + esc(j.err) : ''}</div>`).join(''); },
  };

  /* ================= CONSOLE: CITP + MVR ================= */
  let citpInfo = null, mvrScene = null, mvrFile = null;
  UI.panels.console = {
    sig: s => JSON.stringify([s.citp, !!mvrScene, citpInfo && citpInfo.peers.length]),
    render(s) {
      let h = sec('CITP / MSEX media-server link', `<div class="hint" style="margin-top:0">Lets a lighting console that speaks CITP find PIXORA on the network and show each layer's clips as thumbnails with names, plus live layer status. Each layer appears as a media library; clip numbers match PIXORA's DMX clip channel (value 1 = clip 1).</div>
        ${UI.rToggle('Enable CITP', 'citp.on')}${UI.rText('Name shown on the console', 'citp.name', 'PIXORA')}${UI.rNum('Layers exposed', 'citp.layers', 1, 1, 16)}
        <div id="citpSt" class="small muted"></div>
        <div class="hint">Discovery uses multicast on UDP 4809 (CITP PINF). The console and PIXORA must be on the same network. Thumbnails come from the library previews; patch PIXORA with the GDTF file from the DMX tab.</div>`);
      h += sec('MVR stage import', `<div class="hint" style="margin-top:0">Import a My Virtual Rig (.mvr) file exported from grandMA3, Vectorworks, Capture, Depence or similar. Video screens become PIXORA LED screens placed where they are on stage (3D view), sized from their 3D models.</div>
        <input type="file" id="mvrIn" accept=".mvr,.zip">
        ${mvrScene ? `<div style="margin-top:8px">${kv('Video screens', mvrScene.screens.length)}${kv('Fixtures', mvrScene.fixtures.length)}${kv('Other objects', mvrScene.objects.length)}</div>
          ${mvrScene.screens.map(x => `<label class="small" style="display:block"><input type="checkbox" data-mvr="${esc(x.name)}" checked> <b>${esc(x.name)}</b> · ${x.wm}×${x.hm} m${x.sized ? '' : ' (size not in file — default)'} · at ${x.x.toFixed(1)}, ${x.y.toFixed(1)}, ${x.z.toFixed(1)} m · ${x.ry}°</label>`).join('') || '<div class="hint">No video screens in this file.</div>'}
          <div class="row wide"><label>Panel size (mm)</label><div class="ctl" style="display:flex;gap:4px"><input type="number" id="mvrPw" value="500" style="width:70px">×<input type="number" id="mvrPh" value="500" style="width:70px"></div></div>
          <div class="row wide"><label>Panel pixels</label><div class="ctl" style="display:flex;gap:4px"><input type="number" id="mvrPx" value="128" style="width:70px">×<input type="number" id="mvrPy" value="128" style="width:70px"></div></div>
          <button class="btn sm primary" data-x="mvrApply" ${mvrScene.screens.length ? '' : 'disabled'}>Add screens to LED mapping</button>` : ''}`);
      h += sec('grandMA3', `<div id="maSec"><div class="hint">Loading…</div></div>`);
      return h;
    },
    after(pane) {
      if (UI.maLoad) UI.maLoad();
      const poll = async () => { try { citpInfo = await api('/api/citp'); const el = $('#citpSt', pane); if (el) el.innerHTML = citpInfo.on ? `Running on TCP ${citpInfo.port} · ${citpInfo.peers.length ? 'connected: ' + citpInfo.peers.map(esc).join(', ') : 'waiting for a console'}${citpInfo.log.length ? '<br>' + esc(citpInfo.log.slice(-3).map(l => l.m).join(' · ')) : ''}` : 'Off'; } catch {} };
      poll(); clearInterval(this.t); this.t = setInterval(() => { if (UI.rtab === 'console') poll(); else clearInterval(this.t); }, 2000);
      pane.onchange = async e => { if (e.target.id !== 'mvrIn' || !e.target.files[0]) return; mvrFile = await e.target.files[0].arrayBuffer();
        try { mvrScene = await api('/api/mvr', { method: 'POST', body: mvrFile, headers: { 'Content-Type': 'application/octet-stream' } }); } catch (er) { UI.toast(er.message, 'err'); } UI.renderRight(true); };
      pane.onclick = async e => { const x = e.target.closest('[data-x]'); if (!x || x.dataset.x !== 'mvrApply') return;
        const only = $$('[data-mvr]', pane).filter(c => c.checked).map(c => c.dataset.mvr); const opt = { only, panelMm: +$('#mvrPw').value, panelMmH: +$('#mvrPh').value, panelPx: +$('#mvrPx').value, panelPxH: +$('#mvrPy').value };
        try { const r = await api('/api/mvr?apply=1&opt=' + encodeURIComponent(JSON.stringify(opt)), { method: 'POST', body: mvrFile, headers: { 'Content-Type': 'application/octet-stream' } }); UI.toast(`Added ${r.added.length} screen(s) — see the LED tab and 3D view`); mvrScene = null; UI.renderRight(true); } catch (er) { UI.toast(er.message, 'err'); } };
    },
  };

  /* ================= SYNC ================= */
  UI.panels.sync = {
    sig: s => JSON.stringify([s.sync]),
    render(s) {
      return sec('Frame-locked playback across machines', `<div class="hint" style="margin-top:0">Keeps every output's video playheads locked to one clock, so several PIXORA computers (or several outputs on one) stay in step on a big LED wall.
        <br><br><b>Setup:</b> pick one computer as the master. On each other computer, open <b>Team ▸ Backup</b>, set it to follow the master's address, and turn Sync on here. Followers mirror the master's show and measure their clock offset to it continuously.</div>
        ${UI.rToggle('Sync playback', 'sync.on')}${UI.rNum('Nudge when off by (ms)', 'sync.tolerance', 5, 5, 500)}${UI.rNum('Jump when off by (ms)', 'sync.hardSeek', 10, 50, 5000)}
        <div class="hint">Small drift is corrected by speeding up or slowing down by up to 8% (invisible); bigger drift jumps straight to the right frame. Works for looping clips; one-shot, bounce and beat-synced clips play freely. HAP files sync most precisely.</div>`) + sec('Drift per output', '<div id="syncSt"></div>');
    },
    after(pane) { this.live(pane); },
    live(pane) { const el = $('#syncSt', pane); if (!el) return; const list = UI.ostats || []; el.innerHTML = list.length ? list.map(o => kv(esc(o.name), (o.drift && o.drift.length) ? o.drift.map(d => (d > 0 ? '+' : '') + d + ' ms').join(' · ') : (UI.st().sync.on ? 'no looping video' : 'sync off'))).join('') : '<div class="hint">No outputs connected.</div>'; },
  };

  /* ================= ACCESS: users + remote ================= */
  let users = null, me = null, tunnelInfo = null;
  UI.panels.access = {
    sig: () => JSON.stringify([users && users.length, tunnelInfo && tunnelInfo.status, tunnelInfo && tunnelInfo.url, me && me.user]),
    render(s) {
      if (!users) { this.load(); return '<div class="hint">Loading…</div>'; }
      let h = sec('Users & roles', `<div class="hint" style="margin-top:0">${users.length ? 'Everyone signs in with a user name and password.' : 'No users yet — PIXORA uses the PIN (or is open on your network). <b>Create an admin to require sign-in.</b>'}
        <br><b>Admin</b> everything incl. users & updates · <b>Operator</b> runs and edits the show · <b>Client</b> can only trigger clips, columns and cues, blackout and master · <b>Viewer</b> watches only.</div>
        ${users.map(u => `<div class="kv"><span><b>${esc(u.user)}</b> · ${u.role}${me && me.user === u.user ? ' (you)' : ''}</span><b class="small muted">${u.last ? 'last in ' + ago(u.last) : 'never signed in'} ${me && me.admin ? `<button class="btn xs" data-x="del" data-u="${esc(u.user)}">Remove</button>` : ''}</b></div>`).join('')}
        ${!users.length || (me && me.admin) ? `<div class="row wide"><label>User</label><div class="ctl"><input type="text" id="uName" placeholder="name" autocomplete="off"></div></div>
        <div class="row wide"><label>Password</label><div class="ctl"><input type="password" id="uPass" placeholder="min 6 characters" autocomplete="new-password"></div></div>
        <div class="row wide"><label>Role</label><div class="ctl"><select id="uRole">${(users.length ? ['operator', 'client', 'viewer', 'admin'] : ['admin']).map(r => `<option>${r}</option>`).join('')}</select></div></div>
        <button class="btn sm primary" data-x="add">${users.length ? 'Add / update user' : 'Create admin & require sign-in'}</button>` : ''}
        ${me && me.user ? `<button class="btn sm" data-x="logout" style="margin-left:6px">Sign out ${esc(me.user)}</button>` : ''}`);
      const t = tunnelInfo || { status: 'off' };
      h += sec('Remote access (internet)', `<div class="hint" style="margin-top:0">Control this PIXORA from anywhere through a secure Cloudflare tunnel — no router changes. You get a private https link; everyone still has to sign in. Needs the free <b>cloudflared</b> tool on this computer.</div>
        ${kv('Status', t.status === 'on' ? '<span style="color:var(--green, #3ddc84)">Online</span>' : t.status)}
        ${t.url ? `<div class="codebox" style="user-select:all">${esc(t.url)}</div><a class="btn sm" href="${esc(t.url)}" target="_blank" rel="noopener">Open link</a>` : ''}
        ${t.err ? `<div class="hint" style="color:var(--red)">${esc(t.err)}</div>` : ''}
        <button class="btn sm ${t.status === 'on' || t.status === 'starting' ? '' : 'primary'}" data-x="tunnel">${t.status === 'on' || t.status === 'starting' ? 'Turn off remote access' : 'Turn on remote access'}</button>
        <div class="hint">Install: Windows <span class="mono">winget install Cloudflare.cloudflared</span> · Mac <span class="mono">brew install cloudflared</span>. The link changes each time you turn it on.</div>`);
      return h;
    },
    async load() { try { const [u, m, t] = await Promise.all([api('/api/users'), api('/api/auth/me'), api('/api/tunnel')]); users = u.users; me = m; tunnelInfo = t; } catch (er) { users = []; } UI.renderRight(true); },
    after(pane) {
      pane.onclick = async e => {
        const x = e.target.closest('[data-x]'); if (!x) return; const k = x.dataset.x;
        try {
          if (k === 'add') { const first = !users.length; const r = await api('/api/users', { method: 'POST', body: { user: $('#uName').value.trim(), pass: $('#uPass').value, role: $('#uRole').value } }); users = r.users;
            if (first) { UI.toast('Admin created — sign in to continue'); setTimeout(() => location.href = '/login.html?next=' + encodeURIComponent(location.pathname + location.search), 700); return; } UI.toast('User saved'); }
          if (k === 'del') { if (!confirm('Remove ' + x.dataset.u + '?')) return; users = (await api('/api/users', { method: 'POST', body: { action: 'delete', user: x.dataset.u } })).users; }
          if (k === 'logout') { await api('/api/auth/logout', { method: 'POST' }); location.href = '/login.html'; return; }
          if (k === 'tunnel') { const on = !(tunnelInfo && (tunnelInfo.status === 'on' || tunnelInfo.status === 'starting')); tunnelInfo = await api('/api/tunnel', { method: 'POST', body: { on } }); if (on) { const t0 = Date.now(); const w = async () => { tunnelInfo = await api('/api/tunnel'); UI.renderRight(true); if (tunnelInfo.status === 'starting' && Date.now() - t0 < 30000) setTimeout(w, 1000); }; setTimeout(w, 1000); } }
        } catch (er) { UI.toast(er.message, 'err'); }
        UI.renderRight(true);
      };
    },
  };

  /* ================= REPORTS ================= */
  UI.panels.reports = {
    sig: () => 'r',
    render() {
      const today = new Date().toISOString().slice(0, 10);
      return sec('Show report (PDF)', `<div class="hint" style="margin-top:0">A client-ready PDF: summary, proof of play per item and the full play log, incidents (safe loop, frame drops, errors, failover) and every change made during the show.</div>
        <div class="row wide"><label>Title</label><div class="ctl"><input type="text" id="repT" placeholder="e.g. Pop-Up Polo — Saturday"></div></div>
        <div class="row wide"><label>From</label><div class="ctl"><input type="date" id="repF" value="${today}"></div></div>
        <div class="row wide"><label>To</label><div class="ctl"><input type="date" id="repTo" value="${today}"></div></div>
        <button class="btn sm primary" data-x="pdf">Create PDF</button> <button class="btn sm" data-x="csv">Proof-of-play CSV</button>`);
    },
    after(pane) { pane.onclick = e => { const x = e.target.closest('[data-x]'); if (!x) return; const q = new URLSearchParams({ from: $('#repF').value, to: $('#repTo').value, title: $('#repT').value });
      if (x.dataset.x === 'pdf') window.open('/api/report?' + q, '_blank'); else window.open('/api/pop.csv?' + q, '_blank'); }; },
  };

  /* ================= UPDATES ================= */
  let updInfo = null, ghUpd = null;
  const PN = window.pixoraNative;
  if (PN && PN.onUpdate) PN.onUpdate(v => { ghUpd = v; if (UI.rtab === 'update') UI.renderRight(true); });
  function ghSection() { // desktop app: updates from GitHub Releases
    if (!ghUpd) { PN.updateState().then(v => { ghUpd = v; UI.renderRight(true); }).catch(() => {}); return sec('Automatic updates', '<div class="hint">Loading…</div>'); }
    const g = ghUpd, pct = g.size ? Math.round(g.got / g.size * 100) : 0;
    const status = { idle: g.checked ? 'Up to date' : 'Not checked yet', checking: 'Checking…', available: `PIXORA ${esc(g.version || '')} is available`, downloading: `Downloading ${esc(g.version || '')}… ${pct}%`, ready: `PIXORA ${esc(g.version || '')} is ready to install`, error: 'Couldn’t check: ' + esc(g.error || '') }[g.status] || esc(g.status);
    return sec('Automatic updates', `${kv('Installed', 'v' + esc(g.current))}${kv('Status', status)}
      <div class="row wide"><label>Check automatically</label><div class="ctl"><button class="sw ${g.auto ? 'on' : ''}" data-gh="auto"></button></div></div>
      <div style="display:flex;gap:6px"><button class="btn sm" data-gh="check" ${['checking', 'downloading'].includes(g.status) ? 'disabled' : ''}>Check for updates</button>${g.status === 'ready' ? '<button class="btn sm primary" data-gh="install">Install…</button>' : ''}</div>
      ${g.notes && ['available', 'downloading', 'ready'].includes(g.status) ? `<div class="hint" style="white-space:pre-wrap">${esc(g.notes.slice(0, 600))}</div>` : ''}
      <div class="hint">PIXORA checks <span class="mono">github.com/${esc(g.repo)}</span> shortly after it starts and every 6 hours. It downloads the installer for this computer in the background and checks it against GitHub's checksum. Then it asks before installing: <b>Restart and install</b>, <b>Install when I quit</b> or <b>Skip this version</b>. It never restarts on its own, and while outputs are on air it waits to ask. Shows, settings and media are kept.</div>`);
  }
  UI.panels.update = {
    sig: s => JSON.stringify([s.update, updInfo && [updInfo.latest && updInfo.latest.version, updInfo.err, updInfo.applying, updInfo.checking], ghUpd && [ghUpd.status, ghUpd.auto, ghUpd.version, Math.round((ghUpd.got || 0) / 5e6)]]),
    render(s) {
      if (!updInfo) { api('/api/update').then(r => { updInfo = r; UI.renderRight(true); }).catch(() => {}); }
      const u = updInfo || {}; const L = u.latest;
      return (PN && PN.updateState ? ghSection() : '') + sec(PN && PN.updateState ? 'Your own update feed (optional)' : 'PIXORA version', `${kv('Installed', 'v' + (u.version || BVJ.info && BVJ.info.version || '?'))}
        ${L ? kv('Latest', `v${esc(L.version)} ${L.newer ? '<span style="color:var(--green, #3ddc84)">· update available</span>' : '· up to date'}`) : ''}${L && L.notes ? `<div class="hint">${esc(L.notes)}</div>` : ''}
        ${u.err ? `<div class="hint" style="color:var(--red)">${esc(u.err)}</div>` : ''}${u.staged ? `<div class="hint">${esc(u.staged)}</div>` : ''}
        ${UI.rText('Update feed URL', 'update.feed', 'https://your-site/pixora/latest.json')}
        <div style="display:flex;gap:6px"><button class="btn sm" data-x="check" ${u.checking ? 'disabled' : ''}>Check for updates</button>${L && L.newer ? `<button class="btn sm primary" data-x="apply" ${u.applying ? 'disabled' : ''}>${u.native ? 'Download v' + esc(L.version) + ' installer' : u.applying ? 'Installing…' : 'Install v' + esc(L.version) + ' & restart'}</button>` : ''}</div>
        <div class="hint">The feed is a small JSON file you host (e.g. on your website): <span class="mono">{"version":"1.2.1","url":"PIXORA-1.2.1.zip","sha256":"…","notes":"…"}</span>. Updates are verified against the SHA-256 checksum before anything is replaced; the previous version is kept in <span class="mono">.backup/</span>. Shows, settings and media are never touched.</div>`);
    },
    after(pane) { pane.onclick = async e => { const g = e.target.closest('[data-gh]');
      if (g) { const k = g.dataset.gh; try { ghUpd = k === 'auto' ? await PN.updateAuto(!ghUpd.auto) : k === 'install' ? await PN.updateInstall() : await PN.updateCheck(); } catch (er) { UI.toast(er.message, 'err'); } UI.renderRight(true); return; }
      const x = e.target.closest('[data-x]'); if (!x) return;
      try { updInfo = await api('/api/update', { method: 'POST', body: { action: x.dataset.x } }); if (updInfo.download) { window.open(updInfo.download, '_blank'); UI.toast('Downloading the new installer — run it to update PIXORA'); } else if (x.dataset.x === 'apply') { UI.toast('Installing update — PIXORA will restart'); setTimeout(() => location.reload(), 6000); } } catch (er) { UI.toast(er.message, 'err'); } UI.renderRight(true); }; },
  };
})();
