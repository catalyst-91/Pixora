/* PIXORA pro panels: data feeds & rules, sponsors, scheduler, team, health, checklist + extensions to existing panels */
(function () {
  const S = window.SCHEMA, UI = window.UI, $ = UI.$, $$ = UI.$$, esc = UI.esc, I = UI.icon;
  const sec = (title, body, extra) => `<div class="sec"><h4>${title}${extra || ''}</h4>${body}</div>`;
  const ago = t => { if (!t) return 'never'; const s = Math.round((Date.now() - t) / 1000); return s < 60 ? s + 's ago' : s < 3600 ? Math.round(s / 60) + 'm ago' : Math.round(s / 3600) + 'h ago'; };
  const fmtB = n => n > 1073741824 ? (n / 1073741824).toFixed(1) + ' GB' : Math.round(n / 1048576) + ' MB';

  /* ---------- shared action editor (rules, schedule) */
  UI.actionEditor = function (base, a) {
    a = a || { type: 'column' }; const s = UI.st();
    const f = (k, label, type, extra) => `<label class="af">${label}<input type="${type || 'number'}" data-actf="${k}" value="${esc(a[k] ?? '')}" ${extra || ''}></label>`;
    let h = `<div class="acted" data-actbase="${base}"><label class="af" style="flex:1 1 100%">Action<select data-actf="type">${S.ACTIONS.map(([v, l]) => `<option value="${v}" ${a.type === v ? 'selected' : ''}>${l}</option>`).join('')}</select></label>`;
    if (a.type === 'trigger') h += f('layer', 'Layer #', 'number', 'min="1"') + f('clip', 'Clip #', 'number', 'min="1"');
    if (a.type === 'column') h += f('col', 'Column #', 'number', 'min="1"');
    if (a.type === 'clearLayer') h += f('layer', 'Layer #', 'number', 'min="1"');
    if (a.type === 'cueIndex') h += f('index', 'Cue #', 'number', 'min="1"');
    if (a.type === 'deck') h += f('deck', 'Deck #', 'number', 'min="1"');
    if (a.type === 'master') h += f('value', 'Level 0–1', 'number', 'step="0.05" min="0" max="1"');
    if (a.type === 'loadComp') h += `<label class="af" style="flex:1">Composition<select data-actf="name">${(UI.comps || []).map(c => `<option ${c === a.name ? 'selected' : ''}>${esc(c)}</option>`).join('')}</select></label>`;
    if (a.type === 'custom') h += `<label class="af" style="flex:1 1 100%">JSON command(s)<textarea data-actf="json" rows="2">${esc(a.json || '[{"op":"trigger","layer":0,"clip":0}]')}</textarea></label>`;
    return h + '</div>';
  };
  document.addEventListener('change', e => {
    const box = e.target.closest('.acted'); if (!box || !e.target.dataset.actf) return;
    const a = {}; $$('[data-actf]', box).forEach(x => { a[x.dataset.actf] = x.type === 'number' ? (x.value === '' ? '' : +x.value) : x.value; });
    BVJ.cmd({ op: 'set', path: box.dataset.actbase, value: a }); if (e.target.dataset.actf === 'type') setTimeout(() => UI.renderRight(true), 60);
  });

  /* ================= DATA FEEDS, RULES, OSC OUT ================= */
  UI.panels.data = {
    sig: s => JSON.stringify([s.feeds.map(f => [f.id, f.type]), s.rules.map(r => [r.id, r.action && r.action.type, r.feed]), s.oscOut.targets.length, s.oscOut.enabled]),
    render(s) {
      const host = location.host;
      let h = sec('Data feeds — feed PIXORA from any app', `<div class="hint" style="margin-top:0">PIXORA stays independent: other software (your scoreboard, a ticketing system, a spreadsheet, a console macro…) simply sends data in. Use <span class="mono">{{feedId.key}}</span> in Text and Title generators to display it, and Rules to react to it.</div>
        <div class="codebox"><b>Push JSON</b> POST http://${esc(host)}/api/feed/<i>id</i><br><b>Quick set</b> GET /api/feed/<i>id</i>?score=3&amp;chukka=2<br><b>OSC</b> /pixora/data/<i>id</i>/<i>key</i> value  (UDP ${(UI.st() && 7000)})<br><b>Poll</b> a JSON / CSV / text URL (e.g. a published Google Sheet)</div>
        <button class="btn sm primary" data-x="feedAdd">${I('plus')}Add feed</button>`);
      s.feeds.forEach((f, i) => { const b = `feeds.${i}`; const st = (BVJ.feedStatus || {})[f.id] || {};
        h += `<div class="card"><header><button class="sw" data-path="${b}.on" data-toggle></button><b>${esc(f.name || f.id)}</b><span class="mono small muted">{{${esc(f.id)}.…}}</span><button class="btn xs danger" data-x="feedRemove" data-id="${esc(f.id)}">${I('trash')}</button></header><div class="body">
          <div class="row wide"><label>Name</label><div class="ctl"><input type="text" data-path="${b}.name"></div></div>
          <div class="row wide"><label>Type</label><div class="ctl"><select data-path="${b}.type" data-rerender><option value="json">Poll JSON URL</option><option value="csv">Poll CSV URL</option><option value="text">Poll text URL</option><option value="push">Push only (HTTP / OSC)</option></select></div></div>
          ${f.type !== 'push' ? `<div class="row wide"><label>URL</label><div class="ctl"><input type="text" data-path="${b}.url" placeholder="http://scoreboard.local/api/state"></div></div><div class="row wide"><label>Every (s)</label><div class="ctl"><input type="number" min="1" data-path="${b}.interval" style="width:80px"></div></div>` : `<div class="hint">Push to <span class="mono">POST /api/feed/${esc(f.id)}</span> (JSON body), <span class="mono">GET /api/feed/${esc(f.id)}?key=value</span> or OSC <span class="mono">/pixora/data/${esc(f.id)}/key</span>.</div>`}
          <div class="kv"><span>Last update</span><b data-feedst="${esc(f.id)}" style="color:${st.err ? 'var(--red)' : ''}">${st.err ? esc(st.err) : ago(st.at)}</b></div>
          <pre class="feedval" data-feedval="${esc(f.id)}">${esc(JSON.stringify((BVJ.feeds || {})[f.id] ?? null, null, 1).slice(0, 1200))}</pre></div></div>`; });
      h += sec('Rules — react to data', `<div class="hint" style="margin-top:0">When a feed value changes, equals, rises above or drops below a value, PIXORA runs an action — e.g. play a “GOAL” sting when <span class="mono">polo.homeScore</span> increases.</div><button class="btn sm primary" data-x="ruleAdd" ${s.feeds.length ? '' : 'disabled'}>${I('plus')}Add rule</button>`);
      s.rules.forEach((r, i) => { const b = `rules.${i}`;
        h += `<div class="card"><header><button class="sw" data-path="${b}.on" data-toggle></button><b>${esc(r.name)}</b><button class="btn xs" data-x="ruleTest" data-id="${r.id}">Test</button><button class="btn xs danger" data-x="ruleRemove" data-id="${r.id}">${I('trash')}</button></header><div class="body">
          <div class="row wide"><label>Name</label><div class="ctl"><input type="text" data-path="${b}.name"></div></div>
          <div class="row wide"><label>When feed</label><div class="ctl"><select data-path="${b}.feed">${s.feeds.map(f => `<option value="${esc(f.id)}">${esc(f.name || f.id)}</option>`).join('')}</select><input type="text" data-path="${b}.path" placeholder="key e.g. homeScore" class="mono"></div></div>
          <div class="row wide"><label>Condition</label><div class="ctl"><select data-path="${b}.when" data-rerender><option value="change">changes</option><option value="increase">increases</option><option value="equals">becomes equal to</option><option value="above">rises above</option><option value="below">drops below</option></select>${['equals', 'above', 'below'].includes(r.when) ? `<input type="text" data-path="${b}.value" style="width:90px">` : ''}</div></div>
          <div class="row wide"><label>Cooldown (s)</label><div class="ctl"><input type="number" min="0" data-path="${b}.cooldown" style="width:80px"></div></div>
          ${UI.actionEditor(b + '.action', r.action)}</div></div>`; });
      h += sec('OSC output — feedback to consoles & apps', `${UI.rToggle('Enabled', 'oscOut.enabled')}
        ${s.oscOut.targets.map((t, i) => `<div class="row wide"><label>Target ${i + 1}</label><div class="ctl"><button class="sw" data-path="oscOut.targets.${i}.on" data-toggle></button><input type="text" data-path="oscOut.targets.${i}.host" placeholder="192.168.1.50"><input type="number" data-path="oscOut.targets.${i}.port" style="width:70px"><button class="btn xs danger" data-x="oscDel" data-i="${i}">${I('trash')}</button></div></div>`).join('')}
        <button class="btn sm" data-x="oscAdd">${I('plus')}Add target</button>
        <div class="hint">Sends on change: <span class="mono">/pixora/layer/N/clip</span> (name), <span class="mono">/layer/N/opacity</span>, <span class="mono">/layer/N/active</span>, <span class="mono">/master</span>, <span class="mono">/blackout</span>, <span class="mono">/bpm</span>, <span class="mono">/cue/name</span>, <span class="mono">/cue/index</span>, <span class="mono">/deck</span>, <span class="mono">/test</span>, <span class="mono">/sponsor</span>, <span class="mono">/timeline/playing</span>. Point it at a grandMA3 (OSC in), Companion, TouchOSC or QLab-style software.</div>`);
      return h;
    },
    after() { this.live($('#rpane'), UI.st()); },
    live(pane, s) { $$('[data-feedval]', pane).forEach(e => { const v = (BVJ.feeds || {})[e.dataset.feedval]; e.textContent = JSON.stringify(v ?? null, null, 1).slice(0, 1200); });
      $$('[data-feedst]', pane).forEach(e => { const st = (BVJ.feedStatus || {})[e.dataset.feedst] || {}; e.textContent = st.err ? st.err : ago(st.at); e.style.color = st.err ? 'var(--red)' : ''; }); },
  };

  /* ================= SPONSORS & PROOF OF PLAY ================= */
  let popData = null, popFrom = new Date().toISOString().slice(0, 10), popTo = popFrom;
  UI.panels.sponsors = {
    sig: s => JSON.stringify([s.rotation.items.map(i => [i.id, !!i.clip, i.clip && i.clip.name]), s.rotation.enabled, s.rotation.mode, s.layers.length]),
    render(s) {
      const r = s.rotation;
      let h = sec('Sponsor / ad rotation', `${UI.rToggle('Rotation on', 'rotation.enabled')}
        ${UI.rSelect('Play on layer', 'rotation.layer', s.layers.map((l, i) => [i, `${i + 1} · ${l.name}`]), true)}
        <div class="row wide"><label>Mode</label><div class="ctl">${UI.seg('rotation.mode', [['interval', 'Every N minutes'], ['loop', 'Continuous loop']])}</div></div>
        <div class="kv"><span>Now playing</span><b id="rotNow">—</b></div>
        <div class="hint">Spots take over the chosen layer for their duration, then the layer returns to what it was playing. Every play is logged for proof-of-play reports. Optional time windows restrict a spot to certain hours.</div>
        <div style="display:flex;gap:6px"><button class="btn sm primary" data-x="rotAdd">${I('plus')}Add spot</button><button class="btn sm" data-x="rotStop">■ Stop current</button></div>`);
      r.items.forEach((it, i) => { const b = `rotation.items.${i}`;
        h += `<div class="card"><header><button class="sw" data-path="${b}.on" data-toggle></button><b>${esc(it.name)}</b><span class="muted small">${esc(it.sponsor || '')}</span><button class="btn xs" data-x="rotPlay" data-id="${it.id}">▶ Now</button><button class="btn xs danger" data-x="rotRemove" data-id="${it.id}">${I('trash')}</button></header><div class="body">
          <div class="row wide"><label>Spot name</label><div class="ctl"><input type="text" data-path="${b}.name"></div></div>
          <div class="row wide"><label>Sponsor</label><div class="ctl"><input type="text" data-path="${b}.sponsor"></div></div>
          <div class="row wide"><label>Content</label><div class="ctl"><span class="muted small" style="flex:1">${it.clip ? esc(BVJ.clipLabel(it.clip)) : 'none'}</span><button class="btn xs" data-x="rotClip" data-i="${i}">Use selected clip</button></div></div>
          <div class="row wide"><label>Every / for</label><div class="ctl"><input type="number" step="0.5" min="0.1" data-path="${b}.every" style="width:70px"><span class="muted small">min, for</span><input type="number" min="1" data-path="${b}.dur" style="width:70px"><span class="muted small">s</span></div></div>
          <div class="row wide"><label>Time window</label><div class="ctl"><input type="time" data-path="${b}.from"><span class="muted">→</span><input type="time" data-path="${b}.to"></div></div></div></div>`; });
      h += sec('Proof of play', `<div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap"><input type="date" id="popFrom" value="${popFrom}"><span class="muted">→</span><input type="date" id="popTo" value="${popTo}"><button class="btn sm" data-x="popLoad">Show</button></div>
        <div id="popBox" style="margin-top:8px"><div class="muted small">Loading…</div></div>
        <div style="display:flex;gap:6px;margin-top:8px"><button class="btn sm" data-x="popCsv">${I('upload')}Download CSV</button><button class="btn sm primary" data-x="popReport">${I('book')}Open printable report</button></div>`);
      return h;
    },
    after() { this.loadPop(); },
    async loadPop() { try { popData = await UI.api(`/api/pop/summary?from=${popFrom}&to=${popTo}`); } catch { return; } const b = $('#popBox'); if (!b) return;
      b.innerHTML = popData.sponsors.length ? `<table class="tbl"><thead><tr><th>Sponsor</th><th>Plays</th><th>Airtime</th></tr></thead><tbody>${popData.sponsors.map(x => `<tr><td>${esc(x.sponsor)}</td><td>${x.plays}</td><td>${Math.floor(x.seconds / 60)}m ${Math.round(x.seconds % 60)}s</td></tr>`).join('')}</tbody></table>` : '<div class="muted small">No plays logged in this period.</div>';
      this.live($('#rpane')); },
    live(pane) { const n = $('#rotNow', pane); if (n && popData) n.textContent = popData.playing ? `${popData.playing.name} (${Math.max(0, Math.round(popData.playing.dur - (Date.now() - popData.playing.since) / 1000))}s left)` : '—';
      if (!this._t) this._t = setInterval(() => { if (UI.rtab === 'sponsors') UI.api(`/api/pop/summary?from=${popFrom}&to=${popTo}`).then(d => { popData = d; this.live($('#rpane')); }).catch(() => {}); }, 2000); },
  };

  /* ================= SCHEDULER ================= */
  const DAYS = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
  UI.panels.schedule = {
    sig: s => JSON.stringify(s.schedule.map(e => [e.id, e.action && e.action.type, e.days.join('')])),
    render(s) {
      let h = sec('Scheduler', `<div class="kv"><span>Server clock</span><b id="srvClock" class="mono">—</b></div><div class="hint">Run any action at a time of day on chosen weekdays — e.g. load the “Day” composition at 10:00, switch to night looks at 18:30, black out at 23:00. Times use the clock of the computer running PIXORA. Ideal for unattended installs.</div>
        <button class="btn sm primary" data-x="schedAdd">${I('plus')}Add scheduled action</button>`);
      s.schedule.forEach((e, i) => { const b = `schedule.${i}`;
        h += `<div class="card"><header><button class="sw" data-path="${b}.on" data-toggle></button><b>${esc(e.name)}</b><span class="mono small">${esc(e.time)}</span><button class="btn xs" data-x="schedRun" data-i="${i}">Run now</button><button class="btn xs danger" data-x="schedRemove" data-id="${e.id}">${I('trash')}</button></header><div class="body">
          <div class="row wide"><label>Name</label><div class="ctl"><input type="text" data-path="${b}.name"></div></div>
          <div class="row wide"><label>Time</label><div class="ctl"><input type="time" data-path="${b}.time"></div></div>
          <div class="row wide"><label>Days</label><div class="ctl days">${DAYS.map((d, k) => `<button class="${e.days.includes(k) ? 'on' : ''}" data-x="schedDay" data-i="${i}" data-d="${k}">${d}</button>`).join('')}</div></div>
          ${UI.actionEditor(b + '.action', e.action)}</div></div>`; });
      return h;
    },
    live(pane) { const c = $('#srvClock', pane); if (c) c.textContent = new Date().toLocaleTimeString(); if (!this._t) this._t = setInterval(() => { if (UI.rtab === 'schedule') this.live($('#rpane')); }, 1000); },
    after() { this.live($('#rpane')); },
  };

  /* ================= TEAM / LOCKS / BACKUP ================= */
  UI.panels.team = {
    sig: s => JSON.stringify([s.layers.map(l => [l.id, l.lockedBy]), (UI.presence || []).map(p => [p.id, p.name, p.tab]), UI.follow, UI.backup, UI.library.settings && UI.library.settings.backup]),
    render(s) {
      const b = (UI.library.settings && UI.library.settings.backup) || { mode: 'off', primary: '', failoverSec: 3 }; const bs = UI.backup || {};
      let h = sec('You', `<div class="row wide"><label>Operator name</label><div class="ctl"><input type="text" id="meName" value="${esc(UI.me.name)}"><input type="color" id="meColor" value="${esc(UI.me.color)}"></div></div>`);
      h += sec('Connected operators', `<table class="tbl"><thead><tr><th>Name</th><th>Device</th><th>Looking at</th><th>Ping</th><th></th></tr></thead><tbody>${(UI.presence || []).map(p => {
        const me = p.id === UI.myId; const sel = p.sel ? `L${p.sel.layer + 1}${p.sel.slot != null ? ' C' + (p.sel.slot + 1) : ''}` : '';
        return `<tr><td><span class="swatch" style="display:inline-block;background:${esc(p.color)}"></span> ${esc(p.name)}${me ? ' (you)' : ''}</td><td class="muted">${esc(p.role)}${p.viewer ? ' · view' : ''}</td><td class="muted">${esc(p.tab || '')} ${sel}</td><td class="mono">${p.rtt != null ? p.rtt + 'ms' : ''}</td><td>${!me && p.role === 'control' ? `<button class="btn xs ${UI.follow === p.id ? 'on' : ''}" data-x="follow" data-id="${p.id}">${UI.follow === p.id ? 'Following' : 'Follow'}</button>` : ''}</td></tr>`; }).join('')}</tbody></table>
        <div class="hint">“Follow” mirrors another operator's selected clip and tab — great for training or a second operator shadowing the lead.</div>`);
      h += sec('Layer locks', s.layers.map((l, i) => `<div class="row wide"><label>${i + 1} · ${esc(l.name)}</label><div class="ctl"><button class="btn xs ${l.lockedBy ? 'on' : ''}" data-x="lock" data-i="${i}">${l.lockedBy ? '🔒 ' + esc(l.lockedBy) : 'Unlocked'}</button>${l.lockedBy && l.lockedBy !== UI.me.name ? `<button class="btn xs danger" data-x="unlockForce" data-i="${i}">Force unlock</button>` : ''}</div></div>`).join('') + `<div class="hint">A locked layer can only be changed by the operator who locked it (triggering, faders, effects, clips). Others see the lock in the layer header.</div>`);
      h += sec('Backup / failover server', `<div class="row wide"><label>This server is</label><div class="ctl"><select id="bkMode"><option value="off" ${b.mode !== 'backup' ? 'selected' : ''}>Primary (normal)</option><option value="backup" ${b.mode === 'backup' ? 'selected' : ''}>Backup of another PIXORA</option></select></div></div>
        ${b.mode === 'backup' ? `<div class="row wide"><label>Primary URL</label><div class="ctl"><input type="text" id="bkUrl" value="${esc(b.primary || '')}" placeholder="http://192.168.1.10:8080"></div></div>
          <div class="row wide"><label>Fail over after</label><div class="ctl"><input type="number" id="bkSec" value="${b.failoverSec || 3}" min="1" style="width:70px"><span class="muted small">seconds without the primary</span></div></div>
          <div class="row wide"><label>Primary PIN</label><div class="ctl"><input type="text" id="bkPin" value="${esc(b.pin || '')}" placeholder="if the primary uses a PIN"></div></div>` : ''}
        <button class="btn sm primary" data-x="bkSave">Apply</button>
        <div class="kv"><span>Status</span><b style="color:${bs.active ? 'var(--red)' : bs.connected ? 'var(--green)' : ''}">${bs.mode === 'backup' ? (bs.active ? 'ACTIVE — primary lost, this server is in control' : bs.connected ? 'Mirroring primary (hot standby)' : 'Connecting to primary…') : (bs.mirrors && bs.mirrors.length ? `${bs.mirrors.length} backup server(s) connected: ${bs.mirrors.map(m => m.addr).join(', ')}` : 'No backup connected')}</b></div>
        <div class="hint">Run a second PIXORA machine in Backup mode. It mirrors every change live and its own Output windows render the same show in sync (hot standby). Feed both into your switcher / LED processor's redundant inputs. If the primary disappears, the backup takes control automatically; operator commands sent to it while the primary is alive are forwarded to the primary. Keep media at the same paths, or with the same file names, on both machines.</div>`);
      return h;
    },
    after() {
      $('#meName').onchange = e => UI.setMe(e.target.value); $('#meColor').onchange = e => UI.setMe(null, e.target.value);
      const m = $('#bkMode'); if (m) m.onchange = () => { UI.library.settings.backup = Object.assign({}, UI.library.settings.backup || {}, { mode: m.value }); UI.renderRight(true); };
    },
  };

  /* ================= HEALTH DASHBOARD ================= */
  let healthData = null;
  UI.panels.health = {
    sig: () => '',
    render() { return `<div id="alerts"></div><div id="healthBox"><div class="muted">Collecting…</div></div>`; },
    after() { this.load(); if (!this._t) this._t = setInterval(() => { if (UI.rtab === 'health') this.load(); }, 2000); },
    async load() {
      try { healthData = await UI.api('/api/health'); } catch { return; } const h = healthData; const box = $('#healthBox'); if (!box) return;
      const alerts = UI.healthAlerts(h);
      $('#alerts').innerHTML = alerts.length ? alerts.map(a => `<div class="alert ${a.lvl}">${a.lvl === 'err' ? '●' : '▲'} ${esc(a.msg)}</div>`).join('') : `<div class="alert ok">● All systems normal</div>`;
      const sv = h.server; const memUsed = 1 - sv.mem.free / sv.mem.total;
      box.innerHTML = sec('Outputs', h.outputs.length ? `<table class="tbl"><thead><tr><th>Output</th><th>FPS</th><th>Frame avg/max</th><th>Dropped</th><th>Mem</th></tr></thead><tbody>${h.outputs.map(o => { const st = o.stats || {}; return `<tr><td>${o.primary ? '★ ' : ''}${esc((o.info && o.info.output) || 'Output')}<div class="muted small">${esc(((o.info && o.info.gpu) || '').slice(0, 40))}</div></td><td class="mono" style="color:${st.fps < 25 ? 'var(--red)' : st.fps < 50 ? 'var(--yellow)' : 'var(--green)'}">${st.fps ?? '–'}</td><td class="mono">${st.ftAvg ?? '–'} / ${st.ftMax ?? '–'} ms</td><td class="mono">${st.dropped ?? 0}</td><td class="mono">${st.mem ? st.mem + ' MB' : '–'}</td></tr>`; }).join('')}</tbody></table>` : '<div class="muted">No output windows connected.</div>') +
        sec('Server', `<div class="hgrid"><div><b>${Math.round(sv.load * 100)}%</b><span>CPU (${sv.cpus} cores)</span><div class="meter"><i style="width:${sv.load * 100}%"></i></div></div><div><b>${Math.round(memUsed * 100)}%</b><span>RAM of ${fmtB(sv.mem.total)}</span><div class="meter"><i style="width:${memUsed * 100}%"></i></div></div>
          <div><b style="color:${sv.temp > 85 ? 'var(--red)' : sv.temp > 75 ? 'var(--yellow)' : ''}">${sv.temp != null ? Math.round(sv.temp) + '°C' : sv.throttle != null ? (sv.throttle ? sv.throttle + '% thr.' : 'Nominal') : 'n/a'}</b><span title="${sv.tempSrc ? 'Source: ' + sv.tempSrc : sv.platform === 'darwin' ? 'macOS hides die temperature; showing thermal throttling instead (install osx-cpu-temp for °C)' : sv.platform === 'win32' ? 'No thermal sensor exposed by Windows on this machine' : ''}">${sv.temp == null && sv.throttle != null ? 'Thermal' : 'CPU temp'}</span></div><div><b>${Math.floor(sv.uptime / 3600)}h ${Math.floor(sv.uptime / 60) % 60}m</b><span>Uptime</span></div></div>
          <div class="kv"><span>Host</span><b>${esc(sv.host)} · ${esc(sv.platform)} · Node ${esc(sv.node)} · ffmpeg ${sv.ffmpeg ? 'yes' : 'no'}</b></div>`) +
        sec('Media drives', h.sources.map(d => `<div class="kv"><span><span style="color:${d.online ? 'var(--green)' : 'var(--red)'}">●</span> ${esc(d.name)} <span class="muted small">${d.files} files</span></span><b>${d.bench ? Math.round(d.bench.mbps) + ' MB/s' : ''} <button class="btn xs" data-x="bench" data-id="${d.id}">Test speed</button></b></div>`).join('') + `<div class="hint">A 1080p60 H.264 clip needs ~2–6 MB/s per layer; 4K ProRes-converted content can need 30+ MB/s. USB 2 drives (~30 MB/s) can struggle with several 4K layers.</div>`) +
        sec('Clients & latency', h.clients.map(c => `<div class="kv"><span>${esc(c.name)} <span class="muted small">${esc(c.role)}</span></span><b class="mono" style="color:${c.rtt > 150 ? 'var(--yellow)' : ''}">${c.rtt != null ? c.rtt + ' ms' : '–'}</b></div>`).join(''));
    },
  };
  UI.healthAlerts = function (h) {
    const a = []; const s = UI.st();
    if (!h.outputs.length) a.push({ lvl: 'err', msg: 'No output window connected' });
    else if (s && h.outputs.length < (s.checklist.expectedOutputs || 1)) a.push({ lvl: 'warn', msg: `Only ${h.outputs.length} of ${s.checklist.expectedOutputs} expected outputs connected` });
    for (const o of h.outputs) { const st = o.stats || {}; if (st.fps && st.fps < 24) a.push({ lvl: 'err', msg: `${(o.info && o.info.output) || 'Output'} running at ${st.fps} fps` }); else if (st.fps && st.fps < 50) a.push({ lvl: 'warn', msg: `${(o.info && o.info.output) || 'Output'} below 50 fps (${st.fps})` }); }
    for (const d of h.sources) if (!d.online) a.push({ lvl: 'err', msg: `Drive offline: ${d.name}` });
    if (h.missing.length) a.push({ lvl: 'err', msg: `${h.missing.length} media file(s) missing from the show` });
    if (h.server.temp > 85) a.push({ lvl: 'err', msg: `CPU temperature ${Math.round(h.server.temp)}°C` });
    if (h.server.throttle > 0) a.push({ lvl: 'warn', msg: `CPU thermally throttled ${h.server.throttle}%` });
    if (h.server.mem.free / h.server.mem.total < 0.08) a.push({ lvl: 'warn', msg: 'Server memory almost full' });
    if (h.backup.mode === 'backup' && h.backup.active) a.push({ lvl: 'err', msg: 'Backup has taken over — primary server lost' });
    if (h.backup.mode === 'backup' && !h.backup.connected && !h.backup.active) a.push({ lvl: 'warn', msg: 'Backup not connected to primary' });
    if (h.jobs) a.push({ lvl: 'warn', msg: `${h.jobs} conversion job(s) still running` });
    return a;
  };

  /* ================= SHOW-DAY CHECKLIST ================= */
  let chkHealth = null, testRunning = null;
  UI.panels.check = {
    sig: s => JSON.stringify([s.checklist.items.map(i => [i.id, i.done]), testRunning]),
    render(s) {
      return sec('Automatic checks', `<div class="row wide"><label>Expected outputs</label><div class="ctl"><input type="number" min="0" data-path="checklist.expectedOutputs" style="width:70px"></div></div><div id="autoChecks"><div class="muted">Checking…</div></div>
          <div style="display:flex;gap:6px;margin-top:8px"><button class="btn sm primary" data-x="testSeq">${testRunning ? '■ Stop test sequence' : '▶ Run LED test sequence'}</button><button class="btn sm" data-x="chkRefresh">${I('refresh')}Re-check</button></div>
          <div class="hint">The test sequence shows each test pattern for 4 s on every output (panel numbers → cabling → bars → solid colours → gradients → scan) then returns to the show.</div>`) +
        sec('Your checklist', `${s.checklist.items.map((it, i) => `<div class="chk ${it.done ? 'done' : ''}"><button class="sw ${it.done ? 'on' : ''}" data-path="checklist.items.${i}.done" data-toggle></button><input type="text" data-path="checklist.items.${i}.label"><button class="btn xs danger" data-x="chkDel" data-i="${i}">${I('trash')}</button></div>`).join('')}
          <div style="display:flex;gap:6px;margin-top:6px"><button class="btn sm" data-x="chkAdd">${I('plus')}Add item</button><button class="btn sm" data-x="chkDefaults">Add standard items</button><button class="btn sm" data-x="chkReset">Untick all</button></div>`);
    },
    async after() { try { chkHealth = await UI.api('/api/health'); } catch { return; } const h = chkHealth, s = UI.st(); const box = $('#autoChecks'); if (!box) return;
      const items = [
        [h.outputs.length >= (s.checklist.expectedOutputs || 1), `Outputs connected: ${h.outputs.length} / ${s.checklist.expectedOutputs}`],
        [h.outputs.every(o => !o.stats || o.stats.fps >= 25), 'Outputs rendering smoothly (≥ 25 fps)'],
        [!h.missing.length, h.missing.length ? `${h.missing.length} media file(s) missing — use Relink` : 'All show media present'],
        [h.sources.every(d => d.online), 'All media drives online'],
        [!h.jobs, h.jobs ? `${h.jobs} conversion job(s) running` : 'No conversions pending'],
        [h.backup.mode !== 'backup' ? true : h.backup.connected, h.backup.mode === 'backup' ? 'Backup mirroring primary' : (h.backup.mirrors.length ? 'Backup server in sync' : 'No backup server (optional)')],
        [!s.comp.blackout, s.comp.blackout ? 'Blackout is ON' : 'Blackout off'], [!s.led.test.on, s.led.test.on ? 'Test pattern is ON AIR' : 'Test pattern off'],
        [s.comp.master > 0.05, `Master at ${Math.round(s.comp.master * 100)}%`]];
      box.innerHTML = items.map(([ok, msg]) => `<div class="chkauto ${ok ? 'ok' : 'bad'}">${ok ? '✔' : '✖'} ${esc(msg)}</div>`).join(''); },
  };
  async function runTestSequence() {
    const modes = [['panels', 4], ['chain', 4], ['bars', 4], ['solid', 6], ['gradient', 4], ['scan', 4]]; testRunning = Date.now(); const me = testRunning; UI.renderRight(true);
    for (const [m, sec] of modes) { if (testRunning !== me) return; BVJ.cmd({ op: 'setMany', values: { 'led.test.on': true, 'led.test.mode': m, 'led.test.color': 'cycle' } }); await new Promise(r => setTimeout(r, sec * 1000)); }
    if (testRunning === me) { BVJ.cmd({ op: 'set', path: 'led.test.on', value: false }); testRunning = null; UI.renderRight(true); }
  }

  /* ================= extensions to existing panels ================= */
  const wrap = (name, extra, after) => { const p = UI.panels[name]; const r = p.render.bind(p), sg = p.sig ? p.sig.bind(p) : () => '', af = p.after ? p.after.bind(p) : null, lv = p.live ? p.live.bind(p) : null;
    p.render = s => r(s) + extra.render(s); p.sig = s => sg(s) + (extra.sig ? extra.sig(s) : ''); p.after = (pane, s) => { if (af) af(pane, s); if (after) after(pane, s); };
    if (extra.live) p.live = (pane, s) => { if (lv) lv(pane, s); extra.live(pane, s); }; };

  // Layer: per-screen routing + lock
  wrap('layer', {
    sig: s => { const l = s.layers[UI.sel.layer]; return JSON.stringify([l && l.route, s.led.screens.map(x => x.id), l && l.lockedBy]); },
    render(s) { const li = UI.sel.layer, l = s.layers[li]; if (!l) return ''; const scr = s.led.screens;
      return sec('Screen routing', scr.length ? `<div class="row wide"><label>Mode</label><div class="ctl"><select data-path="layers.${li}.route.mode" data-rerender><option value="all">Whole composition (normal)</option><option value="mask">Only on selected screens (span)</option><option value="each">Each selected screen gets the full clip</option></select></div></div>
        ${l.route.mode !== 'all' ? `<div class="scrchips">${scr.map(x => `<button class="${l.route.screens.includes(x.id) ? 'on' : ''}" data-x="route" data-id="${x.id}" style="--c:${esc(x.color)}">${esc(x.name)}</button>`).join('')}<button data-x="routeAll">All</button></div>` : ''}
        <div class="hint">“Each” fits the clip into every selected LED screen separately — e.g. the same logo on all four sides of a polo screen, sponsors on East/West only — with no big composition to build.</div>` : `<div class="hint">Define LED screens in the LED tab to route this layer to individual screens.</div>`) +
        sec('Operator lock', `<button class="btn sm ${l.lockedBy ? 'on' : ''}" data-x="lock" data-i="${li}">${l.lockedBy ? '🔒 Locked by ' + esc(l.lockedBy) : 'Lock this layer to me'}</button>`); },
  });
  // Clip: frame cache + automation
  wrap('clip', {
    sig: s => { const l = s.layers[UI.sel.layer]; const c = l && UI.sel.slot != null ? l.clips[UI.sel.slot] : null; return JSON.stringify(c ? [c.cache, !!c.auto, c.auto && c.auto.on, UI.autoRecOn] : 0); },
    render(s) { const li = UI.sel.layer, ci = UI.sel.slot, l = s.layers[li]; const c = l && ci != null ? l.clips[ci] : null; if (!c) return ''; const b = `layers.${li}.clips.${ci}`;
      const a = c.auto; const n = a ? Object.keys(a.paths || {}).length : 0;
      return (c.type === 'video' ? sec('Frame cache (smooth reverse / bounce)', `${UI.rToggle('Cache frames in RAM', b + '.cache')}<div class="hint">Keeps decoded frames in GPU-friendly memory after the first forward pass, so reverse speed and bounce loops play perfectly smoothly from any file. Best for loops under ~20 s (uses up to 1.2 GB per output).</div>`) : '') +
        sec('Clip automation', `<div style="display:flex;gap:6px;flex-wrap:wrap"><button class="btn sm ${UI.autoRecOn ? 'testlive' : 'primary'}" data-x="autoRec" data-li="${li}" data-ci="${ci}">${UI.autoRecOn ? '■ Stop recording' : '● Record moves'}</button>${a ? `<button class="btn sm" data-x="autoClear" data-li="${li}" data-ci="${ci}">${I('trash')}Clear</button>` : ''}</div>
          ${a ? `${UI.rToggle('Play automation', b + '.auto.on')}<div class="kv"><span>Recorded</span><b>${n} parameter(s) · ${a.len.toFixed(1)} s loop</b></div><div class="small muted">${Object.keys(a.paths).map(esc).join(', ')}</div>` : ''}
          <div class="hint">Press Record, then move this layer's opacity, transform or effect sliders (with the mouse, MIDI or the remote) while the clip plays. Press Stop: the moves replay every time this clip plays, looping with the recording length.</div>`); },
  });
  // LED: processor, calibration, day/night, templates, 3D
  wrap('led', {
    sig: s => JSON.stringify([s.led.processor, s.led.dayNight.on, s.led.dayNight.points.length, s.led.screens.length]),
    render(s) { const L = s.led; const proc = S.LED_PROCESSORS.find(p => p.id === L.processor);
      let px = 0, ow = 0, oh = 0; for (const x of L.screens) { const w = x.panelW * x.cols, h = x.panelH * x.rows; px += w * h; const [aw, ah] = x.rotation % 180 ? [h, w] : [w, h]; ow = Math.max(ow, x.outX + aw); oh = Math.max(oh, x.outY + ah); }
      let gauge = '';
      if (proc && proc.ports) { const ports = Math.ceil(px / proc.perPort); const load = px / proc.total; const rasterOk = ow <= proc.maxW && oh <= proc.maxH;
        gauge = `<div class="kv"><span>Pixels</span><b>${px.toLocaleString()} of ${proc.total.toLocaleString()}</b></div><div class="meter" style="height:8px"><i style="width:${Math.min(100, load * 100)}%;background:${load > 1 ? 'var(--red)' : load > 0.85 ? 'var(--yellow)' : ''}"></i></div>
          <div class="kv"><span>Ports needed (≈${(proc.perPort / 1000).toFixed(0)}k px each)</span><b style="color:${ports > proc.ports ? 'var(--red)' : ''}">${ports} of ${proc.ports}</b></div>
          <div class="kv"><span>Output raster ${ow}×${oh}</span><b style="color:${rasterOk ? 'var(--green)' : 'var(--red)'}">${rasterOk ? 'within' : 'exceeds'} ${proc.maxW}×${proc.maxH}</b></div>
          ${load > 1 || ports > proc.ports ? `<div class="warnbox">This wall needs more capacity than one ${esc(proc.name)} — add a second processor or reduce the pixel count.</div>` : ''}`; }
      const dn = L.dayNight;
      return sec('LED processor', `${UI.rSelect('Processor', 'led.processor', S.LED_PROCESSORS.map(p => [p.id, p.name]))}${gauge}<div class="hint">${proc && proc.src ? `Figures from ${esc(proc.src)}${proc.note ? ' · ' + esc(proc.note) : ''}. ` : ''}Capacities are at 60 Hz, 8-bit. Port load depends on the receiving-card layout — always confirm with the processor's own software.</div>`) +
        sec('Screen calibration', L.screens.length ? L.screens.map((x, i) => `<div class="card closed" data-card="cal${i}"><header><span class="swatch" style="background:${esc(x.color)}"></span><b>${esc(x.name)}</b><span class="muted small">${Math.round(x.cal.brightness * 100)}%</span><svg class="ico chev"><use href="#i-down"/></svg></header><div class="body">
          ${UI.rRange('Brightness', `led.screens.${i}.cal.brightness`, 0, 1.5, 0.01, 1)}${UI.rRange('Red gain', `led.screens.${i}.cal.r`, 0, 1.5, 0.01, 1)}${UI.rRange('Green gain', `led.screens.${i}.cal.g`, 0, 1.5, 0.01, 1)}${UI.rRange('Blue gain', `led.screens.${i}.cal.b`, 0, 1.5, 0.01, 1)}${UI.rRange('Gamma', `led.screens.${i}.cal.gamma`, 0.5, 2.5, 0.01, 1)}</div></div>`).join('') + `<div class="hint">Match mixed panel batches by eye with the Solid colour test pattern. Applied in the LED Processor output only.</div>` : '<div class="hint">Add screens first.</div>') +
        sec('Day / night brightness', `${UI.rToggle('Automatic', 'led.dayNight.on')}
          ${dn.points.map((pt, i) => `<div class="row wide"><label>Point ${i + 1}</label><div class="ctl"><input type="time" value="${esc(pt[0])}" data-x-dn="${i}:0"><input type="number" min="0" max="1" step="0.05" value="${pt[1]}" data-x-dn="${i}:1" style="width:70px"><button class="btn xs danger" data-x="dnDel" data-i="${i}">${I('trash')}</button></div></div>`).join('')}
          <button class="btn sm" data-x="dnAdd">${I('plus')}Add point</button><div class="kv"><span>Level now</span><b id="dnNow">–</b></div>
          <div class="hint">Brightness follows this curve through the day (interpolated, using the output computer's clock) — e.g. full brightness in daylight, 50% at night. Multiplies the whole output.</div>`) +
        sec('Content templates', `<div style="display:flex;gap:6px;flex-wrap:wrap"><button class="btn sm" data-x="tpl" data-f="png">${I('upload')}PNG</button><button class="btn sm" data-x="tpl" data-f="svg">${I('upload')}SVG</button><button class="btn sm primary" data-x="tpl" data-f="psd">${I('upload')}Photoshop PSD (layers)</button><button class="btn sm" data-x="tpl" data-f="json">${I('upload')}Spec sheet</button></div>
          <div class="hint">Exact-size templates of the composition with every screen, panel grid, panel numbers, pixel sizes and safe areas — send them to content creators. The PSD has one layer per screen plus guides.</div>`) +
        sec('3D stage view', `<button class="btn sm" data-x="go3d">${I('eye')}Open Stage 3D</button><button class="btn sm" data-x="open3d">${I('screen')}Pop-out window</button>`);
    },
    live(pane, s) { const d = $('#dnNow', pane); if (d && s) { const dn = s.led.dayNight; d.textContent = dn.on ? Math.round(dayNight(dn) * 100) + '%' : 'off (100%)'; } },
  });
  function dayNight(dn) { const d = new Date(); const now = d.getHours() * 60 + d.getMinutes(); const pts = dn.points.map(([t, v]) => { const [h, m] = String(t).split(':').map(Number); return [(h || 0) * 60 + (m || 0), +v]; }).sort((a, b) => a[0] - b[0]);
    if (!pts.length) return 1; let prev = pts[pts.length - 1], next = pts[0]; for (let i = 0; i < pts.length; i++) { if (pts[i][0] > now) { next = pts[i]; prev = pts[i - 1] || pts[pts.length - 1]; break; } if (i === pts.length - 1) { prev = pts[i]; next = pts[0]; } }
    const span = ((next[0] - prev[0]) + 1440) % 1440 || 1440; return prev[1] + (next[1] - prev[1]) * ((((now - prev[0]) + 1440) % 1440) / span); }
  // Output: recording + diagnostics
  wrap('output', {
    sig: () => JSON.stringify([UI.rec && UI.rec.on]),
    render() { const r = UI.rec || {};
      return sec('Record output', `<div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap"><select id="recFps"><option value="25">25 fps</option><option value="30" selected>30 fps</option><option value="50">50 fps</option><option value="60">60 fps</option></select>
          <select id="recMbps"><option value="8">8 Mb/s</option><option value="16" selected>16 Mb/s</option><option value="30">30 Mb/s</option><option value="50">50 Mb/s</option></select>
          <select id="recAudio" title="Audio track"><option value="clips" selected>Clip audio</option><option value="clips+input">Clip audio + audio input</option><option value="none">No audio</option></select>
          <button class="btn sm ${r.on ? 'testlive' : 'primary'}" data-x="rec">${r.on ? '■ Stop recording' : '● Record'}</button></div>
        ${r.on ? `<div class="kv"><span>Recording</span><b class="mono">${esc(r.file || '')} · ${Math.round((r.bytes || 0) / 1048576)} MB · ${Math.round((Date.now() - r.since) / 1000)} s</b></div>` : ''}
        <div class="hint">Records the primary output (exactly what the audience sees, after effects and mapping) as MP4/H.264 where supported, otherwise WebM — encoded locally by the output computer's GPU. Files appear in Library ▸ Local Library ▸ Recordings for client previews or re-use as content. Audio: <b>Clip audio</b> records the sound of playing video clips (at their layer/master volume); <b>+ audio input</b> also mixes in the audio device chosen under Mods (e.g. the FOH feed). The output window must have been clicked once so the browser allows audio.</div>`) +
        sec('Diagnostics', `<button class="btn sm" data-x="diag">${I('screen')}Open diagnostics monitor</button><div class="hint">Live view of every incoming OSC, MIDI, Art-Net/sACN, HTTP and data-feed message — the fastest way to check a console or app is really talking to PIXORA.</div>`); },
  });
  // Mods: audio-reactive scenes
  wrap('mods', {
    sig: s => JSON.stringify([s.react.enabled, s.react.onBeat, s.react.onDrop, s.layers.length]),
    render(s) { return sec('Audio-reactive scenes', `${UI.rToggle('Enabled', 'react.enabled')}
        <div class="row wide"><label>On beats</label><div class="ctl"><select data-path="react.onBeat"><option value="off">Do nothing</option><option value="next-clip">Next clip on layer</option><option value="random-clip">Random clip on layer</option><option value="next-column">Next column</option></select></div></div>
        ${UI.rSelect('Layer', 'react.layer', s.layers.map((l, i) => [i, `${i + 1} · ${l.name}`]), true)}${UI.rSelect('Every', 'react.everyBeats', [[1, '1 beat'], [2, '2 beats'], [4, '4 beats (1 bar)'], [8, '2 bars'], [16, '4 bars'], [32, '8 bars']], true)}
        <div class="row wide"><label>On a drop</label><div class="ctl"><select data-path="react.onDrop"><option value="off">Do nothing</option><option value="next-column">Next column</option><option value="random-column">Random column</option><option value="cue-go">Cue GO</option><option value="flash">Strobe for 2 bars</option></select></div></div>
        ${UI.rToggle('Auto BPM from music', 'react.autoBpm')}${UI.rRange('Sensitivity', 'react.sensitivity', 0, 1, 0.01, 0.5)}
        <div class="kv"><span>Bass</span><b style="flex:1;margin-left:10px"><div class="meter"><i data-bass></i></div></b></div>
        <div class="hint">Listens to the audio input of the primary output computer (set in Comp ▸ Audio input). Detects kicks/beats and “drops” (a loud section after a quiet breakdown) and fires clips, columns or cues automatically — hands-free VJ-ing.</div>`); },
    live(pane) { const b = $('[data-bass]', pane); if (b) b.style.width = ((UI.audio && UI.audio.bass) || 0) * 100 + '%'; },
  });

  /* ---------- single delegated handler for all pro actions */
  document.addEventListener('click', async e => {
    const t = e.target.closest('[data-x]'); if (!t || !t.closest('#rpane')) return; const d = t.dataset, x = d.x, s = UI.st();
    const cmd = c => UI.cmd(c);
    switch (x) {
      case 'feedAdd': { const id = await UI.prompt('Feed ID (used in {{id.key}} templates and /api/feed/id)', 'feed' + (s.feeds.length + 1), 'ID'); if (id) cmd({ op: 'feedAdd', feed: { id: id.replace(/[^\w-]/g, ''), name: id } }); break; }
      case 'feedRemove': if (confirm('Remove feed?')) cmd({ op: 'feedRemove', id: d.id }); break;
      case 'ruleAdd': cmd({ op: 'ruleAdd' }); break; case 'ruleRemove': cmd({ op: 'ruleRemove', id: d.id }); break; case 'ruleTest': cmd({ op: 'ruleTest', id: d.id }); break;
      case 'oscAdd': BVJ.cmd({ op: 'set', path: 'oscOut.targets', value: [...s.oscOut.targets, { host: '', port: 8000, on: true }] }); setTimeout(() => UI.renderRight(true), 60); break;
      case 'oscDel': BVJ.cmd({ op: 'set', path: 'oscOut.targets', value: s.oscOut.targets.filter((_, i) => i !== +d.i) }); setTimeout(() => UI.renderRight(true), 60); break;
      case 'rotAdd': cmd({ op: 'rotAdd', item: { clip: UI.selectedClip() } }); break; case 'rotRemove': cmd({ op: 'rotRemove', id: d.id }); break;
      case 'rotPlay': cmd({ op: 'rotPlayNow', id: d.id }); break; case 'rotStop': cmd({ op: 'rotStop' }); break;
      case 'rotClip': { const c = UI.selectedClip(); if (!c) return UI.toast('Select a clip slot first', 'err'); BVJ.cmd({ op: 'set', path: `rotation.items.${d.i}.clip`, value: c }); if (!s.rotation.items[d.i].name || s.rotation.items[d.i].name === 'Sponsor spot') BVJ.cmd({ op: 'set', path: `rotation.items.${d.i}.name`, value: c.name || 'Spot' }); setTimeout(() => UI.renderRight(true), 60); break; }
      case 'popLoad': popFrom = $('#popFrom').value; popTo = $('#popTo').value; UI.panels.sponsors.loadPop(); break;
      case 'popCsv': location.href = `/api/pop.csv?from=${$('#popFrom').value}&to=${$('#popTo').value}`; break;
      case 'popReport': window.open(`/pop-report?from=${$('#popFrom').value}&to=${$('#popTo').value}`, '_blank'); break;
      case 'schedAdd': cmd({ op: 'schedAdd' }); break; case 'schedRemove': cmd({ op: 'schedRemove', id: d.id }); break;
      case 'schedRun': cmd({ op: 'runAction', action: s.schedule[d.i].action }); break;
      case 'schedDay': { const e2 = s.schedule[d.i]; const k = +d.d; const days = e2.days.includes(k) ? e2.days.filter(z => z !== k) : [...e2.days, k].sort(); BVJ.cmd({ op: 'set', path: `schedule.${d.i}.days`, value: days }); t.classList.toggle('on'); break; }
      case 'follow': UI.follow = UI.follow === d.id ? '' : d.id; UI.renderRight(true); UI.renderStatus(); break;
      case 'lock': { const l = s.layers[d.i]; cmd({ op: 'lockLayer', layer: +d.i, on: !l.lockedBy }); break; }
      case 'unlockForce': if (confirm('Force-unlock this layer?')) cmd({ op: 'lockLayer', layer: +d.i, on: false, force: true }); break;
      case 'bkSave': { const b = { mode: $('#bkMode').value, primary: ($('#bkUrl') || {}).value || '', failoverSec: +(($('#bkSec') || {}).value || 3), pin: ($('#bkPin') || {}).value || '' };
        await UI.api('/api/settings', { method: 'POST', body: JSON.stringify({ backup: b }) }); UI.library.settings.backup = b; UI.toast(b.mode === 'backup' ? 'Backup mode on — connecting to primary' : 'This server is primary', 'ok'); UI.renderRight(true); break; }
      case 'bench': { t.textContent = 'Testing…'; try { const r = await UI.api('/api/health/bench?id=' + d.id, { method: 'POST' }); UI.toast(r.mbps ? `${Math.round(r.mbps)} MB/s reading ${r.file}` : 'No video files to test', 'ok'); } catch (er) { UI.toast(er.message, 'err'); } UI.panels.health.load(); break; }
      case 'testSeq': if (testRunning) { testRunning = null; BVJ.cmd({ op: 'set', path: 'led.test.on', value: false }); UI.renderRight(true); } else runTestSequence(); break;
      case 'chkRefresh': UI.renderRight(true); break;
      case 'chkAdd': BVJ.cmd({ op: 'set', path: 'checklist.items', value: [...s.checklist.items, { id: 'c' + Date.now(), label: 'New item', done: false }] }); setTimeout(() => UI.renderRight(true), 60); break;
      case 'chkDel': BVJ.cmd({ op: 'set', path: 'checklist.items', value: s.checklist.items.filter((_, i) => i !== +d.i) }); setTimeout(() => UI.renderRight(true), 60); break;
      case 'chkReset': BVJ.cmd({ op: 'set', path: 'checklist.items', value: s.checklist.items.map(i => Object.assign({}, i, { done: false })) }); setTimeout(() => UI.renderRight(true), 60); break;
      case 'chkDefaults': BVJ.cmd({ op: 'set', path: 'checklist.items', value: [...s.checklist.items, ...['Power & data cables checked', 'LED processor input & mapping confirmed', 'Show file saved & exported', 'Collected show copied to backup SSD', 'Phone remote connected', 'MIDI controllers mapped', 'Sponsor spots approved', 'Audio input level set', 'Blackout & test pattern off'].map((label, k) => ({ id: 'c' + Date.now() + k, label, done: false }))] }); setTimeout(() => UI.renderRight(true), 60); break;
      case 'route': { const l = s.layers[UI.sel.layer]; const ids = l.route.screens.includes(d.id) ? l.route.screens.filter(z => z !== d.id) : [...l.route.screens, d.id]; BVJ.cmd({ op: 'set', path: `layers.${UI.sel.layer}.route.screens`, value: ids }); t.classList.toggle('on'); break; }
      case 'routeAll': BVJ.cmd({ op: 'set', path: `layers.${UI.sel.layer}.route.screens`, value: s.led.screens.map(z => z.id) }); setTimeout(() => UI.renderRight(true), 60); break;
      case 'autoRec': UI.autoRecOn = !UI.autoRecOn; cmd({ op: 'autoRec', layer: +d.li, slot: +d.ci, on: UI.autoRecOn }); UI.renderRight(true); break;
      case 'autoClear': cmd({ op: 'autoClear', layer: +d.li, slot: +d.ci }); break;
      case 'dnAdd': BVJ.cmd({ op: 'set', path: 'led.dayNight.points', value: [...s.led.dayNight.points, ['12:00', 1]] }); setTimeout(() => UI.renderRight(true), 60); break;
      case 'dnDel': BVJ.cmd({ op: 'set', path: 'led.dayNight.points', value: s.led.dayNight.points.filter((_, i) => i !== +d.i) }); setTimeout(() => UI.renderRight(true), 60); break;
      case 'tpl': UI.downloadTemplate(d.f); break;
      case 'go3d': UI.setBtab('stage'); break; case 'open3d': window.open('/stage', 'pixora-stage', 'width=1100,height=700'); break;
      case 'rec': if (UI.rec && UI.rec.on) cmd({ op: 'recStop' }); else cmd({ op: 'recStart', fps: +$('#recFps').value, mbps: +$('#recMbps').value, audio: $('#recAudio').value }); break;
      case 'diag': window.open('/diag', 'pixora-diag', 'width=1100,height=760'); break;
    }
  });
  document.addEventListener('change', e => {
    const dn = e.target.dataset && e.target.dataset.xDn; if (!dn) return; const [i, k] = dn.split(':').map(Number); const pts = UI.st().led.dayNight.points.map(p => p.slice());
    pts[i][k] = k ? +e.target.value : e.target.value; BVJ.cmd({ op: 'set', path: 'led.dayNight.points', value: pts });
  });
  UI.selectedClip = () => { const s = UI.st(); const l = s.layers[UI.sel.layer]; const c = l && UI.sel.slot != null ? l.clips[UI.sel.slot] : null; return c ? JSON.parse(JSON.stringify(c)) : null; };
})();
