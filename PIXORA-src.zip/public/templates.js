/* PIXORA LED content templates: PNG, SVG, layered PSD and a JSON/HTML spec sheet, generated in the browser */
(function () {
  const UI = window.UI;
  const size = x => [x.panelW * x.cols, x.panelH * x.rows];
  function drawScreen(g, x, opts) { // draw one screen (its own region) into a 2D context
    const [w, h] = size(x); const X = opts.local ? 0 : x.x, Y = opts.local ? 0 : x.y; const col = x.color || '#ff2fd0';
    g.fillStyle = col + '33'; g.fillRect(X, Y, w, h);
    for (let r = 0; r < x.rows; r++) for (let c = 0; c < x.cols; c++) { if ((r + c) % 2) { g.fillStyle = col + '22'; g.fillRect(X + c * x.panelW, Y + r * x.panelH, x.panelW, x.panelH); } }
    g.strokeStyle = col; g.lineWidth = 1; g.globalAlpha = 0.8;
    for (let c = 1; c < x.cols; c++) { g.beginPath(); g.moveTo(X + c * x.panelW + 0.5, Y); g.lineTo(X + c * x.panelW + 0.5, Y + h); g.stroke(); }
    for (let r = 1; r < x.rows; r++) { g.beginPath(); g.moveTo(X, Y + r * x.panelH + 0.5); g.lineTo(X + w, Y + r * x.panelH + 0.5); g.stroke(); }
    g.globalAlpha = 1; g.lineWidth = 2; g.strokeRect(X + 1, Y + 1, w - 2, h - 2);
    const inset = Math.round(Math.min(w, h) * 0.05); g.setLineDash([6, 5]); g.strokeStyle = 'rgba(255,255,255,.45)'; g.lineWidth = 1; g.strokeRect(X + inset + 0.5, Y + inset + 0.5, w - inset * 2, h - inset * 2); g.setLineDash([]);
    const fs = Math.max(9, Math.min(x.panelW, x.panelH) * 0.16); g.textAlign = 'center'; g.textBaseline = 'middle';
    for (let r = 0; r < x.rows; r++) for (let c = 0; c < x.cols; c++) { g.fillStyle = 'rgba(255,255,255,.55)'; g.font = `600 ${fs}px Inter, Arial, sans-serif`; g.fillText(`${c + 1},${r + 1}`, X + c * x.panelW + x.panelW / 2, Y + r * x.panelH + x.panelH / 2); }
    const lf = Math.max(11, Math.min(h * 0.08, w / 22)); g.font = `800 ${lf}px Inter, Arial, sans-serif`; g.textAlign = 'left'; g.textBaseline = 'top';
    const label = `${x.name}  ${w}×${h}px  (${x.cols}×${x.rows} @ ${x.panelW}×${x.panelH})`; const tw = g.measureText(label).width;
    g.fillStyle = 'rgba(0,0,0,.7)'; g.fillRect(X + 4, Y + 4, Math.min(w - 8, tw + lf * 0.8), lf * 1.5); g.fillStyle = '#fff'; g.fillText(label, X + 4 + lf * 0.4, Y + 4 + lf * 0.25, w - 8 - lf * 0.8);
  }
  function compCanvas(s, which) { // which: 'all' | 'bg' | screen object
    const W = s.comp.width, H = s.comp.height; const c = document.createElement('canvas'); c.width = W; c.height = H; const g = c.getContext('2d');
    if (which === 'all' || which === 'bg') { g.fillStyle = '#0a0a0e'; g.fillRect(0, 0, W, H); g.strokeStyle = '#1c1c26'; for (let x = 0; x < W; x += 64) { g.beginPath(); g.moveTo(x + .5, 0); g.lineTo(x + .5, H); g.stroke(); } for (let y = 0; y < H; y += 64) { g.beginPath(); g.moveTo(0, y + .5); g.lineTo(W, y + .5); g.stroke(); } }
    if (which === 'all') { for (const x of s.led.screens) drawScreen(g, x, {}); const f = Math.max(10, H / 50); g.font = `600 ${f}px Inter, Arial`; g.fillStyle = 'rgba(255,255,255,.55)'; g.textAlign = 'right'; g.textBaseline = 'bottom'; g.fillText(`${s.comp.name} · ${W}×${H} · PIXORA template`, W - 8, H - 6); }
    return c;
  }
  // ---- minimal layered PSD writer (8-bit RGB, raw channel data)
  function psd(W, H, layers, merged) {
    const chunks = []; let len = 0; const push = a => { chunks.push(a); len += a.length; };
    const u8 = v => push(new Uint8Array([v & 255])), u16 = v => push(new Uint8Array([(v >> 8) & 255, v & 255])), u32 = v => push(new Uint8Array([(v >>> 24) & 255, (v >>> 16) & 255, (v >>> 8) & 255, v & 255]));
    const str = s => push(new TextEncoder().encode(s));
    str('8BPS'); u16(1); push(new Uint8Array(6)); u16(3); u32(H); u32(W); u16(8); u16(3); u32(0); u32(0);
    // layer info block built separately so we know its length
    const li = []; let liLen = 0; const lp = a => { li.push(a); liLen += a.length; };
    const L16 = v => lp(new Uint8Array([(v >> 8) & 255, v & 255])), L32 = v => lp(new Uint8Array([(v >>> 24) & 255, (v >>> 16) & 255, (v >>> 8) & 255, v & 255])), Lstr = s => lp(new TextEncoder().encode(s));
    L16(layers.length);
    for (const l of layers) {
      L32(l.y); L32(l.x); L32(l.y + l.h); L32(l.x + l.w); L16(4);
      for (const id of [65535, 0, 1, 2]) { L16(id); L32(2 + l.w * l.h); }
      Lstr('8BIMnorm'); lp(new Uint8Array([255, 0, 0, 0]));
      const nm = new TextEncoder().encode(l.name.slice(0, 200)); const nlen = Math.ceil((nm.length + 1) / 4) * 4; const name = new Uint8Array(nlen); name[0] = nm.length; name.set(nm, 1);
      L32(8 + nlen); L32(0); L32(0); lp(name);
    }
    for (const l of layers) { const n = l.w * l.h; for (const ch of [3, 0, 1, 2]) { L16(0); const plane = new Uint8Array(n); for (let i = 0; i < n; i++) plane[i] = l.data[i * 4 + ch]; lp(plane); } }
    if (liLen % 2) { lp(new Uint8Array(1)); }
    u32(4 + liLen + 4); u32(liLen); for (const a of li) push(a); u32(0);
    u16(0); const n = W * H; for (const ch of [0, 1, 2]) { const plane = new Uint8Array(n); for (let i = 0; i < n; i++) plane[i] = merged[i * 4 + ch]; push(plane); }
    const out = new Uint8Array(len); let o = 0; for (const a of chunks) { out.set(a, o); o += a.length; } return out;
  }
  function save(blob, name) { const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000); }
  UI.buildTemplate = function (fmt) {
    const s = UI.st(); const W = s.comp.width, H = s.comp.height; const base = (s.comp.name || 'PIXORA') + ` template ${W}x${H}`;
    if (fmt === 'png') return new Promise(r => compCanvas(s, 'all').toBlob(b => r({ blob: b, name: base + '.png' }), 'image/png'));
    if (fmt === 'svg') {
      const e = v => String(v).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
      let sv = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}"><rect width="${W}" height="${H}" fill="#0a0a0e"/>`;
      for (const x of s.led.screens) { const [w, h] = size(x); sv += `<g id="${e(x.name)}"><rect x="${x.x}" y="${x.y}" width="${w}" height="${h}" fill="${e(x.color)}" fill-opacity=".2" stroke="${e(x.color)}" stroke-width="2"/>`;
        for (let c = 1; c < x.cols; c++) sv += `<line x1="${x.x + c * x.panelW}" y1="${x.y}" x2="${x.x + c * x.panelW}" y2="${x.y + h}" stroke="${e(x.color)}" stroke-opacity=".7"/>`;
        for (let r = 1; r < x.rows; r++) sv += `<line x1="${x.x}" y1="${x.y + r * x.panelH}" x2="${x.x + w}" y2="${x.y + r * x.panelH}" stroke="${e(x.color)}" stroke-opacity=".7"/>`;
        sv += `<text x="${x.x + 8}" y="${x.y + 8}" fill="#fff" font-family="Inter,Arial" font-weight="700" font-size="${Math.max(11, Math.min(h * 0.08, w / 22))}" dominant-baseline="hanging">${e(x.name)} ${w}×${h}px</text></g>`; }
      sv += `</svg>`; return Promise.resolve({ blob: new Blob([sv], { type: 'image/svg+xml' }), name: base + '.svg' });
    }
    if (fmt === 'psd') {
      const layers = [{ name: 'Background', x: 0, y: 0, w: W, h: H, data: compCanvas(s, 'bg').getContext('2d').getImageData(0, 0, W, H).data }];
      for (const x of s.led.screens) { const [w, h] = size(x); const c = document.createElement('canvas'); c.width = w; c.height = h; drawScreen(c.getContext('2d'), x, { local: true });
        layers.push({ name: `${x.name} (${w}x${h})`, x: x.x, y: x.y, w, h, data: c.getContext('2d').getImageData(0, 0, w, h).data }); }
      const merged = compCanvas(s, 'all').getContext('2d').getImageData(0, 0, W, H).data;
      return Promise.resolve({ blob: new Blob([psd(W, H, layers, merged)], { type: 'image/vnd.adobe.photoshop' }), name: base + '.psd' });
    }
    if (fmt === 'json') {
      const spec = { composition: { name: s.comp.name, width: W, height: H }, screens: s.led.screens.map(x => { const [w, h] = size(x); return { name: x.name, contentX: x.x, contentY: x.y, width: w, height: h, panels: `${x.cols} x ${x.rows}`, panelPixels: `${x.panelW} x ${x.panelH}`, panelMM: `${x.panelMmW} x ${x.panelMmH}`, pitchMM: x.panelMmW && x.panelW ? +(x.panelMmW / x.panelW).toFixed(2) : null, physicalM: `${(x.panelMmW * x.cols / 1000).toFixed(2)} x ${(x.panelMmH * x.rows / 1000).toFixed(2)}` }; }),
        notes: 'Deliver content at exactly the composition size. Keep important content inside the dashed safe area (5% inset) of each screen. Recommended codec: H.264 MP4, 25/30/50/60 fps.' };
      return Promise.resolve({ blob: new Blob([JSON.stringify(spec, null, 2)], { type: 'application/json' }), name: base + ' spec.json' });
    }
  };
  UI.downloadTemplate = async fmt => { if (!UI.st().led.screens.length) return UI.toast('Add LED screens first', 'err'); const r = await UI.buildTemplate(fmt); save(r.blob, r.name); UI.toast('Template downloaded: ' + r.name, 'ok'); };
})();

/* ---------- Titles & Logos bottom panel: template gallery, logo animations, saved presets */
(function () {
  const UI = window.UI, S = window.SCHEMA, esc = UI.esc, I = UI.icon;
  const TITLE_TPLS = ['Lower third', 'Full-screen title', 'Countdown', 'Clock', 'Ticker bar', 'Corner bug', 'Scoreboard', 'Captions'];
  const LOGO_ANIMS = ['Reveal', 'Pulse (beat)', 'Float', 'Glitch (beat)', 'Spin', 'Bounce around', 'Neon glow', 'Zoom in'];
  const titleClip = i => { const p = S.genDefaults('title'); p.tpl = i; if (i === 2) { p.line1 = 'SHOW STARTS IN'; p.line2 = ''; } if (i === 3) { p.line1 = 'LOCAL TIME'; p.line2 = ''; } if (i === 4) { p.line1 = 'Welcome to the show — follow @boothproductions'; p.line2 = 'LIVE'; } if (i === 5) { p.line1 = 'LIVE'; p.pos = 5; p.size = 0.7; }
    return { type: 'gen', name: TITLE_TPLS[i], gen: { kind: 'title', params: p } }; };
  const logoClip = (i, src) => { const p = S.genDefaults('logo'); p.anim = i; p.src = src || ''; return { type: 'gen', name: 'Logo · ' + LOGO_ANIMS[i], gen: { kind: 'logo', params: p } }; };
  const ico = ['▭', '▣', '⏱', '🕘', '☰', '◤'];
  UI.bpanels.titles = {
    sig: s => JSON.stringify([s.genPresets.map(p => p.id), UI.libVersion, UI.titleLogo || '']),
    render(s) {
      const imgs = []; for (const so of UI.library.sources || []) for (const it of so.items) if (it.kind === 'image') imgs.push(it);
      const logo = UI.titleLogo || (imgs[0] && imgs[0].src) || '';
      return `<div class="libmain"><div class="sec"><h4>Title designer — drag onto a slot, then edit text, colours, position and animation in the Clip tab</h4>
        <div class="cards" style="--card-w:160px">${TITLE_TPLS.map((n, i) => `<div class="gtile" draggable="true" data-tclip='${esc(JSON.stringify(titleClip(i)))}'><div class="gi ttl-prev ttl-${i}"><span>${ico[i]}</span></div><b>${n}</b><span>${['Name / role strap', 'Big centred title', 'Counts down to a time', 'Live clock', 'Scrolling news bar', 'Small corner label'][i]}</span></div>`).join('')}</div></div>
        <div class="sec"><h4>Logo animator</h4><div class="row wide" style="max-width:520px"><label>Logo image</label><div class="ctl"><select id="logoSrc">${imgs.map(it => `<option value="${esc(it.src)}" ${it.src === logo ? 'selected' : ''}>${esc(it.name)}</option>`).join('') || '<option value="">Add a PNG logo to the library first</option>'}</select></div></div>
        <div class="cards" style="--card-w:150px">${LOGO_ANIMS.map((n, i) => `<div class="gtile" draggable="true" data-tclip='${esc(JSON.stringify(logoClip(i, logo)))}'><div class="gi" style="background:#07070b url('${logo ? BVJ.mediaUrl(logo) : ''}') center/contain no-repeat"></div><b>${n}</b><span>${['Wipe-on reveal, repeats', 'Pumps on every beat', 'Gentle hover', 'Glitch hits on beats', 'Coin spin', 'DVD-style bounce', 'Flickering neon glow', 'Zooms in on trigger'][i]}</span></div>`).join('')}</div>
        <div class="hint">Transparent PNG logos work best (e.g. Velvet Sonic, flamingo, Booth Productions). Logos render at the composition — or each routed LED screen's — exact resolution.</div></div>
        <div class="sec"><h4>Saved presets</h4><button class="btn sm" id="gpSave">${I('save')}Save selected clip as preset</button>
        <div class="cards" style="--card-w:150px;margin-top:8px">${s.genPresets.map(p => `<div class="gtile" draggable="true" data-tclip='${esc(JSON.stringify(p.clip))}'><b>${esc(p.name)}</b><span>${esc(p.clip.gen ? p.clip.gen.kind : p.clip.type)}</span><button class="btn xs danger" data-gpdel="${p.id}">${I('trash')}</button></div>`).join('') || '<span class="muted small">None yet — style a title or logo clip, select it, then save it here to reuse.</span>'}</div></div></div>`;
    },
    after(pane) {
      pane.ondragstart = e => { const t = e.target.closest('[data-tclip]'); if (t) e.dataTransfer.setData('bvj/clip', t.dataset.tclip); };
      pane.ondblclick = e => { const t = e.target.closest('[data-tclip]'); if (!t) return; const s = UI.st(); const l = s.layers[UI.sel.layer]; const slot = UI.sel.slot ?? Math.max(0, l.clips.findIndex(c => !c));
        UI.cmd({ op: 'assign', layer: UI.sel.layer, slot, clip: JSON.parse(t.dataset.tclip) }); UI.cmd({ op: 'trigger', layer: UI.sel.layer, clip: slot }); UI.select(UI.sel.layer, slot); };
      pane.onclick = e => { const d = e.target.closest('[data-gpdel]'); if (d) UI.cmd({ op: 'genPresetRemove', id: d.dataset.gpdel }); };
      const ls = document.getElementById('logoSrc'); if (ls) ls.onchange = () => { UI.titleLogo = ls.value; UI.renderBottom(true); };
      const gs = document.getElementById('gpSave'); if (gs) gs.onclick = async () => { const c = UI.selectedClip(); if (!c) return UI.toast('Select a clip slot first', 'err'); const n = await UI.prompt('Preset name', c.name); if (n) UI.cmd({ op: 'genPresetSave', name: n, clip: c }); };
    },
  };
})();
