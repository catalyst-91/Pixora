/* PIXORA controller core: helpers, top bar, deck grid, tabs framework, sockets, shortcuts. */
(function () {
  const S = window.SCHEMA;
  const UI = window.UI = { sel: { layer: 0, slot: null }, rtab: localStorage.bvjRtab || 'clip', btab: localStorage.bvjBtab || 'files',
    library: { sources: [], ffmpeg: false, settings: {} }, libIndex: new Map(), jobs: [], ffmpeg: false, outputs: [], comps: [], positions: [], audio: null,
    shaderErrors: {}, tc: null, panels: {}, bpanels: {}, thumbV: Date.now(), outFps: 0 };
  const $ = UI.$ = (s, r) => (r || document).querySelector(s);
  const $$ = UI.$$ = (s, r) => [...(r || document).querySelectorAll(s)];
  const esc = UI.esc = BVJ.esc;
  UI.icon = (n, c) => `<svg class="ico ${c || ''}"><use href="#i-${n}"/></svg>`;
  UI.el = html => { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; };
  UI.toast = (msg, kind) => { const t = UI.el(`<div class="toast ${kind || ''}">${esc(msg)}</div>`); $('#toast').appendChild(t); setTimeout(() => t.remove(), kind === 'err' ? 6000 : 2600); };
  UI.st = () => BVJ.state;
  UI.cmd = c => BVJ.cmd(c);
  const fmt = UI.fmt = (v, step) => { v = +v; if (!isFinite(v)) return ''; const d = step >= 1 ? 0 : step >= 0.1 ? 1 : step >= 0.01 ? 2 : 3; return v.toFixed(d); };
  UI.api = BVJ.api;

  /* ---------------- modal + menu */
  UI.modal = function (title, body, buttons, opts) {
    const bg = UI.el(`<div class="modal-bg"><div class="modal" style="${opts && opts.width ? 'width:' + opts.width : ''}"><header>${esc(title)}<button class="btn sm icon x">${UI.icon('x')}</button></header><div class="mbody"></div><footer></footer></div></div>`);
    const mb = $('.mbody', bg); if (typeof body === 'string') mb.innerHTML = body; else mb.appendChild(body);
    const close = () => bg.remove();
    $('.x', bg).onclick = close; bg.addEventListener('mousedown', e => { if (e.target === bg) close(); });
    for (const b of buttons || [{ label: 'Close' }]) { const btn = UI.el(`<button class="btn ${b.cls || ''}">${b.label}</button>`); btn.onclick = async () => { if (b.click) { const r = await b.click(bg); if (r === false) return; } close(); }; $('footer', bg).appendChild(btn); }
    document.body.appendChild(bg); const f = $('input,textarea', mb); if (f) setTimeout(() => f.focus(), 30);
    bg.close = close; return bg;
  };
  UI.prompt = (title, value, label) => new Promise(res => {
    const m = UI.modal(title, `<div class="row wide"><label>${esc(label || 'Name')}</label><input type="text" id="pv" value="${esc(value || '')}"></div>`,
      [{ label: 'Cancel', click: () => res(null) }, { label: 'OK', cls: 'primary', click: bg => res($('#pv', bg).value) }]);
    $('#pv', m).addEventListener('keydown', e => { if (e.key === 'Enter') { res(e.target.value); m.close(); } });
  });
  UI.menu = function (x, y, items) {
    $$('.menu').forEach(m => m.remove());
    const m = UI.el('<div class="menu"></div>');
    for (const it of items) {
      if (it === '-') { m.appendChild(UI.el('<hr>')); continue; }
      const mi = UI.el(`<div class="mi">${it.icon ? UI.icon(it.icon) : ''}<span>${esc(it.label)}</span>${it.k ? `<span class="k">${esc(it.k)}</span>` : ''}</div>`);
      mi.onclick = () => { m.remove(); it.click(); }; m.appendChild(mi);
    }
    document.body.appendChild(m);
    const r = m.getBoundingClientRect(); m.style.left = Math.min(x, innerWidth - r.width - 6) + 'px'; m.style.top = Math.min(y, innerHeight - r.height - 6) + 'px';
    setTimeout(() => document.addEventListener('mousedown', function h(e) { if (!m.contains(e.target)) { m.remove(); document.removeEventListener('mousedown', h); } }), 0);
  };

  /* ---------------- control builders (HTML strings bound by data-path) */
  const learnAttr = (path, min, max) => `data-learn='${JSON.stringify({ type: 'set', path, min, max }).replace(/'/g, '&#39;')}'`;
  UI.rRange = (label, path, min, max, step, def, cls) =>
    `<div class="row"><label title="${esc(label)}">${esc(label)}</label><input type="range" class="${cls || ''}" data-path="${path}" min="${min}" max="${max}" step="${step}" data-def="${def ?? ''}" ${learnAttr(path, min, max)}><input class="val" data-val="${path}" data-step="${step}"></div>`;
  UI.rColor = (label, path) => `<div class="row wide"><label>${esc(label)}</label><div class="ctl"><input type="color" data-path="${path}"></div></div>`;
  UI.rSelect = (label, path, opts, num) => `<div class="row wide"><label>${esc(label)}</label><div class="ctl"><select data-path="${path}" ${num ? 'data-num' : ''}>${opts.map(o => { const [v, l] = Array.isArray(o) ? o : [o, o]; return `<option value="${esc(v)}">${esc(l)}</option>`; }).join('')}</select></div></div>`;
  UI.rToggle = (label, path) => `<div class="row wide"><label>${esc(label)}</label><div class="ctl"><button class="sw" data-path="${path}" data-toggle></button></div></div>`;
  UI.rText = (label, path, ph) => `<div class="row wide"><label>${esc(label)}</label><div class="ctl"><input type="text" data-path="${path}" placeholder="${esc(ph || '')}"></div></div>`;
  UI.rNum = (label, path, step, min, max) => `<div class="row wide"><label>${esc(label)}</label><div class="ctl"><input type="number" data-path="${path}" step="${step || 1}" ${min != null ? `min="${min}"` : ''} ${max != null ? `max="${max}"` : ''} style="width:100px"></div></div>`;
  UI.param = (base, p) => { // schema param -> control
    const path = base + '.' + p.k;
    if (p.type === 'color') return UI.rColor(p.label, path);
    if (p.type === 'select') return UI.rSelect(p.label, path, p.options.map((o, i) => [i, o]), true);
    if (p.type === 'text') return UI.rText(p.label, path);
    if (p.type === 'shader') return UI.rSelect(p.label, path, (UI.st().shaders || []).map(s => [s.id, s.name]));
    if (p.type === 'image') { const imgs = []; for (const so of UI.library.sources || []) for (const it of so.items) if (it.kind === 'image') imgs.push([it.src, it.name]); return UI.rSelect(p.label, path, [['', '— choose a PNG logo —'], ...imgs]); }
    return UI.rRange(p.label, path, p.min, p.max, p.step, p.def);
  };
  UI.fxStack = function (base, fx, opts) {
    const on = S.FX.filter(f => fx[f.id] && fx[f.id].on), off = S.FX.filter(f => !(fx[f.id] && fx[f.id].on));
    const open = UI.fxOpen || (UI.fxOpen = {});
    let h = `<div class="row wide" style="margin-bottom:6px"><label>Add effect</label><div class="ctl"><select data-addfx="${base}"><option value="">＋ Choose effect…</option>${off.map(f => `<option value="${f.id}">${f.name}</option>`).join('')}</select>
      <button class="btn sm" data-resetfx="${base}" title="Remove all effects">${UI.icon('trash')}</button></div></div>`;
    if (!on.length) h += `<div class="hint">No effects active. Effects run in a fixed, GPU-optimised order: colour → geometry → stylise → strobe.</div>`;
    for (const f of on) {
      const k = base + '.' + f.id; const closed = open[k] === false;
      h += `<div class="card ${closed ? 'closed' : ''}" data-card="${k}"><header><button class="sw on" data-path="${k}.on" data-toggle></button><b>${f.name}</b>
        <button class="btn xs" data-fxreset="${k}" title="Reset values">Reset</button><svg class="ico chev"><use href="#i-down"/></svg></header><div class="body">${f.params.map(p => UI.param(k, p)).join('')}</div></div>`;
    }
    return h;
  };

  /* ---------------- value syncing */
  let dragging = null;
  function setRangeFill(r) { const mn = +r.min, mx = +r.max; r.style.setProperty('--p', ((r.value - mn) / (mx - mn || 1) * 100) + '%'); }
  UI.setRangeFill = setRangeFill;
  UI.sync = function (root) {
    const s = UI.st(); if (!s) return;
    for (const e of $$('[data-path]', root)) {
      if (e === dragging || (e === document.activeElement && e.type !== 'range' && !e.dataset.toggle)) continue;
      const v = BVJ.get(e.dataset.path); if (v === undefined) continue;
      if (e.dataset.toggle != null) e.classList.toggle('on', !!v);
      else if (e.type === 'range') { if (+e.value !== +v) e.value = v; setRangeFill(e); }
      else if (e.type === 'checkbox') e.checked = !!v;
      else if (e.type === 'color') { if (e.value !== v) e.value = v; }
      else if (String(e.value) !== String(v)) e.value = v;
    }
    for (const e of $$('[data-val]', root)) { if (e === document.activeElement) continue; const v = BVJ.get(e.dataset.val); if (v !== undefined) e.value = fmt(v, +e.dataset.step || 0.01); }
  };
  document.addEventListener('pointerdown', e => { if (e.target.type === 'range') dragging = e.target; });
  document.addEventListener('pointerup', () => { dragging = null; });
  document.addEventListener('input', e => {
    const t = e.target; const p = t.dataset && t.dataset.path; if (!p) return;
    if (t.type === 'range') { BVJ.set(p, +t.value); setRangeFill(t); const vb = t.parentElement && t.parentElement.querySelector(`[data-val="${p}"]`); if (vb) vb.value = fmt(t.value, +t.step); }
    else if (t.type === 'color') BVJ.set(p, t.value);
  });
  document.addEventListener('change', e => {
    const t = e.target;
    if (t.dataset.val) { const v = parseFloat(t.value); if (isFinite(v)) { BVJ.set(t.dataset.val, v); UI.sync(t.parentElement); } return; }
    if (t.dataset.addfx) { if (t.value) { BVJ.set(`${t.dataset.addfx}.${t.value}.on`, true); UI.renderRight(true); } return; }
    const p = t.dataset.path; if (!p) return;
    if (t.tagName === 'SELECT') BVJ.set(p, t.dataset.num != null ? +t.value : t.value);
    else if (t.type === 'number') BVJ.set(p, +t.value);
    else if (t.type === 'text' || t.tagName === 'TEXTAREA') BVJ.set(p, t.value);
    else if (t.type === 'checkbox') BVJ.set(p, t.checked);
    if (t.dataset.rerender != null) setTimeout(() => UI.renderRight(true), 50);
  });
  document.addEventListener('click', e => {
    const sw = e.target.closest('[data-toggle]'); if (sw && sw.dataset.path) { e.stopPropagation(); const v = !BVJ.get(sw.dataset.path); BVJ.set(sw.dataset.path, v); sw.classList.toggle('on', v); if (sw.closest('.card') && !v) setTimeout(() => UI.renderRight(true), 30); return; }
    const card = e.target.closest('.card>header'); if (card && !e.target.closest('button')) { const c = card.parentElement; c.classList.toggle('closed'); (UI.fxOpen || (UI.fxOpen = {}))[c.dataset.card] = !c.classList.contains('closed'); return; }
    const fr = e.target.closest('[data-fxreset]'); if (fr) { const [tgt, , id] = splitFx(fr.dataset.fxreset); resetFx(tgt, id); return; }
    const ra = e.target.closest('[data-resetfx]'); if (ra) { const base = ra.dataset.resetfx; resetFx(base, null); return; }
    const seg = e.target.closest('.seg button[data-path]'); if (seg) { const v = seg.dataset.num != null ? +seg.dataset.v : seg.dataset.v; BVJ.set(seg.dataset.path, v); $$('button', seg.parentElement).forEach(b => b.classList.toggle('on', b === seg)); }
  });
  document.addEventListener('dblclick', e => { const t = e.target; if (t.type === 'range' && t.dataset.def !== '' && t.dataset.path) { t.value = t.dataset.def; BVJ.set(t.dataset.path, +t.dataset.def); setRangeFill(t); } });
  function splitFx(k) { const parts = k.split('.'); const id = parts.pop(); parts.pop(); return [parts.join('.') + '.fx', 'fx', id]; }
  function resetFx(base, id) { // base like layers.0.fx / comp.fx / layers.0.clips.2.fx
    const defs = S.fxDefaults();
    if (id) { BVJ.cmd({ op: 'set', path: base + '.' + id, value: Object.assign(defs[id], { on: true }) }); }
    else BVJ.cmd({ op: 'set', path: base, value: defs });
    setTimeout(() => UI.renderRight(true), 60);
  }
  UI.seg = (path, opts, num) => `<div class="seg">${opts.map(([v, l]) => `<button data-path="${path}" data-v="${esc(v)}" ${num ? 'data-num' : ''} class="${String(BVJ.get(path)) === String(v) ? 'on' : ''}">${esc(l)}</button>`).join('')}</div>`;

  /* ---------------- top bar */
  function renderTop() {
    const s = UI.st(); if (!s) return;
    $('#compName').textContent = s.comp.name + ' · ' + s.comp.width + '×' + s.comp.height;
    const bpm = $('#bpm'); if (document.activeElement !== bpm) bpm.value = s.comp.bpm.toFixed(1);
    $('#blackout').classList.toggle('on', !!s.comp.blackout); $('#testBtn').classList.toggle('testlive', !!s.led.test.on);
    $('#masterOut').textContent = Math.round(s.comp.master * 100) + '%';
    $('#speedOut').textContent = s.comp.speed.toFixed(2) + 'x';
    const dk = $('#decks'); const sig = JSON.stringify([s.decks.map(d => d.name), s.comp.deck]);
    if (dk.dataset.sig !== sig) {
      dk.dataset.sig = sig; dk.innerHTML = s.decks.map((d, i) => `<div class="deck ${i === s.comp.deck ? 'on' : ''}" data-deck="${i}" data-learn='{"type":"cmd","cmd":{"op":"deckSwitch","deck":${i}}}'>${esc(d.name)}</div>`).join('');
    }
    const q = s.cues[s.cueIndex]; $('#cueName').textContent = q ? `${s.cueIndex + 1}. ${q.name}` : '—';
  }
  $('#decks').addEventListener('click', e => { const d = e.target.closest('[data-deck]'); if (d && !document.body.classList.contains('learn')) UI.cmd({ op: 'deckSwitch', deck: +d.dataset.deck }); });
  $('#decks').addEventListener('contextmenu', e => {
    const d = e.target.closest('[data-deck]'); if (!d) return; e.preventDefault(); const i = +d.dataset.deck;
    UI.menu(e.clientX, e.clientY, [
      { label: 'Rename deck…', icon: 'wand', click: async () => { const n = await UI.prompt('Rename deck', UI.st().decks[i].name); if (n) UI.cmd({ op: 'deckRename', deck: i, name: n }); } },
      { label: 'Delete deck', icon: 'trash', click: () => { if (confirm('Delete this deck and its clips?')) UI.cmd({ op: 'deckDelete', deck: i }); } }]);
  });
  $('#addDeck').onclick = () => UI.cmd({ op: 'deckAdd' });
  $('#bpm').addEventListener('change', e => { const v = parseFloat(e.target.value); if (v > 0) UI.cmd({ op: 'bpm', bpm: v }); });
  $('#bpm').addEventListener('keydown', e => { if (e.key === 'Enter') e.target.blur(); });
  $('#tapBtn').onclick = () => { if (!document.body.classList.contains('learn')) BVJ.tap(); };
  $('#resyncBtn').onclick = () => { if (!document.body.classList.contains('learn')) UI.cmd({ op: 'resync' }); };
  $('#blackout').onclick = () => { if (!document.body.classList.contains('learn')) UI.cmd({ op: 'blackout' }); };
  $('#undoBtn').onclick = () => UI.cmd({ op: 'undo' }); $('#redoBtn').onclick = () => UI.cmd({ op: 'redo' });
  $('#addLayer').onclick = () => UI.cmd({ op: 'addLayer' });
  $('#testBtn').onclick = e => { if (!document.body.classList.contains('learn')) { if (e.shiftKey || !UI.st().led.screens.length && !UI.st().led.test.on) UI.setRtab('led'); BVJ.cmd({ op: 'set', path: 'led.test.on', value: !UI.st().led.test.on }); } };
  $('#clearAll').onclick = () => UI.cmd({ op: 'clearAll' });
  $('#cueGo').onclick = () => { if (!document.body.classList.contains('learn')) UI.cmd({ op: 'cueGo' }); };
  $('#cueBack').onclick = () => { if (!document.body.classList.contains('learn')) UI.cmd({ op: 'cueBack' }); };
  $('#layoutSel').innerHTML = `<option value="">Apply layout…</option>` + S.LAYOUTS.map(([v, l]) => `<option value="${v}">${l}</option>`).join('');
  $('#layoutSel').onchange = e => { if (e.target.value) UI.cmd({ op: 'layout', preset: e.target.value }); e.target.value = ''; };
  $('#zoom').addEventListener('input', e => { const w = +e.target.value; document.documentElement.style.setProperty('--slot-w', w + 'px'); document.documentElement.style.setProperty('--slot-h', Math.round(w * 0.625) + 'px'); localStorage.bvjZoom = w; });
  if (localStorage.bvjZoom) { $('#zoom').value = localStorage.bvjZoom; $('#zoom').dispatchEvent(new Event('input')); }
  $('#outBtn').onclick = e => {
    const s = UI.st(); const items = (s ? s.outputs : []).map(o => ({ label: `Open "${o.name}" output`, icon: 'screen', click: () => window.open('/output?out=' + encodeURIComponent(o.id), 'bvj-out-' + o.id, 'width=960,height=600') }));
    items.push('-', { label: 'Open clean feed (for OBS / NDI capture)', icon: 'eye', click: () => window.open('/clean?out=main', 'bvj-clean', 'width=960,height=540') },
      { label: 'Identify all outputs', icon: 'eye', click: () => UI.cmd({ op: 'identify' }) }, { label: 'Reload all outputs', icon: 'refresh', click: () => UI.cmd({ op: 'reloadOutputs' }) });
    const r = e.currentTarget.getBoundingClientRect(); UI.menu(r.left, r.bottom + 4, items);
  };
  $('#manualBtn').onclick = () => window.open('/manual/', 'bvj-manual');
  $('#remoteBtn').onclick = async () => {
    const info = await UI.api('/api/info').catch(() => ({ addresses: [], port: location.port }));
    const port = location.port ? ':' + location.port : '';
    const urls = (info.addresses || []).map(a => `http://${a}${port}`);
    UI.modal('Remote control', `<p class="muted">Open one of these on any phone, tablet or laptop on the same network:</p>
      ${urls.map(u => `<div class="kv"><span>Phone remote</span><b class="mono">${u}/remote</b></div><div class="kv"><span>Full controller</span><b class="mono">${u}/</b></div><div class="kv"><span>Output window</span><b class="mono">${u}/output</b></div><hr style="border-color:#262830">`).join('') || '<p>No LAN address found.</p>'}
      <p class="hint">OSC input: UDP port ${info.osc || 7000} (Resolume-style addresses). HTTP API: <span class="mono">/api/status</span>, <span class="mono">/api/trigger/&lt;layer&gt;/&lt;clip&gt;</span> — see the manual for Stream Deck / Companion set-up.</p>`);
  };

  /* ---------------- composition menu */
  $('#menuBtn').onclick = e => {
    const r = e.currentTarget.getBoundingClientRect();
    UI.menu(r.left, r.bottom + 4, [
      { label: 'New composition', icon: 'plus', click: () => { if (confirm('Start a new empty composition? (Save first if needed)')) UI.cmd({ op: 'newComp' }); } },
      { label: 'Save', icon: 'save', k: 'Ctrl+S', click: () => UI.saveComp() },
      { label: 'Save as…', icon: 'save', click: () => UI.saveComp(true) },
      { label: 'Open…', icon: 'folder', click: () => { UI.setBtab('shows'); } },
      '-',
      { label: 'Export show file (.pixora)…', icon: 'upload', click: () => { location.href = '/api/show/export?name=' + encodeURIComponent(UI.st().comp.name); } },
      { label: 'Import show file…', icon: 'folder', click: () => $('#showIn').click() },
      { label: 'Collect show for offline use…', icon: 'drive', click: () => UI.collectShow() },
      { label: 'Relink missing media', icon: 'link', click: () => UI.relink() },
      '-',
      { label: 'Composition settings', icon: 'wand', click: () => UI.setRtab('comp') },
      { label: 'User manual', icon: 'book', click: () => window.open('/manual/', 'bvj-manual') },
    ]);
  };
  UI.saveComp = async (asNew) => {
    let name = UI.st().comp.name; if (asNew || name === 'Untitled Composition') { name = await UI.prompt('Save composition', name); if (!name) return; }
    UI.cmd({ op: 'saveComp', name }); UI.toast('Saved "' + name + '"', 'ok');
  };
  $('#showIn').addEventListener('change', async e => {
    const f = e.target.files[0]; if (!f) return; e.target.value = '';
    try { const r = await UI.api('/api/show/import', { method: 'POST', body: await f.text(), headers: { 'Content-Type': 'application/json' } });
      UI.toast(`Show loaded · ${r.relinked.length} relinked · ${r.missing.length} missing`, r.missing.length ? 'err' : 'ok');
      if (r.missing.length) UI.modal('Missing media', `<p>These files could not be found in any library source. Add the drive/folder that holds them in <b>Sources</b>, then use <b>Relink missing media</b>.</p><div class="flist">${r.missing.map(m => `<div class="mono small">${esc(m)}</div>`).join('')}</div>`);
    } catch (err) { UI.toast(err.message, 'err'); }
  });
  UI.relink = async () => { try { const r = await UI.api('/api/show/relink', { method: 'POST' }); UI.toast(`${r.relinked.length} relinked · ${r.missing.length} still missing`, r.missing.length ? 'err' : 'ok'); } catch (e) { UI.toast(e.message, 'err'); } };
  UI.collectShow = () => {
    const s = UI.st();
    const m = UI.modal('Collect show for offline use', `<p class="muted">Copies every media file used in this show (plus any converted copies) and a <b>.pixora</b> file into one folder — e.g. on an external SSD. Plug that drive into any PIXORA machine, add it as a source, import the show file and it plays fully offline.</p>
      <div class="row wide"><label>Show name</label><input type="text" id="cn" value="${esc(s.comp.name)}"></div>
      <div class="row wide"><label>Destination</label><div class="ctl"><input type="text" id="cd" placeholder="Leave blank for the app's data/shows folder"><button class="btn sm" id="cb">${UI.icon('folder')}Browse</button></div></div>`,
      [{ label: 'Cancel' }, { label: 'Collect', cls: 'primary', click: async bg => { try { const r = await UI.api('/api/show/collect', { method: 'POST', body: JSON.stringify({ name: $('#cn', bg).value, dest: $('#cd', bg).value }) }); UI.toast('Collecting to ' + r.dest, 'ok'); UI.setBtab('shows'); } catch (e) { UI.toast(e.message, 'err'); return false; } } }]);
    $('#cb', m).onclick = () => UI.browseFolder('Choose destination folder', p => { $('#cd', m).value = p; });
  };
  UI.browseFolder = async function (title, onPick) {
    const drives = await UI.api('/api/drives').catch(() => ({ drives: [] }));
    const body = UI.el(`<div><div class="hint">Drives and mount points detected on the computer running PIXORA:</div><div id="dr" style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px"></div>
      <div class="row wide"><label>Folder</label><div class="ctl"><input type="text" id="bp"><button class="btn sm" id="bgo">Go</button><button class="btn sm icon" id="bup" title="Up">${UI.icon('up')}</button></div></div>
      <div class="flist" id="bl"></div><div class="hint" id="bmeta"></div></div>`);
    $('#dr', body).innerHTML = drives.drives.map(d => `<button class="btn sm" data-p="${esc(d.path)}">${UI.icon('drive')}${esc(d.label)}</button>`).join('') || '<span class="muted">None found</span>';
    let cur = null, parent = null;
    async function go(p) {
      try { const r = await UI.api('/api/browse?path=' + encodeURIComponent(p || '')); cur = r.path; parent = r.parent; $('#bp', body).value = r.path;
        $('#bl', body).innerHTML = r.dirs.map(d => `<div data-d="${esc(d)}">${UI.icon('folder')}${esc(d)}</div>`).join('') || '<div class="muted">No sub-folders</div>';
        $('#bmeta', body).textContent = r.media + ' media file(s) directly in this folder';
      } catch (e) { UI.toast(e.message, 'err'); }
    }
    body.addEventListener('click', e => { const b = e.target.closest('[data-p]'); if (b) go(b.dataset.p); const d = e.target.closest('[data-d]'); if (d) go(cur + (cur.endsWith('/') || cur.endsWith('\\') ? '' : drives.sep || '/') + d.dataset.d); });
    $('#bgo', body).onclick = () => go($('#bp', body).value); $('#bup', body).onclick = () => parent && go(parent);
    UI.modal(title, body, [{ label: 'Cancel' }, { label: 'Use this folder', cls: 'primary', click: () => { if (cur) onPick(cur); } }], { width: '620px' });
    go(drives.drives[0] ? drives.drives[0].path : '');
  };

  /* ---------------- deck grid */
  let gridSig = '';
  UI.clipIcon = c => c.type === 'web' ? 'globe' : c.type === 'capture' ? 'cam' : c.type === 'screen' ? 'screen' : c.type === 'gen' && c.gen && c.gen.kind === 'shader' ? 'code' : 'wand';
  UI.genBg = c => { const p = (c.gen && c.gen.params) || {}; const k = c.gen && c.gen.kind;
    if (k === 'solid' || k === 'beatflash') return p.c1; if (k === 'checker') return `repeating-conic-gradient(${p.c1} 0 25%,${p.c2} 0 50%) 0 0/16px 16px`;
    if (k === 'bars') return `repeating-linear-gradient(90deg,${p.c1} 0 6px,transparent 6px 16px),#000`; if (k === 'rings') return `repeating-radial-gradient(${p.c1} 0 3px,#000 3px 9px)`;
    if (k === 'testgrid') return 'linear-gradient(90deg,#fff,#ff0,#0ff,#0f0,#f0f,#f00,#00f)'; if (k === 'text') return '#111';
    if (k === 'shader') return 'radial-gradient(circle,#2a1550,#05030a)';
    return `linear-gradient(135deg,${p.c1 || '#333'},${p.c2 || '#111'})`; };
  function slotHtml(l, li, c, ci) {
    const s = UI.st(); const active = l.active === ci; const sel = UI.sel.layer === li && UI.sel.slot === ci;
    const learn = `data-learn='{"type":"trigger","layer":${li},"clip":${ci}}'`;
    if (!c) return `<div class="slot ${sel ? 'selc' : ''}" data-l="${li}" data-c="${ci}" ${learn}><div class="empty">${UI.icon('plus')}</div></div>`;
    let inner = '', badge = '';
    if (c.type === 'video' || c.type === 'image') {
      const it = UI.libIndex.get(c.src);
      const th = c.type === 'image' ? BVJ.mediaUrl(c.src) : (it && it.thumb ? BVJ.thumbUrl(c.src, UI.thumbV) : '');
      inner = th ? `<div class="th" style="background-image:url('${th}')"></div>` : `<div class="gen">${UI.icon('play')}</div>`;
      if (UI.library.sources.length && !it) badge = `<span class="badge err">missing</span>`;
      else if (it && it.converting) badge = `<span class="badge warn">converting</span>`;
      else if (it && !it.playable) badge = `<span class="badge warn">convert</span>`;
      else if (c.type === 'image') badge = `<span class="badge">img</span>`;
    } else {
      inner = `<div class="th" style="background:${UI.genBg(c)}"></div><div class="gen" style="color:#fff">${UI.icon(UI.clipIcon(c))}</div>`;
      badge = `<span class="badge">${c.type === 'gen' ? (c.gen.kind === 'shader' ? 'glsl' : 'gen') : c.type === 'capture' ? 'live' : c.type}</span>`;
    }
    const fx = c.fx && Object.values(c.fx).some(f => f.on) ? `<span class="fxb">FX</span>` : '';
    return `<div class="slot has ${active ? 'active' : ''} ${sel ? 'selc' : ''}" draggable="true" data-l="${li}" data-c="${ci}" ${learn}>${inner}${badge}${fx}<div class="play"><svg><use href="#i-play"/></svg></div><div class="nm">${esc(BVJ.clipLabel(c))}</div><div class="prog"></div></div>`;
  }
  UI.renderGrid = function (force) {
    const s = UI.st(); if (!s) return;
    const sig = JSON.stringify([s.comp.columns, s.comp.deck, s.layers.map(l => [l.id, l.name, l.active, l.bypass, l.solo, l.xfade, l.blend, l.autopilot,
      Object.keys(l.fx).filter(k => l.fx[k].on).length, l.mask && l.mask.type, l.lockedBy, l.rotating, l.route && [l.route.mode, l.route.screens.length], l.clips.map(c => c ? [c.type, c.src, c.name, c.gen && c.gen.kind, c.gen && c.gen.params && c.gen.params.c1, c.url, c.fx && Object.values(c.fx).some(f => f.on)] : 0)]),
      UI.sel, UI.thumbV, UI.libVersion]);
    if (!force && sig === gridSig) return; gridSig = sig;
    const cols = s.comp.columns; let h = `<div class="grow ghead"><div class="corner"><span class="tlabel">Layers</span><span class="spacer"></span><span class="tlabel">${s.layers.length}×${cols}</span></div>`;
    for (let c = 0; c < cols; c++) { const any = s.layers.some(l => l.active === c); h += `<div class="colhead ${any ? 'active' : ''}" data-col="${c}" data-learn='{"type":"column","col":${c}}' title="Trigger column ${c + 1}">${UI.icon('play', 'fill')}${c + 1}</div>`; }
    h += `<div class="addcol"><button class="btn sm icon" data-act="addcol" title="Add column">${UI.icon('plus')}</button></div></div>`;
    for (let li = s.layers.length - 1; li >= 0; li--) {
      const l = s.layers[li]; const fxn = Object.keys(l.fx).filter(k => l.fx[k].on).length;
      const xf = l.xfade === 'A' ? 'on a' : l.xfade === 'B' ? 'on bb' : '';
      h += `<div class="grow lrow ${UI.sel.layer === li ? 'sel' : ''}" data-row="${li}"><div class="lhead" data-lh="${li}">
        <div class="lt"><span class="lnum">${li + 1}</span><span class="ln" title="Double-click to rename">${esc(l.name)}</span>
          <button class="lb b ${l.bypass ? 'on' : ''}" data-act="bypass" title="Bypass (hide layer)">B</button>
          <button class="lb s ${l.solo ? 'on' : ''}" data-act="solo" title="Solo">S</button>
          <button class="lb ${xf}" data-act="xfade" title="Crossfader assignment">${l.xfade === 'none' ? '–' : l.xfade}</button>
          <button class="lb" data-act="clear" title="Clear layer" data-learn='{"type":"cmd","cmd":{"op":"clearLayer","layer":${li}}}'>✕</button></div>
        <div class="lo"><input type="range" class="live" min="0" max="1" step="0.001" data-path="layers.${li}.opacity" data-def="1" ${learnAttr(`layers.${li}.opacity`, 0, 1)}><output data-pct="layers.${li}.opacity"></output></div>
        <div class="lmeta">${l.lockedBy ? `<span style="color:var(--yellow)">🔒 ${esc(l.lockedBy)}</span>` : ''}${l.rotating ? `<span style="color:#ffd23f">★ ${esc(l.rotating)}</span>` : ''}${l.route && l.route.mode !== 'all' && l.route.screens.length ? `<span style="color:var(--live)">⧉ ${l.route.mode === 'each' ? 'each' : 'on'} ${l.route.screens.length} scr</span>` : ''}<span>${esc(l.blend)}</span>${fxn ? `<span class="fxdot">● ${fxn} fx</span>` : ''}${l.autopilot !== 'off' ? `<span>auto:${l.autopilot}</span>` : ''}${l.mask && l.mask.type !== 'none' ? `<span>mask</span>` : ''}</div></div>`;
      for (let c = 0; c < cols; c++) h += slotHtml(l, li, l.clips[c], c);
      h += `</div>`;
    }
    $('#grid').innerHTML = h; UI.sync($('#grid')); updatePct(); UI.markLearned();
  };
  function updatePct() { for (const o of $$('[data-pct]')) { const v = BVJ.get(o.dataset.pct); if (v != null) o.textContent = Math.round(v * 100); } }
  UI.updateProgress = function () {
    const s = UI.st(); if (!s) return;
    s.layers.forEach((l, li) => { const p = UI.positions[li]; const e = $(`.slot.active[data-l="${li}"] .prog`); if (e) e.style.width = p ? (Math.max(0, Math.min(1, p.pos)) * 100) + '%' : '0'; });
  };
  const grid = $('#grid');
  grid.addEventListener('click', e => {
    if (document.body.classList.contains('learn')) return;
    const s = UI.st(); const act = e.target.closest('[data-act]');
    if (act) {
      const li = +act.closest('[data-lh]')?.dataset.lh; const l = s.layers[li]; e.stopPropagation();
      if (act.dataset.act === 'addcol') return UI.cmd({ op: 'setColumns', n: s.comp.columns + 1 });
      if (act.dataset.act === 'bypass') return BVJ.cmd({ op: 'set', path: `layers.${li}.bypass`, value: !l.bypass });
      if (act.dataset.act === 'solo') return BVJ.cmd({ op: 'set', path: `layers.${li}.solo`, value: !l.solo });
      if (act.dataset.act === 'xfade') return BVJ.cmd({ op: 'set', path: `layers.${li}.xfade`, value: l.xfade === 'none' ? 'A' : l.xfade === 'A' ? 'B' : 'none' });
      if (act.dataset.act === 'clear') return UI.cmd({ op: 'clearLayer', layer: li });
    }
    const col = e.target.closest('[data-col]'); if (col) return UI.cmd({ op: 'column', col: +col.dataset.col });
    const lh = e.target.closest('[data-lh]'); if (lh && !e.target.closest('input')) { UI.select(+lh.dataset.lh, null); if (UI.rtab === 'clip') UI.setRtab('layer'); return; }
    const sl = e.target.closest('.slot'); if (!sl) return;
    const li = +sl.dataset.l, ci = +sl.dataset.c; const has = s.layers[li].clips[ci];
    if (has && !e.shiftKey) UI.cmd({ op: 'trigger', layer: li, clip: ci });
    UI.select(li, ci); if (UI.rtab !== 'clip' && has) UI.setRtab('clip');
  });
  grid.addEventListener('dblclick', async e => {
    const ln = e.target.closest('.ln'); if (ln) { const li = +ln.closest('[data-lh]').dataset.lh; const n = await UI.prompt('Rename layer', UI.st().layers[li].name); if (n) BVJ.cmd({ op: 'set', path: `layers.${li}.name`, value: n }); }
  });
  grid.addEventListener('input', () => updatePct());
  grid.addEventListener('contextmenu', e => {
    const sl = e.target.closest('.slot'); const lh = e.target.closest('[data-lh]'); const s = UI.st();
    if (sl) {
      e.preventDefault(); const li = +sl.dataset.l, ci = +sl.dataset.c; const c = s.layers[li].clips[ci]; UI.select(li, ci);
      const items = c ? [
        { label: 'Trigger', icon: 'play', click: () => UI.cmd({ op: 'trigger', layer: li, clip: ci }) },
        { label: 'Rename…', icon: 'wand', click: async () => { const n = await UI.prompt('Rename clip', c.name); if (n != null) BVJ.cmd({ op: 'set', path: `layers.${li}.clips.${ci}.name`, value: n }); } },
        { label: 'Duplicate to next empty slot', icon: 'copy', click: () => { const to = s.layers[li].clips.findIndex((x, i) => !x && i > ci); if (to >= 0) UI.cmd({ op: 'moveClip', from: [li, ci], to: [li, to], copy: true }); else UI.toast('No empty slot to the right'); } },
        { label: c.fx ? 'Remove clip effects' : 'Add clip effects', icon: 'wand', click: () => { UI.cmd({ op: 'clipFx', layer: li, slot: ci, on: !c.fx }); UI.setRtab('clip'); } },
        ...(c.src && UI.libIndex.get(c.src) && !UI.libIndex.get(c.src).native ? [{ label: 'Convert for playback (ffmpeg)', icon: 'refresh', click: () => UI.convert(c.src) }] : []),
        '-', { label: 'Clear slot', icon: 'trash', k: 'Del', click: () => UI.cmd({ op: 'removeClip', layer: li, slot: ci }) }]
        : [{ label: 'Add solid colour', icon: 'wand', click: () => UI.assignGen(li, ci, 'solid') }, { label: 'Add text', icon: 'wand', click: () => UI.assignGen(li, ci, 'text') },
          { label: 'Add web page…', icon: 'globe', click: () => UI.assignWeb(li, ci) }, { label: 'Add screen / tab capture', icon: 'screen', click: () => UI.cmd({ op: 'assign', layer: li, slot: ci, clip: { type: 'screen', name: 'Screen capture', fit: 'fit' } }) }];
      UI.menu(e.clientX, e.clientY, items);
    } else if (lh) {
      e.preventDefault(); const li = +lh.dataset.lh;
      UI.menu(e.clientX, e.clientY, [
        { label: 'Move layer up', icon: 'up', click: () => UI.cmd({ op: 'moveLayer', layer: li, dir: 1 }) },
        { label: 'Move layer down', icon: 'down', click: () => UI.cmd({ op: 'moveLayer', layer: li, dir: -1 }) },
        { label: 'Duplicate layer', icon: 'copy', click: () => UI.cmd({ op: 'duplicateLayer', layer: li }) },
        { label: 'Rename…', icon: 'wand', click: async () => { const n = await UI.prompt('Rename layer', s.layers[li].name); if (n) BVJ.cmd({ op: 'set', path: `layers.${li}.name`, value: n }); } },
        '-', { label: 'Delete layer', icon: 'trash', click: () => { if (confirm('Delete ' + s.layers[li].name + '?')) UI.cmd({ op: 'removeLayer', layer: li }); } }]);
    }
  });
  // drag & drop into slots
  grid.addEventListener('dragstart', e => { const sl = e.target.closest('.slot.has'); if (!sl) return; e.dataTransfer.setData('bvj/slot', JSON.stringify([+sl.dataset.l, +sl.dataset.c])); e.dataTransfer.effectAllowed = 'copyMove'; });
  grid.addEventListener('dragover', e => { const sl = e.target.closest('.slot'); if (!sl) return; e.preventDefault(); $$('.slot.drop').forEach(x => x !== sl && x.classList.remove('drop')); sl.classList.add('drop'); e.dataTransfer.dropEffect = e.altKey ? 'copy' : 'move'; });
  grid.addEventListener('dragleave', e => { const sl = e.target.closest('.slot'); if (sl && !sl.contains(e.relatedTarget)) sl.classList.remove('drop'); });
  grid.addEventListener('drop', async e => {
    const sl = e.target.closest('.slot'); if (!sl) return; e.preventDefault(); sl.classList.remove('drop');
    const li = +sl.dataset.l, ci = +sl.dataset.c; const dt = e.dataTransfer;
    if (dt.getData('bvj/slot')) { const [fl, fc] = JSON.parse(dt.getData('bvj/slot')); if (fl !== li || fc !== ci) UI.cmd({ op: 'moveClip', from: [fl, fc], to: [li, ci], copy: e.altKey }); return; }
    if (dt.getData('bvj/media')) { const items = JSON.parse(dt.getData('bvj/media')); if (items.length > 1) UI.cmd({ op: 'fillLayer', layer: li, start: ci, items: items.map(UI.mediaClip) }); else UI.cmd({ op: 'assign', layer: li, slot: ci, clip: UI.mediaClip(items[0]) }); UI.select(li, ci); return; }
    if (dt.getData('bvj/clip')) { UI.cmd({ op: 'assign', layer: li, slot: ci, clip: JSON.parse(dt.getData('bvj/clip')) }); UI.select(li, ci); return; }
    if (dt.files && dt.files.length) { const res = await UI.uploadFiles([...dt.files]); if (res.length) UI.cmd({ op: 'fillLayer', layer: li, start: ci, items: res.map(r => UI.mediaClip({ src: r.src, name: r.name, kind: r.kind })) }); }
  });
  UI.mediaClip = it => ({ type: it.kind === 'image' ? 'image' : 'video', src: it.src, name: (it.name || '').replace(/\.[^.]+$/, ''), size: it.size || 0 });
  UI.assignGen = (li, ci, kind) => { const g = S.GENERATORS.find(x => x.id === kind); UI.cmd({ op: 'assign', layer: li, slot: ci, clip: { type: 'gen', name: g.name, gen: { kind, params: S.genDefaults(kind) } } }); UI.select(li, ci); };
  UI.assignWeb = async (li, ci) => { const url = await UI.prompt('Web page URL', 'https://', 'URL'); if (url) { UI.cmd({ op: 'assign', layer: li, slot: ci, clip: { type: 'web', name: url.replace(/^https?:\/\//, '').slice(0, 40), url } }); UI.select(li, ci); } };
  UI.select = function (li, ci) { UI.sel = { layer: li, slot: ci }; UI.renderGrid(); UI.renderRight(true); UI.sendPresence(); };
  UI.me = { name: localStorage.pxName || ('Operator ' + Math.random().toString(36).slice(2, 5).toUpperCase()), color: localStorage.pxColor || '#9b3bff' };
  localStorage.pxName = UI.me.name; UI.presence = []; UI.follow = '';
  UI.sendPresence = () => { if (BVJ.connected) BVJ.raw({ t: 'presence', sel: UI.sel, tab: UI.rtab }); };
  UI.setMe = (name, color) => { UI.me = { name: name || UI.me.name, color: color || UI.me.color }; localStorage.pxName = UI.me.name; localStorage.pxColor = UI.me.color; BVJ.raw({ t: 'whoami', name: UI.me.name, color: UI.me.color }); };
  UI.convert = async src => { try { await UI.api('/api/convert?src=' + encodeURIComponent(src), { method: 'POST' }); UI.toast('Queued for conversion', 'ok'); } catch (e) { UI.toast(e.message, 'err'); } };
  UI.uploadFiles = async function (files, folder) {
    const out = [];
    for (const f of files) {
      UI.toast('Uploading ' + f.name + '…');
      try { const r = await UI.api('/api/upload?name=' + encodeURIComponent(f.name) + (folder ? '&folder=' + encodeURIComponent(folder) : ''), { method: 'PUT', body: f }); out.push({ src: r.src, name: f.name, kind: /^image\//.test(f.type) ? 'image' : 'video' }); }
      catch (e) { UI.toast(f.name + ': ' + e.message, 'err'); }
    }
    UI.loadLibrary(); return out;
  };

  /* ---------------- right tabs */
  const RTABS = [['clip', 'Clip'], ['layer', 'Layer'], ['comp', 'Comp'], ['led', 'LED'], ['output', 'Output'], ['cues', 'Cues']];
  const MORETABS = [['mods', 'Mods & Audio-reactive', 'wand', 'Mods'], ['data', 'Data Feeds & Rules', 'link', 'Data'], ['sponsors', 'Sponsors & Proof of Play', 'rec', 'Sponsors'], ['schedule', 'Scheduler', 'restart', 'Schedule'],
    ['dmx', 'DMX / Art-Net / Pixels', 'drive', 'DMX'], ['midi', 'MIDI Controllers', 'midi', 'MIDI'], ['tc', 'Timecode', 'restart', 'Timecode'], ['team', 'Team, Locks & Backup', 'eye', 'Team'], ['health', 'Health Dashboard', 'screen', 'Health'], ['check', 'Show-day Checklist', 'save', 'Checklist'], ['log', 'Change Log', 'book', 'Log']];
  UI.MORETABS = MORETABS;
  function renderTabs() {
    const more = MORETABS.find(t => t[0] === UI.rtab);
    $('#rtabs').innerHTML = RTABS.map(([k, l]) => `<div class="tab" data-rt="${k}">${l}</div>`).join('') + (more ? `<div class="tab on" data-rt="${more[0]}">${more[3]}</div>` : '') + `<div class="tab more" data-more>More ▾</div>`;
  }
  renderTabs();
  $('#rtabs').addEventListener('click', e => {
    if (e.target.closest('[data-more]')) { const r = e.target.closest('[data-more]').getBoundingClientRect(); UI.menu(r.left - 120, r.bottom + 4, MORETABS.map(([k, l, ic]) => ({ label: l, icon: ic, click: () => UI.setRtab(k) }))); return; }
    const t = e.target.closest('[data-rt]'); if (t) UI.setRtab(t.dataset.rt); });
  UI.setRtab = k => { UI.rtab = k; localStorage.bvjRtab = k; renderTabs(); UI.renderRight(true); UI.sendPresence(); };
  let rightSig = '';
  UI.renderRight = function (force) {
    const s = UI.st(); if (!s) return;
    $$('#rtabs .tab').forEach(t => t.classList.toggle('on', t.dataset.rt === UI.rtab));
    const p = UI.panels[UI.rtab]; if (!p) return;
    const sig = UI.rtab + JSON.stringify(UI.sel) + (p.sig ? p.sig(s) : '');
    if (force || sig !== rightSig) { rightSig = sig; const pane = $('#rpane'); const sc = pane.scrollTop; pane.innerHTML = p.render(s); UI.sync(pane); if (p.after) p.after(pane, s); pane.scrollTop = sc; UI.markLearned(); }
    else { UI.sync($('#rpane')); if (p.live) p.live($('#rpane'), s); }
  };

  /* ---------------- bottom tabs */
  const BTABS = [['files', 'Files'], ['sources', 'Sources & Drives'], ['gens', 'Generators'], ['titles', 'Titles & Logos'], ['inputs', 'Inputs & Web'], ['shaders', 'Shaders'], ['looks', 'Looks'], ['timeline', 'Timeline'], ['stage', 'Stage 3D'], ['shows', 'Shows & Jobs']];
  $('#btabs').innerHTML = BTABS.map(([k, l]) => `<div class="tab" data-bt="${k}">${l}</div>`).join('');
  $('#btabs').addEventListener('click', e => { const t = e.target.closest('[data-bt]'); if (t) UI.setBtab(t.dataset.bt); });
  UI.setBtab = k => { UI.btab = k; localStorage.bvjBtab = k; UI.renderBottom(true); };
  let botSig = '';
  UI.renderBottom = function (force) {
    const s = UI.st(); if (!s) return; $$('#btabs .tab').forEach(t => t.classList.toggle('on', t.dataset.bt === UI.btab));
    const p = UI.bpanels[UI.btab]; if (!p) return; const sig = UI.btab + (p.sig ? p.sig(s) : '');
    if (force || sig !== botSig) { botSig = sig; const pane = $('#bpane'); const keep = $('.libmain', pane); const sc = keep ? keep.scrollTop : 0; pane.innerHTML = p.render(s); $('#btools').innerHTML = p.tools ? p.tools(s) : ''; UI.sync(pane); UI.sync($('#btools')); if (p.after) p.after(pane, s); const nm = $('.libmain', pane); if (nm) nm.scrollTop = sc; }
  };
  // bottom panel resize
  (() => { const sp = $('#split'); let y0, h0; const saved = +localStorage.bvjBottomH; if (saved) document.documentElement.style.setProperty('--bottom-h', saved + 'px');
    sp.addEventListener('pointerdown', e => { y0 = e.clientY; h0 = $('#bottom').getBoundingClientRect().height; sp.setPointerCapture(e.pointerId); });
    sp.addEventListener('pointermove', e => { if (y0 == null) return; const h = Math.max(120, Math.min(innerHeight - 260, h0 + (y0 - e.clientY))); document.documentElement.style.setProperty('--bottom-h', h + 'px'); localStorage.bvjBottomH = h; });
    sp.addEventListener('pointerup', () => { y0 = null; }); })();

  /* ---------------- library loading + browser-side thumbnails (decoded locally) */
  UI.libVersion = 0;
  UI.loadLibrary = async function (refresh) {
    try {
      const r = await UI.api('/api/library' + (refresh ? '?refresh=1' : ''));
      UI.library = r; UI.ffmpeg = r.ffmpeg; UI.libIndex = new Map(); for (const s of r.sources) for (const it of s.items) UI.libIndex.set(it.src, it);
      UI.libVersion++; UI.renderBottom(true); UI.renderGrid(); queueThumbs(); renderStatus();
    } catch (e) { console.warn(e); }
  };
  const thumbQ = []; let thumbBusy = 0; const thumbTried = new Set();
  function queueThumbs() { for (const s of UI.library.sources) for (const it of s.items) if (it.kind === 'video' && it.playable && !it.thumb && !thumbTried.has(it.src)) { thumbTried.add(it.src); thumbQ.push(it); } pumpThumbs(); }
  function pumpThumbs() {
    while (thumbBusy < 2 && thumbQ.length) {
      const it = thumbQ.shift(); thumbBusy++;
      makeThumb(it).catch(() => {}).finally(() => { thumbBusy--; if (!thumbQ.length) { UI.thumbV = Date.now(); UI.loadLibrary(); } pumpThumbs(); });
    }
  }
  function makeThumb(it) {
    return new Promise((ok, bad) => {
      const v = document.createElement('video'); v.muted = true; v.preload = 'auto'; v.src = BVJ.mediaUrl(it.src);
      const to = setTimeout(() => { v.src = ''; bad(); }, 15000);
      v.onloadedmetadata = () => { v.currentTime = Math.min(2, (v.duration || 1) * 0.15); };
      v.onseeked = () => {
        const c = document.createElement('canvas'); const w = 320, h = Math.round(w * (v.videoHeight || 9) / (v.videoWidth || 16)); c.width = w; c.height = h;
        c.getContext('2d').drawImage(v, 0, 0, w, h);
        c.toBlob(b => { clearTimeout(to); fetch(`/api/thumb?src=${encodeURIComponent(it.src)}&duration=${v.duration || 0}&w=${v.videoWidth}&h=${v.videoHeight}`, { method: 'POST', body: b }).then(ok, bad); v.removeAttribute('src'); v.load(); }, 'image/jpeg', 0.78);
      };
      v.onerror = () => { clearTimeout(to); bad(); };
    });
  }

  /* ---------------- status bar */
  function renderStatus() {
    $('#stConn').innerHTML = BVJ.connected ? '<span style="color:var(--green)">●</span> Connected' : '<span style="color:var(--red)">●</span> Offline — reconnecting';
    const outs = UI.outputs.length; $('#stOut').textContent = `${outs} output${outs === 1 ? '' : 's'}${UI.outFps ? ' · ' + UI.outFps + ' fps' : ''}`;
    $('#stFF').textContent = UI.ffmpeg ? 'ffmpeg ready' : 'ffmpeg not found'; $('#stFF').style.color = UI.ffmpeg ? '' : 'var(--yellow)';
    const run = UI.jobs.filter(j => j.status === 'running' || j.status === 'queued');
    $('#stJobs').textContent = run.length ? `${run.length} job(s): ${run[0].name} ${Math.round((run[0].progress || 0) * 100)}%` : '';
    $('#stTc').textContent = UI.tc ? 'TC ' + UI.fmtTc(UI.tc.frames, UI.tc.fps) : '';
    $('#stLearn').textContent = document.body.classList.contains('learn') ? 'MIDI LEARN — click a control, then move a MIDI control (Esc to exit)' : '';
    const ops = (UI.presence || []).filter(p => p.role === 'control'); const b = UI.backup;
    $('#stTeam').innerHTML = (ops.length > 1 ? `<span title="${esc(ops.map(o => o.name).join(', '))}">👥 ${ops.length} operators</span>` : '') + (UI.follow ? ' · following ' + esc((UI.presence.find(p => p.id === UI.follow) || {}).name || '') : '')
      + (b && b.mode === 'backup' ? ` · <span style="color:${b.active ? 'var(--red)' : b.connected ? 'var(--green)' : 'var(--yellow)'}">BACKUP ${b.active ? 'ACTIVE (primary lost)' : b.connected ? 'mirroring' : 'connecting'}</span>` : b && b.mirrors && b.mirrors.length ? ` · <span style="color:var(--green)">backup in sync</span>` : '')
      + (UI.rec && UI.rec.on ? ` · <span style="color:var(--red)">● REC ${Math.round((UI.rec.bytes || 0) / 1048576)} MB</span>` : '');
  }
  UI.renderStatus = renderStatus;
  UI.fmtTc = (fr, fps) => { fps = fps || 25; fr = Math.max(0, fr | 0); const f = fr % fps, s = Math.floor(fr / fps); return [Math.floor(s / 3600), Math.floor(s / 60) % 60, s % 60, f].map(x => String(x).padStart(2, '0')).join(':'); };

  /* ---------------- MIDI learn integration */
  UI.markLearned = function () {
    if (!window.BVJMidi) return; const keys = new Map(BVJMidi.bindings.map(b => [JSON.stringify(b.action), b.key]));
    $$('.learnbadge').forEach(b => b.remove());
    if (!document.body.classList.contains('learn')) return;
    for (const e of $$('[data-learn]')) { const k = keys.get(JSON.stringify(JSON.parse(e.dataset.learn))); if (k) { const b = UI.el(`<span class="learnbadge">${k.replace(/^n:\d+:/, 'N').replace(/^c:\d+:/, 'CC')}</span>`); if (getComputedStyle(e).position === 'static') e.style.position = 'relative'; e.appendChild(b); } }
  };
  $('#learnBtn').onclick = async () => {
    if (!BVJMidi.ok) await BVJMidi.init();
    if (!BVJMidi.ok) return UI.toast(BVJMidi.error || 'MIDI unavailable', 'err');
    const on = !document.body.classList.contains('learn'); document.body.classList.toggle('learn', on); BVJMidi.learn = on; BVJMidi.learnTarget = null;
    $('#learnBtn').classList.toggle('on', on); UI.markLearned(); renderStatus();
  };
  document.addEventListener('pointerdown', e => {
    if (!document.body.classList.contains('learn')) return;
    const t = e.target.closest('[data-learn]'); if (!t) return; e.preventDefault(); e.stopPropagation();
    $$('.learn-target').forEach(x => x.classList.remove('learn-target')); t.classList.add('learn-target');
    BVJMidi.learnTarget = { action: JSON.parse(t.dataset.learn), label: t.title || t.textContent.trim().slice(0, 30) };
  }, true);
  BVJMidi.onLearned = (key) => { UI.toast('Mapped ' + key, 'ok'); $$('.learn-target').forEach(x => x.classList.remove('learn-target')); UI.markLearned(); if (UI.rtab === 'midi') UI.renderRight(true); };
  BVJMidi.onChange = (what) => { if (what === 'tc') { UI.tc = { frames: BVJMidi.tc.frames, fps: BVJMidi.tc.fps }; } if (UI.rtab === 'midi' || UI.rtab === 'tc') UI.panels[UI.rtab].live ? UI.panels[UI.rtab].live($('#rpane'), UI.st()) : 0; if (!what) UI.renderRight(true); };
  if (localStorage.bvjMidiAuto === '1') BVJMidi.init();

  /* ---------------- keyboard */
  addEventListener('keydown', e => {
    const tag = (e.target.tagName || '').toLowerCase(); const typing = tag === 'input' && e.target.type !== 'range' || tag === 'textarea' || tag === 'select';
    if (e.key === 'Escape') { if (document.body.classList.contains('learn')) $('#learnBtn').click(); $$('.menu').forEach(m => m.remove()); return; }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); UI.cmd({ op: e.shiftKey ? 'redo' : 'undo' }); return; }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') { e.preventDefault(); UI.cmd({ op: 'redo' }); return; }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); UI.saveComp(); return; }
    if (typing) return;
    if (e.key === ' ') { e.preventDefault(); UI.cmd({ op: 'cueGo' }); }
    else if (/^[1-9]$/.test(e.key) && !e.ctrlKey) UI.cmd({ op: 'column', col: +e.key - 1 });
    else if (e.key.toLowerCase() === 't') BVJ.tap();
    else if (e.key === 'Delete' || e.key === 'Backspace') { if (UI.sel.slot != null) UI.cmd({ op: 'removeClip', layer: UI.sel.layer, slot: UI.sel.slot }); }
    else if (e.key.toLowerCase() === 'b' && e.shiftKey) UI.cmd({ op: 'blackout' });
    else if (e.key === 'ArrowUp' && e.altKey) UI.select(Math.min(UI.st().layers.length - 1, UI.sel.layer + 1), UI.sel.slot);
    else if (e.key === 'ArrowDown' && e.altKey) UI.select(Math.max(0, UI.sel.layer - 1), UI.sel.slot);
  });

  /* ---------------- beat indicator */
  function beatLoop() { requestAnimationFrame(beatLoop); const s = UI.st(); if (!s) return; const b = Math.floor(BVJ.beat(s.comp)); const ph = BVJ.beat(s.comp) % 1;
    $$('#beats i').forEach((d, i) => d.classList.toggle('on', ((b % 4) + 4) % 4 === i && ph < 0.5)); }
  requestAnimationFrame(beatLoop);

  /* ---------------- socket */
  let prevUrl = null, lastRender = 0, pendingRender = false;
  function renderAll() {
    pendingRender = false; lastRender = performance.now();
    const s = UI.st(); if (!s) return;
    if (UI.sel.layer >= s.layers.length) UI.sel = { layer: s.layers.length - 1, slot: null };
    renderTop(); UI.renderGrid(); UI.sync($('#top')); UI.sync($('#btools')); UI.sync($('#monitor')); UI.sync($('#grid')); updatePct(); UI.renderRight(); UI.renderBottom();
    if (window.BVJMidi) BVJMidi.refreshLeds();
  }
  window.addEventListener('load', () => {
    BVJ.connect('control', {
      state: () => { if (!pendingRender) { pendingRender = true; const wait = Math.max(0, 40 - (performance.now() - lastRender)); setTimeout(renderAll, wait); } },
      connection: ok => { $('#conn').classList.toggle('ok', ok); renderStatus(); if (ok) { BVJ.raw({ t: 'preview', on: true }); BVJ.raw({ t: 'whoami', name: UI.me.name, color: UI.me.color }); UI.sendPresence(); UI.loadLibrary(); } },
      presence: m => { UI.presence = m.list; if (UI.follow) { const f = m.list.find(x => x.id === UI.follow); if (f && f.sel && (JSON.stringify(f.sel) !== JSON.stringify(UI.sel) || f.tab !== UI.rtab)) { UI.sel = f.sel; if (f.tab && f.tab !== UI.rtab) { UI.rtab = f.tab; renderTabs(); } UI.renderGrid(); UI.renderRight(true); } } if (UI.rtab === 'team') UI.renderRight(true); renderStatus(); },
      hello: m => { UI.myId = m.id; UI.viewer = m.viewer; },
      feeds: () => { if (UI.rtab === 'data') UI.panels.data.live($('#rpane'), UI.st()); },
      backup: m => { UI.backup = m.status; renderStatus(); if (UI.rtab === 'team' || UI.rtab === 'health') UI.renderRight(true); },
      recstate: m => { UI.rec = m.rec; renderStatus(); if (UI.rtab === 'output') UI.renderRight(true); },
      binary: buf => { const url = URL.createObjectURL(new Blob([buf], { type: 'image/jpeg' })); $('#prev').src = url; $('#monPh').style.display = 'none'; if (prevUrl) URL.revokeObjectURL(prevUrl); prevUrl = url; },
      pos: m => { UI.positions = m.layers || []; UI.outFps = m.fps; UI.audio = m.audio; UI.shaderErrors = m.shaderErrors || {}; UI.updateProgress(); const p = UI.panels[UI.rtab]; if (p && p.live) p.live($('#rpane'), UI.st()); },
      outputs: m => { UI.outputs = m.outputs; renderStatus(); const s = UI.st(); if (s) $('#monRes').textContent = s.comp.width + '×' + s.comp.height; if (!m.outputs.length) { $('#monPh').style.display = ''; $('#prev').removeAttribute('src'); } if (UI.rtab === 'output' || UI.btab === 'inputs') { UI.renderRight(true); UI.renderBottom(true); } },
      jobs: m => { UI.jobs = m.jobs; UI.ffmpeg = m.ffmpeg; renderStatus(); if (UI.btab === 'shows' || UI.btab === 'files') UI.renderBottom(true); },
      library: () => { clearTimeout(UI._libT); UI._libT = setTimeout(() => UI.loadLibrary(), 300); },
      comps: m => { UI.comps = m.comps; if (UI.btab === 'shows') UI.renderBottom(true); },
      tc: m => { UI.tc = m; renderStatus(); if (UI.rtab === 'tc') UI.panels.tc.live($('#rpane'), UI.st()); },
      cue: () => renderTop(),
      unplayable: m => UI.toast(m.ffmpeg ? `${m.src.split('/').pop()}: format not playable in the browser — converting locally…` : `${m.src.split('/').pop()}: format not playable — install ffmpeg to convert it`, 'err'),
      error: m => UI.toast(m.msg, 'err'),
    });
    setInterval(renderStatus, 1000);
  });
})();
