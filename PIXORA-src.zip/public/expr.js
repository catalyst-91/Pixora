/* PIXORA — parameter expressions. A small, safe maths language (no access to the page or the network):
     numbers, + - * / % ^, comparisons, && || !, a ? b : c, parentheses
     variables: time (s), beat, bar, bpm, value (the parameter's own value), low / mid / high / level (audio input 0–1), pi
     functions: sin cos tan asin acos atan atan2 abs min max clamp floor ceil round fract sqrt pow exp log sign
                lerp(a,b,t) step(e,x) smoothstep(a,b,x) noise(x) rand(seed) pulse(period,width) saw(x) tri(x) sq(x)
                feed("name") (a data feed's number), param("layers.0.opacity") (another parameter)
   PixoraExpr.compile(src) → fn(ctx) or throws an Error with the position of the problem. */
(function (root) {
  'use strict';
  const FUN = {
    sin: Math.sin, cos: Math.cos, tan: Math.tan, asin: Math.asin, acos: Math.acos, atan: Math.atan, atan2: Math.atan2, abs: Math.abs, min: Math.min, max: Math.max,
    floor: Math.floor, ceil: Math.ceil, round: Math.round, sqrt: Math.sqrt, pow: Math.pow, exp: Math.exp, log: Math.log, sign: Math.sign,
    clamp: (x, a = 0, b = 1) => Math.min(Math.max(x, a), b), fract: x => x - Math.floor(x), lerp: (a, b, t) => a + (b - a) * t, step: (e, x) => (x < e ? 0 : 1),
    smoothstep: (a, b, x) => { const t = Math.min(Math.max((x - a) / ((b - a) || 1e-9), 0), 1); return t * t * (3 - 2 * t); },
    rand: s => { const x = Math.sin((s || 0) * 12.9898 + 78.233) * 43758.5453; return x - Math.floor(x); },
    noise: x => { const i = Math.floor(x), f = x - i, h = n => { const v = Math.sin(n * 127.1 + 311.7) * 43758.5453; return v - Math.floor(v); }, u = f * f * (3 - 2 * f); return h(i) * (1 - u) + h(i + 1) * u; },
    pulse: (p, w = 0.5) => { const f = (Date.now() / 1000 / (p || 1)) % 1; return f < w ? 1 : 0; },
    saw: x => x - Math.floor(x), tri: x => { const f = x - Math.floor(x); return 1 - Math.abs(f * 2 - 1); }, sq: x => (x - Math.floor(x) < 0.5 ? 1 : 0),
  };
  const VARS = new Set(['time', 'beat', 'bar', 'bpm', 'value', 'low', 'mid', 'high', 'level', 'pi']);
  function tokens(src) {
    const out = []; let i = 0; const s = String(src);
    while (i < s.length) { const c = s[i];
      if (/\s/.test(c)) { i++; continue; }
      let m;
      if ((m = /^(\d+\.?\d*|\.\d+)(e[+-]?\d+)?/i.exec(s.slice(i)))) { out.push({ t: 'num', v: parseFloat(m[0]), p: i }); i += m[0].length; continue; }
      if ((m = /^[A-Za-z_]\w*/.exec(s.slice(i)))) { out.push({ t: 'id', v: m[0], p: i }); i += m[0].length; continue; }
      if (c === '"' || c === "'") { const j = s.indexOf(c, i + 1); if (j < 0) throw err('unclosed text', i); out.push({ t: 'str', v: s.slice(i + 1, j), p: i }); i = j + 1; continue; }
      if ((m = /^(&&|\|\||==|!=|<=|>=|[-+*/%^()<>!?:,])/.exec(s.slice(i)))) { out.push({ t: 'op', v: m[0], p: i }); i += m[0].length; continue; }
      throw err(`unexpected “${c}”`, i);
    }
    out.push({ t: 'end', p: s.length }); return out;
  }
  function err(msg, p) { const e = new Error(`${msg} (at ${p + 1})`); e.pos = p; return e; }
  // Pratt parser → nested closures
  function compile(src) {
    if (String(src).length > 500) throw new Error('expression too long');
    const tk = tokens(src); let k = 0; const peek = () => tk[k], next = () => tk[k++];
    const expect = v => { const t = next(); if (t.v !== v) throw err(`expected “${v}”`, t.p); };
    const BP = { '?': 1, '||': 2, '&&': 3, '==': 4, '!=': 4, '<': 5, '>': 5, '<=': 5, '>=': 5, '+': 6, '-': 6, '*': 7, '/': 7, '%': 7, '^': 9 };
    function prefix() {
      const t = next();
      if (t.t === 'num') { const v = t.v; return () => v; }
      if (t.t === 'str') { const v = t.v; return () => v; }
      if (t.t === 'op' && t.v === '(') { const e = expr(0); expect(')'); return e; }
      if (t.t === 'op' && t.v === '-') { const e = expr(8); return c => -e(c); }
      if (t.t === 'op' && t.v === '+') return expr(8);
      if (t.t === 'op' && t.v === '!') { const e = expr(8); return c => (e(c) ? 0 : 1); }
      if (t.t === 'id') {
        if (peek().v === '(') { next(); const args = []; if (peek().v !== ')') { do { args.push(expr(0)); } while (peek().v === ',' && next()); } expect(')');
          if (t.v === 'feed') return c => { const v = c.feed ? c.feed(args[0] && args[0](c)) : 0; return typeof v === 'number' ? v : parseFloat(v) || 0; };
          if (t.v === 'param') return c => (c.param ? +c.param(args[0] && args[0](c)) || 0 : 0);
          const f = FUN[t.v]; if (!f) throw err(`unknown function ${t.v}()`, t.p); return c => f(...args.map(a => a(c))); }
        if (!VARS.has(t.v)) throw err(`unknown name “${t.v}”`, t.p);
        if (t.v === 'pi') return () => Math.PI; const n = t.v; return c => +c[n] || 0;
      }
      throw err(t.t === 'end' ? 'unexpected end' : `unexpected “${t.v}”`, t.p);
    }
    function expr(rbp) {
      let left = prefix();
      for (;;) { const t = peek(); const bp = t.t === 'op' ? BP[t.v] : undefined; if (bp == null || bp <= rbp) break; next();
        if (t.v === '?') { const a = expr(0); expect(':'); const b = expr(0), l = left; left = c => (l(c) ? a(c) : b(c)); continue; }
        const r = expr(t.v === '^' ? bp - 1 : bp), l = left;
        left = ({ '+': c => l(c) + r(c), '-': c => l(c) - r(c), '*': c => l(c) * r(c), '/': c => { const d = r(c); return d ? l(c) / d : 0; }, '%': c => { const d = r(c); return d ? l(c) % d : 0; },
          '^': c => Math.pow(l(c), r(c)), '<': c => +(l(c) < r(c)), '>': c => +(l(c) > r(c)), '<=': c => +(l(c) <= r(c)), '>=': c => +(l(c) >= r(c)), '==': c => +(l(c) === r(c)), '!=': c => +(l(c) !== r(c)),
          '&&': c => (l(c) && r(c)) ? 1 : 0, '||': c => (l(c) || r(c)) ? 1 : 0 })[t.v];
      }
      return left;
    }
    const fn = expr(0); if (peek().t !== 'end') throw err(`unexpected “${peek().v}”`, peek().p);
    return c => { const v = fn(c || {}); return typeof v === 'number' && isFinite(v) ? v : 0; };
  }
  const cache = new Map();
  const get = src => { let e = cache.get(src); if (!e) { try { e = { fn: compile(src) }; } catch (x) { e = { error: x.message }; } if (cache.size > 500) cache.clear(); cache.set(src, e); } return e; };
  const api = { compile, get, FUNCTIONS: Object.keys(FUN).concat(['feed', 'param']), VARIABLES: [...VARS] };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.PixoraExpr = api;
})(typeof window !== 'undefined' ? window : this);
