/* PIXORA — ISF (Interactive Shader Format) support: parse the JSON header, normalise inputs / passes / imported images,
 * and build WebGL (GLSL ES 1.00) vertex + fragment shaders with the ISF built-ins (TIME, RENDERSIZE, PASSINDEX, IMG_PIXEL…).
 * Spec: https://github.com/mrRay/ISF_Spec — handles ISF 2.0 and the older 1.x keys (PERSISTENT_BUFFERS, vv_FragNormCoord).
 * Works in the browser (window.PixoraISF) and in Node (tests, server-side validation on import). */
(function (root, factory) { if (typeof module === 'object' && module.exports) module.exports = factory(); else root.PixoraISF = factory(); })(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const IDENT = /^[A-Za-z_][A-Za-z0-9_]*$/;
  const TYPES = ['float', 'bool', 'long', 'color', 'point2D', 'event', 'image', 'audio', 'audioFFT'];
  const isISF = code => /^\s*\/\*\s*\{/.test(String(code || ''));

  function headerOf(code) {
    const s = String(code || ''), a = s.indexOf('/*'), b = s.indexOf('*/', a + 2);
    if (a < 0 || b < 0) throw new Error('No ISF JSON header (/* { … } */) at the top of the file');
    let json = s.slice(a + 2, b).trim();
    json = json.replace(/,\s*([}\]])/g, '$1'); // tolerate trailing commas, which several published ISFs have
    let h; try { h = JSON.parse(json); } catch (e) { throw new Error('ISF header is not valid JSON: ' + e.message); }
    if (!h || typeof h !== 'object' || Array.isArray(h)) throw new Error('ISF header must be a JSON object');
    return { header: h, body: s.slice(b + 2) };
  }
  const num = (v, d) => { const n = +v; return Number.isFinite(n) ? n : d; };
  const arr = (v, n, d) => { const a = Array.isArray(v) ? v.map(x => num(x, 0)) : []; while (a.length < n) a.push(d[a.length]); return a.slice(0, n); };

  function normInput(i, errors) {
    if (!i || typeof i !== 'object') return null;
    const name = String(i.NAME || ''), type = TYPES.find(t => t.toLowerCase() === String(i.TYPE || '').toLowerCase());
    if (!IDENT.test(name)) { errors.push(`input name "${name}" is not a valid identifier`); return null; }
    if (!type) { errors.push(`input ${name}: unknown TYPE "${i.TYPE}"`); return null; }
    const o = { name, type, label: String(i.LABEL || name) };
    if (type === 'float') { o.min = num(i.MIN, 0); o.max = num(i.MAX, 1); if (o.max < o.min) [o.min, o.max] = [o.max, o.min]; o.def = num(i.DEFAULT, o.min); o.identity = i.IDENTITY != null ? num(i.IDENTITY, o.def) : null; }
    else if (type === 'bool') o.def = !!i.DEFAULT;
    else if (type === 'long') { o.values = Array.isArray(i.VALUES) ? i.VALUES.map(v => num(v, 0) | 0) : [];
      o.labels = Array.isArray(i.LABELS) ? i.LABELS.map(String) : [];
      if (!o.values.length) { const mn = num(i.MIN, 0) | 0, mx = num(i.MAX, mn + 1) | 0; for (let v = mn; v <= mx && o.values.length < 64; v++) o.values.push(v); }
      while (o.labels.length < o.values.length) o.labels.push(String(o.values[o.labels.length]));
      o.def = i.DEFAULT != null ? num(i.DEFAULT, o.values[0]) | 0 : o.values[0]; }
    else if (type === 'color') { o.def = arr(i.DEFAULT, 4, [0, 0, 0, 1]); }
    else if (type === 'point2D') { o.def = arr(i.DEFAULT, 2, [0, 0]); if (i.MIN != null || i.MAX != null) { o.min = arr(i.MIN, 2, [0, 0]); o.max = arr(i.MAX, 2, [1, 1]); } }
    else if (type === 'audio' || type === 'audioFFT') o.samples = Math.max(0, num(i.MAX, 0) | 0);
    return o;
  }

  function parse(code, vsCode) {
    const errors = [];
    const { header: h, body } = headerOf(code);
    const inputs = []; const seen = new Set();
    for (const raw of Array.isArray(h.INPUTS) ? h.INPUTS : []) { const i = normInput(raw, errors); if (i && !seen.has(i.name)) { seen.add(i.name); inputs.push(i); } }
    let passes = (Array.isArray(h.PASSES) && h.PASSES.length ? h.PASSES : [{}]).map(p => ({
      target: p && IDENT.test(String(p.TARGET || '')) ? String(p.TARGET) : '', persistent: !!(p && (p.PERSISTENT === true || p.PERSISTENT === 1 || p.PERSISTENT === 'true')),
      float: !!(p && (p.FLOAT === true || p.FLOAT === 1 || p.FLOAT === 'true')), width: p && p.WIDTH != null ? String(p.WIDTH) : '', height: p && p.HEIGHT != null ? String(p.HEIGHT) : '' }));
    // ISF 1.x: PERSISTENT_BUFFERS as an array of names or an object of { name: { WIDTH, HEIGHT, FLOAT } }
    const pb = h.PERSISTENT_BUFFERS; const pers = Array.isArray(pb) ? pb.map(String) : pb && typeof pb === 'object' ? Object.keys(pb) : [];
    for (const n of pers) { const p = passes.find(x => x.target === n); const extra = pb && !Array.isArray(pb) ? pb[n] || {} : {};
      if (p) { p.persistent = true; if (extra.FLOAT) p.float = true; if (!p.width && extra.WIDTH != null) p.width = String(extra.WIDTH); if (!p.height && extra.HEIGHT != null) p.height = String(extra.HEIGHT); } }
    const imported = []; const im = h.IMPORTED;
    if (Array.isArray(im)) for (const x of im) { if (x && IDENT.test(String(x.NAME || ''))) imported.push({ name: String(x.NAME), path: String(x.PATH || '') }); }
    else if (im && typeof im === 'object') for (const k of Object.keys(im)) if (IDENT.test(k)) imported.push({ name: k, path: String((im[k] && im[k].PATH) || '') });
    const isFilter = inputs.some(i => i.name === 'inputImage' && i.type === 'image');
    const isTransition = inputs.some(i => i.name === 'startImage' && i.type === 'image') && inputs.some(i => (i.name === 'endImage' || i.name === 'inputImage') && i.type === 'image') && inputs.some(i => i.name === 'progress'); // ISF spec: startImage · endImage · progress (older ones call the end picture inputImage)
    const cats = Array.isArray(h.CATEGORIES) ? h.CATEGORIES.map(String) : [];
    return { ok: !errors.length, errors, version: String(h.ISFVSN || h.VSN || (pers.length ? '1' : '2')), description: String(h.DESCRIPTION || ''), credit: String(h.CREDIT || ''),
      categories: cats, inputs, passes, imported, isFilter, isTransition, body, vsBody: vsCode ? String(vsCode) : '',
      targets: [...new Set(passes.map(p => p.target).filter(Boolean))] };
  }

  /* --- IMG_* macros: rewritten as text because GLSL ES has no token pasting (same approach as VVISF) */
  function splitArgs(s, open) { // s[open] === '(' → [args[], indexAfterClose]
    let depth = 0, cur = '', out = [];
    for (let i = open; i < s.length; i++) { const c = s[i];
      if (c === '(') { if (depth++ > 0) cur += c; }
      else if (c === ')') { if (--depth === 0) { out.push(cur.trim()); return [out, i + 1]; } cur += c; }
      else if (c === ',' && depth === 1) { out.push(cur.trim()); cur = ''; }
      else cur += c; }
    throw new Error('Unbalanced parentheses in an IMG_ call');
  }
  function rewriteImg(src) {
    const re = /\b(IMG_THIS_NORM_PIXEL|IMG_THIS_PIXEL|IMG_NORM_PIXEL|IMG_PIXEL|IMG_SIZE)\s*\(/g; let out = '', last = 0, m;
    while ((m = re.exec(src))) {
      const open = m.index + m[0].length - 1; const [a, end] = splitArgs(src, open); const fn = m[1], img = rewriteImg(a[0] || ''); const c = a[1] != null ? rewriteImg(a[1]) : '';
      if (!IDENT.test(img)) throw new Error(`${fn}: first argument must be an image name, got "${img}"`);
      let rep;
      if (fn === 'IMG_SIZE') rep = `_${img}_imgSize`;
      else if (fn === 'IMG_PIXEL') rep = `texture2D(${img}, (${c}) / _${img}_imgSize)`;
      else if (fn === 'IMG_NORM_PIXEL') rep = `texture2D(${img}, ${c})`;
      else rep = `texture2D(${img}, isf_FragNormCoord)`;
      out += src.slice(last, m.index) + rep; last = end; re.lastIndex = end;
    }
    return out + src.slice(last);
  }

  const UNIFORM_TYPE = { float: 'float', bool: 'bool', long: 'int', color: 'vec4', point2D: 'vec2', event: 'bool' };
  function decls(p, text, forVs) {
    let d = 'uniform int PASSINDEX;\nuniform vec2 RENDERSIZE;\nuniform float TIME;\nuniform float TIMEDELTA;\nuniform vec4 DATE;\nuniform int FRAMEINDEX;\n';
    const imgs = [];
    for (const i of p.inputs) { if (UNIFORM_TYPE[i.type]) d += `uniform ${UNIFORM_TYPE[i.type]} ${i.name};\n`; else imgs.push(i.name); }
    for (const t of p.targets) if (!imgs.includes(t)) imgs.push(t);
    for (const t of p.imported) if (!imgs.includes(t.name)) imgs.push(t.name);
    for (const n of imgs) { if (forVs && !new RegExp('\\b' + n + '\\b').test(text)) continue; d += `uniform sampler2D ${n};\nuniform vec2 _${n}_imgSize;\n`; }
    return { d, imgs };
  }
  function build(p) {
    const fsBody = rewriteImg(p.body.replace(/\bvv_FragNormCoord\b/g, 'isf_FragNormCoord'));
    const deriv = /\b(dFdx|dFdy|fwidth)\s*\(/.test(fsBody);
    // #extension lines inside the body have to move above everything else
    const exts = []; const fsClean = fsBody.replace(/^[ \t]*#extension[^\n]*\n?/gm, l => { exts.push(l.trim()); return ''; }).replace(/^[ \t]*#version[^\n]*\n?/gm, '');
    if (deriv && !exts.some(e => /standard_derivatives/.test(e))) exts.push('#extension GL_OES_standard_derivatives : enable');
    const fd = decls(p, fsClean, false);
    const fs = `${exts.join('\n')}${exts.length ? '\n' : ''}#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\nprecision highp int;\n#else\nprecision mediump float;\nprecision mediump int;\n#endif\n`
      + fd.d + 'varying vec2 isf_FragNormCoord;\n#line 1\n' + fsClean;
    let vsBody = p.vsBody ? rewriteImg(p.vsBody.replace(/\bvv_vertShaderInit\b/g, 'isf_vertShaderInit').replace(/\bvv_FragNormCoord\b/g, 'isf_FragNormCoord')).replace(/^[ \t]*#version[^\n]*\n?/gm, '') : '';
    if (!/\bvoid\s+main\s*\(/.test(vsBody)) vsBody = 'void main(){ isf_vertShaderInit(); }\n';
    const vd = decls(p, vsBody, true);
    const vs = 'precision highp float;\nprecision highp int;\nattribute vec2 a_pos;\n' + vd.d + 'varying vec2 isf_FragNormCoord;\n'
      + 'void isf_vertShaderInit(){ gl_Position=vec4(a_pos*2.0,0.0,1.0); isf_FragNormCoord=a_pos+0.5; }\n#line 1\n' + vsBody;
    return { fs, vs, images: fd.imgs };
  }

  /* --- pass WIDTH / HEIGHT expressions: "$WIDTH/2.0", "floor($HEIGHT*$scale)", "max($WIDTH,64.0)" — tiny safe evaluator, no eval() */
  function evalSize(expr, vars) {
    const s = String(expr || '').trim(); if (!s) return null;
    let i = 0; const ws = () => { while (/\s/.test(s[i] || '')) i++; };
    const F = { floor: Math.floor, ceil: Math.ceil, round: Math.round, abs: Math.abs, sqrt: Math.sqrt, max: Math.max, min: Math.min, pow: Math.pow };
    function prim() { ws(); const c = s[i];
      if (c === '(') { i++; const v = add(); ws(); if (s[i] !== ')') throw new Error('expected )'); i++; return v; }
      if (c === '-') { i++; return -prim(); } if (c === '+') { i++; return prim(); }
      if (c === '$') { const m = /^\$([A-Za-z_]\w*)/.exec(s.slice(i)); if (!m) throw new Error('bad variable'); i += m[0].length; const v = vars[m[1]]; return Number.isFinite(+v) ? +v : 0; }
      const n = /^(\d+\.?\d*|\.\d+)(e[+-]?\d+)?/i.exec(s.slice(i)); if (n) { i += n[0].length; return +n[0]; }
      const f = /^([a-z]+)\s*\(/.exec(s.slice(i)); if (f && F[f[1]]) { i += f[0].length; const args = [add()]; ws(); while (s[i] === ',') { i++; args.push(add()); ws(); } if (s[i] !== ')') throw new Error('expected )'); i++; return F[f[1]](...args); }
      throw new Error('unexpected "' + s.slice(i, i + 8) + '"'); }
    function mul() { let v = prim(); for (;;) { ws(); const c = s[i]; if (c === '*') { i++; v *= prim(); } else if (c === '/') { i++; const d = prim(); v = d ? v / d : 0; } else return v; } }
    function add() { let v = mul(); for (;;) { ws(); const c = s[i]; if (c === '+') { i++; v += mul(); } else if (c === '-') { i++; v -= mul(); } else return v; } }
    try { const v = add(); ws(); if (i < s.length) return null; return Number.isFinite(v) ? v : null; } catch { return null; }
  }
  function passSize(pass, W, H, vals) {
    const vars = Object.assign({}, vals || {}, { WIDTH: W, HEIGHT: H });
    const w = evalSize(pass.width, vars), h = evalSize(pass.height, vars);
    return { w: Math.max(1, Math.min(8192, Math.round(w == null ? W : w))), h: Math.max(1, Math.min(8192, Math.round(h == null ? H : h))) };
  }

  /* --- current value of an input, from a { NAME: value } bag with the ISF default as fallback */
  function value(inp, vals) {
    const v = vals ? vals[inp.name] : undefined;
    if (inp.type === 'float') return Number.isFinite(+v) && v !== null && v !== '' ? Math.max(inp.min, Math.min(inp.max, +v)) : inp.def;
    if (inp.type === 'bool') return v == null ? inp.def : !!v;
    if (inp.type === 'long') return v == null || v === '' ? inp.def : (+v | 0);
    if (inp.type === 'color') { if (typeof v === 'string' && /^#[0-9a-f]{6}$/i.test(v)) { const n = parseInt(v.slice(1), 16); return [(n >> 16 & 255) / 255, (n >> 8 & 255) / 255, (n & 255) / 255, 1]; } return Array.isArray(v) ? arr(v, 4, inp.def) : inp.def; }
    if (inp.type === 'point2D') return Array.isArray(v) ? arr(v, 2, inp.def) : inp.def;
    return v;
  }
  const hex = c => '#' + c.slice(0, 3).map(x => Math.round(Math.max(0, Math.min(1, x)) * 255).toString(16).padStart(2, '0')).join('');

  /* --- quick checks used on import (no GL needed) */
  function validate(code, vsCode) {
    try { const p = parse(code, vsCode); build(p); return { ok: p.ok, errors: p.errors, info: p }; }
    catch (e) { return { ok: false, errors: [String(e.message || e)] }; }
  }
  return { isISF, parse, build, rewriteImg, evalSize, passSize, value, hex, validate, TYPES };
});
