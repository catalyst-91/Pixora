/* PIXORA shared browser client: WebSocket link, commands, time/beat sync, helpers. */
(function () {
  const BVJ = window.BVJ = {};
  let ws = null, handlers = {}, role = 'control', queue = [], timeOffset = 0, retry = 500;
  BVJ.state = null; BVJ.feeds = {};
  BVJ.connected = false;

  async function ensureAuth() {
    try {
      const info = await (await fetch('/api/info')).json();
      if (info.users && !info.authed) { location.href = '/login.html?next=' + encodeURIComponent(location.pathname + location.search); return new Promise(() => {}); }
      if (info.pinRequired && !info.authed && !info.users) {
        let pin = new URLSearchParams(location.search).get('pin') || localStorage.getItem('bvjpin') || prompt('PIXORA PIN');
        const r = await fetch('/api/login?pin=' + encodeURIComponent(pin || ''));
        if (!r.ok) { localStorage.removeItem('bvjpin'); alert('Wrong PIN'); return ensureAuth(); }
        localStorage.setItem('bvjpin', pin);
      }
      BVJ.info = info;
    } catch { /* server down — the socket loop will retry */ }
  }

  BVJ.connect = async function (r, h) {
    role = r; handlers = h || {};
    await ensureAuth();
    open();
  };
  function open() {
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    ws = new WebSocket(`${proto}//${location.host}/ws?role=${role}`);
    ws.binaryType = 'arraybuffer';
    ws.onopen = () => {
      BVJ.connected = true; retry = 500; (handlers.connection || (() => {}))(true);
      queue.splice(0).forEach(m => ws.send(m)); syncClock();
    };
    ws.onclose = () => { BVJ.connected = false; (handlers.connection || (() => {}))(false); setTimeout(open, retry = Math.min(retry * 1.6, 5000)); };
    ws.onerror = () => {};
    ws.onmessage = ev => {
      if (typeof ev.data !== 'string') { (handlers.binary || (() => {}))(ev.data); return; }
      const m = JSON.parse(ev.data);
      if (m.t === 'state') { BVJ.state = m.state; if (!BVJ._synced) timeOffset = m.serverTime - Date.now(); }
      if (m.t === 'feeds') { BVJ.feeds = m.values || {}; BVJ.feedStatus = m.status || {}; }
      if (m.t === 'hping') { BVJ.raw({ t: 'hpong', at: m.at }); }
      if (m.t === 'pong') { const rtt = Date.now() - m.id; timeOffset = m.serverTime + rtt / 2 - Date.now(); BVJ._synced = true; }
      const fn = handlers[m.t]; if (fn) fn(m); const fx = (BVJ.extraHandlers || {})[m.t]; if (fx) try { fx(m); } catch (e) { console.warn(e); }
      if (handlers.any) handlers.any(m);
    };
  }
  function syncClock() { BVJ.raw({ t: 'ping', id: Date.now() }); }
  setInterval(() => { if (BVJ.connected) syncClock(); }, 20000);

  BVJ.raw = function (obj) { const m = typeof obj === 'string' ? obj : JSON.stringify(obj); if (ws && ws.readyState === 1) ws.send(m); else queue.push(m); };
  BVJ.sendBinary = function (buf) { if (ws && ws.readyState === 1 && ws.bufferedAmount < 256 * 1024) ws.send(buf); };
  BVJ.sendBinaryAlways = function (buf) { if (ws && ws.readyState === 1) { ws.send(buf); return ws.bufferedAmount; } return -1; }; // live stream: never drop
  BVJ.cmd = function (cmd) { BVJ.raw({ t: 'cmd', cmd }); };

  // Throttled setter: coalesces rapid fader moves into ~30 msgs/sec per path, applies optimistically.
  const pending = new Map(); let flushT = null;
  BVJ.set = function (path, value) {
    if (BVJ.state) { try { setLocal(BVJ.state, path, value); } catch {} }
    pending.set(path, value);
    if (!flushT) flushT = setTimeout(() => { flushT = null; const values = Object.fromEntries(pending); pending.clear(); BVJ.cmd({ op: 'setMany', values }); }, 33);
  };
  function setLocal(obj, p, v) { const k = p.split('.'); let o = obj; for (let i = 0; i < k.length - 1; i++) o = o[k[i]]; o[k[k.length - 1]] = v; }
  BVJ.get = function (path, obj) { let o = obj || BVJ.state; for (const k of path.split('.')) { if (o == null) return undefined; o = o[k]; } return o; };

  BVJ.now = () => Date.now() + timeOffset; // server clock
  BVJ.beat = comp => (BVJ.now() - comp.beatEpoch) / (60000 / comp.bpm); // continuous beat count

  // Tap tempo: returns bpm after 2+ taps within 2.5s windows.
  let taps = [];
  BVJ.tap = function () {
    const now = BVJ.now(); taps = taps.filter(t => now - t < 2500); taps.push(now);
    if (taps.length >= 2) {
      const iv = (taps[taps.length - 1] - taps[0]) / (taps.length - 1);
      const bpm = Math.round(60000 / iv * 10) / 10;
      BVJ.cmd({ op: 'bpm', bpm, resync: true });
      return bpm;
    }
    return null;
  };

  BVJ.mediaUrl = src => /^https?:\/\//i.test(src) ? src : '/media/' + src.split('/').map(encodeURIComponent).join('/'); // playlists may list web URLs
  BVJ.thumbUrl = (src, v) => '/thumb/' + encodeURIComponent(src) + (v ? '?v=' + v : '');
  BVJ.esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  BVJ.api = async function (url, opts) {
    const r = await fetch(url, opts); let j = {}; try { j = await r.json(); } catch {}
    if (!r.ok) throw new Error(j.error || r.statusText); return j;
  };
  BVJ.clipLabel = c => !c ? '' : c.name || (c.src ? c.src.split('/').pop() : c.type);
  BVJ.hex2rgb = h => { const n = parseInt((h || '#000000').slice(1), 16); return [(n >> 16 & 255) / 255, (n >> 8 & 255) / 255, (n & 255) / 255]; };
  BVJ.fmtTime = s => { if (!isFinite(s)) return '--:--'; s = Math.max(0, s); const m = Math.floor(s / 60); return m + ':' + String(Math.floor(s % 60)).padStart(2, '0'); };
})();
