/* PIXORA shared browser client: WebSocket link, commands, time/beat sync, helpers. */
(function () {
  const BVJ = window.BVJ = {};
  let ws = null, handlers = {}, role = 'control', queue = [], timeOffset = 0, retry = 500;
  BVJ.state = null; BVJ.feeds = {};
  BVJ.connected = false;

  async function ensureAuth() {
    try {
      const info = await (await fetch('/api/info')).json();
      if (info.users && !info.authed) { location.href = '/login.html?next=' + encodeURIComponent(location.pathname + location.search); return new Promise(() => {}); }
      if (info.pinRequired && !info.authed && !info.users) {
        let pin = new URLSearchParams(location.search).get('pin') || localStorage.getItem('bvjpin') || prompt('PIXORA PIN');
        const r = await fetch('/api/login?pin=' + encodeURIComponent(pin || ''));
        if (!r.ok) { localStorage.removeItem('bvjpin'); alert('Wrong PIN'); return ensureAuth(); }
        localStorage.setItem('bvjpin', pin);
      }
      BVJ.info = info;
    } catch { /* server down — the socket loop will retry */ }
  }

  BVJ.connect = async function (r, h) {
    role = r; handlers = h || {};
    await ensureAuth();
    open();
  };
  function open() {
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    ws = new WebSocket(`${proto}//${location.host}/ws?role=${role}${BVJ.wsQuery || ''}`);
    ws.binaryType = 'arraybuffer';
    ws.onopen = () => {
      BVJ.connected = true; retry = 500; (handlers.connection || (() => {}))(true); failover.back();
      queue.splice(0).forEach(m => ws.send(m)); syncClock();
    };
    ws.onclose = () => { BVJ.connected = false; (handlers.connection || (() => {}))(false); setTimeout(open, retry = Math.min(retry * 1.6, 5000)); failover.lost(); };
    ws.onerror = () => {};
    ws.onmessage = ev => {
      if (typeof ev.data !== 'string') { (handlers.binary || (() => {}))(ev.data); return; }
      const m = JSON.parse(ev.data);
      if (m.t === 'state') { BVJ.state = m.state; if (!BVJ._synced) timeOffset = m.serverTime - Date.now(); }
      if (m.t === 'feeds') { BVJ.feeds = m.values || {}; BVJ.feedStatus = m.status || {}; }
      if (m.t === 'hping') { BVJ.raw({ t: 'hpong', at: m.at }); }
      if (m.t === 'backup') failover.status(m);
      if (m.t === 'pong') { const rtt = Date.now() - m.id; timeOffset = m.serverTime + rtt / 2 - Date.now(); BVJ._synced = true; }
      const fn = handlers[m.t]; if (fn) fn(m); const fx = (BVJ.extraHandlers || {})[m.t]; if (fx) try { fx(m); } catch (e) { console.warn(e); }
      if (handlers.any) handlers.any(m);
    };
  }
  /* main/backup failover: controllers, phone remotes and output windows on other computers follow control to the backup */
  const failover = (() => {
    let lostAt = 0, timer = null, ov = null; const followRoles = ['control', 'remote', 'output'];
    try { const q = new URLSearchParams(location.search); const from = q.get('pxfrom'); if (from) { sessionStorage.setItem('pxReturnTo', from); q.delete('pxfrom'); history.replaceState(null, '', location.pathname + (q.toString() ? '?' + q : '') + location.hash); } } catch {}
    const here = () => location.pathname + location.search + location.hash;
    const banner = (msg, btn) => { if (!document.body) return; if (!ov) { ov = document.createElement('div'); ov.style.cssText = 'position:fixed;left:50%;top:14px;transform:translateX(-50%);z-index:99999;background:#1b0d12;border:1px solid #ff4d5e;color:#fff;padding:10px 16px;border-radius:10px;font:600 14px Inter,system-ui,sans-serif;box-shadow:0 8px 30px #0008;display:flex;gap:12px;align-items:center'; document.body.appendChild(ov); }
      ov.innerHTML = ''; const t = document.createElement('span'); t.textContent = msg; ov.appendChild(t); if (btn) { const b = document.createElement('button'); b.textContent = btn[0]; b.style.cssText = 'background:#ff4d5e;color:#fff;border:0;border-radius:6px;padding:5px 10px;font:inherit;cursor:pointer'; b.onclick = btn[1]; ov.appendChild(b); } };
    const clear = () => { if (ov) { ov.remove(); ov = null; } };
    function go(url, from) { const sep = here().includes('?') ? '&' : '?'; const [path, hash] = here().split('#'); location.href = url.replace(/\/$/, '') + path + (from ? (path.includes('?') ? '&' : '?') + 'pxfrom=' + encodeURIComponent(from) : '') + (hash ? '#' + hash : ''); }
    return {
      status(m) { const st = m.status || {}; BVJ.backupStatus = st;
        if (st.mode !== 'backup') { const u = (st.mirrors || []).map(x => x.url).find(Boolean); try { if (u && st.follow !== false) localStorage.setItem('pxBackupUrl', u); if (st.follow === false) localStorage.removeItem('pxBackupUrl'); } catch {}
          if (st.held && st.held.url && role !== 'output' && st.follow !== false) banner('The backup server is in control', ['Open backup', () => go(st.held.url, location.origin)]); else if (!lostAt) clear(); }
        else { let back = null; try { back = sessionStorage.getItem('pxReturnTo'); } catch {}
          if (back && m.handedBack) { banner('Control handed back to the primary — returning…'); try { sessionStorage.removeItem('pxReturnTo'); } catch {} setTimeout(() => go(back), 1200); } } },
      lost() { if (lostAt || !followRoles.includes(role)) return; lostAt = Date.now(); let url = null; try { url = localStorage.getItem('pxBackupUrl'); } catch {}
        if (!url || url.replace(/\/$/, '') === location.origin) return;
        clearTimeout(timer); timer = setTimeout(async function check() { if (BVJ.connected) return;
          const ok = await fetch(url.replace(/\/$/, '') + '/api/info', { mode: 'no-cors', cache: 'no-store' }).then(() => true).catch(() => false);
          if (!ok) { banner('Primary server lost — backup not reachable yet, retrying…'); timer = setTimeout(check, 2000); return; }
          let n = 3; banner(`Primary server lost — switching to the backup in ${n}s`, ['Stay here', () => { clearTimeout(timer); banner('Primary lost — staying here (reconnecting)'); }]);
          timer = setTimeout(function tickDown() { if (BVJ.connected) return clear(); if (--n > 0) { ov && (ov.firstChild.textContent = `Primary server lost — switching to the backup in ${n}s`); timer = setTimeout(tickDown, 1000); } else go(url, location.origin); }, 1000);
        }, 4500); },
      back() { lostAt = 0; clearTimeout(timer); clear(); },
    };
  })();
  BVJ.failover = failover;
  function syncClock() { BVJ.raw({ t: 'ping', id: Date.now() }); }
  setInterval(() => { if (BVJ.connected) syncClock(); }, 20000);

  BVJ.raw = function (obj) { const m = typeof obj === 'string' ? obj : JSON.stringify(obj); if (ws && ws.readyState === 1) ws.send(m); else queue.push(m); };
  BVJ.sendBinary = function (buf) { if (ws && ws.readyState === 1 && ws.bufferedAmount < 256 * 1024) ws.send(buf); };
  BVJ.sendBinaryAlways = function (buf) { if (ws && ws.readyState === 1) { ws.send(buf); return ws.bufferedAmount; } return -1; }; // live stream: never drop
  BVJ.cmd = function (cmd) { BVJ.raw({ t: 'cmd', cmd }); };

  // Throttled setter: coalesces rapid fader moves into ~30 msgs/sec per path, applies optimistically.
  const pending = new Map(); let flushT = null;
  BVJ.set = function (path, value) {
    if (BVJ.state) { try { setLocal(BVJ.state, path, value); } catch {} }
    pending.set(path, value);
    if (!flushT) flushT = setTimeout(() => { flushT = null; const values = Object.fromEntries(pending); pending.clear(); BVJ.cmd({ op: 'setMany', values }); }, 33);
  };
  function setLocal(obj, p, v) { const k = p.split('.'); let o = obj; for (let i = 0; i < k.length - 1; i++) o = o[k[i]]; o[k[k.length - 1]] = v; }
  BVJ.get = function (path, obj) { let o = obj || BVJ.state; for (const k of path.split('.')) { if (o == null) return undefined; o = o[k]; } return o; };

  BVJ.now = () => { const t = Date.now() + timeOffset; const g = window.PXGenlock; if (!g || !g.fps) return t; // server clock
    const ft = 1000 / g.fps; return (Math.floor((t + g.lead) / ft) + 0.5) * ft; }; // genlocked DeckLink output: render ahead by the card's queue, on frame boundaries
  BVJ.beat = comp => (BVJ.now() - comp.beatEpoch) / (60000 / comp.bpm); // continuous beat count

  // Tap tempo: returns bpm after 2+ taps within 2.5s windows.
  let taps = [];
  BVJ.tap = function () {
    const now = BVJ.now(); taps = taps.filter(t => now - t < 2500); taps.push(now);
    if (taps.length >= 2) {
      const iv = (taps[taps.length - 1] - taps[0]) / (taps.length - 1);
      const bpm = Math.round(60000 / iv * 10) / 10;
      BVJ.cmd({ op: 'bpm', bpm, resync: true });
      return bpm;
    }
    return null;
  };

  BVJ.mediaUrl = src => /^https?:\/\//i.test(src) ? src : '/media/' + src.split('/').map(encodeURIComponent).join('/'); // playlists may list web URLs
  BVJ.thumbUrl = (src, v) => '/thumb/' + encodeURIComponent(src) + (v ? '?v=' + v : '');
  BVJ.esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  BVJ.api = async function (url, opts) {
    const r = await fetch(url, opts); let j = {}; try { j = await r.json(); } catch {}
    if (!r.ok) throw new Error(j.error || r.statusText); return j;
  };
  BVJ.clipLabel = c => !c ? '' : c.name || (c.src ? c.src.split('/').pop() : c.type);
  BVJ.hex2rgb = h => { const n = parseInt((h || '#000000').slice(1), 16); return [(n >> 16 & 255) / 255, (n >> 8 & 255) / 255, (n & 255) / 255]; };
  BVJ.fmtTime = s => { if (!isFinite(s)) return '--:--'; s = Math.max(0, s); const m = Math.floor(s / 60); return m + ':' + String(Math.floor(s % 60)).padStart(2, '0'); };
})();
