/* PIXORA v1.2 output additions: health stats to the server, safe loop, preloading the next cue, multi-machine frame sync,
 * HAP clip list. Loaded after output.html's main script; reaches the engine through window.PX_OUT. */
(function () {
  const O = window.PX_OUT; if (!O || !O.engine) return;
  const engine = O.engine, canvas = O.canvas;
  /* ---------- HAP list (which library files are HAP) */
  async function loadHap() { try { BVJ.hapSet = await (await fetch('/api/hap')).json(); } catch {} }
  loadHap(); setInterval(loadHap, 30000);
  let lastClipKeys = '';
  /* ---------- safe loop overlay */
  const safe = document.createElement('video'); safe.muted = true; safe.loop = true; safe.playsInline = true; safe.id = 'pxsafe';
  Object.assign(safe.style, { position: 'absolute', left: 0, top: 0, width: '100%', height: '100%', objectFit: 'cover', display: 'none', zIndex: 50, background: '#000' });
  (document.getElementById('stage') || document.body).appendChild(safe);
  let safeWhy = '', manualSafe = false, glLost = false;
  canvas.addEventListener('webglcontextlost', e => { e.preventDefault(); glLost = true; });
  canvas.addEventListener('webglcontextrestored', () => { glLost = false; setTimeout(() => location.reload(), 300); });
  function setSafe(on, why, st) {
    const src = st && st.show && st.show.safeSrc;
    if (on && src) { const u = BVJ.mediaUrl(src); if (safe.dataset.src !== u) { safe.dataset.src = u; safe.src = u; } safe.style.display = 'block'; safe.play().catch(() => {}); safeWhy = why; }
    else if (on && !src) { safe.style.display = 'block'; safe.removeAttribute('src'); safeWhy = why + ' (no safe clip set — black)'; }
    else { if (safe.style.display !== 'none') { safe.style.display = 'none'; safe.pause(); } safeWhy = ''; }
  }
  const stallAt = new Map();
  function checkSafe(st) {
    const sh = st.show || {}; let why = '';
    if (manualSafe) why = 'operator';
    else if (glLost) why = 'graphics context lost';
    else engine.layers.forEach((rt, li) => {
      const l = st.layers[li]; if (!rt || !l || l.active == null || l.bypass || why) return;
      const s = rt.cur; if (!s) return;
      if (s.error && sh.safeOnError) why = `layer ${li + 1}: clip can't play`;
      const v = s.el; if (v && v.tagName === 'VIDEO' && sh.safeOnStall && !l.paused && !s.held && v.readyState >= 1) {
        const k = li, prev = stallAt.get(k); const t = v.currentTime;
        if (!prev || Math.abs(prev.t - t) > 0.01) stallAt.set(k, { t, at: performance.now() });
        else if (performance.now() - prev.at > 3000 && !v.ended) why = `layer ${li + 1}: playback stalled`;
      }
    });
    setSafe(!!why, why, st);
  }
  /* ---------- preload the next cue / next column so they start instantly */
  const warm = new Map();
  function preload(st) {
    if (!st.show || !st.show.preload) { for (const v of warm.values()) v.remove(); warm.clear(); return; }
    const want = new Set();
    const addClip = c => { if (c && c.type === 'video' && c.src && !(BVJ.hapSet || {})[c.src]) want.add(c.src); };
    const nextCue = st.cues && st.cues[(st.cueIndex | 0) + 1];
    if (nextCue) { if (nextCue.col != null) st.layers.forEach(l => addClip(l.clips[nextCue.col])); (nextCue.snapshot && nextCue.snapshot.layers || []).forEach(x => { const l = st.layers[x.layer]; if (l && x.active != null) addClip(l.clips[x.active]); }); }
    st.layers.forEach(l => { if (l.active != null) addClip(l.clips[l.active + 1]); else addClip(l.clips[0]); });
    for (const [k, v] of warm) if (!want.has(k)) { v.removeAttribute('src'); v.load(); warm.delete(k); }
    for (const k of want) if (!warm.has(k) && warm.size < 10) { const v = document.createElement('video'); v.muted = true; v.preload = 'auto'; v.src = BVJ.mediaUrl(k); warm.set(k, v); }
  }
  /* ---------- multi-machine frame sync: keep video playheads locked to the (master) server clock */
  function sync(st) {
    const on = st.sync && st.sync.on; const tol = ((st.sync && st.sync.tolerance) || 40) / 1000, hard = ((st.sync && st.sync.hardSeek) || 250) / 1000;
    engine.layers.forEach((rt, li) => {
      const l = st.layers[li]; const s = rt && rt.cur; if (!s || !l) return;
      if (!on || l.active == null || l.paused) { s.syncMul = 1; return; }
      const c = s.clip || {}; if ((c.loop || 'loop') !== 'loop' || c.beatSync || (c.speed ?? 1) <= 0 || !l.trigAt) { s.syncMul = 1; return; }
      const rate = (c.speed ?? 1) * (st.comp.speed ?? 1); const el = BVJ.now() - l.trigAt; if (el < 0) return;
      let len, cur, seek;
      if (s.kind === 'hap' && s.hap && s.hap.dur) { len = s.dur || s.hap.dur; cur = s.t || 0; seek = t => { s.vt = (c.inPt || 0) * s.hap.dur + t; }; }
      else if (s.el && s.el.tagName === 'VIDEO' && s.el.duration && s.dur) { len = s.dur; cur = s.t || 0; seek = t => { s.el.currentTime = (c.inPt || 0) * s.el.duration + t; }; }
      else return;
      const expect = ((el / 1000) * rate) % len; let d = cur - expect; if (d > len / 2) d -= len; if (d < -len / 2) d += len;
      s.syncDrift = d;
      if (Math.abs(d) > hard) { seek(expect); s.syncMul = 1; }
      else if (Math.abs(d) > tol) s.syncMul = 1 - Math.max(-0.08, Math.min(0.08, d * 0.6));
      else s.syncMul = 1;
    });
  }
  /* ---------- stats to the server (Show tab meters, alerts, reports) */
  let lastStat = 0, lastDropped = 0, lastFrames = 0, frames = 0, worst = 0, prevT = 0;
  function stats(st, now) {
    frames++; if (prevT) { const ft = now - prevT; if (ft > worst) worst = ft; } prevT = now;
    if (now - lastStat < 2000) return;
    const es = engine.stats || {}; const dropped = es.dropped || 0; const dF = Math.max(1, frames - lastFrames); const dD = Math.max(0, dropped - lastDropped);
    let vdrop = 0; engine.layers.forEach(rt => { const v = rt && rt.cur && rt.cur.el; if (v && v.getVideoPlaybackQuality) vdrop += v.getVideoPlaybackQuality().droppedVideoFrames || 0; });
    const errors = []; engine.layers.forEach((rt, i) => { if (rt && rt.cur && rt.cur.error) errors.push(`L${i + 1}: ${rt.cur.errMsg || 'clip error'}`); });
    const drift = []; engine.layers.forEach((rt, i) => { if (rt && rt.cur && rt.cur.syncDrift != null && st.sync && st.sync.on) drift.push(Math.round(rt.cur.syncDrift * 1000)); });
    BVJ.raw({ t: 'ostat', name: O.outName(), fps: +(engine.fps || 0).toFixed(1), target: 60, drops: dropped, dropRate: +(dD / (dF + dD) * 100).toFixed(2), worst: Math.round(worst), vdrop,
      mem: performance.memory ? Math.round(performance.memory.usedJSHeapSize / 1048576) : 0, safe: safe.style.display === 'block', safeWhy, glLost, errors, drift });
    lastStat = now; lastDropped = dropped; lastFrames = frames; worst = 0;
  }
  O.onFrame = function (st, now) { checkSafe(st); sync(st); stats(st, now); if (now - (O._pl || 0) > 1000) { O._pl = now; preload(st);
    const keys = st.layers.map(l => { const c = l.active != null ? l.clips[l.active] : null; return c ? c.src : ''; }).join('|'); if (keys !== lastClipKeys) { lastClipKeys = keys; if (/\.mov/i.test(keys)) loadHap(); } } };
  O.onMessage = function (m) { if (m.t === 'safe') { manualSafe = !!m.on; } };
})();
