/* PIXORA — playlists as one input: Library ▸ Inputs maker and the Clip panel section. */
(function () {
  const UI = window.UI, $ = UI.$, $$ = UI.$$, esc = UI.esc, I = UI.icon;
  const sec = (title, body) => `<div class="sec"><h4>${title}</h4>${body}</div>`;
  const fmtN = n => n + ' item' + (n === 1 ? '' : 's');
  let made = null; // last resolved playlist for the library tile

  // ---- Library ▸ Inputs: build a playlist input from a folder or an external list
  UI.playlistMaker = function () {
    const lib = (UI.library && UI.library.sources) || [], folders = [];
    for (const s of lib) { const set = new Set(['']); for (const it of s.items || []) { const parts = (it.folder || '').split('/'); for (let i = 1; i <= parts.length; i++) set.add(parts.slice(0, i).join('/')); }
      for (const f of [...set].sort()) folders.push([s.id + (f ? '/' + f : ''), s.name + (f ? ' / ' + f : '')]); }
    return `<div class="sec"><h4>Playlist (one input)</h4>
      <div class="row wide"><label>From</label><div class="ctl"><select id="plKind"><option value="folder">Media folder</option><option value="file">Playlist file / URL (M3U, M3U8, PLS, TXT)</option></select></div></div>
      <div class="row wide" id="plFolderRow"><label>Folder</label><div class="ctl"><select id="plFolder">${folders.map(([v, l]) => `<option value="${esc(v)}">${esc(l)}</option>`).join('')}</select></div></div>
      <div class="row wide" id="plFileRow" style="display:none"><label>Path / URL</label><div class="ctl"><input type="text" id="plPath" placeholder="local/playlists/walk-in.m3u  or  https://…/list.m3u8"></div></div>
      <div style="display:flex;gap:6px;align-items:center;margin-top:6px"><button class="btn sm" id="plLoad">${I('refresh')}Load</button><span class="small muted" id="plInfo"></span></div>
      <div class="gtile" draggable="true" id="plTile" style="margin-top:6px;padding:8px;flex-direction:row;align-items:center;opacity:.45">${I('book')}<b>Drag playlist to a slot</b></div>
      <div class="hint">The whole list plays on one layer, one item after another, and stays linked: new files in the folder or edits to the list are picked up automatically.</div></div>`;
  };
  document.addEventListener('change', e => { if (e.target.id === 'plKind') { const f = e.target.value === 'folder'; $('#plFolderRow').style.display = f ? '' : 'none'; $('#plFileRow').style.display = f ? 'none' : ''; } });
  document.addEventListener('click', async e => {
    if (!e.target.closest('#plLoad')) return;
    const kind = $('#plKind').value === 'folder' ? 'folder' : 'file', p = kind === 'folder' ? $('#plFolder').value : $('#plPath').value.trim();
    if (!p) return UI.toast('Choose a folder or enter a playlist path', 'err');
    $('#plInfo').textContent = 'Loading…';
    try { const r = await UI.api('/api/playlist/resolve', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ext: { kind, path: p } }) });
      if (!r.items.length) { made = null; $('#plInfo').textContent = r.error || 'Nothing playable found'; $('#plTile').style.opacity = .45; return; }
      made = { type: 'playlist', name: p.split('/').pop().replace(/\.(m3u8?|pls|txt)$/i, '') || 'Playlist', ext: { kind, path: p }, items: r.items, index: 0, order: 'sequential', loop: true, imageSecs: 8, fit: 'fit' };
      $('#plInfo').textContent = fmtN(r.items.length) + ' · ' + r.items.slice(0, 3).map(i => i.name).join(', ') + (r.items.length > 3 ? '…' : ''); $('#plTile').style.opacity = 1;
    } catch (er) { $('#plInfo').textContent = er.message; }
  });
  document.addEventListener('dragstart', e => { if (e.target.id !== 'plTile') return; if (!made) { e.preventDefault(); UI.toast('Load a playlist first', 'err'); return; } e.dataTransfer.setData('bvj/clip', JSON.stringify(made)); });

  // ---- Clip panel section
  UI.playlistSection = function (c, li, ci, b, layer) {
    const items = c.items || [], cur = (c.index || 0) % Math.max(1, items.length), live = layer.active === ci;
    return sec(`Playlist <span class="muted small">${fmtN(items.length)}</span>`, `
      <div style="display:flex;gap:4px;margin-bottom:6px"><button class="btn sm" data-pl="prev" data-li="${li}" data-ci="${ci}">⏮ Previous</button><button class="btn sm primary" data-pl="next" data-li="${li}" data-ci="${ci}">Next ⏭</button>
        ${c.ext ? `<button class="btn sm" data-pl="refresh" data-li="${li}" data-ci="${ci}" title="Re-read the folder / playlist now">${I('refresh')}Refresh</button>` : ''}</div>
      <div class="plitems" data-plitems="${li}:${ci}">${items.map((it, i) => `<div class="plitem ${i === cur ? (live ? 'on' : 'next') : ''}" data-plgo="${i}" data-li="${li}" data-ci="${ci}" draggable="true"><span class="mono muted">${i + 1}</span>${I(it.kind === 'image' ? 'eye' : 'play')}<span class="pln">${esc(it.name || it.src)}</span>${it.dur ? `<span class="mono muted small">${Math.round(it.dur)}s</span>` : ''}${c.ext ? '' : `<button class="btn sm icon" data-pldel="${i}" data-li="${li}" data-ci="${ci}" title="Remove">✕</button>`}</div>`).join('') || '<p class="muted small">Empty — drag media from the library here.</p>'}</div>
      <div class="row wide"><label>Order</label><div class="ctl">${UI.seg(b + '.order', [['sequential', 'In order'], ['shuffle', 'Shuffle']])}</div></div>
      ${UI.rToggle('Loop the list', b + '.loop')}${UI.rNum('Stills (seconds)', b + '.imageSecs', 1, 1, 3600)}
      <div class="hint">${c.ext ? `Linked to <span class="mono">${esc(c.ext.path)}</span> (${c.ext.kind === 'folder' ? 'folder' : 'playlist'}); checked every 30 s${c.extError ? ` — <span style="color:var(--red)">${esc(c.extError)}</span>` : ''}. ` : 'Drag files from the library onto the list to add them; drag rows to reorder. '}Videos play to their end, stills for the time set (or the #EXTINF length). Cues and MIDI can use Next / Previous.</div>`);
  };
  const plCmd = (o, d) => UI.cmd(Object.assign({ op: 'playlist', layer: +d.li, clip: +d.ci }, o));
  document.addEventListener('click', e => {
    const t = e.target.closest('[data-pl],[data-plgo],[data-pldel]'); if (!t || !t.closest('#rpane')) return; const d = t.dataset;
    if (d.pldel != null) { e.stopPropagation(); const c = UI.st().layers[+d.li].clips[+d.ci], items = c.items.slice(); items.splice(+d.pldel, 1); BVJ.set(`layers.${d.li}.clips.${d.ci}.items`, items); return; }
    if (d.pl) return plCmd({ a: d.pl }, d); if (d.plgo != null) return plCmd({ a: 'goto', index: +d.plgo }, d);
  });
  // drag library files in, drag rows to reorder
  let dragRow = null;
  document.addEventListener('dragstart', e => { const r = e.target.closest && e.target.closest('.plitem'); if (r) { dragRow = +r.dataset.plgo; e.dataTransfer.setData('text/plain', 'plrow'); } });
  document.addEventListener('dragover', e => { if (e.target.closest && e.target.closest('[data-plitems]')) e.preventDefault(); });
  document.addEventListener('drop', e => {
    const box = e.target.closest && e.target.closest('[data-plitems]'); if (!box) return; e.preventDefault(); e.stopPropagation();
    const [li, ci] = box.dataset.plitems.split(':').map(Number), c = UI.st().layers[li].clips[ci]; if (!c || c.ext) { if (c && c.ext) UI.toast('This playlist is linked to ' + c.ext.path + ' — edit the folder or file instead'); return; }
    const items = (c.items || []).slice(), row = e.target.closest('.plitem'), at = row ? +row.dataset.plgo : items.length;
    if (dragRow != null) { const [m] = items.splice(dragRow, 1); items.splice(at > dragRow ? at - 1 : at, 0, m); dragRow = null; }
    else { let clip = null; try { clip = JSON.parse(e.dataTransfer.getData('bvj/clip') || 'null'); } catch {} if (!clip || !clip.src) return; items.splice(at, 0, { src: clip.src, name: clip.name || clip.src.split('/').pop(), kind: clip.type === 'image' ? 'image' : 'video' }); }
    BVJ.set(`layers.${li}.clips.${ci}.items`, items);
  }, true);
})();
