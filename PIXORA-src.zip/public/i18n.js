/* PIXORA — interface languages. The controller is written in English; this translates what is on screen (text, button labels,
 * tooltips, placeholders) from a dictionary keyed by the English text, as the UI re-renders. Each operator picks a language
 * for their own screen. Packs: /i18n/<lang>.json (built in) plus an optional custom pack per language imported in the app.
 * Names you type (layers, clips, cues…) are never translated, and nothing about the show changes. */
(function () {
  'use strict';
  const BUILTIN = { en: 'English', es: 'Español', fr: 'Français', de: 'Deutsch', pt: 'Português', ja: '日本語' };
  const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'TEXTAREA', 'CODE', 'PRE', 'INPUT', 'SELECT__NOT', 'svg', 'SVG']);
  const ATTRS = ['title', 'placeholder', 'aria-label', 'data-tip'];
  let lang = 'en', dict = new Map(), values = new Set(), patterns = [], missing = new Map(), observer = null, applying = false;
  const I = window.PX_I18N = { lang: () => lang, languages: () => Object.assign({}, BUILTIN, customNames()), t, set, apply, missing: () => [...missing.keys()], exportMissing, importPack, removePack, ready: null };

  function customNames() { try { return JSON.parse(localStorage.pxI18nCustomNames || '{}'); } catch { return {}; } }
  function t(s) {
    if (lang === 'en' || s == null) return s; const str = String(s), core = str.trim(); if (!core) return str;
    let tr = dict.get(core);
    if (tr == null) for (const p of patterns) { const m = p.re.exec(core); if (m) { tr = p.out.replace(/\{(\w+)\}/g, (_, k) => m.groups[k] ?? ''); break; } }
    if (tr == null && values.has(core)) return str; // already translated text seen again
    if (tr == null) { if (/[a-z]{3}/.test(core) && core.length < 120 && !/^[\w.-]+\.(mp4|mov|png|jpg|cube|fs|pixora)$/i.test(core)) missing.set(core, (missing.get(core) || 0) + 1); return str; }
    const lead = str.match(/^\s*/)[0], trail = str.match(/\s*$/)[0]; return lead + tr + trail;
  }
  function compile(obj) {
    dict = new Map(); patterns = [];
    for (const [k, v] of Object.entries(obj || {})) { if (typeof v !== 'string' || !v) continue;
      if (/\{\w+\}/.test(k)) { const names = []; const re = new RegExp('^' + k.replace(/[.*+?^$()|[\]\\]/g, '\\$&').replace(/\\?\{(\w+)\\?\}/g, (_, n) => { names.push(n); return `(?<${n}>.+?)`; }) + '$'); patterns.push({ re, out: v }); }
      else dict.set(k, v); }
    values = new Set(dict.values());
  }
  async function load(code) {
    let obj = {};
    if (code !== 'en' && BUILTIN[code]) { try { obj = await fetch('/i18n/' + code + '.json', { cache: 'no-cache' }).then(r => r.ok ? r.json() : {}); } catch {} }
    try { Object.assign(obj, JSON.parse(localStorage['pxI18nCustom_' + code] || '{}')); } catch {}
    return obj;
  }
  // walk a subtree, translating text nodes and a few attributes; originals are kept so switching back is exact
  function apply(root) {
    if (lang === 'en' && !root.__pxI18nTouched) return; applying = true;
    try {
      const w = document.createTreeWalker(root || document.body, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT, { acceptNode(n) {
        if (n.nodeType === 1) { if (SKIP_TAGS.has(n.tagName) || n.closest && n.closest('[data-noi18n],.mono,[contenteditable]')) return NodeFilter.FILTER_REJECT; return NodeFilter.FILTER_ACCEPT; }
        return NodeFilter.FILTER_ACCEPT; } });
      for (let n = w.currentNode; n; n = w.nextNode()) {
        if (n.nodeType === 3) { if (!n.parentElement || n.parentElement.closest('[data-noi18n],.mono,textarea,script,style')) continue; const orig = n.__pxOrig ?? n.nodeValue; if (!/[A-Za-z]/.test(orig)) continue;
          const tr = lang === 'en' ? orig : t(orig); if (tr !== orig) n.__pxOrig = orig; if (n.nodeValue !== tr) n.nodeValue = tr; n.__pxSet = tr; }
        else for (const a of ATTRS) { if (!n.hasAttribute || !n.hasAttribute(a)) continue; const key = '__pxA_' + a, orig = n[key] ?? n.getAttribute(a); const tr = lang === 'en' ? orig : t(orig);
          if (tr !== orig) n[key] = orig; if (n.getAttribute(a) !== tr) n.setAttribute(a, tr); n['__pxS_' + a] = tr; }
      }
      if (root) root.__pxI18nTouched = lang !== 'en';
    } finally { applying = false; }
  }
  function watch() {
    if (observer) return; observer = new MutationObserver(list => { if (applying || lang === 'en') return;
      for (const m of list) { if (m.type === 'characterData') { const n = m.target; if (n.nodeValue === n.__pxSet) continue; // our own change
          n.__pxOrig = undefined; apply(n.parentElement || document.body); }
        else if (m.type === 'attributes') { const el = m.target, a = m.attributeName; if (el.getAttribute(a) === el['__pxS_' + a]) continue; delete el['__pxA_' + a]; apply(el); }
        else for (const n of m.addedNodes) apply(n.nodeType === 1 ? n : n.parentElement || document.body); } });
    observer.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  }
  async function set(code, opts) {
    code = (I.languages()[code] ? code : 'en'); const obj = await load(code); lang = code; compile(obj); missing = new Map();
    try { localStorage.pxLang = code; } catch {}
    document.documentElement.lang = code; document.body.__pxI18nTouched = true; apply(document.body); if (code !== 'en') watch();
    if (!(opts && opts.silent) && window.UI && UI.renderAll) try { UI.renderAll(); } catch {}
    window.dispatchEvent(new CustomEvent('px-lang', { detail: code })); return code;
  }
  // translators: everything seen on screen that has no translation yet, as a JSON pack to fill in
  function exportMissing() {
    const base = {}; for (const k of [...missing.keys()].sort()) base[k] = ''; return JSON.stringify({ '//': `PIXORA ${BUILTIN[lang] || lang} pack — fill in the empty values, then Import it under Interface language.`, ...base }, null, 1);
  }
  function importPack(code, name, obj) {
    if (!/^[a-z]{2}(-[A-Za-z]{2,4})?$/.test(code)) throw new Error('language code like "it" or "pt-BR"'); const clean = {};
    for (const [k, v] of Object.entries(obj || {})) if (k !== '//' && typeof v === 'string' && v.trim()) clean[k] = v.slice(0, 400);
    localStorage['pxI18nCustom_' + code] = JSON.stringify(clean); if (!BUILTIN[code]) { const n = customNames(); n[code] = name || code; localStorage.pxI18nCustomNames = JSON.stringify(n); }
    return Object.keys(clean).length;
  }
  function removePack(code) { delete localStorage['pxI18nCustom_' + code]; const n = customNames(); delete n[code]; localStorage.pxI18nCustomNames = JSON.stringify(n); }

  const want = (() => { try { if (localStorage.pxLang) return localStorage.pxLang; } catch {} const nav = (navigator.language || 'en').slice(0, 2).toLowerCase(); return BUILTIN[nav] ? nav : 'en'; })();
  const start = () => { I.ready = set(want, { silent: true }); };
  if (document.body) start(); else document.addEventListener('DOMContentLoaded', start);
})();
