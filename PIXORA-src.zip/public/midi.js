/* PIXORA MIDI: learn, controller auto-map profiles with LED feedback, MTC + LTC timecode readers. */
(function () {
  const M = window.BVJMidi = {
    access: null, ok: false, error: '', inId: localStorage.bvjMidiIn || '', outId: localStorage.bvjMidiOut || '',
    profile: +(localStorage.bvjMidiProfile || 0), feedback: localStorage.bvjMidiFb !== '0',
    bindings: JSON.parse(localStorage.bvjMidiBindings || '[]'), learn: false, learnTarget: null, lastMsg: '', onChange: () => {},
    tc: { mtcIn: localStorage.bvjMtcIn || '', ltcDev: localStorage.bvjLtcDev || '', frames: null, fps: 25, ltcOn: false, label: '' },
  };
  const save = () => { localStorage.bvjMidiIn = M.inId; localStorage.bvjMidiOut = M.outId; localStorage.bvjMidiProfile = M.profile; localStorage.bvjMidiFb = M.feedback ? '1' : '0'; localStorage.bvjMidiBindings = JSON.stringify(M.bindings); localStorage.bvjMtcIn = M.tc.mtcIn; localStorage.bvjLtcDev = M.tc.ltcDev; };
  M.save = save;

  M.init = async function () {
    if (!navigator.requestMIDIAccess) { M.error = 'Web MIDI is not supported in this browser (use Chrome or Edge).'; M.onChange(); return; }
    try { M.access = await navigator.requestMIDIAccess({ sysex: true }); }
    catch { try { M.access = await navigator.requestMIDIAccess(); } catch (e) { M.error = 'MIDI access denied: ' + e.message + ' (Web MIDI needs http://localhost or https).'; M.onChange(); return; } }
    M.ok = true; M.access.onstatechange = () => { attach(); M.onChange(); }; attach(); M.onChange();
  };
  M.inputs = () => M.access ? [...M.access.inputs.values()] : [];
  M.outputs = () => M.access ? [...M.access.outputs.values()] : [];
  function attach() {
    for (const i of M.inputs()) i.onmidimessage = e => handle(e.data, i);
    sentLeds.clear(); programmerMode();
  }
  function out() { return M.outputs().find(o => o.id === M.outId) || null; }
  M.setOut = id => { M.outId = id; save(); sentLeds.clear(); programmerMode(); M.refreshLeds(); };
  M.setProfile = p => { M.profile = +p; save(); sentLeds.clear(); programmerMode(); M.refreshLeds(); M.onChange(); };

  /* ---------------- incoming */
  function handle(d, input) {
    if (!d || !d.length) return;
    if (d[0] === 0xF1 && (!M.tc.mtcIn || M.tc.mtcIn === input.id)) return mtcQuarter(d[1]);
    if (d[0] === 0xF0 && d[1] === 0x7F && d[3] === 0x01 && d[4] === 0x01) return mtcFull(d);
    if (M.inId && input.id !== M.inId) return;
    const st = d[0] & 0xf0, ch = d[0] & 0x0f;
    const isNoteOn = st === 0x90 && d[2] > 0, isCC = st === 0xB0;
    if (!isNoteOn && !isCC) return;
    const key = (isCC ? 'c' : 'n') + ':' + ch + ':' + d[1];
    M.lastMsg = (isCC ? 'CC ' : 'Note ') + d[1] + ' ch' + (ch + 1) + ' = ' + d[2]; M.onChange('msg');
    if (M.learn && M.learnTarget) {
      M.bindings = M.bindings.filter(b => b.key !== key && JSON.stringify(b.action) !== JSON.stringify(M.learnTarget.action));
      M.bindings.push({ key, action: M.learnTarget.action, label: M.learnTarget.label || '' }); save();
      M.onLearned && M.onLearned(key, M.learnTarget); M.learnTarget = null; M.onChange(); return;
    }
    let used = false;
    for (const b of M.bindings) if (b.key === key) { run(b.action, d[2], isCC); used = true; }
    if (!used) autoMap(isCC, d[1], d[2]);
  }
  function run(a, v, isCC) {
    const s = BVJ.state; if (!s) return;
    switch (a.type) {
      case 'trigger': BVJ.cmd({ op: 'trigger', layer: a.layer, clip: a.clip }); break;
      case 'column': BVJ.cmd({ op: 'column', col: a.col }); break;
      case 'tap': BVJ.tap(); break;
      case 'cmd': BVJ.cmd(a.cmd); break;
      case 'set': {
        if (isCC) BVJ.set(a.path, +a.min + (v / 127) * (+a.max - +a.min));
        else { const cur = BVJ.get(a.path); BVJ.set(a.path, Math.abs(cur - a.max) < 1e-6 ? +a.min : +a.max); }
        break;
      }
      case 'toggle': BVJ.set(a.path, !BVJ.get(a.path)); break;
    }
  }
  // Controller profiles: grid rows = layers (bottom row = layer 1), grid columns = clip columns.
  function autoMap(isCC, n, v) {
    const s = BVJ.state; if (!s) return; const p = M.profile;
    if (p === 1) { // Akai APC Mini mk2
      if (!isCC && n <= 63) { const row = Math.floor(n / 8), col = n % 8; if (s.layers[row]) BVJ.cmd({ op: 'trigger', layer: row, clip: col }); }
      else if (!isCC && n >= 100 && n <= 107) BVJ.cmd({ op: 'column', col: n - 100 });
      else if (!isCC && n >= 112 && n <= 119) { const row = 119 - n; if (s.layers[row]) BVJ.cmd({ op: 'clearLayer', layer: row }); }
      else if (!isCC && n === 122) BVJ.cmd({ op: 'clearAll' }); // Shift
      else if (isCC && n >= 48 && n <= 55) { const li = n - 48; if (s.layers[li]) BVJ.set(`layers.${li}.opacity`, v / 127); }
      else if (isCC && n === 56) BVJ.set('comp.master', v / 127);
    } else if (p >= 2) { // Launchpads in Programmer mode
      if (!isCC && n >= 11 && n <= 88 && n % 10 >= 1 && n % 10 <= 8) { const row = Math.floor(n / 10) - 1, col = n % 10 - 1; if (s.layers[row]) BVJ.cmd({ op: 'trigger', layer: row, clip: col }); }
      else if (isCC && v > 0 && n >= 91 && n <= 98) BVJ.cmd({ op: 'column', col: n - 91 });
      else if (isCC && v > 0 && n % 10 === 9 && n >= 19 && n <= 89) { const row = Math.floor(n / 10) - 1; if (s.layers[row]) BVJ.cmd({ op: 'clearLayer', layer: row }); }
    }
  }

  /* ---------------- LED feedback */
  const sentLeds = new Map();
  function send(bytes) { const o = out(); if (o) try { o.send(bytes); } catch {} }
  function led(kind, n, color, ch) { const k = kind + n; const v = (ch || 0) * 1000 + color; if (sentLeds.get(k) === v) return; sentLeds.set(k, v); send([(kind === 'c' ? 0xB0 : 0x90) | (ch || 0), n, color]); }
  function programmerMode() {
    const o = out(); if (!o || M.profile < 2) return;
    const dev = { 2: 0x0D, 3: 0x0C, 4: 0x0E }[M.profile];
    try { o.send([0xF0, 0x00, 0x20, 0x29, 0x02, dev, 0x0E, 0x01, 0xF7]); } catch (e) { /* needs sysex permission */ }
  }
  const TYPE_COL = { video: 21, image: 13, gen: 37, web: 45, capture: 5, screen: 5, ndi: 53 };
  M.refreshLeds = function () {
    const s = BVJ.state; if (!s || !M.feedback || !out() || M.profile === 0) return;
    for (let row = 0; row < 8; row++) {
      const l = s.layers[row];
      for (let col = 0; col < 8; col++) {
        const has = l && l.clips[col], act = l && l.active === col;
        // pad colour shows the clip type: video green, image yellow, generator cyan, web blue, live input red, NDI purple
        const tc = has ? (TYPE_COL[has.type] || 9) : 0;
        if (M.profile === 1) led('n', row * 8 + col, act ? tc || 21 : tc, act ? 6 : has ? 1 : 0); // APC Mini mk2: channel = brightness (1 dim, 6 full)
        else led('n', (row + 1) * 10 + col + 1, act ? tc || 21 : has ? tc + 2 : 0, act ? 2 : 0); // Launchpad: dim palette variant; active pulses (MIDI ch 3)
      }
      if (M.profile === 1) led('n', 119 - row, l && l.active != null ? 1 : 0, 0);
      else led('c', (row + 1) * 10 + 9, l && l.active != null ? 21 : l ? 1 : 0, 0);
    }
    for (let col = 0; col < 8; col++) {
      const any = s.layers.some(l => l.clips[col]);
      if (M.profile === 1) led('n', 100 + col, any ? 1 : 0, 0); else led('c', 91 + col, any ? 45 : 0, 0);
    }
  };

  /* ---------------- MTC + LTC readers (decoders in tc-decoders.js) */
  const TCD = window.PixoraTC;
  const mtc = new TCD.MtcDecoder(fr => emitTc('mtc', fr));
  function mtcQuarter(b) { mtc.quarter(b); }
  function mtcFull(d) { mtc.sysex(d); }
  let lastSent = 0;
  function emitTc(src, fr) {
    M.tc.frames = fr.frames; M.tc.fps = fr.fps; M.tc.drop = fr.drop; M.tc.reverse = fr.reverse; M.tc.level = fr.level || 0;
    M.tc.label = src.toUpperCase() + ' ' + fr.label + (fr.reverse ? ' ◀' : ''); M.tc.at = performance.now();
    const now = performance.now(); if (now - lastSent > 30) { lastSent = now; BVJ.raw({ t: 'tc', src, frames: fr.frames, fps: fr.fps, drop: fr.drop, reverse: fr.reverse, level: fr.level || 0 }); }
    M.onChange('tc');
  }
  let ltc = null;
  M.ltcStart = async function (deviceId) {
    M.ltcStop();
    const stream = await navigator.mediaDevices.getUserMedia({ audio: { deviceId: deviceId ? { exact: deviceId } : undefined, echoCancellation: false, noiseSuppression: false, autoGainControl: false, channelCount: { ideal: 2 } } });
    const ctx = new AudioContext(); const src = ctx.createMediaStreamSource(stream); const proc = ctx.createScriptProcessor(2048, 2, 1);
    const ch = () => +((BVJ.state && BVJ.state.comp.timecode.ltcChannel) || 0); // 0 = left / mono, 1 = right
    const dec = new TCD.LtcDecoder(ctx.sampleRate, fr => emitTc('ltc', fr));
    proc.onaudioprocess = e => { const b = e.inputBuffer; dec.push(b.getChannelData(Math.min(ch(), b.numberOfChannels - 1))); M.tc.inLevel = dec.peak; };
    src.connect(proc); proc.connect(ctx.destination);
    ltc = { stream, ctx, proc, dec }; M.tc.ltcOn = true; M.onChange();
  };
  M.ltcStop = function () { if (ltc) { ltc.stream.getTracks().forEach(t => t.stop()); ltc.ctx.close(); ltc = null; } M.tc.ltcOn = false; };
})();
