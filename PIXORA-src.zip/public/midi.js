/* PIXORA MIDI: learn, controller auto-map profiles with LED feedback, MTC + LTC timecode readers. */
(function () {
  const M = window.BVJMidi = {
    access: null, ok: false, error: '', inId: localStorage.bvjMidiIn || '', outId: localStorage.bvjMidiOut || '',
    profile: +(localStorage.bvjMidiProfile || 0), feedback: localStorage.bvjMidiFb !== '0',
    bindings: JSON.parse(localStorage.bvjMidiBindings || '[]'), learn: false, learnTarget: null, lastMsg: '', onChange: () => {},
    tc: { mtcIn: localStorage.bvjMtcIn || '', ltcDev: localStorage.bvjLtcDev || '', frames: null, fps: 25, ltcOn: false, label: '' },
  };
  const save = () => { localStorage.bvjMidiIn = M.inId; localStorage.bvjMidiOut = M.outId; localStorage.bvjMidiProfile = M.profile; localStorage.bvjMidiFb = M.feedback ? '1' : '0'; localStorage.bvjMidiBindings = JSON.stringify(M.bindings); localStorage.bvjMtcIn = M.tc.mtcIn; localStorage.bvjLtcDev = M.tc.ltcDev; };
  M.save = save;

  M.init = async function () {
    if (!navigator.requestMIDIAccess) { M.error = 'Web MIDI is not supported in this browser (use Chrome or Edge).'; M.onChange(); return; }
    try { M.access = await navigator.requestMIDIAccess({ sysex: true }); }
    catch { try { M.access = await navigator.requestMIDIAccess(); } catch (e) { M.error = 'MIDI access denied: ' + e.message + ' (Web MIDI needs http://localhost or https).'; M.onChange(); return; } }
    M.ok = true; M.access.onstatechange = () => { attach(); M.onChange(); }; attach(); M.onChange();
  };
  M.inputs = () => M.access ? [...M.access.inputs.values()] : [];
  M.outputs = () => M.access ? [...M.access.outputs.values()] : [];
  function attach() {
    for (const i of M.inputs()) i.onmidimessage = e => handle(e.data, i);
    sentLeds.clear(); programmerMode();
  }
  function out() { return M.outputs().find(o => o.id === M.outId) || null; }
  M.setOut = id => { M.outId = id; save(); sentLeds.clear(); programmerMode(); M.refreshLeds(); };
  M.setProfile = p => { M.profile = +p; save(); sentLeds.clear(); programmerMode(); M.refreshLeds(); M.onChange(); };

  /* ---------------- incoming */
  function handle(d, input) {
    if (!d || !d.length) return;
    if (d[0] === 0xF1 && (!M.tc.mtcIn || M.tc.mtcIn === input.id)) return mtcQuarter(d[1]);
    if (d[0] === 0xF0 && d[1] === 0x7F && d[3] === 0x01 && d[4] === 0x01) return mtcFull(d);
    if (M.inId && input.id !== M.inId) return;
    const st = d[0] & 0xf0, ch = d[0] & 0x0f;
    const isNoteOn = st === 0x90 && d[2] > 0, isCC = st === 0xB0;
    if (!isNoteOn && !isCC) return;
    const key = (isCC ? 'c' : 'n') + ':' + ch + ':' + d[1];
    M.lastMsg = (isCC ? 'CC ' : 'Note ') + d[1] + ' ch' + (ch + 1) + ' = ' + d[2]; M.onChange('msg');
    if (M.learn && M.learnTarget) {
      M.bindings = M.bindings.filter(b => b.key !== key && JSON.stringify(b.action) !== JSON.stringify(M.learnTarget.action));
      M.bindings.push({ key, action: M.learnTarget.action, label: M.learnTarget.label || '' }); save();
      M.onLearned && M.onLearned(key, M.learnTarget); M.learnTarget = null; M.onChange(); return;
    }
    let used = false;
    for (const b of M.bindings) if (b.key === key) { run(b.action, d[2], isCC); used = true; }
    if (!used) autoMap(isCC, d[1], d[2]);
  }
  function run(a, v, isCC) {
    const s = BVJ.state; if (!s) return;
    switch (a.type) {
      case 'trigger': BVJ.cmd({ op: 'trigger', layer: a.layer, clip: a.clip }); break;
      case 'column': BVJ.cmd({ op: 'column', col: a.col }); break;
      case 'tap': BVJ.tap(); break;
      case 'cmd': BVJ.cmd(a.cmd); break;
      case 'set': {
        if (isCC) BVJ.set(a.path, +a.min + (v / 127) * (+a.max - +a.min));
        else { const cur = BVJ.get(a.path); BVJ.set(a.path, Math.abs(cur - a.max) < 1e-6 ? +a.min : +a.max); }
        break;
      }
      case 'toggle': BVJ.set(a.path, !BVJ.get(a.path)); break;
    }
  }
  // Controller profiles: grid rows = layers (bottom row = layer 1), grid columns = clip columns.
  function autoMap(isCC, n, v) {
    const s = BVJ.state; if (!s) return; const p = M.profile;
    if (p === 1) { // Akai APC Mini mk2
      if (!isCC && n <= 63) { const row = Math.floor(n / 8), col = n % 8; if (s.layers[row]) BVJ.cmd({ op: 'trigger', layer: row, clip: col }); }
      else if (!isCC && n >= 100 && n <= 107) BVJ.cmd({ op: 'column', col: n - 100 });
      else if (!isCC && n >= 112 && n <= 119) { const row = 119 - n; if (s.layers[row]) BVJ.cmd({ op: 'clearLayer', layer: row }); }
      else if (!isCC && n === 122) BVJ.cmd({ op: 'clearAll' }); // Shift
      else if (isCC && n >= 48 && n <= 55) { const li = n - 48; if (s.layers[li]) BVJ.set(`layers.${li}.opacity`, v / 127); }
      else if (isCC && n === 56) BVJ.set('comp.master', v / 127);
    } else if (p >= 2) { // Launchpads in Programmer mode
      if (!isCC && n >= 11 && n <= 88 && n % 10 >= 1 && n % 10 <= 8) { const row = Math.floor(n / 10) - 1, col = n % 10 - 1; if (s.layers[row]) BVJ.cmd({ op: 'trigger', layer: row, clip: col }); }
      else if (isCC && v > 0 && n >= 91 && n <= 98) BVJ.cmd({ op: 'column', col: n - 91 });
      else if (isCC && v > 0 && n % 10 === 9 && n >= 19 && n <= 89) { const row = Math.floor(n / 10) - 1; if (s.layers[row]) BVJ.cmd({ op: 'clearLayer', layer: row }); }
    }
  }

  /* ---------------- LED feedback */
  const sentLeds = new Map();
  function send(bytes) { const o = out(); if (o) try { o.send(bytes); } catch {} }
  function led(kind, n, color, ch) { const k = kind + n; const v = (ch || 0) * 1000 + color; if (sentLeds.get(k) === v) return; sentLeds.set(k, v); send([(kind === 'c' ? 0xB0 : 0x90) | (ch || 0), n, color]); }
  function programmerMode() {
    const o = out(); if (!o || M.profile < 2) return;
    const dev = { 2: 0x0D, 3: 0x0C, 4: 0x0E }[M.profile];
    try { o.send([0xF0, 0x00, 0x20, 0x29, 0x02, dev, 0x0E, 0x01, 0xF7]); } catch (e) { /* needs sysex permission */ }
  }
  const TYPE_COL = { video: 21, image: 13, gen: 37, web: 45, capture: 5, screen: 5, ndi: 53 };
  M.refreshLeds = function () {
    const s = BVJ.state; if (!s || !M.feedback || !out() || M.profile === 0) return;
    for (let row = 0; row < 8; row++) {
      const l = s.layers[row];
      for (let col = 0; col < 8; col++) {
        const has = l && l.clips[col], act = l && l.active === col;
        // pad colour shows the clip type: video green, image yellow, generator cyan, web blue, live input red, NDI purple
        const tc = has ? (TYPE_COL[has.type] || 9) : 0;
        if (M.profile === 1) led('n', row * 8 + col, act ? tc || 21 : tc, act ? 6 : has ? 1 : 0); // APC Mini mk2: channel = brightness (1 dim, 6 full)
        else led('n', (row + 1) * 10 + col + 1, act ? tc || 21 : has ? tc + 2 : 0, act ? 2 : 0); // Launchpad: dim palette variant; active pulses (MIDI ch 3)
      }
      if (M.profile === 1) led('n', 119 - row, l && l.active != null ? 1 : 0, 0);
      else led('c', (row + 1) * 10 + 9, l && l.active != null ? 21 : l ? 1 : 0, 0);
    }
    for (let col = 0; col < 8; col++) {
      const any = s.layers.some(l => l.clips[col]);
      if (M.profile === 1) led('n', 100 + col, any ? 1 : 0, 0); else led('c', 91 + col, any ? 45 : 0, 0);
    }
  };

  /* ---------------- MTC */
  const q = new Array(8).fill(0); let qCount = 0;
  function mtcQuarter(b) {
    const piece = b >> 4, val = b & 0x0f; q[piece] = val; qCount++;
    if (piece === 7 && qCount >= 8) {
      const fr = q[0] | (q[1] << 4), sc = q[2] | (q[3] << 4), mn = q[4] | (q[5] << 4), hr = q[6] | ((q[7] & 1) << 4);
      const rate = [24, 25, 29.97, 30][(q[7] >> 1) & 3]; qCount = 0;
      emitTc('mtc', hr, mn, sc, fr + 2, rate); // +2 frames: MTC quarter frames lag by two frames
    }
  }
  function mtcFull(d) { const hr = d[5] & 0x1f, rate = [24, 25, 29.97, 30][(d[5] >> 5) & 3]; emitTc('mtc', hr, d[6], d[7], d[8], rate); }
  let lastSent = 0;
  function emitTc(src, h, m, s, f, rate) {
    const fps = (BVJ.state && BVJ.state.comp.timecode.fps) || Math.round(rate) || 25;
    const frames = ((h * 60 + m) * 60 + s) * fps + f;
    M.tc.frames = frames; M.tc.fps = fps; M.tc.label = src.toUpperCase() + ' ' + [h, m, s, f].map(x => String(x).padStart(2, '0')).join(':');
    const now = performance.now(); if (now - lastSent > 30) { lastSent = now; BVJ.raw({ t: 'tc', src, frames, fps }); }
    M.onChange('tc');
  }

  /* ---------------- LTC (SMPTE linear timecode decoded from an audio input) */
  let ltc = null;
  M.ltcStart = async function (deviceId) {
    M.ltcStop();
    const stream = await navigator.mediaDevices.getUserMedia({ audio: { deviceId: deviceId ? { exact: deviceId } : undefined, echoCancellation: false, noiseSuppression: false, autoGainControl: false } });
    const ctx = new AudioContext(); const src = ctx.createMediaStreamSource(stream); const proc = ctx.createScriptProcessor(1024, 1, 1);
    const sr = ctx.sampleRate; const dec = { sign: 0, since: 0, period: sr / (25 * 80), half: false, bits: [], maxFrame: 0 };
    proc.onaudioprocess = e => {
      const x = e.inputBuffer.getChannelData(0);
      for (let i = 0; i < x.length; i++) {
        dec.since++;
        const v = x[i]; const sgn = v > 0.02 ? 1 : v < -0.02 ? -1 : dec.sign;
        if (sgn !== dec.sign && dec.sign !== 0) { ltcEdge(dec, dec.since, sr); dec.since = 0; }
        dec.sign = sgn;
      }
    };
    src.connect(proc); proc.connect(ctx.destination);
    ltc = { stream, ctx, proc }; M.tc.ltcOn = true; M.onChange();
  };
  M.ltcStop = function () { if (ltc) { ltc.stream.getTracks().forEach(t => t.stop()); ltc.ctx.close(); ltc = null; } M.tc.ltcOn = false; };
  const SYNC = [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1];
  function ltcEdge(d, n, sr) {
    const lo = sr / (30 * 80) * 0.8, hi = sr / (24 * 80) * 1.25;
    if (n < d.period * 0.75) { // half bit
      d.period = Math.min(hi, Math.max(lo, d.period * 0.95 + n * 2 * 0.05));
      if (d.half) { pushBit(d, 1); d.half = false; } else d.half = true;
    } else if (n < d.period * 1.5) { d.period = Math.min(hi, Math.max(lo, d.period * 0.95 + n * 0.05)); pushBit(d, 0); d.half = false; }
    else { d.half = false; } // gap / noise
  }
  function pushBit(d, b) {
    d.bits.push(b); if (d.bits.length > 80) d.bits.shift();
    if (d.bits.length < 80) return;
    for (let i = 0; i < 16; i++) if (d.bits[64 + i] !== SYNC[i]) return;
    const v = (o, n) => { let r = 0; for (let i = 0; i < n; i++) r |= d.bits[o + i] << i; return r; };
    const f = v(0, 4) + v(8, 2) * 10, s = v(16, 4) + v(24, 3) * 10, m = v(32, 4) + v(40, 3) * 10, h = v(48, 4) + v(56, 2) * 10;
    if (f > 30 || s > 59 || m > 59 || h > 23) return;
    d.maxFrame = Math.max(d.maxFrame, f); const rate = d.maxFrame >= 29 ? 30 : d.maxFrame >= 24 ? 25 : 24;
    emitTc('ltc', h, m, s, f, rate);
  }
})();
