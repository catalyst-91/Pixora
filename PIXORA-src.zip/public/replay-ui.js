/* PIXORA — Replay panel (controller): 4 replay units, marks, events, slow motion, angles. */
(function () {
  const UI = window.UI, $ = UI.$, $$ = UI.$$, esc = UI.esc, I = UI.icon;
  const sec = (title, body, extra) => `<div class="sec"><h4>${title}${extra || ''}</h4>${body}</div>`;
  UI.MORETABS.push(['replay', 'Instant Replay', 'restart', 'Replay']);
  let stats = {};
  (BVJ.extraHandlers = BVJ.extraHandlers || {}).replaystat = m => { stats = Object.fromEntries((m.units || []).map(u => [u.id, u])); if (UI.rtab === 'replay') live(); };
  const R = () => (UI.st() && UI.st().replay) || null;
  const cmd = (a, o) => UI.cmd(Object.assign({ op: 'replay', a }, o || {}));
  const posOf = (p, now) => !p ? now : p.paused ? p.pausedAt : p.at + (now - p.startedAt) * p.speed;
  const t = ms => { const s = Math.max(0, ms) / 1000; return (s >= 60 ? Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0') : Math.floor(s)) + '.' + Math.floor((s % 1) * 10); };
  const KEYS = 'I mark in · O mark out · E save event · R replay last 8 s · Space pause · ←/→ jog · 1–4 angle · L live';

  function live() {
    const r = R(), pane = $('#rpane'); if (!r || !pane || !$('#rpHead', pane)) return;
    for (const u of r.units) { const el = $(`[data-rpstat="${u.id}"]`, pane), s = stats[u.id]; if (el) el.textContent = u.source === 'off' ? 'off' : s ? (s.error ? s.error : `${s.sec}s · ${s.fps} fps · ${s.size} · ${s.mb} MB`) : 'waiting for an output…'; }
    const P = r.play, now = BVJ.now(), head = $('#rpHead', pane);
    if (!P) head.innerHTML = `<b class="rplive">LIVE</b> <span class="muted">angle ${r.selected}</span>${r.mark.in ? ` · in marked ${t(now - r.mark.in)} ago` : ''}${r.mark.out ? ' · out marked' : ''}`;
    else { const p = posOf(P, now), ev = r.events.find(e => e.id === P.event);
      head.innerHTML = `<b class="rpplay">${P.paused ? '❚❚ PAUSED' : '▶ REPLAY'}</b> angle <b>${P.unit}</b> · ${Math.round(P.speed * 100)}% · ${ev ? `${esc(ev.name)} ${t(p - ev.in)} / ${t(ev.out - ev.in)}` : `${t(now - p)} behind live`}`; }
  }
  setInterval(() => { if (UI.rtab === 'replay') live(); }, 100);

  UI.panels.replay = {
    sig: s => JSON.stringify(s.replay && [s.replay.units, s.replay.events, s.replay.selected, s.replay.play && [s.replay.play.unit, s.replay.play.speed, s.replay.play.paused, s.replay.play.event], s.replay.seconds, s.replay.fps, s.replay.size, s.replay.autoTake, !!s.replay.mark.in, s.layers.map(l => l.name)]),
    render(s) {
      const r = s.replay; if (!r) return '<p class="muted">Replay is starting…</p>';
      const P = r.play, hasClip = s.layers.some(l => l.clips.some(c => c && c.type === 'replay'));
      const src = u => `<select data-rpsrc="${u.id}"><option value="off">Off</option><option value="program" ${u.source === 'program' ? 'selected' : ''}>Program output</option>${s.layers.map((l, i) => `<option value="${i}" ${u.source === i ? 'selected' : ''}>Layer ${i + 1} · ${esc(l.name || '')}</option>`).join('')}</select>`;
      let h = `<div class="rphead" id="rpHead"></div>`;
      h += `<div class="rpunits">${r.units.map((u, i) => `<div class="rpunit ${(P ? P.unit : r.selected) === u.id ? 'on' : ''}" data-rpangle="${u.id}"><div class="rpu-top"><b>${u.id}</b><span class="muted small">${i + 1}</span></div>${src(u)}<div class="small mono muted" data-rpstat="${u.id}"></div></div>`).join('')}</div>`;
      h += `<div class="rptrans">
        <button class="btn" data-rp="mark" data-which="in" title="I">Mark in</button><button class="btn" data-rp="mark" data-which="out" title="O">Mark out</button><button class="btn primary" data-rp="event" title="E">Save event</button>
        <span class="rpsep"></span><button class="btn" data-rp="last" title="R">${I('restart')}Last 8 s</button><button class="btn" data-rp="playmark" ${r.mark.in ? '' : 'disabled'}>Play marks</button>
        <span class="rpsep"></span><button class="btn" data-rp="jog" data-ms="-1000">−1 s</button><button class="btn" data-rp="jog" data-ms="${-1000 / r.fps}">◀</button><button class="btn ${P && P.paused ? 'primary' : ''}" data-rp="pause" title="Space">❚❚</button><button class="btn" data-rp="jog" data-ms="${1000 / r.fps}">▶</button><button class="btn" data-rp="jog" data-ms="1000">+1 s</button>
        <span class="rpsep"></span><button class="btn ${P ? 'danger' : ''}" data-rp="live" title="L">LIVE</button></div>`;
      h += `<div class="rpspeed"><span class="small muted">Speed</span>${[0.25, 0.33, 0.5, 0.75, 1].map(v => `<button class="btn sm ${P && Math.abs(P.speed - v) < 0.01 ? 'primary' : ''}" data-rpspeed="${v}">${Math.round(v * 100)}%</button>`).join('')}<input type="range" min="5" max="200" value="${P ? Math.round(P.speed * 100) : 50}" data-rpslide style="flex:1"></div>`;
      h += sec(`Events <span class="muted small">${r.events.length}</span>`, r.events.length ? `<div class="rpevents">${r.events.slice().reverse().map(e => `<div class="rpev ${P && P.event === e.id ? 'on' : ''}">
          <button class="btn sm icon ${e.star ? 'primary' : ''}" data-rpstar="${e.id}" title="Highlight">★</button><input type="text" value="${esc(e.name)}" data-rpname="${e.id}"><span class="mono small muted">${e.unit} · ${t(e.out - e.in)}</span>
          ${[0.25, 0.5, 1].map(v => `<button class="btn sm" data-rpplay="${e.id}" data-speed="${v}">${Math.round(v * 100)}%</button>`).join('')}<button class="btn sm icon" data-rpdel="${e.id}">${I('trash')}</button></div>`).join('')}</div>` : '<p class="muted small">Mark in and out (or just press Save event for the last 8 seconds), then play events back at any speed and switch angles while they play.</p>');
      h += sec('Setup', `<div class="row wide"><label>Buffer</label><div class="ctl"><select data-rpset="seconds">${[30, 60, 90, 120, 180, 300].map(v => `<option value="${v}" ${r.seconds === v ? 'selected' : ''}>${v} seconds</option>`).join('')}</select></div></div>
        <div class="row wide"><label>Record at</label><div class="ctl"><select data-rpset="fps">${[25, 30, 50, 60].map(v => `<option value="${v}" ${r.fps === v ? 'selected' : ''}>${v} fps</option>`).join('')}</select> <select data-rpset="size">${['540p', '720p', '1080p'].map(v => `<option ${r.size === v ? 'selected' : ''}>${v}</option>`).join('')}</select></div></div>
        <div class="row wide"><label>Auto take</label><div class="ctl"><label class="djchk"><input type="checkbox" data-rpset="autoTake" ${r.autoTake ? 'checked' : ''}> Put the Replay clip on air when a replay plays, and back on LIVE</label></div></div>
        ${hasClip ? '' : `<p class="small" style="color:var(--amber,#ffb020)">Drag <b>Replay</b> from Library ▸ Inputs into a slot to put replays on screen.</p>`}
        <p class="muted small">Record at 50 fps and play at 50% for smooth slow motion. Higher sizes and frame rates use more of the graphics chip; each unit holds its buffer in memory (about ${Math.round(({ '540p': 3, '720p': 6, '1080p': 12 })[r.size] / 8 * r.seconds)} MB at this setting).<br>Keys: ${KEYS}</p>`);
      return h;
    },
    after(pane) {
      pane.onclick = e => {
        const b = e.target.closest('button'), ang = e.target.closest('[data-rpangle]');
        if (!b && ang && !e.target.closest('select')) return cmd('angle', { unit: ang.dataset.rpangle });
        if (!b) return; const d = b.dataset;
        if (d.rp === 'mark') return cmd('mark', { which: d.which }); if (d.rp === 'event') return cmd('event');
        if (d.rp === 'last') return cmd('play', { seconds: 8 }); if (d.rp === 'playmark') return cmd('play', { from: 'mark' });
        if (d.rp === 'pause') return R().play ? cmd('pause') : cmd('play', { seconds: 8 }); if (d.rp === 'jog') return cmd('jog', { ms: +d.ms }); if (d.rp === 'live') return cmd('live');
        if (d.rpspeed) return R().play ? cmd('speed', { speed: +d.rpspeed }) : cmd('play', { seconds: 8, speed: +d.rpspeed });
        if (d.rpplay) return cmd('play', { event: d.rpplay, speed: +d.speed });
        if (d.rpdel) return cmd('deleteEvent', { id: d.rpdel }); if (d.rpstar) { const ev = R().events.find(x => x.id === d.rpstar); return cmd('renameEvent', { id: d.rpstar, star: !(ev && ev.star) }); }
      };
      pane.onchange = e => { const x = e.target, d = x.dataset;
        if (d.rpsrc) return cmd('unit', { unit: d.rpsrc, source: x.value === 'off' || x.value === 'program' ? x.value : +x.value });
        if (d.rpset) return cmd('settings', { [d.rpset]: x.type === 'checkbox' ? x.checked : d.rpset === 'size' ? x.value : +x.value });
        if (d.rpname) return cmd('renameEvent', { id: d.rpname, name: x.value }); };
      pane.oninput = e => { if ('rpslide' in e.target.dataset && R().play) cmd('speed', { speed: e.target.value / 100 }); };
      live();
    },
  };
  // keyboard while the Replay panel is open
  addEventListener('keydown', e => {
    if (UI.rtab !== 'replay' || e.ctrlKey || e.metaKey || e.altKey || e.target.closest('input,textarea,select,[contenteditable]')) return;
    const r = R(); if (!r) return; const k = e.key.toLowerCase(), step = 1000 / r.fps;
    const map = { i: () => cmd('mark', { which: 'in' }), o: () => cmd('mark', { which: 'out' }), e: () => cmd('event'), r: () => cmd('play', { seconds: 8 }), l: () => cmd('live'),
      ' ': () => r.play ? cmd('pause') : cmd('play', { seconds: 8 }), arrowleft: () => cmd('jog', { ms: e.shiftKey ? -1000 : -step }), arrowright: () => cmd('jog', { ms: e.shiftKey ? 1000 : step }),
      1: () => cmd('angle', { unit: 'A' }), 2: () => cmd('angle', { unit: 'B' }), 3: () => cmd('angle', { unit: 'C' }), 4: () => cmd('angle', { unit: 'D' }) };
    if (map[k]) { e.preventDefault(); e.stopPropagation(); map[k](); }
  }, true);
})();
