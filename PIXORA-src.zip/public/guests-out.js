/* PIXORA — remote guests, output side: receives each guest's camera + mic over WebRTC for Guest clips. */
(function () {
  const want = new Map(); // slot → Set(video elements)
  const peers = new Map(); // guest id → { pc, stream, slot }
  let guests = [], ice = [{ urls: 'stun:stun.l.google.com:19302' }];
  const guestFor = slot => guests.find(g => g.slot === slot);
  function ask(slot) { const g = guestFor(slot); if (!g || !want.get(slot) || !want.get(slot).size) return; const p = peers.get(g.id); if (p && p.pc && !['failed', 'closed'].includes(p.pc.connectionState)) { feed(slot); return; } BVJ.raw({ t: 'rtc', to: g.id, data: { want: true } }); }
  function feed(slot) { const g = guestFor(slot), p = g && peers.get(g.id); for (const v of want.get(slot) || []) { if (p && p.stream) { if (v.srcObject !== p.stream) { v.srcObject = p.stream; v.play().catch(() => {}); } } else if (v.srcObject) v.srcObject = null; } }
  const H = BVJ.extraHandlers = BVJ.extraHandlers || {};
  H.guests = m => { guests = m.guests || []; for (const [id, p] of peers) if (!guests.some(g => g.id === id)) { try { p.pc.close(); } catch {} peers.delete(id); } for (const s of want.keys()) { feed(s); ask(s); } };
  H.guestJoined = m => setTimeout(() => ask(m.slot), 300);
  H.rtc = async m => { const d = m.data || {}; let p = peers.get(m.from);
    if (d.sdp && d.sdp.type === 'offer') {
      if (p) { try { p.pc.close(); } catch {} }
      const pc = new RTCPeerConnection({ iceServers: ice }); p = { pc, stream: null, slot: m.slot }; peers.set(m.from, p);
      pc.ontrack = e => { p.stream = e.streams[0] || new MediaStream([e.track]); feed(p.slot); };
      pc.onicecandidate = e => { if (e.candidate) BVJ.raw({ t: 'rtc', to: m.from, data: { ice: e.candidate } }); };
      pc.onconnectionstatechange = () => { if (pc.connectionState === 'failed') setTimeout(() => ask(p.slot), 1500); };
      await pc.setRemoteDescription(d.sdp); const ans = await pc.createAnswer(); await pc.setLocalDescription(ans); BVJ.raw({ t: 'rtc', to: m.from, data: { sdp: pc.localDescription } });
    } else if (d.ice && p) { try { await p.pc.addIceCandidate(d.ice); } catch {} } };
  window.pixoraGuest = {
    attach(slot, v) { slot = +slot || 1; if (!want.has(slot)) want.set(slot, new Set()); want.get(slot).add(v); feed(slot); ask(slot); },
    detach(v) { for (const s of want.values()) s.delete(v); },
    list: () => guests,
  };
})();
