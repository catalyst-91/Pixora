/* PIXORA — QR code encoder (byte mode, error correction M, versions 1–15: up to 412 bytes). No dependencies; works in the
   browser (window.PixoraQR) and in Node (require). qr(text) → { size, get(x, y) → true for a dark module }. */
(function (root) {
  'use strict';
  // EC level M: [ecc codewords per block, blocks in group 1, data codewords each, blocks in group 2, data codewords each]
  const BLOCKS = [null, [10, 1, 16], [16, 1, 28], [26, 1, 44], [18, 2, 32], [24, 2, 43], [16, 4, 27], [18, 4, 31], [22, 2, 38, 2, 39], [22, 3, 36, 2, 37],
    [26, 4, 43, 1, 44], [30, 1, 50, 4, 51], [22, 6, 36, 2, 37], [22, 8, 37, 1, 38], [24, 4, 40, 5, 41], [24, 5, 41, 5, 42]];
  const ALIGN = [null, [], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50], [6, 30, 54], [6, 32, 58], [6, 34, 62], [6, 26, 46, 66], [6, 26, 48, 70]];
  const dataCap = v => { const b = BLOCKS[v]; return b[1] * b[2] + (b[3] || 0) * (b[4] || 0); };
  const gmul = (x, y) => { let z = 0; for (let i = 7; i >= 0; i--) { z = (z << 1) ^ ((z >>> 7) * 0x11D); z ^= ((y >>> i) & 1) * x; } return z & 255; };
  function rsDivisor(deg) { const r = new Array(deg).fill(0); r[deg - 1] = 1; let root = 1;
    for (let i = 0; i < deg; i++) { for (let j = 0; j < deg; j++) { r[j] = gmul(r[j], root); if (j + 1 < deg) r[j] ^= r[j + 1]; } root = gmul(root, 2); } return r; }
  function rsRemainder(data, div) { const r = new Array(div.length).fill(0);
    for (const b of data) { const f = b ^ r.shift(); r.push(0); for (let i = 0; i < div.length; i++) r[i] ^= gmul(div[i], f); } return r; }
  const utf8 = s => typeof TextEncoder !== 'undefined' ? Array.from(new TextEncoder().encode(s)) : Array.from(Buffer.from(s, 'utf8'));

  function qr(text) {
    const bytes = utf8(String(text));
    let ver = 0; for (let v = 1; v <= 15; v++) { const need = 4 + (v < 10 ? 8 : 16) + bytes.length * 8; if (need <= dataCap(v) * 8) { ver = v; break; } }
    if (!ver) throw new Error('text too long for a QR code (max ~400 bytes)');
    // data bits
    const bits = []; const put = (val, n) => { for (let i = n - 1; i >= 0; i--) bits.push((val >>> i) & 1); };
    put(4, 4); put(bytes.length, ver < 10 ? 8 : 16); for (const b of bytes) put(b, 8);
    const capBits = dataCap(ver) * 8; put(0, Math.min(4, capBits - bits.length)); while (bits.length % 8) bits.push(0);
    const data = []; for (let i = 0; i < bits.length; i += 8) data.push(parseInt(bits.slice(i, i + 8).join(''), 2));
    for (let p = 0; data.length < dataCap(ver); p++) data.push(p % 2 ? 0x11 : 0xEC);
    // blocks + error correction, interleaved
    const [ecLen, g1, d1, g2 = 0, d2 = 0] = BLOCKS[ver], div = rsDivisor(ecLen), blocks = []; let k = 0;
    for (let i = 0; i < g1 + g2; i++) { const n = i < g1 ? d1 : d2; const d = data.slice(k, k + n); k += n; blocks.push({ d, e: rsRemainder(d, div) }); }
    const cw = []; for (let i = 0; i < Math.max(d1, d2); i++) for (const b of blocks) if (i < b.d.length) cw.push(b.d[i]);
    for (let i = 0; i < ecLen; i++) for (const b of blocks) cw.push(b.e[i]);
    // matrix
    const size = ver * 4 + 17, M = Array.from({ length: size }, () => new Array(size).fill(false)), F = Array.from({ length: size }, () => new Array(size).fill(false));
    const fn = (x, y, dark) => { M[y][x] = dark; F[y][x] = true; };
    for (let i = 0; i < size; i++) { fn(6, i, i % 2 === 0); fn(i, 6, i % 2 === 0); }
    for (const [cx, cy] of [[3, 3], [size - 4, 3], [3, size - 4]]) for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) {
      const x = cx + dx, y = cy + dy; if (x < 0 || y < 0 || x >= size || y >= size) continue; const d = Math.max(Math.abs(dx), Math.abs(dy)); fn(x, y, d !== 2 && d !== 4); }
    const al = ALIGN[ver], last = al.length - 1;
    for (let i = 0; i < al.length; i++) for (let j = 0; j < al.length; j++) { if ((i === 0 && j === 0) || (i === 0 && j === last) || (i === last && j === 0)) continue;
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) fn(al[i] + dx, al[j] + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1); }
    const format = mask => { const d = (0 << 3) | mask; let r = d; for (let i = 0; i < 10; i++) r = (r << 1) ^ ((r >>> 9) * 0x537); const b = ((d << 10) | r) ^ 0x5412, bit = i => ((b >>> i) & 1) === 1;
      for (let i = 0; i <= 5; i++) fn(8, i, bit(i)); fn(8, 7, bit(6)); fn(8, 8, bit(7)); fn(7, 8, bit(8)); for (let i = 9; i < 15; i++) fn(14 - i, 8, bit(i));
      for (let i = 0; i < 8; i++) fn(size - 1 - i, 8, bit(i)); for (let i = 8; i < 15; i++) fn(8, size - 15 + i, bit(i)); fn(8, size - 8, true); };
    format(0);
    if (ver >= 7) { let r = ver; for (let i = 0; i < 12; i++) r = (r << 1) ^ ((r >>> 11) * 0x1F25); const b = (ver << 12) | r;
      for (let i = 0; i < 18; i++) { const dark = ((b >>> i) & 1) === 1, a = size - 11 + i % 3, c = Math.floor(i / 3); fn(a, c, dark); fn(c, a, dark); } }
    // codewords, zig-zag from the bottom right
    let bi = 0; const total = cw.length * 8;
    for (let right = size - 1; right >= 1; right -= 2) { if (right === 6) right = 5;
      for (let v = 0; v < size; v++) for (let j = 0; j < 2; j++) { const x = right - j, up = ((right + 1) & 2) === 0, y = up ? size - 1 - v : v;
        if (!F[y][x] && bi < total) { M[y][x] = ((cw[bi >>> 3] >>> (7 - (bi & 7))) & 1) === 1; bi++; } } }
    // pick the mask with the lowest penalty
    const MASKS = [(x, y) => (x + y) % 2 === 0, (x, y) => y % 2 === 0, x => x % 3 === 0, (x, y) => (x + y) % 3 === 0, (x, y) => (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0,
      (x, y) => x * y % 2 + x * y % 3 === 0, (x, y) => (x * y % 2 + x * y % 3) % 2 === 0, (x, y) => ((x + y) % 2 + x * y % 3) % 2 === 0];
    const apply = m => { for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) if (!F[y][x] && MASKS[m](x, y)) M[y][x] = !M[y][x]; };
    const penalty = () => { let p = 0, dark = 0;
      const line = get => { let s = 0, run = 0, prev = null; const seq = [];
        for (let i = 0; i < size; i++) { const c = get(i); seq.push(c ? 1 : 0); if (c === prev) { run++; if (run === 5) s += 3; else if (run > 5) s++; } else { run = 1; prev = c; } }
        const str = seq.join(''); for (const pat of ['10111010000', '00001011101']) { let i = -1; while ((i = str.indexOf(pat, i + 1)) >= 0) s += 40; } return s; };
      for (let i = 0; i < size; i++) { p += line(x => M[i][x]); p += line(y => M[y][i]); }
      for (let y = 0; y < size - 1; y++) for (let x = 0; x < size - 1; x++) { const c = M[y][x]; if (c === M[y][x + 1] && c === M[y + 1][x] && c === M[y + 1][x + 1]) p += 3; }
      for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) if (M[y][x]) dark++;
      p += Math.floor(Math.abs(dark * 20 - size * size * 10) / (size * size)) * 10; return p; };
    let best = 0, bestP = Infinity;
    for (let m = 0; m < 8; m++) { apply(m); format(m); const p = penalty(); if (p < bestP) { bestP = p; best = m; } apply(m); }
    apply(best); format(best);
    return { size, version: ver, mask: best, get: (x, y) => x >= 0 && y >= 0 && x < size && y < size && M[y][x] };
  }
  // draw onto a 2D canvas context: quiet zone of 4 modules included, dark on light
  qr.draw = (ctx, text, x, y, px, dark = '#000', light = '#fff') => { const q = qr(text), n = q.size + 8, m = px / n;
    ctx.fillStyle = light; ctx.fillRect(x, y, px, px); ctx.fillStyle = dark;
    for (let r = 0; r < q.size; r++) for (let c = 0; c < q.size; c++) if (q.get(c, r)) ctx.fillRect(Math.floor(x + (c + 4) * m), Math.floor(y + (r + 4) * m), Math.ceil(m), Math.ceil(m));
    return q; };
  if (typeof module !== 'undefined' && module.exports) module.exports = qr; else root.PixoraQR = qr;
})(typeof window !== 'undefined' ? window : this);
