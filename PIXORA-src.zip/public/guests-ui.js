/* PIXORA — remote guests in Library ▸ Inputs: invite link, who is connected, Guest 1–4 tiles. */
(function () {
  const UI = window.UI, $ = UI.$, esc = UI.esc, I = UI.icon;
  let info = null; UI.guests = [];
  (BVJ.extraHandlers = BVJ.extraHandlers || {}).guests = m => { UI.guests = m.guests || []; const box = $('#guestBox'); if (box) box.outerHTML = UI.guestSection(); };
  BVJ.extraHandlers.guestKey = () => { info = null; const box = $('#guestBox'); if (box) box.outerHTML = UI.guestSection(); };
  const link = () => { if (!info) return ''; const host = location.protocol === 'https:' || /^(localhost|127\.)/.test(location.hostname) ? location.host : location.host;
    return `${location.protocol}//${host}/guest?key=${info.key}`; };
  UI.guestSection = function () {
    if (!info) { UI.api('/api/guests').then(r => { info = r; UI.guests = r.guests; const box = $('#guestBox'); if (box) box.outerHTML = UI.guestSection(); }).catch(() => {}); }
    const tile = n => { const g = UI.guests.find(x => x.slot === n); return `<div class="gtile" draggable="true" data-guesttile="${n}" style="flex-direction:row;align-items:center;gap:8px;padding:8px">${I('cam')}<div style="flex:1;min-width:0"><b>Guest ${n}</b><div class="small ${g ? '' : 'muted'}" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${g ? '● ' + esc(g.name) : 'nobody yet'}</div></div>${g ? `<button class="btn sm icon" data-guestkick="${n}" title="End this guest's session">${I('x')}</button>` : ''}</div>`; };
    const secure = location.protocol === 'https:';
    return `<div class="sec" id="guestBox"><h4>Remote guests</h4>
      <div class="row wide"><label>Invite link</label><div class="ctl" style="display:flex;gap:4px"><input type="text" readonly value="${esc(link())}" id="guestLink" style="flex:1"><button class="btn sm" data-guestcopy>${I('copy')}</button><button class="btn sm" data-guestnew title="New link — current guests are disconnected">${I('refresh')}</button></div></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:4px;margin-top:6px">${[1, 2, 3, 4].map(tile).join('')}</div>
      <div class="hint">Send the link to a presenter, caller or remote camera phone; drag Guest 1–4 into a slot or overlay. Picture and sound go peer-to-peer to the output computer.${secure ? '' : ' <b>Phones and other computers need a secure https:// address for the camera</b> — use PIXORA through a Cloudflare Tunnel or other HTTPS address and share that link.'}</div></div>`;
  };
  document.addEventListener('click', e => { const t = e.target.closest('button'); if (!t || !t.closest('#guestBox')) return;
    if ('guestcopy' in t.dataset) { navigator.clipboard.writeText($('#guestLink').value).then(() => UI.toast('Invite link copied', 'ok')); }
    if ('guestnew' in t.dataset) BVJ.raw({ t: 'guestNewKey' });
    if (t.dataset.guestkick) BVJ.raw({ t: 'guestKick', slot: +t.dataset.guestkick }); });
  document.addEventListener('dragstart', e => { const t = e.target.closest && e.target.closest('[data-guesttile]'); if (!t) return; const n = +t.dataset.guesttile, g = UI.guests.find(x => x.slot === n);
    e.dataTransfer.setData('bvj/clip', JSON.stringify({ type: 'guest', name: g ? g.name : 'Guest ' + n, slot: n, fit: 'fill' })); });
})();
