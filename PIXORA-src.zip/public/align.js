/* PIXORA — automatic projector alignment with a camera (shared by the controller and the tests).
   1. Each projector shows coded dot patterns: black, all dots, then one frame per bit of each dot's Gray-coded number.
   2. The camera images are decoded: dots are found in (all − black), and each dot's number is read from the bit frames.
   3. A homography camera → projector is fitted (normalised DLT inside RANSAC).
   4. With the screen's 4 corners marked in the camera picture, every projector gets a slice: the part of the
      screen it covers (src) corner-pinned onto its own pixels (dst), plus soft edges where projectors overlap.
   Flat screens only: curved surfaces need the mesh warp afterwards. */
(function (root) {
  'use strict';
  const gray = n => n ^ (n >> 1), ungray = g => { let n = 0; for (; g; g >>= 1) n ^= g; return n; };

  // ---------- patterns ----------
  function layout(W, H, o = {}) {
    const cols = o.cols || 12, rows = o.rows || 8, m = o.margin ?? 0.06; const pts = [];
    for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) pts.push([W * (m + (1 - 2 * m) * c / (cols - 1)), H * (m + (1 - 2 * m) * r / (rows - 1))]);
    const bits = Math.ceil(Math.log2(pts.length + 1)); // codes 1..N (0 is never used, so a dot is never dark in every bit frame)
    return { cols, rows, pts, bits, frames: 2 + bits, radius: o.radius || Math.max(3, Math.min(W, H) / 70) };
  }
  // frame 0 = black, 1 = all dots, 2+b = dots whose Gray code has bit b set
  function dotsOn(L, frame) { if (frame === 0) return []; if (frame === 1) return L.pts.map((_, i) => i); const b = frame - 2; return L.pts.map((_, i) => i).filter(i => (gray(i + 1) >> b) & 1); }
  function draw(ctx, W, H, frame, o) {
    const L = layout(W, H, o); ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H); ctx.fillStyle = '#fff';
    for (const i of dotsOn(L, frame)) { ctx.beginPath(); ctx.arc(L.pts[i][0], L.pts[i][1], L.radius, 0, Math.PI * 2); ctx.fill(); }
    return L;
  }

  // ---------- decoding (images: { w, h, data: Uint8Array/Float32Array of luminance 0..255 }) ----------
  function blobs(img, thr, minA, maxA) {
    const { w, h, data } = img, lab = new Int32Array(w * h), out = []; let id = 0; const st = [];
    for (let p = 0; p < w * h; p++) {
      if (lab[p] || data[p] < thr) continue; id++; let sx = 0, sy = 0, sw = 0, n = 0, x0 = w, x1 = 0, y0 = h, y1 = 0; st.push(p); lab[p] = id;
      while (st.length) { const q = st.pop(), x = q % w, y = (q / w) | 0, v = data[q]; sx += x * v; sy += y * v; sw += v; n++; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
        for (const nq of [q - 1, q + 1, q - w, q + w]) { if (nq < 0 || nq >= w * h) continue; if ((nq === q - 1 && x === 0) || (nq === q + 1 && x === w - 1)) continue; if (!lab[nq] && data[nq] >= thr) { lab[nq] = id; st.push(nq); } } }
      if (n >= minA && n <= maxA && sw > 0) out.push({ x: sx / sw, y: sy / sw, n, box: [x0, y0, x1, y1], id });
    }
    return { list: out, lab };
  }
  function decode(frames, L, o = {}) {
    const [blk, all] = frames, w = all.w, h = all.h, diff = new Float32Array(w * h); let mx = 0;
    for (let p = 0; p < w * h; p++) { const d = all.data[p] - blk.data[p]; diff[p] = d > 0 ? d : 0; if (diff[p] > mx) mx = diff[p]; }
    if (mx < 8) return { pairs: [], error: 'no dots seen — is the camera pointing at the projection, with the room dark enough?' };
    const B = blobs({ w, h, data: diff }, mx * (o.thr || 0.35), o.minArea || 3, o.maxArea || (w * h) / 60);
    const pairs = [], seen = new Map();
    for (const b of B.list) {
      let code = 0;
      for (let k = 0; k < L.bits; k++) { const f = frames[2 + k]; let on = 0, tot = 0;
        for (let y = b.box[1]; y <= b.box[3]; y++) for (let x = b.box[0]; x <= b.box[2]; x++) { const p = y * w + x; if (B.lab[p] !== b.id) continue; const span = all.data[p] - blk.data[p]; if (span <= 0) continue; on += (f.data[p] - blk.data[p]) / span; tot++; }
        if (tot && on / tot > 0.5) code |= 1 << k; }
      const i = ungray(code) - 1; if (i < 0 || i >= L.pts.length) continue;
      if (seen.has(i)) { seen.get(i).dup = true; continue; } // the same number twice: drop both (reflection / misread)
      const pr = { cam: [b.x, b.y], proj: L.pts[i], index: i }; seen.set(i, pr); pairs.push(pr);
    }
    return { pairs: pairs.filter(p => !p.dup), blobs: B.list.length };
  }

  // ---------- homography ----------
  function solve(A, b) { // Gaussian elimination, A n×n
    const n = b.length; for (let i = 0; i < n; i++) { let m = i; for (let r = i + 1; r < n; r++) if (Math.abs(A[r][i]) > Math.abs(A[m][i])) m = r; [A[i], A[m]] = [A[m], A[i]]; [b[i], b[m]] = [b[m], b[i]];
      const d = A[i][i]; if (Math.abs(d) < 1e-12) return null; for (let r = i + 1; r < n; r++) { const f = A[r][i] / d; for (let c = i; c < n; c++) A[r][c] -= f * A[i][c]; b[r] -= f * b[i]; } }
    const x = new Array(n); for (let i = n - 1; i >= 0; i--) { let s = b[i]; for (let c = i + 1; c < n; c++) s -= A[i][c] * x[c]; x[i] = s / A[i][i]; } return x;
  }
  const norm = pts => { const n = pts.length, cx = pts.reduce((a, p) => a + p[0], 0) / n, cy = pts.reduce((a, p) => a + p[1], 0) / n; const d = pts.reduce((a, p) => a + Math.hypot(p[0] - cx, p[1] - cy), 0) / n || 1; const s = Math.SQRT2 / d; return { T: [s, 0, -s * cx, 0, s, -s * cy, 0, 0, 1], f: p => [(p[0] - cx) * s, (p[1] - cy) * s] }; };
  const mul3 = (a, b) => { const o = new Array(9); for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) o[r * 3 + c] = a[r * 3] * b[c] + a[r * 3 + 1] * b[3 + c] + a[r * 3 + 2] * b[6 + c]; return o; };
  function inv3(m) { const [a, b, c, d, e, f, g, h, i] = m, A = e * i - f * h, B = -(d * i - f * g), C = d * h - e * g, det = a * A + b * B + c * C; if (Math.abs(det) < 1e-15) return null;
    return [A, -(b * i - c * h), b * f - c * e, B, a * i - c * g, -(a * f - c * d), C, -(a * h - b * g), a * e - b * d].map(v => v / det); }
  const apply = (H, p) => { const w = H[6] * p[0] + H[7] * p[1] + H[8]; return [(H[0] * p[0] + H[1] * p[1] + H[2]) / w, (H[3] * p[0] + H[4] * p[1] + H[5]) / w]; };
  function fit(src, dst) { // least squares with h33 = 1, on normalised points
    if (src.length < 4) return null; const ns = norm(src), nd = norm(dst); const A = Array.from({ length: 8 }, () => new Array(8).fill(0)), b = new Array(8).fill(0);
    for (let k = 0; k < src.length; k++) { const [x, y] = ns.f(src[k]), [u, v] = nd.f(dst[k]);
      for (const [row, rhs] of [[[x, y, 1, 0, 0, 0, -u * x, -u * y], u], [[0, 0, 0, x, y, 1, -v * x, -v * y], v]]) for (let i = 0; i < 8; i++) { b[i] += row[i] * rhs; for (let j = 0; j < 8; j++) A[i][j] += row[i] * row[j]; } }
    const h = solve(A, b); if (!h) return null; const Hn = [...h, 1]; const Ti = inv3(nd.T); if (!Ti) return null; const H = mul3(Ti, mul3(Hn, ns.T)); return H.map(v => v / H[8]);
  }
  function ransac(pairs, o = {}) { // camera → projector
    const n = pairs.length; if (n < 6) return null; const thr = o.thr || 4, it = o.iterations || 400; let best = null, bestIn = [];
    let seed = 12345; const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
    for (let t = 0; t < it; t++) { const s = new Set(); while (s.size < 4) s.add((rnd() * n) | 0); const sm = [...s].map(i => pairs[i]);
      const H = fit(sm.map(p => p.cam), sm.map(p => p.proj)); if (!H) continue; const inl = pairs.filter(p => { const q = apply(H, p.cam); return Math.hypot(q[0] - p.proj[0], q[1] - p.proj[1]) < thr; });
      if (inl.length > bestIn.length) { bestIn = inl; best = H; if (inl.length > n * 0.95) break; } }
    if (bestIn.length < 6) return null; const H = fit(bestIn.map(p => p.cam), bestIn.map(p => p.proj));
    const err = bestIn.reduce((a, p) => { const q = apply(H, p.cam); return a + Math.hypot(q[0] - p.proj[0], q[1] - p.proj[1]); }, 0) / bestIn.length;
    return { H, inliers: bestIn.length, total: n, error: err };
  }

  // ---------- solve the screen: projectors [{ id, W, H, camToProj: H }], screen corners in the camera [TL, TR, BR, BL] ----------
  function plan(projectors, screenCam, o = {}) {
    const Hcs = fit(screenCam, [[0, 0], [1, 0], [1, 1], [0, 1]]); if (!Hcs) throw new Error('the 4 screen corners don\'t make a usable shape');
    const res = projectors.map(P => {
      const Hpc = inv3(P.camToProj); const Hps = mul3(Hcs, Hpc), Hsp = inv3(Hps); // projector px → screen uv, and back
      const fp = [[0, 0], [P.W, 0], [P.W, P.H], [0, P.H]].map(p => apply(Hps, p)); // footprint on the screen (uv)
      // inner rectangle of the footprint, clipped to the screen
      const cl = v => Math.max(0, Math.min(1, v));
      const x0 = cl(Math.max(fp[0][0], fp[3][0])), x1 = cl(Math.min(fp[1][0], fp[2][0])), y0 = cl(Math.max(fp[0][1], fp[1][1])), y1 = cl(Math.min(fp[2][1], fp[3][1]));
      return { id: P.id, W: P.W, H: P.H, Hsp, footprint: fp, rect: { x0, y0, x1, y1 }, empty: !(x1 - x0 > 0.01 && y1 - y0 > 0.01) };
    });
    const live = res.filter(r => !r.empty);
    for (const r of live) r.soft = { l: 0, r: 0, t: 0, b: 0 };
    for (const a of live) for (const b of live) { if (a === b) continue; const A = a.rect, B = b.rect;
      const ovY = Math.min(A.y1, B.y1) - Math.max(A.y0, B.y0), ovX = Math.min(A.x1, B.x1) - Math.max(A.x0, B.x0); if (ovX <= 0 || ovY <= 0) continue;
      const side = Math.abs((A.x0 + A.x1) - (B.x0 + B.x1)) >= Math.abs((A.y0 + A.y1) - (B.y0 + B.y1)); // side by side, else stacked
      if (side) { if ((A.x0 + A.x1) < (B.x0 + B.x1)) a.soft.r = Math.max(a.soft.r, Math.min(0.5, ovX / (A.x1 - A.x0))); else a.soft.l = Math.max(a.soft.l, Math.min(0.5, ovX / (A.x1 - A.x0))); }
      else { if ((A.y0 + A.y1) < (B.y0 + B.y1)) a.soft.b = Math.max(a.soft.b, Math.min(0.5, ovY / (A.y1 - A.y0))); else a.soft.t = Math.max(a.soft.t, Math.min(0.5, ovY / (A.y1 - A.y0))); } }
    for (const r of live) { const R = r.rect; const q = [[R.x0, R.y0], [R.x1, R.y0], [R.x1, R.y1], [R.x0, R.y1]].map(p => apply(r.Hsp, p));
      r.slice = { src: { x: +R.x0.toFixed(4), y: +R.y0.toFixed(4), w: +(R.x1 - R.x0).toFixed(4), h: +(R.y1 - R.y0).toFixed(4) }, dst: q.map(([x, y]) => [+(x / r.W).toFixed(4), +(y / r.H).toFixed(4)]),
        soft: Object.fromEntries(Object.entries(r.soft).map(([k, v]) => [k, +v.toFixed(4)])) }; }
    return res;
  }

  // luminance from RGBA (canvas ImageData), optional downscale handled by the caller drawing to a smaller canvas
  function luma(rgba, w, h) { const out = new Float32Array(w * h); for (let i = 0, p = 0; p < w * h; p++, i += 4) out[p] = 0.299 * rgba[i] + 0.587 * rgba[i + 1] + 0.114 * rgba[i + 2]; return { w, h, data: out }; }

  // ---------- blend tuning from camera measurements ----------
  // Sample the camera image along the screen's middle band in screen-uv: mean luminance inside each projector's
  // single-coverage area and inside each overlap. regions: [{ kind: 'single', id } | { kind: 'overlap', ids }, u0, u1]
  function regions(plan) {
    const live = plan.filter(p => !p.empty).sort((a, b) => a.rect.x0 - b.rect.x0), out = [];
    live.forEach((p, i) => { const prev = live[i - 1], next = live[i + 1]; const a = prev ? Math.max(p.rect.x0, prev.rect.x1) : p.rect.x0, b = next ? Math.min(p.rect.x1, next.rect.x0) : p.rect.x1;
      if (b - a > 0.02) out.push({ kind: 'single', id: p.id, u0: a + 0.01, u1: b - 0.01 });
      if (next && next.rect.x0 < p.rect.x1) out.push({ kind: 'overlap', ids: [p.id, next.id], u0: next.rect.x0 + (p.rect.x1 - next.rect.x0) * 0.2, u1: p.rect.x1 - (p.rect.x1 - next.rect.x0) * 0.2 }); });
    return out;
  }
  function measure(img, screenCam, regs, v0 = 0.3, v1 = 0.7) {
    const Hsc = fit([[0, 0], [1, 0], [1, 1], [0, 1]], screenCam); const res = [];
    for (const r of regs) { let sum = 0, n = 0;
      for (let k = 0; k <= 12; k++) for (let j = 0; j <= 8; j++) { const u = r.u0 + (r.u1 - r.u0) * k / 12, v = v0 + (v1 - v0) * j / 8; const [x, y] = apply(Hsc, [u, v]); const xi = Math.round(x), yi = Math.round(y);
        if (xi < 0 || yi < 0 || xi >= img.w || yi >= img.h) continue; sum += img.data[yi * img.w + xi]; n++; }
      res.push(Object.assign({}, r, { lum: n ? sum / n : 0 })); }
    return res;
  }
  // one tuning step. slices: { [id]: { gamma, black, cal: { brightness } } } (changed in place). white/black: measure() results.
  // Returns { done, notes } — call again with fresh measurements until done (2–4 rounds).
  function tune(slices, white, black, o = {}) {
    const notes = []; let done = true; const singles = white.filter(r => r.kind === 'single'), overl = white.filter(r => r.kind === 'overlap');
    if (singles.length > 1) { const min = Math.min(...singles.map(r => r.lum));
      for (const r of singles) { const ratio = min / Math.max(1, r.lum); if (ratio < 0.97) { const c = slices[r.id].cal = slices[r.id].cal || {}; c.brightness = +Math.max(0.5, (c.brightness ?? 1) * Math.pow(ratio, 1 / 2.2)).toFixed(3); done = false; notes.push(`${r.id}: brightness ${Math.round(c.brightness * 100)} %`); } } }
    for (const r of overl) { const s = singles.filter(x => r.ids.includes(x.id)); if (!s.length) continue; const ref = s.reduce((a, x) => a + x.lum, 0) / s.length; const ratio = r.lum / Math.max(1, ref);
      if (Math.abs(ratio - 1) > (o.tol || 0.06)) { done = false; for (const id of r.ids) { const sl = slices[id]; sl.gamma = +Math.max(1, Math.min(3.5, (sl.gamma || 2.2) * Math.pow(1 / ratio, 0.9))).toFixed(3); }
        notes.push(`overlap ${r.ids.join('/')}: ${ratio > 1 ? 'too bright' : 'too dark'} (${Math.round(ratio * 100)} %) → blend gamma ${slices[r.ids[0]].gamma}`); } }
    if (black) { const bs = black.filter(r => r.kind === 'single'), bo = black.filter(r => r.kind === 'overlap');
      for (const r of bo) { const s = bs.filter(x => r.ids.includes(x.id)); if (!s.length) continue; const ref = s.reduce((a, x) => a + x.lum, 0) / s.length, diff = r.lum - ref;
        if (diff > (o.blackTol || 1.5)) { done = false; for (const x of s) { const sl = slices[x.id]; const w = singles.find(y => y.id === x.id), span = Math.max(10, (w ? w.lum : 255) - x.lum);
            // the extra light needed, as a fraction of full white, turned back into a signal level through the display gamma (~2.2)
            const have = Math.pow(sl.black || 0, 2.2); sl.black = +Math.min(0.35, Math.pow(have + 0.85 * diff / span, 1 / 2.2)).toFixed(4); } notes.push(`black band in overlap ${r.ids.join('/')}: +${diff.toFixed(1)} → black level ${slices[s[0].id].black}`); } } }
    return { done, notes };
  }

  const API = { regions, measure, tune, layout, dotsOn, draw, decode, fit, ransac, plan, apply, inv3, mul3, luma, gray, ungray };
  if (typeof module !== 'undefined' && module.exports) module.exports = API; else root.PixoraAlign = API;
})(typeof window !== 'undefined' ? window : globalThis);
