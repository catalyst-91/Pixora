/* PIXORA HAP player — plays Vidvox HAP / HAP Alpha / HAP Q .mov files in the browser.
 * QuickTime demux → HAP section parsing (simple + chunked "complex" frames) → Snappy decompression →
 * DXT1/DXT5 upload as compressed GPU textures (WEBGL_compressed_texture_s3tc), or CPU decode to RGBA when the
 * GPU path isn't available. HAP Q (YCoCg-DXT5) is decoded on the CPU. Frames are streamed with HTTP range requests.
 */
(function (root) {
  'use strict';
  /* ---------------- Snappy */
  function snappy(src, outLen) {
    let p = 0, len = 0, shift = 0, b;
    do { b = src[p++]; len |= (b & 0x7f) << shift; shift += 7; } while (b & 0x80);
    const out = new Uint8Array(outLen || len); let o = 0;
    while (p < src.length) {
      const tag = src[p++]; const t = tag & 3;
      if (t === 0) { let l = tag >> 2; if (l >= 60) { const n = l - 59; l = 0; for (let i = 0; i < n; i++) l |= src[p++] << (8 * i); } l += 1; out.set(src.subarray(p, p + l), o); p += l; o += l; continue; }
      let l, off;
      if (t === 1) { l = ((tag >> 2) & 7) + 4; off = ((tag >> 5) << 8) | src[p++]; }
      else if (t === 2) { l = (tag >> 2) + 1; off = src[p] | (src[p + 1] << 8); p += 2; }
      else { l = (tag >> 2) + 1; off = (src[p] | (src[p + 1] << 8) | (src[p + 2] << 16) | (src[p + 3] << 24)) >>> 0; p += 4; }
      if (off >= l) out.copyWithin(o, o - off, o - off + l); else for (let i = 0; i < l; i++) out[o + i] = out[o - off + i];
      o += l;
    }
    return o === out.length ? out : out.subarray(0, o);
  }
  /* ---------------- HAP sections */
  function section(b, p) { let size = b[p] | (b[p + 1] << 8) | (b[p + 2] << 16), hl = 4; const type = b[p + 3]; if (size === 0) { size = (b[p + 4] | (b[p + 5] << 8) | (b[p + 6] << 16) | (b[p + 7] << 24)) >>> 0; hl = 8; } return { type, start: p + hl, end: p + hl + size }; }
  function decodeFrame(b) { // → { fmt: 0xB|0xE|0xF|0x1|0xC, data: Uint8Array }
    const s = section(b, 0); let type = s.type;
    if ((type & 0xF0) === 0xD0 || type === 0x0D) { const first = section(b, s.start); return decodeFrame(b.subarray(first.start - (first.end - first.start > 0xffffff ? 8 : 4), first.end)); } // multi-image (HAP Q Alpha): first image
    const comp = type >> 4, fmt = type & 0x0F; const body = b.subarray(s.start, s.end);
    if (comp === 0xA) return { fmt, data: body };
    if (comp === 0xB) return { fmt, data: snappy(body) };
    if (comp === 0xC) { // decode instructions container + chunks
      const di = section(body, 0); let comps = null, sizes = null, offs = null;
      for (let q = di.start; q < di.end;) { const ss = section(body, q); const d = body.subarray(ss.start, ss.end);
        if (ss.type === 0x02) comps = d; else if (ss.type === 0x03) { sizes = []; for (let i = 0; i < d.length; i += 4) sizes.push((d[i] | (d[i + 1] << 8) | (d[i + 2] << 16) | (d[i + 3] << 24)) >>> 0); }
        else if (ss.type === 0x04) { offs = []; for (let i = 0; i < d.length; i += 4) offs.push((d[i] | (d[i + 1] << 8) | (d[i + 2] << 16) | (d[i + 3] << 24)) >>> 0); }
        q = ss.end; }
      const parts = []; let p = di.end, total = 0;
      for (let i = 0; i < sizes.length; i++) { const st = offs ? di.end + offs[i] : p; const raw = body.subarray(st, st + sizes[i]); p = st + sizes[i];
        const out = comps[i] === 0x0B ? snappy(raw) : raw; parts.push(out); total += out.length; }
      const data = new Uint8Array(total); let o = 0; for (const x of parts) { data.set(x, o); o += x.length; }
      return { fmt, data };
    }
    throw new Error('unknown HAP compressor 0x' + comp.toString(16));
  }
  /* ---------------- DXT → RGBA (CPU path) */
  function c565(c, out, o) { out[o] = ((c >> 11) & 31) * 255 / 31 | 0; out[o + 1] = ((c >> 5) & 63) * 255 / 63 | 0; out[o + 2] = (c & 31) * 255 / 31 | 0; }
  function decodeDXT(data, w, h, fmt, out) { // out: RGBA w*h (top-down)
    const bw = Math.ceil(w / 4), bh = Math.ceil(h / 4), bs = fmt === 0xB ? 8 : 16; const pal = new Uint8Array(16), al = new Uint8Array(8);
    for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) {
      let o = (by * bw + bx) * bs; let aLo = 0, aHi = 0, hasA = false;
      if (bs === 16) { // DXT5 alpha block: two 24-bit halves of 3-bit indices (no BigInt — this runs per block)
        const a0 = data[o], a1 = data[o + 1]; al[0] = a0; al[1] = a1;
        if (a0 > a1) for (let i = 1; i < 7; i++) al[i + 1] = ((7 - i) * a0 + i * a1) / 7 | 0; else { for (let i = 1; i < 5; i++) al[i + 1] = ((5 - i) * a0 + i * a1) / 5 | 0; al[6] = 0; al[7] = 255; }
        aLo = data[o + 2] | (data[o + 3] << 8) | (data[o + 4] << 16); aHi = data[o + 5] | (data[o + 6] << 8) | (data[o + 7] << 16); hasA = true; o += 8;
      }
      const c0 = data[o] | (data[o + 1] << 8), c1 = data[o + 2] | (data[o + 3] << 8); c565(c0, pal, 0); c565(c1, pal, 4); pal[3] = pal[7] = 255;
      if (c0 > c1 || bs === 16) { for (let k = 0; k < 3; k++) { pal[8 + k] = (2 * pal[k] + pal[4 + k]) / 3 | 0; pal[12 + k] = (pal[k] + 2 * pal[4 + k]) / 3 | 0; } pal[11] = pal[15] = 255; }
      else { for (let k = 0; k < 3; k++) { pal[8 + k] = (pal[k] + pal[4 + k]) >> 1; pal[12 + k] = 0; } pal[11] = 255; pal[15] = 0; }
      const idx = (data[o + 4] | (data[o + 5] << 8) | (data[o + 6] << 16) | (data[o + 7] << 24)) >>> 0;
      for (let py = 0; py < 4; py++) { const y = by * 4 + py; if (y >= h) break;
        for (let px = 0; px < 4; px++) { const x = bx * 4 + px; if (x >= w) continue; const i = py * 4 + px; const ci = (idx >>> (2 * i)) & 3; const d = (y * w + x) * 4;
          out[d] = pal[ci * 4]; out[d + 1] = pal[ci * 4 + 1]; out[d + 2] = pal[ci * 4 + 2]; out[d + 3] = hasA ? al[i < 8 ? (aLo >> (3 * i)) & 7 : (aHi >> (3 * (i - 8))) & 7] : pal[ci * 4 + 3]; } }
    }
    return out;
  }
  function ycocg(out) { // HAP Q: scaled YCoCg in DXT5 (Co=R, Cg=G, scale=B, Y=A) → RGB
    for (let i = 0; i < out.length; i += 4) { const sc = (out[i + 2] / 8 | 0) + 1; const co = (out[i] - 128) / sc, cg = (out[i + 1] - 128) / sc, y = out[i + 3];
      const r = y + co - cg, g = y + cg, b = y - co - cg; out[i] = r < 0 ? 0 : r > 255 ? 255 : r; out[i + 1] = g < 0 ? 0 : g > 255 ? 255 : g; out[i + 2] = b < 0 ? 0 : b > 255 ? 255 : b; out[i + 3] = 255; }
    return out;
  }
  /* vertical flip of DXT data (the renderer uploads with UNPACK_FLIP_Y, which compressed uploads ignore) */
  function flipDXT(data, w, h, fmt) {
    const bw = Math.ceil(w / 4), bh = Math.ceil(h / 4), bs = fmt === 0xB ? 8 : 16, row = bw * bs, out = new Uint8Array(data.length);
    for (let by = 0; by < bh; by++) {
      const src = by * row, dst = (bh - 1 - by) * row;
      for (let bx = 0; bx < bw; bx++) {
        const s = src + bx * bs, d = dst + bx * bs; let c = s, e = d;
        if (bs === 16) { // alpha: 4 rows × 12 bits
          out[d] = data[s]; out[d + 1] = data[s + 1];
          const lo = data[s + 2] | (data[s + 3] << 8) | (data[s + 4] << 16), hi = data[s + 5] | (data[s + 6] << 8) | (data[s + 7] << 16);
          const nlo = (hi >> 12) | ((hi & 0xFFF) << 12), nhi = (lo >> 12) | ((lo & 0xFFF) << 12); // rows 3,2 | rows 1,0
          out[d + 2] = nlo & 255; out[d + 3] = (nlo >> 8) & 255; out[d + 4] = (nlo >> 16) & 255; out[d + 5] = nhi & 255; out[d + 6] = (nhi >> 8) & 255; out[d + 7] = (nhi >> 16) & 255;
          c += 8; e += 8;
        }
        out[e] = data[c]; out[e + 1] = data[c + 1]; out[e + 2] = data[c + 2]; out[e + 3] = data[c + 3];
        out[e + 4] = data[c + 7]; out[e + 5] = data[c + 6]; out[e + 6] = data[c + 5]; out[e + 7] = data[c + 4];
      }
    }
    return out;
  }
  /* ---------------- QuickTime demux */
  async function fetchRange(url, start, len) { const r = await fetch(url, { headers: { Range: `bytes=${start}-${start + len - 1}` } }); if (!r.ok) throw new Error('HTTP ' + r.status); const b = new Uint8Array(await r.arrayBuffer()); return r.status === 206 ? b : b.subarray(start, start + len); }
  const u32 = (b, o) => ((b[o] << 24) | (b[o + 1] << 16) | (b[o + 2] << 8) | b[o + 3]) >>> 0;
  const str = (b, o) => String.fromCharCode(b[o], b[o + 1], b[o + 2], b[o + 3]);
  function* atoms(b, s, e) { let o = s; while (o + 8 <= e) { let size = u32(b, o), hl = 8; const type = str(b, o + 4); if (size === 1) { size = u32(b, o + 8) * 4294967296 + u32(b, o + 12); hl = 16; } else if (size === 0) size = e - o; if (size < 8) return; yield { type, s: o + hl, e: o + size }; o += size; } }
  const child = (b, a, t) => { for (const x of atoms(b, a.s, a.e)) if (x.type === t) return x; return null; };
  async function findMoov(url, total) {
    let o = 0;
    while (o < total) { const h = await fetchRange(url, o, 16); let size = u32(h, 0); const type = str(h, 4); if (size === 1) size = u32(h, 8) * 4294967296 + u32(h, 12); else if (size === 0) size = total - o;
      if (type === 'moov') return fetchRange(url, o, size); if (size < 8) break; o += size; }
    throw new Error('moov atom not found');
  }
  async function demux(url) {
    const head = await fetch(url, { headers: { Range: 'bytes=0-0' } }); const cr = head.headers.get('content-range'); const total = cr ? +cr.split('/')[1] : +head.headers.get('content-length');
    const m = await findMoov(url, total); const moov = { s: 8, e: m.length };
    for (const trak of atoms(m, moov.s, moov.e)) {
      if (trak.type !== 'trak') continue;
      const mdia = child(m, trak, 'mdia'), minf = mdia && child(m, mdia, 'minf'), stbl = minf && child(m, minf, 'stbl'), stsd = stbl && child(m, stbl, 'stsd'); if (!stsd) continue;
      const fourcc = str(m, stsd.s + 12); if (!/^Hap/.test(fourcc)) continue;
      const w = (m[stsd.s + 8 + 32] << 8) | m[stsd.s + 8 + 33], h = (m[stsd.s + 8 + 34] << 8) | m[stsd.s + 8 + 35];
      const mdhd = child(m, mdia, 'mdhd'); const v1 = m[mdhd.s] === 1; const timescale = u32(m, mdhd.s + (v1 ? 20 : 12));
      const stts = child(m, stbl, 'stts'), stsz = child(m, stbl, 'stsz'), stsc = child(m, stbl, 'stsc'), stco = child(m, stbl, 'stco') || child(m, stbl, 'co64'); const is64 = stco && str(m, stco.s - 4) === 'co64';
      const times = []; let t = 0; for (let i = 0, n = u32(m, stts.s + 4); i < n; i++) { const c = u32(m, stts.s + 8 + i * 8), d = u32(m, stts.s + 12 + i * 8); for (let k = 0; k < c; k++) { times.push(t / timescale); t += d; } }
      const fixed = u32(m, stsz.s + 4), count = u32(m, stsz.s + 8); const sizes = []; for (let i = 0; i < count; i++) sizes.push(fixed || u32(m, stsz.s + 12 + i * 4));
      const chunks = []; for (let i = 0, n = u32(m, stco.s + 4); i < n; i++) chunks.push(is64 ? u32(m, stco.s + 8 + i * 8) * 4294967296 + u32(m, stco.s + 12 + i * 8) : u32(m, stco.s + 8 + i * 4));
      const sc = []; for (let i = 0, n = u32(m, stsc.s + 4); i < n; i++) sc.push([u32(m, stsc.s + 8 + i * 12), u32(m, stsc.s + 12 + i * 12)]);
      const offs = []; let si = 0;
      for (let ci = 0; ci < chunks.length; ci++) { let per = sc[0][1]; for (const [first, n] of sc) if (ci + 1 >= first) per = n; let o = chunks[ci]; for (let k = 0; k < per && si < count; k++, si++) { offs.push(o); o += sizes[si]; } }
      return { fourcc, w, h, dur: t / timescale, fps: count / Math.max(0.001, t / timescale), times, sizes, offs, count };
    }
    throw new Error('no HAP video track');
  }
  /* ---------------- player */
  class HapPlayer {
    constructor(url, gl) {
      this.url = url; this.gl = gl; this.cache = new Map(); this.inflight = new Map(); this.ready = false; this.error = null; this.shown = -1;
      this.s3tc = gl.getExtension('WEBGL_compressed_texture_s3tc') || gl.getExtension('WEBKIT_WEBGL_compressed_texture_s3tc');
      this.opened = demux(url).then(info => { Object.assign(this, info); this.rgba = new Uint8Array(this.w * this.h * 4); this.ready = true; }).catch(e => { this.error = e.message; });
    }
    get gpu() { return !!this.s3tc && this.fourcc !== 'HapY' && !this.forceCpu; }
    frameIndex(t) { const ts = this.times; if (!ts || !ts.length) return 0; let lo = 0, hi = ts.length - 1; while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (ts[mid] <= t) lo = mid; else hi = mid - 1; } return lo; }
    load(i) {
      if (this.cache.has(i) || this.inflight.has(i) || i < 0 || i >= this.count) return;
      const p = fetchRange(this.url, this.offs[i], this.sizes[i]).then(b => { const f = decodeFrame(b); if (this.gpu && (f.fmt === 0xB || f.fmt === 0xE)) { f.data = flipDXT(f.data, Math.ceil(this.w / 4) * 4, Math.ceil(this.h / 4) * 4, f.fmt); f.flipped = true; } this.cache.set(i, f); this.inflight.delete(i); if (this.cache.size > 24) { for (const k of this.cache.keys()) { if (Math.abs(k - i) > 12) this.cache.delete(k); if (this.cache.size <= 16) break; } } })
        .catch(e => { this.inflight.delete(i); this.lastErr = e.message; });
      this.inflight.set(i, p);
    }
    show(t, tex, dir = 1) { // upload the frame for time t (seconds) into tex; returns true when a new frame was uploaded
      if (!this.ready) return false;
      const want = this.frameIndex(t);
      // prefetch ahead of the playhead (wrapping for loops); limit concurrent range requests
      for (let k = 0; k < 8 && this.inflight.size < 6; k++) this.load(((want + k * dir) % this.count + this.count) % this.count);
      // show the newest frame we already have at or just behind the playhead (never stall waiting for one frame)
      let i = -1; for (let k = 0; k < 10; k++) { const j = ((want - k * dir) % this.count + this.count) % this.count; if (this.cache.has(j)) { i = j; break; } }
      if (i < 0 || i === this.shown) return false; const f = this.cache.get(i);
      const gl = this.gl; gl.bindTexture(gl.TEXTURE_2D, tex);
      const W = Math.ceil(this.w / 4) * 4, H = Math.ceil(this.h / 4) * 4;
      try {
        if (this.gpu && (f.fmt === 0xB || f.fmt === 0xE)) {
          const fmt = f.fmt === 0xB ? this.s3tc.COMPRESSED_RGB_S3TC_DXT1_EXT : this.s3tc.COMPRESSED_RGBA_S3TC_DXT5_EXT;
          gl.compressedTexImage2D(gl.TEXTURE_2D, 0, fmt, W, H, 0, f.flipped ? f.data : flipDXT(f.data, W, H, f.fmt));
        } else if (f.fmt === 0xB || f.fmt === 0xE || f.fmt === 0xF) {
          if (f.flipped) { f.data = flipDXT(f.data, W, H, f.fmt); f.flipped = false; }
          decodeDXT(f.data, this.w, this.h, f.fmt === 0xF ? 0xE : f.fmt, this.rgba); if (f.fmt === 0xF) ycocg(this.rgba);
          gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, this.w, this.h, 0, gl.RGBA, gl.UNSIGNED_BYTE, this.rgba);
        } else { this.error = f.fmt === 0xC ? 'HAP R (BC7) is not supported yet — convert to HAP or HAP Q' : 'Unsupported HAP texture format'; return false; }
      } catch (e) { if (this.gpu) { this.forceCpu = true; return false; } this.error = e.message; return false; }
      this.shown = i; return true;
    }
    close() { this.cache.clear(); this.closed = true; }
  }
  HapPlayer.decodeFrame = decodeFrame; HapPlayer.snappy = snappy; HapPlayer.decodeDXT = decodeDXT; HapPlayer.flipDXT = flipDXT; HapPlayer.demux = demux; HapPlayer.ycocg = ycocg;
  root.HapPlayer = HapPlayer;
})(typeof window !== 'undefined' ? window : globalThis);
