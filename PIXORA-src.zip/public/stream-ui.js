/* PIXORA — Live Streaming panel: destinations (RTMP / RTMPS / SRT), quality, start / stop, Blackmagic Streaming XML. */
(function () {
  const UI = window.UI, $ = UI.$, $$ = UI.$$, esc = UI.esc, I = UI.icon;
  const sec = (title, body, extra) => `<div class="sec"><h4>${title}${extra || ''}</h4>${body}</div>`;
  UI.MORETABS.push(['stream', 'Live Streaming', 'globe', 'Stream']);
  UI.streamState = null;
  (BVJ.extraHandlers = BVJ.extraHandlers || {}).streamstate = m => { const was = UI.streamState; UI.streamState = m.stream;
    const sig = s => s && JSON.stringify([s.state, s.destinations.map(d => [d.id, d.name, d.on, d.state, d.url, d.hasKey]), s.video, s.audio, s.presets.length]);
    if (UI.rtab === 'stream') { if (sig(was) !== sig(m.stream)) UI.renderRight(true); else live(); } };
  const api = (p, body, method = 'POST') => UI.api('/api/stream' + p, { method, headers: { 'Content-Type': 'application/json' }, body: typeof body === 'string' ? body : JSON.stringify(body || {}) }).then(v => { if (v && v.destinations) UI.streamState = v; return v; }).catch(e => { UI.toast(e.message, 'err'); throw e; });
  const dur = ms => { const s = Math.max(0, ms / 1000 | 0); return `${s / 3600 | 0}:${String((s / 60 | 0) % 60).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`; };
  function live() { const s = UI.streamState, el = $('#stLive'); if (!s || !el) return;
    el.innerHTML = s.state === 'live' ? `<b class="stlive">● LIVE</b> <span class="mono">${dur(Date.now() - s.since)}</span> · ${s.kbps} kb/s · ${s.speed ? (s.speed < 0.95 ? `<span class="err">speed ${s.speed}× — falling behind</span>` : 'speed ' + s.speed + '×') : ''} · ${s.passthrough ? 'H.264 pass-through' : 'x264 ' + s.video.preset}`
      : s.state === 'starting' ? '<b>Starting…</b>' + (s.error ? ` <span class="err small">(retrying: ${esc(s.error)})</span>` : '') : s.state === 'error' ? `<b class="err">Stopped:</b> ${esc(s.error)}` : s.state === 'stopping' ? 'Stopping…' : '<span class="muted">Off air</span>'; }
  setInterval(() => { if (UI.rtab === 'stream') live(); }, 1000);

  UI.panels.stream = {
    sig: () => JSON.stringify(UI.streamState ? [UI.streamState.state, UI.streamState.destinations.length] : null),
    render() {
      const s = UI.streamState; if (!s) { api('', null, 'GET').then(() => UI.renderRight(true)).catch(() => {}); return '<p class="muted">Loading…</p>'; }
      const on = s.state === 'live' || s.state === 'starting';
      let h = `<div class="sthead"><div id="stLive" class="small"></div><button class="btn ${on ? 'danger' : 'primary'} stbig" data-st="${on ? 'stop' : 'start'}">${on ? '■ Stop stream' : '● Go live'}</button></div>`;
      if (!s.ffmpeg) h += '<p class="err small">Live streaming needs ffmpeg on this computer.</p>';
      const presetOpts = cur => `<option value="">Preset…</option>` + s.presets.map((p, i) => `<optgroup label="${esc(p.service)}${p.imported ? ' (imported)' : ''}">${p.servers.map((x, j) => `<option value="${i}:${j}">${esc(p.service)} · ${esc(x.name)}</option>`).join('')}</optgroup>`).join('');
      h += sec('Destinations', (s.destinations.map(d => `<div class="stdest ${d.state}" data-dest="${d.id}">
          <label class="djchk"><input type="checkbox" data-df="on" ${d.on ? 'checked' : ''}></label>
          <input type="text" data-df="name" value="${esc(d.name)}" style="width:110px" title="Name">
          <select data-dpreset>${presetOpts()}</select>
          <input type="text" data-df="url" value="${esc(d.url)}" placeholder="rtmp://… or srt://host:port" style="flex:1;min-width:160px">
          ${d.kind === 'srt' ? '' : `<input type="password" data-df="key" value="${esc(d.key)}" placeholder="stream key" style="width:130px" autocomplete="off">`}
          <span class="stds small">${d.state === 'error' ? `<span class="err" title="${esc(d.error)}">failed</span>` : d.state === 'live' ? '<span class="ok">● live</span>' : ''}</span>
          <button class="btn sm icon" data-ddel title="Remove">${I('trash')}</button></div>`).join('') || '<p class="muted small">No destinations yet.</p>') +
        `<div class="toolbar" style="margin-top:6px"><button class="btn sm" data-dadd>${I('plus')}Add destination</button><label class="btn sm" style="cursor:pointer">${I('upload')}Import Blackmagic Streaming XML<input type="file" accept=".xml" data-xml hidden></label></div>
        <div class="hint">Every switched-on destination gets the same stream at once; if one fails the others carry on. Stream keys are kept on this computer only.${s.srt ? '' : ' SRT is not available in this ffmpeg.'}${s.rtmps ? '' : ' RTMPS is not available in this ffmpeg.'}</div>`);
      const v = s.video, sel = (k, opts, cur) => `<select data-vf="${k}">${opts.map(([x, l]) => `<option value="${x}" ${String(cur) === String(x) ? 'selected' : ''}>${l}</option>`).join('')}</select>`;
      h += sec('Quality', `<div class="row wide"><label>Video</label><div class="ctl">${sel('mode', [['auto', 'Automatic — H.264 straight from the output when possible (least CPU)'], ['reencode', 'Always re-encode with x264 (most compatible)']], v.mode)}</div></div>
        <div class="row wide"><label>Bitrate</label><div class="ctl"><input type="number" data-vf="kbps" value="${v.kbps}" min="500" max="50000" step="500" style="width:90px"> kb/s · ${sel('fps', [[24, '24'], [25, '25'], [30, '30'], [50, '50'], [60, '60']].map(([a, b]) => [a, b + ' fps']), v.fps)} ${sel('height', [[720, '720p'], [1080, '1080p'], [1440, '1440p'], [2160, '2160p']], v.height)}</div></div>
        <div class="row wide"><label>Encoder speed</label><div class="ctl">${sel('preset', ['ultrafast', 'superfast', 'veryfast', 'faster', 'fast', 'medium'].map(x => [x, x]), v.preset)} <span class="small muted">audio</span> <input type="number" data-af="kbps" value="${s.audio.kbps}" min="64" max="320" step="32" style="width:64px"> kb/s</div></div>
        <div class="hint">YouTube 1080p30: 6 000–8 000 kb/s; Facebook up to 8 000; Twitch 6 000. Pass-through sends the output at its own size; resolution and encoder speed apply when re-encoding. Streams the main (primary) output window with the audio mix.</div>`);
      return h;
    },
    after(pane) {
      live();
      const destOf = el => el.closest('[data-dest]') && el.closest('[data-dest]').dataset.dest;
      pane.onclick = e => { const t = e.target.closest('button'); if (!t) return;
        if (t.dataset.st) return api('/' + t.dataset.st).then(() => UI.renderRight(true)).catch(() => {});
        if ('dadd' in t.dataset) return api('', { destination: { name: 'Stream ' + (UI.streamState.destinations.length + 1), url: '', on: true } }).then(() => UI.renderRight(true));
        if ('ddel' in t.dataset) return api('', { destination: { id: destOf(t), remove: true } }).then(() => UI.renderRight(true)); };
      pane.onchange = e => { const x = e.target, d = x.dataset;
        if (d.df) return api('', { destination: { id: destOf(x), [d.df]: x.type === 'checkbox' ? x.checked : x.value } });
        if ('dpreset' in d && x.value) { const [i, j] = x.value.split(':').map(Number), p = UI.streamState.presets[i], sv = p.servers[j]; return api('', { destination: { id: destOf(x), name: p.service, url: sv.url, kind: /^srt:/i.test(sv.url) ? 'srt' : 'rtmp' } }).then(() => UI.renderRight(true)); }
        if (d.vf) return api('', { video: { [d.vf]: x.type === 'number' ? +x.value : x.value } }); if (d.af) return api('', { audio: { kbps: +x.value } });
        if ('xml' in d && x.files[0]) x.files[0].text().then(t => api('/xml', t)).then(r => { UI.toast(`Imported ${r.imported} streaming service${r.imported === 1 ? '' : 's'}`, 'ok'); return api('', null, 'GET'); }).then(() => UI.renderRight(true)).catch(() => {}); };
    },
  };
})();
