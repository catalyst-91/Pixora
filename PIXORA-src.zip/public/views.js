/* PIXORA — Views: job-based layouts for the controller, plus custom views the operator saves.
 * A view decides which panel tabs are pinned, which tab/library opens, how big the side panel, library and preview are,
 * the clip size, and which top-bar controls are hidden. Resizing panels while in a view is remembered for that view. */
(function () {
  const UI = window.UI, $ = UI.$, $$ = UI.$$, esc = UI.esc, I = UI.icon;
  const root = document.documentElement;

  const TEMPLATES = [
    { id: 'vj', name: 'VJ / Live', icon: 'play', desc: 'Clip grid front and centre for triggering to music: clips, layers, effects, mods, DJ Link and MIDI.',
      tabs: ['clip', 'layer', 'comp', 'cues', 'mods', 'djlink', 'midi'], rtab: 'clip', btab: 'files', rightW: 420, bottomH: 280, monH: 0, zoom: 118, hide: [] },
    { id: 'led', name: 'LED & Mapping', icon: 'screen', desc: 'Screen mapping, outputs, pixel and DMX with a big preview. For building and checking LED walls and projection.',
      tabs: ['led', 'output', 'comp', 'dmx', 'preflight', 'check'], rtab: 'led', btab: 'inputs', rightW: 600, bottomH: 200, monH: 36, zoom: 96, hide: ['speed', 'xfade', 'learn'] },
    { id: 'show', name: 'Show Operator', icon: 'restart', desc: 'Cue list and GO for corporate, theatre and award shows, with show lock, timecode, schedule and health beside it.',
      tabs: ['cues', 'switcher', 'show', 'tc', 'schedule', 'health', 'check'], rtab: 'cues', btab: 'files', rightW: '46vw', bottomH: 0, monH: 26, zoom: 90, hide: ['speed', 'xfade', 'learn', 'decks'] },
    { id: 'production', name: 'Production & Cameras', icon: 'cam', desc: 'Program / preview switching with CUT, AUTO and a T-bar, overlays and timers, plus cameras, routers, decks and encoders. For broadcast-style and IMAG work.',
      tabs: ['switcher', 'mixer', 'devices', 'replay', 'output', 'cues', 'clip', 'layer'], rtab: 'switcher', btab: 'inputs', rightW: 560, bottomH: 230, monH: 30, zoom: 100, hide: ['speed', 'learn'] },
    { id: 'replay', name: 'Replay & Sports', icon: 'restart', desc: 'Instant replay with four angles, slow motion and events, beside cameras and the cue list. For sport, awards and live events.',
      tabs: ['replay', 'devices', 'cues', 'clip', 'layer'], rtab: 'replay', btab: 'inputs', rightW: 560, bottomH: 220, monH: 30, zoom: 96, hide: ['speed', 'learn', 'xfade'] },
    { id: 'stream', name: 'Stream & Record', icon: 'rec', desc: 'Recording, streaming encoders, health and the change log at a glance.',
      tabs: ['stream', 'output', 'mixer', 'devices', 'health', 'reports', 'log'], rtab: 'stream', btab: 'shows', rightW: 520, bottomH: 200, monH: 34, zoom: 100, hide: ['speed', 'learn'] },
    { id: 'signage', name: 'Signage & Sponsors', icon: 'globe', desc: 'Unattended playback: sponsor rotation and proof of play, schedules, data feeds, health and reports.',
      tabs: ['sponsors', 'schedule', 'data', 'health', 'reports', 'log'], rtab: 'sponsors', btab: 'files', rightW: 520, bottomH: 260, monH: 0, zoom: 100, hide: ['speed', 'xfade', 'learn'] },
    { id: 'setup', name: 'Setup & Programming', icon: 'midi', desc: 'The pre-show build: controllers, DMX, console link, data, multi-machine sync, users and team.',
      tabs: ['comp', 'midi', 'dmx', 'console', 'data', 'sync', 'access', 'team'], rtab: 'midi', btab: 'shaders', rightW: 520, bottomH: 300, monH: 0, zoom: 100, hide: [] },
    { id: 'perform', name: 'Perform (grid only)', icon: 'eye', desc: 'Just the clip grid, big and touch-friendly. Nothing else on screen.',
      tabs: ['clip', 'layer', 'cues'], rtab: 'clip', btab: 'files', rightW: 0, bottomH: 0, monH: 0, zoom: 170, hide: ['speed', 'learn'] },
  ];
  const HIDEABLE = [['speed', 'Speed fader'], ['xfade', 'A/B crossfader'], ['learn', 'MIDI Learn button'], ['decks', 'Deck tabs'], ['monitor', 'Output preview'], ['test', 'LED test button'], ['status', 'Status bar']];
  const hideEls = { speed: () => $('#speed') && $('#speed').closest('.tgroup'), xfade: () => $('.xfade'), learn: () => $('#learnBtn'), decks: () => $('#decks') && $('#decks').closest('.tgroup'), monitor: () => $('#monitor'), test: () => $('#testBtn'), status: () => $('#status') };

  const load = (k, d) => { try { return JSON.parse(localStorage[k]) || d; } catch { return d; } };
  let custom = load('pixoraViews', []), tweaks = load('pixoraViewTweaks', {}), active = localStorage.pixoraView || 'vj';
  const saveAll = () => { try { localStorage.pixoraViews = JSON.stringify(custom); localStorage.pixoraViewTweaks = JSON.stringify(tweaks); localStorage.pixoraView = active; } catch {} };
  const all = () => TEMPLATES.concat(custom);
  const byId = id => all().find(v => v.id === id) || TEMPLATES[0];
  const css = v => typeof v === 'number' ? v + 'px' : v;
  UI.views = { TEMPLATES, all, current: () => byId(active) };

  /* ---------- apply */
  function apply(id, opts = {}) {
    const base = byId(id); active = base.id; saveAll();
    const v = Object.assign({}, base, opts.noTweaks ? {} : tweaks[base.id] || {});
    const rightOff = !v.rightW || v.rightW === '0' || v.rightW === '0px', botOff = !v.bottomH;
    root.style.setProperty('--right-w', rightOff ? '0px' : css(v.rightW));
    root.style.setProperty('--bottom-h', botOff ? '0px' : css(v.bottomH));
    root.style.setProperty('--mon-h', v.monH ? v.monH + 'vh' : 'auto');
    document.body.classList.toggle('v-noright', rightOff); document.body.classList.toggle('v-nobottom', botOff);
    document.body.dataset.view = base.id;
    for (const [k] of HIDEABLE) { const el = hideEls[k](); if (el) el.classList.toggle('v-hidden', (v.hide || []).includes(k)); }
    if (v.zoom && $('#zoom')) { $('#zoom').value = v.zoom; $('#zoom').dispatchEvent(new Event('input')); }
    UI.viewTabs = v.tabs && v.tabs.length ? v.tabs : null;
    const want = opts.keepTab && UI.viewTabs && UI.viewTabs.includes(UI.rtab) ? UI.rtab : v.rtab;
    if (want && UI.panels[want] && UI.setRtab) UI.setRtab(want); else UI.renderTabs();
    if (!botOff && v.btab && UI.bpanels && UI.bpanels[v.btab] && UI.setBtab) UI.setBtab(v.btab);
    renderButton();
    if (!opts.quiet) UI.toast('View: ' + base.name, 'ok');
  }

  /* ---------- top-bar switcher */
  function renderButton() {
    let b = $('#viewBtn');
    if (!b) { b = UI.el(`<button class="btn sm" id="viewBtn" title="View: change the layout for the job (Ctrl+Alt+1…9)"></button>`); const after = $('#menuBtn'); after.parentNode.insertBefore(b, after.nextSibling); b.onclick = openMenu; }
    const v = byId(active); b.innerHTML = `${I(v.icon || 'eye')}<span class="hide-md">${esc(v.name)}</span>${tweaks[v.id] ? '<i class="vtweak" title="Resized since the view was chosen"></i>' : ''}${I('down')}`;
  }
  function openMenu() {
    const r = $('#viewBtn').getBoundingClientRect(), items = [];
    TEMPLATES.forEach((v, i) => items.push({ label: (v.id === active ? '● ' : '') + v.name, icon: v.icon, k: 'Ctrl+Alt+' + (i + 1), click: () => apply(v.id) }));
    if (custom.length) { items.push('-'); custom.forEach(v => items.push({ label: (v.id === active ? '● ' : '') + v.name, icon: v.icon || 'save', click: () => apply(v.id) })); }
    items.push('-');
    if (tweaks[active]) items.push({ label: 'Reset this view’s panel sizes', icon: 'restart', click: () => { delete tweaks[active]; saveAll(); apply(active, { quiet: true }); } });
    items.push({ label: 'Save current layout as a view…', icon: 'save', click: () => editView(null) });
    items.push({ label: 'Manage views…', icon: 'wand', click: manage });
    UI.menu(r.left, r.bottom + 4, items);
  }

  /* ---------- custom views */
  function snapshot() {
    const v = Object.assign({}, byId(active), tweaks[active] || {});
    return { tabs: (UI.viewTabs || v.tabs || []).slice(), rtab: UI.rtab, btab: UI.btab, rightW: v.rightW, bottomH: v.bottomH, monH: v.monH || 0, zoom: +($('#zoom') || {}).value || v.zoom, hide: (v.hide || []).slice() };
  }
  function editView(v) {
    const isNew = !v; const d = v ? Object.assign({}, v) : Object.assign({ name: 'My view', icon: 'save' }, snapshot());
    const tabs = UI.ALLTABS(); const rw = typeof d.rightW === 'number' ? d.rightW : d.rightW ? Math.round(parseFloat(d.rightW) / 100 * innerWidth) : 0;
    const body = `<div class="row wide"><label>Name</label><input type="text" id="vwName" value="${esc(d.name)}"></div>
      <div class="row wide"><label>Start from</label><select id="vwBase"><option value="">— keep what's below —</option>${TEMPLATES.map(t => `<option value="${t.id}">${esc(t.name)}</option>`).join('')}</select></div>
      <h4 class="vwh">Pinned panel tabs <span class="muted small">(the rest stay under More ▾)</span></h4>
      <div class="vwtabs">${tabs.map(t => `<label><input type="checkbox" data-vtab="${t[0]}" ${d.tabs.includes(t[0]) ? 'checked' : ''}> ${esc(t[3])}</label>`).join('')}</div>
      <div class="row wide"><label>Opens on</label><select id="vwRtab">${tabs.map(t => `<option value="${t[0]}" ${t[0] === d.rtab ? 'selected' : ''}>${esc(t[1])}</option>`).join('')}</select></div>
      <div class="row wide"><label>Library tab</label><select id="vwBtab">${Object.keys(UI.bpanels || {}).map(k => `<option value="${k}" ${k === d.btab ? 'selected' : ''}>${esc(($(`#btabs [data-bt="${k}"]`) || { textContent: k }).textContent)}</option>`).join('')}</select></div>
      <h4 class="vwh">Sizes</h4>
      <div class="row"><label>Side panel</label><input type="range" id="vwRight" min="0" max="${Math.round(innerWidth * 0.7)}" step="10" value="${rw}"><output></output></div>
      <div class="row"><label>Library</label><input type="range" id="vwBottom" min="0" max="${Math.round(innerHeight * 0.6)}" step="10" value="${d.bottomH || 0}"><output></output></div>
      <div class="row"><label>Preview</label><input type="range" id="vwMon" min="0" max="60" step="1" value="${d.monH || 0}"><output></output></div>
      <div class="row"><label>Clip size</label><input type="range" id="vwZoom" min="70" max="190" value="${d.zoom || 118}"><output></output></div>
      <h4 class="vwh">Hide</h4><div class="vwtabs">${HIDEABLE.map(([k, l]) => `<label><input type="checkbox" data-vhide="${k}" ${(d.hide || []).includes(k) ? 'checked' : ''}> ${esc(l)}</label>`).join('')}</div>
      <p class="muted small">0 hides the side panel or library. Changes preview live; Cancel puts the current view back.</p>`;
    const read = bg => ({ name: $('#vwName', bg).value.trim() || 'My view', icon: d.icon || 'save', tabs: $$('[data-vtab]', bg).filter(i => i.checked).map(i => i.dataset.vtab), rtab: $('#vwRtab', bg).value, btab: $('#vwBtab', bg).value,
      rightW: +$('#vwRight', bg).value, bottomH: +$('#vwBottom', bg).value, monH: +$('#vwMon', bg).value, zoom: +$('#vwZoom', bg).value, hide: $$('[data-vhide]', bg).filter(i => i.checked).map(i => i.dataset.vhide) });
    const prev = active;
    const m = UI.modal(isNew ? 'Save view' : 'Edit view', body, [{ label: 'Cancel', click: () => apply(prev, { quiet: true, keepTab: true }) }, { label: isNew ? 'Save view' : 'Save', cls: 'primary', click: bg => {
      const nv = Object.assign(read(bg), { id: v ? v.id : 'c' + Date.now().toString(36), custom: true });
      if (!nv.tabs.length) { UI.toast('Pin at least one tab', 'err'); return false; }
      const i = custom.findIndex(x => x.id === nv.id); if (i >= 0) custom[i] = nv; else custom.push(nv); delete tweaks[nv.id]; saveAll(); apply(nv.id, { quiet: true }); UI.toast('Saved view “' + nv.name + '”', 'ok'); } }], { width: '520px' });
    const outs = () => { $$('input[type=range]', m).forEach(r => { const o = r.nextElementSibling; o.textContent = r.id === 'vwMon' ? (+r.value ? r.value + '% h' : 'auto') : r.id === 'vwZoom' ? r.value : +r.value ? r.value + 'px' : 'off'; }); };
    const preview = () => { outs(); const p = read(m); root.style.setProperty('--right-w', p.rightW + 'px'); root.style.setProperty('--bottom-h', p.bottomH + 'px'); root.style.setProperty('--mon-h', p.monH ? p.monH + 'vh' : 'auto');
      document.body.classList.toggle('v-noright', !p.rightW); document.body.classList.toggle('v-nobottom', !p.bottomH); for (const [k] of HIDEABLE) { const el = hideEls[k](); if (el) el.classList.toggle('v-hidden', p.hide.includes(k)); } };
    m.addEventListener('input', preview); outs();
    $('#vwBase', m).onchange = e => { const t = TEMPLATES.find(x => x.id === e.target.value); if (!t) return;
      $$('[data-vtab]', m).forEach(i => i.checked = t.tabs.includes(i.dataset.vtab)); $('#vwRtab', m).value = t.rtab; if (UI.bpanels[t.btab]) $('#vwBtab', m).value = t.btab;
      $('#vwRight', m).value = typeof t.rightW === 'number' ? t.rightW : Math.round(parseFloat(t.rightW) / 100 * innerWidth); $('#vwBottom', m).value = t.bottomH; $('#vwMon', m).value = t.monH; $('#vwZoom', m).value = t.zoom;
      $$('[data-vhide]', m).forEach(i => i.checked = t.hide.includes(i.dataset.vhide)); preview(); };
  }
  function manage() {
    const body = () => `${custom.length ? custom.map(v => `<div class="kv vwrow"><span>${I(v.icon || 'save')} ${esc(v.name)} <span class="muted small">${v.tabs.length} tabs</span></span><span><button class="btn sm" data-ve="${v.id}">Edit</button> <button class="btn sm" data-vu="${v.id}">Use</button> <button class="btn sm icon" data-vd="${v.id}">${I('trash')}</button></span></div>`).join('') : '<p class="muted">No custom views yet. Arrange the screen the way you like it, then choose “Save current layout as a view…”.</p>'}
      <div class="toolbar" style="margin-top:10px"><button class="btn sm" data-vx>${I('upload')}Export views</button><button class="btn sm" data-vi>${I('folder')}Import views</button></div>
      <p class="muted small">Views are kept in this browser, so each operator position can have its own. Export to move them to another machine.</p>`;
    const m = UI.modal('Views', body(), [{ label: 'Done' }], { width: '480px' }); const mb = $('.mbody', m);
    mb.onclick = e => {
      const t = e.target.closest('button'); if (!t) return;
      if (t.dataset.ve) { m.close(); return editView(custom.find(v => v.id === t.dataset.ve)); }
      if (t.dataset.vu) { m.close(); return apply(t.dataset.vu); }
      if (t.dataset.vd) { custom = custom.filter(v => v.id !== t.dataset.vd); delete tweaks[t.dataset.vd]; if (active === t.dataset.vd) active = 'vj'; saveAll(); apply(active, { quiet: true, keepTab: true }); mb.innerHTML = body(); return; }
      if ('vx' in t.dataset) { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify({ pixoraViews: 1, views: custom }, null, 2)], { type: 'application/json' })); a.download = 'pixora-views.json'; a.click(); return; }
      if ('vi' in t.dataset) { const f = document.createElement('input'); f.type = 'file'; f.accept = '.json'; f.onchange = async () => { try { const j = JSON.parse(await f.files[0].text()); const list = (j.views || []).filter(v => v && v.name && Array.isArray(v.tabs));
        for (const v of list) { v.id = 'c' + Math.random().toString(36).slice(2, 9); v.custom = true; custom.push(v); } saveAll(); renderButton(); mb.innerHTML = body(); UI.toast(`Imported ${list.length} view${list.length === 1 ? '' : 's'}`, 'ok'); } catch { UI.toast('That is not a PIXORA views file', 'err'); } }; f.click(); }
    };
  }

  /* ---------- remember resizing per view */
  function tweak(k, val) { tweaks[active] = Object.assign(tweaks[active] || {}, { [k]: val }); saveAll(); renderButton(); }
  const sp = $('#split'); if (sp) sp.addEventListener('pointerup', () => tweak('bottomH', Math.round($('#bottom').getBoundingClientRect().height)));
  $('#zoom') && $('#zoom').addEventListener('change', e => tweak('zoom', +e.target.value));
  // side panel width splitter
  const right = $('#right');
  if (right) { const vs = UI.el('<div class="vsplit" title="Drag to resize the panel"></div>'); right.appendChild(vs); let x0, w0;
    vs.addEventListener('pointerdown', e => { x0 = e.clientX; w0 = right.getBoundingClientRect().width; vs.setPointerCapture(e.pointerId); });
    vs.addEventListener('pointermove', e => { if (x0 == null) return; const w = Math.max(300, Math.min(innerWidth - 360, w0 + (x0 - e.clientX))); root.style.setProperty('--right-w', w + 'px'); });
    vs.addEventListener('pointerup', () => { if (x0 == null) return; x0 = null; tweak('rightW', Math.round(right.getBoundingClientRect().width)); }); }
  // remember tab changes as part of the view only when the user pins (tabs outside the pin list stay temporary)

  /* ---------- keys: Ctrl+Alt+1…9 */
  addEventListener('keydown', e => {
    if (!(e.ctrlKey || e.metaKey) || !e.altKey || e.target.closest('input,textarea,select')) return;
    const n = +e.key || (/^Digit\d$/.test(e.code) ? +e.code.slice(5) : 0); if (!n) return;
    const v = all()[n - 1]; if (v) { e.preventDefault(); apply(v.id); }
  });

  UI.applyView = apply;
  apply(active, { quiet: true, keepTab: true });
})();
