/* PIXORA — Switcher panel: program / preview with CUT, AUTO and a T-bar, 4 overlay channels, shared timers. */
(function () {
  const UI = window.UI, $ = UI.$, $$ = UI.$$, esc = UI.esc, I = UI.icon;
  const sec = (title, body, extra) => `<div class="sec"><h4>${title}${extra || ''}</h4>${body}</div>`;
  UI.MORETABS.push(['switcher', 'Switcher, Overlays & Timers', 'screen', 'Switcher']);
  const cmd = c => UI.cmd(c);
  const STYLES = [['fade', 'Fade'], ['cut', 'Cut'], ['dip', 'Dip'], ['wipe-left', 'Wipe →'], ['wipe-right', 'Wipe ←'], ['wipe-up', 'Wipe ↑'], ['wipe-down', 'Wipe ↓'], ['split', 'Split'], ['stinger', 'Stinger']];
  const clipName = c => !c ? '' : c.name || (c.src ? c.src.split('/').pop() : c.type);
  const timerVal = t => { const now = BVJ.now(), el = t.base + (t.running ? (now - t.startedAt) / 1000 : 0); let v;
    if (t.mode === 'up') v = Math.floor(el); else if (t.mode === 'to' && /^\d{1,2}:\d{2}$/.test(t.until)) { const [h, m] = t.until.split(':').map(Number), d = new Date(now), g = new Date(d); g.setHours(h, m, 0, 0); if (g < d) g.setDate(g.getDate() + 1); v = Math.ceil((g - d) / 1000); } else v = Math.max(0, Math.ceil(t.secs - el));
    const hh = Math.floor(v / 3600), mm = Math.floor(v / 60) % 60, ss = v % 60; return (hh ? hh + ':' + String(mm).padStart(2, '0') : mm) + ':' + String(ss).padStart(2, '0'); };
  setInterval(() => { if (UI.rtab !== 'switcher') return; const s = UI.st(); if (!s) return; (s.timers || []).forEach((t, i) => { const el = $(`[data-tmval="${i}"]`); if (el) el.textContent = timerVal(t); }); }, 200);
  let dragTbar = false;

  UI.panels.switcher = {
    sig: s => JSON.stringify([s.switcher, s.overlays && s.overlays.map(o => [clipName(o.clip), o.on, o.dur, o.transition]), (s.timers || []).map(t => [t.name, t.mode, t.secs, t.until, t.running]),
      s.layers.map(l => l.name), (s.layers[s.switcher ? s.switcher.layer : 0] || {}).active, (s.layers[s.switcher ? s.switcher.layer : 0] || { clips: [] }).clips.map(clipName), (s.layers[s.switcher ? s.switcher.layer : 0] || {}).transition]),
    render(s) {
      const sw = s.switcher || {}, L = s.layers[sw.layer] || { clips: [] }, b = `layers.${sw.layer}`;
      let h = sec('Switcher', `<div class="row wide"><label>Program layer</label><div class="ctl"><select data-sw="layer">${s.layers.map((l, i) => `<option value="${i}" ${sw.layer === i ? 'selected' : ''}>Layer ${i + 1} · ${esc(l.name || '')}</option>`).join('')}</select>
          <label class="djchk" style="margin-left:8px"><input type="checkbox" data-sw="on" ${sw.on ? 'checked' : ''}> Preview / program mode</label></div></div>
        ${sw.on ? `<div class="swwrap"><div class="swins">${L.clips.map((c, i) => c ? `<button class="swin ${L.active === i ? 'pgm' : ''} ${sw.preview === i ? 'pvw' : ''}" data-swin="${i}" title="Click: preview · Double-click: straight to program"><span class="mono">${i + 1}</span>${esc(clipName(c))}</button>` : '').join('') || '<p class="muted small">Put sources (cameras, NDI, videos, titles) in this layer’s slots.</p>'}</div>
          <div class="swtbar"><input type="range" min="0" max="100" value="${Math.round((sw.tbar || 0) * 100)}" data-tbar orient="vertical" title="T-bar"><span class="small muted">T-bar</span></div></div>
          <div class="swbtns"><button class="btn danger swbig" data-swa="cut" title="Enter">CUT</button><button class="btn primary swbig" data-swa="auto" title="Space">AUTO</button>
            <select data-path="${b}.transition">${STYLES.map(([v, l]) => `<option value="${v}" ${L.transition === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
            <input type="number" data-path="${b}.transitionDur" step="0.1" min="0" max="10" style="width:64px" title="Seconds"><span class="small muted">s</span></div>
          <div class="hint">Program = red, preview = green. CUT and AUTO swap them; drag the T-bar for a manual transition. ${L.transition === 'stinger' ? 'Stinger video is set in Layer ▸ Transition.' : ''} Keys here: 1–9 preview · Enter cut · Space auto.</div>` : '<p class="muted small">Turn on preview / program mode to switch this layer like a vision mixer: pick the next source on preview, then CUT, AUTO or T-bar it to air.</p>'}`);
      h += sec('Overlays', `<div class="ovgrid">${(s.overlays || []).map((o, i) => `<div class="ovch ${o.on ? 'on' : ''}" data-ovdrop="${i + 1}">
          <button class="btn ${o.on ? 'danger' : ''} ovbtn" data-ov="${i + 1}" ${o.clip ? '' : 'disabled'}>${i + 1}</button>
          <div class="ovinfo"><b>${o.clip ? esc(clipName(o.clip)) : '<span class="muted">empty</span>'}</b><div class="small muted">${o.clip ? (o.on ? 'on air' : 'ready') : 'drop a clip or title here'}</div></div>
          <button class="btn sm" data-ovsel="${i + 1}" title="Use the clip selected in the grid">${I('copy')}</button>${o.clip ? `<button class="btn sm icon" data-ovclr="${i + 1}" title="Empty">${I('x')}</button>` : ''}
          <select data-ovtr="${i + 1}" title="In / out">${STYLES.filter(x => x[0] !== 'stinger').map(([v, l]) => `<option value="${v}" ${o.transition === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
          <input type="number" data-ovdur="${i + 1}" value="${o.dur}" min="0" max="10" step="0.1" style="width:52px" title="Seconds"></div>`).join('')}</div>
        <div class="hint">Overlays sit above every layer: lower thirds, logos, scorebugs, a guest picture-in-picture. Keys here: Shift+1–4. Cues and MIDI: “Overlay channel on/off”.</div>`);
      h += sec('Timers', `<div class="tmlist">${(s.timers || []).map((t, i) => `<div class="tmrow ${t.running ? 'run' : ''}"><input type="text" value="${esc(t.name)}" data-tmname="${esc(t.name)}" style="width:96px">
          <select data-tmmode="${esc(t.name)}"><option value="down" ${t.mode === 'down' ? 'selected' : ''}>Count down</option><option value="up" ${t.mode === 'up' ? 'selected' : ''}>Count up</option><option value="to" ${t.mode === 'to' ? 'selected' : ''}>Count to time</option></select>
          ${t.mode === 'to' ? `<input type="text" value="${esc(t.until)}" placeholder="19:30" data-tmuntil="${esc(t.name)}" style="width:56px">` : t.mode === 'down' ? `<input type="number" value="${Math.round(t.secs / 60 * 100) / 100}" step="0.5" min="0" data-tmmin="${esc(t.name)}" style="width:56px" title="Minutes"><span class="small muted">min</span>` : ''}
          <b class="mono tmval" data-tmval="${i}">${timerVal(t)}</b>
          <button class="btn sm ${t.running ? 'danger' : 'primary'}" data-tm="toggle" data-n="${esc(t.name)}">${t.running ? '❚❚' : '▶'}</button><button class="btn sm" data-tm="reset" data-n="${esc(t.name)}">${I('restart')}</button>
          ${t.mode === 'down' ? `<button class="btn sm" data-tm="add" data-secs="30" data-n="${esc(t.name)}">+30s</button>` : ''}<button class="btn sm icon" data-tm="delete" data-n="${esc(t.name)}">${I('trash')}</button></div>`).join('')}</div>
        <button class="btn sm" data-tmadd>${I('plus')}Add timer</button>
        <div class="hint">Use a timer in any text or title as <span class="mono">{{timer.Name}}</span>, e.g. “Doors in {{timer.Doors}}”. Also: <span class="mono">{{clock}}</span>, <span class="mono">{{time}}</span>, <span class="mono">{{date}}</span>. Title ▸ Countdown can follow a timer too. All outputs show the same time.</div>`);
      return h;
    },
    after(pane) {
      pane.onclick = e => {
        const t = e.target.closest('button'); if (!t) return; const d = t.dataset;
        if (d.swin != null) return cmd({ op: 'switcher', a: 'preview', clip: +d.swin });
        if (d.swa) return cmd({ op: 'switcher', a: d.swa });
        if (d.ov) return cmd({ op: 'overlay', n: +d.ov, a: 'toggle' });
        if (d.ovclr) return cmd({ op: 'overlay', n: +d.ovclr, a: 'set', clip: null });
        if (d.ovsel) { const s = UI.st(), c = UI.sel && s.layers[UI.sel.layer] && s.layers[UI.sel.layer].clips[UI.sel.clip]; if (!c) return UI.toast('Select a clip in the grid first', 'err'); return cmd({ op: 'overlay', n: +d.ovsel, a: 'set', clip: JSON.parse(JSON.stringify(c)) }); }
        if (d.tm) return cmd({ op: 'timer', name: d.n, a: d.tm, secs: +d.secs || 0 });
        if ('tmadd' in d) { const n = 'Timer ' + ((UI.st().timers || []).length + 1); return cmd({ op: 'timer', name: n, a: 'set', mode: 'down', secs: 300 }); }
      };
      pane.ondblclick = e => { const t = e.target.closest('[data-swin]'); if (t) cmd({ op: 'switcher', a: 'program', clip: +t.dataset.swin, cut: true }); };
      pane.onchange = e => { const x = e.target, d = x.dataset;
        if (d.sw) return cmd({ op: 'switcher', a: 'set', [d.sw]: x.type === 'checkbox' ? x.checked : +x.value });
        if (d.ovtr) return cmd({ op: 'overlay', n: +d.ovtr, a: 'set', transition: x.value }); if (d.ovdur) return cmd({ op: 'overlay', n: +d.ovdur, a: 'set', dur: +x.value });
        if (d.tmname) return cmd({ op: 'timer', name: d.tmname, a: 'set', name2: x.value }); if (d.tmmode) return cmd({ op: 'timer', name: d.tmmode, a: 'set', mode: x.value });
        if (d.tmmin) return cmd({ op: 'timer', name: d.tmmin, a: 'set', secs: Math.round(+x.value * 60) }); if (d.tmuntil) return cmd({ op: 'timer', name: d.tmuntil, a: 'set', until: x.value });
        if ('tbar' in d) { dragTbar = false; const v = +x.value / 100; if (v >= 0.99) { cmd({ op: 'switcher', a: 'tbar', value: 1 }); x.value = 0; } } };
      pane.oninput = e => { if ('tbar' in e.target.dataset) { dragTbar = true; cmd({ op: 'switcher', a: 'tbar', value: Math.min(0.995, +e.target.value / 100) }); } };
      // drop a library item or clip onto an overlay channel
      pane.ondragover = e => { if (e.target.closest('[data-ovdrop]')) e.preventDefault(); };
      pane.ondrop = e => { const ch = e.target.closest('[data-ovdrop]'); if (!ch) return; e.preventDefault(); let c = null; try { c = JSON.parse(e.dataTransfer.getData('bvj/clip') || 'null'); } catch {}
        if (c) cmd({ op: 'overlay', n: +ch.dataset.ovdrop, a: 'set', clip: c }); };
    },
  };
  addEventListener('keydown', e => {
    if (UI.rtab !== 'switcher' || e.ctrlKey || e.metaKey || e.altKey || e.target.closest('input,textarea,select,[contenteditable]')) return;
    const s = UI.st(); if (!s) return; let done = true;
    if (e.shiftKey && /^Digit[1-4]$/.test(e.code)) cmd({ op: 'overlay', n: +e.code.slice(5), a: 'toggle' });
    else if (!e.shiftKey && /^[1-9]$/.test(e.key) && s.switcher && s.switcher.on) cmd({ op: 'switcher', a: 'preview', clip: +e.key - 1 });
    else if (e.key === 'Enter' && s.switcher && s.switcher.on) cmd({ op: 'switcher', a: 'cut' });
    else if (e.key === ' ' && s.switcher && s.switcher.on) cmd({ op: 'switcher', a: 'auto' });
    else done = false;
    if (done) { e.preventDefault(); e.stopPropagation(); }
  }, true);
})();
