/* PIXORA — DJ Link panel: Pioneer DJ PRO DJ LINK Bridge (and other TCNet nodes such as ShowKontrol). */
(function () {
  const UI = window.UI, $ = UI.$, esc = UI.esc, I = UI.icon;
  const sec = (title, body, extra) => `<div class="sec"><h4>${title}${extra || ''}</h4>${body}</div>`;
  UI.MORETABS.push(['djlink', 'DJ Link & Ableton Link', 'midi', 'DJ / Link']);
  let info = null, poll = null;
  const load = () => UI.api('/api/tcnet').then(r => { const first = !info || !$('#djDecks'); info = r; if (UI.rtab !== 'djlink') return; if (first) UI.renderRight(true); else UI.panels.djlink.live($('#rpane')); }).catch(() => {});
  const save = c => UI.api('/api/tcnet', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(c) }).then(r => { info = r; UI.renderRight(true); }).catch(e => UI.toast(e.message, 'err'));
  const fmt = ms => { const s = Math.max(0, ms / 1000 | 0); return (s / 60 | 0) + ':' + String(s % 60).padStart(2, '0'); };
  const deckCard = (d, isM) => `<div class="djdeck ${d.playing ? 'play' : ''} ${isM ? 'master' : ''}">
      <header><b>${esc(d.layerName || 'Deck ' + d.deck)}</b><span class="mono djbpm">${d.bpm ? d.bpm.toFixed(1) : ''}</span></header>
      <div class="djtags">${isM ? '<span class="djm">MASTER</span>' : ''}${d.onAir ? '<span class="djair">ON AIR</span>' : ''}</div>
      <div class="djt">${esc(d.title || (d.trackId ? 'Track ' + d.trackId : 'No track'))}</div><div class="muted small">${esc(d.artist || '')}</div>
      <div class="djbar"><i style="width:${d.length ? Math.min(100, d.ms / 10 / d.length) : 0}%"></i></div>
      <div class="small muted mono djfoot"><span>${esc(d.state)}</span><span class="djbeats">${[1, 2, 3, 4].map(n => `<i class="${d.playing && d.beat === n ? 'on' : ''}"></i>`).join('')}</span><span>${fmt(d.ms)} / ${fmt(d.length * 1000)}</span></div></div>`;
  // ---- Ableton Link (through the Carabiner helper)
  let lk = null; const lkLoad = () => UI.api('/api/link').then(r => { const first = !lk; lk = r; if (UI.rtab === 'djlink') { if (first || !$('#lkBox')) UI.renderRight(true); else lkLive(); } }).catch(() => {});
  (BVJ.extraHandlers = BVJ.extraHandlers || {}).linkstate = m => { const was = lk && lk.cfg && JSON.stringify(lk.cfg); lk = m.link; if (UI.rtab !== 'djlink') return; if (was !== JSON.stringify(lk.cfg)) UI.renderRight(true); else lkLive(); };
  function lkLive() { const el = $('#lkStatus'); if (!el || !lk) return; el.innerHTML = !lk.cfg.on ? '<span class="muted">off</span>' : lk.status === 'connected' ? `<b class="ok">● ${lk.peers} peer${lk.peers === 1 ? '' : 's'}</b> · ${lk.bpm} BPM · beat ${(lk.phase + 1).toFixed(1)} / ${lk.cfg.quantum}` : `${esc(lk.status)}${lk.error ? ' — <span class="err">' + esc(lk.error) + '</span>' : ''}`; }
  setInterval(() => { if (UI.rtab === 'djlink' && lk && lk.cfg.on) lkLive(); }, 250);
  const lkSection = () => { if (!lk) { lkLoad(); return ''; } const c = lk.cfg;
    return `<div class="sec" id="lkBox"><h4>Ableton Link</h4><div class="row wide"><label>Link</label><div class="ctl"><label class="djchk"><input type="checkbox" data-lk="on" ${c.on ? 'checked' : ''}> Join the Link session on this network</label></div></div>
      <div class="row wide"><label>Tempo</label><div class="ctl"><select data-lk="mode"><option value="both" ${c.mode === 'both' ? 'selected' : ''}>Both ways — anyone can change it</option><option value="follow" ${c.mode === 'follow' ? 'selected' : ''}>Follow Link</option><option value="lead" ${c.mode === 'lead' ? 'selected' : ''}>PIXORA leads</option></select></div></div>
      <div class="row wide"><label>Bar length</label><div class="ctl"><select data-lk="quantum">${[1, 2, 4, 8, 16].map(q => `<option value="${q}" ${c.quantum === q ? 'selected' : ''}>${q} beats</option>`).join('')}</select> <span class="small muted">latency</span> <input type="number" data-lk="latency" value="${c.latency || 0}" step="5" style="width:64px"> ms</div></div>
      <div class="kv"><span>Status</span><b id="lkStatus"></b></div>
      <p class="muted small">Syncs tempo and bar phase with Ableton Live, Traktor, Resolume, Serato, Rekordbox and phone apps on the same network. ${lk.helper ? '' : '<span class="err">The Link helper (Carabiner) is not included in this copy — run Carabiner yourself on port ' + c.port + ' or use the desktop app.</span>'} Use DJ Link or Ableton Link for tempo, not both at once.</p></div>`; };
  document.addEventListener('change', e => { const t = e.target.closest && e.target.closest('[data-lk]'); if (!t) return; const k = t.dataset.lk;
    UI.api('/api/link', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ [k]: t.type === 'checkbox' ? t.checked : t.type === 'number' || k === 'quantum' ? +t.value : t.value }) }).then(r => { lk = r; UI.renderRight(true); }).catch(er => UI.toast(er.message, 'err')); });

  UI.panels.djlink = {
    sig: () => JSON.stringify(info && [info.cfg, info.status, info.nodes.length]),
    render() {
      if (!info) { load(); return '<p class="muted">Loading…</p>'; }
      const c = info.cfg, on = c.on;
      const direct = c.source !== 'bridge';
      let h = sec('Pro DJ Link', `<div class="row wide"><label>Connect</label><div class="ctl"><label class="djchk"><input type="checkbox" data-dj="on" ${on ? 'checked' : ''}> Follow the DJ booth</label></div></div>
        <div class="row wide"><label>Connection</label><div class="ctl"><select data-dj="source"><option value="direct" ${direct ? 'selected' : ''}>Players directly (Pro DJ Link network)</option><option value="bridge" ${!direct ? 'selected' : ''}>PRO DJ LINK Bridge app (TCNet)</option></select></div></div>
        ${direct ? `<div class="row wide"><label>Player number</label><div class="ctl"><input type="number" data-dj="device" value="${c.device || 7}" min="7" max="15" style="width:70px"> <span class="muted small">PIXORA's virtual CDJ number (7–15)</span></div></div>` : ''}
        <div class="kv"><span>Status</span><b id="djStatus">${esc(info.status)}</b></div><div id="djNodes"></div>
        <p class="muted small">${direct ? 'Plug PIXORA into the same network switch as the CDJs / XDJs / DJM. PIXORA joins as a virtual player and reads tempo, beats, play state and track info straight from the players, so no extra app is needed. If rekordbox or another DJ Link program runs on this computer, use the Bridge option instead.'
          : 'Run Pioneer DJ’s free PRO DJ LINK Bridge app on this computer or the same network, with the players connected. PIXORA joins as a TCNet node, so ShowKontrol and other TCNet sources work too.'}</p>`);
      h += sec('Follow the DJ', `<div class="row wide"><label>Master deck</label><div class="ctl"><select data-dj="master">${[['auto', 'Automatic (sync master / loudest on air)'], ['1', 'Deck 1'], ['2', 'Deck 2'], ['3', 'Deck 3'], ['4', 'Deck 4']].map(([v, l]) => `<option value="${v}" ${String(c.master) === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div></div>
        <div class="row wide"><label>Tempo</label><div class="ctl"><label class="djchk"><input type="checkbox" data-dj="bpm" ${c.bpm ? 'checked' : ''}> Set PIXORA's BPM from the master deck</label></div></div>
        <div class="row wide"><label>Bar phase</label><div class="ctl"><label class="djchk"><input type="checkbox" data-dj="beat" ${c.beat ? 'checked' : ''}> Line up beat 1 with the deck's downbeat</label></div></div>
        <div class="row wide"><label>Latency (ms)</label><div class="ctl"><input type="number" data-dj="latency" value="${+c.latency || 0}" min="-500" max="500" step="5" style="width:90px"> <span class="muted small">raise if visuals land late</span></div></div>`);
      h += `<div id="djDecks"></div>`;
      h += lkSection();
      h += sec('Use it', `<ul class="small muted djuse"><li><b>Titles:</b> type <span class="mono">{{djlink.master.title}}</span>, <span class="mono">{{djlink.master.artist}}</span> or <span class="mono">{{djlink.deck2.bpm}}</span> into any title.</li>
        <li><b>Clips:</b> Clip ▸ “Follow DJ deck” locks a song-length video to a deck's playhead (scratch, pause and cue included).</li>
        <li><b>Timecode cues:</b> Timecode ▸ Source ▸ “DJ deck” fires cues at track positions on the master deck.</li>
        <li><b>Rules:</b> Data ▸ Rules on feed <span class="mono">djlink</span>, e.g. when <span class="mono">master.title</span> changes, or equals a track name, run a cue or column.</li></ul>`);
      return h;
    },
    after(pane) {
      pane.onchange = e => { const t = e.target.closest('[data-dj]'); if (!t) return; const k = t.dataset.dj; save({ [k]: t.type === 'checkbox' ? t.checked : t.type === 'number' ? +t.value : t.value }); };
      clearInterval(poll); poll = setInterval(() => { if (UI.rtab !== 'djlink') return clearInterval(poll); load(); }, 250);
      this.live(pane); lkLive();
    },
    live(pane) {
      if (!info || !pane) return; const dn = $('#djNodes', pane), dd = $('#djDecks', pane); if (!dd) return;
      $('#djStatus', pane).textContent = info.status + (info.port ? ' · port ' + info.port : '') + (info.number ? ' · virtual CDJ #' + info.number : '');
      dn.innerHTML = info.nodes.length ? info.nodes.map(n => `<div class="kv"><span>${esc(n.app || n.name)} <span class="muted small">${esc(n.vendor || '')} ${esc(n.version || '')}</span></span><b class="mono small">${esc(n.ip)}</b></div>`).join('') : (info.cfg.on ? (info.cfg.source === 'bridge' ? '<p class="muted small">No TCNet nodes found yet. Check PRO DJ LINK Bridge is running and on the same network.</p>' : '<p class="muted small">No players found yet. Check PIXORA is on the same switch as the players and Link is on.</p>') : '');
      const decks = info.decks.slice(0, 4), mIdx = info.master ? ['1', '2', '3', '4', 'A', 'B'].indexOf(info.master) : -1;
      dd.innerHTML = info.cfg.on ? sec('Decks', `<div class="djgrid">${decks.map((d, i) => deckCard(d, i === mIdx)).join('')}</div>${info.mixer && info.mixer.name ? `<div class="kv small"><span>${esc(info.mixer.name)}</span><b class="mono">X-fade ${info.mixer.crossfader} · master ${info.mixer.master}</b></div>` : ''}`) : '';
    },
  };
})();
