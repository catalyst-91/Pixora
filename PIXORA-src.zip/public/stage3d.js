/* PIXORA Stage 3D — live 3D preview of LED screens on a simple stage, textured with the real output (raw WebGL, no libraries) */
(function () {
  const M = { // tiny mat4 helpers (column-major)
    persp(f, a, n, fa) { const t = 1 / Math.tan(f / 2); return [t / a, 0, 0, 0, 0, t, 0, 0, 0, 0, (fa + n) / (n - fa), -1, 0, 0, 2 * fa * n / (n - fa), 0]; },
    mul(a, b) { const o = new Array(16); for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) { let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k]; o[c * 4 + r] = s; } return o; },
    look(e, c, u) { const z = norm(sub(e, c)), x = norm(cross(u, z)), y = cross(z, x); return [x[0], y[0], z[0], 0, x[1], y[1], z[1], 0, x[2], y[2], z[2], 0, -dot(x, e), -dot(y, e), -dot(z, e), 1]; },
    trs(tx, ty, tz, ry, rx, sx, sy) { const cy = Math.cos(ry), syy = Math.sin(ry), cx = Math.cos(rx), sxx = Math.sin(rx);
      // R = Ry * Rx, then scale x,y
      const r = [cy, 0, -syy, 0, syy * sxx, cx, cy * sxx, 0, syy * cx, -sxx, cy * cx, 0, 0, 0, 0, 1];
      return [r[0] * sx, r[1] * sx, r[2] * sx, 0, r[4] * sy, r[5] * sy, r[6] * sy, 0, r[8], r[9], r[10], 0, tx, ty, tz, 1]; },
  };
  const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]], dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]], norm = a => { const l = Math.hypot(...a) || 1; return a.map(v => v / l); };

  const VS = `attribute vec3 p; attribute vec2 uv; uniform mat4 mvp; varying vec2 v; void main(){ v=uv; gl_Position=mvp*vec4(p,1.0); }`;
  const FS = `precision mediump float; varying vec2 v; uniform sampler2D tex; uniform vec4 col; uniform vec4 rect; uniform float useTex, glow;
    void main(){ if(useTex>0.5){ vec2 u=vec2(rect.x+v.x*rect.z, rect.y+v.y*rect.w); vec3 c=texture2D(tex,u).rgb*glow; gl_FragColor=vec4(c,1.0);} else gl_FragColor=col; }`;

  class Stage3D {
    constructor(canvas, getState, getImage) {
      this.cv = canvas; this.getState = getState; this.getImage = getImage; const gl = this.gl = canvas.getContext('webgl', { antialias: true, alpha: false });
      const sh = (t, s) => { const o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); return o; };
      const p = this.p = gl.createProgram(); gl.attachShader(p, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(p, sh(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(p);
      this.u = n => gl.getUniformLocation(p, n); this.quad = this.buf([-0.5, -0.5, 0, 0, 0, 0.5, -0.5, 0, 1, 0, -0.5, 0.5, 0, 0, 1, 0.5, 0.5, 0, 1, 1]);
      const grid = []; for (let i = -20; i <= 20; i++) { grid.push(i, 0, -20, 0, 0, i, 0, 20, 0, 0, -20, 0, i, 0, 0, 20, 0, i, 0, 0); } this.grid = this.buf(grid); this.gridN = grid.length / 5;
      const cube = []; const f = (a, b, c, d) => cube.push(...a, 0, 0, ...b, 1, 0, ...c, 0, 1, ...b, 1, 0, ...d, 1, 1, ...c, 0, 1);
      const v = [[-.5, 0, -.5], [.5, 0, -.5], [-.5, 1, -.5], [.5, 1, -.5], [-.5, 0, .5], [.5, 0, .5], [-.5, 1, .5], [.5, 1, .5]];
      f(v[4], v[5], v[6], v[7]); f(v[1], v[0], v[3], v[2]); f(v[0], v[4], v[2], v[6]); f(v[5], v[1], v[7], v[3]); f(v[2], v[6], v[3], v[7]); this.cube = this.buf(cube); this.cubeN = cube.length / 5;
      this.tex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, this.tex); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([20, 20, 30, 255]));
      [gl.TEXTURE_MIN_FILTER, gl.TEXTURE_MAG_FILTER].forEach(k => gl.texParameteri(gl.TEXTURE_2D, k, gl.LINEAR)); [gl.TEXTURE_WRAP_S, gl.TEXTURE_WRAP_T].forEach(k => gl.texParameteri(gl.TEXTURE_2D, k, gl.CLAMP_TO_EDGE));
      this.yaw = 0.6; this.pitch = 0.25; this.dist = 0; this.target = [0, 2, 0]; this.people = true; this.lastImg = null;
      let drag = null; canvas.addEventListener('pointerdown', e => { drag = { x: e.clientX, y: e.clientY, b: e.button, shift: e.shiftKey }; canvas.setPointerCapture(e.pointerId); });
      canvas.addEventListener('pointermove', e => { if (!drag) return; const dx = e.clientX - drag.x, dy = e.clientY - drag.y; drag.x = e.clientX; drag.y = e.clientY;
        if (drag.b === 2 || drag.shift) { const r = [Math.cos(this.yaw), 0, -Math.sin(this.yaw)]; const k = this.dist / 600; this.target = [this.target[0] - r[0] * dx * k, this.target[1] + dy * k, this.target[2] - r[2] * dx * k]; }
        else { this.yaw -= dx * 0.006; this.pitch = Math.max(-0.2, Math.min(1.4, this.pitch + dy * 0.005)); } });
      canvas.addEventListener('pointerup', () => drag = null); canvas.addEventListener('contextmenu', e => e.preventDefault());
      canvas.addEventListener('wheel', e => { e.preventDefault(); this.dist = Math.max(2, Math.min(200, this.dist * (e.deltaY > 0 ? 1.1 : 0.9))); }, { passive: false });
      const loop = () => { if (!this.cv.isConnected) return; this.raf = requestAnimationFrame(loop); if (this.cv.offsetParent !== null) this.draw(); }; loop();
    }
    buf(a) { const gl = this.gl, b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(a), gl.STATIC_DRAW); return b; }
    bind(b) { const gl = this.gl; gl.bindBuffer(gl.ARRAY_BUFFER, b); const pl = gl.getAttribLocation(this.p, 'p'), ul = gl.getAttribLocation(this.p, 'uv'); gl.enableVertexAttribArray(pl); gl.vertexAttribPointer(pl, 3, gl.FLOAT, false, 20, 0); gl.enableVertexAttribArray(ul); gl.vertexAttribPointer(ul, 2, gl.FLOAT, false, 20, 12); }
    static layout(s) { // world placement for each screen (metres)
      const scr = s.led.screens; const mode = s.led.layout3d || 'auto'; const out = [];
      const size = x => { const w = (x.panelMmW > 0 ? x.panelMmW : x.panelW * 3.9) * x.cols / 1000, h = (x.panelMmH > 0 ? x.panelMmH : x.panelH * 3.9) * x.rows / 1000; return [w, h]; };
      const m = mode === 'auto' ? (scr.length === 4 && scr.every(x => Math.abs(size(x)[0] - size(scr[0])[0]) < 0.01) ? 'box' : 'flat') : mode;
      if (m === 'custom') return scr.map(x => { const [w, h] = size(x); return { sc: x, w, h, x: x.pos3d.x, y: x.pos3d.y + h / 2, z: x.pos3d.z, ry: x.pos3d.ry * Math.PI / 180, rx: x.pos3d.rx * Math.PI / 180 }; });
      const hang = scr.length ? (scr[0].pos3d.y ?? 2.5) : 2.5;
      if (m === 'box') { const [w] = size(scr[0]); return scr.map((x, i) => { const [ww, h] = size(x); const a = -i * Math.PI / 2; return { sc: x, w: ww, h, x: Math.sin(a) * w / 2, y: hang + h / 2, z: Math.cos(a) * w / 2, ry: a, rx: 0 }; }); }
      if (m === 'arc') { const tot = scr.reduce((a, x) => a + size(x)[0], 0); const R = Math.max(3, tot / 2); let acc = -tot / 2; return scr.map(x => { const [w, h] = size(x); const mid = (acc + w / 2) / R; acc += w; return { sc: x, w, h, x: Math.sin(mid) * R, y: hang + h / 2, z: -Math.cos(mid) * R + R, ry: -mid, rx: 0 }; }); }
      const gap = 0.3; const tot = scr.reduce((a, x) => a + size(x)[0], 0) + gap * Math.max(0, scr.length - 1); let acc = -tot / 2;
      return scr.map(x => { const [w, h] = size(x); const cx = acc + w / 2; acc += w + gap; return { sc: x, w, h, x: cx, y: hang + h / 2, z: 0, ry: 0, rx: 0 }; });
    }
    draw() {
      const gl = this.gl, cv = this.cv, s = this.getState(); if (!s) return;
      const dpr = devicePixelRatio || 1, W = Math.max(50, cv.clientWidth * dpr | 0), H = Math.max(50, cv.clientHeight * dpr | 0); if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
      const img = this.getImage(); if (img && img.complete && img.naturalWidth && img.src !== this.lastImg) { this.lastImg = img.src; gl.bindTexture(gl.TEXTURE_2D, this.tex); gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false); try { gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img); } catch {} }
      const L = Stage3D.layout(s); if (!this.dist) { let r = 4; for (const q of L) r = Math.max(r, Math.hypot(q.x, q.z) + q.w); this.dist = r * 2.2; if (L.length) this.target = [0, L[0].y, 0]; }
      gl.viewport(0, 0, W, H); gl.clearColor(0.03, 0.03, 0.05, 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT); gl.enable(gl.DEPTH_TEST); gl.useProgram(this.p);
      const eye = [this.target[0] + Math.sin(this.yaw) * Math.cos(this.pitch) * this.dist, this.target[1] + Math.sin(this.pitch) * this.dist, this.target[2] + Math.cos(this.yaw) * Math.cos(this.pitch) * this.dist];
      const vp = M.mul(M.persp(0.9, W / H, 0.05, 500), M.look(eye, this.target, [0, 1, 0]));
      const ident = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1];
      gl.uniform1f(this.u('useTex'), 0); this.bind(this.grid); gl.uniformMatrix4fv(this.u('mvp'), false, vp); gl.uniform4f(this.u('col'), 0.16, 0.16, 0.22, 1); gl.drawArrays(gl.LINES, 0, this.gridN);
      const comp = s.comp;
      for (const q of L) {
        const x = q.sc; const pw = x.panelW * x.cols, ph = x.panelH * x.rows;
        // truss / back box
        this.bind(this.cube); gl.uniform1f(this.u('useTex'), 0); gl.uniform4f(this.u('col'), 0.09, 0.09, 0.12, 1);
        const back = M.mul(M.trs(q.x - Math.sin(q.ry) * 0.06, q.y - q.h / 2, q.z - Math.cos(q.ry) * 0.06, q.ry, 0, q.w, 1), [1, 0, 0, 0, 0, q.h, 0, 0, 0, 0, 0.1, 0, 0, 0, 0, 1]);
        gl.uniformMatrix4fv(this.u('mvp'), false, M.mul(vp, back)); gl.drawArrays(gl.TRIANGLES, 0, this.cubeN);
        this.bind(this.quad); gl.uniform1f(this.u('useTex'), 1); gl.uniform1f(this.u('glow'), (s.comp.blackout ? 0 : 1));
        gl.uniform4f(this.u('rect'), x.x / comp.width, x.y / comp.height + ph / comp.height, pw / comp.width, -ph / comp.height);
        gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, this.tex); gl.uniform1i(this.u('tex'), 0);
        gl.uniformMatrix4fv(this.u('mvp'), false, M.mul(vp, M.trs(q.x, q.y, q.z, q.ry, q.rx, q.w, q.h))); gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
        // pole down to the floor
        this.bind(this.cube); gl.uniform1f(this.u('useTex'), 0); gl.uniform4f(this.u('col'), 0.2, 0.2, 0.25, 1);
        gl.uniformMatrix4fv(this.u('mvp'), false, M.mul(vp, M.mul(M.trs(q.x, 0, q.z, q.ry, 0, 0.06, 1), [1, 0, 0, 0, 0, Math.max(0.01, q.y - q.h / 2), 0, 0, 0, 0, 0.06, 0, 0, 0, 0, 1]))); gl.drawArrays(gl.TRIANGLES, 0, this.cubeN);
      }
      if (this.people) for (const [px, pz] of [[2.2, 4.5], [-1.4, 5.2], [0.6, 6.4], [-3, 7], [3.4, 7.6]]) { // 1.8 m crowd figures for scale
        this.bind(this.cube); gl.uniform4f(this.u('col'), 0.28, 0.25, 0.4, 1); gl.uniformMatrix4fv(this.u('mvp'), false, M.mul(vp, M.mul(M.trs(px, 0, pz, 0, 0, 0.45, 1), [1, 0, 0, 0, 0, 1.75, 0, 0, 0, 0, 0.3, 0, 0, 0, 0, 1]))); gl.drawArrays(gl.TRIANGLES, 0, this.cubeN); }
    }
    reset() { this.dist = 0; }
  }
  window.PixoraStage3D = Stage3D;

  // bottom-panel integration in the controller
  if (window.UI && UI.bpanels) {
    let stage = null;
    UI.bpanels.stage = {
      sig: s => JSON.stringify([s.led.layout3d, s.led.screens.length]),
      tools: s => `<span class="tlabel">Layout</span><select data-path="led.layout3d"><option value="auto">Auto</option><option value="flat">Flat wall</option><option value="box">Box / square truss</option><option value="arc">Arc</option><option value="custom">Custom (per screen)</option></select>
        <button class="btn sm" id="st3dReset">${UI.icon('restart')}Reset view</button><button class="btn sm" id="st3dPeople">Crowd</button><button class="btn sm" id="st3dPop">${UI.icon('screen')}Pop out</button>`,
      render: s => `<div class="lib"><div class="libmain" style="padding:0;position:relative;overflow:hidden"><canvas id="st3d" style="width:100%;height:100%;display:block;cursor:grab"></canvas>
        <div class="tlhelp">Drag to orbit · right-drag / shift-drag to pan · scroll to zoom · textures are the live output</div></div>
        ${s.led.layout3d === 'custom' ? `<div class="libside" style="width:300px;border-left:1px solid var(--line);border-right:0">${s.led.screens.map((x, i) => `<div class="small" style="font-weight:600;margin:6px 0 2px;color:${UI.esc(x.color)}">${UI.esc(x.name)}</div>
          <div class="grid4 small">${['x', 'y', 'z', 'ry'].map(k => `<label class="af">${k === 'ry' ? 'rot°' : k + ' m'}<input type="number" step="${k === 'ry' ? 5 : 0.1}" data-path="led.screens.${i}.pos3d.${k}"></label>`).join('')}</div>`).join('')}</div>` : ''}</div>`,
      after(pane) {
        if (!UI.st().led.screens.length) { $('#st3d', pane).replaceWith(UI.el('<div class="empty-note" style="padding-top:60px">Add LED screens in the LED tab to see them here in 3D.</div>')); return; }
        stage = new Stage3D($('#st3d', pane), () => UI.st(), () => document.getElementById('prev'));
        $('#st3dReset').onclick = () => stage.reset(); $('#st3dPeople').onclick = () => { stage.people = !stage.people; };
        $('#st3dPop').onclick = () => window.open('/stage', 'pixora-stage', 'width=1100,height=700');
      },
    };
  }
  const $ = s => document.querySelector(s);
})();
