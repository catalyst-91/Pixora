#!/usr/bin/env node
/*
 * PIXORA — Booth Productions
 * Zero-dependency server: static files, media streaming from local + external drives,
 * live state over WebSocket, HTTP API and OSC input (Resolume-style addresses).
 * All video decoding/compositing happens in the browser (WebGL) on the user's own computer.
 */
'use strict';
const http = require('http');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const crypto = require('crypto');
const os = require('os');
const dgram = require('dgram');
const S = require('./public/schema.js');

const PORT = +process.env.PORT || 8080;
const OSC_PORT = +process.env.OSC_PORT || 7000;
const PIN = process.env.PIN || '';
const VIEW_PIN = process.env.VIEW_PIN || ''; // optional read-only PIN for view-only remotes
const ROOT = __dirname;
const PUB = path.join(ROOT, 'public');
const DATA = path.resolve(process.env.DATA_DIR || path.join(ROOT, 'data'));
const LOCAL_MEDIA = path.resolve(process.env.MEDIA_DIR || path.join(ROOT, 'media'));
const THUMBS = path.join(DATA, 'thumbs');
const COMPS = path.join(DATA, 'compositions');
for (const d of [DATA, LOCAL_MEDIA, THUMBS, COMPS]) fs.mkdirSync(d, { recursive: true });

const MIME = { html: 'text/html; charset=utf-8', js: 'text/javascript; charset=utf-8', css: 'text/css; charset=utf-8',
  json: 'application/json', svg: 'image/svg+xml', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif',
  webp: 'image/webp', bmp: 'image/bmp', ico: 'image/x-icon', mp4: 'video/mp4', m4v: 'video/mp4', webm: 'video/webm',
  mov: 'video/quicktime', ogv: 'video/ogg', mkv: 'video/x-matroska', woff2: 'font/woff2' };
const extOf = f => path.extname(f).slice(1).toLowerCase();
const mediaKind = f => S.IMAGE_EXT.includes(extOf(f)) ? 'image' : S.VIDEO_EXT.includes(extOf(f)) ? 'video' : null;

/* ------------------------------------------------------------------ JSON store */
function readJSON(file, fallback) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJSONSoon(file, getter, ms = 800) {
  let t = null;
  return () => { clearTimeout(t); t = setTimeout(() => fsp.writeFile(file, JSON.stringify(getter(), null, 1)).catch(e => console.error('save', e.message)), ms); };
}

/* ------------------------------------------------------------------ media sources (local + external drives) */
const SOURCES_FILE = path.join(DATA, 'sources.json');
const srcId = p => crypto.createHash('sha1').update(path.resolve(p).toLowerCase()).digest('hex').slice(0, 8);
let sources = readJSON(SOURCES_FILE, null);
if (!Array.isArray(sources)) {
  sources = [];
  // MEDIA_DIRS env: extra roots separated by ';' or ',' (e.g. "E:\\Videos;F:\\VJ Loops" or "/mnt/usb,/media/jay/SSD")
  for (const p of (process.env.MEDIA_DIRS || '').split(/[;,]/).map(s => s.trim()).filter(Boolean))
    sources.push({ id: srcId(p), name: path.basename(p) || p, path: path.resolve(p), kind: 'external' });
}
sources = sources.filter(s => s.id !== 'local');
sources.unshift({ id: 'local', name: 'Local Library', path: LOCAL_MEDIA, kind: 'local' });
const saveSources = writeJSONSoon(SOURCES_FILE, () => sources.filter(s => s.id !== 'local'), 100);

const SKIP_DIRS = new Set(['$recycle.bin', 'system volume information', 'node_modules', '.trashes', '.spotlight-v100', '.fseventsd', 'lost+found', 'windows', 'program files', 'program files (x86)', 'programdata', 'appdata']);
const scanCache = new Map(); // id -> {at, items, online}
async function scanSource(src, force) {
  const c = scanCache.get(src.id);
  if (c && !force && Date.now() - c.at < 15000) return c;
  const items = []; let online = true;
  try { await fsp.access(src.path); } catch { online = false; }
  async function walk(dir, rel, depth) {
    if (depth > 8 || items.length >= 8000) return;
    let ents; try { ents = await fsp.readdir(dir, { withFileTypes: true }); } catch { return; }
    for (const e of ents) {
      if (e.name.startsWith('.')) continue;
      const r = rel ? rel + '/' + e.name : e.name;
      if (e.isDirectory()) { if (!SKIP_DIRS.has(e.name.toLowerCase())) await walk(path.join(dir, e.name), r, depth + 1); }
      else if (mediaKind(e.name)) {
        let size = 0; try { size = (await fsp.stat(path.join(dir, e.name))).size; } catch {}
        items.push({ src: src.id + '/' + r, name: e.name, folder: rel, kind: mediaKind(e.name), size });
      }
    }
  }
  if (online) await walk(src.path, '', 0);
  items.sort((a, b) => (a.folder + '/' + a.name).localeCompare(b.folder + '/' + b.name, undefined, { numeric: true }));
  const res = { at: Date.now(), items, online };
  scanCache.set(src.id, res); return res;
}
// Resolve "sourceId/relative/path.mp4" -> absolute path, refusing traversal outside the source root.
function resolveMedia(key) {
  const i = key.indexOf('/'); if (i < 0) return null;
  const src = sources.find(s => s.id === key.slice(0, i)); if (!src) return null;
  const root = path.resolve(src.path);
  const abs = path.resolve(root, key.slice(i + 1));
  if (abs !== root && !abs.startsWith(root.endsWith(path.sep) ? root : root + path.sep)) return null;
  return abs;
}
// Detect drives / mount points on the machine running the server.
async function detectDrives() {
  const out = [];
  const add = async (p, label) => { try { const st = await fsp.stat(p); if (st.isDirectory()) out.push({ path: p, label }); } catch {} };
  if (process.platform === 'win32') {
    for (let c = 67; c <= 90; c++) await add(String.fromCharCode(c) + ':\\', String.fromCharCode(c) + ': drive');
  } else {
    const parents = process.platform === 'darwin' ? ['/Volumes'] : ['/media', '/mnt', '/run/media', '/media/' + (os.userInfo().username || '')];
    for (const par of parents) {
      let ents = []; try { ents = await fsp.readdir(par, { withFileTypes: true }); } catch { continue; }
      for (const e of ents) {
        if (!e.isDirectory()) continue;
        const p = path.join(par, e.name);
        // /media/<user>/<drive> and /run/media/<user>/<drive>: descend one level
        let sub = []; try { sub = await fsp.readdir(p, { withFileTypes: true }); } catch {}
        if ((par === '/media' || par === '/run/media') && e.name === os.userInfo().username) {
          for (const s of sub) if (s.isDirectory()) await add(path.join(p, s.name), s.name);
        } else await add(p, e.name);
      }
    }
  }
  await add(os.homedir(), 'Home folder');
  const vids = path.join(os.homedir(), process.platform === 'win32' ? 'Videos' : process.platform === 'darwin' ? 'Movies' : 'Videos');
  await add(vids, 'My Videos');
  // de-dupe
  const seen = new Set(); return out.filter(d => !seen.has(d.path) && seen.add(d.path));
}

/* ------------------------------------------------------------------ thumbnails & meta (generated in the browser, cached here) */
const META_FILE = path.join(DATA, 'meta.json');
const meta = readJSON(META_FILE, {});
const saveMeta = writeJSONSoon(META_FILE, () => meta, 1500);
const thumbFile = key => path.join(THUMBS, crypto.createHash('sha1').update(key).digest('hex') + '.jpg');

/* ------------------------------------------------------------------ settings */
const SETTINGS_FILE = path.join(DATA, 'settings.json');
const settings = Object.assign({ autoConvert: true, convertMode: 'balanced' }, readJSON(SETTINGS_FILE, {}));
const saveSettings = writeJSONSoon(SETTINGS_FILE, () => settings, 100);

/* ------------------------------------------------------------------ local ffmpeg conversion (runs on this computer) */
const { spawn, spawnSync, execFile } = require('child_process');
const TRANS = path.join(DATA, 'transcodes'); fs.mkdirSync(TRANS, { recursive: true });
const FFMPEG = process.env.FFMPEG_PATH || 'ffmpeg';
let ffmpegOk = false;
/* ---- v1.2 modules (reliability, preflight, CITP, Art-Net TC, MVR, users/remote access, reports, web proxy, updates) */
const pro3 = require('./server-pro3.js')({
  DATA, ROOT, PORT, PIN, LOCAL_MEDIA, send: (...a) => send(...a), readBody: (...a) => readBody(...a), broadcast: (...a) => broadcast(...a), monitor: (...a) => monitor(...a),
  getState: () => state, applyCmd: (c, f) => applyCmd(c, f), markDirty: () => markDirty(), broadcastState: () => markDirty(),
  library: async () => { const out = []; for (const s of sources) { const r = await scanSource(s, false); out.push(...r.items); } return out; },
  rescan: () => { try { for (const s of sources) scanSource(s, true); } catch {} },
  usedMedia: st => usedMedia(st), resolveMedia: k => resolveMedia(k), thumbFile: k => thumbFile(k), ffmpegOk: () => ffmpegOk,
  relinkMedia: (from, to) => { let n = 0; const fix = c => { if (c && c.src === from) { c.src = to; n++; } }; for (const l of state.layers) { l.clips.forEach(fix); fix(l.activeClip); } for (const d of state.decks || []) for (const k in d.clips || {}) (d.clips[k] || []).forEach && d.clips[k].forEach(fix); markDirty(); return n; },
  updateTc: (f, fps) => updateTc(f, fps), tcInfo: () => tc, popRows: (a, b) => { try { return popRows(a, b); } catch { return { hdr: '', rows: [] }; } },
  monitorLog: () => monitorLog, changeLog: () => changeLog, closeServer: cb => server.close(cb),
});
try { ffmpegOk = spawnSync(FFMPEG, ['-version'], { timeout: 5000 }).status === 0; } catch {}
const transFile = key => path.join(TRANS, crypto.createHash('sha1').update(key).digest('hex') + '.mp4');
const hasTranscode = key => fs.existsSync(transFile(key));
const isNative = f => S.NATIVE_EXT.includes(extOf(f)) || S.IMAGE_EXT.includes(extOf(f));
const jobs = []; // {id, type, src, name, progress, status, error}
let jobRunning = false;
function jobList() { return jobs.slice(-40).map(j => ({ id: j.id, type: j.type, src: j.src, name: j.name, progress: j.progress, status: j.status, error: j.error })); }
let jobsTimer = null;
function pushJobs() { if (jobsTimer) return; jobsTimer = setTimeout(() => { jobsTimer = null; broadcast({ t: 'jobs', jobs: jobList(), ffmpeg: ffmpegOk }); }, 250); }
function queueConvert(key) {
  if (!ffmpegOk) throw new Error('ffmpeg not found on this computer — install it (Windows: winget install ffmpeg) or set FFMPEG_PATH.');
  if (!resolveMedia(key)) throw new Error('media not found');
  if (jobs.find(j => j.type === 'convert' && j.src === key && (j.status === 'queued' || j.status === 'running'))) return;
  jobs.push({ id: crypto.randomBytes(3).toString('hex'), type: 'convert', src: key, name: path.basename(key), progress: 0, status: 'queued' });
  pushJobs(); runJobs();
}
function convertArgs(input, output) {
  const mode = settings.convertMode;
  const v = mode === 'scrub' ? ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '17', '-g', '1', '-tune', 'fastdecode']
    : mode === 'small' ? ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '23', '-g', '60']
    : ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '19', '-g', '15'];
  return ['-hide_banner', '-y', '-i', input, ...v, '-pix_fmt', 'yuv420p', '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2',
    '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', '-f', 'mp4', output];
}
async function runJobs() {
  if (jobRunning) return; const j = jobs.find(x => x.status === 'queued'); if (!j) return;
  jobRunning = true; j.status = 'running'; pushJobs();
  try {
    if (j.type === 'convert') await runConvert(j);
    else if (j.type === 'collect') await runCollect(j);
    else if (j.run) await j.run({ progress: v => { j.progress = v; pushJobs(); } });
    j.status = 'done'; j.progress = 1;
  } catch (e) { j.status = 'error'; j.error = String(e.message || e).slice(-300); }
  jobRunning = false; pushJobs(); broadcast({ t: 'library' }); runJobs();
}
// generic job (used by recording): resolves when the job has run
function addJob(spec) {
  return new Promise((ok, bad) => {
    const j = { id: crypto.randomBytes(3).toString('hex'), type: spec.type || 'job', src: spec.src || '', name: spec.name || '', progress: 0, status: 'queued',
      run: async h => { try { await spec.run(h); ok(); } catch (e) { bad(e); throw e; } } };
    jobs.push(j); pushJobs(); runJobs();
  });
}
function runConvert(j) {
  return new Promise((ok, bad) => {
    const input = resolveMedia(j.src), out = transFile(j.src), part = out + '.part';
    const ff = spawn(FFMPEG, convertArgs(input, part), { windowsHide: true });
    let dur = 0, tail = '';
    ff.stderr.on('data', d => {
      const s = d.toString(); tail = (tail + s).slice(-600);
      const dm = /Duration: (\d+):(\d+):([\d.]+)/.exec(s); if (dm) dur = +dm[1] * 3600 + +dm[2] * 60 + +dm[3];
      const tm = /time=(\d+):(\d+):([\d.]+)/.exec(s); if (tm && dur) { j.progress = Math.min(0.99, (+tm[1] * 3600 + +tm[2] * 60 + +tm[3]) / dur); pushJobs(); }
    });
    ff.on('error', bad);
    ff.on('close', code => {
      if (code === 0) { fs.rename(part, out, e => e ? bad(e) : (delete meta[j.src], saveMeta(), ok())); }
      else { fs.unlink(part, () => {}); bad(new Error('ffmpeg failed: ' + tail.split('\n').filter(Boolean).slice(-2).join(' '))); }
    });
  });
}

/* ------------------------------------------------------------------ show files (offline, portable) */
const SHOW_EXT = '.pixora';
function usedMedia(st) {
  const set = new Set();
  for (const l of st.layers) for (const c of l.clips) if (c && c.src && (c.type === 'video' || c.type === 'image')) set.add(c.src);
  return [...set];
}
function showDoc(st) {
  return { format: 'pixora-show', version: 1, savedAt: new Date().toISOString(), app: 'PIXORA — Booth Productions',
    media: usedMedia(st).map(src => { const abs = resolveMedia(src); let size = 0; try { size = fs.statSync(abs).size; } catch {} return { src, name: path.basename(src), size }; }),
    state: st };
}
// Re-point clips whose files are missing (moved drive, different drive letter, collected show folder) by filename (+size).
async function relink(st) {
  const missing = [], relinked = [];
  const index = new Map();
  for (const s of sources) { const r = await scanSource(s, true); for (const it of r.items) { const k = it.name.toLowerCase(); if (!index.has(k)) index.set(k, []); index.get(k).push(it); } }
  for (const l of st.layers) for (const c of l.clips) {
    if (!c || !(c.type === 'video' || c.type === 'image') || !c.src) continue;
    const abs = resolveMedia(c.src); if (abs && fs.existsSync(abs)) continue;
    const cands = index.get(path.basename(c.src).toLowerCase()) || [];
    const pick = cands.find(x => c.size && x.size === c.size) || cands[0];
    if (pick) { relinked.push({ from: c.src, to: pick.src }); c.src = pick.src; } else missing.push(c.src);
  }
  return { relinked, missing: [...new Set(missing)] };
}
async function runCollect(j) {
  const dest = j.dest; const mediaDir = path.join(dest, 'media');
  await fsp.mkdir(mediaDir, { recursive: true });
  const st = JSON.parse(JSON.stringify(state)); const list = usedMedia(st); const map = {}; const used = new Set();
  for (let i = 0; i < list.length; i++) {
    const src = list[i]; const abs = resolveMedia(src); if (!abs || !fs.existsSync(abs)) continue;
    // converted files are packaged as their playable MP4 so the offline machine needs no ffmpeg
    const conv = hasTranscode(src); const ext = conv ? '.mp4' : path.extname(abs); const base = path.basename(abs, path.extname(abs)) + (conv ? '_converted' : '');
    let name = base + ext, n = 1; while (used.has(name.toLowerCase())) name = base + `_${n++}` + ext;
    used.add(name.toLowerCase());
    await fsp.copyFile(conv ? transFile(src) : abs, path.join(mediaDir, name));
    map[src] = name; j.progress = (i + 1) / Math.max(1, list.length); pushJobs();
  }
  // Add the collected folder as a source so the show is immediately playable from it.
  const sid = srcId(mediaDir);
  if (!sources.find(s => s.id === sid)) { sources.push({ id: sid, name: j.name + ' (collected)', path: mediaDir, kind: 'external' }); saveSources(); }
  for (const l of st.layers) for (const c of l.clips) if (c && map[c.src]) c.src = sid + '/' + map[c.src];
  await fsp.writeFile(path.join(dest, safeName(j.name) + SHOW_EXT), JSON.stringify(showDoc(st), null, 1));
  scanCache.delete(sid);
}

/* ------------------------------------------------------------------ state */
const STATE_FILE = path.join(DATA, 'state.json');
let state = readJSON(STATE_FILE, null) || S.newState();
function normalizeState(st) {
  const base = S.newState();
  st.comp = Object.assign(S.compDefaults(), st.comp || {});
  st.comp.fx = mergeFx(st.comp.fx);
  if (!Array.isArray(st.layers) || !st.layers.length) st.layers = base.layers;
  st.layers = st.layers.map((l, i) => {
    const d = S.layerDefaults(i, st.comp.columns);
    const o = Object.assign(d, l); o.fx = mergeFx(l.fx);
    o.clips = Array.from({ length: st.comp.columns }, (_, c) => { if (!(l.clips && l.clips[c])) return null; const cd = S.clipDefaults(); const x = Object.assign(cd, l.clips[c]); x.web = Object.assign(S.clipDefaults().web, l.clips[c].web || {}); return x; });
    if (o.active != null && !o.clips[o.active] && !o.activeClip) o.active = null;
    o.transform = Object.assign({ x: 0, y: 0, scale: 1, rotation: 0 }, l.transform || {});
    o.mask = Object.assign({ type: 'none', x: 0, y: 0, w: 1, h: 1, feather: 0, invert: false }, l.mask || {});
    return o;
  });
  const cd = S.compDefaults(); for (const k of ['dmx', 'pixelMap', 'timecode', 'audio']) st.comp[k] = Object.assign(cd[k], st.comp[k] || {});
  if (!Array.isArray(st.decks) || !st.decks.length) st.decks = [{ name: 'Deck 1', clips: {} }];
  if (st.comp.deck >= st.decks.length) st.comp.deck = 0;
  if (!Array.isArray(st.outputs) || !st.outputs.length) st.outputs = [S.outputDefaults('main', 'Main')];
  const ld = S.ledDefaults(); st.led = Object.assign(ld, st.led || {}); st.led.test = Object.assign(S.ledDefaults().test, st.led.test || {});
  if (!Array.isArray(st.led.screens)) st.led.screens = []; st.led.screens = st.led.screens.map((x, i) => Object.assign(S.screenDefaults(i + 1), x));
  for (const k of ['cues', 'mods', 'presets']) if (!Array.isArray(st[k])) st[k] = [];
  if (typeof st.cueIndex !== 'number') st.cueIndex = -1;
  if (!Array.isArray(st.shaders)) st.shaders = [];
  for (const b of S.BUILTIN_SHADERS) if (!st.shaders.find(x => x.id === b.id)) st.shaders.push(Object.assign({ builtin: true }, b));
  const nd = S.newState();
  for (const k of ['feeds', 'rules', 'schedule', 'genPresets']) if (!Array.isArray(st[k])) st[k] = [];
  for (const k of ['rotation', 'oscOut', 'checklist', 'react']) st[k] = Object.assign(nd[k], st[k] || {});
  if (!Array.isArray(st.rotation.items)) st.rotation.items = []; if (!Array.isArray(st.oscOut.targets)) st.oscOut.targets = []; if (!Array.isArray(st.checklist.items)) st.checklist.items = [];
  st.timeline = Object.assign(S.timelineDefaults(), st.timeline || {}); st.timeline.play = Object.assign({ playing: false, pos: 0, startAt: 0 }, st.timeline.play || {});
  st.led.dayNight = Object.assign(S.ledDefaults().dayNight, st.led.dayNight || {});
  for (const sc of st.led.screens) { sc.cal = Object.assign({ brightness: 1, r: 1, g: 1, b: 1, gamma: 1 }, sc.cal || {}); sc.pos3d = Object.assign({ x: 0, y: 2.5, z: 0, ry: 0, rx: 0 }, sc.pos3d || {}); }
  for (const o of st.outputs) for (const sl of o.slices || []) sl.cal = Object.assign({ brightness: 1, r: 1, g: 1, b: 1, gamma: 1 }, sl.cal || {});
  for (const l of st.layers) { l.route = Object.assign({ mode: 'all', screens: [] }, l.route || {}); if (typeof l.lockedBy !== 'string') l.lockedBy = ''; }
  pro3.normalize(st);
  return st;
}
function mergeFx(fx) { const d = S.fxDefaults(); for (const k in d) Object.assign(d[k], (fx || {})[k] || {}); return d; }
state = normalizeState(state);
const saveState = writeJSONSoon(STATE_FILE, () => state, 1000);

/* ------------------------------------------------------------------ WebSocket (RFC 6455, minimal) */
const clients = new Set();
function wsFrame(op, payload) {
  const len = payload.length; let h;
  if (len < 126) { h = Buffer.alloc(2); h[1] = len; }
  else if (len < 65536) { h = Buffer.alloc(4); h[1] = 126; h.writeUInt16BE(len, 2); }
  else { h = Buffer.alloc(10); h[1] = 127; h.writeBigUInt64BE(BigInt(len), 2); }
  h[0] = 0x80 | op; return Buffer.concat([h, payload]);
}
function wsAccept(req, socket, role, viewer, client) {
  const key = req.headers['sec-websocket-key'];
  if (!key) return socket.destroy();
  const accept = crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  socket.setNoDelay(true);
  const c = { socket, role, viewer, client: !!client, addr: (req.socket.remoteAddress || '').replace('::ffff:', ''), id: crypto.randomBytes(4).toString('hex'), buf: Buffer.alloc(0), frags: [], fragOp: 0, alive: true,
    send(obj) { if (!socket.destroyed) socket.write(wsFrame(1, Buffer.from(typeof obj === 'string' ? obj : JSON.stringify(obj)))); },
    sendBin(b) { if (!socket.destroyed && socket.writableLength < 512 * 1024) socket.write(wsFrame(2, b)); } };
  clients.add(c);
  socket.on('data', d => { c.buf = c.buf.length ? Buffer.concat([c.buf, d]) : d; wsParse(c); });
  const bye = () => { if (clients.delete(c)) onLeave(c); };
  socket.on('close', bye); socket.on('error', bye); socket.on('end', bye);
  onJoin(c);
}
function wsParse(c) {
  for (;;) {
    const b = c.buf; if (b.length < 2) return;
    const fin = b[0] & 0x80, op = b[0] & 0x0f, masked = b[1] & 0x80; let len = b[1] & 0x7f, off = 2;
    if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
    else if (len === 127) { if (b.length < 10) return; len = Number(b.readBigUInt64BE(2)); off = 10; }
    if (len > 16 * 1024 * 1024) return c.socket.destroy();
    const mOff = off; if (masked) off += 4;
    if (b.length < off + len) return;
    const p = Buffer.from(b.subarray(off, off + len));
    if (masked) for (let i = 0; i < p.length; i++) p[i] ^= b[mOff + (i & 3)];
    c.buf = b.subarray(off + len);
    if (op === 8) { try { c.socket.end(wsFrame(8, Buffer.alloc(0))); } catch {} return; }
    if (op === 9) { c.socket.write(wsFrame(10, p)); continue; }
    if (op === 10) { c.alive = true; continue; }
    if (op === 0) { c.frags.push(p); if (fin) { const all = Buffer.concat(c.frags); c.frags = []; onMessage(c, c.fragOp, all); } continue; }
    if (!fin) { c.fragOp = op; c.frags = [p]; continue; }
    onMessage(c, op, p);
  }
}
setInterval(() => { for (const c of clients) { if (!c.alive) { c.socket.destroy(); continue; } c.alive = false; try { c.socket.write(wsFrame(9, Buffer.alloc(0))); } catch {} } }, 15000);

/* ------------------------------------------------------------------ broadcast */
let stateDirty = false;
function markDirty() {
  saveState();
  if (stateDirty) return; stateDirty = true;
  setImmediate(() => { stateDirty = false; const msg = JSON.stringify({ t: 'state', state, serverTime: pro3.now() }); for (const c of clients) c.send(msg); try { oscOutSync(); } catch {} });
}
function broadcast(obj, role) { const m = JSON.stringify(obj); for (const c of clients) if (!role || c.role === role) c.send(m); }
let primaryOutput = null;
function outputsInfo() { return [...clients].filter(c => c.role === 'output').map(c => ({ id: c.id, primary: c === primaryOutput, info: c.info || {} })); }
function onJoin(c) {
  if (c.role === 'output' && (!primaryOutput || !clients.has(primaryOutput))) primaryOutput = c;
  c.send({ t: 'hello', id: c.id, role: c.role, viewer: !!c.viewer, serverTime: Date.now() });
  c.send({ t: 'state', state, serverTime: Date.now() });
  c.send({ t: 'jobs', jobs: jobList(), ffmpeg: ffmpegOk });
  c.send({ t: 'comps', comps: listComps() });
  c.send({ t: 'feeds', values: feedValues, status: feedStatus }); c.send({ t: 'backup', status: backupStatus() });
  c.send({ t: 'recstate', rec: rec.view() }); if (c.role !== 'output') c.send({ t: 'recprefs', prefs: rec.prefs() });
  if (c.role === 'diag') { c.wantMonitor = true; c.send({ t: 'monlog', log: monitorLog.slice(-300) }); }
  broadcast({ t: 'outputs', outputs: outputsInfo() }); pushPresence();
  if (c.role === 'mirror') monitor('backup', 'backup server connected from ' + c.addr);
}
function onLeave(c) {
  pro3.outputGone(c); rec.outputGone(c);
  pushPresence(); delete health.outputs[c.id];
  if (c.role === 'mirror') monitor('backup', 'backup server disconnected');
  if (c === primaryOutput) primaryOutput = [...clients].find(x => x.role === 'output') || null;
  broadcast({ t: 'outputs', outputs: outputsInfo() });
}
function onMessage(c, op, payload) {
  if (op === 2) { // binary from the primary output: [1]=preview JPEG, [2]=pixel-map data
    if (c !== primaryOutput || !payload.length) return;
    if (payload[0] === 1) { const jpg = payload.subarray(1); for (const x of clients) if (x.role !== 'output' && x.wantPreview) x.sendBin(jpg); }
    else if (payload[0] === 2) sendPixels(payload);
    return;
  }
  let m; try { m = JSON.parse(payload.toString('utf8')); } catch { return; }
  if (pro3.onMessage(c, m)) return;
  if (m.t === 'cmd') { if (c.viewer) return c.send({ t: 'error', msg: 'View-only connection' }); if (c.client && !pro3.clientAllowed(m.cmd || m)) return c.send({ t: 'error', msg: 'Your login can only trigger clips and cues' }); try { applyCmd(m.cmd || m, c); } catch (e) { c.send({ t: 'error', msg: e.message }); } }
  else if (m.t === 'preview') c.wantPreview = !!m.on;
  else if (m.t === 'pos') { if (m.stats) health.outputs[c.id] = Object.assign(m.stats, { at: Date.now() }); if (c === primaryOutput) for (const x of clients) if (x.role !== 'output' && x.role !== 'mirror') x.send(payload.toString('utf8')); }
  else if (m.t === 'ended') handleEnded(m.layer, m.trig);
  else if (m.t === 'unplayable') { if (settings.autoConvert && ffmpegOk && m.src && !hasTranscode(m.src)) { try { queueConvert(m.src); } catch {} } broadcast({ t: 'unplayable', src: m.src, ffmpeg: ffmpegOk }); }
  else if (m.t === 'outinfo') { c.info = m.info; broadcast({ t: 'outputs', outputs: outputsInfo() }); }
  else if (m.t === 'makePrimary' && c.role === 'output') { primaryOutput = c; broadcast({ t: 'outputs', outputs: outputsInfo() }); }
  else if (m.t === 'ping') c.send({ t: 'pong', id: m.id, serverTime: pro3.now() });
  else if (m.t === 'whoami') { c.name = String(m.name || '').slice(0, 30); c.color = String(m.color || '').slice(0, 9); pushPresence(); }
  else if (m.t === 'presence') { c.sel = m.sel || null; c.tab = String(m.tab || '').slice(0, 20); pushPresence(); }
  else if (m.t === 'monitor') { c.wantMonitor = !!m.on; if (m.on) c.send({ t: 'monlog', log: monitorLog.slice(-300) }); }
  else if (m.t === 'hpong') { c.rtt = Date.now() - m.at; }
  else if (m.t === 'beat' && c === primaryOutput) onBeat(m);
  else if (m.t === 'drop' && c === primaryOutput) onDrop(m);
  else if (m.t === 'recerr') rec.captureError(String(m.msg || 'capture failed'));
  else if (m.t === 'midimon' || m.t === 'diagnote') monitor('midi', m.text);
  else if (m.t === 'tc' && !c.viewer) { if (state.comp.timecode.source === m.src) updateTc(m.frames, m.fps); }
  else if (m.t === 'audio' && c === primaryOutput) { for (const x of clients) if (x.role !== 'output') x.send(payload.toString('utf8')); }
}

/* ------------------------------------------------------------------ commands */
const BAD_KEYS = new Set(['__proto__', 'prototype', 'constructor']);
function setPath(obj, p, value) {
  const keys = String(p).split('.'); let o = obj;
  for (let i = 0; i < keys.length - 1; i++) {
    const k = keys[i]; if (BAD_KEYS.has(k)) throw new Error('bad path');
    if (o[k] == null || typeof o[k] !== 'object') throw new Error('no such path: ' + p);
    o = o[k];
  }
  const last = keys[keys.length - 1]; if (BAD_KEYS.has(last)) throw new Error('bad path');
  if (!(last in o) && !Array.isArray(o)) throw new Error('no such key: ' + p);
  o[last] = value;
}
const L = i => { const l = state.layers[i]; if (!l) throw new Error('no layer ' + i); return l; };
function trigger(li, ci) {
  const l = L(li); if (!l.clips[ci]) return;
  l.active = ci; l.trig++; l.trigAt = Date.now(); l.paused = false; l.activeClip = null;
}
function setColumns(n) {
  n = Math.max(1, Math.min(64, n | 0)); state.comp.columns = n;
  for (const l of state.layers) { l.clips.length = n; for (let i = 0; i < n; i++) if (l.clips[i] === undefined) l.clips[i] = null; if (l.active != null && l.active >= n) l.active = null; }
}
function nextClip(l, random) {
  const idx = l.clips.map((c, i) => c ? i : -1).filter(i => i >= 0);
  if (!idx.length) return null;
  if (random && idx.length > 1) { const others = idx.filter(i => i !== l.active); return others[Math.floor(Math.random() * others.length)]; }
  const cur = l.active == null ? -1 : l.active; return idx.find(i => i > cur) ?? idx[0];
}
function handleEnded(li, trig) {
  const l = state.layers[li]; if (!l || l.trig !== trig) return; // dedupe across multiple outputs
  if (l.autopilot !== 'off' && l.autoWhen === 'end') { const n = nextClip(l, l.autopilot === 'random'); if (n != null) { trigger(li, n); markDirty(); } }
}
setInterval(() => { // beat-based autopilot
  const beatMs = 60000 / (state.comp.bpm || 120); let dirty = false;
  state.layers.forEach((l, i) => {
    if (l.autopilot === 'off' || l.autoWhen !== 'beats' || l.active == null || l.paused) return;
    if (Date.now() - (l.trigAt || 0) >= l.autoBeats * beatMs) { const n = nextClip(l, l.autopilot === 'random'); if (n != null) { trigger(i, n); dirty = true; } }
  });
  if (dirty) markDirty();
}, 40);

/* undo / redo + change log */
const undoStack = [], redoStack = [], changeLog = [];
const NO_UNDO = new Set(['feedSet', 'runAction', 'ruleTest', 'rotPlayNow', 'rotStop', 'tlPlay', 'tlStop', 'tlSeek', 'autoRec', 'recStart', 'recStop', 'lockLayer', 'scanInputs', 'trigger', 'column', 'clearLayer', 'clearAll', 'restart', 'pause', 'seek', 'next', 'prev', 'bpm', 'resync', 'blackout',
  'cueGo', 'cueBack', 'cueStop', 'identify', 'reloadOutputs', 'undo', 'redo', 'saveComp', 'deleteComp', 'tcStart', 'tcStop', 'tcReset']);
const PERF_PATHS = /^(comp\.(master|crossfader|speed|blackout|volume)|layers\.\d+\.(opacity|volume))$/;
let lastSnapAt = 0, lastSnapOp = '';
function snapshotForUndo(cmd) {
  if (NO_UNDO.has(cmd.op)) return;
  if (cmd.op === 'set' || cmd.op === 'setMany') {
    const paths = cmd.op === 'set' ? [cmd.path] : Object.keys(cmd.values || {});
    if (paths.every(p => PERF_PATHS.test(p))) return; // live fader moves are performance, not edits
    if (Date.now() - lastSnapAt < 1500 && lastSnapOp === 'set') { lastSnapAt = Date.now(); return; }
  }
  undoStack.push(JSON.stringify(state)); if (undoStack.length > 60) undoStack.shift(); redoStack.length = 0;
  lastSnapAt = Date.now(); lastSnapOp = (cmd.op === 'setMany' ? 'set' : cmd.op);
}
function restoreSnapshot(json) { // keep what is playing live; restore edits
  const live = new Map(state.layers.map(l => [l.id, { active: l.active, trig: l.trig, trigAt: l.trigAt, activeClip: l.activeClip, opacity: l.opacity }]));
  const perf = { master: state.comp.master, blackout: state.comp.blackout, bpm: state.comp.bpm, beatEpoch: state.comp.beatEpoch, crossfader: state.comp.crossfader };
  state = normalizeState(JSON.parse(json)); Object.assign(state.comp, perf);
  for (const l of state.layers) { const v = live.get(l.id); if (v) Object.assign(l, v); else l.active = null; }
}
function logCmd(cmd, from) {
  if (from === 'dmx' || cmd.op === 'seek') return;
  let summary = cmd.op;
  if (cmd.op === 'set') summary = `set ${cmd.path} = ${JSON.stringify(cmd.value)}`;
  else if (cmd.op === 'setMany') summary = 'set ' + Object.entries(cmd.values || {}).map(([k, v]) => `${k}=${typeof v === 'object' ? '…' : v}`).join(', ');
  else if (cmd.layer != null) summary += ` L${cmd.layer + 1}` + (cmd.clip != null ? ` C${cmd.clip + 1}` : '') + (cmd.slot != null ? ` S${cmd.slot + 1}` : '');
  else if (cmd.col != null) summary += ` col ${cmd.col + 1}`; else if (cmd.name) summary += ` "${cmd.name}"`;
  const who = from && from.role ? from.role : (typeof from === 'string' ? from : 'api');
  const last = changeLog[changeLog.length - 1];
  if (last && last.who === who && (cmd.op === 'setMany' || cmd.op === 'set') && last.kind === 'set' && Date.now() - last.at < 1200) { last.summary = summary; last.at = Date.now(); return; }
  changeLog.push({ at: Date.now(), who, kind: cmd.op === 'setMany' ? 'set' : cmd.op, summary: summary.slice(0, 200) }); if (changeLog.length > 300) changeLog.shift();
}
function applyCmd(cmd, from) {
  if (Array.isArray(cmd)) return cmd.forEach(x => applyCmd(x, from));
  if (!cmd || typeof cmd !== 'object') return;
  if (cmd.op === 'undo') { if (undoStack.length) { redoStack.push(JSON.stringify(state)); restoreSnapshot(undoStack.pop()); logCmd(cmd, from); markDirty(); } return; }
  if (cmd.op === 'redo') { if (redoStack.length) { undoStack.push(JSON.stringify(state)); restoreSnapshot(redoStack.pop()); logCmd(cmd, from); markDirty(); } return; }
  // backup mode: while the primary is alive, forward operator commands to it (the primary stays the authority)
  if ((settings.backup || {}).mode === 'backup' && mirror.connected && !mirror.active && from && typeof from === 'object') { try { mirror.ws.send(JSON.stringify({ t: 'cmd', cmd })); } catch {} return; }
  checkLock(cmd, from);
  if (from && (typeof from === 'object' || from === 'api' || from === 'osc')) pro3.lockCheck(cmd);
  if (typeof from === 'string' && from !== 'api') monitor(from, JSON.stringify(cmd).slice(0, 160));
  if (autoRec) { if (cmd.op === 'set') autoRecord(cmd.path, cmd.value); else if (cmd.op === 'setMany') for (const [k, v] of Object.entries(cmd.values || {})) autoRecord(k, v); }
  snapshotForUndo(cmd); logCmd(cmd, from);
  const r = applyCmdInner(cmd, from); try { pro3.afterChange(); } catch (e) { console.warn(e.message); } return r;
}
function autoConvertClip(clip) { // queue local conversion as soon as a non-browser format is placed in a slot
  if (!clip || clip.type !== 'video' || !clip.src || !settings.autoConvert || !ffmpegOk) return;
  const abs = resolveMedia(clip.src); if (abs && !isNative(abs) && !hasTranscode(clip.src)) { try { queueConvert(clip.src); } catch {} }
}
function applyCmdInner(cmd, from) {
  if (Array.isArray(cmd)) return cmd.forEach(x => applyCmdInner(x, from));
  const c = state.comp;
  if (cmd.op === 'assign') autoConvertClip(cmd.clip); if (cmd.op === 'fillLayer') (cmd.items || []).forEach(autoConvertClip);
  switch (cmd.op) {
    case 'set': setPath(state, cmd.path, cmd.value); break;
    case 'setMany': for (const [p, v] of Object.entries(cmd.values || {})) setPath(state, p, v); break;
    case 'trigger': trigger(cmd.layer, cmd.clip); break;
    case 'column': state.layers.forEach((l, i) => { if (l.clips[cmd.col]) trigger(i, cmd.col); else if (cmd.clearEmpty) l.active = null; }); break;
    case 'clearLayer': L(cmd.layer).active = null; break;
    case 'clearAll': state.layers.forEach(l => l.active = null); break;
    case 'restart': { const l = L(cmd.layer); if (l.active != null) { l.trig++; l.trigAt = Date.now(); l.paused = false; } break; }
    case 'pause': L(cmd.layer).paused = cmd.paused != null ? !!cmd.paused : !L(cmd.layer).paused; break;
    case 'seek': broadcast({ t: 'seek', layer: cmd.layer, pos: +cmd.pos }, 'output'); return;
    case 'next': { const l = L(cmd.layer); const n = nextClip(l, cmd.random); if (n != null) trigger(cmd.layer, n); break; }
    case 'prev': { const l = L(cmd.layer); const idx = l.clips.map((x, i) => x ? i : -1).filter(i => i >= 0); if (idx.length) { const cur = l.active ?? 0; const p = [...idx].reverse().find(i => i < cur) ?? idx[idx.length - 1]; trigger(cmd.layer, p); } break; }
    case 'assign': {
      const l = L(cmd.layer); if (cmd.slot < 0 || cmd.slot >= c.columns) throw new Error('bad slot');
      l.clips[cmd.slot] = Object.assign(S.clipDefaults(), cmd.clip || {}); break;
    }
    case 'removeClip': { const l = L(cmd.layer); l.clips[cmd.slot] = null; if (l.active === cmd.slot) l.active = null; break; }
    case 'moveClip': {
      const [fl, fs_] = cmd.from, [tl, ts] = cmd.to; const a = L(fl), b = L(tl);
      const clip = a.clips[fs_]; if (!clip) break;
      const copy = JSON.parse(JSON.stringify(clip));
      if (!cmd.copy) { const swap = b.clips[ts]; a.clips[fs_] = swap || null; if (a.active === fs_) a.active = null; }
      b.clips[ts] = copy; break;
    }
    case 'addLayer': state.layers.push(S.layerDefaults(state.layers.length, c.columns)); break;
    case 'removeLayer': if (state.layers.length > 1) state.layers.splice(cmd.layer, 1); break;
    case 'moveLayer': { const i = cmd.layer, j = i + cmd.dir; if (j >= 0 && j < state.layers.length) [state.layers[i], state.layers[j]] = [state.layers[j], state.layers[i]]; break; }
    case 'duplicateLayer': { const cp = JSON.parse(JSON.stringify(L(cmd.layer))); cp.id = 'L' + Math.random().toString(36).slice(2, 8); cp.name += ' copy'; cp.active = null; state.layers.splice(cmd.layer + 1, 0, cp); break; }
    case 'setColumns': setColumns(cmd.n); break;
    case 'bpm': c.bpm = Math.max(20, Math.min(400, +cmd.bpm || 120)); if (cmd.resync) c.beatEpoch = Date.now() - (cmd.phaseMs || 0); break;
    case 'resync': c.beatEpoch = Date.now(); break;
    case 'blackout': c.blackout = cmd.on != null ? !!cmd.on : !c.blackout; break;
    case 'resetFx': { const t = cmd.layer == null ? c : L(cmd.layer); if (cmd.fx) { t.fx[cmd.fx] = S.fxDefaults()[cmd.fx]; } else t.fx = S.fxDefaults(); break; }
    case 'newComp': state = normalizeState(S.newState()); break;
    case 'saveComp': { const name = safeName(cmd.name || c.name); c.name = cmd.name || c.name; fs.writeFileSync(path.join(COMPS, name + '.json'), JSON.stringify(state)); broadcastComps(); break; }
    case 'loadComp': { const f = path.join(COMPS, safeName(cmd.name) + '.json'); const st = readJSON(f, null); if (!st) throw new Error('not found'); state = normalizeState(st); state.layers.forEach(l => l.active = null); break; }
    case 'deleteComp': { try { fs.unlinkSync(path.join(COMPS, safeName(cmd.name) + '.json')); } catch {} broadcastComps(); return; }
    /* data feeds & rules */
    case 'feedAdd': state.feeds.push(Object.assign({ id: 'feed' + (state.feeds.length + 1), name: 'Feed ' + (state.feeds.length + 1), type: 'json', url: '', interval: 5, on: true }, cmd.feed || {})); break;
    case 'feedRemove': state.feeds = state.feeds.filter(f => f.id !== cmd.id); delete feedValues[cmd.id]; break;
    case 'feedSet': setFeed(String(cmd.id), cmd.value, 'command'); return;
    case 'ruleAdd': state.rules.push(Object.assign({ id: 'r' + crypto.randomBytes(3).toString('hex'), name: 'Rule ' + (state.rules.length + 1), on: true, feed: (state.feeds[0] || {}).id || '', path: '', when: 'change', value: '', cooldown: 0, action: { type: 'column', col: 1 } }, cmd.rule || {})); break;
    case 'ruleRemove': state.rules = state.rules.filter(r => r.id !== cmd.id); break;
    case 'ruleTest': { const r = state.rules.find(x => x.id === cmd.id); if (r) applyCmd(S.actionToCmd(r.action), 'rule-test'); return; }
    /* scheduler */
    case 'schedAdd': state.schedule.push(Object.assign({ id: 's' + crypto.randomBytes(3).toString('hex'), name: 'Scheduled action', on: true, days: [0, 1, 2, 3, 4, 5, 6], time: '18:00', action: { type: 'blackoutOff' } }, cmd.entry || {})); break;
    case 'schedRemove': state.schedule = state.schedule.filter(e => e.id !== cmd.id); break;
    case 'runAction': applyCmd(S.actionToCmd(cmd.action), from); return;
    /* sponsors */
    case 'rotAdd': state.rotation.items.push(Object.assign({ id: 'ad' + crypto.randomBytes(3).toString('hex'), on: true, name: 'Sponsor spot', sponsor: '', clip: null, every: 10, dur: 15, from: '', to: '' }, cmd.item || {})); break;
    case 'rotRemove': state.rotation.items = state.rotation.items.filter(i => i.id !== cmd.id); break;
    case 'rotPlayNow': { const it = state.rotation.items.find(i => i.id === cmd.id); if (it) { if (rot.playing) rotStop('replaced'); rotPlay(it); } return; }
    case 'rotStop': rotStop('manual'); return;
    /* generator presets (titles / logos) */
    case 'genPresetSave': state.genPresets.push({ id: 'gp' + crypto.randomBytes(3).toString('hex'), name: cmd.name || 'Preset', clip: cmd.clip }); break;
    case 'genPresetRemove': state.genPresets = state.genPresets.filter(p => p.id !== cmd.id); break;
    /* timeline */
    case 'tlPlay': { const p = state.timeline.play; if (!p.playing) state.timeline.play = { playing: true, pos: p.pos >= state.timeline.duration ? 0 : p.pos, startAt: Date.now() }; for (const k in tlLast) delete tlLast[k]; break; }
    case 'tlStop': state.timeline.play = { playing: false, pos: tlPos(), startAt: 0 }; break;
    case 'tlSeek': { const p = state.timeline.play; state.timeline.play = { playing: p.playing, pos: Math.max(0, +cmd.pos || 0), startAt: Date.now() }; for (const k in tlLast) delete tlLast[k]; break; }
    case 'tlAddTrack': { const l = L(cmd.layer); if (!state.timeline.tracks.find(t => t.layerId === l.id)) state.timeline.tracks.push({ id: 't' + crypto.randomBytes(3).toString('hex'), layerId: l.id, items: [], mute: false, clearGaps: true }); break; }
    case 'tlRemoveTrack': state.timeline.tracks = state.timeline.tracks.filter(t => t.id !== cmd.id); break;
    case 'tlAddItem': { const tr = state.timeline.tracks.find(t => t.id === cmd.track); if (tr) tr.items.push({ id: 'i' + crypto.randomBytes(3).toString('hex'), start: Math.max(0, +cmd.start || 0), dur: Math.max(0.1, +cmd.dur || 8), slot: cmd.slot | 0 }); break; }
    case 'tlRemoveItem': for (const tr of state.timeline.tracks) tr.items = tr.items.filter(i => i.id !== cmd.id); break;
    case 'tlAddLane': state.timeline.lanes.push({ id: 'ln' + crypto.randomBytes(3).toString('hex'), path: cmd.path || 'comp.master', min: cmd.min ?? 0, max: cmd.max ?? 1, on: true, points: [] }); break;
    case 'tlRemoveLane': state.timeline.lanes = state.timeline.lanes.filter(l => l.id !== cmd.id); break;
    /* clip automation */
    case 'autoRec': {
      if (cmd.on) { const l = L(cmd.layer); if (!l.clips[cmd.slot]) break; if (l.active !== cmd.slot) trigger(cmd.layer, cmd.slot); autoRec = { layerId: l.id, slot: cmd.slot, start: l.trigAt || Date.now(), data: {} }; monitor('auto', 'recording automation'); }
      else if (autoRec) { const li = state.layers.findIndex(l => l.id === autoRec.layerId); const cl = li >= 0 && state.layers[li].clips[autoRec.slot];
        if (cl && Object.keys(autoRec.data).length) cl.auto = { len: Math.max(0.5, (Date.now() - autoRec.start) / 1000), paths: autoRec.data, on: true }; autoRec = null; }
      break; }
    case 'autoClear': { const cl = L(cmd.layer).clips[cmd.slot]; if (cl) cl.auto = null; break; }
    /* team */
    case 'lockLayer': { const l = L(cmd.layer); const me = (from && from.name) || 'API'; if (cmd.on) l.lockedBy = me; else if (!l.lockedBy || l.lockedBy === me || cmd.force) l.lockedBy = ''; else throw new Error('Locked by ' + l.lockedBy); break; }
    /* recording */
    case 'recStart': rec.start(cmd); return;
    case 'recStop': rec.stop(); return;
    case 'recPrefs': rec.setPrefs(cmd.prefs || {}); return;
    /* LED day/night & processors use plain set */
    case 'identify': broadcast({ t: 'identify' }, 'output'); return;
    /* decks */
    case 'deckSwitch': { const i = cmd.deck | 0; if (!state.decks[i] || i === c.deck) break; storeDeck();
      for (const l of state.layers) if (l.active != null && l.clips[l.active]) l.activeClip = JSON.parse(JSON.stringify(l.clips[l.active]));
      loadDeck(i); break; }
    case 'deckAdd': storeDeck(); state.decks.push({ name: cmd.name || 'Deck ' + (state.decks.length + 1), clips: {} }); for (const l of state.layers) if (l.active != null && l.clips[l.active]) l.activeClip = JSON.parse(JSON.stringify(l.clips[l.active])); loadDeck(state.decks.length - 1); break;
    case 'deckRename': if (state.decks[cmd.deck]) state.decks[cmd.deck].name = String(cmd.name || '').slice(0, 40); break;
    case 'deckDelete': { if (state.decks.length < 2) break; const i = cmd.deck | 0; storeDeck(); state.decks.splice(i, 1); const ni = Math.max(0, Math.min(i, state.decks.length - 1)); c.deck = -1; loadDeck(ni); break; }
    /* effect presets / looks */
    case 'presetSave': { const src = cmd.layer == null ? c : L(cmd.layer); state.presets.push({ id: 'p' + crypto.randomBytes(3).toString('hex'), name: cmd.name || 'Look ' + (state.presets.length + 1), fav: false, fx: JSON.parse(JSON.stringify(src.fx)), blend: cmd.layer == null ? null : src.blend }); break; }
    case 'presetApply': { const pr = state.presets.find(x => x.id === cmd.id); if (!pr) break; const t = cmd.layer == null ? c : L(cmd.layer); t.fx = mergeFx(JSON.parse(JSON.stringify(pr.fx))); if (pr.blend && cmd.layer != null) t.blend = pr.blend; break; }
    case 'presetDelete': state.presets = state.presets.filter(x => x.id !== cmd.id); break;
    case 'clipFx': { const cl = L(cmd.layer).clips[cmd.slot]; if (cl) cl.fx = cmd.on ? (cl.fx || S.fxDefaults()) : null; break; }
    /* modulators (LFO / audio) */
    case 'addMod': state.mods.push(Object.assign(S.modDefaults(), cmd.mod || {})); break;
    case 'removeMod': state.mods = state.mods.filter(m => m.id !== cmd.id); break;
    /* outputs & slices */
    case 'addOutput': state.outputs.push(S.outputDefaults(null, cmd.name || 'Output ' + (state.outputs.length + 1))); break;
    case 'removeOutput': if (cmd.id !== 'main') state.outputs = state.outputs.filter(o => o.id !== cmd.id); break;
    case 'addSlice': { const o = state.outputs.find(x => x.id === cmd.output); if (o) o.slices.push(Object.assign(S.sliceDefaults(o.slices.length + 1), cmd.slice || {})); break; }
    case 'removeSlice': { const o = state.outputs.find(x => x.id === cmd.output); if (o) o.slices = o.slices.filter(s => s.id !== cmd.slice); break; }
    case 'sliceTemplate': { const o = state.outputs.find(x => x.id === cmd.output); if (!o) break; const n = Math.max(1, Math.min(16, cmd.n | 0)); const dir = cmd.dir || 'h';
      o.slices = Array.from({ length: n }, (_, i) => { const s = S.sliceDefaults(i + 1); const a = i / n, b = (i + 1) / n;
        if (dir === 'h') { s.src = { x: a, y: 0, w: 1 / n, h: 1 }; s.dst = [[a, 0], [b, 0], [b, 1], [a, 1]]; } else { s.src = { x: 0, y: a, w: 1, h: 1 / n }; s.dst = [[0, a], [1, a], [1, b], [0, b]]; } return s; }); break; }
    /* LED screens / panels */
    case 'ledAddScreen': { const n = state.led.screens.length + 1; const sc = Object.assign(S.screenDefaults(n), cmd.screen || {});
      if (cmd.screen == null || cmd.screen.x == null) { const r = ledBounds('x', 'y'); sc.x = state.led.screens.length ? r.w : 0; sc.y = 0; sc.outX = sc.x; sc.outY = 0; }
      state.led.screens.push(sc); break; }
    case 'ledRemoveScreen': state.led.screens = state.led.screens.filter(x => x.id !== cmd.id); break;
    case 'ledDuplicate': { const src = state.led.screens.find(x => x.id === cmd.id); if (!src) break; const r = ledBounds('x', 'y');
      state.led.screens.push(Object.assign(JSON.parse(JSON.stringify(src)), { id: 'scr' + crypto.randomBytes(3).toString('hex'), name: src.name + ' copy', x: r.w, outX: ledBounds('outX', 'outY').w, color: S.SCREEN_COLORS[state.led.screens.length % S.SCREEN_COLORS.length] })); break; }
    case 'ledFitComp': { const r = ledBounds('x', 'y'); if (r.w > 0 && r.h > 0) { c.width = Math.min(8192, r.w); c.height = Math.min(8192, r.h); } break; }
    case 'ledPack': { // pack screens left-to-right into a processor raster (wrap at maxWidth)
      const maxW = Math.max(64, cmd.maxWidth | 0 || 1920); let x = 0, y = 0, rowH = 0;
      for (const sc of state.led.screens) { const [w, h] = ledOutSize(sc); if (x > 0 && x + w > maxW) { x = 0; y += rowH; rowH = 0; } sc.outX = x; sc.outY = y; x += w; rowH = Math.max(rowH, h); } break; }
    case 'ledSameAsContent': for (const sc of state.led.screens) { sc.outX = sc.x; sc.outY = sc.y; } break;
    case 'ledBuildOutput': buildLedOutput(cmd.output); break;
    /* pixel-map fixtures */
    case 'addFixture': c.pixelMap.fixtures.push(Object.assign(S.fixtureDefaults(c.pixelMap.fixtures.length + 1), cmd.fixture || {})); break;
    case 'removeFixture': c.pixelMap.fixtures = c.pixelMap.fixtures.filter(f => f.id !== cmd.id); break;
    /* cue list */
    case 'cueRecord': { const cue = { id: 'q' + crypto.randomBytes(3).toString('hex'), name: cmd.name || 'Cue ' + (state.cues.length + 1), type: 'snapshot', data: snapshot(), fade: cmd.fade ?? 1, follow: 'none', wait: 0, tc: '' };
      const at = cmd.index == null ? state.cues.length : cmd.index; state.cues.splice(at, 0, cue); break; }
    case 'cueAdd': state.cues.push(Object.assign({ id: 'q' + crypto.randomBytes(3).toString('hex'), name: 'Cue ' + (state.cues.length + 1), type: 'column', data: { col: 0 }, fade: 0, follow: 'none', wait: 0, tc: '' }, cmd.cue || {})); break;
    case 'cueRerecord': { const q = state.cues[cmd.index]; if (q) { q.type = 'snapshot'; q.data = snapshot(); } break; }
    case 'cueDelete': state.cues.splice(cmd.index, 1); if (state.cueIndex >= state.cues.length) state.cueIndex = state.cues.length - 1; break;
    case 'cueMove': { const i = cmd.index, j = i + cmd.dir; if (j >= 0 && j < state.cues.length) [state.cues[i], state.cues[j]] = [state.cues[j], state.cues[i]]; break; }
    case 'cueGo': cueGo(cmd.index == null ? state.cueIndex + 1 : cmd.index); break;
    case 'cueBack': cueGo(Math.max(0, state.cueIndex - 1)); break;
    case 'cueStop': clearTimeout(followTimer); tweens.length = 0; break;
    /* layouts / PiP / grids */
    case 'layout': applyLayout(cmd.preset, cmd.layers); break;
    case 'fillLayer': { const l = L(cmd.layer); const items = (cmd.items || []).slice(0, 64); let slot = cmd.start | 0;
      if (slot + items.length > c.columns) setColumns(Math.min(64, slot + items.length));
      for (const it of items) { if (slot >= c.columns) break; l.clips[slot++] = Object.assign(S.clipDefaults(), it); } break; }
    /* shaders */
    case 'shaderSave': { const sh = cmd.shader || {}; const ex = state.shaders.find(x => x.id === sh.id);
      if (ex) Object.assign(ex, { name: sh.name || ex.name, code: String(sh.code || ex.code) }); else state.shaders.push({ id: sh.id || 'sh' + crypto.randomBytes(3).toString('hex'), name: sh.name || 'My Shader', code: String(sh.code || '') }); break; }
    case 'shaderDelete': state.shaders = state.shaders.filter(x => x.id !== cmd.id); break;
    /* timecode (internal clock) */
    case 'tcStart': tc.running = true; tc.startAt = Date.now(); tc.base = tc.frames; c.timecode.source = 'internal'; break;
    case 'tcStop': tc.running = false; break;
    case 'tcReset': tc.running = false; tc.frames = cmd.frames | 0; tc.base = tc.frames; tc.last = tc.frames; broadcast({ t: 'tc', frames: tc.frames, fps: c.timecode.fps, running: false }); return;
    case 'reloadOutputs': broadcast({ t: 'reload' }, 'output'); return;
    case 'scanInputs': broadcast({ t: 'scanInputs' }, 'output'); return;
    default: if (!pro3.op(cmd, from)) throw new Error('unknown op ' + cmd.op);
  }
  markDirty();
}
const safeName = n => String(n).replace(/[^\w\- ]+/g, '').trim().slice(0, 60) || 'composition';
function listComps() { try { return fs.readdirSync(COMPS).filter(f => f.endsWith('.json')).map(f => f.slice(0, -5)).sort(); } catch { return []; } }
function broadcastComps() { broadcast({ t: 'comps', comps: listComps() }); }

/* ------------------------------------------------------------------ LED walls */
const ledSize = sc => [Math.max(1, sc.panelW | 0) * Math.max(1, sc.cols | 0), Math.max(1, sc.panelH | 0) * Math.max(1, sc.rows | 0)];
const ledOutSize = sc => { const [w, h] = ledSize(sc); return (sc.rotation === 90 || sc.rotation === 270) ? [h, w] : [w, h]; };
function ledBounds(kx, ky) { let w = 0, h = 0; for (const sc of state.led.screens) { const [sw, sh] = kx === 'x' ? ledSize(sc) : ledOutSize(sc); w = Math.max(w, (sc[kx] | 0) + sw); h = Math.max(h, (sc[ky] | 0) + sh); } return { w, h }; }
function buildLedOutput(outId) {
  const W = state.comp.width, H = state.comp.height; const ob = ledBounds('outX', 'outY'); if (!ob.w) return;
  let o = state.outputs.find(x => x.id === (outId || state.led.output)) || state.outputs.find(x => x.id === 'led');
  if (!o) { o = S.outputDefaults('led', 'LED Processor'); state.outputs.push(o); }
  state.led.output = o.id; o.width = ob.w; o.height = ob.h; o.slices = o.slices.filter(s => !String(s.id).startsWith('led-'));
  for (const sc of state.led.screens) {
    const [w, h] = ledSize(sc), [ow, oh] = ledOutSize(sc);
    const L = (sc.outX | 0) / ob.w, T = (sc.outY | 0) / ob.h, R = ((sc.outX | 0) + ow) / ob.w, B = ((sc.outY | 0) + oh) / ob.h;
    const TL = [L, T], TR = [R, T], BR = [R, B], BL = [L, B];
    const dst = sc.rotation === 90 ? [TR, BR, BL, TL] : sc.rotation === 180 ? [BR, BL, TL, TR] : sc.rotation === 270 ? [BL, TL, TR, BR] : [TL, TR, BR, BL];
    o.slices.push(Object.assign(S.sliceDefaults(), { id: 'led-' + sc.id, name: sc.name, src: { x: (sc.x | 0) / W, y: (sc.y | 0) / H, w: w / W, h: h / H }, dst }));
  }
}

/* ------------------------------------------------------------------ decks */
function storeDeck() { const d = state.decks[state.comp.deck]; if (!d) return; d.clips = {}; for (const l of state.layers) d.clips[l.id] = JSON.parse(JSON.stringify(l.clips)); }
function loadDeck(i) {
  const d = state.decks[i]; const cols = state.comp.columns;
  for (const l of state.layers) l.clips = Array.from({ length: cols }, (_, k) => ((d.clips || {})[l.id] || [])[k] || null);
  state.comp.deck = i;
}

/* ------------------------------------------------------------------ cues + tweens */
const tweens = []; let followTimer = null;
function snapshot() { return { master: state.comp.master, deck: state.comp.deck, layers: state.layers.map(l => ({ id: l.id, active: l.active, opacity: l.opacity })) }; }
function tweenTo(pth, to, dur) {
  for (let i = tweens.length - 1; i >= 0; i--) if (tweens[i].path === pth) tweens.splice(i, 1);
  const from = pth.split('.').reduce((o, k) => o && o[k], state);
  if (typeof from !== 'number' || dur <= 0) { try { setPath(state, pth, to); } catch {} return; }
  tweens.push({ path: pth, from, to, start: Date.now(), dur: dur * 1000 });
}
setInterval(() => {
  if (!tweens.length) return; const now = Date.now();
  for (let i = tweens.length - 1; i >= 0; i--) { const t = tweens[i]; const k = Math.min(1, (now - t.start) / t.dur);
    try { setPath(state, t.path, t.from + (t.to - t.from) * k); } catch { k === 1; } if (k >= 1) tweens.splice(i, 1); }
  markDirty();
}, 33);
function cueGo(i) {
  const q = state.cues[i]; if (!q) return; state.cueIndex = i; clearTimeout(followTimer);
  if (q.type === 'snapshot' && q.data) {
    if (q.data.deck != null && q.data.deck !== state.comp.deck && state.decks[q.data.deck]) applyCmdInner({ op: 'deckSwitch', deck: q.data.deck });
    for (const s of q.data.layers || []) {
      const li = state.layers.findIndex(l => l.id === s.id); if (li < 0) continue; const l = state.layers[li];
      if (s.active == null) { if (q.fade > 0) { tweenTo(`layers.${li}.opacity`, 0, q.fade); setTimeout(() => { const ll = state.layers[li]; if (ll && ll.id === s.id && ll.opacity < 0.01) { ll.active = null; ll.opacity = s.opacity; markDirty(); } }, q.fade * 1000 + 60); } else l.active = null; continue; }
      if (l.active !== s.active && l.clips[s.active]) trigger(li, s.active);
      tweenTo(`layers.${li}.opacity`, s.opacity, q.fade || 0);
    }
    if (q.data.master != null) tweenTo('comp.master', q.data.master, q.fade || 0);
  } else if (q.type === 'column') applyCmdInner({ op: 'column', col: (q.data && q.data.col) | 0 });
  else if (q.type === 'commands') { try { applyCmdInner(q.data && q.data.cmds || []); } catch (e) { console.warn('cue cmd', e.message); } }
  if (q.follow === 'auto' && state.cues[i + 1]) followTimer = setTimeout(() => { cueGo(i + 1); markDirty(); }, Math.max(0, +q.wait || 0) * 1000);
  broadcast({ t: 'cue', index: i });
}

/* ------------------------------------------------------------------ timecode (MTC / LTC from browsers, or internal clock) */
const tc = { frames: 0, last: -1, running: false, startAt: 0, base: 0, sentAt: 0 };
function parseTc(str, fps) { const m = /^(\d+):(\d+):(\d+)[:;.](\d+)$/.exec(String(str || '').trim()); return m ? ((+m[1] * 60 + +m[2]) * 60 + +m[3]) * fps + +m[4] : null; }
function updateTc(frames, fpsIn) {
  const fps = state.comp.timecode.fps || fpsIn || 25; frames = (frames | 0) + Math.round((state.comp.timecode.offset || 0) * fps);
  const prev = tc.last; tc.frames = frames; tc.last = frames;
  if (prev >= 0 && frames > prev && frames - prev <= fps * 2) {
    state.cues.forEach((q, i) => { const f = parseTc(q.tc, fps); if (f != null && f > prev && f <= frames) { cueGo(i); markDirty(); } });
  }
  if (Date.now() - tc.sentAt > 90) { tc.sentAt = Date.now(); broadcast({ t: 'tc', frames, fps, running: tc.running, source: state.comp.timecode.source }); }
}
setInterval(() => { if (tc.running && state.comp.timecode.source === 'internal') updateTc(tc.base + Math.floor((Date.now() - tc.startAt) / 1000 * (state.comp.timecode.fps || 25))); }, 20);

/* ------------------------------------------------------------------ layouts (grids / picture-in-picture) */
function applyLayout(preset, layerIdx) {
  const idx = Array.isArray(layerIdx) && layerIdx.length ? layerIdx : state.layers.map((l, i) => i).filter(i => state.layers[i].active != null);
  const cells = {
    full: () => [], '2-side': () => [[-0.5, 0, 1, 0, 0, 0.5, 1], [0.5, 0, 1, 0.5, 0, 0.5, 1]], '2-stack': () => [[0, 0.5, 1, 0, 0, 1, 0.5], [0, -0.5, 1, 0, 0.5, 1, 0.5]],
    '3-across': () => [[-2 / 3, 0, 1, 0, 0, 1 / 3, 1], [0, 0, 1, 1 / 3, 0, 1 / 3, 1], [2 / 3, 0, 1, 2 / 3, 0, 1 / 3, 1]],
    '4-grid': () => [[-0.5, 0.5, 0.5, 0, 0, 0.5, 0.5], [0.5, 0.5, 0.5, 0.5, 0, 0.5, 0.5], [-0.5, -0.5, 0.5, 0, 0.5, 0.5, 0.5], [0.5, -0.5, 0.5, 0.5, 0.5, 0.5, 0.5]],
  };
  for (const l of state.layers) { l.transform = { x: 0, y: 0, scale: 1, rotation: 0 }; l.mask = { type: 'none', x: 0, y: 0, w: 1, h: 1, feather: 0, invert: false }; }
  if (preset.startsWith('pip')) { // top-most active layer becomes the small picture
    const top = idx[idx.length - 1]; if (top == null) return; const l = state.layers[top]; const s = 0.3;
    const px = preset.endsWith('r') ? 0.62 : -0.62, py = preset.includes('-t') ? 0.62 : -0.62;
    const u = 0.5 + px / 2, v = 0.5 - py / 2; l.transform = { x: px, y: py, scale: s, rotation: 0 };
    l.mask = { type: 'rect', x: u - s / 2, y: v - s / 2, w: s, h: s, feather: 0, invert: false }; return;
  }
  const list = (cells[preset] || cells.full)();
  list.forEach((c, k) => { const li = idx[k]; if (li == null) return; const l = state.layers[li];
    l.transform = { x: c[0], y: c[1], scale: c[2], rotation: 0 }; l.mask = { type: 'rect', x: c[3], y: c[4], w: c[5], h: c[6], feather: 0, invert: false }; });
}

/* ------------------------------------------------------------------ DMX input (Art-Net 6454 / sACN 5568) */
const dmxLast = new Uint8Array(512).fill(255); let dmxSeen = false, dmxSacnJoined = null;
function applyDmx(data) {
  const cfg = state.comp.dmx; if (!cfg.enabled) return; const base = Math.max(1, cfg.address | 0) - 1; let dirty = false;
  const ch = i => data[base + i] ?? 0;
  const changed = i => { const a = base + i; if (a >= 512) return false; if (!dmxSeen || dmxLast[a] !== (data[a] ?? 0)) { dmxLast[a] = data[a] ?? 0; return true; } return false; };
  const set = (pth, v) => { try { setPath(state, pth, v); dirty = true; } catch {} };
  if (changed(0)) set('comp.master', ch(0) / 255);
  if (changed(1)) set('comp.crossfader', ch(1) / 255);
  if (changed(2) && ch(2) > 0) { applyCmdInner({ op: 'column', col: ch(2) - 1 }); dirty = true; }
  if (changed(3)) set('comp.speed', ch(3) === 0 ? 1 : ch(3) / 255 * 2);
  state.layers.forEach((l, li) => {
    const o = 4 + li * 6;
    if (changed(o)) set(`layers.${li}.opacity`, ch(o) / 255);
    if (changed(o + 1)) { const v = ch(o + 1); if (v === 0) { l.active = null; dirty = true; } else if (l.clips[v - 1] && l.active !== v - 1) { trigger(li, v - 1); dirty = true; } }
    if (changed(o + 2)) { const v = ch(o + 2); if (l.active != null && l.clips[l.active]) set(`layers.${li}.clips.${l.active}.speed`, v === 0 ? 1 : v / 255 * 2); }
    if (changed(o + 3)) { const v = ch(o + 3); l.fx.color.on = v > 0 || l.fx.color.on && l.fx.color.hue === 0 ? v > 0 || l.fx.color.on : false; l.fx.color.hue = v / 255; if (v > 0) l.fx.color.on = true; dirty = true; }
    if (changed(o + 4)) { const v = ch(o + 4); l.fx.strobe.on = v > 0; if (v > 0) l.fx.strobe.rate = Math.min(4, Math.floor((v - 1) / 51)); dirty = true; }
    if (changed(o + 5)) { const v = ch(o + 5); l.fx.pixelate.on = v > 0; l.fx.pixelate.size = Math.max(2, Math.round(v / 2)); dirty = true; }
  });
  dmxSeen = true; if (dirty) markDirty();
}
function sacnJoin(sock) {
  const cfg = state.comp.dmx; const u = Math.max(1, cfg.universe | 0); const addr = `239.255.${(u >> 8) & 255}.${u & 255}`;
  if (dmxSacnJoined === addr) return; try { if (dmxSacnJoined) sock.dropMembership(dmxSacnJoined); } catch {}
  try { sock.addMembership(addr); dmxSacnJoined = addr; } catch (e) { /* no multicast iface */ }
}
try {
  const art = dgram.createSocket({ type: 'udp4', reuseAddr: true });
  art.on('message', b => {
    if (b.length >= 19 && b.readUInt16LE(8) === 0x9700 && b.toString('latin1', 0, 7) === 'Art-Net') return pro3.artTc(b);
    const cfg = state.comp.dmx; if (!cfg.enabled || cfg.protocol !== 'artnet') return;
    if (b.length < 18 || b.toString('latin1', 0, 7) !== 'Art-Net' || b.readUInt16LE(8) !== 0x5000) return;
    const uni = b[14] | (b[15] << 8); monRate('Art-Net universe ' + uni); if (uni !== (cfg.universe | 0)) return;
    applyDmx(b.subarray(18, 18 + b.readUInt16BE(16)));
  });
  art.on('error', e => console.warn('Art-Net input disabled:', e.message));
  art.bind(6454, () => { try { art.setBroadcast(true); } catch {} });
  const sacn = dgram.createSocket({ type: 'udp4', reuseAddr: true });
  sacn.on('message', b => {
    const cfg = state.comp.dmx; if (!cfg.enabled || cfg.protocol !== 'sacn') return;
    if (b.length < 126 || b.toString('latin1', 4, 13) !== 'ASC-E1.17') return;
    monRate('sACN universe ' + b.readUInt16BE(113)); if (b.readUInt16BE(113) !== Math.max(1, cfg.universe | 0) || b[125] !== 0) return;
    applyDmx(b.subarray(126));
  });
  sacn.on('error', e => console.warn('sACN input disabled:', e.message));
  sacn.bind(5568, () => { sacnJoin(sacn); setInterval(() => sacnJoin(sacn), 3000); });
} catch (e) { console.warn('DMX input disabled', e.message); }

/* ------------------------------------------------------------------ pixel-map output (Art-Net / sACN) */
const pxSock = dgram.createSocket('udp4'); pxSock.on('error', () => {}); pxSock.bind(() => { try { pxSock.setBroadcast(true); pxSock.setMulticastTTL(4); } catch {} });
const CID = crypto.randomBytes(16); const pxSeq = {};
function artDmx(uni, data) {
  const b = Buffer.alloc(18 + 512); b.write('Art-Net\0', 0, 'latin1'); b.writeUInt16LE(0x5000, 8); b.writeUInt16BE(14, 10);
  pxSeq[uni] = ((pxSeq[uni] || 0) % 255) + 1; b[12] = pxSeq[uni]; b[13] = 0; b[14] = uni & 255; b[15] = (uni >> 8) & 127; b.writeUInt16BE(512, 16);
  data.copy(b, 18, 0, Math.min(512, data.length)); return b;
}
function sacnPkt(uni, data) {
  const b = Buffer.alloc(638); b.writeUInt16BE(0x0010, 0); b.write('ASC-E1.17', 4, 'latin1');
  b.writeUInt16BE(0x7000 | (638 - 16), 16); b.writeUInt32BE(4, 18); CID.copy(b, 22);
  b.writeUInt16BE(0x7000 | (638 - 38), 38); b.writeUInt32BE(2, 40); b.write('PIXORA', 44, 'latin1'); b[108] = 100;
  pxSeq['s' + uni] = ((pxSeq['s' + uni] || 0) + 1) & 255; b[111] = pxSeq['s' + uni]; b.writeUInt16BE(uni, 113);
  b.writeUInt16BE(0x7000 | (638 - 115), 115); b[117] = 2; b[118] = 0xa1; b.writeUInt16BE(0, 119); b.writeUInt16BE(1, 121); b.writeUInt16BE(513, 123); b[125] = 0;
  data.copy(b, 126, 0, Math.min(512, data.length)); return b;
}
let pxLast = 0;
function sendPixels(buf) {
  const pm = state.comp.pixelMap; if (!pm.enabled) return;
  if (Date.now() - pxLast < 1000 / Math.max(1, Math.min(60, pm.fps || 40)) - 2) return; pxLast = Date.now();
  const unis = new Map(); const uni = u => { if (!unis.has(u)) unis.set(u, Buffer.alloc(512)); return unis.get(u); };
  let o = 2; const n = buf[1];
  for (let f = 0; f < n && o + 2 <= buf.length; f++) {
    const len = buf.readUInt16BE(o); o += 2; const px = buf.subarray(o, o + len); o += len;
    const fx = pm.fixtures[f]; if (!fx) continue;
    const order = String(fx.rgb || 'RGB').toUpperCase(); const bpp = order.length; const perUni = Math.floor(512 / bpp) * bpp;
    let u = fx.universe | 0, ch = Math.max(1, fx.channel | 0) - 1;
    for (let i = 0; i + 2 < px.length; i += 3) {
      if (ch + bpp > perUni) { u++; ch = 0; }
      const d = uni(u); const r = px[i], g = px[i + 1], b = px[i + 2];
      for (let k = 0; k < bpp; k++) { const cc = order[k]; d[ch + k] = cc === 'R' ? r : cc === 'G' ? g : cc === 'B' ? b : cc === 'W' ? Math.min(r, g, b) : 0; }
      ch += bpp;
    }
  }
  for (const [u, d] of unis) {
    if (pm.protocol === 'sacn') { const su = Math.max(1, u); const host = pm.host && pm.host !== '255.255.255.255' ? pm.host : `239.255.${(su >> 8) & 255}.${su & 255}`; pxSock.send(sacnPkt(su, d), 5568, host); }
    else pxSock.send(artDmx(u, d), 6454, pm.host || '255.255.255.255');
  }
}

/* ------------------------------------------------------------------ live text feeds (fetched by the server to avoid browser CORS) */
const feedCache = new Map();
function parseCSV(t) { const rows = []; let row = [], f = '', q = false;
  for (let i = 0; i < t.length; i++) { const c = t[i];
    if (q) { if (c === '"') { if (t[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += c; }
    else if (c === '"') q = true; else if (c === ',') { row.push(f); f = ''; } else if (c === '\n') { row.push(f); rows.push(row); row = []; f = ''; } else if (c !== '\r') f += c; }
  if (f || row.length) { row.push(f); rows.push(row); } return rows; }
async function getFeed(u, cell) {
  const key = u + '|' + cell; const c = feedCache.get(key); if (c && Date.now() - c.at < 5000) return c.text;
  const r = await fetch(u, { headers: { 'User-Agent': 'PIXORA' } }); if (!r.ok) throw new Error('feed HTTP ' + r.status);
  let text = (await r.text()).slice(0, 20000);
  const isCsv = /output=csv|\.csv(\?|$)|format=csv/i.test(u) || cell;
  if (isCsv) { const rows = parseCSV(text); const m = /^([A-Z]+)(\d+)$/i.exec(String(cell || '').trim());
    if (m) { let col = 0; for (const ch of m[1].toUpperCase()) col = col * 26 + ch.charCodeAt(0) - 64; text = ((rows[+m[2] - 1] || [])[col - 1] || ''); }
    else text = rows.map(r => r.filter(Boolean).join('  ')).filter(Boolean).join('   •   '); }
  text = text.replace(/\s+/g, ' ').trim(); feedCache.set(key, { at: Date.now(), text }); return text;
}

/* ------------------------------------------------------------------ live monitor (diagnostics page) */
const monitorLog = []; const monRates = {};
function monitor(kind, text) {
  const e = { at: Date.now(), kind, text: String(text).slice(0, 240) }; monitorLog.push(e); if (monitorLog.length > 500) monitorLog.shift();
  for (const c of clients) if (c.wantMonitor) c.send({ t: 'mon', e });
}
const monRate = k => { monRates[k] = (monRates[k] || 0) + 1; };
setInterval(() => { const keys = Object.keys(monRates); if (!keys.length) return; if ([...clients].some(c => c.wantMonitor)) for (const k of keys) monitor('rate', `${k}: ${monRates[k]}/s`); for (const k of keys) delete monRates[k]; }, 1000);

/* ------------------------------------------------------------------ zip writer (store) — used for GDTF export */
const CRC_T = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = b => { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRC_T[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
function makeZip(files) { // [{name, data:Buffer}]
  const locals = [], centrals = []; let off = 0;
  for (const f of files) {
    const name = Buffer.from(f.name), d = f.data, crc = crc32(d);
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0, 6); lh.writeUInt16LE(0, 8);
    lh.writeUInt32LE(0, 10); lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(d.length, 18); lh.writeUInt32LE(d.length, 22); lh.writeUInt16LE(name.length, 26); lh.writeUInt16LE(0, 28);
    const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0, 8); ch.writeUInt16LE(0, 10);
    ch.writeUInt32LE(0, 12); ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(d.length, 20); ch.writeUInt32LE(d.length, 24); ch.writeUInt16LE(name.length, 28);
    ch.writeUInt32LE(off, 42); locals.push(lh, name, d); centrals.push(ch, name); off += 30 + name.length + d.length;
  }
  const cd = Buffer.concat(centrals); const end = Buffer.alloc(22); end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(off, 16); return Buffer.concat([...locals, cd, end]);
}

/* ------------------------------------------------------------------ GDTF export of the DMX personality (for grandMA3 and other consoles) */
function gdtfFile(nLayers) {
  const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
  const uuid = () => { const h = crypto.createHash('md5').update('PIXORA-GDTF-fixture-type-v1').digest('hex').toUpperCase(); return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`; };
  const attrs = [['Dimmer', 'Dim', 'Dimmer.Dimmer'], ['Pixora_Crossfader', 'XFade', 'Control.Control'], ['Pixora_Column', 'Column', 'Control.Control'], ['PlaySpeed', 'Speed', 'Video.Video'],
    ['MediaContent1', 'Clip', 'Video.Video'], ['HSB_Hue', 'Hue', 'Color.HSB'], ['Shutter1', 'Strobe', 'Beam.Beam'], ['VideoEffect1Parameter1', 'Pixelate', 'Video.Video']];
  const fg = [['Dimmer', ['Dimmer']], ['Control', ['Control']], ['Video', ['Video']], ['Color', ['HSB']], ['Beam', ['Beam']]];
  // GDTF 1.1+: Default lives on ChannelFunction; DMXChannel carries InitialFunction = "<Geometry>_<Attribute>.<Attribute>.<ChannelFunction>"
  const chan = (geom, off, attr, name) => `<DMXChannel DMXBreak="1" Offset="${off}" InitialFunction="${geom}_${attr}.${attr}.${esc(name)}" Highlight="None" Geometry="${geom}"><LogicalChannel Attribute="${attr}" Snap="No" Master="None" MibFade="0" DMXChangeTimeLimit="0"><ChannelFunction Name="${esc(name)}" Attribute="${attr}" OriginalAttribute="" DMXFrom="0/1" Default="0/1" PhysicalFrom="0" PhysicalTo="1" RealFade="0" RealAcceleration="0"/></LogicalChannel></DMXChannel>`;
  const mode = n => { let ch = chan('Base', 1, 'Dimmer', 'Master') + chan('Base', 2, 'Pixora_Crossfader', 'Crossfader') + chan('Base', 3, 'Pixora_Column', 'Column trigger') + chan('Base', 4, 'PlaySpeed', 'Global speed');
    for (let i = 0; i < n; i++) { const g = 'Layer' + (i + 1), o = 5 + i * 6;
      ch += chan(g, o, 'Dimmer', 'Opacity') + chan(g, o + 1, 'MediaContent1', 'Clip select') + chan(g, o + 2, 'PlaySpeed', 'Speed') + chan(g, o + 3, 'HSB_Hue', 'Hue') + chan(g, o + 4, 'Shutter1', 'Strobe') + chan(g, o + 5, 'VideoEffect1Parameter1', 'Pixelate'); }
    return `<DMXMode Name="${n} Layers" Geometry="Base"><DMXChannels>${ch}</DMXChannels><Relations/><FTMacros/></DMXMode>`; };
  const modes = [...new Set([nLayers, 4, 8])].sort((a, b) => a - b);
  const geoms = Array.from({ length: Math.max(...modes) }, (_, i) => `<Geometry Name="Layer${i + 1}" Model="Layer" Position="{1,0,0,0}{0,1,0,0}{0,0,1,0}{0,0,0,1}"/>`).join('');
  const xml = `<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<GDTF DataVersion="1.1"><FixtureType Name="PIXORA" ShortName="PIXORA" LongName="PIXORA Media Server" Manufacturer="Booth Productions" Description="PIXORA media server DMX personality: 4 master channels + 6 per layer" FixtureTypeID="${uuid()}" Thumbnail="" RefFT="">
<AttributeDefinitions><ActivationGroups/><FeatureGroups>${fg.map(([g, fs]) => `<FeatureGroup Name="${g}" Pretty="${g}">${fs.map(f => `<Feature Name="${f}"/>`).join('')}</FeatureGroup>`).join('')}</FeatureGroups>
<Attributes>${attrs.map(([n, p, f]) => `<Attribute Name="${n}" Pretty="${p}" Feature="${f}" PhysicalUnit="None"/>`).join('')}</Attributes></AttributeDefinitions>
<Wheels/><PhysicalDescriptions/><Models><Model Name="Base" Length="0.4" Width="0.4" Height="0.1" PrimitiveType="Cube"/><Model Name="Layer" Length="0.1" Width="0.1" Height="0.02" PrimitiveType="Cube"/></Models>
<Geometries><Geometry Name="Base" Model="Base" Position="{1,0,0,0}{0,1,0,0}{0,0,1,0}{0,0,0,1}">${geoms}</Geometry></Geometries>
<DMXModes>${modes.map(mode).join('')}</DMXModes><Revisions><Revision Text="Generated by PIXORA" UserID="0" Date="${new Date().toISOString().slice(0, 19)}"/></Revisions><FTPresets/><Protocols/></FixtureType></GDTF>`;
  return makeZip([{ name: 'description.xml', data: Buffer.from(xml) }]);
}

/* ------------------------------------------------------------------ data feeds: generic inputs any app can feed (poll JSON/CSV/text, HTTP push, OSC) */
const FEEDVAL_FILE = path.join(DATA, 'feed-values.json');
const feedValues = readJSON(FEEDVAL_FILE, {}), feedStatus = {};
const saveFeedValues = writeJSONSoon(FEEDVAL_FILE, () => feedValues, 1500); const feedTimers = new Map(); let feedSig = '';
const getByPath = (o, p) => String(p || '').split('.').filter(Boolean).reduce((a, k) => a == null ? undefined : a[k], o);
const colName = i => { let s = ''; i++; while (i > 0) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; };
function csvToObj(t) {
  const rows = parseCSV(t); const v = { rows };
  rows.forEach((r, ri) => r.forEach((c, ci) => { v[colName(ci) + (ri + 1)] = c; }));
  if (rows.length > 1) { const hdr = rows[0]; v.records = rows.slice(1).map(r => Object.fromEntries(hdr.map((h, i) => [h, r[i]]))); v.first = v.records[0] || {}; }
  return v;
}
async function pollFeed(f) {
  try {
    const r = await fetch(f.url, { headers: { 'User-Agent': 'PIXORA' }, signal: AbortSignal.timeout(8000) }); if (!r.ok) throw new Error('HTTP ' + r.status);
    const t = await r.text(); const ct = r.headers.get('content-type') || '';
    const v = f.type === 'csv' || (f.type !== 'json' && /csv/.test(ct)) ? csvToObj(t) : f.type === 'text' ? { text: t.trim() } : JSON.parse(t);
    setFeed(f.id, v, 'poll');
  } catch (e) { feedStatus[f.id] = { err: e.message, at: Date.now() }; broadcastFeedsSoon(); }
}
let feedsT = null;
function broadcastFeedsSoon() { if (feedsT) return; feedsT = setTimeout(() => { feedsT = null; broadcast({ t: 'feeds', values: feedValues, status: feedStatus }); oscOutSync(); }, 200); }
function setFeed(id, v, src) {
  const prev = feedValues[id]; feedValues[id] = v; feedStatus[id] = { at: Date.now(), src }; saveFeedValues();
  monitor('feed', `${id} ← ${src}: ${JSON.stringify(v).slice(0, 120)}`); broadcastFeedsSoon(); runRules(id, prev, v);
}
function scheduleFeeds() {
  const sig = JSON.stringify((state.feeds || []).map(f => [f.id, f.url, f.type, f.interval, f.on])); if (sig === feedSig) return; feedSig = sig;
  for (const t of feedTimers.values()) clearInterval(t); feedTimers.clear();
  for (const f of state.feeds || []) if (f.on !== false && f.type !== 'push' && f.url) { pollFeed(f); feedTimers.set(f.id, setInterval(() => pollFeed(f), Math.max(1, +f.interval || 5) * 1000)); }
}
setInterval(scheduleFeeds, 2000);
// rules: when a feed value changes / crosses a threshold, run an action
const ruleLast = {};
function runRules(feedId, prev, cur) {
  for (const r of state.rules || []) {
    if (r.on === false || r.feed !== feedId) continue;
    const a = getByPath(prev, r.path), b = getByPath(cur, r.path); let fire = false;
    if (r.when === 'change') fire = prev !== undefined && JSON.stringify(a) !== JSON.stringify(b);
    else if (r.when === 'equals') fire = String(b) === String(r.value) && String(a) !== String(r.value);
    else if (r.when === 'above') fire = +b > +r.value && !(+a > +r.value);
    else if (r.when === 'below') fire = +b < +r.value && !(+a < +r.value);
    else if (r.when === 'increase') fire = prev !== undefined && +b > +a;
    if (!fire || Date.now() - (ruleLast[r.id] || 0) < (+r.cooldown || 0) * 1000) continue;
    ruleLast[r.id] = Date.now(); monitor('rule', `${r.name || r.id}: ${r.path} ${a} → ${b}`);
    try { applyCmd(S.actionToCmd(r.action), 'rule'); } catch (e) { monitor('rule', 'error ' + e.message); }
  }
}

/* ------------------------------------------------------------------ scheduler (time-of-day / weekday) */
const schedFired = {};
setInterval(() => {
  const d = new Date(); const hm = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); const day = d.getDay(); const key = d.toDateString() + hm;
  for (const e of state.schedule || []) {
    if (e.on === false || e.time !== hm || !(e.days || []).includes(day) || schedFired[e.id] === key) continue;
    schedFired[e.id] = key; monitor('schedule', `${e.name || e.id} @ ${hm}`);
    try { applyCmd(S.actionToCmd(e.action), 'schedule'); } catch (er) { monitor('schedule', 'error ' + er.message); }
  }
}, 5000);

/* ------------------------------------------------------------------ sponsor / ad rotation with proof-of-play log */
const POP_FILE = path.join(DATA, 'proof-of-play.csv');
if (!fs.existsSync(POP_FILE)) fs.writeFileSync(POP_FILE, 'start,end,sponsor,item,planned_s,played_s,layer,outputs\n');
const rot = { playing: null, last: {}, idx: -1 };
function rotInWindow(it) { if (!it.from && !it.to) return true; const d = new Date(); const m = d.getHours() * 60 + d.getMinutes(); const p = s => { const [h, mi] = String(s || '').split(':').map(Number); return isFinite(h) ? h * 60 + (mi || 0) : null; };
  const a = p(it.from) ?? 0, b = p(it.to) ?? 1440; return a <= b ? m >= a && m < b : m >= a || m < b; }
function rotStop(reason) {
  const pl = rot.playing; if (!pl) return; rot.playing = null; const l = state.layers.find(x => x.id === pl.layerId);
  if (l) { l.activeClip = pl.prev.activeClip; l.active = pl.prev.active; l.trig++; l.trigAt = Date.now(); l.rotating = ''; }
  const csv = v => '"' + String(v ?? '').replace(/"/g, '""') + '"';
  fs.appendFile(POP_FILE, [new Date(pl.start).toISOString(), new Date().toISOString(), csv(pl.item.sponsor), csv(pl.item.name), pl.item.dur, ((Date.now() - pl.start) / 1000).toFixed(1), csv(pl.layerName), outputsInfo().length].join(',') + '\n', () => {});
  monitor('sponsor', `ended ${pl.item.name} (${reason})`); markDirty();
}
function rotPlay(it) {
  const r = state.rotation; const l = state.layers[r.layer | 0]; if (!l || !it.clip) return;
  rot.playing = { item: it, start: Date.now(), layerId: l.id, layerName: l.name, prev: { active: l.active, activeClip: l.activeClip } };
  l.activeClip = Object.assign(S.clipDefaults(), JSON.parse(JSON.stringify(it.clip))); l.active = l.active ?? 0; l.trig++; l.trigAt = Date.now(); l.paused = false; l.rotating = it.name;
  rot.last[it.id] = Date.now(); monitor('sponsor', `playing ${it.name} for ${it.dur}s on ${l.name}`); markDirty();
}
setInterval(() => {
  const r = state.rotation; if (!r) return;
  if (!r.enabled) { if (rot.playing) rotStop('disabled'); return; }
  if (rot.playing) { if (Date.now() - rot.playing.start >= (+rot.playing.item.dur || 10) * 1000) rotStop('done'); else return; }
  const items = (r.items || []).filter(it => it.on !== false && it.clip && rotInWindow(it)); if (!items.length) return;
  if (r.mode === 'loop') { rot.idx = (rot.idx + 1) % items.length; rotPlay(items[rot.idx]); return; }
  const due = items.filter(it => Date.now() - (rot.last[it.id] || 0) >= Math.max(0.1, +it.every || 10) * 60000).sort((a, b) => (rot.last[a.id] || 0) - (rot.last[b.id] || 0));
  if (due.length) rotPlay(due[0]);
}, 500);
function popRows(from, to) {
  const lines = fs.readFileSync(POP_FILE, 'utf8').trim().split('\n'); const hdr = lines.shift();
  const rows = lines.map(l => parseCSV(l)[0]).filter(r => r && (!from || r[0] >= from) && (!to || r[0].slice(0, 10) <= to));
  return { hdr, rows };
}

/* ------------------------------------------------------------------ timeline: playhead, clip triggers (automation lanes are applied by the renderers) */
const tlLast = {};
function tlPos() { const p = state.timeline.play; return p.playing ? p.pos + (Date.now() - p.startAt) / 1000 : p.pos; }
setInterval(() => {
  const tl = state.timeline; if (!tl) return; const p = tl.play;
  if (tl.followTc && state.comp.timecode.source !== 'off' && tc.last >= 0) { // chase timecode
    const pos = tc.frames / (state.comp.timecode.fps || 25) - (+tl.tcStart || 0);
    if (!p.playing || Math.abs(tlPos() - pos) > 0.25) { tl.play = { playing: true, pos, startAt: Date.now() }; markDirty(); }
  }
  if (!tl.play.playing) return;
  let pos = tlPos();
  if (pos >= tl.duration) { if (tl.loop) { tl.play = { playing: true, pos: 0, startAt: Date.now() }; pos = 0; for (const k in tlLast) delete tlLast[k]; } else { tl.play = { playing: false, pos: tl.duration, startAt: 0 }; markDirty(); return; } }
  let dirty = false;
  for (const tr of tl.tracks) {
    const li = state.layers.findIndex(l => l.id === tr.layerId); if (li < 0 || tr.mute) continue;
    const it = tr.items.find(x => pos >= x.start && pos < x.start + x.dur);
    const key = it ? it.id : null;
    if (key !== (tlLast[tr.id] ?? null)) {
      tlLast[tr.id] = key;
      if (it) { if (state.layers[li].clips[it.slot]) { trigger(li, it.slot); dirty = true; } }
      else if (tr.clearGaps !== false) { state.layers[li].active = null; dirty = true; }
    }
  }
  if (dirty) markDirty();
}, 30);

/* ------------------------------------------------------------------ clip automation recording (record live moves, replay with the clip) */
let autoRec = null; // {layerId, slot, start, data:{relPath:[[t,v]]}}
function autoRecord(pth, value) {
  if (!autoRec) return; const li = state.layers.findIndex(l => l.id === autoRec.layerId); if (li < 0) return;
  const pre = `layers.${li}.`; if (!pth.startsWith(pre) || pth.includes('.clips.') || typeof value !== 'number') return;
  const rel = pth.slice(pre.length); const t = (Date.now() - autoRec.start) / 1000;
  (autoRec.data[rel] = autoRec.data[rel] || []).push([+t.toFixed(3), value]);
}

/* ------------------------------------------------------------------ team: operator names, presence, layer locks */
function presenceList() { return [...clients].filter(c => c.role !== 'output' && c.role !== 'mirror').map(c => ({ id: c.id, name: c.name || (c.role === 'remote' ? 'Phone remote' : 'Controller'), color: c.color || '#9b3bff', role: c.role, sel: c.sel || null, tab: c.tab || '', viewer: !!c.viewer, rtt: c.rtt || null })); }
let presT = null; function pushPresence() { if (presT) return; presT = setTimeout(() => { presT = null; broadcast({ t: 'presence', list: presenceList() }); }, 150); }
function cmdLayerIndex(cmd) {
  if (cmd.layer != null) return cmd.layer;
  const ps = cmd.op === 'set' ? [cmd.path] : cmd.op === 'setMany' ? Object.keys(cmd.values || {}) : []; for (const p of ps) { const m = /^layers\.(\d+)\./.exec(p || ''); if (m) return +m[1]; }
  if (cmd.op === 'moveClip') return cmd.to && cmd.to[0]; return null;
}
function checkLock(cmd, from) {
  if (!from || typeof from !== 'object' || !from.role) return; const li = cmdLayerIndex(cmd); if (li == null) return;
  const l = state.layers[li]; if (l && l.lockedBy && l.lockedBy !== (from.name || '') && cmd.op !== 'lockLayer') throw new Error(`${l.name} is locked by ${l.lockedBy}`);
}

/* ------------------------------------------------------------------ OSC output (feedback to consoles, Companion, other apps) */
const oscOutSock = dgram.createSocket('udp4'); oscOutSock.on('error', () => {}); oscOutSock.bind(() => { try { oscOutSock.setBroadcast(true); } catch {} });
function oscPad(b) { const n = Math.ceil((b.length + 1) / 4) * 4; const o = Buffer.alloc(n); b.copy(o); return o; }
function oscMsg(addr, args) {
  const parts = [oscPad(Buffer.from(addr))]; let tags = ','; const data = [];
  for (const a of args) { if (typeof a === 'string') { tags += 's'; data.push(oscPad(Buffer.from(a))); } else if (Number.isInteger(a)) { tags += 'i'; const b = Buffer.alloc(4); b.writeInt32BE(a); data.push(b); } else { tags += 'f'; const b = Buffer.alloc(4); b.writeFloatBE(+a || 0); data.push(b); } }
  return Buffer.concat([...parts, oscPad(Buffer.from(tags)), ...data]);
}
const oscOutLast = new Map();
function oscOutSync() {
  const o = state.oscOut; if (!o || !o.enabled || !(o.targets || []).length) return;
  const vals = { '/pixora/master': state.comp.master, '/pixora/blackout': state.comp.blackout ? 1 : 0, '/pixora/bpm': state.comp.bpm, '/pixora/test': state.led.test.on ? 1 : 0,
    '/pixora/cue/index': state.cueIndex + 1, '/pixora/cue/name': (state.cues[state.cueIndex] || {}).name || '', '/pixora/deck': (state.decks[state.comp.deck] || {}).name || '',
    '/pixora/timeline/playing': state.timeline.play.playing ? 1 : 0, '/pixora/sponsor': rot.playing ? rot.playing.item.name : '' };
  state.layers.forEach((l, i) => { const c = l.active != null ? (l.activeClip || l.clips[l.active]) : null; vals[`/pixora/layer/${i + 1}/opacity`] = l.opacity; vals[`/pixora/layer/${i + 1}/clip`] = c ? (c.name || c.src || c.type) : ''; vals[`/pixora/layer/${i + 1}/active`] = l.active == null ? 0 : l.active + 1; });
  for (const [k, v] of Object.entries(vals)) {
    const sv = typeof v === 'number' ? +v.toFixed(3) : v; if (oscOutLast.get(k) === sv) continue; oscOutLast.set(k, sv);
    const msg = oscMsg(k, [typeof v === 'number' && !Number.isInteger(v) ? v : v]);
    for (const t of o.targets) if (t.on !== false && t.host && t.port) oscOutSock.send(msg, +t.port, t.host);
  }
}
setInterval(() => { oscOutLast.clear(); oscOutSync(); }, 10000); // periodic full refresh

/* ------------------------------------------------------------------ backup / failover (this server mirrors a primary PIXORA) */
const mirror = { ws: null, connected: false, lastSeen: 0, active: false, retry: null };
function mirrorConnect() {
  clearTimeout(mirror.retry);
  const b = settings.backup || {}; if (b.mode !== 'backup' || !b.primary) { if (mirror.ws) { try { mirror.ws.close(); } catch {} mirror.ws = null; } mirror.connected = false; mirror.active = false; return; }
  const url = b.primary.replace(/^http/, 'ws').replace(/\/$/, '') + '/ws?role=mirror' + (b.pin ? '&pin=' + encodeURIComponent(b.pin) : '');
  let ws; try { ws = new WebSocket(url); } catch (e) { mirror.retry = setTimeout(mirrorConnect, 3000); return; }
  mirror.ws = ws;
  ws.onopen = () => { mirror.connected = true; mirror.lastSeen = Date.now(); if (mirror.active) monitor('backup', 'primary is back — mirroring again'); mirror.active = false; broadcast({ t: 'backup', status: backupStatus() }); };
  ws.onmessage = ev => { mirror.lastSeen = Date.now(); if (typeof ev.data !== 'string') return; let m; try { m = JSON.parse(ev.data); } catch { return; }
    if (m.t === 'state' && !mirror.active) { state = normalizeState(m.state); markDirty(); }
    if (m.t === 'tpong') { const n = Date.now(), rtt = n - m.c; if (rtt < 500) { const off = m.s + rtt / 2 - n; mirror.off = mirror.off == null ? off : mirror.off * 0.8 + off * 0.2; pro3.setMasterOffset(mirror.off); } } };
  clearInterval(mirror.ping); mirror.ping = setInterval(() => { try { if (ws.readyState === 1) ws.send(JSON.stringify({ t: 'tping', c: Date.now() })); } catch {} }, 2000);
  ws.onclose = ws.onerror = () => { if (mirror.ws !== ws) return; mirror.connected = false; mirror.ws = null; broadcast({ t: 'backup', status: backupStatus() }); mirror.retry = setTimeout(mirrorConnect, 2000); };
}
setInterval(() => { // failover watchdog
  const b = settings.backup || {}; if (b.mode !== 'backup') return;
  if (!mirror.connected && !mirror.active && Date.now() - mirror.lastSeen > (+b.failoverSec || 3) * 1000 && mirror.lastSeen) { mirror.active = true; monitor('backup', 'PRIMARY LOST — backup has taken over'); broadcast({ t: 'backup', status: backupStatus() }); }
}, 500);
function backupStatus() { const b = settings.backup || {}; return { mode: b.mode || 'off', primary: b.primary || '', connected: mirror.connected, active: mirror.active, lastSeen: mirror.lastSeen,
  mirrors: [...clients].filter(c => c.role === 'mirror').map(c => ({ id: c.id, addr: c.addr })) }; }

/* ------------------------------------------------------------------ health */
const health = { outputs: {}, bench: {} };
// CPU temperature: Linux reads sysfs directly; Windows/macOS are sampled in the background (never blocks a request)
let tempCache = { c: null, src: null, at: 0 };
function cpuTemp() {
  if (process.platform === 'linux') {
    try { let max = null; for (const z of fs.readdirSync('/sys/class/thermal')) { if (!z.startsWith('thermal_zone')) continue; const v = +fs.readFileSync(`/sys/class/thermal/${z}/temp`, 'utf8') / 1000; if (v > 0 && (max == null || v > max)) max = v; } if (max != null) return max; } catch {}
    try { for (const h of fs.readdirSync('/sys/class/hwmon')) { const v = +fs.readFileSync(`/sys/class/hwmon/${h}/temp1_input`, 'utf8') / 1000; if (v > 0) return v; } } catch {}
    return null;
  }
  return tempCache.c;
}
function runQuiet(cmd, args, ms = 8000) {
  return new Promise(res => { try { execFile(cmd, args, { timeout: ms, windowsHide: true }, (e, out) => res(e ? '' : String(out))); } catch { res(''); } });
}
async function sampleTemp() {
  let c = null, src = null;
  if (process.platform === 'win32') {
    // 1) performance counter (no admin needed; tenths of Kelvin) 2) ACPI WMI (often needs admin)
    const ps = ['-NoProfile', '-NonInteractive', '-Command'];
    let out = await runQuiet('powershell.exe', [...ps, '(Get-CimInstance Win32_PerfFormattedData_Counters_ThermalZoneInformation -ErrorAction SilentlyContinue | Measure-Object -Property HighPrecisionTemperature -Maximum).Maximum']);
    let v = parseFloat(out); if (v > 0) { c = v / 10 - 273.15; src = 'thermal-zone counter'; }
    if (c == null) { out = await runQuiet('powershell.exe', [...ps, '(Get-CimInstance -Namespace root/wmi -ClassName MSAcpi_ThermalZoneTemperature -ErrorAction SilentlyContinue | Measure-Object -Property CurrentTemperature -Maximum).Maximum']); v = parseFloat(out); if (v > 0) { c = v / 10 - 273.15; src = 'ACPI'; } }
  } else if (process.platform === 'darwin') {
    // Apple doesn't expose die temperature without root; report thermal pressure from pmset instead, plus an
    // optional reading if the user installed the free osx-cpu-temp / istats tools.
    let out = await runQuiet('osx-cpu-temp', []); let v = parseFloat(out);
    if (v > 0) { c = v; src = 'osx-cpu-temp'; }
    const th = await runQuiet('pmset', ['-g', 'therm']); const lvl = /CPU_Speed_Limit\s*=\s*(\d+)/.exec(th);
    tempCache.throttle = lvl ? 100 - +lvl[1] : null;
    const pr = await runQuiet('sysctl', ['-n', 'kern.thermalpressure'], 3000).catch(() => ''); if (pr.trim()) tempCache.pressure = pr.trim();
  }
  if (c != null && !(c > 5 && c < 150)) c = null; // discard nonsense (some ACPI zones report fixed values)
  tempCache = { ...tempCache, c: c == null ? null : Math.round(c * 10) / 10, src, at: Date.now() };
}
if (process.platform === 'win32' || process.platform === 'darwin') { setTimeout(sampleTemp, 3000).unref?.(); setInterval(sampleTemp, 15000).unref?.(); }
let cpuPrev = os.cpus().map(c => c.times);
function cpuLoad() { const now = os.cpus().map(c => c.times); let idle = 0, tot = 0; now.forEach((t, i) => { const p = cpuPrev[i] || t; const d = k => t[k] - p[k]; const all = d('user') + d('nice') + d('sys') + d('idle') + d('irq'); idle += d('idle'); tot += all; }); cpuPrev = now; return tot ? 1 - idle / tot : 0; }
async function benchSource(src) {
  const r = await scanSource(src, false); const big = r.items.filter(i => i.kind === 'video').sort((a, b) => b.size - a.size)[0]; if (!big) return null;
  const abs = resolveMedia(big.src); const fh = await fsp.open(abs, 'r'); const buf = Buffer.alloc(4 * 1024 * 1024); let read = 0; const t0 = process.hrtime.bigint();
  try { const max = Math.min(big.size, 128 * 1024 * 1024); let pos = Math.max(0, Math.floor(big.size / 3) - max / 2); while (read < max) { const { bytesRead } = await fh.read(buf, 0, buf.length, pos + read); if (!bytesRead) break; read += bytesRead; } } finally { await fh.close(); }
  const s = Number(process.hrtime.bigint() - t0) / 1e9; return { mbps: read / 1048576 / Math.max(s, 1e-3), file: big.name, at: Date.now(), note: 'May include OS cache — for a cold-read test, run after reconnecting the drive' };
}
setInterval(() => { for (const c of clients) if (c.role !== 'output') c.send({ t: 'hping', at: Date.now() }); }, 5000);

/* ------------------------------------------------------------------ audio-reactive scenes (beats/drops reported by the primary output) */
const react = { beats: [], count: 0 };
function onBeat(m) {
  const r = state.react; if (!r || !r.enabled) return; const now = Date.now(); react.count++; monRate('beats');
  react.beats.push(now); react.beats = react.beats.filter(t => now - t < 12000);
  if (r.autoBpm && react.beats.length >= 8) {
    const iv = react.beats.slice(1).map((t, i) => t - react.beats[i]).filter(x => x > 250 && x < 1500).sort((a, b) => a - b);
    if (iv.length >= 6) { const med = iv[Math.floor(iv.length / 2)]; const dev = iv.reduce((a, x) => a + Math.abs(x - med), 0) / iv.length / med;
      if (dev < 0.08) { const bpm = Math.round(60000 / med * 10) / 10; if (Math.abs(bpm - state.comp.bpm) > 0.5) { state.comp.bpm = bpm; state.comp.beatEpoch = now; markDirty(); monitor('react', `auto BPM ${bpm}`); } } }
  }
  const every = Math.max(1, r.everyBeats | 0);
  if (r.onBeat !== 'off' && react.count % every === 0) {
    const li = r.layer | 0;
    if (r.onBeat === 'next-clip' && state.layers[li]) applyCmdInner({ op: 'next', layer: li });
    else if (r.onBeat === 'random-clip' && state.layers[li]) applyCmdInner({ op: 'next', layer: li, random: true });
    else if (r.onBeat === 'next-column') { const cols = [...new Set(state.layers.flatMap(l => l.clips.map((c, i) => c ? i : -1)).filter(i => i >= 0))].sort((a, b) => a - b);
      if (cols.length) { const cur = Math.max(...state.layers.map(l => l.active ?? -1)); applyCmdInner({ op: 'column', col: cols.find(c => c > cur) ?? cols[0] }); } }
    markDirty();
  }
}
function onDrop() {
  const r = state.react; if (!r || !r.enabled || r.onDrop === 'off') return; monitor('react', 'DROP detected');
  if (r.onDrop === 'cue-go') applyCmdInner({ op: 'cueGo' });
  else if (r.onDrop === 'next-column' || r.onDrop === 'random-column') { const cols = [...new Set(state.layers.flatMap(l => l.clips.map((c, i) => c ? i : -1)).filter(i => i >= 0))];
    if (cols.length) { const cur = Math.max(...state.layers.map(l => l.active ?? -1)); applyCmdInner({ op: 'column', col: r.onDrop === 'random-column' ? cols[Math.floor(Math.random() * cols.length)] : (cols.sort((a, b) => a - b).find(c => c > cur) ?? cols[0]) }); } }
  else if (r.onDrop === 'flash') { state.comp.fx.strobe.on = true; setTimeout(() => { state.comp.fx.strobe.on = false; markDirty(); }, 60000 / state.comp.bpm * 8); }
  markDirty();
}

/* ------------------------------------------------------------------ output recording (MediaRecorder in the primary output, saved into the Local Library) */
const rec = require('./server-rec.js')({ DATA, LOCAL_MEDIA, FFMPEG, ffmpegOk: () => ffmpegOk, settings, saveSettings, broadcast: (o, r) => broadcast(o, r), monitor: (...a) => monitor(...a),
  output: () => primaryOutput, addJob: j => addJob(j),
  saved: () => { for (const k of [...scanCache.keys()]) scanCache.delete(k); broadcast({ t: 'library' }); } });

/* ------------------------------------------------------------------ OSC input (UDP) */
function oscStr(b, o) { let e = o; while (e < b.length && b[e] !== 0) e++; return [b.toString('utf8', o, e), (e + 4) & ~3]; }
function oscParse(b, out) {
  let [addr, o] = oscStr(b, 0);
  if (addr === '#bundle') { o = 16; while (o + 4 <= b.length) { const n = b.readInt32BE(o); o += 4; oscParse(b.subarray(o, o + n), out); o += n; } return; }
  let tags = ''; if (o < b.length && b[o] === 44) [tags, o] = oscStr(b, o);
  const args = [];
  for (const t of tags.slice(1)) {
    if (t === 'i') { args.push(b.readInt32BE(o)); o += 4; } else if (t === 'f') { args.push(b.readFloatBE(o)); o += 4; }
    else if (t === 's') { let s; [s, o] = oscStr(b, o); args.push(s); } else if (t === 'd') { args.push(b.readDoubleBE(o)); o += 8; }
    else if (t === 'T') args.push(1); else if (t === 'F') args.push(0); else if (t === 'h') { args.push(Number(b.readBigInt64BE(o))); o += 8; }
  }
  out.push({ addr, args });
}
function handleOsc({ addr, args }) {
  const a = args[0], on = a === undefined || +a > 0; let m;
  monitor('osc', addr + ' ' + args.map(x => JSON.stringify(x)).join(' '));
  if (rec.osc(addr, args)) return;
  if ((m = addr.match(/^\/pixora\/data\/([\w-]+)\/(.+)$/))) { const v = Object.assign({}, feedValues[m[1]] || {}); v[m[2].replace(/\//g, '.')] = a; if (!state.feeds.find(f => f.id === m[1])) { state.feeds.push({ id: m[1], name: m[1], type: 'push', url: '', interval: 5, on: true }); markDirty(); } setFeed(m[1], v, 'osc'); return; }
  if ((m = addr.match(/^\/pixora\/feed\/([\w-]+)$/))) { try { setFeed(m[1], JSON.parse(String(a)), 'osc'); } catch {} return; }
  if (addr.startsWith('/pixora/')) addr = '/bvj/' + addr.slice(8);
  const parts = addr.split('/').filter(Boolean);
  try {
    if ((m = addr.match(/^\/composition\/layers\/(\d+)\/clips\/(\d+)\/connect$/))) { if (on) applyCmd({ op: 'trigger', layer: m[1] - 1, clip: m[2] - 1 }); }
    else if ((m = addr.match(/^\/composition\/columns\/(\d+)\/connect$/))) { if (on) applyCmd({ op: 'column', col: m[1] - 1 }); }
    else if ((m = addr.match(/^\/composition\/layers\/(\d+)\/(clear|disconnect)$/))) { if (on) applyCmd({ op: 'clearLayer', layer: m[1] - 1 }); }
    else if ((m = addr.match(/^\/composition\/layers\/(\d+)\/(video\/opacity|master)$/))) applyCmd({ op: 'set', path: `layers.${m[1] - 1}.opacity`, value: clamp01(a) });
    else if ((m = addr.match(/^\/composition\/layers\/(\d+)\/bypassed$/))) applyCmd({ op: 'set', path: `layers.${m[1] - 1}.bypass`, value: on });
    else if ((m = addr.match(/^\/composition\/layers\/(\d+)\/solo$/))) applyCmd({ op: 'set', path: `layers.${m[1] - 1}.solo`, value: on });
    else if (addr === '/composition/master' || addr === '/composition/video/opacity') applyCmd({ op: 'set', path: 'comp.master', value: clamp01(a) });
    else if (addr === '/composition/speed') applyCmd({ op: 'set', path: 'comp.speed', value: Math.max(0, +a * (+a <= 1 ? 2 : 1)) });
    else if (addr === '/composition/crossfader/phase' || addr === '/composition/crossfader') applyCmd({ op: 'set', path: 'comp.crossfader', value: clamp01(a) });
    else if (addr === '/composition/disconnectall') { if (on) applyCmd({ op: 'clearAll' }); }
    else if (addr === '/composition/tempocontroller/tempo') applyCmd({ op: 'bpm', bpm: +a <= 1 ? 20 + a * 480 : +a });
    else if (addr === '/composition/tempocontroller/tempotap') { if (on) oscTap(); }
    else if (addr === '/composition/tempocontroller/resync') { if (on) applyCmd({ op: 'resync' }); }
    else if (parts[0] === 'bvj') {
      if (parts[1] === 'blackout') applyCmd({ op: 'blackout', on: a === undefined ? undefined : on });
      else if (parts[1] === 'test') { if (parts[2]) applyCmd({ op: 'setMany', values: { 'led.test.mode': parts[2], 'led.test.on': true } }); else applyCmd({ op: 'set', path: 'led.test.on', value: a === undefined ? !state.led.test.on : on }); }
      else if (parts[1] === 'set') applyCmd({ op: 'set', path: args[0], value: args[1] });
      else if (parts[1] === 'next' && on) applyCmd({ op: 'next', layer: (+parts[2] || 1) - 1 });
      else if (parts[1] === 'cue' && on) { if (parts[2] === 'go') applyCmd({ op: 'cueGo' }); else if (parts[2] === 'back') applyCmd({ op: 'cueBack' }); else if (+parts[2]) applyCmd({ op: 'cueGo', index: +parts[2] - 1 }); }
      else if (parts[1] === 'deck' && on && +parts[2]) applyCmd({ op: 'deckSwitch', deck: +parts[2] - 1 });
      else if (parts[1] === 'undo' && on) applyCmd({ op: 'undo' });
      else if (parts[1] === 'prev' && on) applyCmd({ op: 'prev', layer: (+parts[2] || 1) - 1 });
      else if (parts[1] === 'fx' && parts.length >= 5) { // /bvj/fx/<layer|comp>/<fx>/<param> value
        const tgt = parts[2] === 'comp' ? 'comp' : 'layers.' + (parts[2] - 1);
        applyCmd({ op: 'set', path: `${tgt}.fx.${parts[3]}.${parts[4]}`, value: parts[4] === 'on' ? on : +a });
      }
    }
  } catch (e) { /* ignore bad OSC */ }
}
const clamp01 = v => Math.max(0, Math.min(1, +v || 0));
let taps = [];
function oscTap() { const now = Date.now(); taps = taps.filter(t => now - t < 2500); taps.push(now); if (taps.length >= 2) { const iv = (taps[taps.length - 1] - taps[0]) / (taps.length - 1); applyCmd({ op: 'bpm', bpm: Math.round(60000 / iv * 10) / 10, resync: true }); } }
try {
  const osc = dgram.createSocket('udp4');
  osc.on('message', msg => { const out = []; try { oscParse(msg, out); } catch {} out.forEach(handleOsc); });
  osc.on('error', e => console.warn('OSC disabled:', e.message));
  osc.bind(OSC_PORT, () => console.log(`OSC input listening on udp ${OSC_PORT}`));
} catch (e) { console.warn('OSC disabled', e.message); }

/* ------------------------------------------------------------------ HTTP */
function parseCookies(h) { const o = {}; (h || '').split(';').forEach(p => { const i = p.indexOf('='); if (i > 0) o[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); }); return o; }
function authRole(req, url) {
  const ur = pro3.authRole(req, url); if (ur !== undefined) return ur;
  if (!PIN) return 'op';
  const v = req.headers['x-pin'] || url.searchParams.get('pin') || parseCookies(req.headers.cookie).bvjpin;
  if (v === PIN) return 'op'; if (VIEW_PIN && v === VIEW_PIN) return 'view'; return null;
}
const authed = (req, url) => !!authRole(req, url);
function send(res, code, body, type = 'application/json') {
  const b = typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body);
  res.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store', 'Access-Control-Allow-Origin': '*' }); res.end(b);
}
function readBody(req, limit = 4 * 1024 * 1024) {
  return new Promise((ok, bad) => { const ch = []; let n = 0;
    req.on('data', d => { n += d.length; if (n > limit) { bad(new Error('too large')); req.destroy(); } else ch.push(d); });
    req.on('end', () => ok(Buffer.concat(ch))); req.on('error', bad); });
}
async function serveFile(req, res, file, cache, forceType) {
  let st; try { st = await fsp.stat(file); if (!st.isFile()) throw 0; } catch { return send(res, 404, { error: 'not found' }); }
  const type = forceType || MIME[extOf(file)] || 'application/octet-stream';
  const range = req.headers.range;
  const headers = { 'Content-Type': type, 'Accept-Ranges': 'bytes', 'Cache-Control': cache || 'no-cache', 'Access-Control-Allow-Origin': '*' };
  if (range) {
    const m = /bytes=(\d*)-(\d*)/.exec(range); let start = m && m[1] ? +m[1] : 0; let end = m && m[2] ? +m[2] : st.size - 1;
    if (m && !m[1] && m[2]) { start = Math.max(0, st.size - +m[2]); end = st.size - 1; }
    if (start >= st.size || end >= st.size || start > end) { res.writeHead(416, { 'Content-Range': `bytes */${st.size}` }); return res.end(); }
    res.writeHead(206, { ...headers, 'Content-Range': `bytes ${start}-${end}/${st.size}`, 'Content-Length': end - start + 1 });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file, { start, end }).on('error', () => res.destroy()).pipe(res);
  } else {
    res.writeHead(200, { ...headers, 'Content-Length': st.size });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).on('error', () => res.destroy()).pipe(res);
  }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const p = decodeURIComponent(url.pathname);
  try {
    if (req.method === 'OPTIONS') { res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE' }); return res.end(); }
    if (p === '/api/login') {
      const pin = url.searchParams.get('pin') || '';
      if (!PIN || pin === PIN || (VIEW_PIN && pin === VIEW_PIN)) { res.writeHead(200, { 'Set-Cookie': `bvjpin=${encodeURIComponent(pin)}; Path=/; Max-Age=31536000; SameSite=Lax`, 'Content-Type': 'application/json' }); return res.end('{"ok":true}'); }
      return send(res, 401, { error: 'bad pin' });
    }
    if (p.startsWith('/api/auth/') || p === '/webproxy') { if (await pro3.route(req, res, p, url, authRole(req, url))) return; }
    if (p === '/api/info') return send(res, 200, { pinRequired: !!PIN, users: pro3.hasUsers(), version: pro3.VERSION, authed: authed(req, url), role: authRole(req, url), osc: OSC_PORT, port: PORT, addresses: lanAddresses(), platform: process.platform });
    if (p.startsWith('/api/') || p.startsWith('/media/') || p.startsWith('/thumb/')) {
      const role = authRole(req, url); if (!role) return send(res, 401, { error: 'pin required' });
      const mutating = req.method !== 'GET' || /^\/api\/(trigger|column|clear|blackout|master|bpm|next|cue|deck|test)\//.test(p) || (/^\/api\/feed\//.test(p) && [...url.searchParams.keys()].some(k => k !== 'pin'));
      if (role === 'view' && mutating) return send(res, 403, { error: 'view-only PIN' });
      if (role === 'client' && mutating && !/^\/api\/(trigger|column|blackout|master|next|cue|auth)\b/.test(p) && !(p === '/api/cmd' && false)) return send(res, 403, { error: 'Your login can only trigger clips and cues' });
    }

    // ---- media streaming
    if (p.startsWith('/media/')) {
      const key = p.slice(7); let abs = resolveMedia(key);
      if (!abs || !fs.existsSync(abs)) { // fallback: find the same file name in any source (moved drives, backup machines)
        const base = path.basename(key).toLowerCase(); for (const s of sources) { const r = scanCache.get(s.id) || await scanSource(s, false); const hit = r.items.find(i => i.name.toLowerCase() === base); if (hit) { abs = resolveMedia(hit.src); break; } } }
      if (!abs) return send(res, 404, { error: 'bad media path' });
      if (hasTranscode(key)) return serveFile(req, res, transFile(key), 'public, max-age=3600', 'video/mp4');
      return serveFile(req, res, abs, 'public, max-age=3600');
    }
    if (p.startsWith('/thumb/')) { const f = thumbFile(p.slice(7)); return serveFile(req, res, f, 'no-cache'); }

    // ---- API
    if (p.startsWith('/api/') && (req.method !== 'GET' || /^\/api\/(trigger|column|clear|blackout|master|bpm|next|cue|deck|test|feed)\//.test(p))) monitor('http', req.method + ' ' + p + (url.search || '') + ' from ' + (req.socket.remoteAddress || '').replace('::ffff:', ''));
    if (await pro3.route(req, res, p, url, authRole(req, url))) return;
    if (p === '/api/state') return send(res, 200, state);
    if (p === '/api/cmd' && req.method === 'POST') { const body = JSON.parse((await readBody(req)).toString() || '{}'); applyCmd(body, 'api'); return send(res, 200, { ok: true }); }
    if (p === '/api/library') {
      const force = url.searchParams.get('refresh') === '1';
      const out = [];
      for (const s of sources) { const r = await scanSource(s, force); out.push({ ...s, online: r.online, items: r.items.map(it => {
        const conv = it.kind === 'video' && hasTranscode(it.src); const job = jobs.find(j => j.src === it.src && (j.status === 'queued' || j.status === 'running'));
        return { ...it, meta: meta[it.src] || null, thumb: !!(meta[it.src] && meta[it.src].thumb), native: isNative(it.name), converted: conv,
          converting: !!job, playable: isNative(it.name) || conv };
      }) }); }
      return send(res, 200, { sources: out, ffmpeg: ffmpegOk, settings });
    }
    if (p === '/api/sources' && req.method === 'POST') {
      const body = JSON.parse((await readBody(req)).toString() || '{}');
      const abs = path.resolve(String(body.path || ''));
      let st; try { st = await fsp.stat(abs); } catch { return send(res, 400, { error: 'Folder not found on the server machine: ' + abs }); }
      if (!st.isDirectory()) return send(res, 400, { error: 'Not a folder' });
      const id = srcId(abs);
      if (!sources.find(s => s.id === id)) sources.push({ id, name: body.name || path.basename(abs) || abs, path: abs, kind: 'external' });
      saveSources(); scanCache.delete(id); broadcast({ t: 'library' });
      return send(res, 200, { ok: true, id });
    }
    if (p === '/api/sources' && req.method === 'DELETE') {
      const id = url.searchParams.get('id'); if (id === 'local') return send(res, 400, { error: 'cannot remove local library' });
      sources = sources.filter(s => s.id !== id); saveSources(); broadcast({ t: 'library' }); return send(res, 200, { ok: true });
    }
    if (p === '/api/drives') return send(res, 200, { drives: await detectDrives(), sep: path.sep });
    if (p === '/api/browse') {
      const dir = path.resolve(url.searchParams.get('path') || os.homedir());
      let ents; try { ents = await fsp.readdir(dir, { withFileTypes: true }); } catch (e) { return send(res, 400, { error: e.code || e.message }); }
      const dirs = ents.filter(e => e.isDirectory() && !e.name.startsWith('.') && !e.name.startsWith('$')).map(e => e.name).sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
      const media = ents.filter(e => e.isFile() && mediaKind(e.name)).length;
      return send(res, 200, { path: dir, parent: path.dirname(dir) !== dir ? path.dirname(dir) : null, dirs, media });
    }
    if (p === '/api/upload' && (req.method === 'PUT' || req.method === 'POST')) {
      const name = path.basename(url.searchParams.get('name') || '').replace(/[<>:"|?*\\]/g, '_');
      if (!name || !mediaKind(name)) return send(res, 400, { error: 'unsupported file type' });
      const sub = (url.searchParams.get('folder') || '').replace(/[^\w\- ]/g, '');
      const dir = path.join(LOCAL_MEDIA, sub); await fsp.mkdir(dir, { recursive: true });
      let dest = path.join(dir, name), n = 1;
      while (fs.existsSync(dest)) dest = path.join(dir, path.basename(name, path.extname(name)) + ` (${n++})` + path.extname(name));
      await new Promise((ok, bad) => { const w = fs.createWriteStream(dest); req.pipe(w); w.on('finish', ok); w.on('error', bad); req.on('error', bad); });
      scanCache.delete('local'); broadcast({ t: 'library' });
      return send(res, 200, { ok: true, src: 'local/' + path.relative(LOCAL_MEDIA, dest).split(path.sep).join('/') });
    }
    if (p === '/api/media' && req.method === 'DELETE') {
      const key = url.searchParams.get('src') || ''; if (!key.startsWith('local/')) return send(res, 400, { error: 'Only files in the Local Library can be deleted from here (external drives are read-only).' });
      const abs = resolveMedia(key); if (!abs) return send(res, 404, {});
      await fsp.unlink(abs).catch(() => {}); scanCache.delete('local'); broadcast({ t: 'library' }); return send(res, 200, { ok: true });
    }
    if (p === '/api/thumb' && req.method === 'POST') {
      const key = url.searchParams.get('src'); if (!key || !resolveMedia(key)) return send(res, 400, {});
      const buf = await readBody(req, 2 * 1024 * 1024); await fsp.writeFile(thumbFile(key), buf);
      meta[key] = Object.assign(meta[key] || {}, { thumb: true, duration: +url.searchParams.get('duration') || 0, w: +url.searchParams.get('w') || 0, h: +url.searchParams.get('h') || 0 });
      saveMeta(); return send(res, 200, { ok: true });
    }
    if (p === '/api/comps') return send(res, 200, { comps: listComps() });
    if (p === '/api/log') return send(res, 200, { log: changeLog.slice(-150).reverse(), undo: undoStack.length, redo: redoStack.length });
    if (p === '/api/status') return send(res, 200, { name: state.comp.name, master: state.comp.master, blackout: state.comp.blackout, bpm: state.comp.bpm,
      deck: state.decks[state.comp.deck] && state.decks[state.comp.deck].name, cue: state.cues[state.cueIndex] ? { index: state.cueIndex + 1, name: state.cues[state.cueIndex].name } : null,
      timecode: tc.frames, outputs: outputsInfo().length,
      layers: state.layers.map((l, i) => { const cl = l.active != null ? (l.activeClip || l.clips[l.active]) : null; return { layer: i + 1, name: l.name, opacity: l.opacity, active: l.active == null ? null : l.active + 1, clip: cl ? (cl.name || cl.src) : null }; }) });
    if (p === '/api/meta' && req.method === 'POST') {
      const key = url.searchParams.get('src'); if (!key || !resolveMedia(key)) return send(res, 400, { error: 'bad src' });
      const b = JSON.parse((await readBody(req)).toString() || '{}'); const m0 = meta[key] = meta[key] || {};
      if (Array.isArray(b.tags)) m0.tags = b.tags.map(t => String(t).trim().toLowerCase().slice(0, 30)).filter(Boolean).slice(0, 20);
      if (b.rating != null) m0.rating = Math.max(0, Math.min(5, b.rating | 0));
      saveMeta(); broadcast({ t: 'library' }); return send(res, 200, { ok: true });
    }
    if (p === '/api/feed') { try { return send(res, 200, { text: await getFeed(url.searchParams.get('url'), url.searchParams.get('cell') || '') }); } catch (e) { return send(res, 502, { error: e.message }); } }
    if (p === '/api/settings') {
      if (req.method === 'POST') { const b = JSON.parse((await readBody(req)).toString() || '{}'); for (const k of ['autoConvert', 'convertMode', 'backup']) if (k in b) settings[k] = b[k]; saveSettings(); broadcast({ t: 'settings', settings }); if ('backup' in b) { mirror.lastSeen = 0; mirrorConnect(); broadcast({ t: 'backup', status: backupStatus() }); } }
      return send(res, 200, { settings, ffmpeg: ffmpegOk });
    }
    if (p === '/api/convert' && req.method === 'POST') { queueConvert(url.searchParams.get('src')); return send(res, 200, { ok: true }); }
    if (p === '/api/convert' && req.method === 'DELETE') { const k = url.searchParams.get('src'); try { fs.unlinkSync(transFile(k)); } catch {} broadcast({ t: 'library' }); return send(res, 200, { ok: true }); }
    if (p === '/api/jobs') return send(res, 200, { jobs: jobList(), ffmpeg: ffmpegOk });
    if (p === '/api/convertAll' && req.method === 'POST') { // convert every non-native video used in the show
      let n = 0; for (const src of usedMedia(state)) { const abs = resolveMedia(src); if (abs && !isNative(abs) && !hasTranscode(src)) { queueConvert(src); n++; } } return send(res, 200, { ok: true, queued: n });
    }
    // ---- show files
    if (p === '/api/show/export') {
      const name = safeName(url.searchParams.get('name') || state.comp.name);
      res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Disposition': `attachment; filename="${name}${SHOW_EXT}"` });
      return res.end(JSON.stringify(showDoc(state), null, 1));
    }
    if (p === '/api/show/import' && req.method === 'POST') {
      const doc = JSON.parse((await readBody(req, 20 * 1024 * 1024)).toString());
      const st = doc && /-show$/.test(doc.format || '') ? doc.state : doc; if (!st || !st.layers) return send(res, 400, { error: 'Not a PIXORA show file' });
      const sizes = {}; for (const m of (doc.media || [])) sizes[m.src] = m.size;
      for (const l of st.layers) for (const c of (l.clips || [])) if (c && sizes[c.src]) c.size = sizes[c.src];
      const report = await relink(st); state = normalizeState(st); state.layers.forEach(l => l.active = null); markDirty();
      return send(res, 200, { ok: true, ...report });
    }
    if (p === '/api/show/relink' && req.method === 'POST') { const report = await relink(state); markDirty(); return send(res, 200, report); }
    if (p === '/api/show/missing') { const miss = usedMedia(state).filter(src => { const a = resolveMedia(src); return !a || !fs.existsSync(a); }); return send(res, 200, { missing: miss }); }
    if (p === '/api/show/collect' && req.method === 'POST') {
      const b = JSON.parse((await readBody(req)).toString() || '{}');
      const name = safeName(b.name || state.comp.name);
      const base = b.dest ? path.resolve(String(b.dest)) : path.join(DATA, 'shows');
      try { await fsp.mkdir(base, { recursive: true }); } catch (e) { return send(res, 400, { error: 'Cannot write to ' + base }); }
      const dest = path.join(base, name);
      jobs.push({ id: crypto.randomBytes(3).toString('hex'), type: 'collect', name, dest, src: dest, progress: 0, status: 'queued' }); pushJobs(); runJobs();
      return send(res, 200, { ok: true, dest });
    }
    if (p === '/api/outputs') return send(res, 200, { outputs: outputsInfo() });

    // ---- simple GET shortcuts for Stream Deck / Companion / browsers (1-based numbers)
    let m;
    // ---- data feeds (push from any app: POST JSON / CSV / text, or GET ?key=value)
    if ((m = p.match(/^\/api\/feed\/([\w-]+)$/))) {
      const id = m[1]; let v;
      if (req.method === 'POST' || req.method === 'PUT') { const body = (await readBody(req, 2 * 1024 * 1024)).toString(); const ct = req.headers['content-type'] || '';
        try { v = /json/.test(ct) || /^\s*[\[{]/.test(body) ? JSON.parse(body) : /csv/.test(ct) ? csvToObj(body) : { text: body.trim() }; } catch (e) { return send(res, 400, { error: 'Invalid JSON: ' + e.message }); }
        if (url.searchParams.get('merge') === '1' && feedValues[id] && typeof v === 'object') v = Object.assign({}, feedValues[id], v); }
      else if ([...url.searchParams.keys()].length) { v = Object.assign({}, feedValues[id] || {}); for (const [k, val] of url.searchParams) if (k !== 'pin') v[k] = isFinite(+val) && val !== '' ? +val : val; }
      else return send(res, 200, { id, value: feedValues[id] ?? null, status: feedStatus[id] || null });
      if (!state.feeds.find(f => f.id === id)) { state.feeds.push({ id, name: id, type: 'push', url: '', interval: 5, on: true }); markDirty(); }
      setFeed(id, v, 'push ' + (req.socket.remoteAddress || '')); return send(res, 200, { ok: true });
    }
    if (p === '/api/feeds') return send(res, 200, { values: feedValues, status: feedStatus });
    // ---- GDTF personality for consoles
    if (p === '/api/gdtf') { const n = Math.max(1, Math.min(32, +url.searchParams.get('layers') || state.layers.length)); const z = gdtfFile(n);
      res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Disposition': `attachment; filename="Booth_Productions@PIXORA.gdtf"` }); return res.end(z); }
    // ---- proof of play
    if (p === '/api/pop.csv') { const { hdr, rows } = popRows(url.searchParams.get('from'), url.searchParams.get('to'));
      res.writeHead(200, { 'Content-Type': 'text/csv', 'Content-Disposition': `attachment; filename="PIXORA proof-of-play ${url.searchParams.get('from') || 'all'}.csv"` });
      return res.end(hdr + '\n' + rows.map(r => r.map(c => /[",]/.test(c) ? '"' + c.replace(/"/g, '""') + '"' : c).join(',')).join('\n') + '\n'); }
    if (p === '/api/pop/summary') { const { rows } = popRows(url.searchParams.get('from'), url.searchParams.get('to')); const by = {};
      for (const r of rows) { const k = r[2] || '(no sponsor)'; const o = by[k] = by[k] || { sponsor: k, plays: 0, seconds: 0, items: {} }; o.plays++; o.seconds += +r[5] || 0; o.items[r[3]] = (o.items[r[3]] || 0) + 1; }
      return send(res, 200, { total: rows.length, sponsors: Object.values(by).sort((a, b) => b.plays - a.plays), playing: rot.playing ? { name: rot.playing.item.name, since: rot.playing.start, dur: rot.playing.item.dur } : null, last: rot.last }); }
    if (p === '/pop-report') { const from = url.searchParams.get('from') || '', to = url.searchParams.get('to') || ''; const { rows } = popRows(from, to); const by = {};
      for (const r of rows) { const k = r[2] || '(no sponsor)'; const o = by[k] = by[k] || { plays: 0, seconds: 0, items: {} }; o.plays++; o.seconds += +r[5] || 0; o.items[r[3]] = (o.items[r[3]] || 0) + 1; }
      const e = s => String(s).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
      const html = `<!doctype html><meta charset="utf-8"><title>Proof of play — PIXORA</title><style>body{font:14px/1.5 Inter,Segoe UI,Arial;margin:40px;color:#16161c}h1{margin:0}img{height:46px}table{border-collapse:collapse;width:100%;margin:16px 0}th,td{border-bottom:1px solid #ddd;padding:7px 10px;text-align:left}th{font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:#666}.m{color:#666}</style>
        <div style="display:flex;justify-content:space-between;align-items:center"><div><h1>Proof of play report</h1><div class="m">${e(state.comp.name)} · ${from || 'all time'} → ${to || 'today'} · generated ${new Date().toLocaleString()}</div></div><div style="background:#08080b;padding:10px 14px;border-radius:8px"><img src="/pixora-logo.png"></div></div>
        <h2>Summary</h2><table><tr><th>Sponsor</th><th>Plays</th><th>Total airtime</th><th>Spots</th></tr>${Object.entries(by).map(([k, o]) => `<tr><td><b>${e(k)}</b></td><td>${o.plays}</td><td>${Math.floor(o.seconds / 60)} min ${Math.round(o.seconds % 60)} s</td><td>${Object.entries(o.items).map(([n, c]) => `${e(n)} ×${c}`).join(', ')}</td></tr>`).join('') || '<tr><td colspan=4>No plays in this period</td></tr>'}</table>
        <h2>Detailed log</h2><table><tr><th>Start</th><th>Sponsor</th><th>Spot</th><th>Played</th><th>Layer</th><th>Outputs live</th></tr>${rows.map(r => `<tr><td>${new Date(r[0]).toLocaleString()}</td><td>${e(r[2])}</td><td>${e(r[3])}</td><td>${r[5]} s</td><td>${e(r[6])}</td><td>${r[7]}</td></tr>`).join('')}</table>
        <p class="m">Generated by PIXORA — Booth Productions. Each row is logged at the moment the spot left the screen.</p>`;
      return send(res, 200, html, 'text/html; charset=utf-8'); }
    // ---- health
    if (p === '/api/health') {
      const srcs = []; for (const s of sources) { const r = await scanSource(s, false); srcs.push({ id: s.id, name: s.name, path: s.path, online: r.online, files: r.items.length, bench: health.bench[s.id] || null }); }
      const missing = usedMedia(state).filter(src => { const a = resolveMedia(src); return !a || !fs.existsSync(a); });
      return send(res, 200, { server: { host: os.hostname(), platform: process.platform, uptime: process.uptime(), load: cpuLoad(), cpus: os.cpus().length, mem: { total: os.totalmem(), free: os.freemem() }, temp: cpuTemp(), tempSrc: process.platform === 'linux' ? 'sysfs' : tempCache.src, throttle: tempCache.throttle ?? null, node: process.version, ffmpeg: ffmpegOk },
        outputs: outputsInfo().map(o => Object.assign(o, { stats: health.outputs[o.id] || null })), clients: presenceList(), sources: srcs, missing, backup: backupStatus(), jobs: jobList().filter(j => j.status === 'running' || j.status === 'queued').length, rec: rec.on }); }
    if (p === '/api/health/bench' && req.method === 'POST') { const s = sources.find(x => x.id === url.searchParams.get('id')); if (!s) return send(res, 404, {}); try { health.bench[s.id] = await benchSource(s); return send(res, 200, health.bench[s.id] || { error: 'no video files' }); } catch (e) { return send(res, 500, { error: e.message }); } }
    if (p === '/api/monitor') return send(res, 200, { log: monitorLog.slice(-300) });
    // ---- local recording (upload from the output window, formats, start/stop API)
    if (await rec.http(p, req, res, url, send, readBody)) return;
    if ((m = p.match(/^\/api\/trigger\/(\d+)\/(\d+)$/))) { applyCmd({ op: 'trigger', layer: m[1] - 1, clip: m[2] - 1 }); return send(res, 200, { ok: true }); }
    if ((m = p.match(/^\/api\/column\/(\d+)$/))) { applyCmd({ op: 'column', col: m[1] - 1 }); return send(res, 200, { ok: true }); }
    if ((m = p.match(/^\/api\/clear\/(\d+|all)$/))) { applyCmd(m[1] === 'all' ? { op: 'clearAll' } : { op: 'clearLayer', layer: m[1] - 1 }); return send(res, 200, { ok: true }); }
    if ((m = p.match(/^\/api\/blackout\/(on|off|toggle)$/))) { applyCmd({ op: 'blackout', on: m[1] === 'toggle' ? undefined : m[1] === 'on' }); return send(res, 200, { ok: true }); }
    if ((m = p.match(/^\/api\/master\/([\d.]+)$/))) { applyCmd({ op: 'set', path: 'comp.master', value: clamp01(m[1]) }); return send(res, 200, { ok: true }); }
    if ((m = p.match(/^\/api\/bpm\/([\d.]+)$/))) { applyCmd({ op: 'bpm', bpm: +m[1] }); return send(res, 200, { ok: true }); }
    if ((m = p.match(/^\/api\/next\/(\d+)$/))) { applyCmd({ op: 'next', layer: m[1] - 1 }); return send(res, 200, { ok: true }); }
    if ((m = p.match(/^\/api\/cue\/(go|back|stop|\d+)$/))) { applyCmd(m[1] === 'go' ? { op: 'cueGo' } : m[1] === 'back' ? { op: 'cueBack' } : m[1] === 'stop' ? { op: 'cueStop' } : { op: 'cueGo', index: m[1] - 1 }); return send(res, 200, { ok: true }); }
    if ((m = p.match(/^\/api\/test\/(on|off|toggle|[a-z]+)$/))) { const v = m[1]; applyCmd(v === 'toggle' ? { op: 'set', path: 'led.test.on', value: !state.led.test.on } : v === 'on' || v === 'off' ? { op: 'set', path: 'led.test.on', value: v === 'on' } : { op: 'setMany', values: { 'led.test.mode': v, 'led.test.on': true } }); return send(res, 200, { ok: true }); }
    if ((m = p.match(/^\/api\/deck\/(\d+)$/))) { applyCmd({ op: 'deckSwitch', deck: m[1] - 1 }); return send(res, 200, { ok: true }); }

    // ---- static
    let file = p === '/' ? '/index.html' : p.endsWith('/') ? p + 'index.html' : p === '/manual' ? '/manual/index.html' : p;
    if (['/output', '/remote', '/clean', '/diag', '/stage'].includes(file)) file = file === '/clean' ? '/output.html' : file + '.html';
    const abs = path.resolve(PUB, '.' + file);
    if (!abs.startsWith(PUB + path.sep)) return send(res, 403, 'forbidden', 'text/plain');
    return serveFile(req, res, abs, 'no-cache');
  } catch (e) {
    console.error(e); if (!res.headersSent) send(res, 500, { error: e.message });
  }
});
server.on('upgrade', (req, socket) => {
  const url = new URL(req.url, 'http://x');
  if (url.pathname !== '/ws' || !authed(req, url)) { socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n'); return socket.destroy(); }
  const role = ['output', 'control', 'remote', 'mirror', 'diag'].includes(url.searchParams.get('role')) ? url.searchParams.get('role') : 'control';
  const ar = authRole(req, url); wsAccept(req, socket, role, ar === 'view', ar === 'client');
});
function lanAddresses() { return Object.values(os.networkInterfaces()).flat().filter(i => i && i.family === 'IPv4' && !i.internal).map(i => i.address); }

setTimeout(mirrorConnect, 500);
server.on('error', e => { if (e.code === 'EADDRINUSE' && process.env.PIXORA_RESTART_WAIT && (server._tries = (server._tries || 0) + 1) < 40) return setTimeout(() => server.listen(PORT), 250); console.error(e.message); process.exit(1); });
server.listen(PORT, () => {
  console.log('\n  PIXORA — Booth Productions');
  console.log(`  Controller : http://localhost:${PORT}/`);
  console.log(`  Output     : http://localhost:${PORT}/output`);
  console.log(`  Phone      : http://localhost:${PORT}/remote`);
  for (const a of lanAddresses()) console.log(`  On LAN     : http://${a}:${PORT}/  (remote: /remote)`);
  console.log(`  Media roots: ${sources.map(s => s.path).join('  |  ')}`);
  console.log(`  ffmpeg     : ${ffmpegOk ? 'found — non-browser formats will be converted locally' : 'NOT found — install ffmpeg to play AVI/WMV/MPEG-2/ProRes etc.'}`);
  if (PIN) console.log('  PIN protection ON');
  console.log('');
});
