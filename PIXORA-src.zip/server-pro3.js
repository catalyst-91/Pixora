/*
 * PIXORA v1.2 server modules — Booth Productions
 * Show reliability & show lock · content preflight & optimise · CITP/MSEX media-server protocol · Art-Net timecode in/out ·
 * MVR stage import · multi-machine frame sync clock · HAP detection · users, roles & sessions · Cloudflare remote access ·
 * show reports (PDF) · web proxy for websites · update checker / installer.
 * Zero dependencies (Node 18+). Loaded by server.js with a small context object.
 */
'use strict';
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const crypto = require('crypto');
const dgram = require('dgram');
const net = require('net');
const zlib = require('zlib');
const os = require('os');
const { spawn, spawnSync } = require('child_process');

module.exports = function initPro3(ctx) {
  const { DATA, ROOT, PORT, send, readBody, broadcast, monitor } = ctx;
  const VERSION = require(path.join(ROOT, 'package.json')).version;
  const st = () => ctx.getState();
  const readJ = (f, d) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } };
  const writeJ = (f, v) => { try { fs.writeFileSync(f + '.tmp', JSON.stringify(v, null, 1)); fs.renameSync(f + '.tmp', f); } catch (e) { console.warn(e.message); } };

  /* =========================================================== state defaults */
  const DEF = {
    show: { lock: false, lockPin: '', safeSrc: '', safeName: '', safeOnError: true, safeOnStall: true, preload: true, dropWarn: 2 },
    citp: { on: false, name: 'PIXORA', layers: 4 },
    sync: { on: false, tolerance: 40, hardSeek: 250 },
    access: { tunnel: false },
    update: { feed: '', auto: false },
  };
  function normalize(s) {
    for (const k of Object.keys(DEF)) s[k] = Object.assign(JSON.parse(JSON.stringify(DEF[k])), s[k] || {});
    if (s.comp && s.comp.timecode) s.comp.timecode = Object.assign({ artnetOut: false, artnetDest: '' }, s.comp.timecode);
    return s;
  }

  /* =========================================================== 1. show lock & reliability stats */
  const LOCK_ALLOWED = new Set(['trigger', 'column', 'clearLayer', 'clearAll', 'cueGo', 'cueNext', 'cueBack', 'cueIndex', 'next', 'blackout', 'master', 'tap', 'bpm',
    'tcStart', 'tcStop', 'tlPlay', 'tlStop', 'tlSeek', 'rotStart', 'rotStop', 'recStart', 'recStop', 'unlockShow', 'safeLoop', 'presence']);
  const LOCK_PATHS = /^(comp\.(master|blackout|bpm|crossfader)|layers\.\d+\.(opacity|volume))$/;
  function lockCheck(cmd) { // throws when the show is locked and the command would change the setup
    const s = st(); if (!s.show || !s.show.lock) return;
    const list = Array.isArray(cmd) ? cmd : [cmd];
    for (const c of list) {
      if (!c || LOCK_ALLOWED.has(c.op)) continue;
      if (c.op === 'set' && LOCK_PATHS.test(c.path || '')) continue;
      if (c.op === 'setMany' && Object.keys(c.values || {}).every(p => LOCK_PATHS.test(p))) continue;
      throw new Error('Show is locked — unlock in Show tab to edit (playback controls still work)');
    }
  }
  const CLIENT_OPS = new Set(['trigger', 'column', 'cueGo', 'cueNext', 'cueBack', 'cueIndex', 'next', 'blackout', 'master', 'tap', 'rotStart', 'rotStop']);
  const clientAllowed = cmd => (Array.isArray(cmd) ? cmd : [cmd]).every(c => c && (CLIENT_OPS.has(c.op) || (c.op === 'set' && /^comp\.(master|blackout)$/.test(c.path || ''))));

  const ostats = new Map(); // output id → latest stats
  function outputStats(c, m) {
    const prev = ostats.get(c.id) || { drops: 0, events: [] };
    const now = Date.now(), d = { id: c.id, name: m.name || c.outName || c.id, fps: m.fps, target: m.target, drops: m.drops | 0, dropRate: m.dropRate || 0, worst: m.worst || 0,
      vdrop: m.vdrop | 0, mem: m.mem || 0, safe: !!m.safe, glLost: !!m.glLost, errors: m.errors || [], at: now, since: prev.since || now, events: prev.events };
    if (m.safe && !prev.safe) { d.events.push({ at: now, msg: 'Safe loop engaged: ' + (m.safeWhy || '') }); monitor('show', 'Safe loop engaged on ' + d.name + ' — ' + (m.safeWhy || '')); }
    if (m.dropRate > (st().show.dropWarn || 2) && !(prev.dropRate > (st().show.dropWarn || 2))) d.events.push({ at: now, msg: `Frame drops ${m.dropRate.toFixed(1)}%` });
    d.events = d.events.slice(-30); ostats.set(c.id, d);
    if (!outputStats.t) outputStats.t = setTimeout(() => { outputStats.t = null; broadcast({ t: 'ostats', list: [...ostats.values()] }); }, 400);
  }
  function outputGone(c) { if (ostats.delete(c.id)) broadcast({ t: 'ostats', list: [...ostats.values()] }); }

  /* =========================================================== 2. preflight & optimise */
  const PF_CACHE = path.join(DATA, 'preflight-cache.json');
  const pfCache = readJ(PF_CACHE, {});
  let ffprobeOk = false; try { ffprobeOk = spawnSync('ffprobe', ['-version'], { timeout: 4000 }).status === 0; } catch {}
  function probe(abs) {
    return new Promise(res => {
      let out = ''; const p = spawn('ffprobe', ['-v', 'error', '-print_format', 'json', '-show_streams', '-show_format', abs]);
      p.stdout.on('data', d => out += d); p.on('error', () => res(null));
      p.on('close', () => { try { res(JSON.parse(out)); } catch { res(null); } });
      setTimeout(() => { try { p.kill(); } catch {} }, 15000);
    });
  }
  const HEAVY = new Set(['prores', 'dnxhd', 'cfhd', 'hevc', 'mpeg2video', 'mjpeg', 'qtrle', 'png', 'rawvideo', 'v210', 'r10k']);
  const BROWSER = new Set(['h264', 'vp8', 'vp9', 'av1', 'hevc']);
  function targets(s) { // the resolutions content is shown at: composition, each output, each LED screen
    const t = [{ name: 'Composition', w: s.comp.width, h: s.comp.height }];
    for (const sc of (s.led && s.led.screens) || []) { const w = (sc.cols || 1) * (sc.panelW || sc.pw || 0), h = (sc.rows || 1) * (sc.panelH || sc.ph || 0); if (w && h) t.push({ name: sc.name || 'LED screen', w, h }); }
    return t;
  }
  async function preflight(force) {
    const s = st(), lib = await ctx.library(), used = new Set(ctx.usedMedia(s)), tg = targets(s), fps = s.comp.fps || 60;
    const maxT = tg.reduce((a, b) => (b.w * b.h > a.w * a.h ? b : a), tg[0]);
    const items = [], missing = [];
    for (const key of used) if (!lib.find(i => i.src === key) && !ctx.resolveMedia(key)) missing.push(key);
    for (const it of lib) {
      if (it.kind !== 'video' && it.kind !== 'image') continue;
      const abs = ctx.resolveMedia(it.src); if (!abs) continue;
      let stat; try { stat = fs.statSync(abs); } catch { continue; }
      const ck = it.src + '|' + stat.size + '|' + stat.mtimeMs;
      let info = !force && pfCache[ck];
      if (!info && ffprobeOk) {
        const j = await probe(abs); const v = j && (j.streams || []).find(x => x.codec_type === 'video'); const a = j && (j.streams || []).find(x => x.codec_type === 'audio');
        if (v) {
          const fr = (v.avg_frame_rate || v.r_frame_rate || '0/1').split('/'); const vf = +fr[1] ? +fr[0] / +fr[1] : 0;
          info = { codec: v.codec_name, w: v.width, h: v.height, fps: Math.round(vf * 100) / 100, pix: v.pix_fmt, bits: /10|12/.test(v.pix_fmt || '') ? 10 : 8,
            dur: +(j.format && j.format.duration) || 0, mbps: Math.round((+(j.format && j.format.bit_rate) || 0) / 1e5) / 10, audio: a ? a.codec_name : '', hap: v.codec_name === 'hap' };
        } else info = { error: 'unreadable' };
        pfCache[ck] = info;
      }
      if (!info) info = it.kind === 'image' ? { codec: 'image' } : { codec: '?', note: 'install ffmpeg/ffprobe for full checks' };
      const issues = [];
      if (info.error) issues.push({ lvl: 'err', msg: 'File could not be read (corrupt or unsupported)' });
      if (info.w && maxT.w) {
        const up = Math.max(maxT.w / info.w, maxT.h / info.h); // scale needed to cover the target
        if (up > 1.34) issues.push({ lvl: 'warn', msg: `Low resolution ${info.w}×${info.h} for ${maxT.name} ${maxT.w}×${maxT.h} (upscaled)` });
        else if (info.w > maxT.w * 2.2 && info.h > maxT.h * 2.2) issues.push({ lvl: 'info', msg: `Much larger than needed (${info.w}×${info.h}) — wastes decode power` });
        const ar = info.w / info.h, tar = maxT.w / maxT.h; if (Math.abs(ar - tar) / tar > 0.12) issues.push({ lvl: 'info', msg: `Aspect ${ar.toFixed(2)} vs ${maxT.name} ${tar.toFixed(2)} — will crop or stretch per Fit` });
      }
      const isImg = it.kind === 'image';
      if (!isImg && info.fps && Math.abs(info.fps - fps) > 0.6 && Math.abs(info.fps * 2 - fps) > 0.6 && Math.abs(info.fps - fps * 2) > 0.6) issues.push({ lvl: 'warn', msg: `${info.fps} fps content on a ${fps} fps show (judder)` });
      if (!isImg && info.codec && HEAVY.has(info.codec) && !info.hap) issues.push({ lvl: info.codec === 'hevc' ? 'info' : 'warn', msg: `${info.codec.toUpperCase()}${info.bits > 8 ? ' ' + info.bits + '-bit' : ''} is heavy to play live` });
      if (info.codec && !BROWSER.has(info.codec) && !info.hap && it.kind === 'video') issues.push({ lvl: 'warn', msg: 'Needs conversion for browser playback' });
      if (info.mbps > 60) issues.push({ lvl: 'warn', msg: `Very high bitrate (${info.mbps} Mb/s)` });
      if (info.hap) issues.push({ lvl: 'ok', msg: 'HAP — GPU playback' });
      items.push({ src: it.src, name: it.name, kind: it.kind, used: used.has(it.src), size: stat.size, info, issues });
    }
    writeJ(PF_CACHE, pfCache);
    const bad = items.filter(i => i.issues.some(x => x.lvl === 'warn' || x.lvl === 'err'));
    return { at: Date.now(), ffprobe: ffprobeOk, target: maxT, fps, targets: tg, missing, items, summary: { total: items.length, flagged: bad.length, usedFlagged: bad.filter(i => i.used).length, missing: missing.length } };
  }
  const optJobs = []; let optRunning = false;
  function optimise(keys, opts) {
    const s = st(), tg = targets(s); const T = tg.reduce((a, b) => (b.w * b.h > a.w * a.h ? b : a), tg[0]);
    for (const key of keys) {
      if (optJobs.find(j => j.src === key && j.status !== 'done' && j.status !== 'error')) continue;
      const abs = ctx.resolveMedia(key); if (!abs) continue;
      optJobs.push({ id: crypto.randomBytes(4).toString('hex'), src: key, abs, name: path.basename(key), status: 'queued', pct: 0, w: opts.w || T.w, h: opts.h || T.h, fps: opts.fps || s.comp.fps || 60, relink: opts.relink !== false });
    }
    runOpt(); return optJobs.slice(-40);
  }
  function runOpt() {
    if (optRunning) return; const j = optJobs.find(x => x.status === 'queued'); if (!j) return;
    optRunning = true; j.status = 'running';
    const outDir = path.join(ctx.LOCAL_MEDIA, 'Optimised'); fs.mkdirSync(outDir, { recursive: true });
    const base = path.basename(j.abs).replace(/\.[^.]+$/, ''); j.out = path.join(outDir, `${base} ${j.w}x${j.h}.mp4`);
    const vf = `scale=${j.w}:${j.h}:force_original_aspect_ratio=decrease:flags=lanczos,pad=${j.w}:${j.h}:(ow-iw)/2:(oh-ih)/2,fps=${j.fps},format=yuv420p`;
    const args = ['-y', '-hide_banner', '-i', j.abs, '-vf', vf, '-c:v', 'libx264', '-preset', 'medium', '-crf', '18', '-profile:v', 'high', '-g', String(Math.round(j.fps)), '-movflags', '+faststart', '-c:a', 'aac', '-b:a', '192k', j.out];
    let dur = 0; const p = spawn('ffmpeg', args); let err = '';
    p.stderr.on('data', d => { const t = String(d); err = (err + t).slice(-2000); const m = /Duration: (\d+):(\d+):([\d.]+)/.exec(t); if (m) dur = +m[1] * 3600 + +m[2] * 60 + +m[3];
      const q = /time=(\d+):(\d+):([\d.]+)/.exec(t); if (q && dur) { j.pct = Math.min(99, Math.round((+q[1] * 3600 + +q[2] * 60 + +q[3]) / dur * 100)); pushOpt(); } });
    p.on('error', e => { j.status = 'error'; j.err = e.message; optRunning = false; pushOpt(); runOpt(); });
    p.on('close', code => {
      optRunning = false;
      if (code === 0) {
        j.status = 'done'; j.pct = 100; j.newSrc = 'local/Optimised/' + path.basename(j.out);
        if (j.relink) { const n = ctx.relinkMedia(j.src, j.newSrc); j.relinked = n; }
        ctx.rescan && ctx.rescan();
      } else { j.status = 'error'; j.err = err.split('\n').filter(Boolean).slice(-2).join(' '); }
      pushOpt(); runOpt();
    });
    pushOpt();
  }
  function pushOpt() { if (pushOpt.t) return; pushOpt.t = setTimeout(() => { pushOpt.t = null; broadcast({ t: 'optjobs', jobs: optJobs.slice(-40).map(({ abs, out, ...j }) => j) }); }, 300); }

  /* =========================================================== 3. HAP detection (reads the codec fourcc from the QuickTime sample description) */
  const hapCache = new Map();
  function hapCodec(abs) {
    let stt; try { stt = fs.statSync(abs); } catch { return null; }
    const ck = abs + stt.size + stt.mtimeMs; if (hapCache.has(ck)) return hapCache.get(ck);
    let res = null, fd;
    try {
      fd = fs.openSync(abs, 'r'); const hdr = Buffer.alloc(16);
      const atoms = (start, end, want) => { // iterate child atoms
        const out = []; let o = start;
        while (o + 8 <= end) {
          fs.readSync(fd, hdr, 0, 16, o); let size = hdr.readUInt32BE(0); const type = hdr.toString('latin1', 4, 8); let hl = 8;
          if (size === 1) { size = Number(hdr.readBigUInt64BE(8)); hl = 16; } else if (size === 0) size = end - o;
          if (size < 8) break; if (!want || want.includes(type)) out.push({ type, start: o + hl, end: o + size }); o += size;
        }
        return out;
      };
      const moov = atoms(0, stt.size, ['moov'])[0];
      if (moov) for (const trak of atoms(moov.start, moov.end, ['trak'])) {
        const mdia = atoms(trak.start, trak.end, ['mdia'])[0]; if (!mdia) continue;
        const minf = atoms(mdia.start, mdia.end, ['minf'])[0]; if (!minf) continue;
        const stbl = atoms(minf.start, minf.end, ['stbl'])[0]; if (!stbl) continue;
        const stsd = atoms(stbl.start, stbl.end, ['stsd'])[0]; if (!stsd) continue;
        const b = Buffer.alloc(16); fs.readSync(fd, b, 0, 16, stsd.start + 8); const fourcc = b.toString('latin1', 4, 8);
        if (/^Hap[15YMAH7]$/.test(fourcc) || fourcc === 'HapA' || fourcc === 'HapM') { res = fourcc; break; }
      }
    } catch { res = null; } finally { if (fd != null) try { fs.closeSync(fd); } catch {} }
    hapCache.set(ck, res); return res;
  }
  async function hapList() {
    const lib = await ctx.library(), out = {};
    for (const it of lib) if (it.kind === 'video' && /\.(mov|mp4|avi)$/i.test(it.name)) { const abs = ctx.resolveMedia(it.src); const c = abs && hapCodec(abs); if (c) out[it.src] = c; }
    return out;
  }

  /* =========================================================== 4. Art-Net timecode in / out */
  const TC_TYPES = { 24: 0, 25: 1, 29.97: 2, 30: 3 };
  function artTc(b) { // OpTimeCode 0x9700
    const s = st(); if (s.comp.timecode.source !== 'artnet' || b.length < 19) return;
    const fr = b[14], sc = b[15], mn = b[16], hr = b[17], type = b[18];
    const rate = [24, 25, 29.97, 30][type] || 25, fps = s.comp.timecode.fps || Math.round(rate);
    ctx.updateTc(((hr * 60 + mn) * 60 + sc) * fps + fr, fps); lastArtTc = Date.now();
  }
  let lastArtTc = 0;
  const tcOutSock = dgram.createSocket('udp4'); tcOutSock.on('error', () => {}); tcOutSock.bind(() => { try { tcOutSock.setBroadcast(true); } catch {} });
  let tcOutTimer = null;
  function tcOutTick() {
    const s = st(), t = s.comp.timecode; if (!t.artnetOut) return;
    const tc = ctx.tcInfo(); if (tc.frames == null || tc.frames < 0) return;
    const fps = t.fps || 25, f = tc.frames; const fr = f % fps, secs = Math.floor(f / fps);
    const b = Buffer.alloc(19); b.write('Art-Net\0', 0, 'latin1'); b.writeUInt16LE(0x9700, 8); b[10] = 0; b[11] = 14;
    b[14] = fr; b[15] = secs % 60; b[16] = Math.floor(secs / 60) % 60; b[17] = Math.floor(secs / 3600) % 24; b[18] = TC_TYPES[fps] ?? 1;
    try { tcOutSock.send(b, 6454, (t.artnetDest || '').trim() || '255.255.255.255'); } catch {}
  }
  function tcOutSchedule() { const t = st().comp.timecode; clearInterval(tcOutTimer); if (t.artnetOut) tcOutTimer = setInterval(tcOutTick, Math.round(1000 / (t.fps || 25))); }

  /* =========================================================== 5. CITP / MSEX (media server thumbnails & layer status for lighting consoles) */
  const CITP_MC = ['224.0.0.180', '239.224.0.180'];
  let citp = { udp: null, tcp: null, port: 0, peers: new Set(), timer: null, lsta: null, log: [] };
  const ucs1 = s => Buffer.from(String(s) + '\0', 'latin1');
  const ucs2 = s => Buffer.from(String(s) + '\0', 'utf16le');
  const cookie = s => Buffer.from(s, 'latin1');
  function citpPacket(content, body) { // CITP header + layer
    const h = Buffer.alloc(20); h.write('CITP', 0, 'latin1'); h[4] = 1; h[5] = 0; h.writeUInt16LE(0, 6);
    h.writeUInt32LE(20 + body.length, 8); h.writeUInt16LE(1, 12); h.writeUInt16LE(0, 14); cookie(content).copy(h, 16);
    return Buffer.concat([h, body]);
  }
  const msex = (ver, type, body) => citpPacket('MSEX', Buffer.concat([Buffer.from([ver[0], ver[1]]), cookie(type), body]));
  const u8 = v => Buffer.from([v & 255]), u16 = v => { const b = Buffer.alloc(2); b.writeUInt16LE(v & 0xffff); return b; }, u32 = v => { const b = Buffer.alloc(4); b.writeUInt32LE(v >>> 0); return b; };
  const u64 = v => { const b = Buffer.alloc(8); b.writeBigUInt64LE(BigInt(Math.max(0, Math.floor(v)))); return b; };
  function citpLog(m) { citp.log.push({ at: Date.now(), m }); if (citp.log.length > 60) citp.log.shift(); }
  const SERVER_UUID = (() => { const f = path.join(DATA, 'citp-uuid.txt'); let u = ''; try { u = fs.readFileSync(f, 'utf8').trim(); } catch {} if (!/^[0-9a-f-]{36}$/.test(u)) { u = crypto.randomUUID(); try { fs.writeFileSync(f, u); } catch {} } return u; })();
  function citpLayers() { const s = st(); return s.layers.slice(0, Math.max(1, Math.min(s.layers.length, s.citp.layers || s.layers.length))); }
  function dmxSource(li) { const d = st().comp.dmx || {}; return `ArtNet/${(d.net | 0)}/${(d.universe | 0)}/${(d.address || 1) + li * 8}`; }
  function libId(ver, n) { return ver[1] >= 1 ? Buffer.from([1, n, 0, 0]) : u8(n); } // MSEX 1.1+: level 1, number n
  function sinf(ver) {
    const ls = citpLayers(); const vs = VERSION.split('.').map(Number);
    if (ver[1] >= 2) return msex(ver, 'SInf', Buffer.concat([ucs1(SERVER_UUID), ucs2(st().citp.name || 'PIXORA'), u8(vs[0] || 1), u8(vs[1] || 0), u8(vs[2] || 0),
      u8(3), u16(0x0001), u16(0x0101), u16(0x0201), u16(0x0001), u8(1), cookie('JPEG'), u8(0), u8(ls.length), ...ls.map((l, i) => ucs1(dmxSource(i)))]));
    return msex(ver, 'SInf', Buffer.concat([ucs2(st().citp.name || 'PIXORA'), u8(vs[0] || 1), u8(vs[1] || 0), u8(ls.length), ...ls.map((l, i) => ucs1(dmxSource(i)))]));
  }
  function elin(ver, nums) {
    const ls = citpLayers(); const want = nums && nums.length ? nums : ls.map((l, i) => i + 1);
    const libs = want.filter(n => n >= 1 && n <= ls.length).map(n => {
      const l = ls[n - 1], count = l.clips.filter(Boolean).length, name = l.name || 'Layer ' + n;
      if (ver[1] >= 2) return Buffer.concat([libId(ver, n), u32(l.trig || 0), u8(0), u8(255), ucs2(name), u16(0), u16(l.clips.length)]);
      if (ver[1] === 1) return Buffer.concat([libId(ver, n), u8(0), u8(255), ucs2(name), u8(0), u8(l.clips.length)]);
      return Buffer.concat([u8(n), u8(0), u8(255), ucs2(name), u8(l.clips.length)]);
    });
    return msex(ver, 'ELIn', Buffer.concat([u8(1), ver[1] >= 2 ? u16(libs.length) : u8(libs.length), ...libs]));
  }
  async function mediaMeta(clip) { // width/height/frames/fps from the preflight cache when available
    const hit = Object.entries(pfCache).find(([k]) => k.startsWith((clip.src || '') + '|')); const i = hit ? hit[1] : {};
    return { w: i.w || st().comp.width, h: i.h || st().comp.height, fps: Math.round(i.fps || 30), frames: Math.round((i.dur || 0) * (i.fps || 30)) };
  }
  async function mein(ver, lib, nums) {
    const l = citpLayers()[lib - 1]; if (!l) return null;
    const want = nums && nums.length ? nums : l.clips.map((c, i) => i);
    const els = [];
    for (const n of want) {
      const c = l.clips[n]; if (n < 0 || n >= l.clips.length) continue; const m = c ? await mediaMeta(c) : { w: 0, h: 0, fps: 0, frames: 0 };
      const name = c ? (c.name || 'Clip ' + (n + 1)) : '';
      const dmx = Math.min(255, n + 1); // PIXORA's clip channel: value 1 = clip 1 … (0 = clear)
      els.push(Buffer.concat([u8(n), ...(ver[1] >= 2 ? [u32(0)] : []), u8(dmx), u8(dmx), ucs2(name), u64(Date.now() / 1000), u16(m.w), u16(m.h), u32(m.frames), u8(m.fps)]));
    }
    return msex(ver, 'MEIn', Buffer.concat([libId(ver, lib), ver[1] >= 2 ? u16(els.length) : u8(els.length), ...els]));
  }
  function jpegSize(b) { let o = 2; while (o < b.length - 9) { if (b[o] !== 0xFF) { o++; continue; } const m = b[o + 1]; if (m >= 0xC0 && m <= 0xC3) return { h: b.readUInt16BE(o + 5), w: b.readUInt16BE(o + 7) }; o += 2 + b.readUInt16BE(o + 2); } return { w: 0, h: 0 }; }
  function ethn(ver, lib, n) {
    const l = citpLayers()[lib - 1]; const c = l && l.clips[n]; if (!c) return null;
    let jpg = null; try { const f = ctx.thumbFile(c.src || ''); if (f && fs.existsSync(f)) jpg = fs.readFileSync(f); } catch {}
    if (!jpg) jpg = BLACK_JPEG; if (jpg.length > 65000) return null;
    const sz = jpegSize(jpg);
    return msex(ver, 'EThn', Buffer.concat([u8(1), libId(ver, lib), u8(n), cookie('JPEG'), u16(sz.w), u16(sz.h), u16(jpg.length), jpg]));
  }
  const BLACK_JPEG = Buffer.from('/9j/4AAQSkZJRgABAgAAAQABAAD//gAQTGF2YzYwLjMxLjEwMgD/2wBDAAgQEBMQExYWFhYWFhoYGhsbGxoaGhobGxsdHR0iIiIdHR0bGx0dICAiIiUmJSMjIiMmJigoKDAwLi44ODpFRVP/xABLAAEBAAAAAAAAAAAAAAAAAAAACAEBAAAAAAAAAAAAAAAAAAAAABABAAAAAAAAAAAAAAAAAAAAABEBAAAAAAAAAAAAAAAAAAAAAP/AABEIACQAQAMBIgACEQADEQD/2gAMAwEAAhEDEQA/AJ/AAAAAAAAAAAAAAAAAAAAAAAB//9k=', 'base64');
  function lsta(ver) {
    const s = st(), ls = citpLayers();
    const body = [u8(ls.length)];
    ls.forEach((l, i) => {
      const c = l.active != null ? l.clips[l.active] : null;
      const flags = (c ? 0x0001 : 0) | (l.paused ? 0x0008 : 0) | ((c && c.loop === 'loop') ? 0x0004 : 0);
      body.push(u8(i), u8(0), ...(ver[1] >= 2 ? [u8(1), libId(ver, i + 1)] : [u8(i + 1)]), u8(c ? l.active : 0), ucs2(c ? c.name || '' : ''), u32(0), u32(0), u8(30), u32(flags));
    });
    return msex(ver, 'LSta', Buffer.concat(body));
  }
  function parseHdr(b) { if (b.length < 20 || b.toString('latin1', 0, 4) !== 'CITP') return null; return { size: b.readUInt32LE(8), content: b.toString('latin1', 16, 20) }; }
  async function citpHandle(sock, msg) {
    const h = parseHdr(msg); if (!h || h.content !== 'MSEX') return;
    const ver = [msg[20], msg[21]], type = msg.toString('latin1', 22, 26), d = msg.subarray(26);
    const reply = b => { if (b && !sock.destroyed) sock.write(b); };
    try {
      if (type === 'CInf') {
        const n = d[0], vs = []; for (let i = 0; i < n; i++) vs.push([d[1 + i * 2], d[2 + i * 2]]);
        const best = vs.filter(v => v[0] === 1 && v[1] <= 2).sort((a, b) => b[1] - a[1])[0] || [1, 0]; sock.msexVer = best;
        citpLog(`${sock.remoteAddress} hello, MSEX ${best.join('.')}`); reply(sinf(best));
      } else if (type === 'GELI') {
        const v = ver; let nums = [];
        if (v[1] >= 1) { const cnt = v[1] >= 2 ? d.readUInt16LE(5) : d[5]; const o = v[1] >= 2 ? 7 : 6; for (let i = 0; i < cnt; i++) nums.push(d[o + i]); }
        else { const cnt = d[1]; for (let i = 0; i < cnt; i++) nums.push(d[2 + i]); }
        // 1.1+: a request for the root (level 0) lists every layer library
        if (v[1] >= 1 && d[1] === 0) nums = [];
        citpLog('library list requested'); reply(elin(v, nums));
      } else if (type === 'GEIn') {
        const v = ver; let lib, cnt, o;
        if (v[1] >= 1) { lib = d[2]; cnt = v[1] >= 2 ? d.readUInt16LE(5) : d[5]; o = v[1] >= 2 ? 7 : 6; } else { lib = d[1]; cnt = d[2]; o = 3; }
        const nums = []; for (let i = 0; i < cnt; i++) nums.push(d[o + i]);
        reply(await mein(v, lib, nums));
      } else if (type === 'GETh') {
        const v = ver; let p = 9, lib, cnt;
        if (v[1] >= 1) { lib = d[p + 2]; p += 5; } else { lib = d[p]; p += 1; } // libType(1) + id
        cnt = v[1] >= 2 ? d.readUInt16LE(p) : d[p]; p += v[1] >= 2 ? 2 : 1;
        let nums = []; for (let i = 0; i < cnt; i++) nums.push(d[p + i]);
        const l = citpLayers()[lib - 1]; if (!nums.length && l) nums = l.clips.map((c, i) => i).filter(i => l.clips[i]);
        citpLog(`thumbnails layer ${lib}: ${nums.length}`);
        for (const n of nums) reply(ethn(v, lib, n));
      } else if (type === 'RqSt' || type === 'GVSr') { reply(msex(ver, 'Nack', cookie(type))); }
    } catch (e) { citpLog('error ' + type + ': ' + e.message); }
  }
  function citpStart() {
    citpStop(); const s = st(); if (!s.citp.on) return;
    citp.tcp = net.createServer(sock => {
      citp.peers.add(sock); sock.msexVer = [1, 2]; let buf = Buffer.alloc(0);
      sock.on('data', d => { buf = Buffer.concat([buf, d]); while (buf.length >= 20) { const h = parseHdr(buf); if (!h) { buf = Buffer.alloc(0); break; } if (buf.length < h.size) break; const m = buf.subarray(0, h.size); buf = buf.subarray(h.size); citpHandle(sock, m); } });
      const bye = () => citp.peers.delete(sock); sock.on('close', bye); sock.on('error', bye);
    });
    citp.tcp.on('error', e => citpLog('TCP error ' + e.message));
    citp.tcp.listen(0, () => {
      citp.port = citp.tcp.address().port;
      citp.udp = dgram.createSocket({ type: 'udp4', reuseAddr: true }); citp.udp.on('error', () => {});
      citp.udp.bind(4809, () => { for (const g of CITP_MC) try { citp.udp.addMembership(g); } catch {} try { citp.udp.setMulticastTTL(4); } catch {} });
      const ploc = () => citpPacket('PINF', Buffer.concat([cookie('PLoc'), u16(citp.port), ucs1('MediaServer'), ucs1(st().citp.name || 'PIXORA'), ucs1('Running')]));
      const beacon = () => { const b = ploc(); for (const g of CITP_MC) try { citp.udp.send(b, 4809, g); } catch {} };
      beacon(); citp.timer = setInterval(beacon, 1000);
      citp.lsta = setInterval(() => { for (const p of citp.peers) if (!p.destroyed) p.write(lsta(p.msexVer || [1, 2])); }, 250);
      citpLog(`CITP on TCP ${citp.port}, announcing on 4809`);
    });
  }
  function citpStop() { clearInterval(citp.timer); clearInterval(citp.lsta); for (const p of citp.peers) p.destroy(); citp.peers.clear(); try { citp.tcp && citp.tcp.close(); } catch {} try { citp.udp && citp.udp.close(); } catch {} citp.tcp = citp.udp = null; citp.port = 0; }

  /* =========================================================== zip reader (MVR, updates) */
  function unzip(buf) {
    let e = buf.length - 22; while (e >= 0 && buf.readUInt32LE(e) !== 0x06054b50) e--; if (e < 0) throw new Error('not a zip file');
    const n = buf.readUInt16LE(e + 10); let o = buf.readUInt32LE(e + 16); const files = {};
    for (let i = 0; i < n; i++) {
      if (buf.readUInt32LE(o) !== 0x02014b50) break;
      const method = buf.readUInt16LE(o + 10), csize = buf.readUInt32LE(o + 20), nl = buf.readUInt16LE(o + 28), xl = buf.readUInt16LE(o + 30), cl = buf.readUInt16LE(o + 32), lo = buf.readUInt32LE(o + 42);
      const name = buf.toString('utf8', o + 46, o + 46 + nl); o += 46 + nl + xl + cl;
      const lnl = buf.readUInt16LE(lo + 26), lxl = buf.readUInt16LE(lo + 28); const data = buf.subarray(lo + 30 + lnl + lxl, lo + 30 + lnl + lxl + csize);
      if (name.endsWith('/')) continue;
      files[name] = method === 0 ? data : method === 8 ? zlib.inflateRawSync(data) : null;
    }
    return files;
  }

  /* =========================================================== 6. MVR import (stage layout from grandMA3 / Vectorworks / Capture …) */
  const attr = (s, k) => { const m = new RegExp('\\b' + k + '="([^"]*)"').exec(s); return m ? m[1] : ''; };
  function parseMatrix(m) { // {u1,u2,u3}{v1,v2,v3}{w1,w2,w3}{o1,o2,o3} in mm
    const n = (m || '').match(/-?[\d.]+(?:e-?\d+)?/gi); if (!n || n.length < 12) return { o: [0, 0, 0], u: [1, 0, 0], v: [0, 1, 0], w: [0, 0, 1] };
    const v = n.map(Number); return { u: v.slice(0, 3), v: v.slice(3, 6), w: v.slice(6, 9), o: v.slice(9, 12) };
  }
  function glbBounds(b) { // POSITION accessor min/max of a binary glTF
    if (b.toString('latin1', 0, 4) !== 'glTF') return null; const jl = b.readUInt32LE(12); const j = JSON.parse(b.toString('utf8', 20, 20 + jl));
    let mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
    for (const m of j.meshes || []) for (const p of m.primitives || []) { const a = j.accessors[p.attributes.POSITION]; if (a && a.min && a.max) for (let i = 0; i < 3; i++) { mn[i] = Math.min(mn[i], a.min[i]); mx[i] = Math.max(mx[i], a.max[i]); } }
    return isFinite(mn[0]) ? { size: [mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]], unit: 'm' } : null;
  }
  function tdsBounds(b) { // 3DS: vertex list chunks 0x4110 (units usually mm)
    let mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
    const walk = (s, e) => { let o = s; while (o + 6 <= e) { const id = b.readUInt16LE(o), len = b.readUInt32LE(o + 2); if (len < 6 || o + len > e) break;
      if (id === 0x4D4D || id === 0x3D3D || id === 0x4000 || id === 0x4100) { const skip = id === 0x4000 ? (() => { let k = o + 6; while (b[k]) k++; return k + 1 - o; })() : 6; walk(o + skip, o + len); }
      else if (id === 0x4110) { const n = b.readUInt16LE(o + 6); for (let i = 0; i < n; i++) for (let a = 0; a < 3; a++) { const v = b.readFloatLE(o + 8 + i * 12 + a * 4); mn[a] = Math.min(mn[a], v); mx[a] = Math.max(mx[a], v); } }
      o += len; } };
    try { walk(0, b.length); } catch {}
    return isFinite(mn[0]) ? { size: [mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]], unit: 'mm' } : null;
  }
  function parseMvr(buf) {
    const files = unzip(buf); const xmlName = Object.keys(files).find(f => /GeneralSceneDescription\.xml$/i.test(f)); if (!xmlName) throw new Error('GeneralSceneDescription.xml not found — is this an MVR file?');
    const xml = files[xmlName].toString('utf8');
    const screens = [], fixtures = [], objects = [];
    const re = /<(VideoScreen|Fixture|SceneObject|Truss|Projector)\b([^>]*)>([\s\S]*?)<\/\1>/g; let m;
    while ((m = re.exec(xml))) {
      const [, tag, attrs, inner] = m; const name = attr(attrs, 'name') || attr(attrs, 'Name') || tag;
      const mat = parseMatrix((/<Matrix>([^<]*)<\/Matrix>/.exec(inner) || [])[1]);
      const pos = mat.o.map(x => x / 1000); // mm → m
      const ry = Math.round(Math.atan2(mat.u[1], mat.u[0]) * 180 / Math.PI); // rotation about the vertical (MVR Z-up)
      const geoFile = (/fileName="([^"]+)"/.exec(inner) || [])[1] || '';
      if (tag === 'VideoScreen' || (tag === 'SceneObject' && /screen|led|wall|video/i.test(name))) {
        let size = null; const gf = geoFile && Object.keys(files).find(f => f.toLowerCase().endsWith(geoFile.toLowerCase()) || f.toLowerCase().endsWith(geoFile.toLowerCase() + '.glb') || f.toLowerCase().endsWith(geoFile.toLowerCase() + '.3ds'));
        if (gf) { const b = files[gf]; size = /\.glb$/i.test(gf) ? glbBounds(b) : /\.3ds$/i.test(gf) ? tdsBounds(b) : null; }
        let wm = 4, hm = 2.25, sized = false;
        if (size) { const k = size.unit === 'mm' ? 1 / 1000 : 1; const dims = size.size.map(x => Math.abs(x) * k); wm = Math.max(dims[0], dims[1]) || wm; hm = dims[2] || Math.min(dims[0], dims[1]) || hm; sized = true; }
        screens.push({ name, x: pos[0], y: pos[2], z: -pos[1], ry, wm: +wm.toFixed(3), hm: +hm.toFixed(3), sized, source: tag });
      } else if (tag === 'Fixture') fixtures.push({ name, x: pos[0], y: pos[2], z: -pos[1], gdtf: attr(inner.replace(/\n/g, ' '), 'x') || (/<GDTFSpec>([^<]*)</.exec(inner) || [])[1] || '', addr: (/<Address[^>]*>([^<]*)</.exec(inner) || [])[1] || '' });
      else objects.push({ name, tag, x: pos[0], y: pos[2], z: -pos[1] });
    }
    const layers = (xml.match(/<Layer\b[^>]*name="([^"]*)"/g) || []).map(s => attr(s, 'name'));
    return { file: xmlName, version: attr(xml.slice(0, 400), 'verMajor') + '.' + attr(xml.slice(0, 400), 'verMinor'), screens, fixtures: fixtures.slice(0, 2000), objects: objects.slice(0, 500), layers };
  }
  function applyMvr(scene, opt) {
    const s = st(); const pw = +opt.panelMm || 500, ph = +opt.panelMmH || pw, ppx = +opt.panelPx || 128, ppy = +opt.panelPxH || ppx;
    const added = [];
    for (const sc of scene.screens.filter(x => !opt.only || opt.only.includes(x.name))) {
      const cols = Math.max(1, Math.round(sc.wm * 1000 / pw)), rows = Math.max(1, Math.round(sc.hm * 1000 / ph));
      ctx.applyCmd({ op: 'ledAddScreen' }, { mvr: true });
      const i = s.led.screens.length - 1, scr = s.led.screens[i];
      const vals = { name: sc.name, cols, rows }; for (const k of Object.keys(vals)) if (k in scr) scr[k] = vals[k];
      for (const [a, b] of [['panelW', ppx], ['panelH', ppy], ['pw', ppx], ['ph', ppy], ['panelMmW', pw], ['panelMmH', ph], ['mmW', pw], ['mmH', ph]]) if (a in scr) scr[a] = b;
      scr.pos3d = Object.assign(scr.pos3d || {}, { x: sc.x, y: sc.y, z: sc.z, ry: sc.ry, rx: 0 });
      added.push({ name: sc.name, cols, rows });
    }
    ctx.markDirty(); ctx.broadcastState();
    return added;
  }

  /* =========================================================== 7. users, roles, sessions */
  const USERS = path.join(DATA, 'users.json'), SESS = path.join(DATA, 'sessions.json');
  let users = readJ(USERS, []), sessions = readJ(SESS, {});
  const hashPw = (pw, salt) => crypto.scryptSync(String(pw), salt, 32).toString('hex');
  const ROLES = { admin: 'op', operator: 'op', client: 'client', viewer: 'view' };
  function cookieMap(h) { const o = {}; (h || '').split(';').forEach(p => { const i = p.indexOf('='); if (i > 0) o[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); }); return o; }
  function session(req, url) {
    const tok = (req.headers.authorization || '').replace(/^Bearer /, '') || cookieMap(req.headers.cookie).pxsess || (url && url.searchParams.get('token')) || '';
    const s = tok && sessions[tok]; if (!s) return null; if (s.exp < Date.now()) { delete sessions[tok]; writeJ(SESS, sessions); return null; }
    const u = users.find(x => x.user === s.user); return u ? { user: u.user, role: u.role, token: tok } : null;
  }
  function authRole(req, url) { // undefined → legacy PIN handling
    const appTok = process.env.PIXORA_APP_TOKEN; // the desktop app's own menu commands (secret passed from the app that started this server)
    if (appTok && req.headers && req.headers['x-app-token'] && crypto.timingSafeEqual(Buffer.from(String(req.headers['x-app-token']).padEnd(64).slice(0, 64)), Buffer.from(appTok.padEnd(64).slice(0, 64)))) return 'op';
    if (!users.length) return undefined;
    const s = session(req, url); if (s) return ROLES[s.role] || 'view';
    const pin = req.headers['x-pin'] || (url && url.searchParams.get('pin')) || cookieMap(req.headers.cookie).bvjpin;
    if (ctx.PIN && pin === ctx.PIN) return 'op'; // the operator PIN still works as a master key
    const ip = (req.socket.remoteAddress || '').replace('::ffff:', '');
    // output windows on this same computer (launcher / desktop app) don't need a login; tunnelled requests carry forwarding headers and never match
    const local = (ip === '127.0.0.1' || ip === '::1') && !req.headers['cf-connecting-ip'] && !req.headers['x-forwarded-for'] && !req.headers['x-real-ip'];
    if (local && url) { const pth = url.pathname; if (pth === '/ws' && url.searchParams.get('role') === 'output') return 'op'; if (req.method === 'GET' && (/^\/(media|thumb)\//.test(pth) || ['/api/hap', '/api/info', '/api/state'].includes(pth)) && /^\/output(\.html)?$/.test(String(req.headers.referer || '').replace(/^https?:\/\/[^/]+/, '').split('?')[0])) return 'view'; }
    return null;
  }
  const isAdmin = (req, url) => { if (!users.length) return true; const s = session(req, url); return !!(s && s.role === 'admin') || (ctx.PIN && ((url && url.searchParams.get('pin')) || cookieMap(req.headers.cookie).bvjpin) === ctx.PIN); };
  const userList = () => users.map(u => ({ user: u.user, role: u.role, created: u.created, last: u.last || 0 }));

  /* =========================================================== 8. remote access (Cloudflare quick tunnel) */
  const tunnel = { proc: null, url: '', status: 'off', log: [] };
  function cloudflaredPath() {
    const cands = ['cloudflared', path.join(ROOT, 'cloudflared'), path.join(ROOT, 'cloudflared.exe'), '/opt/homebrew/bin/cloudflared', '/usr/local/bin/cloudflared', 'C:\\Program Files (x86)\\cloudflared\\cloudflared.exe', 'C:\\Program Files\\cloudflared\\cloudflared.exe'];
    for (const c of cands) { try { if (spawnSync(c, ['--version'], { timeout: 4000 }).status === 0) return c; } catch {} }
    return null;
  }
  function tunnelStart() {
    if (tunnel.proc) return tunnel;
    if (!users.length && !ctx.PIN) { tunnel.status = 'error'; tunnel.err = 'Set up at least one user (or a PIN) first — remote access is never opened without a login.'; return tunnel; }
    const bin = cloudflaredPath(); if (!bin) { tunnel.status = 'error'; tunnel.err = 'cloudflared is not installed. Windows: winget install Cloudflare.cloudflared · Mac: brew install cloudflared'; return tunnel; }
    tunnel.status = 'starting'; tunnel.err = ''; tunnel.url = '';
    const p = spawn(bin, ['tunnel', '--no-autoupdate', '--url', `http://localhost:${PORT}`]); tunnel.proc = p;
    const scan = d => { const t = String(d); tunnel.log.push(...t.split('\n').filter(Boolean).slice(-5)); tunnel.log = tunnel.log.slice(-30);
      const m = /https:\/\/[a-z0-9-]+\.trycloudflare\.com/.exec(t); if (m && !tunnel.url) { tunnel.url = m[0]; tunnel.status = 'on'; monitor('access', 'Remote access on ' + tunnel.url); broadcast({ t: 'tunnel', tunnel: tunnelInfo() }); } };
    p.stdout.on('data', scan); p.stderr.on('data', scan);
    p.on('close', () => { tunnel.proc = null; tunnel.status = 'off'; tunnel.url = ''; broadcast({ t: 'tunnel', tunnel: tunnelInfo() }); });
    p.on('error', e => { tunnel.proc = null; tunnel.status = 'error'; tunnel.err = e.message; });
    return tunnel;
  }
  function tunnelStop() { if (tunnel.proc) try { tunnel.proc.kill(); } catch {} tunnel.proc = null; tunnel.status = 'off'; tunnel.url = ''; }
  const tunnelInfo = () => ({ status: tunnel.status, url: tunnel.url, err: tunnel.err || '', log: tunnel.log.slice(-8) });

  /* =========================================================== 9. show report (PDF writer, no dependencies) */
  function pdf(pages) { // pages: [[{t:'text', x,y,size,bold,str,color}|{t:'line',x1,y1,x2,y2,w,color}|{t:'rect',x,y,w,h,color}]]
    const objs = []; const add = s => { objs.push(s); return objs.length; };
    const fontR = add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
    const fontB = add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
    const pagesId = objs.length + 1; objs.push(null); const kids = [];
    const esc = s => String(s).replace(/[\\()]/g, m => '\\' + m).replace(/[^\x20-\x7e\xa0-\xff]/g, c => ({ '—': '\x97', '–': '\x96', '•': '\x95', '…': '\x85', '’': '\x92', '“': '\x93', '”': '\x94', '×': '\xd7' }[c] || '?'));
    const col = c => (c || [0, 0, 0]).map(v => (v / 255).toFixed(3)).join(' ');
    for (const items of pages) {
      let s = '';
      for (const it of items) {
        if (it.t === 'text') s += `BT /${it.bold ? 'F2' : 'F1'} ${it.size || 10} Tf ${col(it.color)} rg ${it.x.toFixed(1)} ${it.y.toFixed(1)} Td (${esc(it.str)}) Tj ET\n`;
        else if (it.t === 'line') s += `${col(it.color || [200, 200, 200])} RG ${it.w || 0.5} w ${it.x1} ${it.y1} m ${it.x2} ${it.y2} l S\n`;
        else if (it.t === 'rect') s += `${col(it.color)} rg ${it.x} ${it.y} ${it.w} ${it.h} re f\n`;
      }
      const stream = Buffer.from(s, 'latin1'); const sid = add(`<< /Length ${stream.length} >>\nstream\n${stream.toString('latin1')}\nendstream`);
      kids.push(add(`<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 ${fontR} 0 R /F2 ${fontB} 0 R >> >> /Contents ${sid} 0 R >>`));
    }
    objs[pagesId - 1] = `<< /Type /Pages /Kids [${kids.map(k => k + ' 0 R').join(' ')}] /Count ${kids.length} >>`;
    const cat = add(`<< /Type /Catalog /Pages ${pagesId} 0 R >>`);
    let out = '%PDF-1.4\n%\xe2\xe3\xcf\xd3\n'; const offs = [];
    objs.forEach((o, i) => { offs.push(Buffer.byteLength(out, 'latin1')); out += `${i + 1} 0 obj\n${o}\nendobj\n`; });
    const xref = Buffer.byteLength(out, 'latin1');
    out += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n` + offs.map(o => String(o).padStart(10, '0') + ' 00000 n \n').join('') + `trailer\n<< /Size ${objs.length + 1} /Root ${cat} 0 R >>\nstartxref\n${xref}\n%%EOF`;
    return Buffer.from(out, 'latin1');
  }
  function buildReport(from, to, title) {
    const s = st(); const pages = []; let page = [], y = 800;
    const BRAND = [168, 40, 255], GREY = [110, 110, 120];
    const np = () => { if (page.length) pages.push(page); page = []; y = 800; footer(); };
    const footer = () => { page.push({ t: 'text', x: 40, y: 24, size: 8, color: GREY, str: `PIXORA ${VERSION} · Booth Productions · generated ${new Date().toLocaleString()}` }); };
    const need = h => { if (y - h < 50) np(); };
    const text = (str, o = {}) => { need((o.size || 10) + 6); page.push({ t: 'text', x: o.x || 40, y, size: o.size || 10, bold: o.bold, color: o.color, str }); if (!o.keep) y -= (o.size || 10) + (o.gap ?? 5); };
    const rule = () => { page.push({ t: 'line', x1: 40, y1: y + 4, x2: 555, y2: y + 4 }); y -= 8; };
    const table = (cols, rows, widths) => {
      need(30); let x = 40; page.push({ t: 'rect', x: 40, y: y - 4, w: 515, h: 16, color: [240, 236, 250] });
      cols.forEach((c, i) => { page.push({ t: 'text', x: x + 4, y, size: 8.5, bold: true, str: c }); x += widths[i]; }); y -= 16;
      for (const r of rows) { need(14); x = 40; r.forEach((c, i) => { const w = widths[i]; const maxc = Math.floor(w / 4.4); let v = String(c ?? ''); if (v.length > maxc) v = v.slice(0, maxc - 1) + '…'; page.push({ t: 'text', x: x + 4, y, size: 8.5, str: v }); x += w; }); y -= 13; }
      y -= 6;
    };
    footer();
    page.push({ t: 'rect', x: 0, y: 812, w: 595, h: 30, color: [12, 10, 20] });
    page.push({ t: 'text', x: 40, y: 822, size: 14, bold: true, color: [255, 255, 255], str: 'PIXORA' });
    page.push({ t: 'text', x: 110, y: 822, size: 11, color: [200, 190, 230], str: 'Show report' }); y = 780;
    text(title || 'Show report', { size: 20, bold: true, gap: 8 });
    text(`Period: ${from || 'all'} to ${to || 'today'}   ·   Composition ${s.comp.width}×${s.comp.height} @ ${s.comp.fps || 60} fps`, { color: GREY, gap: 14 });
    const pop = ctx.popRows(from, to); const rows = pop.rows || [];
    const byName = {}; for (const r of rows) { const k = r[2] || r[1] || '?'; byName[k] = byName[k] || { plays: 0, secs: 0 }; byName[k].plays++; byName[k].secs += +r[4] || +r[3] || 0; }
    text('Summary', { size: 13, bold: true }); rule();
    const outs = [...ostats.values()];
    const kv = [['Sponsor / content plays logged', rows.length], ['Distinct items', Object.keys(byName).length], ['Cues in show', s.cues.length], ['Outputs connected now', outs.length],
      ['Worst frame-drop rate (current session)', outs.length ? Math.max(...outs.map(o => o.dropRate || 0)).toFixed(2) + ' %' : 'n/a'], ['Server uptime', (process.uptime() / 3600).toFixed(1) + ' h']];
    for (const [k, v] of kv) { text(k, { keep: true }); text(String(v), { x: 330, bold: true }); }
    y -= 8; text('Proof of play by item', { size: 13, bold: true }); rule();
    table(['Item', 'Plays', 'Total time'], Object.entries(byName).sort((a, b) => b[1].plays - a[1].plays).slice(0, 60).map(([k, v]) => [k, v.plays, fmtDur(v.secs)]), [335, 80, 100]);
    y -= 4; text('Play log', { size: 13, bold: true }); rule();
    const hdr = (pop.hdr || '').split(','); table(hdr.slice(0, 5).map(h => h.replace(/"/g, '')), rows.slice(-400).map(r => r.slice(0, 5)), [120, 95, 150, 80, 70]);
    const events = []; for (const o of outs) for (const e of o.events || []) events.push([new Date(e.at).toLocaleString(), o.name, e.msg]);
    for (const e of ctx.monitorLog().filter(e => /show|error|access|backup|fail/i.test(e.kind + ' ' + e.text)).slice(-80)) events.push([new Date(e.at).toLocaleString(), e.kind, e.text]);
    y -= 4; text('Incidents & system events', { size: 13, bold: true }); rule();
    if (events.length) table(['Time', 'Source', 'Event'], events.slice(-120), [120, 90, 305]); else text('None recorded.', { color: GREY });
    y -= 4; text('Changes made during the show', { size: 13, bold: true }); rule();
    const ch = ctx.changeLog().filter(c => (!from || new Date(c.at).toISOString().slice(0, 10) >= from) && (!to || new Date(c.at).toISOString().slice(0, 10) <= to));
    if (ch.length) table(['Time', 'Who', 'What'], ch.slice(-150).map(c => [new Date(c.at).toLocaleString(), c.who, c.summary]), [120, 90, 305]); else text('None recorded.', { color: GREY });
    pages.push(page);
    return pdf(pages);
  }
  const fmtDur = s => { s = Math.round(s); return s >= 3600 ? `${Math.floor(s / 3600)}h ${Math.floor(s % 3600 / 60)}m` : `${Math.floor(s / 60)}m ${s % 60}s`; };

  /* =========================================================== 10. web proxy for websites that refuse to be embedded */
  async function webProxy(req, res, url) {
    const target = url.searchParams.get('u') || ''; let tu; try { tu = new URL(target); } catch { return send(res, 400, 'bad url', 'text/plain'); }
    if (!/^https?:$/.test(tu.protocol)) return send(res, 400, 'only http(s)', 'text/plain');
    const opt = { zoom: +url.searchParams.get('zoom') || 1, scroll: +url.searchParams.get('scroll') || 0, transparent: url.searchParams.get('transparent') === '1', css: url.searchParams.get('css') || '', loop: url.searchParams.get('loop') !== '0' };
    let r; try { r = await fetch(tu, { headers: { 'User-Agent': 'Mozilla/5.0 (PIXORA media server) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Safari/537.36', 'Accept-Language': req.headers['accept-language'] || 'en' }, redirect: 'follow' }); }
    catch (e) { return send(res, 502, `<html><body style="background:#111;color:#eee;font:20px sans-serif;display:grid;place-items:center;height:100vh">Can't reach ${tu.host}: ${String(e.message).replace(/</g, '')}</body></html>`, 'text/html'); }
    const type = r.headers.get('content-type') || 'text/html';
    // sandboxed opaque origin: proxied pages can run scripts but can never touch PIXORA's API or cookies
    const headers = { 'Content-Type': type, 'Cache-Control': 'no-store', 'Content-Security-Policy': 'sandbox allow-scripts allow-forms allow-popups allow-pointer-lock' };
    if (!/text\/html/i.test(type)) { res.writeHead(r.status, headers); return res.end(Buffer.from(await r.arrayBuffer())); }
    let html = await r.text(); const finalUrl = r.url || tu.href;
    html = html.replace(/<meta[^>]+http-equiv=["']?(content-security-policy|x-frame-options)[^>]*>/gi, '');
    const inject = `<base href="${finalUrl.replace(/"/g, '&quot;')}"><style id="pixora-web">${opt.transparent ? 'html,body{background:transparent!important}' : ''}${opt.zoom !== 1 ? `html{zoom:${opt.zoom}}` : ''}${opt.scroll ? 'html,body{scrollbar-width:none}::-webkit-scrollbar{display:none}' : ''}${opt.css.replace(/<\/style/gi, '')}</style>` +
      (opt.scroll ? `<script>(function(){var sp=${opt.scroll},loop=${opt.loop},last=0,y=0;function f(t){if(last){y+=sp*(t-last)/1000;var max=document.documentElement.scrollHeight-innerHeight;if(y>max+40){y=loop?0:max}window.scrollTo(0,y)}last=t;requestAnimationFrame(f)}requestAnimationFrame(f)})()</script>` : '');
    html = /<head[^>]*>/i.test(html) ? html.replace(/<head[^>]*>/i, m => m + inject) : inject + html;
    res.writeHead(r.status, headers); res.end(html);
  }

  /* =========================================================== 11. updates */
  const updateState = { checking: false, latest: null, err: '', applying: false, progress: 0, staged: '' };
  const verCmp = (a, b) => { const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) - (pb[i] || 0); } return 0; };
  async function updateCheck() {
    const feed = st().update.feed; if (!feed) { updateState.err = 'No update feed URL set'; return updateState; }
    updateState.checking = true; updateState.err = '';
    try { const r = await fetch(feed, { cache: 'no-store' }); if (!r.ok) throw new Error('HTTP ' + r.status); const j = await r.json(); updateState.latest = { ...j, newer: verCmp(j.version, VERSION) > 0 }; }
    catch (e) { updateState.err = 'Update check failed: ' + e.message; }
    updateState.checking = false; return updateState;
  }
  async function updateApply() {
    const L = updateState.latest; if (!L || !L.newer || !L.url) throw new Error('No newer version available — check first');
    updateState.applying = true; updateState.progress = 0; updateState.err = '';
    try {
      const r = await fetch(new URL(L.url, st().update.feed)); if (!r.ok) throw new Error('download HTTP ' + r.status);
      const buf = Buffer.from(await r.arrayBuffer()); updateState.progress = 60;
      if (L.sha256 && crypto.createHash('sha256').update(buf).digest('hex') !== String(L.sha256).toLowerCase()) throw new Error('checksum mismatch — download rejected');
      if (!L.sha256) throw new Error('update manifest has no sha256 — refusing to install an unverified update');
      const files = unzip(buf); const names = Object.keys(files);
      const prefix = names.every(n => n.startsWith('PIXORA/')) ? 'PIXORA/' : '';
      if (!names.includes(prefix + 'server.js') || !names.includes(prefix + 'package.json')) throw new Error('update package does not contain server.js/package.json');
      const backup = path.join(ROOT, '.backup', VERSION); fs.mkdirSync(backup, { recursive: true });
      for (const f of fs.readdirSync(ROOT).filter(f => /^server[\w-]*\.js$/.test(f)).concat('package.json')) try { fs.copyFileSync(path.join(ROOT, f), path.join(backup, f)); } catch {}
      try { fs.cpSync(path.join(ROOT, 'public'), path.join(backup, 'public'), { recursive: true }); } catch {}
      let n = 0;
      for (const name of names) {
        const rel = name.slice(prefix.length); if (!rel || !/^(server[\w-]*\.js|package\.json|public\/.+|README\.md|tests\/.+)$/.test(rel) || rel.includes('..')) continue;
        const dst = path.join(ROOT, rel); fs.mkdirSync(path.dirname(dst), { recursive: true }); fs.writeFileSync(dst, files[name]); n++;
      }
      updateState.progress = 100; updateState.staged = `${n} files updated to ${L.version} — restarting`; monitor('update', updateState.staged);
      broadcast({ t: 'update', update: updateState });
      setTimeout(restart, 800);
    } catch (e) { updateState.err = e.message; updateState.applying = false; throw e; }
  }
  function restart() {
    if (process.env.PIXORA_LAUNCHER) process.exit(75); // the desktop launchers restart the engine on exit code 75
    const child = spawn(process.execPath, process.argv.slice(1), { detached: true, stdio: 'inherit', env: { ...process.env, PIXORA_RESTART_WAIT: '1' } }); child.unref();
    ctx.closeServer(() => process.exit(0)); setTimeout(() => process.exit(0), 3000);
  }

  /* =========================================================== multi-machine sync: clock service */
  let masterOffset = 0; // ms to add to this server's clock to get the master's clock (followers)
  function setMasterOffset(o) { masterOffset = o; }
  const now = () => Date.now() + masterOffset;

  /* =========================================================== HTTP routes */
  async function route(req, res, p, url, role) {
    if (p === '/webproxy') { if (!role) return send(res, 401, 'login required', 'text/plain'), true; await webProxy(req, res, url); return true; }
    if (!p.startsWith('/api/')) return false;
    const body = async () => { try { return JSON.parse((await readBody(req)).toString() || '{}'); } catch { return {}; } };
    const op = role === 'op';
    switch (p) {
      case '/api/auth/login': {
        const b = await body(); const u = users.find(x => x.user.toLowerCase() === String(b.user || '').toLowerCase());
        if (!u || hashPw(b.pass || '', u.salt) !== u.hash) { await new Promise(r => setTimeout(r, 600)); return send(res, 401, { error: 'Wrong user name or password' }), true; }
        const tok = crypto.randomBytes(24).toString('hex'); sessions[tok] = { user: u.user, exp: Date.now() + (b.remember ? 30 : 1) * 86400000, at: Date.now(), ip: (req.socket.remoteAddress || '') };
        u.last = Date.now(); writeJ(USERS, users); writeJ(SESS, sessions); monitor('access', `${u.user} signed in (${u.role}) from ${req.headers['cf-connecting-ip'] || req.socket.remoteAddress}`);
        res.writeHead(200, { 'Set-Cookie': `pxsess=${tok}; Path=/; Max-Age=${(b.remember ? 30 : 1) * 86400}; HttpOnly; SameSite=Lax`, 'Content-Type': 'application/json' }); res.end(JSON.stringify({ ok: true, user: u.user, role: u.role })); return true;
      }
      case '/api/auth/logout': { const s = session(req, url); if (s) { delete sessions[s.token]; writeJ(SESS, sessions); } res.writeHead(200, { 'Set-Cookie': 'pxsess=; Path=/; Max-Age=0', 'Content-Type': 'application/json' }); res.end('{"ok":true}'); return true; }
      case '/api/auth/me': { const s = session(req, url); send(res, 200, { users: users.length > 0, user: s ? s.user : null, role: s ? s.role : (role === 'op' ? 'operator' : role), admin: isAdmin(req, url) }); return true; }
    }
    if (!role) return false; // server.js answers 401
    switch (p) {
      case '/api/users': {
        if (req.method === 'GET') return send(res, 200, { users: userList(), admin: isAdmin(req, url) }), true;
        if (!isAdmin(req, url)) return send(res, 403, { error: 'Only admins can manage users' }), true;
        const b = await body(); const name = String(b.user || '').trim();
        if (b.action === 'delete') { const t = users.find(u => u.user === name); if (t && t.role === 'admin' && users.filter(x => x.role === 'admin').length === 1) return send(res, 400, { error: 'Keep at least one admin' }), true; users = users.filter(u => u.user !== name); for (const k in sessions) if (sessions[k].user === name) delete sessions[k]; }
        else {
          if (!/^[\w.@ -]{2,40}$/.test(name)) return send(res, 400, { error: 'User name: 2–40 letters, numbers, . @ - _' }), true;
          if (!ROLES[b.role]) return send(res, 400, { error: 'Unknown role' }), true;
          let u = users.find(x => x.user === name);
          if (!u) { if (!b.pass || String(b.pass).length < 6) return send(res, 400, { error: 'Password must be at least 6 characters' }), true; if (!users.length && b.role !== 'admin') return send(res, 400, { error: 'The first user must be an admin' }), true; u = { user: name, created: Date.now() }; users.push(u); }
          if (u.role === 'admin' && b.role !== 'admin' && users.filter(x => x.role === 'admin').length === 1) return send(res, 400, { error: 'Keep at least one admin' }), true;
          u.role = b.role; if (b.pass) { if (String(b.pass).length < 6) return send(res, 400, { error: 'Password must be at least 6 characters' }), true; u.salt = crypto.randomBytes(16).toString('hex'); u.hash = hashPw(b.pass, u.salt); for (const k in sessions) if (sessions[k].user === name && b.user !== (session(req, url) || {}).user) delete sessions[k]; }
        }
        writeJ(USERS, users); writeJ(SESS, sessions); monitor('access', `user ${name} ${b.action === 'delete' ? 'removed' : 'saved'}`); return send(res, 200, { users: userList() }), true;
      }
      case '/api/tunnel': {
        if (req.method === 'POST') { if (!isAdmin(req, url)) return send(res, 403, { error: 'Admins only' }), true; const b = await body(); if (b.on) tunnelStart(); else tunnelStop(); }
        return send(res, 200, tunnelInfo()), true;
      }
      case '/api/ostats': return send(res, 200, { list: [...ostats.values()] }), true;
      case '/api/preflight': { if (!op) return send(res, 403, { error: 'operator only' }), true; return send(res, 200, await preflight(url.searchParams.get('force') === '1')), true; }
      case '/api/optimise': { if (!op) return send(res, 403, { error: 'operator only' }), true; if (!ctx.ffmpegOk()) return send(res, 400, { error: 'ffmpeg is needed to optimise media' }), true; const b = await body(); return send(res, 200, { jobs: optimise(b.keys || [], b) }), true; }
      case '/api/optjobs': return send(res, 200, { jobs: optJobs.slice(-40).map(({ abs, out, ...j }) => j) }), true;
      case '/api/hap': return send(res, 200, await hapList()), true;
      case '/api/citp': return send(res, 200, { on: !!citp.tcp, port: citp.port, peers: [...citp.peers].map(p => p.remoteAddress + (p.msexVer ? ' (MSEX ' + p.msexVer.join('.') + ')' : '')), log: citp.log.slice(-20), uuid: SERVER_UUID }), true;
      case '/api/mvr': {
        if (!op) return send(res, 403, { error: 'operator only' }), true;
        const buf = await readBody(req, 512 * 1024 * 1024); const scene = parseMvr(buf);
        if (url.searchParams.get('apply') === '1') { const opt = JSON.parse(url.searchParams.get('opt') || '{}'); scene.added = applyMvr(scene, opt); monitor('mvr', `MVR import: ${scene.added.length} screens added`); }
        return send(res, 200, scene), true;
      }
      case '/api/report': {
        const from = url.searchParams.get('from') || '', to = url.searchParams.get('to') || '';
        const b = buildReport(from, to, url.searchParams.get('title') || ''); res.writeHead(200, { 'Content-Type': 'application/pdf', 'Content-Disposition': `inline; filename="PIXORA report ${from || 'all'}${to && to !== from ? ' to ' + to : ''}.pdf"` }); res.end(b); return true;
      }
      case '/api/update': {
        if (req.method === 'POST') { if (!isAdmin(req, url)) return send(res, 403, { error: 'Admins only' }), true; const b = await body();
          if (b.action === 'check') await updateCheck();
          else if (b.action === 'apply' && process.env.PIXORA_NATIVE) { // installed desktop app: updates come as a new signed installer
            const L = updateState.latest || {}; const key = process.env.PIXORA_NATIVE === 'darwin' ? (process.arch === 'arm64' ? 'mac-arm64' : 'mac-x64') : process.env.PIXORA_NATIVE === 'win32' ? 'win' : 'linux';
            const dl = L.installers && (L.installers[key] || L.installers[key.split('-')[0]]); if (!dl) return send(res, 400, { error: 'This update feed has no installer for this computer (installers.' + key + ')', ...updateState }), true;
            return send(res, 200, { version: VERSION, native: true, download: new URL(dl, st().update.feed).href, ...updateState }), true; }
          else if (b.action === 'apply') { try { await updateApply(); } catch (e) { return send(res, 400, { error: e.message, ...updateState }), true; } } }
        return send(res, 200, { version: VERSION, native: !!process.env.PIXORA_NATIVE, ...updateState }), true;
      }
      case '/api/timesync': return send(res, 200, { t: now() }), true;
    }
    return false;
  }

  /* =========================================================== WebSocket messages */
  function onMessage(c, m) {
    if (m.t === 'ostat' && c.role === 'output') { outputStats(c, m); return true; }
    if (m.t === 'tping') { c.send({ t: 'tpong', c: m.c, s: now() }); return true; }
    return false;
  }

  /* =========================================================== commands */
  function op(cmd, from) {
    const s = st();
    switch (cmd.op) {
      case 'lockShow': s.show.lock = true; if (cmd.pin != null) s.show.lockPin = String(cmd.pin); monitor('show', 'Show locked'); return true;
      case 'unlockShow': if (s.show.lockPin && String(cmd.pin || '') !== s.show.lockPin) throw new Error('Wrong unlock PIN'); s.show.lock = false; monitor('show', 'Show unlocked'); return true;
      case 'safeLoop': broadcast({ t: 'safe', on: !!cmd.on }); return true;
      case 'citpRestart': citpStart(); return true;
    }
    return false;
  }
  function afterChange() { // called after every applied command
    const s = st();
    if (!!citp.tcp !== !!s.citp.on) s.citp.on ? citpStart() : citpStop();
    const want = s.comp.timecode.artnetOut ? (s.comp.timecode.fps || 25) : 0; if (want !== afterChange.tc) { afterChange.tc = want; tcOutSchedule(); }
  }
  setTimeout(afterChange, 500);

  return { VERSION, hasUsers: () => users.length > 0, normalize, lockCheck, clientAllowed, authRole, route, onMessage, outputGone, op, afterChange, artTc, hapCodec, setMasterOffset, now, tunnelStop, citpStop, unzip, parseMvr, buildReport };
};
