// PIXORA ⇄ Ableton Link — Booth Productions.
// Link itself is GPL, so PIXORA does not include it: it runs Deep Symmetry's Carabiner (https://github.com/Deep-Symmetry/carabiner,
// GPL-2.0) as a separate program and talks to it over a local TCP socket (text protocol, one message per line).
//   follow: PIXORA's BPM and bar phase follow the Link session (Ableton Live, Traktor, Resolume, phones…)
//   lead:   changes to PIXORA's BPM (tap, MIDI, cues) are sent to the Link session
//   both:   either side can change the tempo
'use strict';
const net = require('net'), fs = require('fs'), path = require('path'), { spawn } = require('child_process');

module.exports = function link(ctx) { // ctx: { settings, saveSettings, state (getter), markDirty, monitor, broadcast, carabinerPath }
  const cfg = () => (ctx.settings.link = Object.assign({ on: false, mode: 'both', quantum: 4, port: 17000, latency: 0 }, ctx.settings.link || {}));
  let proc = null, sock = null, buf = '', st = { status: 'off', peers: 0, bpm: 0, beat: 0, at: 0, error: '' }, retryT = null, pollT = null, lastLinkBpm = 0, lastPixBpm = 0, ourProc = false;
  const push = () => ctx.broadcast({ t: 'linkstate', link: view() });
  function view() { return { cfg: cfg(), status: st.status, peers: st.peers, bpm: Math.round(st.bpm * 100) / 100, beat: st.beat, phase: st.bpm ? ((st.beat + (Date.now() - st.at) / 60000 * st.bpm) % cfg().quantum + cfg().quantum) % cfg().quantum : 0, error: st.error, helper: !!findHelper() }; }
  function findHelper() {
    const exe = process.platform === 'win32' ? 'Carabiner.exe' : 'Carabiner';
    for (const p of [process.env.PIXORA_CARABINER, ctx.carabinerPath && path.join(ctx.carabinerPath, exe), path.join(__dirname, 'desktop', 'link-dist', exe)].filter(Boolean)) { try { if (fs.statSync(p).isFile()) return p; } catch {} }
    return null;
  }
  function parse(line) { // status { :peers 1 :bpm 128.500000 :start 512311975 :beat 4.905970 }
    const m = /^(\S+)\s*\{(.*)\}\s*$/.exec(line.trim()); if (!m) { if (/^bad-/.test(line)) ctx.monitor('link', 'Carabiner: ' + line.trim()); return; }
    const o = {}; for (const kv of m[2].matchAll(/:([\w-]+)\s+(\S+)/g)) o[kv[1]] = kv[2] === 'true' ? true : kv[2] === 'false' ? false : +kv[2];
    if (m[1] === 'status') onStatus(o);
  }
  function onStatus(o) {
    const S = ctx.state.comp, c = cfg(), now = Date.now() - (+c.latency || 0);
    const peersWas = st.peers; Object.assign(st, { status: 'connected', peers: o.peers | 0, bpm: o.bpm, beat: o.beat, at: now, error: '' });
    if (peersWas !== st.peers) ctx.monitor('link', `${st.peers} Link peer${st.peers === 1 ? '' : 's'}`);
    if (c.mode !== 'lead' && st.bpm > 20) {
      if (Math.abs(S.bpm - st.bpm) >= 0.01 && Math.abs(st.bpm - lastLinkBpm) >= 0.005) { S.bpm = Math.round(st.bpm * 100) / 100; lastPixBpm = S.bpm; ctx.markDirty(); }
      lastLinkBpm = st.bpm;
      // bar phase: PIXORA's beat clock (comp.beatEpoch = time of a bar start) follows Link's quantum
      const q = c.quantum || 4, barMs = q * 60000 / st.bpm, ph = ((o.beat % q) + q) % q, epoch = now - ph * 60000 / st.bpm;
      const cur = (((now - (S.beatEpoch || 0)) % barMs) + barMs) % barMs, want = ph * 60000 / st.bpm, drift = Math.min(Math.abs(cur - want), barMs - Math.abs(cur - want));
      if (drift > 8) { S.beatEpoch = Math.round(epoch); ctx.markDirty(); }
    }
    push();
  }
  // PIXORA tempo changes (tap, fader, MIDI, cues) → Link
  function watchPixora() {
    const c = cfg(), S = ctx.state.comp; if (!sock || c.mode === 'follow') return;
    if (lastPixBpm && Math.abs(S.bpm - lastPixBpm) >= 0.01 && Math.abs(S.bpm - st.bpm) >= 0.01) { send('bpm ' + (+S.bpm).toFixed(3)); lastLinkBpm = S.bpm; }
    lastPixBpm = S.bpm;
  }
  const send = line => { if (sock && !sock.destroyed) sock.write(line + '\n'); };
  function connect() {
    clearTimeout(retryT); const c = cfg(); if (!c.on) return;
    const s = sock = net.connect({ host: '127.0.0.1', port: c.port }); s.setEncoding('utf8'); s.setNoDelay(true);
    s.on('connect', () => { ctx.monitor('link', 'connected to Carabiner on port ' + c.port); lastPixBpm = ctx.state.comp.bpm; if (c.mode === 'lead') send('bpm ' + (+ctx.state.comp.bpm).toFixed(3)); send('status'); });
    s.on('data', d => { buf += d; let i; while ((i = buf.indexOf('\n')) >= 0) { const l = buf.slice(0, i); buf = buf.slice(i + 1); if (l.trim()) parse(l); } if (buf.length > 2000 && /\}\s*$/.test(buf)) { parse(buf); buf = ''; } });
    s.on('error', e => { st.error = e.code === 'ECONNREFUSED' ? 'Carabiner is not running' : e.message; });
    s.on('close', () => { if (sock === s) sock = null; st.status = cfg().on ? 'connecting' : 'off'; st.peers = 0; push(); if (cfg().on) retryT = setTimeout(() => { startHelper(); connect(); }, 2000); });
  }
  function startHelper() {
    if (proc || !cfg().on) return; const exe = findHelper(); if (!exe) { st.error = 'Carabiner (the Ableton Link helper) is not installed with this copy of PIXORA'; return; }
    try { const p = proc = spawn(exe, ['--port', String(cfg().port), '--daemon', '--poll', '20'], { windowsHide: true, stdio: 'ignore' }); ourProc = true;
      // only forget *this* helper: a restart (settings change) may already have started the next one
      p.on('exit', code => { if (proc === p) proc = null; if (cfg().on && code) ctx.monitor('link', 'Carabiner stopped (' + code + ')'); });
      p.on('error', e => { if (proc === p) proc = null; st.error = e.message; });
    } catch (e) { st.error = e.message; }
  }
  function start() { stop(); if (!cfg().on) { push(); return; } st.status = 'connecting'; startHelper(); setTimeout(connect, proc ? 600 : 0); pollT = setInterval(() => { watchPixora(); if (sock) send('status'); }, 250); push(); }
  function stop() { clearTimeout(retryT); clearInterval(pollT); if (sock) { const s = sock; sock = null; s.destroy(); } if (proc && ourProc) { try { proc.kill(); } catch {} } proc = null; st = { status: 'off', peers: 0, bpm: 0, beat: 0, at: 0, error: '' }; }
  function set(b) { const c = cfg(); for (const k of ['on', 'mode', 'quantum', 'port', 'latency']) if (k in b) c[k] = k === 'on' ? !!b.on : k === 'mode' ? (['follow', 'lead', 'both'].includes(b.mode) ? b.mode : c.mode) : +b[k] || c[k]; ctx.saveSettings(); start(); return view(); }
  async function http(p, req, res, url, send, readBody) {
    if (p !== '/api/link') return false;
    if (req.method === 'POST') { let b = {}; try { b = JSON.parse((await readBody(req)).toString() || '{}'); } catch {} send(res, 200, set(b)); } else send(res, 200, view());
    return true;
  }
  process.on('exit', () => { if (proc && ourProc) try { proc.kill(); } catch {} });
  start();
  return { view, set, http, stop, start };
};
