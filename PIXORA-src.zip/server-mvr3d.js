/* PIXORA — MVR 3D scene builder for the Stage 3D preview.
   Turns an MVR file (GeneralSceneDescription.xml + 3DS / glTF geometry) into one triangle list in metres, Y-up,
   plus fixture positions and beam directions. Nested groups, symbols (Symdef) and per-geometry matrices are followed.
   Output: { verts: Float32Array [x,y,z, nx,ny,nz, r,g,b]*, tris, fixtures: [{name, p:[x,y,z], d:[x,y,z]}], objects, skipped, bounds } */
'use strict';

const MAX_TRIS = 400000;
const COLORS = { Truss: [0.62, 0.64, 0.7], Support: [0.5, 0.5, 0.55], SceneObject: [0.34, 0.35, 0.42], Projector: [0.3, 0.3, 0.36], VideoScreen: [0.15, 0.15, 0.2], Fixture: [0.2, 0.2, 0.24], GroupObject: [0.34, 0.35, 0.42] };
const OBJ_TAGS = new Set(['SceneObject', 'Fixture', 'Truss', 'Support', 'VideoScreen', 'Projector', 'GroupObject', 'FocusPoint']);

// ---------- tiny XML tree parser (enough for MVR) ----------
function parseXml(xml) {
  const root = { tag: '#root', attrs: {}, children: [], text: '' }, stack = [root];
  const re = /<!--[\s\S]*?-->|<\?[\s\S]*?\?>|<!\[CDATA\[([\s\S]*?)\]\]>|<(\/?)([\w:.-]+)((?:\s+[\w:.-]+\s*=\s*(?:"[^"]*"|'[^']*'))*)\s*(\/?)>|([^<]+)/g;
  let m;
  while ((m = re.exec(xml))) {
    const top = stack[stack.length - 1];
    if (m[1] != null) { top.text += m[1]; continue; }
    if (m[6] != null) { top.text += m[6]; continue; }
    if (!m[3]) continue;
    if (m[2]) { if (stack.length > 1) stack.pop(); continue; }
    const attrs = {}; m[4].replace(/([\w:.-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g, (_, k, a, b) => { attrs[k] = decode(a != null ? a : b); });
    const node = { tag: m[3], attrs, children: [], text: '' }; top.children.push(node);
    if (!m[5]) stack.push(node);
  }
  return root;
}
const decode = s => s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
const kids = (n, tag) => n.children.filter(c => c.tag === tag);
const kid = (n, tag) => n.children.find(c => c.tag === tag);

// ---------- 4×3 affine transforms in MVR space (mm, Z-up). p' = x*u + y*v + z*w + o ----------
const IDENT = { u: [1, 0, 0], v: [0, 1, 0], w: [0, 0, 1], o: [0, 0, 0] };
function parseMatrix(s) {
  const n = String(s || '').match(/-?\d*\.?\d+(?:e[-+]?\d+)?/gi); if (!n || n.length < 12) return IDENT;
  const v = n.map(Number); return { u: v.slice(0, 3), v: v.slice(3, 6), w: v.slice(6, 9), o: v.slice(9, 12) };
}
const apply = (t, p) => [p[0] * t.u[0] + p[1] * t.v[0] + p[2] * t.w[0] + t.o[0], p[0] * t.u[1] + p[1] * t.v[1] + p[2] * t.w[1] + t.o[1], p[0] * t.u[2] + p[1] * t.v[2] + p[2] * t.w[2] + t.o[2]];
const applyDir = (t, p) => [p[0] * t.u[0] + p[1] * t.v[0] + p[2] * t.w[0], p[0] * t.u[1] + p[1] * t.v[1] + p[2] * t.w[1], p[0] * t.u[2] + p[1] * t.v[2] + p[2] * t.w[2]];
const compose = (parent, local) => ({ u: applyDir(parent, local.u), v: applyDir(parent, local.v), w: applyDir(parent, local.w), o: apply(parent, local.o) }); // parent ∘ local
const matOf = n => { const m = n && kid(n, 'Matrix'); return m ? parseMatrix(m.text) : IDENT; };

// ---------- geometry readers → { pos: Float32Array (mm, MVR Z-up), idx: Uint32Array } ----------
function read3ds(b) {
  const pos = [], idx = [];
  const walk = (s, e) => {
    let o = s;
    while (o + 6 <= e) {
      const id = b.readUInt16LE(o), len = b.readUInt32LE(o + 2); if (len < 6 || o + len > e) break;
      if (id === 0x4D4D || id === 0x3D3D) walk(o + 6, o + len);
      else if (id === 0x4000) { let k = o + 6; while (k < o + len && b[k]) k++; walk(k + 1, o + len); }
      else if (id === 0x4100) { // one triangle mesh: its own vertex + face lists
        const base = pos.length / 3; let verts = 0; let p = o + 6;
        while (p + 6 <= o + len) { const cid = b.readUInt16LE(p), cl = b.readUInt32LE(p + 2); if (cl < 6 || p + cl > o + len) break;
          if (cid === 0x4110) { const n = b.readUInt16LE(p + 6); verts = n; for (let i = 0; i < n * 3; i++) pos.push(b.readFloatLE(p + 8 + i * 4)); }
          else if (cid === 0x4120) { const n = b.readUInt16LE(p + 6); for (let i = 0; i < n; i++) { const q = p + 8 + i * 8; const a = b.readUInt16LE(q), c = b.readUInt16LE(q + 2), d = b.readUInt16LE(q + 4); if (a < verts && c < verts && d < verts) idx.push(base + a, base + c, base + d); } }
          p += cl; }
      }
      o += len;
    }
  };
  walk(0, b.length);
  return { pos: Float32Array.from(pos), idx: Uint32Array.from(idx) };
}
function readGlb(b) {
  if (b.length < 20 || b.toString('latin1', 0, 4) !== 'glTF') return null;
  const jl = b.readUInt32LE(12); const j = JSON.parse(b.toString('utf8', 20, 20 + jl));
  let bin = null; const bo = 20 + jl; if (bo + 8 <= b.length && b.readUInt32LE(bo + 4) === 0x004E4942) bin = b.subarray(bo + 8, bo + 8 + b.readUInt32LE(bo));
  if (!bin) return null;
  const view = a => { const bv = j.bufferViews[a.bufferView]; return { off: (bv.byteOffset || 0) + (a.byteOffset || 0), stride: bv.byteStride || 0 }; };
  const COMP = { 5120: 1, 5121: 1, 5122: 2, 5123: 2, 5125: 4, 5126: 4 };
  const readAcc = (ai, comps) => { const a = j.accessors[ai]; if (!a || a.bufferView == null) return null; const { off, stride } = view(a); const cs = COMP[a.componentType] || 4, st = stride || cs * comps, out = new Array(a.count * comps);
    for (let i = 0; i < a.count; i++) for (let c = 0; c < comps; c++) { const p = off + i * st + c * cs; out[i * comps + c] = a.componentType === 5126 ? bin.readFloatLE(p) : a.componentType === 5125 ? bin.readUInt32LE(p) : a.componentType === 5123 ? bin.readUInt16LE(p) : a.componentType === 5121 ? bin[p] : a.componentType === 5122 ? bin.readInt16LE(p) : bin.readInt8(p); }
    return out; };
  const pos = [], idx = [];
  const mat4 = n => { if (n.matrix) return n.matrix; const t = n.translation || [0, 0, 0], r = n.rotation || [0, 0, 0, 1], s = n.scale || [1, 1, 1]; const [x, y, z, w] = r;
    return [(1 - 2 * (y * y + z * z)) * s[0], 2 * (x * y + z * w) * s[0], 2 * (x * z - y * w) * s[0], 0, 2 * (x * y - z * w) * s[1], (1 - 2 * (x * x + z * z)) * s[1], 2 * (y * z + x * w) * s[1], 0, 2 * (x * z + y * w) * s[2], 2 * (y * z - x * w) * s[2], (1 - 2 * (x * x + y * y)) * s[2], 0, t[0], t[1], t[2], 1]; };
  const mul = (a, b2) => { const o = new Array(16); for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) { let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b2[c * 4 + k]; o[c * 4 + r] = s; } return o; };
  const visit = (ni, parent) => { const n = j.nodes[ni]; if (!n) return; const m = mul(parent, mat4(n));
    if (n.mesh != null) for (const pr of (j.meshes[n.mesh] || {}).primitives || []) { if (pr.mode != null && pr.mode !== 4) continue; const P = readAcc(pr.attributes.POSITION, 3); if (!P) continue; const base = pos.length / 3;
      for (let i = 0; i < P.length; i += 3) { const x = P[i], y = P[i + 1], z = P[i + 2]; const wx = m[0] * x + m[4] * y + m[8] * z + m[12], wy = m[1] * x + m[5] * y + m[9] * z + m[13], wz = m[2] * x + m[6] * y + m[10] * z + m[14];
        pos.push(wx * 1000, -wz * 1000, wy * 1000); } // glTF is metres, Y-up → MVR mm, Z-up
      const I = pr.indices != null ? readAcc(pr.indices, 1) : Array.from({ length: P.length / 3 }, (_, i) => i); for (const k of I) idx.push(base + k); }
    for (const c of n.children || []) visit(c, m); };
  const I4 = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]; const sc = (j.scenes || [])[j.scene || 0];
  for (const ni of (sc ? sc.nodes : (j.nodes || []).map((_, i) => i))) visit(ni, I4);
  return { pos: Float32Array.from(pos), idx: Uint32Array.from(idx) };
}

// ---------- scene walk ----------
function build(files, xml) {
  const root = parseXml(xml);
  const findFile = name => { if (!name) return null; const lo = name.toLowerCase(); const keys = Object.keys(files);
    return keys.find(f => f.toLowerCase() === lo) || keys.find(f => f.toLowerCase().endsWith('/' + lo)) || keys.find(f => /\.(3ds|glb)$/i.test(f) && f.toLowerCase().replace(/\.(3ds|glb)$/, '').endsWith(lo.replace(/\.(3ds|glb)$/, ''))) || null; };
  const geoCache = new Map();
  const geo = name => { const f = findFile(name); if (!f) return null; if (geoCache.has(f)) return geoCache.get(f); let g = null;
    try { g = /\.glb$/i.test(f) ? readGlb(files[f]) : /\.3ds$/i.test(f) ? read3ds(files[f]) : null; } catch { g = null; } geoCache.set(f, g); return g; };
  const symdefs = {}; const walkAll = n => { if (n.tag === 'Symdef' && n.attrs.uuid) symdefs[n.attrs.uuid] = n; n.children.forEach(walkAll); }; walkAll(root);

  const verts = []; let tris = 0, skipped = 0, objects = 0; const fixtures = []; const mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
  const emit = (g, t, col) => {
    if (!g || !g.idx.length) return;
    const n = g.idx.length / 3; if (tris + n > MAX_TRIS) { skipped += n; return; } tris += n;
    const P = i => { const w = apply(t, [g.pos[i * 3], g.pos[i * 3 + 1], g.pos[i * 3 + 2]]); return [w[0] / 1000, w[2] / 1000, -w[1] / 1000]; }; // mm Z-up → m Y-up
    for (let k = 0; k < g.idx.length; k += 3) {
      const a = P(g.idx[k]), b = P(g.idx[k + 1]), c = P(g.idx[k + 2]);
      const e1 = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], e2 = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
      let nx = e1[1] * e2[2] - e1[2] * e2[1], ny = e1[2] * e2[0] - e1[0] * e2[2], nz = e1[0] * e2[1] - e1[1] * e2[0]; const l = Math.hypot(nx, ny, nz) || 1; nx /= l; ny /= l; nz /= l;
      for (const p of [a, b, c]) { verts.push(p[0], p[1], p[2], nx, ny, nz, col[0], col[1], col[2]); for (let i = 0; i < 3; i++) { mn[i] = Math.min(mn[i], p[i]); mx[i] = Math.max(mx[i], p[i]); } }
    }
  };
  const geometries = (n, t, col, depth) => { // <Geometries>: Geometry3D and Symbol children
    if (!n || depth > 8) return;
    for (const g of n.children) {
      if (g.tag === 'Geometry3D') emit(geo(g.attrs.fileName), compose(t, matOf(g)), col);
      else if (g.tag === 'Symbol') { const sd = symdefs[g.attrs.symdef]; if (sd) { const st = compose(t, matOf(g)); const cl = kid(sd, 'ChildList'); if (cl) geometries(cl, st, col, depth + 1); } }
    }
  };
  const visit = (n, parent, depth) => {
    if (depth > 16) return;
    for (const c of n.children) {
      if (OBJ_TAGS.has(c.tag)) {
        const t = compose(parent, matOf(c)); objects++;
        if (c.tag === 'Fixture') { const p = apply(t, [0, 0, 0]), d = applyDir(t, [0, 0, -1]), dl = Math.hypot(...d) || 1;
          fixtures.push({ name: c.attrs.name || 'Fixture', p: [p[0] / 1000, p[2] / 1000, -p[1] / 1000].map(v => +v.toFixed(3)), d: [d[0] / dl, d[2] / dl, -d[1] / dl].map(v => +v.toFixed(3)) }); }
        else if (c.tag !== 'VideoScreen') geometries(kid(c, 'Geometries'), t, COLORS[c.tag] || COLORS.SceneObject, 0); // screens are drawn live, textured with the output
        const cl = kid(c, 'ChildList'); if (cl) visit(cl, t, depth + 1);
      } else if (c.tag !== 'AUXData' && c.tag !== 'Symdef') visit(c, c.tag === 'Layer' ? compose(parent, matOf(c)) : parent, depth + 1);
    }
  };
  visit(root, IDENT, 0);
  return { verts: Float32Array.from(verts), tris, fixtures: fixtures.slice(0, 5000), objects, skipped, bounds: isFinite(mn[0]) ? { min: mn.map(v => +v.toFixed(3)), max: mx.map(v => +v.toFixed(3)) } : null };
}

module.exports = { build, parseXml, read3ds, readGlb, parseMatrix };
