// PIXORA instant replay — Booth Productions. Server side: 4 replay units (A–D), marks, events and the shared playback
// clock. Output windows keep the rolling recordings (public/replay.js, WebCodecs) and all show the same frame, because
// the playhead is defined in server time:   pos(now) = play.at + (now − play.startedAt) × speed   (ms of recorded time)
'use strict';
const UNITS = ['A', 'B', 'C', 'D'];
const defaults = () => ({ units: UNITS.map(id => ({ id, source: 'off' })), seconds: 90, fps: 50, size: '720p', preroll: 4000, play: null, mark: { in: null, out: null },
  events: [], selected: 'A', autoTake: true, back: null });
function normalize(r) {
  const d = defaults(); r = Object.assign(d, r || {});
  r.units = UNITS.map(id => Object.assign({ id, source: 'off' }, (r.units || []).find(u => u && u.id === id) || {}));
  r.seconds = Math.max(10, Math.min(600, +r.seconds || 90)); r.fps = [25, 30, 50, 60].includes(+r.fps) ? +r.fps : 50;
  r.size = ['540p', '720p', '1080p'].includes(r.size) ? r.size : '720p'; r.events = (r.events || []).slice(-200);
  if (!UNITS.includes(r.selected)) r.selected = 'A'; return r;
}
const pos = (p, now) => !p ? now : p.paused ? p.pausedAt : p.at + (now - p.startedAt) * p.speed;

// cmd: { op:'replay', a: <action>, ... } → true if state changed
function apply(state, cmd, now, ctx) {
  const R = state.replay = normalize(state.replay), P = R.play, unit = u => UNITS.includes(String(u).toUpperCase()) ? String(u).toUpperCase() : R.selected;
  const takeReplay = () => { if (!R.autoTake) return; // put the Replay clip on air, remember what was there
    for (let li = 0; li < state.layers.length; li++) { const L = state.layers[li], ci = L.clips.findIndex(c => c && c.type === 'replay'); if (ci < 0) continue;
      if (L.active !== ci) { R.back = { layer: li, clip: L.active }; ctx.trigger(li, ci); } return; } };
  const giveBack = () => { if (!R.autoTake || !R.back) return; const b = R.back; R.back = null; if (b.clip == null) state.layers[b.layer].active = null; else ctx.trigger(b.layer, b.clip); };
  switch (cmd.a) {
    case 'unit': { const u = R.units.find(x => x.id === unit(cmd.unit)); u.source = cmd.source === 'program' ? 'program' : cmd.source === 'off' || cmd.source == null || cmd.source === '' ? 'off' : Math.max(0, +cmd.source | 0); return true; }
    case 'settings': for (const k of ['seconds', 'fps', 'size', 'preroll', 'autoTake']) if (k in cmd) R[k] = k === 'autoTake' ? !!cmd[k] : cmd[k]; state.replay = normalize(R); return true;
    case 'select': R.selected = unit(cmd.unit); if (P && cmd.follow !== false) P.unit = R.selected; return true;
    case 'mark': if (cmd.which === 'out') R.mark.out = P ? pos(P, now) : now; else { R.mark.in = P ? pos(P, now) : now; R.mark.out = null; } return true;
    case 'event': { const out = R.mark.out || (P ? pos(P, now) : now), inn = R.mark.in && R.mark.in < out ? R.mark.in : out - (+cmd.seconds || 8) * 1000;
      const n = R.events.length + 1; R.events.push({ id: 'e' + now.toString(36) + n, name: cmd.name || `Replay ${n}`, in: inn, out, unit: unit(cmd.unit), at: now, star: false }); R.mark = { in: null, out: null }; return true; }
    case 'play': { // an event, the marks, or the last N seconds
      const ev = cmd.event && R.events.find(e => e.id === cmd.event); let from, to = null;
      if (ev) { from = ev.in; to = ev.out; } else if (cmd.from === 'mark' && R.mark.in) { from = R.mark.in; to = R.mark.out; } else { from = now - (+cmd.seconds || 8) * 1000; }
      const speed = cmd.speed != null ? +cmd.speed : P ? P.speed : 0.5;
      R.play = { unit: unit(cmd.unit || (ev && ev.unit)), at: from, startedAt: now, speed: Math.max(0.05, Math.min(2, speed || 0.5)), end: to, event: ev ? ev.id : null, paused: false, loop: !!cmd.loop };
      R.selected = R.play.unit; takeReplay(); return true; }
    case 'speed': if (!P) return false; { const p = pos(P, now); P.speed = Math.max(0.05, Math.min(2, +cmd.speed || 1)); if (!P.paused) { P.at = p; P.startedAt = now; } } return true;
    case 'pause': if (!P) return false; if (P.paused) { P.at = P.pausedAt; P.startedAt = now; P.paused = false; } else { P.pausedAt = pos(P, now); P.paused = true; } return true;
    case 'jog': if (!P) return false; if (!P.paused) { P.pausedAt = pos(P, now); P.paused = true; } P.pausedAt += +cmd.ms || 0; return true;
    case 'angle': if (!P) { R.selected = unit(cmd.unit); return true; } { const p = pos(P, now); P.unit = unit(cmd.unit); R.selected = P.unit; if (!P.paused) { P.at = p; P.startedAt = now; } } return true;
    case 'live': R.play = null; giveBack(); return true;
    case 'deleteEvent': R.events = R.events.filter(e => e.id !== cmd.id); return true;
    case 'renameEvent': { const e = R.events.find(x => x.id === cmd.id); if (e) { if (cmd.name != null) e.name = String(cmd.name).slice(0, 60); if (cmd.star != null) e.star = !!cmd.star; } return true; }
    case 'clearEvents': R.events = []; return true;
  }
  return false;
}
// end of an event: hold the last frame (or loop); called from the server tick
function tick(state, now) {
  const P = state.replay && state.replay.play; if (!P || P.paused || P.end == null) return false;
  const p = pos(P, now); if (p < P.end) return false;
  if (P.loop) { P.at = state.replay.events.find(e => e.id === P.event) ? state.replay.events.find(e => e.id === P.event).in : P.at; P.startedAt = now; } else { P.paused = true; P.pausedAt = P.end; }
  return true;
}
module.exports = { UNITS, defaults, normalize, apply, tick, pos };
